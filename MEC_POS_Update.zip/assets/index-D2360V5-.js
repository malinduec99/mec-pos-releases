window.toSinhala=e=>{if(!e)return"";let t=e.toLowerCase();const n={th:"ත",dh:"ද",sh:"ශ",ch:"ච",kh:"ඛ",gh:"ඝ",ph:"ඵ",bh:"භ",jh:"ඣ",ng:"ඟ",kn:"ඥ"};Object.keys(n).forEach(d=>{t=t.replace(new RegExp(d,"g"),n[d])});const s={aa:"ා",ae:"ැ",ii:"ී",uu:"ූ",ee:"ේ",oo:"ෝ",au:"ෞ",a:"",e:"ෙ",i:"ි",o:"ො",u:"ු"},o={k:"ක",g:"ග",c:"ච",j:"ජ",T:"ඨ",D:"ඪ",t:"ට",d:"ඩ",n:"න",p:"ප",b:"බ",m:"ම",y:"ය",r:"ර",l:"ල",v:"ව",w:"ව",s:"ස",h:"හ",f:"ෆ"};let i="",c=0;for(;c<t.length;){let d=!1;if(c+1<t.length){let u=t.substr(c,2);s[u]&&(i+=s[u],c+=2,d=!0)}if(d)continue;let r=t[c];s[r]!==void 0?i+=s[r]:o[r]?i+=o[r]:i+=r,c++}return i};window.matchProductSku=(e,t)=>{if(!e||!t)return!1;const n=t.toLowerCase().trim(),s=e.toLowerCase();if(s===n)return!0;let o=s;if(o.startsWith("sku-")){const i=o.split("-");i.length>1&&(i.pop(),o=i.join("-"))}return o.includes(n)};window.COMMON_SEARCH_ALIASES={stepler:["stapler","staplar","steplar","staple","steple"],stapler:["stepler","staplar","steplar","staple","steple"],steple:["staple","stapler","stepler"],staple:["steple","stapler","stepler"],steples:["staples","stapler","stepler"],staples:["steples","stapler","stepler"],pin:["pins","steple pin","staple pin"],pins:["pin"],pensil:["pencil"],pencil:["pensil"],colour:["color"],color:["colour"],eraser:["iraser","rubber"],iraser:["eraser","rubber"],rubber:["eraser","iraser"],ruler:["rooler","rule"],rooler:["ruler"],scissors:["scissor","sissor","sissors"],scissor:["scissors","sissor","sissors"],sissor:["scissors","scissor"],glue:["glu","gum"],glu:["glue","gum"],gum:["glue","glu","gam"],tape:["tep","selotep","sellotape"],tep:["tape"],selotep:["sellotape","cellotape","tape"],sellotape:["selotep","cellotape","tape"],box:["boks"],boks:["box"],book:["buk","books"],buk:["book"],books:["book"],file:["fayil","fail","files"],fail:["file","fayil"],paper:["pepar","peper","papers"],pepar:["paper"],peper:["paper"],marker:["maka","maker","markers"],highlighter:["hilighter","hiliter"],tippex:["tipex","correct","correction"],battery:["betry","betari","batteries"],calculator:["calculater","kelculator"],cover:["kawar","kover","covers"],bag:["beg","bags"],bottle:["botle","botal","bottles"],paste:["pest"],board:["bod","boards"],whiteboard:["waitbod","whitebord"],crayons:["creyons","crayan","crayon"],clay:["kley"],bristol:["bristal"],envelope:["envelop","envalop","envelopes"]};window.splitSearchTokens=e=>e?String(e).toLowerCase().trim().split(/[\s,_\/\\+]+/).filter(t=>t.length>0):[];window.getSearchWordVariants=e=>{if(!e)return[];const t=new Set([e]),n=window.COMMON_SEARCH_ALIASES[e];if(n&&n.forEach(s=>t.add(s)),e.length>3&&e.endsWith("s")){const s=e.slice(0,-1);t.add(s),window.COMMON_SEARCH_ALIASES[s]&&window.COMMON_SEARCH_ALIASES[s].forEach(o=>t.add(o))}else e.length>2&&t.add(e+"s");if(window.toSinhala&&/[a-z]/i.test(e)&&e.length>=2){const s=window.toSinhala(e);s&&t.add(s)}return Array.from(t)};window.matchProductSearch=(e,t)=>{if(!e)return!1;if(!t||!String(t).trim())return!0;const n=window.splitSearchTokens(t);if(n.length===0)return!0;const s=(e.name||e.searchKeyName||"").toLowerCase(),o=(e.category||"").toLowerCase(),i=(e.description||"").toLowerCase(),c=(e.brand||e.supplierName||"").toLowerCase(),d=(e.sku||e.code||e.barcode||"").toLowerCase(),r=[],u=e.variants||e.allVariants||[];for(let g=0;g<u.length;g++){const a=u[g];a&&(a.name&&r.push(String(a.name).toLowerCase()),a.variantLabel&&r.push(String(a.variantLabel).toLowerCase()),a.sku&&r.push(String(a.sku).toLowerCase()),a.barcode&&r.push(String(a.barcode).toLowerCase()),a.size&&r.push(String(a.size).toLowerCase()),a.color&&r.push(String(a.color).toLowerCase()))}const l=[s,o,i,c,d,...r].join(" ");for(let g=0;g<n.length;g++){const a=n[g],h=window.getSearchWordVariants(a);let f=!1;for(let E=0;E<h.length;E++){const w=h[E];if(l.includes(w)){f=!0;break}if(window.matchProductSku(e.sku,w)){f=!0;break}if(u.some(C=>C&&C.sku&&window.matchProductSku(C.sku,w))){f=!0;break}}if(!f)return!1}return!0};window.getProductSearchScore=(e,t)=>{if(!e||!t)return 0;const n=String(t).toLowerCase().trim(),s=(e.name||e.searchKeyName||"").toLowerCase(),o=(e.sku||"").toLowerCase();let i=0;s===n&&(i+=500),o===n&&(i+=400),s.startsWith(n)&&(i+=200),s.includes(n)&&(i+=100);const c=window.splitSearchTokens(t);return c.length>0&&(s.startsWith(c[0])&&(i+=50),c.forEach(d=>{s.includes(d)&&(i+=20),o.includes(d)&&(i+=15)})),i};window.filterProductsSmart=(e,t)=>!e||!Array.isArray(e)?[]:!t||!String(t).trim()?e:e.filter(n=>window.matchProductSearch(n,t)).sort((n,s)=>{const o=window.getProductSearchScore(s,t),i=window.getProductSearchScore(n,t);return o!==i?o-i:(n.name||"").localeCompare(s.name||"")});window.matchOrderSearch=(e,t)=>{if(!e)return!1;if(!t||!String(t).trim())return!0;const n=window.splitSearchTokens(t);if(n.length===0)return!0;const s=(e.userName||e.customerName||"").toLowerCase(),o=(e.orderId||e.id||"").toLowerCase(),i=(e.phone||e.customerPhone||"").toLowerCase(),c=(e.invoiceNo||e.receiptNo||"").toLowerCase(),d=[];Array.isArray(e.items)&&e.items.forEach(u=>{u.name&&d.push(String(u.name).toLowerCase()),u.sku&&d.push(String(u.sku).toLowerCase())});const r=[s,o,i,c,...d].join(" ");for(let u=0;u<n.length;u++){const l=n[u],g=window.getSearchWordVariants(l);let a=!1;for(let h=0;h<g.length;h++)if(r.includes(g[h])){a=!0;break}if(!a)return!1}return!0};window.isChequeCleared=(e,t)=>{const n=e||t;if(!n)return!1;let s=null;const o=String(n).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(o)){const i=o.split("-"),c=parseInt(i[0],10),d=parseInt(i[1],10)-1,r=parseInt(i[2],10);s=new Date(c,d,r+1,17,0,0,0)}else{const i=new Date(o);isNaN(i.getTime())||(i.setDate(i.getDate()+1),i.setHours(17,0,0,0),s=i)}return s?new Date>=s:!1};window.getChequeClearanceTime=(e,t)=>{const n=e||t;if(!n)return null;const s=String(n).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(s)){const i=s.split("-");return new Date(parseInt(i[0],10),parseInt(i[1],10)-1,parseInt(i[2],10)+1,17,0,0,0)}const o=new Date(s);return isNaN(o.getTime())?null:(o.setDate(o.getDate()+1),o.setHours(17,0,0,0),o)};(function(){var d;const e={zdh:"ඳ",zd:"ඬ",zg:"ඟ",zj:"ඦ",zk:"ඥ",zh:"ඤ",thh:"ථ",dhh:"ධ",chh:"ඡ",kh:"ඛ",gh:"ඝ",ph:"ඵ",bh:"භ",sh:"ශ",Sh:"ෂ",ch:"ච",th:"ත",dh:"ද",J:"ඣ",T:"ඨ",D:"ඪ",B:"ඹ",S:"ෂ",N:"ණ",L:"ළ",k:"ක",g:"ග",t:"ට",d:"ඩ",n:"න",p:"ප",b:"බ",m:"ම",y:"ය",r:"ර",l:"ල",w:"ව",v:"ව",s:"ස",h:"හ",f:"ෆ",j:"ජ",c:"ච",nd:"ඳ",nnd:"ඳ",nndh:"ඳ",mb:"ඹ",nnb:"ඹ",ng:"ඟ",nng:"ඟ",gn:"ඥ",kn:"ඥ"},t={Aa:"ඈ",AA:"ඈ",aae:"ඈ",aa:"ආ",A:"ඇ",ae:"ඇ",a:"අ",ii:"ඊ",I:"ඊ",i:"ඉ",uu:"ඌ",U:"ඌ",u:"උ",Ru:"ඎ",R:"ඍ",ee:"ඒ",E:"ඒ",e:"එ",ai:"ඓ",oo:"ඕ",O:"ඕ",o:"ඔ",au:"ඖ",ou:"ඖ"},n={Aa:"ෑ",AA:"ෑ",aae:"ෑ",aa:"ා",A:"ැ",ae:"ැ",a:"",ii:"ී",I:"ී",i:"ි",uu:"ූ",U:"ූ",u:"ු",ruu:"ෲ",ru:"ෘ",ee:"ේ",E:"ේ",e:"ෙ",ai:"ෛ",oo:"ෝ",O:"ෝ",o:"ො",au:"ෞ",ou:"ෞ"},s=Object.keys(e).sort((r,u)=>u.length-r.length),o=Object.keys(n).sort((r,u)=>u.length-r.length);window.helakuruPhoneticConvert=function(r){if(!r)return"";let u="",l=0;const g=r.length;for(;l<g;){if(r[l]==="x"){u+="ං",l++;continue}if(r[l]==="H"){u+="ඃ",l++;continue}if(r[l]==="X"){u+="ඞ",l++;continue}if(r.startsWith("zn",l)){u+="ං",l+=2;continue}if(r[l]==="q"||r[l]==="Q"){u+="ං",l++;continue}if(!/[a-zA-Z]/.test(r[l])){u+=r[l],l++;continue}let a=null,h="";for(const f of s)if(r.startsWith(f,l)){a=e[f],h=f;break}if(a){l+=h.length;let f="";l<g&&r.startsWith("Ya",l)?(f="්‍ර්‍ය",l+=2):l<g&&r.startsWith("Ra",l)?(f="්‍ර්‍",l+=2):l<g&&r[l]==="y"&&h!=="y"?(f="්‍ය",l++):l<g&&r[l]==="r"&&h!=="r"&&(r.startsWith("ruu",l)||r.startsWith("ru",l)||(f="්‍ර",l++));let E=null,w="";for(const T of o)if(r.startsWith(T,l)){E=n[T],w=T;break}let C="";l<g&&r[l]==="H"?(C="ඃ",l++):l<g&&r[l]==="x"?(C="ං",l++):l<g&&r[l]==="X"&&(C="ඞ",l++);let m=a+f;w!==""?(u+=m+E+C,l+=w.length):f||C?u+=m+C:u+=m+"්"}else{let f=null,E="";for(const w of o)if(r.startsWith(w,l)){f=t[w],E=w;break}f?(u+=f,l+=E.length):(u+=r[l],l++)}}return u};let i=localStorage.getItem("mec_helakuru_mode")==="true";window.isHelakuruActive=()=>i,window.toggleHelakuruTyping=function(r,u=!1){var g;if(typeof r=="boolean"?i=r:i=!i,localStorage.setItem("mec_helakuru_mode",i?"true":"false"),window.updateHelakuruUI(),!u&&((g=window.chrome)!=null&&g.webview))try{window.chrome.webview.postMessage({type:"setInputLanguage",isSinhala:i})}catch{}const l=i?"🇱🇰 හෙළකුරු Phonetic සක්‍රීයයි (Ctrl+Space මඟින් මාරු කළ හැක)":"🔤 English Keyboard Active (Press Ctrl+Space to switch)";typeof window.showToast=="function"&&window.showToast(l,i?"success":"info")},window.updateHelakuruUI=function(){[document.getElementById("header-helakuru-btn"),document.getElementById("pos-header-helakuru-btn"),...document.querySelectorAll(".helakuru-toggle-btn")].filter(Boolean).forEach(u=>{const l=u.querySelector(".helakuru-icon")||u.querySelector("#header-helakuru-icon"),g=u.querySelector(".helakuru-label")||u.querySelector("#header-helakuru-label");i?(u.style.borderColor="rgba(16, 185, 129, 0.6)",u.style.background="rgba(16, 185, 129, 0.2)",u.style.color="#10b981",u.style.boxShadow="0 0 14px rgba(16, 185, 129, 0.35)",l&&(l.innerText="🇱🇰"),g&&(g.innerText="සිංහල (SI)")):(u.style.borderColor="rgba(255, 255, 255, 0.15)",u.style.background="rgba(15, 23, 42, 0.75)",u.style.color="#94a3b8",u.style.boxShadow="0 2px 10px rgba(0,0,0,0.2)",l&&(l.innerText="⌨️"),g&&(g.innerText="English (EN)"))})};function c(r,u,l){const g=r.selectionStart,a=r.selectionEnd,h=Math.max(0,g-u);r.setSelectionRange(h,a);let f=!1;try{f=document.execCommand("insertText",!1,l)}catch{f=!1}if(!f){const E=r.value,w=E.substring(0,h),C=E.substring(a);r.value=w+l+C;const m=h+l.length;r.setSelectionRange(m,m),r.dispatchEvent(new Event("input",{bubbles:!0})),r.dispatchEvent(new Event("change",{bubbles:!0}))}}document.addEventListener("keydown",function(r){const u=(r.metaKey||r.key==="OS"||r.key==="Meta")&&(r.code==="Space"||r.key===" "),l=r.ctrlKey&&(r.code==="Space"||r.key===" "),g=r.altKey&&r.shiftKey||r.altKey&&(r.code==="Space"||r.key===" ");if(u||l||g){r.preventDefault(),r.stopPropagation(),window.toggleHelakuruTyping();return}if(!i)return;const a=r.target;if(!a||a.tagName!=="INPUT"&&a.tagName!=="TEXTAREA")return;const h=(a.type||"text").toLowerCase();if(!["password","number","date","time","datetime-local","file","checkbox","radio","range","color"].includes(h)&&!(a.readOnly||a.disabled)&&a.dataset.noHelakuru!=="true"){if(r.ctrlKey||r.altKey||r.metaKey){a._helakuruBuffer="",a._helakuruInsertedLength=0;return}if(r.key==="Backspace"){if(a._helakuruBuffer&&a._helakuruBuffer.length>0){r.preventDefault(),a._helakuruBuffer=a._helakuruBuffer.slice(0,-1);const f=a._helakuruInsertedLength||0;if(a._helakuruBuffer.length>0){const E=window.helakuruPhoneticConvert(a._helakuruBuffer);c(a,f,E),a._helakuruInsertedLength=E.length}else c(a,f,""),a._helakuruInsertedLength=0;return}return}if(r.key&&r.key.length===1)if(/[a-zA-Z]/.test(r.key)){r.preventDefault(),a._helakuruBuffer||(a._helakuruBuffer="",a._helakuruInsertedLength=0),a._helakuruBuffer+=r.key;const f=window.helakuruPhoneticConvert(a._helakuruBuffer),E=a._helakuruInsertedLength||0;c(a,E,f),a._helakuruInsertedLength=f.length;return}else a._helakuruBuffer="",a._helakuruInsertedLength=0;else["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End","Enter","Tab","Escape"].includes(r.key)&&(a._helakuruBuffer="",a._helakuruInsertedLength=0)}},!0),document.addEventListener("focusin",function(r){r.target&&(r.target._helakuruBuffer="",r.target._helakuruInsertedLength=0)}),document.addEventListener("click",function(r){r.target&&(r.target.tagName==="INPUT"||r.target.tagName==="TEXTAREA")&&(r.target._helakuruBuffer="",r.target._helakuruInsertedLength=0)}),(d=window.chrome)!=null&&d.webview&&window.chrome.webview.addEventListener("message",function(r){try{const u=typeof r.data=="string"?JSON.parse(r.data):r.data;u&&u.type==="inputLanguageChanged"&&window.toggleHelakuruTyping(!!u.isSinhala,!0)}catch{}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>window.updateHelakuruUI()):setTimeout(()=>window.updateHelakuruUI(),500)})();var k;(function(e){e.STRING="string",e.NUMBER="number",e.INTEGER="integer",e.BOOLEAN="boolean",e.ARRAY="array",e.OBJECT="object"})(k||(k={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var L;(function(e){e.LANGUAGE_UNSPECIFIED="language_unspecified",e.PYTHON="python"})(L||(L={}));var M;(function(e){e.OUTCOME_UNSPECIFIED="outcome_unspecified",e.OUTCOME_OK="outcome_ok",e.OUTCOME_FAILED="outcome_failed",e.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"})(M||(M={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const D=["user","model","function","system"];var x;(function(e){e.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",e.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",e.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",e.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",e.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",e.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"})(x||(x={}));var H;(function(e){e.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",e.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",e.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",e.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",e.BLOCK_NONE="BLOCK_NONE"})(H||(H={}));var G;(function(e){e.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",e.NEGLIGIBLE="NEGLIGIBLE",e.LOW="LOW",e.MEDIUM="MEDIUM",e.HIGH="HIGH"})(G||(G={}));var U;(function(e){e.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",e.SAFETY="SAFETY",e.OTHER="OTHER"})(U||(U={}));var I;(function(e){e.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",e.STOP="STOP",e.MAX_TOKENS="MAX_TOKENS",e.SAFETY="SAFETY",e.RECITATION="RECITATION",e.LANGUAGE="LANGUAGE",e.BLOCKLIST="BLOCKLIST",e.PROHIBITED_CONTENT="PROHIBITED_CONTENT",e.SPII="SPII",e.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",e.OTHER="OTHER"})(I||(I={}));var B;(function(e){e.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",e.RETRIEVAL_QUERY="RETRIEVAL_QUERY",e.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",e.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",e.CLASSIFICATION="CLASSIFICATION",e.CLUSTERING="CLUSTERING"})(B||(B={}));var j;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.AUTO="AUTO",e.ANY="ANY",e.NONE="NONE"})(j||(j={}));var K;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.MODE_DYNAMIC="MODE_DYNAMIC"})(K||(K={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p extends Error{constructor(t){super(`[GoogleGenerativeAI Error]: ${t}`)}}class y extends p{constructor(t,n){super(t),this.response=n}}class J extends p{constructor(t,n,s,o){super(t),this.status=n,this.statusText=s,this.errorDetails=o}}class S extends p{}class z extends p{}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ee="https://generativelanguage.googleapis.com",te="v1beta",ne="0.24.1",se="genai-js";var v;(function(e){e.GENERATE_CONTENT="generateContent",e.STREAM_GENERATE_CONTENT="streamGenerateContent",e.COUNT_TOKENS="countTokens",e.EMBED_CONTENT="embedContent",e.BATCH_EMBED_CONTENTS="batchEmbedContents"})(v||(v={}));class oe{constructor(t,n,s,o,i){this.model=t,this.task=n,this.apiKey=s,this.stream=o,this.requestOptions=i}toString(){var t,n;const s=((t=this.requestOptions)===null||t===void 0?void 0:t.apiVersion)||te;let i=`${((n=this.requestOptions)===null||n===void 0?void 0:n.baseUrl)||ee}/${s}/${this.model}:${this.task}`;return this.stream&&(i+="?alt=sse"),i}}function ie(e){const t=[];return e!=null&&e.apiClient&&t.push(e.apiClient),t.push(`${se}/${ne}`),t.join(" ")}async function re(e){var t;const n=new Headers;n.append("Content-Type","application/json"),n.append("x-goog-api-client",ie(e.requestOptions)),n.append("x-goog-api-key",e.apiKey);let s=(t=e.requestOptions)===null||t===void 0?void 0:t.customHeaders;if(s){if(!(s instanceof Headers))try{s=new Headers(s)}catch(o){throw new S(`unable to convert customHeaders value ${JSON.stringify(s)} to Headers: ${o.message}`)}for(const[o,i]of s.entries()){if(o==="x-goog-api-key")throw new S(`Cannot set reserved header name ${o}`);if(o==="x-goog-api-client")throw new S(`Header name ${o} can only be set using the apiClient field`);n.append(o,i)}}return n}async function ae(e,t,n,s,o,i){const c=new oe(e,t,n,s,i);return{url:c.toString(),fetchOptions:Object.assign(Object.assign({},de(i)),{method:"POST",headers:await re(c),body:o})}}async function A(e,t,n,s,o,i={},c=fetch){const{url:d,fetchOptions:r}=await ae(e,t,n,s,o,i);return ce(d,r,c)}async function ce(e,t,n=fetch){let s;try{s=await n(e,t)}catch(o){le(o,e)}return s.ok||await ue(s,e),s}function le(e,t){let n=e;throw n.name==="AbortError"?(n=new z(`Request aborted when fetching ${t.toString()}: ${e.message}`),n.stack=e.stack):e instanceof J||e instanceof S||(n=new p(`Error fetching from ${t.toString()}: ${e.message}`),n.stack=e.stack),n}async function ue(e,t){let n="",s;try{const o=await e.json();n=o.error.message,o.error.details&&(n+=` ${JSON.stringify(o.error.details)}`,s=o.error.details)}catch{}throw new J(`Error fetching from ${t.toString()}: [${e.status} ${e.statusText}] ${n}`,e.status,e.statusText,s)}function de(e){const t={};if((e==null?void 0:e.signal)!==void 0||(e==null?void 0:e.timeout)>=0){const n=new AbortController;(e==null?void 0:e.timeout)>=0&&setTimeout(()=>n.abort(),e.timeout),e!=null&&e.signal&&e.signal.addEventListener("abort",()=>{n.abort()}),t.signal=n.signal}return t}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function N(e){return e.text=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),R(e.candidates[0]))throw new y(`${_(e)}`,e);return fe(e)}else if(e.promptFeedback)throw new y(`Text not available. ${_(e)}`,e);return""},e.functionCall=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),R(e.candidates[0]))throw new y(`${_(e)}`,e);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),F(e)[0]}else if(e.promptFeedback)throw new y(`Function call not available. ${_(e)}`,e)},e.functionCalls=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),R(e.candidates[0]))throw new y(`${_(e)}`,e);return F(e)}else if(e.promptFeedback)throw new y(`Function call not available. ${_(e)}`,e)},e}function fe(e){var t,n,s,o;const i=[];if(!((n=(t=e.candidates)===null||t===void 0?void 0:t[0].content)===null||n===void 0)&&n.parts)for(const c of(o=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)c.text&&i.push(c.text),c.executableCode&&i.push("\n```"+c.executableCode.language+`
`+c.executableCode.code+"\n```\n"),c.codeExecutionResult&&i.push("\n```\n"+c.codeExecutionResult.output+"\n```\n");return i.length>0?i.join(""):""}function F(e){var t,n,s,o;const i=[];if(!((n=(t=e.candidates)===null||t===void 0?void 0:t[0].content)===null||n===void 0)&&n.parts)for(const c of(o=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)c.functionCall&&i.push(c.functionCall);if(i.length>0)return i}const he=[I.RECITATION,I.SAFETY,I.LANGUAGE];function R(e){return!!e.finishReason&&he.includes(e.finishReason)}function _(e){var t,n,s;let o="";if((!e.candidates||e.candidates.length===0)&&e.promptFeedback)o+="Response was blocked",!((t=e.promptFeedback)===null||t===void 0)&&t.blockReason&&(o+=` due to ${e.promptFeedback.blockReason}`),!((n=e.promptFeedback)===null||n===void 0)&&n.blockReasonMessage&&(o+=`: ${e.promptFeedback.blockReasonMessage}`);else if(!((s=e.candidates)===null||s===void 0)&&s[0]){const i=e.candidates[0];R(i)&&(o+=`Candidate was blocked due to ${i.finishReason}`,i.finishMessage&&(o+=`: ${i.finishMessage}`))}return o}function b(e){return this instanceof b?(this.v=e,this):new b(e)}function ge(e,t,n){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var s=n.apply(e,t||[]),o,i=[];return o={},c("next"),c("throw"),c("return"),o[Symbol.asyncIterator]=function(){return this},o;function c(a){s[a]&&(o[a]=function(h){return new Promise(function(f,E){i.push([a,h,f,E])>1||d(a,h)})})}function d(a,h){try{r(s[a](h))}catch(f){g(i[0][3],f)}}function r(a){a.value instanceof b?Promise.resolve(a.value.v).then(u,l):g(i[0][2],a)}function u(a){d("next",a)}function l(a){d("throw",a)}function g(a,h){a(h),i.shift(),i.length&&d(i[0][0],i[0][1])}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;function Ee(e){const t=e.body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0})),n=Ce(t),[s,o]=n.tee();return{stream:we(s),response:pe(o)}}async function pe(e){const t=[],n=e.getReader();for(;;){const{done:s,value:o}=await n.read();if(s)return N(_e(t));t.push(o)}}function we(e){return ge(this,arguments,function*(){const n=e.getReader();for(;;){const{value:s,done:o}=yield b(n.read());if(o)break;yield yield b(N(s))}})}function Ce(e){const t=e.getReader();return new ReadableStream({start(s){let o="";return i();function i(){return t.read().then(({value:c,done:d})=>{if(d){if(o.trim()){s.error(new p("Failed to parse stream"));return}s.close();return}o+=c;let r=o.match(P),u;for(;r;){try{u=JSON.parse(r[1])}catch{s.error(new p(`Error parsing JSON response: "${r[1]}"`));return}s.enqueue(u),o=o.substring(r[0].length),r=o.match(P)}return i()}).catch(c=>{let d=c;throw d.stack=c.stack,d.name==="AbortError"?d=new z("Request aborted when reading from the stream"):d=new p("Error reading from the stream"),d})}}})}function _e(e){const t=e[e.length-1],n={promptFeedback:t==null?void 0:t.promptFeedback};for(const s of e){if(s.candidates){let o=0;for(const i of s.candidates)if(n.candidates||(n.candidates=[]),n.candidates[o]||(n.candidates[o]={index:o}),n.candidates[o].citationMetadata=i.citationMetadata,n.candidates[o].groundingMetadata=i.groundingMetadata,n.candidates[o].finishReason=i.finishReason,n.candidates[o].finishMessage=i.finishMessage,n.candidates[o].safetyRatings=i.safetyRatings,i.content&&i.content.parts){n.candidates[o].content||(n.candidates[o].content={role:i.content.role||"user",parts:[]});const c={};for(const d of i.content.parts)d.text&&(c.text=d.text),d.functionCall&&(c.functionCall=d.functionCall),d.executableCode&&(c.executableCode=d.executableCode),d.codeExecutionResult&&(c.codeExecutionResult=d.codeExecutionResult),Object.keys(c).length===0&&(c.text=""),n.candidates[o].content.parts.push(c)}o++}s.usageMetadata&&(n.usageMetadata=s.usageMetadata)}return n}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function X(e,t,n,s){const o=await A(t,v.STREAM_GENERATE_CONTENT,e,!0,JSON.stringify(n),s);return Ee(o)}async function Q(e,t,n,s){const i=await(await A(t,v.GENERATE_CONTENT,e,!1,JSON.stringify(n),s)).json();return{response:N(i)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Z(e){if(e!=null){if(typeof e=="string")return{role:"system",parts:[{text:e}]};if(e.text)return{role:"system",parts:[e]};if(e.parts)return e.role?e:{role:"system",parts:e.parts}}}function O(e){let t=[];if(typeof e=="string")t=[{text:e}];else for(const n of e)typeof n=="string"?t.push({text:n}):t.push(n);return Se(t)}function Se(e){const t={role:"user",parts:[]},n={role:"function",parts:[]};let s=!1,o=!1;for(const i of e)"functionResponse"in i?(n.parts.push(i),o=!0):(t.parts.push(i),s=!0);if(s&&o)throw new p("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!s&&!o)throw new p("No content is provided for sending chat message.");return s?t:n}function ve(e,t){var n;let s={model:t==null?void 0:t.model,generationConfig:t==null?void 0:t.generationConfig,safetySettings:t==null?void 0:t.safetySettings,tools:t==null?void 0:t.tools,toolConfig:t==null?void 0:t.toolConfig,systemInstruction:t==null?void 0:t.systemInstruction,cachedContent:(n=t==null?void 0:t.cachedContent)===null||n===void 0?void 0:n.name,contents:[]};const o=e.generateContentRequest!=null;if(e.contents){if(o)throw new S("CountTokensRequest must have one of contents or generateContentRequest, not both.");s.contents=e.contents}else if(o)s=Object.assign(Object.assign({},s),e.generateContentRequest);else{const i=O(e);s.contents=[i]}return{generateContentRequest:s}}function $(e){let t;return e.contents?t=e:t={contents:[O(e)]},e.systemInstruction&&(t.systemInstruction=Z(e.systemInstruction)),t}function me(e){return typeof e=="string"||Array.isArray(e)?{content:O(e)}:e}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],ye={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function Ie(e){let t=!1;for(const n of e){const{role:s,parts:o}=n;if(!t&&s!=="user")throw new p(`First content should be with role 'user', got ${s}`);if(!D.includes(s))throw new p(`Each item should include role field. Got ${s} but valid roles are: ${JSON.stringify(D)}`);if(!Array.isArray(o))throw new p("Content should have 'parts' property with an array of Parts");if(o.length===0)throw new p("Each Content should have at least one part");const i={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(const d of o)for(const r of Y)r in d&&(i[r]+=1);const c=ye[s];for(const d of Y)if(!c.includes(d)&&i[d]>0)throw new p(`Content with role '${s}' can't contain '${d}' part`);t=!0}}function V(e){var t;if(e.candidates===void 0||e.candidates.length===0)return!1;const n=(t=e.candidates[0])===null||t===void 0?void 0:t.content;if(n===void 0||n.parts===void 0||n.parts.length===0)return!1;for(const s of n.parts)if(s===void 0||Object.keys(s).length===0||s.text!==void 0&&s.text==="")return!1;return!0}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const q="SILENT_ERROR";class be{constructor(t,n,s,o={}){this.model=n,this.params=s,this._requestOptions=o,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=t,s!=null&&s.history&&(Ie(s.history),this._history=s.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(t,n={}){var s,o,i,c,d,r;await this._sendPromise;const u=O(t),l={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(c=this.params)===null||c===void 0?void 0:c.toolConfig,systemInstruction:(d=this.params)===null||d===void 0?void 0:d.systemInstruction,cachedContent:(r=this.params)===null||r===void 0?void 0:r.cachedContent,contents:[...this._history,u]},g=Object.assign(Object.assign({},this._requestOptions),n);let a;return this._sendPromise=this._sendPromise.then(()=>Q(this._apiKey,this.model,l,g)).then(h=>{var f;if(V(h.response)){this._history.push(u);const E=Object.assign({parts:[],role:"model"},(f=h.response.candidates)===null||f===void 0?void 0:f[0].content);this._history.push(E)}else{const E=_(h.response);E&&console.warn(`sendMessage() was unsuccessful. ${E}. Inspect response object for details.`)}a=h}).catch(h=>{throw this._sendPromise=Promise.resolve(),h}),await this._sendPromise,a}async sendMessageStream(t,n={}){var s,o,i,c,d,r;await this._sendPromise;const u=O(t),l={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(c=this.params)===null||c===void 0?void 0:c.toolConfig,systemInstruction:(d=this.params)===null||d===void 0?void 0:d.systemInstruction,cachedContent:(r=this.params)===null||r===void 0?void 0:r.cachedContent,contents:[...this._history,u]},g=Object.assign(Object.assign({},this._requestOptions),n),a=X(this._apiKey,this.model,l,g);return this._sendPromise=this._sendPromise.then(()=>a).catch(h=>{throw new Error(q)}).then(h=>h.response).then(h=>{if(V(h)){this._history.push(u);const f=Object.assign({},h.candidates[0].content);f.role||(f.role="model"),this._history.push(f)}else{const f=_(h);f&&console.warn(`sendMessageStream() was unsuccessful. ${f}. Inspect response object for details.`)}}).catch(h=>{h.message!==q&&console.error(h)}),a}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oe(e,t,n,s){return(await A(t,v.COUNT_TOKENS,e,!1,JSON.stringify(n),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ae(e,t,n,s){return(await A(t,v.EMBED_CONTENT,e,!1,JSON.stringify(n),s)).json()}async function Re(e,t,n,s){const o=n.requests.map(c=>Object.assign(Object.assign({},c),{model:t}));return(await A(t,v.BATCH_EMBED_CONTENTS,e,!1,JSON.stringify({requests:o}),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(t,n,s={}){this.apiKey=t,this._requestOptions=s,n.model.includes("/")?this.model=n.model:this.model=`models/${n.model}`,this.generationConfig=n.generationConfig||{},this.safetySettings=n.safetySettings||[],this.tools=n.tools,this.toolConfig=n.toolConfig,this.systemInstruction=Z(n.systemInstruction),this.cachedContent=n.cachedContent}async generateContent(t,n={}){var s;const o=$(t),i=Object.assign(Object.assign({},this._requestOptions),n);return Q(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}async generateContentStream(t,n={}){var s;const o=$(t),i=Object.assign(Object.assign({},this._requestOptions),n);return X(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}startChat(t){var n;return new be(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(n=this.cachedContent)===null||n===void 0?void 0:n.name},t),this._requestOptions)}async countTokens(t,n={}){const s=ve(t,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),o=Object.assign(Object.assign({},this._requestOptions),n);return Oe(this.apiKey,this.model,s,o)}async embedContent(t,n={}){const s=me(t),o=Object.assign(Object.assign({},this._requestOptions),n);return Ae(this.apiKey,this.model,s,o)}async batchEmbedContents(t,n={}){const s=Object.assign(Object.assign({},this._requestOptions),n);return Re(this.apiKey,this.model,t,s)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Te{constructor(t){this.apiKey=t}getGenerativeModel(t,n){if(!t.model)throw new p("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new W(this.apiKey,t,n)}getGenerativeModelFromCachedContent(t,n,s){if(!t.name)throw new S("Cached content must contain a `name` field.");if(!t.model)throw new S("Cached content must contain a `model` field.");const o=["model","systemInstruction"];for(const c of o)if(n!=null&&n[c]&&t[c]&&(n==null?void 0:n[c])!==t[c]){if(c==="model"){const d=n.model.startsWith("models/")?n.model.replace("models/",""):n.model,r=t.model.startsWith("models/")?t.model.replace("models/",""):t.model;if(d===r)continue}throw new S(`Different value for "${c}" specified in modelParams (${n[c]}) and cachedContent (${t[c]})`)}const i=Object.assign(Object.assign({},n),{model:t.model,tools:t.tools,toolConfig:t.toolConfig,systemInstruction:t.systemInstruction,cachedContent:t});return new W(this.apiKey,i,s)}}export{Te as G};
