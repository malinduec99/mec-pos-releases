/* empty css              */import{G as Xe}from"./index-BpRkNtKl.js";import{a as Y,c as L,d as P,s as Z,o as Ae,q as $,w as k,g as A,b as le,e as ze,i as Pe,f as et,h as tt,l as ot,j as rt,u as nt,k as at,m as Oe}from"./firebase-Bn3UcnFE.js";window.uploadLogToCloud=async(e,t="error")=>{try{const n=window.currentStoreId||"unknown",i=window.HostPCName||navigator.userAgent||"WebBrowser";await Y(L(P,"systemLogs"),{message:e,level:t,storeId:n,pcName:i,timestamp:Z()})}catch(n){console.error("Failed to upload log:",n)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function it(){try{const e=localStorage.getItem("mecThemeColors");if(e){const t=JSON.parse(e),n=document.documentElement;n.style.setProperty("--primary-blue",t.primary),n.style.setProperty("--accent-blue",t.accent),n.style.setProperty("--admin-bg",t.bg),n.style.setProperty("--glass-bg",t.glass),n.style.setProperty("--primary-color",t.primary),n.style.setProperty("--secondary-color",t.accent),n.style.setProperty("--deep-bg",t.bg),t.bg==="#0f172a"||t.bg==="#11011c"||t.bg==="#022c22"?(n.style.setProperty("--text-dark","#f8fafc"),n.style.setProperty("--text-muted","#94a3b8")):(n.style.setProperty("--text-dark","#0f172a"),n.style.setProperty("--text-muted","#64748b"))}}catch{}}it();function de(){const e=document.querySelector("header");if(e){const n=e.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(n)}px`)}const t=document.getElementById("product-grid-header");if(t&&e){const n=e.getBoundingClientRect().height,o=t.getBoundingClientRect().top<=Math.round(n)+2;t.classList.toggle("is-stuck",o)}}window.addEventListener("resize",de);window.addEventListener("scroll",de,{passive:!0});document.addEventListener("DOMContentLoaded",de);setTimeout(de,200);setTimeout(de,800);const Ve=new URLSearchParams(window.location.search),J=window.location.pathname.split("/").filter(e=>e!=="");let Ee=null;J[0]==="store"&&J[1]?Ee=J[1]:J[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(J[0])&&(Ee=J[0]);const st=Ve.get("store")||Ee;window.currentStoreId=st||null;window.currentStoreData=null;try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const me=L(P,"stores"),ee=window.location.hostname;async function lt(){let e=null;try{if(window.currentStoreId){const t=$(me,k("slug","==",window.currentStoreId)),n=await A(t);if(!n.empty)e={...n.docs[0].data(),docId:n.docs[0].id};else try{const i=le(P,"stores",window.currentStoreId),o=await et(i);o.exists()&&(e={...o.data(),docId:o.id})}catch{}}else if(["mecbookshop.web.lk","mecbookshop.com.lk","mec-book-shop.web.app","localhost","127.0.0.1"].includes(ee)){window.currentStoreId="mec-book-shop";const n=$(me,k("slug","==","mec-book-shop")),i=await A(n);i.empty||(e={...i.docs[0].data(),docId:i.docs[0].id})}else if(ee==="mecpos.web.lk"||ee==="mec-pos-shop.web.app"||ee==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const n=ee.replace(/^www\./,""),i=$(me,k("domain","==",n)),o=await A(i);o.empty||(e={...o.docs[0].data(),docId:o.docs[0].id})}}catch(t){console.error("Store resolution query failed:",t)}if(e)window.currentStoreData=e,window.currentStoreId=e.slug||e.storeSlug||e.docId||"mec-book-shop",console.log("Resolved Store ID:",window.currentStoreId),qe(),Ue(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{window.currentStoreId||(window.currentStoreId="mec-book-shop");try{const n=$(me,k("slug","==","mec-book-shop")),i=await A(n);i.empty||window.currentStoreId==="mec-book-shop"&&(window.currentStoreData=i.docs[0].data())}catch(n){console.error("Error loading fallback store data:",n)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),qe(),Ue(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}lt();function qe(){var w,u,f,g,y,h,C,b,S,v,T,B,z,O,R;let e=(w=window.currentStoreData)==null?void 0:w.name;e||(window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?e=window.currentStoreId.split("-").map(I=>I.charAt(0).toUpperCase()+I.slice(1)).join(" "):e="MEC Book Shop"),e==="MEC POS"&&(e="MEC Book Shop"),document.title=`${e} | Official Store`;const t=(f=(u=window.currentStoreData)==null?void 0:u.webDesign)==null?void 0:f.primary,n=(y=(g=window.currentStoreData)==null?void 0:g.webDesign)==null?void 0:y.accent;t&&document.documentElement.style.setProperty("--primary-color",t),n&&document.documentElement.style.setProperty("--secondary-color",n),document.querySelectorAll(".logo-text").forEach(I=>{I.innerText=e});const i=window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master";i?(document.querySelectorAll(".bookshop-brand-banner").forEach(I=>I.style.display="none"),document.querySelectorAll(".merchant-only").forEach(I=>I.style.display="")):(document.querySelectorAll(".bookshop-brand-banner").forEach(I=>I.style.display="block"),document.querySelectorAll(".merchant-only").forEach(I=>I.style.display="none"));const o=(h=window.currentStoreData)==null?void 0:h.logoUrl,a=o&&o.trim()!==""&&!o.includes("zenith_logo")&&!o.includes("/logo.png")?o:"/mec-logo.png";document.querySelectorAll(".logo-img, #pwa-install-banner img").forEach(I=>{I.src=a,I.style.display=i?"":I.classList.contains("merchant-only")?"none":""});const s=document.getElementById("hero");if(s){const I=(b=(C=window.currentStoreData)==null?void 0:C.webDesign)==null?void 0:b.bannerUrl,D=I&&I.length>10?I:window.currentStoreId==="mec-book-shop"?"/banner.png":null;if(D)s.innerHTML=`
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${D}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `;else{const xe=((v=(S=window.currentStoreData)==null?void 0:S.webContent)==null?void 0:v.welcome)||`Welcome to ${e}`,ke=((B=(T=window.currentStoreData)==null?void 0:T.webContent)==null?void 0:B.announce)||"Your premium destination for high-quality products and services.";s.innerHTML=`
        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">
          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${xe}</h1>
          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${ke}</p>
          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>
        </div>
      `}}const d=document.getElementById("page-title");d&&(d.innerText=`${e} | Official Store`);const r=document.getElementById("footer-copy");r&&(r.innerText=`© 2026 ${e}. All rights reserved.`);const l=((z=window.currentStoreData)==null?void 0:z.webEpinics)||{},c=!!l.multiVendor,p=!!l.affiliate;(O=document.getElementById("nav-sell-with-us"))==null||O.remove(),(R=document.getElementById("nav-affiliate-program"))==null||R.remove();const m=document.getElementById("nav-menu");if(m){const I=document.getElementById("nav-auth-item");if(c){const D=document.createElement("li");D.id="nav-sell-with-us",D.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',I?m.insertBefore(D,I):m.appendChild(D)}if(p){const D=document.createElement("li");D.id="nav-affiliate-program",D.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',I?m.insertBefore(D,I):m.appendChild(D)}}document.documentElement.classList.remove("loading-merchant")}let te;const W=document.createElement("div");W.id="pwa-install-banner";W.innerHTML=`
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>
            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>
        </div>
        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;W.style.display="none";document.body.appendChild(W);window.addEventListener("beforeinstallprompt",e=>{e.preventDefault(),te=e,W.style.display="block"});W.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){W.style.display="none";return}if(te){te.prompt();const{outcome:t}=await te.userChoice;t==="accepted"&&(W.style.display="none"),te=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const K=document.getElementById("menu-toggle"),F=document.getElementById("nav-menu"),_=document.getElementById("mobile-menu-overlay"),ye=()=>{F==null||F.classList.remove("active"),K==null||K.classList.remove("active"),_==null||_.classList.remove("active")};K==null||K.addEventListener("click",()=>{const e=F==null?void 0:F.classList.toggle("active");K==null||K.classList.toggle("active"),e?_==null||_.classList.add("active"):_==null||_.classList.remove("active")});const Se=document.getElementById("close-menu");Se==null||Se.addEventListener("click",ye);_==null||_.addEventListener("click",ye);F==null||F.querySelectorAll("a").forEach(e=>{e.addEventListener("click",ye)});function ce(e,t){var i;if(typeof e=="string"&&e.trim()!==""){const o=e.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const n=(i=window.currentStoreData)==null?void 0:i.logoUrl;return n&&n.trim()!==""&&!n.includes("zenith_logo.png")&&!n.includes("/logo.png")?n:"/mec-logo.png"}const dt=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}],oe=L(P,"products"),ct=L(P,"orders"),pt=L(P,"promotions"),ut=L(P,"branches"),mt=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let _e=[];Ae(ut,e=>{_e=e.docs.map(t=>({...t.data(),docId:t.id})),window.allStoreBranches=_e,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function re(){var i,o,a,s;const e=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master";let t=(window.allStoreBranches||[]).filter(d=>e||d.storeId===window.currentStoreId||!d.storeId);const n={docId:"main",name:(((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop")+" - Main Branch",location:((o=window.currentStoreData)==null?void 0:o.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",address:((a=window.currentStoreData)==null?void 0:a.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",city:"Horana",district:"Kalutara",phone:((s=window.currentStoreData)==null?void 0:s.phone)||"071 923 3388"};return t.length===0&&(t=[n]),t}window.getAllAvailableShops=re;function Ge(){const t=re().map(i=>(i.location||i.city||"").trim()).filter(i=>i.length>0);return Array.from(new Set([...t,...mt])).filter(Boolean).sort((i,o)=>i.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=Ge;let M=[],pe=0,x=[],G="All",N=1,Ie=12,Q="recommended",j="",Ce=null;document.getElementById("cart-count");function Ue(){let e;window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?e=$(oe):e=$(oe,k("storeId","==",window.currentStoreId)),Ae(e,t=>{const n=t.docs.map(o=>({...o.data(),id:o.id,docId:o.id,sku:o.data().sku||o.id}));if((window.currentStoreId==="mec-book-shop"||window.currentStoreId==="O8ywuZTKSwdL4z77RQ9M"||window.currentStoreId==="master")&&!n.some(a=>a.name&&a.name.trim().toLowerCase()==="other")&&t.docs.length>0){console.log("Auto-creating 'Other' product for MEC Book Shop...");const a={name:"Other",sku:"SKU-OTHER-0000-GEN-P1C0",category:"Uncategorized",mode:"Shop",supplierId:"General",supplierName:"General",cost:0,price:1,wholesalePrice:1,loyaltyPrice:1,discount:0,stock:999999,wStock:0,totalStock:999999,timestamp:Z(),salesToday:0,image:"",variants:[],payMethods:{cod:!0,bank:!0,shop:!0},storeId:window.currentStoreId};a.docId=a.sku,ze(le(P,"products",a.sku),a).catch(s=>console.error("Error creating 'Other' product:",s))}M=n.filter(o=>{const s=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?o.storeId==="mec-book-shop"||o.storeId==="master"||!o.storeId:o.storeId===window.currentStoreId,d=o.mode==="Shop"||o.mode==="Warehouse"||o.mode===void 0,r=o.status!=="pending";return s&&d&&r}),M.sort((o,a)=>{var s,d;return(((s=a.timestamp)==null?void 0:s.seconds)||0)-(((d=o.timestamp)==null?void 0:d.seconds)||0)}),M.length===0&&window.currentStoreId==="master"&&dt.forEach(async o=>{await Y(oe,o)}),q(),he()})}var je;(je=document.getElementById("product-sort"))==null||je.addEventListener("change",e=>{Q=e.target.value,N=1,q()});const gt=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.addEventListener("input",t=>{j=t.target.value.toLowerCase(),window.searchQuery=j,document.querySelectorAll("#store-search, .store-search-input").forEach(n=>{n!==t.target&&(n.value=t.target.value)}),N=1,q()})})};gt();window.renderProducts=q;window.clearSearch=()=>{j="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.value=""}),N=1,q()};function De(){localStorage.setItem("mec_cart",JSON.stringify(x))}function ft(){const e=localStorage.getItem("mec_cart");e&&(x=JSON.parse(e),pe=x.reduce((t,n)=>t+(n.quantity||1),0),we())}const ne=document.createElement("div");ne.id="cart-modal";document.body.appendChild(ne);const ae=document.createElement("div");ae.id="cart-overlay";document.body.appendChild(ae);window.toggleCart=e=>{e?(ne.classList.add("active"),ae.classList.add("active"),ve(),document.body.style.overflow="hidden"):(ne.classList.remove("active"),ae.classList.remove("active"),document.body.style.overflow="")};const ue=window.toggleCart;ae.onclick=()=>ue(!1);const yt=document.querySelectorAll('a[href="#cart"]');yt.forEach(e=>{e.onclick=t=>{t.preventDefault(),ye(),ue(!0)}});const Ke=document.getElementById("shop-now-btn");Ke&&Ke.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const Je={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function ht(){return["All",...new Set(M.map(t=>t.category))]}function he(){const e=ht(),t=document.getElementById("sidebar-category-list"),n=document.getElementById("mobile-category-bar");t&&(t.innerHTML=e.map(s=>`
      <li class="sidebar-cat-item ${s===G?"active":""}" data-category="${s}">
        <div class="cat-icon-text">
          <span class="cat-icon">${Je[s]||"📁"}</span>
          <span>${s}</span>
        </div>
        <span class="arrow">›</span>
      </li>
    `).join("")),n&&(n.innerHTML=e.map(s=>`
      <button class="mobile-cat-btn ${s===G?"active":""}" data-category="${s}">
        ${s}
      </button>
    `).join(""));const i=s=>{var r;G=s;const d=document.getElementById("featured-title");d&&(d.innerText=s==="All"?"Featured Collection":`${s} Collection`),q(),he(),H(),(r=document.getElementById("shop-section"))==null||r.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(s=>{s.addEventListener("click",d=>{d.stopPropagation(),i(d.currentTarget.dataset.category)}),s.addEventListener("mouseenter",d=>{const r=d.currentTarget.dataset.category;r!=="All"?bt(r,d.currentTarget):H()})}),document.querySelectorAll(".mobile-cat-btn").forEach(s=>{s.addEventListener("click",d=>i(d.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),a=document.getElementById("nav-category-btn");a&&o&&(a.onclick=s=>{s.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),H()})}document.addEventListener("click",e=>{const t=document.querySelector(".category-menu-wrapper");t&&!t.contains(e.target)&&(t.classList.remove("active"),typeof H=="function"&&H())});const U=document.getElementById("mega-menu");let be;function bt(e,t){if(!U)return;clearTimeout(be),document.querySelectorAll(".sidebar-cat-item").forEach(r=>r.classList.remove("active")),t==null||t.classList.add("active");const n=(M||[]).filter(r=>r.category===e),i={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`
      <div style="margin-bottom: 1.1rem;">
        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>
        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">
          <span>${Je[e]||"📁"}</span>
          <span>${e}</span>
        </div>
        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${n.length} Items Available</div>
      </div>
      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">
        <span>View All</span>
        <span>→</span>
      </button>
      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        ${i.map(r=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${r}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${r}</a>`).join("")}
      </div>
    `);const a=document.getElementById("mega-products-heading");a&&(a.innerText=`${e} Products (${n.length})`);const s=document.getElementById("mega-products-list");s&&(s.innerHTML=n.length>0?n.map(r=>`
          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${r.docId}')">
            <img src="${ce(r.image,r.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">
            <div class="mega-prod-info">
              <h5 title="${r.name}">${r.name}</h5>
              <div class="price">LKR ${Number(r.price||0).toFixed(2)}</div>
            </div>
          </a>
        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),U.style.top="calc(100% + 8px)",U.style.left="248px",U.classList.add("active");const d=U.getBoundingClientRect();if(d.right>window.innerWidth-16){const r=d.right-(window.innerWidth-16);U.style.left=`${Math.max(0,248-r)}px`}}function H(){be=setTimeout(()=>{U==null||U.classList.remove("active")},400)}U==null||U.addEventListener("mouseenter",()=>clearTimeout(be));var We;(We=document.getElementById("sidebar-category-list"))==null||We.addEventListener("mouseenter",()=>clearTimeout(be));window.filterByCategoryAndScroll=e=>{var n;G=e;const t=document.getElementById("featured-title");t&&(t.innerText=e==="All"?"Featured Collection":`${e} Collection`),q(),he(),H(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,t)=>{var i;G=t,q(),he();const n=document.getElementById("featured-title");n&&(n.innerText=`${e} in ${t}`),(i=document.getElementById("shop-section"))==null||i.scrollIntoView({behavior:"smooth"}),H()};window.scrollToProduct=e=>{const t=document.getElementById(`product-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"center"}),t.classList.add("highlight-pulse"),setTimeout(()=>t.classList.remove("highlight-pulse"),3e3),H())};function X(e,t=null,n=null){var p;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const i=(n||((p=window.currentUserProfile)==null?void 0:p.customerType)||"retail").toLowerCase();let o=0,a=0,s=0;t?(o=Number(t.price),(isNaN(o)||o<=0)&&(o=Number(e.price)||0),a=Number(t.wholesalePrice),(isNaN(a)||a<=0)&&(a=Number(e.wholesalePrice)||0),s=Number(t.loyaltyPrice),(isNaN(s)||s<=0)&&(s=Number(e.loyaltyPrice)||0)):(o=Number(e.price)||0,a=Number(e.wholesalePrice)||0,s=Number(e.loyaltyPrice)||0),isNaN(o)&&(o=0);let d=o,r=!1;i==="wholesale"&&a>0?(d=a,r=a!==o):i==="loyalty"&&s>0&&(d=s,r=s!==o);const l=Number(e.discount)||0,c=d*(1-(l>0?l/100:0));return{retailPrice:isNaN(o)?0:o,effectivePrice:isNaN(d)?0:d,discountedPrice:isNaN(c)?0:c,isSpecial:r,userType:i}}window.getCustomerEffectivePrice=X;function ie(e,t=null){return Ne(e,t,"web")}function Ne(e,t=null,n="web"){if(!e)return 0;if(n==="ShopPay"||n==="shop"||n==="Shop"){if(t){const a=parseFloat(t.stock)||0;if(a>0)return a}const o=parseFloat(e.stock||0);return o>0?o:0}else{if(t){const r=parseFloat(t.stock)||0,l=parseFloat(t.wStock)||0,c=r+l;if(c>0)return c}if(e.variants&&e.variants.length>0){const r=e.variants.reduce((l,c)=>l+(parseFloat(c.stock)||0)+(parseFloat(c.wStock)||0),0);if(r>0)return r}const o=parseFloat(e.stock||0),a=parseFloat(e.wStock||0),s=parseFloat(e.totalStock||0),d=o+a;return d>0?d:s>0?s:0}}const se=document.getElementById("product-detail-modal"),Me=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const t=(window.groupedProducts||[]).find(u=>u.docId===e)||M.find(u=>u.docId===e);if(!t)return;const n=Number(t.discount)||0,i=t.variants&&t.variants.length>0,o=i?t.variants[0]:null;let a=t.image;o&&(o.image?a=o.image:o.images&&o.images.length>0&&(a=o.images[0]));const s=X(t,o),d=s.userType,r=s.isSpecial,l=s.retailPrice,c=s.discountedPrice,p=ie(t,o),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let w="";if(i){const u=[...new Set(t.variants.map(g=>g.size).filter(Boolean))],f=[...new Set(t.variants.map(g=>g.color).filter(Boolean))];if(u.length>0||f.length>0){let g="";f.length>0&&(g=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Color</span>
              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||f[0]}</span>
            </div>
            <div class="variant-pill-container" id="color-pill-group">
              ${f.map(h=>{const C=m[h.toLowerCase()]||"#64748b";return`
                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||f[0])===h?"active":""}" 
                    style="background-color: ${C};" 
                    title="${h}" data-color="${h}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'color', '${h}')">
                  </button>
                `}).join("")}
            </div>
          </div>
        `);let y="";u.length>0&&(y=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Style / Size</span>
              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>
            </div>
            <div class="variant-pill-container" id="size-pill-group">
              ${u.map(h=>`
                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===h?"active":""}" 
                    data-size="${h}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'size', '${h}')">
                    ${h}
                  </button>
                `).join("")}
            </div>
          </div>
        `),w=`${g}${y}`}else w=`
        <div class="variant-selector-group">
          <div class="variant-selector-label">
            <span>Choose Option / MRP</span>
          </div>
          <div class="variant-pill-container">
            ${t.variants.map((g,y)=>{const h=ie(t,g);return`
              <div class="variant-mrp-card ${y===0?"active":""}" id="v-card-${y}"
                   onclick="window.updateDetailDisplay('${t.docId}', ${y})">
                <div style="flex:1;">
                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${g.name||g.variantLabel||g.color||g.size||`Option ${y+1}`}</div>
                  <div style="font-size: 0.75rem; color: #64748b;">${h>0?`In Stock (${h})`:"Out of stock"}</div>
                </div>
                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">
                  LKR ${(g.price||t.price||0).toLocaleString()}
                </div>
              </div>
            `}).join("")}
          </div>
        </div>
      `}se.innerHTML=`
        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>
        <div class="detail-content">
            <div class="detail-image-sec">
                <img src="${ce(a,t.name)}" id="detail-main-img" 
                    alt="${t.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">
            </div>

            <div class="detail-info-sec">
                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${t.category}</div>
                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${t.name}</h2>
                ${r?`<div style="font-size: 0.8rem; color: ${d==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${d.toUpperCase()} APPLIED</div>`:""}
                
                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">
                    ${n>0||r?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}
                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${c.toFixed(2)}</span>
                </div>
                
                ${w}

                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">
                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}
                </div>
                
                <div class="detail-actions-sec">
                    <button class="add-to-cart-btn detail-add-btn" 
                            onclick="window.handleDetailAddToCart('${t.docId}')">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `,window.activeDetailVariantIndex=0,se.classList.add("active"),Me.classList.add("active"),document.body.style.overflow="hidden",H(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,t,n)=>{const i=(window.groupedProducts||[]).find(s=>s.docId===e)||M.find(s=>s.docId===e);if(!i||!i.variants)return;const o=window.activeDetailVariantIndex||0;i.variants[o]||i.variants[0];let a=i.variants.findIndex(s=>t==="color"?s.color===n:t==="size"?s.size===n:!1);if(a===-1&&(a=0),t==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(d=>{d.classList.toggle("active",d.dataset.color===n)});const s=document.getElementById("detail-selected-color");s&&(s.innerText=n)}if(t==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(d=>{d.classList.toggle("active",d.dataset.size===n)});const s=document.getElementById("detail-selected-size");s&&(s.innerText=n)}window.updateDetailDisplay(e,a)};window.closeProductDetail=()=>{se.classList.remove("active"),Me.classList.remove("active"),document.body.style.overflow=""};Me.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,t)=>{window.activeDetailVariantIndex=Number(t);const n=(window.groupedProducts||[]).find(c=>c.docId===e)||M.find(c=>c.docId===e);if(!n)return;const i=n.variants&&n.variants.length>0?n.variants[t]:null,o=document.getElementById("detail-main-img"),a=document.getElementById("detail-stock"),s=se.querySelector(".detail-original-price"),d=se.querySelector(".detail-final-price");if(o){let c=n.image;i&&(i.image?c=i.image:i.images&&i.images.length>0&&(c=i.images[0])),o.src=ce(c,n.name)}document.querySelectorAll(".variant-mrp-card").forEach((c,p)=>{c.classList.toggle("active",p===Number(t))}),Number(n.discount);const r=X(n,i);s&&(s.innerText=`LKR ${r.retailPrice.toFixed(2)}`),d&&(d.innerText=`LKR ${r.discountedPrice.toFixed(2)}`);const l=ie(n,i);if(a){const c=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";a.innerHTML=c,a.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const t=(window.groupedProducts||[]).find(p=>p.docId===e)||M.find(p=>p.docId===e);if(!t)return;const n=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let i="Default",o=null;t.variants&&t.variants.length>0&&(o=t.variants[n]||t.variants[0],i=o.name||o.variantLabel||o.color||o.size||"Default");const s=X(t,o).effectivePrice,d=o&&o.cost!==void 0?Number(o.cost):Number(t.cost)||0,r=ie(t,o),l=x.findIndex(p=>p.docId===t.docId&&p.selectedVariant===i),c=l!==-1?(x[l].quantity||1)+1:1;if(t.mode!=="Service"&&t.mode!=="Technical"&&c>r){alert(`Sorry, out of stock! Only ${r} available.`);return}wt(t,i,s,d),window.closeProductDetail(),ue(!0)};function wt(e,t,n,i){const o=x.findIndex(a=>a.docId===e.docId&&a.selectedVariant===t);o!==-1?x[o].quantity=(x[o].quantity||1)+1:x.push({...e,selectedVariant:t,price:n,cost:i,quantity:1}),pe=x.reduce((a,s)=>a+(s.quantity||1),0),De(),we()}window.changeCartQty=(e,t,n)=>{var o;const i=x.findIndex(a=>a.docId===e&&a.selectedVariant===t);if(i!==-1){if(n>0){const a=M.find(s=>s.docId===e);if(a&&a.mode!=="Service"&&a.mode!=="Technical"){let s=null;t!=="Default"&&a.variants&&(s=a.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===t));const d=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",r=Ne(a,s,d);if((x[i].quantity||1)+n>r){alert(d==="ShopPay"?`Sorry! Only ${r} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${r} available.`);return}}}x[i].quantity=(x[i].quantity||1)+n,x[i].quantity<=0&&x.splice(i,1),pe=x.reduce((a,s)=>a+(s.quantity||1),0),De(),we(),ve()}};function we(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(t=>{t&&(t.innerText=pe,t.classList.add("bump"),setTimeout(()=>t.classList.remove("bump"),300))})}function Re(e,t,n){if(!e||!t||t.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let i=t;if(e.targetType==="specific_products"){const s=(e.selectedProducts||[]).map(d=>(d||"").trim().toLowerCase());if(i=t.filter(d=>{const r=(d.name||"").trim().toLowerCase(),l=(d.docId||"").trim().toLowerCase();return s.includes(r)||s.includes(l)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const s=(e.selectedCategories||[]).map(d=>(d||"").trim().toLowerCase());if(i=t.filter(d=>{const r=(d.category||"").trim().toLowerCase();return s.includes(r)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const o=i.reduce((s,d)=>{const r=d.discount||0,l=d.price*(1-r/100),c=d.quantity||1;return s+l*c},0);let a=0;return e.type==="Percentage"?a=o*(Number(e.value)/100):a=Math.min(o,Number(e.value)||0),{discountAmount:a,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function ve(){var i;const e=x.reduce((o,a)=>{const s=a.discount||0,d=a.price*(1-s/100),r=a.quantity||1;return o+d*r},0);let t=0;if(window.appliedCoupon){const o=Re(window.appliedCoupon,x);o.isValidForCart?t=o.discountAmount:window.appliedCoupon=null}const n=Math.max(0,e-t);ne.innerHTML=`
        <div class="cart-header">
            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>
            <button class="close-cart" id="close-cart-btn">&times;</button>
        </div>
        
        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">
            <div class="cart-body">
                ${x.length===0?`
                    <div class="cart-empty-state">
                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>
                        <p>Your cart is empty</p>
                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>
                    </div>
                `:x.map(o=>{const a=o.discount||0,s=o.price*(1-a/100),d=o.quantity||1,r=s*d;return`
                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">
                            <div class="cart-item-info" style="flex: 1;">
                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>
                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>
                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">
                                    ${a>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}
                                    LKR ${s.toFixed(2)} ${d>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${d} = LKR ${r.toFixed(2)}</span>`:""}
                                </div>
                            </div>
                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 
                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">
                                    -
                                </button>
                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${d}</span>
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 
                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">
                                    +
                                </button>
                            </div>
                        </div>
                    `}).join("")}
            </div>

            ${x.length>0?`
                <div class="cart-footer">
                    <div class="delivery-info-banner">
                        <span>🚚</span>
                        <span>COD LKR 400 | Bank Transfer LKR 250</span>
                    </div>

                    <!-- Promo / Coupon Code Section -->
                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; gap: 0.5rem;">
                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>
                            ${window.appliedCoupon?`
                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>
                            `:`
                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>
                            `}
                        </div>
                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">
                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}
                        </div>
                    </div>
                    
                    ${window.appliedCoupon?`
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">
                            <span>Subtotal</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">
                            <span>Coupon Discount (${window.appliedCoupon.code})</span>
                            <span>- LKR ${t.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">
                            <span>Total Payable</span>
                            <span>LKR ${n.toFixed(2)}</span>
                        </div>
                    `:`
                        <div class="cart-subtotal">
                            <span>Total Payable</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="checkout-form-section">
                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>
                        <div class="input-group">
                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">
                        </div>
                        <div class="input-group">
                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">
                        </div>
                        <div class="input-group" id="delivery-address-group">
                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">
                        </div>
                        <div class="input-group" id="delivery-city-group">
                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">
                        </div>

                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>
                        <div class="payment-method-selector">
                            ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">
                                <span class="method-label">COD</span>
                            </label>
                            `:""}
                            ${x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="Bank" ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">
                                <span class="method-label">Transfer</span>
                            </label>
                            `:""}
                            ${x.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="ShopPay" ${!x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">
                                <span class="method-label">Shop Cash</span>
                            </label>
                            `:""}
                        </div>
                        
                        <!-- Bank Transfer Info Box -->
                        <!-- Bank Transfer Info Box -->
                        <div id="bank-details-box" style="display: none;">
                            <p style="color: #166534; font-weight: 800; margin-bottom: 0.5rem; font-size: 0.8rem; display: flex; align-items: center; gap: 6px;">
                                <span>✨</span> Lower delivery charge (LKR 250) - Transfer to any account below:
                            </p>

                            <!-- Account 1: National Development Bank (NDB) -->
                            <div class="bank-info-card" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 0.85rem; margin: 0.5rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                                <div style="font-weight: 900; color: #b91c1c; font-size: 0.95rem; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center;">
                                    <span>🏦 National Development Bank (NDB)</span>
                                    <span style="font-size: 0.72rem; background: #fee2e2; color: #991b1b; padding: 2px 8px; border-radius: 6px; font-weight: 700;">NDB</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600;">
                                    <span>Account Name: <span style="color: #0f172a; font-weight: 700;">MEC BOOK SHOP & COMMUNICATION</span></span>
                                    <button type="button" onclick="navigator.clipboard.writeText('MEC BOOK SHOP & COMMUNICATION'); alert('Account Name Copied: MEC BOOK SHOP & COMMUNICATION');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600;">
                                    Account Type: <span style="color: #0f172a; font-weight: 700;">Regular Current</span>
                                </div>
                                <div style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600;">
                                    <span>Bank Code: <strong style="color: #334155;">7214</strong></span>
                                    <span>Swift Code: <strong style="color: #334155;">NDBSLKLX</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>
                                    </div>
                                    <button type="button" onclick="navigator.clipboard.writeText('111000391437'); alert('NDB Account Number Copied: 111000391437');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <!-- Account 2: Bank of Ceylon (BOC) -->
                            <div class="bank-info-card" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                                <div style="font-weight: 900; color: #0284c7; font-size: 0.95rem; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center;">
                                    <span>🏦 Bank of Ceylon (BOC)</span>
                                    <span style="font-size: 0.72rem; background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 6px; font-weight: 700;">BOC</span>
                                </div>
                                <div style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600;">
                                    Branch: <span style="color: #0f172a; font-weight: 700;">Horana Branch</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600;">
                                    <span>Account Name: <span style="color: #0f172a; font-weight: 700;">WPM Shamesh</span></span>
                                    <button type="button" onclick="navigator.clipboard.writeText('WPM Shamesh'); alert('Account Name Copied: WPM Shamesh');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>
                                    </div>
                                    <button type="button" onclick="navigator.clipboard.writeText('0084334885'); alert('BOC Account Number Copied: 0084334885');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <div style="margin-top: 1rem;">
                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>
                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">
                            </div>
                        </div>

                        <!-- Shop Pickup / Branch Selection Box -->
                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch
                            </p>

                            <!-- City / Town Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>
                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>
                                  ${Ge().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}
                                </select>
                            </div>

                            <!-- Shop / Branch List Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>
                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <!-- Injected by populatePickupShops -->
                                </select>
                            </div>

                            <!-- Selected Shop Info Card -->
                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">
                            </div>
                        </div>
                    </div>

                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">
                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">
                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">
                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 
                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 
                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.
                        </label>
                    </div>

                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">
                        Confirm Order
                    </button>
                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->
                </div>
            `:""}
        </div>
    `,document.getElementById("close-cart-btn").onclick=()=>ue(!1),(i=document.getElementById("checkout-btn"))==null||i.addEventListener("click",vt),window.toggleBankDetails=o=>{const a=document.getElementById("bank-details-box");a&&(a.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const a=document.getElementById("bank-details-box"),s=document.getElementById("shop-pickup-box"),d=document.getElementById("delivery-address-group"),r=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(a&&(a.style.display="block"),s&&(s.style.display="none"),d&&(d.style.display="block"),r&&(r.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(a&&(a.style.display="none"),s&&(s.style.display="block",window.populatePickupShops()),d&&(d.style.display="none"),r&&(r.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(a&&(a.style.display="none"),s&&(s.style.display="none"),d&&(d.style.display="block"),r&&(r.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var c,p,m,w;const o=document.getElementById("pickup-town-select"),a=document.getElementById("pickup-shop-select"),s=document.getElementById("selected-shop-info-card");if(!a)return;const d=o?o.value:"All",r=re();let l=r;d&&d!=="All"&&(l=r.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(d.toLowerCase()))),l.length===0?(a.innerHTML=r.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),s&&(s.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${d}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((c=r[0])==null?void 0:c.docId)||((p=r[0])==null?void 0:p.id)||0)):(a.innerHTML=l.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((w=l[0])==null?void 0:w.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const a=document.getElementById("selected-shop-info-card");if(!a)return;const s=re(),d=s.find(r=>r.docId===o||r.id===o)||s[0];d&&(a.innerHTML=`
        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${d.name||d.shopName||"Main Branch"}</div>
        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${d.location||d.address||"In-store Pickup Counter"}</div>
        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${d.phone?`Contact: <b>${d.phone}</b>`:"Store Pickup Active"}</div>
        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">
          <span>✓</span> Collect & Pay Cash at this shop counter
        </div>
      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),t=document.getElementById("promo-message");if(!e)return;const n=e.value.trim().toUpperCase();if(!n){t&&(t.innerText="❌ Please enter a promo code.",t.style.color="#ef4444");return}t&&(t.innerText="⏳ Validating coupon...",t.style.color="var(--primary-color)");try{const i=$(pt,k("code","==",n),k("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty){t&&(t.innerText="❌ Invalid or expired coupon code.",t.style.color="#ef4444");return}const a=o.docs[0],s={...a.data(),id:a.id},d=new Date().toISOString().split("T")[0];if(s.expiryDate<d){t&&(t.innerText="❌ This coupon has expired.",t.style.color="#ef4444");return}if(s.status!=="Active"){t&&(t.innerText="❌ This coupon is inactive.",t.style.color="#ef4444");return}const r=x.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=Re(s,x,r);if(!l.isValidForCart){t&&(t.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,t.style.color="#ef4444");return}window.appliedCoupon=s,ve();const c=document.getElementById("promo-message");if(c){const p=s.targetType==="specific_products"?" (Selected Items)":s.targetType==="specific_categories"?" (Selected Categories)":"";c.innerText=`✅ Coupon applied: ${s.type==="Percentage"?`${s.value}% OFF`:`LKR ${s.value} OFF`}${p}`,c.style.color="#10b981"}}catch(i){console.error("Error validating coupon:",i),t&&(t.innerText="❌ Error validating coupon code.",t.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,ve()};async function vt(){var m,w,u,f,g,y,h,C;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!"),window.location.href="/login.html";return}if(x.length===0)return;const t=document.getElementById("terms-agree");if(t&&!t.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const n=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),i=(w=document.getElementById("delivery-phone-2"))==null?void 0:w.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),a=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),s=((g=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:g.value)||"COD",d=(y=document.getElementById("deposit-slip"))==null?void 0:y.files[0],r=s==="ShopPay";let l=null,c="All";if(r){c=((h=document.getElementById("pickup-town-select"))==null?void 0:h.value)||"All";const b=(C=document.getElementById("pickup-shop-select"))==null?void 0:C.value,S=re();if(l=S.find(v=>v.docId===b||v.id===b)||S[0],!b&&(!S||S.length===0)){alert("Please select a pickup shop / branch!");return}}if(!n||!r&&(!o||!a)){alert(r?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",n),localStorage.setItem("mec_saved_phone2",i),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",a),s==="Bank"&&!d){alert("Please upload your bank deposit slip!");return}for(const b of x){const S=M.find(v=>v.docId===b.docId)||(window.groupedProducts||[]).find(v=>v.docId===b.docId);if(S&&S.mode!=="Service"&&S.mode!=="Technical"){let v=null;b.selectedVariant&&b.selectedVariant!=="Default"&&S.variants&&(v=S.variants.find(B=>(B.name||B.variantLabel||B.color||B.size||"Variant")===b.selectedVariant));const T=Ne(S,v,s);if((b.quantity||1)>T){alert(s==="ShopPay"?`Sorry! "${b.name}" only has ${T} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${b.name}" only has ${T} available in stock.`);return}}}const p=async(b=null)=>{var S;try{const v=x.reduce((E,V)=>E+V.price*(1-(V.discount||0)/100)*(V.quantity||1),0);let T=0,B="";if(window.appliedCoupon){B=window.appliedCoupon.code;const E=Re(window.appliedCoupon,x,v);E.isValidForCart&&(T=E.discountAmount)}const z=Math.max(0,v-T),O=sessionStorage.getItem("mec_ref_code");let R="",I=0;if(O)try{const E=$(L(P,"affiliates"),k("code","==",O),k("storeId","==",window.currentStoreId));(await A(E)).empty||(R=O,I=Number((z*.05).toFixed(2)))}catch(E){console.error("Error verifying affiliate referral code at checkout:",E)}const D=window.currentStoreId||"mec-book-shop",xe=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),ke=e&&(e.name||e.email)?e.name||e.email:n||"Guest Customer",Ye={orderId:"ORD-"+Date.now(),userId:xe,userName:ke,userEmail:e&&e.email?e.email:"",phone:n||"",phone2:i||"",branchId:r?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:r?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:r?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:r?c:"",pickupShopPhone:r&&(l==null?void 0:l.phone)||"",pickupShopAddress:r&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:r?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:r?c!=="All"?c:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":a||"",items:x.map(E=>({id:E.id||E.docId||"",docId:E.docId||E.id||"",name:E.name||"",price:Number(E.price)||0,cost:Number(E.cost)||0,quantity:Number(E.quantity)||1,discount:Number(E.discount)||0,finalPrice:Number(E.price)*(1-(Number(E.discount)||0)/100)})),subtotal:Number(v)||0,discount:Number(T)||0,couponCode:B||"",total:Number(z)||0,status:"Pending",customerType:(((S=window.currentUserProfile)==null?void 0:S.customerType)||"retail").toLowerCase(),paymentMethod:s||"COD",slipImage:b||"",codCharge:s==="COD"?400:s==="Bank"?250:0,isShopPending:s==="ShopPay",storeId:D,numericStoreId:"1001",timestamp:Z(),date:new Date().toLocaleString(),referredBy:R||"",referredCommission:Number(I)||0};if(await Y(ct,Ye),R)try{const E=$(L(P,"affiliates"),k("code","==",R),k("storeId","==",D)),V=await A(E);if(!V.empty){const Ze=V.docs[0].id;await ze(le(P,"affiliates",Ze),{salesCount:Pe(1),totalCommission:Pe(I)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(E){console.error("Error updating affiliate statistics post-order:",E)}x=[],pe=0,window.appliedCoupon=null,De(),we(),ue(!1),alert(s==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":r?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch(v){console.error("Order error:",v),alert("Error placing order: "+(v.message||"Please try again."))}};if(d){const b=new FileReader;b.onload=S=>{const v=new Image;v.onload=()=>{const T=document.createElement("canvas"),B=1e3,z=1e3;let O=v.width,R=v.height;O>R?O>B&&(R*=B/O,O=B):R>z&&(O*=z/R,R=z),T.width=O,T.height=R,T.getContext("2d").drawImage(v,0,0,O,R);const D=T.toDataURL("image/jpeg",.6);p(D)},v.onerror=()=>{p(S.target.result)},v.src=S.target.result},b.onerror=S=>{console.error("FileReader Error:",S),alert("Error reading slip file. Please try selecting the image again.")},b.readAsDataURL(d)}else p()}function q(){const e=document.querySelector("#product-grid"),t=document.getElementById("pagination-controls");if(!e)return;let n=M.filter(r=>{if(r.mode==="Service"||r.mode==="Technical"||r.mode==="POS")return!1;const l=(r.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const c=G==="All"||r.category===G,p=r.name.toLowerCase().includes(j)||r.category.toLowerCase().includes(j)||r.sku&&r.sku.toLowerCase().includes(j);return c&&p});Q==="recommended"?((!Ce||Ce.length!==n.length)&&(Ce=n.map((r,l)=>({id:l,sort:Math.random()})).sort((r,l)=>r.sort-l.sort).map(r=>r.id)),n.sort(()=>Math.random()-.5)):n.sort((r,l)=>{if(Q==="az")return r.name.localeCompare(l.name);if(Q==="za")return l.name.localeCompare(r.name);if(Q==="low"){const c=r.variants&&r.variants.length>0?r.variants[0].price:r.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return c-p}if(Q==="high"){const c=r.variants&&r.variants.length>0?r.variants[0].price:r.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-c}return 0});const i=new Map;n.forEach(r=>{const l=r.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),c=l?l[1].trim():r.name.trim(),p=l?l[2].trim():(r.size||r.color)&&`${r.size?r.size:""} ${r.color?r.color:""}`.trim()||"Default",m=c.toLowerCase();if(i.has(m)){const w=i.get(m);w.totalStock+=r.totalStock!==void 0?r.totalStock:r.stock||0;const u=(r.variants||[]).map(f=>({...f,sourceDocId:r.docId}));u.length===0&&u.push({name:p,price:r.price,wholesalePrice:r.wholesalePrice,loyaltyPrice:r.loyaltyPrice,cost:r.cost,stock:r.stock||0,images:[r.image],sourceDocId:r.docId}),w.variants=[...w.variants,...u]}else{const w=(r.variants||[]).map(u=>({...u,sourceDocId:r.docId}));w.length===0&&w.push({name:p,price:r.price,wholesalePrice:r.wholesalePrice,loyaltyPrice:r.loyaltyPrice,cost:r.cost,stock:r.stock||0,images:[r.image],sourceDocId:r.docId}),i.set(m,{...r,name:c,totalStock:r.totalStock!==void 0?r.totalStock:r.stock||0,variants:w})}}),window.groupedProducts=Array.from(i.values());const o=window.groupedProducts.length,a=Math.ceil(o/Ie);N>a&&a>0&&(N=a),N<1&&(N=1);const s=(N-1)*Ie,d=window.groupedProducts.slice(s,s+Ie);if(window.groupedProducts.length===0){e.innerHTML=`
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>
        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${j}</strong>".<br>Try a different keyword or browse all categories.</p>
        <button onclick="window.clearSearch()" 
          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"
          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
          Clear Search
        </button>
      </div>`,t&&(t.innerHTML="");return}if(e.innerHTML=d.map(r=>{const l=r.variants&&r.variants.length>0,c=l?r.variants[0]:null,p=X(r,c),m=p.retailPrice,w=p.discountedPrice,u=p.isSpecial,f=p.userType,g=Number(r.discount)||0;let y=ie(r,c);isNaN(y)&&(y=0);let h=r.image;(!h||h.trim()===""||h.includes("/logo.png"))&&c&&(c.images&&c.images.length>0?h=c.images[0]:c.image&&(h=c.image)),h=ce(h,r.name);const C=r.timestamp?typeof r.timestamp.toMillis=="function"?r.timestamp.toMillis():typeof r.timestamp=="number"?r.timestamp:0:0,b=C>0&&Date.now()-C<10080*60*1e3;return`
    <div class="product-card" id="product-${r.docId}">
      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${r.docId}')">
        <div class="image-slider-container" style="height: 100%; width: 100%;">
            <img src="${h}" class="main-product-img" alt="${r.name}" 
                loading="lazy" decoding="async"
                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 
                style="width:100%; height:100%; object-fit:cover;">
        </div>
        ${y<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}
        ${g>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${g}% OFF</div>`:b?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}
        
        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">
            ${((c==null?void 0:c.images)||[r.image]).map((S,v)=>`<div class="dot ${v===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${v===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}
        </div>

        ${l?`
          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${r.docId}')">
            Select Options
          </button>
        `:`
          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${r.docId}')" ${y<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>
            ${y<=0?"Out of Stock":"Add to Cart"}
          </button>
        `}
      </div>
      <div class="product-info">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">
          <div style="font-size: 0.8rem; color: var(--text-light);">${r.category}</div>
          <div class="stock-display" style="font-size: 0.75rem; color: ${y<5?"#ef4444":"#10b981"}; font-weight:700;">Stock: ${y}</div>
        </div>
        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${r.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">
          ${r.name}
        </div>
        


        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">
            ${g>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${m.toFixed(2)}</span>`:""}
            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${w.toFixed(2)}</span>
            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}
        </div>
      </div>
    </div>`}).join(""),t)if(a>1){let r=`<button class="pag-nav-btn" ${N===1?"disabled":""} onclick="window.changePage(${N-1})">‹ Previous</button>`;const l=5;let c=Math.max(1,N-2),p=Math.min(a,c+l-1);p===a&&(c=Math.max(1,p-l+1)),c>1&&(r+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',c>2&&(r+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=c;m<=p;m++)r+=`<button class="pag-page-btn ${m===N?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<a&&(p<a-1&&(r+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),r+=`<button class="pag-page-btn" onclick="window.changePage(${a})">${a}</button>`),r+=`<button class="pag-nav-btn" ${N===a?"disabled":""} onclick="window.changePage(${N+1})">Next ›</button>`,t.innerHTML=r}else t.innerHTML=""}window.changePage=e=>{var t;N=e,q(),(t=document.getElementById("shop-section"))==null||t.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,t)=>{const n=window.groupedProducts?window.groupedProducts.find(C=>C.docId===e):null,i=document.getElementById(`product-${e}`);if(!n||!i)return;const o=n.variants&&n.variants[t]?n.variants[t]:null,a=X(n,o),s=a.retailPrice,d=a.discountedPrice,r=a.isSpecial,l=Number(n.discount)||0,c=o&&o.stock!==void 0?o.stock:n.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:n.images&&n.images.length>0?p=n.images:p=[n.image];const m=p.map(C=>ce(C,n.name)),w=i.querySelector(".original-price"),u=i.querySelector(".final-price");w&&(w.innerText=`LKR ${s.toFixed(2)}`,w.style.display=l>0||r?"inline":"none"),u&&(u.innerText=`LKR ${d.toFixed(2)}`);const f=i.querySelector(".stock-display");f.innerText=`Stock: ${c}`,f.style.color=c<5?"#ef4444":"#10b981";const g=i.querySelector(".add-to-cart-btn");c<=0?(g.disabled=!0,g.innerText="Out of Stock",g.style.background="#cbd5e1",g.style.cursor="not-allowed"):(g.disabled=!1,g.innerText="Add to Cart",g.style.background="",g.style.cursor="pointer");const y=i.querySelector(".main-product-img");y.src=m[0];const h=i.querySelector(".image-dots");if(h.innerHTML=m.map((C,b)=>`<div class="dot ${b===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${b===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let C=0;i.imageInterval&&clearInterval(i.imageInterval),i.imageInterval=setInterval(()=>{C=(C+1)%m.length,y.style.opacity="0.5",setTimeout(()=>{y.src=m[C],y.style.opacity="1",h.querySelectorAll(".dot").forEach((S,v)=>{S.style.background=v===C?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else i.imageInterval&&clearInterval(i.imageInterval)};function xt(){const e=document.getElementById("nav-auth-item"),t=document.getElementById("user-profile");document.getElementById("user-display-name"),tt(Oe,n=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),n){const i={name:n.displayName||n.email.split("@")[0],email:n.email,id:n.uid};sessionStorage.setItem("mec_user",JSON.stringify(i));const o=()=>{var C,b,S,v,T;if(!e)return;const l=(((C=window.currentUserProfile)==null?void 0:C.customerType)||"retail").toLowerCase(),c=((b=window.currentUserProfile)==null?void 0:b.phone)||((S=window.currentUserProfile)==null?void 0:S.contact)||"",p=n.photoURL||((v=window.currentUserProfile)==null?void 0:v.photoURL)||((T=window.currentUserProfile)==null?void 0:T.avatar)||"",w=(B=>{if(!B)return"U";const z=B.trim().split(" ");return z.length>=2?(z[0][0]+z[1][0]).toUpperCase():B.slice(0,2).toUpperCase()})(i.name),u=l==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':l==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=l==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">
               <span>👑</span> Wholesale Customer (Wholesale Price Active)
             </div>`:l==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>💎</span> Loyalty Card Member Active
                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>🛍️</span> Standard Retail Customer
                 </div>`;e.innerHTML=`
          <div style="position: relative; display: inline-block;">
            <!-- Circular Avatar Only Trigger Button -->
            <button id="user-profile-trigger" style="
              background: transparent;
              border: none;
              padding: 2px;
              cursor: pointer;
              outline: none;
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
            " title="${i.name}">
              
              <!-- Circular Avatar Photo / Initials -->
              <div style="
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0284c7, #6366f1);
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 800;
                font-size: 0.88rem;
                color: white;
                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);
                border: 2px solid ${l==="wholesale"?"#eab308":l==="loyalty"?"#10b981":"#38bdf8"};
                overflow: hidden;
                flex-shrink: 0;
                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 
                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">
                ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:w}
              </div>

              <!-- Status Badge Dot -->
              ${l==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':l==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}
            </button>

            <!-- Modern Floating Profile Card Dropdown -->
            <div id="user-profile-dropdown" style="
              display: none;
              position: absolute;
              right: 0;
              top: calc(100% + 12px);
              width: 290px;
              background: #0f172a;
              border: 1px solid rgba(255, 255, 255, 0.15);
              border-radius: 16px;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);
              padding: 1.25rem;
              z-index: 10000;
              text-align: left;
            ">
              <!-- Profile Card Header -->
              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div style="
                  width: 46px;
                  height: 46px;
                  border-radius: 50%;
                  background: linear-gradient(135deg, #0284c7, #8b5cf6);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 1.1rem;
                  color: white;
                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
                  border: 2px solid rgba(255,255,255,0.6);
                  overflow: hidden;
                  flex-shrink: 0;
                ">
                  ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:w}
                </div>
                <div style="overflow: hidden; flex: 1;">
                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">
                      ${i.name}
                    </span>
                    ${u}
                  </div>
                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                    ${i.email||"Registered Customer"}
                  </div>
                </div>
              </div>

              <!-- Account Details & Benefits -->
              <div style="margin: 12px 0;">
                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">
                  Account Membership
                </div>
                ${f}
                
                ${c?`
                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">
                    <span style="color:#38bdf8;">📞</span> <span>${c}</span>
                  </div>
                `:""}
              </div>

              <!-- Quick Actions -->
              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">
                <a href="/track.html" style="
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  padding: 8px 12px;
                  background: rgba(255, 255, 255, 0.05);
                  border: 1px solid rgba(255, 255, 255, 0.08);
                  border-radius: 8px;
                  color: #f1f5f9;
                  text-decoration: none;
                  font-size: 0.82rem;
                  font-weight: 600;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">
                  <span style="display:flex; align-items:center; gap:8px;">
                    <span>📦</span> Track My Orders
                  </span>
                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>
                </a>
              </div>

              <!-- Divider & Logout Button -->
              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">
                <button id="nav-logout-btn" style="
                  width: 100%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 8px;
                  background: rgba(239, 68, 68, 0.12);
                  border: 1px solid rgba(239, 68, 68, 0.3);
                  color: #f87171;
                  padding: 8px 12px;
                  border-radius: 8px;
                  font-size: 0.85rem;
                  font-weight: 700;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"
                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">
                  <span>🚪</span> Log Out
                </button>
              </div>
            </div>
          </div>
        `;const g=document.getElementById("user-profile-trigger"),y=document.getElementById("user-profile-dropdown");g&&y&&(g.onclick=B=>{B.stopPropagation();const z=y.style.display==="block";y.style.display=z?"none":"block"});const h=document.getElementById("nav-logout-btn");h&&(h.onclick=async B=>{if(B.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await at(Oe),window.location.href="/"}catch(z){console.error("Logout Error:",z),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",l=>{const c=document.getElementById("user-profile-trigger"),p=document.getElementById("user-profile-dropdown");p&&c&&!c.contains(l.target)&&!p.contains(l.target)&&(p.style.display="none")}),o();const a=(n.email||"").trim(),s=a.toLowerCase(),d=$(L(P,"customers"),k("email","==",a)),r=$(L(P,"customers"),k("email","==",s));Promise.all([A(d),A(r)]).then(([l,c])=>{let p=null;if(l.empty?c.empty||(p=c.docs[0].data()):p=l.docs[0].data(),p){const m=(p.customerType||p.type||(p.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...p,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()}else{const m=window.currentStoreId||"mec-book-shop";A($(L(P,"customers"),k("storeId","==",m))).then(w=>{const u=(n.displayName||n.email.split("@")[0]||"").trim().toLowerCase(),f=w.docs.find(g=>{const y=g.data(),h=(y.email||"").trim().toLowerCase(),C=(y.phone||"").trim(),b=(y.name||"").trim().toLowerCase(),S=h&&h===s,v=n.phoneNumber&&C&&(C===n.phoneNumber||n.phoneNumber.includes(C)),T=b&&u&&(b===u||u.includes(b)||b.includes(u)||u.split(" ")[0]===b);return S||v||T});if(f){const g=f.data(),y=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:y,docId:f.id},!g.email&&n.email&&nt(le(P,"customers",f.id),{email:n.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()})}}).catch(l=>{console.error("Error fetching user profile:",l),window.currentUserProfile={customerType:"retail"},o(),q()})}else sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},q(),e&&(e.innerHTML='<a href="/login">Login</a>'),t&&(t.style.display="none")})}function kt(){const e=document.getElementById("reviews-container");if(!e)return;const t=L(P,"reviews"),n=$(t,rt("timestamp","desc"),ot(15));Ae(n,i=>{const o=i.docs.map(a=>a.data());if(o.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=o.map(a=>`
      <div class="review-card">
        <div class="review-stars">
          ${"★".repeat(a.rating)}${"☆".repeat(5-a.rating)}
        </div>
        <p class="review-comment">"${a.comment||"No comment provided."}"</p>
        <div class="review-footer">
          <span class="review-author">${a.userName}</span>
          <span class="review-date">${a.date}</span>
        </div>
      </div>
    `).join("")})}ft();xt();kt();const Be="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let $e=null;try{Be&&($e=new Xe(Be))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function Fe(e,t){if(!M||M.length===0)return t?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const i=(e||"").toLowerCase().split(/\s+/).filter(a=>a.length>2),o=M.map(a=>{let s=0;const d=(a.name||"").toLowerCase(),r=(a.category||"").toLowerCase(),l=(a.description||"").toLowerCase();return i.forEach(c=>{d.includes(c)&&(s+=3),r.includes(c)&&(s+=2),l.includes(c)&&(s+=1)}),{product:a,score:s}}).filter(a=>a.score>0).sort((a,s)=>s.score-a.score);if(o.length>0){const a=o.slice(0,3).map(s=>s.product);return t?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${a.map(d=>{const r=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=d.wholesalePrice?` | තොග මිල: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${r}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${a.map(d=>{const r=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"In Stock":"Out of Stock",l=d.wholesalePrice?` | Wholesale: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${r}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return t?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function St(e,t){var i,o,a,s,d,r;const n=/[\u0D80-\u0DFF]/.test(e)||t==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop, Horana",c=(M||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(g=>`${g.name||g.variantLabel||"Var"}-Stock:${g.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.
Available Inventory & Prices:
${c}

CRITICAL RULES:
1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).
2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.
3. Keep answers concise, clear, and direct (max 2-3 short sentences).
4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if($e)try{const y=(await(await $e.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(y)return y}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Be)}`,w=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(w.ok){const u=await w.json(),f=(r=(d=(s=(a=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:a.content)==null?void 0:s.parts)==null?void 0:d[0])==null?void 0:r.text;if(f&&f.trim())return f.trim()}return Fe(e,n)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),Fe(e,n)}}window.toggleGeminiChat=e=>{var o;const t=document.getElementById("gemini-chat-window"),n=document.getElementById("gemini-bubble");if(!t)return;(e!=null?!!e:!t.classList.contains("active"))?(t.classList.add("active"),n&&n.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):t.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),t=document.getElementById("gemini-chat-messages");if(!e||!t||!e.value.trim())return;const n=e.value.trim();e.value="";const i=document.createElement("div");i.className="user-msg",i.textContent=n,t.appendChild(i),t.scrollTop=t.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",t.appendChild(o),t.scrollTop=t.scrollHeight;const a=n.toLowerCase(),s=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let d=n,r=!1;if(s.forEach(m=>{a.includes(m)&&(r=!0)}),r&&(s.forEach(m=>{d=d.replace(new RegExp(m,"gi"),"")}),d=d.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),d.length>1)){window.searchQuery=d,j=d;const m=document.getElementById("store-search");m&&(m.value=d),N=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(n)||["mata","thiyenawada","tiyenawada","poth"].some(m=>a.includes(m)),c=await St(n,l?"si":"en");o.textContent=c,t.scrollTop=t.scrollHeight};window.talkToAgentWhatsApp=()=>{var a,s,d;const e=document.getElementById("gemini-chat-messages");let t="";e&&(t=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let n=((a=window.currentStoreData)==null?void 0:a.phone)||((s=window.systemConfig)==null?void 0:s.invPhone)||"94770658356";n=n.replace(/[^0-9]/g,""),n.startsWith("0")&&(n="94"+n.substring(1));const i=`Hi ${((d=window.currentStoreData)==null?void 0:d.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(i+t);window.open(`https://wa.me/${n}?text=${o}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const He=document.getElementById("gemini-orb-btn");He&&He.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=Ve.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const t=$(L(P,"affiliates"),k("code","==",e),k("storeId","==",window.currentStoreId)),n=await A(t);if(!n.empty){const i=le(P,"affiliates",n.docs[0].id);await ze(i,{clicks:Pe(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(t){console.error("Error incrementing referral click:",t)}}};function It(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="aff-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>
        
        <!-- Tab navigation inside modal -->
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>
        </div>

        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>
        </form>
      </div>

      <div id="aff-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>
        
        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">
          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>
          <div style="display:flex; gap:10px; align-items:center;">
            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">
            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>
          </div>
        </div>

        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}function Ct(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="seller-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>
        
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>
        </div>

        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>
        </form>
      </div>

      <div id="seller-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>
            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>
          </div>
          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">
            Pending
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">
          
          <!-- Add Product Form -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>
            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">
              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>
              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>
            </form>
          </div>

          <!-- Product List -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>
            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">
              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>
            </div>
          </div>
        </div>

        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{It();const t=document.getElementById("affiliate-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_affiliate_user");if(n){const i=JSON.parse(n);try{const o=$(L(P,"affiliates"),k("email","==",i.email),k("storeId","==",window.currentStoreId)),a=await A(o);if(a.empty)localStorage.removeItem("mec_affiliate_user"),Le();else{const s={...a.docs[0].data(),docId:a.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),ge(s)}}catch(o){console.error(o),ge(i)}}else Le()}};function Le(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const t=document.getElementById("aff-login-form"),n=document.getElementById("aff-register-form"),i=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const t=document.getElementById("aff-login-email").value.trim(),n=document.getElementById("aff-login-pass").value;try{const i=$(L(P,"affiliates"),k("email","==",t),k("password","==",n),k("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const a={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(a)),ge(a)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const t=document.getElementById("aff-reg-name").value.trim(),n=document.getElementById("aff-reg-email").value.trim(),i=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const a=$(L(P,"affiliates"),k("email","==",n),k("storeId","==",window.currentStoreId));if(!(await A(a)).empty){alert("An account with this email is already registered as a partner.");return}const d=t.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),r={name:t,email:n,phone:i,password:o,code:d,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:Z()},l=await Y(L(P,"affiliates"),r);r.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(r)),ge(r)}catch(a){console.error(a),alert("Registration failed. Please try again.")}};function ge(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const t=window.location.protocol,n=window.location.host,i=window.location.pathname;let o=`${t}//${n}${i}`;window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?o+=`?store=${window.currentStoreId}&ref=${e.code}`:o+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),Le()};window.toggleSellerPortal=async e=>{Ct();const t=document.getElementById("seller-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_seller_user");if(n){const i=JSON.parse(n);try{const o=$(L(P,"vendor_shops"),k("email","==",i.email),k("storeId","==",window.currentStoreId)),a=await A(o);if(a.empty)localStorage.removeItem("mec_seller_user"),Te();else{const s={...a.docs[0].data(),docId:a.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),fe(s)}}catch(o){console.error(o),fe(i)}}else Te()}};function Te(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const t=document.getElementById("seller-login-form"),n=document.getElementById("seller-register-form"),i=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const t=document.getElementById("seller-login-email").value.trim(),n=document.getElementById("seller-login-pass").value;try{const i=$(L(P,"vendor_shops"),k("email","==",t),k("password","==",n),k("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const a={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(a)),fe(a)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{e.preventDefault();const t=document.getElementById("seller-reg-shopname").value.trim(),n=document.getElementById("seller-reg-owner").value.trim(),i=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),a=document.getElementById("seller-reg-pass").value;try{const s=$(L(P,"vendor_shops"),k("shopName","==",t),k("storeId","==",window.currentStoreId));if(!(await A(s)).empty){alert("This shop name is already registered.");return}const r=$(L(P,"vendor_shops"),k("email","==",i),k("storeId","==",window.currentStoreId));if(!(await A(r)).empty){alert("This email is already registered to a shop.");return}const c={shopName:t,ownerName:n,email:i,phone:o,password:a,status:"pending",storeId:window.currentStoreId,timestamp:Z()},p=await Y(L(P,"vendor_shops"),c);c.docId=p.id,localStorage.setItem("mec_seller_user",JSON.stringify(c)),fe(c);try{const m="+94770658356",w=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${t}
Owner: ${n}
Phone: ${o}
Email: ${i}`,u=`https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(m)}&message=${encodeURIComponent(w)}`;fetch(u,{method:"GET",mode:"no-cors"}).catch(()=>{})}catch(m){console.error("Vendor SMS alert error:",m)}}catch(s){console.error(s),alert("Shop registration failed. Please try again.")}};async function fe(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const t=document.getElementById("seller-dash-status-badge");t&&(t.innerText=e.status||"pending",e.status==="active"?(t.style.background="rgba(16, 185, 129, 0.2)",t.style.color="#10b981"):(t.style.background="rgba(251, 191, 36, 0.2)",t.style.color="#fbbf24")),await Qe(e.email)}async function Qe(e){const t=document.getElementById("seller-products-list");if(t){t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const n=$(oe,k("vendorId","==",e),k("storeId","==",window.currentStoreId)),i=await A(n);if(i.empty)t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";i.forEach(a=>{const s=a.data(),d=s.status==="active"?"#10b981":"#fbbf24";o+=`
          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-weight:bold; font-size:0.85rem; display:block;">${s.name||""}</span>
              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${s.price||0}</span>
            </div>
            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${d};">${s.status||"pending"}</span>
          </div>
        `}),t.innerHTML=o}}catch(n){console.error(n),t.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const t=localStorage.getItem("mec_seller_user");if(!t)return;const n=JSON.parse(t),i=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),a=document.getElementById("seller-prod-category").value.trim(),s=document.getElementById("seller-prod-image").value.trim(),d=document.getElementById("seller-prod-desc").value.trim();try{const r={name:i,price:Number(o),category:a,image:s||"",description:d||"",status:"pending",vendorId:n.email,storeId:window.currentStoreId,timestamp:Z(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await Y(oe,r),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await Qe(n.email)}catch(r){console.error(r),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),Te()};window.addEventListener("beforeunload",function(e){var t;(t=window.chrome)!=null&&t.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
