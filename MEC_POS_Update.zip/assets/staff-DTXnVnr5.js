import{q as E,c as x,d as p,w as L,g as J,l as W,j as K,o as P,u as G,b as v,a as F,s as O,f as Y,e as k}from"./firebase-Bn3UcnFE.js";/* empty css              */window.staffLogin=async()=>{var i;const e=document.getElementById("staff-phone").value.trim(),t=document.getElementById("staff-pin").value.trim();if(!e||!t)return l("Please enter both Phone and PIN");const n=document.getElementById("section-login"),o=document.getElementById("login-loading"),a=document.getElementById("section-dashboard");n.style.display="none",o.style.display="block";try{const s=E(x(p,"employees"),L("phone","==",e)),c=await J(s);if(c.empty)throw new Error("Mobile number not registered.");const r=c.docs[0].data();if(r.docId=c.docs[0].id,t===r.regno||t===r.password){window.currentStaff=r;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(r)),localStorage.setItem("mec_staff_session",JSON.stringify(r))}catch{}H(r),o.style.display="none",a.style.display="block",(i=document.getElementById("section-login"))==null||i.remove()}else throw new Error("Invalid Security PIN.")}catch(s){l(s.message),o.style.display="none",n.style.display="block"}};window.staffLogout=()=>{try{sessionStorage.removeItem("mec_staff_session"),localStorage.removeItem("mec_staff_session")}catch{}window.location.reload()};function D(){try{const e=sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session");if(e){const t=JSON.parse(e);if(t&&(t.docId||t.phone)){window.currentStaff=t;const n=document.getElementById("section-login"),o=document.getElementById("login-loading"),a=document.getElementById("section-dashboard");n&&a&&(n.style.display="none",o&&(o.style.display="none"),a.style.display="block",H(t))}}}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",D):D();function H(e){document.getElementById("disp-name").innerText=e.name,document.getElementById("disp-role").innerText=e.role,document.getElementById("disp-avatar").innerText=e.name.charAt(0).toUpperCase();const t=E(x(p,"payroll"),L("empId","==",e.docId),K("timestamp","desc"),W(1));P(t,c=>{if(!c.empty){const r=c.docs[0].data();document.getElementById("disp-salary").innerText=`LKR ${parseFloat(r.amount).toLocaleString()}`,window.lastPaySlip=r}});const n=new Date,o=`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}`,a=E(x(p,"attendance"),L("empId","==",e.docId));P(a,c=>{const r=c.docs.map(f=>f.data()),g=r.filter(f=>f.date.startsWith(o)&&f.status==="Present");document.getElementById("disp-attendance").innerText=`${g.length} Days`,window.myAttendanceRecords=r});const i=q(e),s=document.getElementById("admin-calibrate-gps-btn");s&&(s.style.display=i?"flex":"none"),Z(e)}function q(e){if(!e)return!1;const t=(e.role||"").toLowerCase();return(e.regno||"").toUpperCase()==="EMP-001"||t.includes("admin")||t.includes("ceo")||t.includes("owner")||t.includes("manager")||t.includes("director")||t.includes("super")}let _=!0;const M=new Set;function X(){try{const e=new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");e.volume=.8;const t=e.play();t!==void 0&&t.catch(()=>{try{const n=new(window.AudioContext||window.webkitAudioContext);n.state==="suspended"&&n.resume();const o=n.createOscillator(),a=n.createGain();o.type="sine",o.frequency.setValueAtTime(587.33,n.currentTime),o.frequency.setValueAtTime(880,n.currentTime+.1),a.gain.setValueAtTime(.25,n.currentTime),a.gain.exponentialRampToValueAtTime(.001,n.currentTime+.45),o.connect(a),a.connect(n.destination),o.start(),o.stop(n.currentTime+.5)}catch{}})}catch{}}function Z(e){const t=e.storeId||"mec-book-shop",n=e.docId||e.regno||e.email,o=e.role||"Staff",a=e.branchId||"Global",i=E(x(p,"internal_mails"),L("storeId","==",t));P(i,s=>{let c=s.docs.map(m=>({docId:m.id,...m.data()}));c.sort((m,d)=>{var u,h;const y=(u=m.timestamp)!=null&&u.seconds?m.timestamp.seconds*1e3:new Date(m.timestamp||0).getTime()||0;return((h=d.timestamp)!=null&&h.seconds?d.timestamp.seconds*1e3:new Date(d.timestamp||0).getTime()||0)-y});const r=c.filter(m=>{const d=m.recipientId||"ALL";return!!(d==="ALL"||d===n||d===e.regno||d===e.email||d===e.phone||d.startsWith("BRANCH_")&&(d.replace("BRANCH_","")===a||d.replace("BRANCH_","")===e.branchName)||d.startsWith("ROLE_")&&d.replace("ROLE_","").toLowerCase()===o.toLowerCase()||d==="CASHIERS"&&o.toLowerCase().includes("cashier")||d==="INVENTORY"&&(o.toLowerCase().includes("inventory")||o.toLowerCase().includes("stock"))||d==="TECH"&&(o.toLowerCase().includes("tech")||o.toLowerCase().includes("repair"))||d==="HR_ONLY"&&(o.toLowerCase().includes("hr")||o.toLowerCase().includes("admin")||o.toLowerCase().includes("manager")))});if(_)r.forEach(m=>M.add(m.docId)),_=!1;else{const m=r.filter(d=>!M.has(d.docId));m.length>0&&m.forEach(d=>{M.add(d.docId),X(),l(`📩 New Notice from ${d.senderName||"HR"}: ${d.subject||"Staff Message"}`)})}window.myStaffMails=r;const g=r.filter(m=>!m.isRead).length,f=document.getElementById("staff-unread-badge");f&&(g>0?(f.innerText=g,f.style.display="inline-block"):f.style.display="none"),j(r)},s=>{console.warn("Staff mail snapshot error:",s)})}function j(e){const t=document.getElementById("staff-inbox-list");if(t){if(!e||e.length===0){t.innerHTML='<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>';return}t.innerHTML=e.map(n=>{const o=n.timestamp?new Date(n.timestamp.seconds*1e3).toLocaleString([],{dateStyle:"short",timeStyle:"short"}):"Just now",a=n.priority==="urgent",i=!!(n.attachment&&n.attachment.url),s=n.isRead?"":'<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>',c=a?'<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>':"";return`
            <div onclick="window.readStaffMailDetail('${n.docId}')" style="background: ${n.isRead?"rgba(255,255,255,0.03)":"rgba(56,189,248,0.08)"}; border: 1px solid ${n.isRead?"rgba(255,255,255,0.06)":"rgba(56,189,248,0.3)"}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${s}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${n.senderName||"HR Management"}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${o}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${n.subject||"No Subject"}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${i?'<span title="Has Attachment" style="font-size:0.8rem;">📎</span>':""}
                        ${c}
                    </div>
                </div>
            </div>
        `}).join("")}}window.openStaffInboxModal=()=>{document.getElementById("staff-inbox-modal").style.display="flex",window.myStaffMails&&j(window.myStaffMails)};window.readStaffMailDetail=async e=>{const t=(window.myStaffMails||[]).find(a=>a.docId===e);if(!t)return;if(!t.isRead)try{await G(v(p,"internal_mails",e),{isRead:!0}),t.isRead=!0}catch{}document.getElementById("staff-mail-view-subject").innerText=t.subject||"No Subject",document.getElementById("staff-mail-view-sender").innerText=`${t.senderName||"HR Management"} (${t.senderEmail||"System"})`,document.getElementById("staff-mail-view-date").innerText=t.timestamp?new Date(t.timestamp.seconds*1e3).toLocaleString():"Just now",document.getElementById("staff-mail-view-body").innerText=t.body||"";const n=document.getElementById("staff-mail-view-badge");n&&(t.priority==="urgent"?(n.innerText="🚨 Urgent Notice",n.style.background="rgba(239,68,68,0.2)",n.style.color="#ef4444"):t.priority==="confidential"?(n.innerText="🔒 Confidential",n.style.background="rgba(168,85,247,0.2)",n.style.color="#c084fc"):(n.innerText="✉️ Staff Notice",n.style.background="rgba(56,189,248,0.15)",n.style.color="#38bdf8"));const o=document.getElementById("staff-mail-view-attachment");if(o)if(t.attachment&&t.attachment.url){const a=t.attachment.type&&t.attachment.type.startsWith("image/");let i=`
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${t.attachment.name||"File"}</span>
                        <a href="${t.attachment.url}" download="${t.attachment.name||"download"}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;a&&(i+=`<img src="${t.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`),i+="</div>",o.innerHTML=i,o.style.display="block"}else o.innerHTML="",o.style.display="none";document.getElementById("staff-read-mail-modal").style.display="flex"};function l(e){const t=document.getElementById("toast");t.innerText=e,t.style.display="block",setTimeout(()=>t.style.display="none",3e3)}const ee=(e,t)=>{const n=new Blob([e],{type:"text/plain"}),o=window.URL.createObjectURL(n),a=document.createElement("a");a.href=o,a.download=t,a.click(),window.URL.revokeObjectURL(o)};window.downloadMySlip=()=>{var n;if(!window.lastPaySlip)return l("No salary records found.");const e=window.lastPaySlip,t=`
------------------------------------------
        MEC BOOK SHOP - PAY SLIP       
------------------------------------------
Employee: ${window.currentStaff.name}
Role:     ${window.currentStaff.role}
ID:       ${window.currentStaff.regno||"-"}
------------------------------------------
Month:    ${e.month}
Amount:   LKR ${parseFloat(e.amount).toLocaleString()}
Note:     ${e.note||"Regular Salary"}
Date:     ${e.date||new Date(((n=e.timestamp)==null?void 0:n.seconds)*1e3).toLocaleDateString()}
------------------------------------------
Generated by MEC Staff Portal
    `;ee(t,`payslip_${e.month}.txt`),l("📥 Payslip downloaded!")};window.viewMyAttendance=()=>{if(!window.myAttendanceRecords||window.myAttendanceRecords.length===0)return l("No attendance records found.");const e=window.currentStaff,t=[...window.myAttendanceRecords].sort((a,i)=>i.date.localeCompare(a.date)),n=`
        <html>
        <head>
            <title>Attendance Report - ${e.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${e.name}<br>
                    <strong>Role:</strong> ${e.role}<br>
                    <strong>Employee ID:</strong> ${e.regno||"-"}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${t.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Time</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${t.map(a=>`
                        <tr>
                            <td>${a.date}</td>
                            <td class="status-${(a.status||"").toLowerCase().replace(" ","")}">${a.status}</td>
                            <td>${a.time||"--:--"}</td>
                            <td>${a.note||"-"}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            <\/script>
        </body>
        </html>
    `,o=window.open("","_blank");o.document.write(n),o.document.close(),l("📅 Generating PDF Report...")};window.openLeaveModal=()=>{document.getElementById("leave-modal").style.display="flex",document.getElementById("leave-date").value=new Date().toISOString().split("T")[0]};window.submitLeaveRequest=async()=>{var d,y;const e=document.getElementById("leave-date"),t=document.getElementById("leave-type"),n=document.getElementById("leave-reason"),o=e?e.value:"",a=t?t.value:"Half Day",i=n?n.value.trim():"";if(!o||!i)return l("⚠️ Please fill all fields (Date & Reason).");let s=window.currentStaff;if(!s)try{s=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{s={}}const c=s.docId||s.regno||s.id||"EMP-UNKNOWN",r=s.name||((d=document.getElementById("disp-name"))==null?void 0:d.innerText)||"Staff Member",g=s.role||((y=document.getElementById("disp-role"))==null?void 0:y.innerText)||"Staff",f=s.storeId||"mec-book-shop",m=document.querySelector("#leave-modal button.btn-login:last-child");m&&(m.disabled=!0,m.innerText="Submitting...");try{await F(x(p,"leave_requests"),{empId:c,empName:r,empRole:g,empPhone:s.phone||"",date:o,type:a,reason:i,status:"Pending",storeId:f,timestamp:O()}),l("✅ Leave request submitted successfully!");const w=document.getElementById("leave-modal");w&&(w.style.display="none"),n&&(n.value="")}catch(w){console.error("Leave request error:",w),l(`❌ Error: ${w.message||"Failed to submit request"}`)}finally{m&&(m.disabled=!1,m.innerText="Submit Request")}};let S=null,B="environment",b=null,I=null,U=null;async function z(e,t,n){var s;const o=parseFloat(t),a=parseFloat(n),i=e||((s=window.currentStaff)==null?void 0:s.storeId)||"mec-book-shop";try{await k(v(p,"config",i),{storeLatitude:o,storeLongitude:a},{merge:!0})}catch(c){console.warn("Set config storeId error, attempting fallback:",c);try{await G(v(p,"config",i),{storeLatitude:o,storeLongitude:a})}catch(r){console.error("Config update error:",r)}}try{await k(v(p,"system","config"),{storeLatitude:o,storeLongitude:a},{merge:!0})}catch{}try{const c=localStorage.getItem(`mecpos_system_config_${i}`);if(c){const r=JSON.parse(c);r.storeLatitude=o,r.storeLongitude=a,localStorage.setItem(`mecpos_system_config_${i}`,JSON.stringify(r))}}catch{}}async function Q(e="Present",t=""){var i,s,c,r;const n=new Date,o=n.toLocaleDateString("sv-SE"),a=n.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit"});await F(x(p,"attendance"),{empId:((i=window.currentStaff)==null?void 0:i.docId)||((s=window.currentStaff)==null?void 0:s.regno)||"EMP-UNKNOWN",empName:((c=window.currentStaff)==null?void 0:c.name)||"Staff Member",date:o,time:a,status:e,note:t||"GPS+QR Verified",storeId:((r=window.currentStaff)==null?void 0:r.storeId)||"mec-book-shop",timestamp:O()})}window.calibrateStoreGPSFromPhone=()=>{if(!navigator.geolocation)return l("GPS Geolocation not supported on this device.");l("📍 Acquiring high-accuracy GPS coordinates..."),navigator.geolocation.getCurrentPosition(async e=>{var i;const t=e.coords.latitude,n=e.coords.longitude,o=e.coords.accuracy?` (±${Math.round(e.coords.accuracy)}m)`:"",a=`Set current phone location as official Shop GPS?

📍 Latitude: ${t.toFixed(6)}
📍 Longitude: ${n.toFixed(6)}${o}

All employee clock-in scans will be verified against this exact store location.`;if(confirm(a))try{const s=((i=window.currentStaff)==null?void 0:i.storeId)||"mec-book-shop";await z(s,t,n),l("✅ Store GPS coordinates successfully updated!")}catch(s){l("❌ Failed to update GPS coordinates: "+s.message)}},e=>{console.error("GPS Error:",e),l("❌ Unable to acquire GPS location. Please ensure Location is enabled.")},{enableHighAccuracy:!0,timeout:1e4})};window.confirmCalibrateStoreGPS=async()=>{var t;const e=document.getElementById("btn-calibrate-gps");e&&(e.disabled=!0,e.innerText="⏳ Saving Store GPS...");try{if(!b||!I)throw new Error("Phone GPS coordinates not found. Please re-scan.");const n=U||((t=window.currentStaff)==null?void 0:t.storeId)||"mec-book-shop";await z(n,b,I),document.getElementById("gps-mismatch-modal").style.display="none",l("📍 Shop GPS calibrated! Recording attendance..."),await Q("Present",`GPS Calibrated to Store (${b.toFixed(5)}, ${I.toFixed(5)})`),l("✅ Shop GPS Calibrated & Clocked In Successfully!")}catch(n){console.error("Calibration error:",n),l(`❌ Error: ${n.message||"Failed to calibrate"}`)}finally{e&&(e.disabled=!1,e.innerText="📍 Set Shop GPS to My Phone & Clock-In")}};window.startAttendanceClock=()=>{if(!navigator.geolocation)return l("GPS Geolocation not supported on this device.");l("📍 Accessing GPS coordinates..."),navigator.geolocation.getCurrentPosition(e=>{b=e.coords.latitude,I=e.coords.longitude,document.getElementById("scanner-modal").style.display="flex",S||(S=new Html5Qrcode("scanner-reader")),V()},e=>{console.error("GPS Error:",e),l("❌ Unable to verify location. Enable GPS/Location Services.")},{enableHighAccuracy:!0,timeout:8e3})};const V=()=>{const e={fps:20,qrbox:(t,n)=>({width:Math.floor(t*.7),height:Math.floor(n*.7)})};S.start({facingMode:B},e,te).catch(t=>{console.error("Camera access error:",t),l("Cannot open camera. Check permissions.")})};window.toggleCamera=()=>{B=B==="environment"?"user":"environment",S&&S.isScanning&&S.stop().then(()=>V())};window.closeScanner=()=>{S&&S.isScanning?S.stop().then(()=>{document.getElementById("scanner-modal").style.display="none"}):document.getElementById("scanner-modal").style.display="none"};const te=async e=>{var w;const t=e.trim();if(!t.startsWith("MEC-POS-ATTENDANCE-QR:")){l("⚠️ Invalid QR Code. Scan the Shop QR Code.");return}window.closeScanner(),l("🔄 Verifying physical presence...");const n=t.split(":"),o=n[1]||((w=window.currentStaff)==null?void 0:w.storeId)||"mec-book-shop";let a=parseFloat(n[2]),i=parseFloat(n[3]);try{const u=await Y(v(p,"config",o));if(u.exists()){const h=u.data();h.storeLatitude&&h.storeLongitude&&(a=parseFloat(h.storeLatitude),i=parseFloat(h.storeLongitude))}}catch(u){console.warn("Could not fetch remote store config:",u)}const s=6371e3,c=b*Math.PI/180,r=a*Math.PI/180,g=(a-b)*Math.PI/180,f=(i-I)*Math.PI/180,m=Math.sin(g/2)*Math.sin(g/2)+Math.cos(c)*Math.cos(r)*Math.sin(f/2)*Math.sin(f/2),d=2*Math.atan2(Math.sqrt(m),Math.sqrt(1-m)),y=s*d;if(y>150){U=o;const u=y>=1e3?`${(y/1e3).toFixed(1)} km`:`${y.toFixed(1)} m`,h=document.getElementById("mismatch-distance");h&&(h.innerText=u);const $=document.getElementById("mismatch-my-coords");$&&($.innerText=`${b.toFixed(5)}, ${I.toFixed(5)}`);const T=document.getElementById("mismatch-qr-coords");T&&(T.innerText=`${a.toFixed(5)}, ${i.toFixed(5)}`);const C=q(window.currentStaff),R=document.getElementById("gps-mismatch-admin-actions"),N=document.getElementById("gps-mismatch-staff-actions");R&&(R.style.display=C?"flex":"none"),N&&(N.style.display=C?"none":"flex");const A=document.getElementById("gps-mismatch-modal");A&&(A.style.display="flex");return}try{await Q("Present",`GPS+QR Verified (Distance: ${y.toFixed(1)}m)`),l("✅ Attendance Marked successfully!")}catch(u){console.error(u),l("Error logging attendance to database.")}};
