import{p as V,r as te,t as ae,v as ne,e as se,x as oe,s as ie}from"./firebase-CVcZ1MF3.js";function le(e){if(e<=1e5)return 0;let s=e-1e5,o=0;const p=[{limit:41667,rate:.06},{limit:41667,rate:.12},{limit:41667,rate:.18},{limit:41667,rate:.24},{limit:41667,rate:.3},{limit:1/0,rate:.36}];for(const i of p){if(s<=0)break;const n=Math.min(s,i.limit);o+=n*i.rate,s-=n}return Math.round(o*100)/100}function me({emp:e,monthStr:s,allOrders:o=[],allLeaveRequests:p=[],allAttendance:i=(typeof window<"u"?window.allAttendance:[])||[],advanceDeductions:n=0}){var U,Y;const[d,t]=s.split("-"),l=parseInt(d),b=parseInt(t),g=parseFloat(e.basicSalary||e.salary||0),f=parseFloat(e.braAllowance||e.budgetaryAllowance||0),c=parseFloat(e.colaAllowance||e.livingAllowance||0),h=parseFloat(e.fixedAllowance||0),u=g+f+c+h;let E=0;for(let a=0;a<o.length;a++){const y=o[a];if(!y.isPOS||!(y.staffId===e.docId||y.staffId===e.regno||y.staffId===e.id))continue;const F=(U=y.timestamp)!=null&&U.seconds?new Date(y.timestamp.seconds*1e3):new Date(y.date);F.getFullYear()===l&&F.getMonth()+1===b&&(E+=y.total||0)}const x=parseFloat(e.commission||e.salesCommission||0),v=E*(x/100),I=parseFloat(e.attendanceAllowance||e.allowance||0);let N=0,C=!1,M="Not configured";const r=typeof window<"u"&&((Y=window.systemConfig)!=null&&Y.hrPolicies)?window.systemConfig.hrPolicies:{};if(I>0){const a=p.filter(m=>m.empId===e.docId||m.empId===e.regno||m.empId===e.id?String(m.date||"").trim().startsWith(s):!1),y=r.protectMedicalLeave!==!1,A=a.some(m=>(m.status||"").toLowerCase()==="rejected"),F=a.some(m=>(m.status||"").toLowerCase()==="approved"?!(m.allowanceProtected===!0||y&&m.medicalBill&&(m.type||"").toLowerCase().includes("medical")):!1),G=a.some(m=>(m.status||"").toLowerCase()==="approved"&&(m.allowanceProtected===!0||y&&!!m.medicalBill));A||F?(N=0,C=!1,M=A?"Forfeited due to rejected leave":"Forfeited due to uncertified casual absence"):(N=I,C=G,M=G?"Protected under Shop & Office Act (Medical Certificate Verified)":"Granted in full (100% Attendance)")}let $=26;r.salaryDayBasis==="30"?$=30:r.salaryDayBasis==="actual"&&($=new Date(l,b,0).getDate()||30);const S=!isNaN(parseFloat(r.fullDayHours))&&parseFloat(r.fullDayHours)>0?parseFloat(r.fullDayHours):8,T=(u>0&&$>0&&S>0?u/($*S):0)*1.5,K=isNaN(parseFloat(r.latePenaltyRate))?0:parseFloat(r.latePenaltyRate);let w=0,_=0;(i||[]).filter(a=>a.empId===e.docId||a.empId===e.regno||a.empId===e.id||a.staffId===e.docId||a.staffId===e.regno?String(a.date||a.punchInDate||"").trim().startsWith(s):!1).forEach(a=>{a.otHours&&!isNaN(parseFloat(a.otHours))?w+=parseFloat(a.otHours):a.workedMinutes&&a.workedMinutes>Math.round(S*60)&&(w+=(a.workedMinutes-Math.round(S*60))/60),a.lateMinutes&&!isNaN(parseInt(a.lateMinutes,10))&&(_+=parseInt(a.lateMinutes,10))}),w=Math.round(w*100)/100;const O=Math.round(w*T*100)/100,j=Math.round(_*K*100)/100,P=u+v+N+O,D=e.epfEnabled!==!1&&e.status!=="Contractor",J=r.epfEmployeeRate!==void 0&&!isNaN(r.epfEmployeeRate)?parseFloat(r.epfEmployeeRate):8,q=r.epfEmployerRate!==void 0&&!isNaN(r.epfEmployerRate)?parseFloat(r.epfEmployerRate):12,W=r.etfEmployerRate!==void 0&&!isNaN(r.etfEmployerRate)?parseFloat(r.etfEmployerRate):3,k=D?Math.round(u*(J/100)*100)/100:0,B=D?Math.round(u*(q/100)*100)/100:0,R=D?Math.round(u*(W/100)*100)/100:0,L=k+B,Z=L+R,z=le(P),H=k+z+n+j,Q=Math.max(0,P-H),X=P+B+R;return{empId:e.docId||e.regno,empRegNo:e.regno||e.empId||"EMP-000",empName:e.name||e.fullName||"Employee",empRole:e.role||e.designation||"Staff",empPhone:e.phone||"",bankName:e.bankName||"Commercial Bank",bankBranch:e.bankBranch||"Colombo",bankAccount:e.bankAccount||e.accountNo||"",epfNumber:e.epfNumber||e.epfNo||e.regno||"",nic:e.nic||e.nationalId||"",month:s,basicSalary:g,braAllowance:f,colaAllowance:c,fixedAllowance:h,epfBase:u,totalSales:E,commissionPct:x,commissionEarned:v,monthlyAttendanceAllowance:I,payableAttendanceAllowance:N,allowanceProtected:C,allowanceRemarks:M,otHours:w,otRatePerHour:T,otPay:O,grossEarnings:P,employeeEpf8:k,apitTax:z,advanceDeductions:n,lateMinutes:_,lateDeductions:j,totalEmployeeDeductions:H,netSalary:Q,employerEpf12:B,employerEtf3:R,totalEpfRemittance:L,totalStatutoryContribution:Z,totalCompanyCost:X}}function ue(e,s="EPF/MEC/99812",o=""){const p=[];p.push(`H|${s}|${o.replace("-","")}|${e.length}`),e.forEach((t,l)=>{const b=(t.epfNumber||(l+1).toString()).padEnd(6," "),g=(t.nic||"000000000V").padEnd(12," "),f=(t.empName||"Staff").substring(0,30).padEnd(30," "),c=t.epfBase.toFixed(2).padStart(12," "),h=t.employeeEpf8.toFixed(2).padStart(10," "),u=t.employerEpf12.toFixed(2).padStart(10," ");p.push(`D|${b}|${g}|${f}|${c}|${h}|${u}`)});const i=e.reduce((t,l)=>t+l.epfBase,0).toFixed(2),n=e.reduce((t,l)=>t+l.employeeEpf8,0).toFixed(2),d=e.reduce((t,l)=>t+l.employerEpf12,0).toFixed(2);return p.push(`T|${e.length}|${i}|${n}|${d}`),p.join(`\r
`)}function be(e,s="ETF/MEC/7721",o=""){const p=["Employer ETF No","Month","Member No","NIC","Employee Name","Statutory Earnings (LKR)","ETF Contribution 3% (LKR)"],i=e.map(t=>[`"${s}"`,`"${o}"`,`"${t.epfNumber}"`,`"${t.nic}"`,`"${t.empName}"`,t.epfBase.toFixed(2),t.employerEtf3.toFixed(2)]),n=e.reduce((t,l)=>t+l.epfBase,0).toFixed(2),d=e.reduce((t,l)=>t+l.employerEtf3,0).toFixed(2);return i.push(['"TOTAL"',`"${o}"`,'""','""',`"${e.length} Employees"`,n,d]),[p.join(","),...i.map(t=>t.join(","))].join(`\r
`)}function ye(e,s="10002938471",o=""){const p=["Beneficiary Name","Beneficiary Bank","Branch Code","Account Number","Net Amount (LKR)","Payment Reference","Originating Account"],i=e.map(n=>[`"${n.empName.replace(/"/g,'""')}"`,`"${n.bankName||"Commercial Bank"}"`,`"${n.bankBranch||"001"}"`,`"${n.bankAccount||"0000000000"}"`,n.netSalary.toFixed(2),`"SALARY ${n.month}"`,`"${s}"`]);return[p.join(","),...i.map(n=>n.join(","))].join(`\r
`)}function pe(e,s={}){const o=s.name||s.storeName||"MEC BOOK SHOP",p=e.month||new Date().toISOString().slice(0,7),[i,n]=p.split("-"),d=["January","February","March","April","May","June","July","August","September","October","November","December"],t=["ජනවාරි","පෙබරවාරි","මාර්තු","අප්‍රේල්","මැයි","ජූනි","ජූලි","අගෝස්තු","සැප්තැම්බර්","ඔක්තෝබර්","නොවැම්බර්","දෙසැම්බර්"],l=parseInt(n,10)-1,b=d[l]||n,g=t[l]||n,f=x=>{const v=parseFloat(x);return isNaN(v)||v===0?"-":v.toFixed(2)},c=x=>(parseFloat(x)||0).toFixed(2),h=e.braAllowance||0,u=e.colaAllowance||0,E=(e.fixedAllowance||0)+(e.commissionEarned||0)+(e.payableAttendanceAllowance||0);return`
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Pay Slip - ${e.empName} - ${p}</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 20px;
            background: #f8fafc;
            color: #000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 13px;
            display: flex;
            justify-content: center;
        }
        .payslip-wrapper {
            width: 100%;
            max-width: 540px;
            background: #fff;
            border: 1.5px solid #000;
            padding: 0;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        }
        .header-banner {
            background: #e2e8f0;
            border-bottom: 1.5px solid #000;
            padding: 8px 12px;
            text-align: center;
        }
        .header-title {
            font-size: 13px;
            font-weight: 700;
            color: #0f172a;
        }
        .header-subtitle {
            font-size: 14px;
            font-weight: 800;
            margin-top: 2px;
            color: #000;
        }
        .meta-section {
            padding: 8px 12px;
            border-bottom: 1.5px solid #000;
            font-size: 12px;
            line-height: 1.5;
        }
        .meta-row {
            display: flex;
            justify-content: space-between;
        }
        .currency-header {
            text-align: right;
            font-weight: 700;
            font-size: 12px;
            padding: 4px 12px 2px 12px;
        }
        .section-header {
            font-weight: 800;
            font-size: 12px;
            padding: 4px 12px 2px 12px;
        }
        .line-item {
            display: flex;
            justify-content: space-between;
            padding: 2px 12px;
            font-size: 12px;
        }
        .line-item .label {
            color: #111;
        }
        .line-item .val {
            font-variant-numeric: tabular-nums;
            min-width: 75px;
            text-align: right;
            font-weight: 600;
        }
        .subtotal-line {
            display: flex;
            justify-content: space-between;
            padding: 4px 12px;
            font-weight: 800;
            font-size: 12.5px;
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
            margin: 4px 0 6px 0;
        }
        .net-pay-line {
            display: flex;
            justify-content: space-between;
            padding: 6px 12px;
            font-weight: 900;
            font-size: 13.5px;
            border-top: 1.5px solid #000;
            border-bottom: 1.5px solid #000;
            margin: 6px 0 8px 0;
        }
        .receipt-section {
            border-top: 1px dashed #64748b;
            padding: 10px 12px 14px 12px;
            font-size: 11.5px;
            line-height: 1.45;
        }
        .receipt-header {
            font-weight: 800;
            margin-bottom: 4px;
        }
        .bank-details {
            text-align: right;
            margin-top: 8px;
            font-size: 11.5px;
        }
        .sig-container {
            margin-top: 14px;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .print-btn-bar {
            position: fixed;
            top: 15px;
            right: 15px;
            z-index: 9999;
            display: flex;
            gap: 8px;
        }
        .btn-p {
            background: #0284c7;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        @media print {
            body {
                background: #fff;
                padding: 0;
            }
            .payslip-wrapper {
                box-shadow: none;
                border: 1.5px solid #000;
                max-width: 100%;
                page-break-inside: avoid;
            }
            .print-btn-bar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="print-btn-bar">
        <button class="btn-p" onclick="window.print()">🖨️ Print Pay Slip</button>
    </div>

    <div class="payslip-wrapper">
        <!-- Top Grey Header Banner -->
        <div class="header-banner">
            <div class="header-title">${o}</div>
            <div class="header-subtitle">වැටුප් පත්‍රිකාව / Pay Slip</div>
        </div>

        <!-- Meta Section -->
        <div class="meta-section">
            <div class="meta-row">
                <span><b>මාසය / Month:</b> ${g} (${b})</span>
                <span><b>වර්ෂය / Year:</b> ${i}</span>
            </div>
            <div><b>සේවකයාගේ නම / Name:</b> ${e.empName}</div>
            <div><b>කාර්ය මණ්ඩල අංකය / Staff Number:</b> ${e.empRegNo||e.empId}</div>
            <div><b>සේ.අ.අ. අංකය / EPF Number:</b> ${e.epfNumber||e.empRegNo}</div>
        </div>

        <div class="currency-header">රු. ශත</div>

        <!-- Section 1: Consolidated Salary -->
        <div class="section-header">ඒකාබද්ධ වැටුප / CONSOLIDATED SALARY</div>
        <div class="line-item">
            <span class="label">මූලික වැටුප / Basic Pay</span>
            <span class="val">${f(e.basicSalary)}</span>
        </div>
        <div class="line-item">
            <span class="label">අයවැය සහන දීමනාව 1 / Budgetary Allowance 1</span>
            <span class="val">${f(h)}</span>
        </div>
        <div class="line-item">
            <span class="label">අයවැය සහන දීමනාව 2 / Budgetary Allowance 2</span>
            <span class="val">${f(u)}</span>
        </div>
        <div class="line-item">
            <span class="label">අතිකාල දීමනා / OT Pay</span>
            <span class="val">${f(e.otPay)}</span>
        </div>
        <div class="line-item">
            <span class="label">එකතු කිරීම්: හිඟ වැටුප් / Add: Arrears</span>
            <span class="val">-</span>
        </div>
        <div class="line-item">
            <span class="label">අඩු කිරීම්: වැටුප් රහිත / Less: No Pay</span>
            <span class="val">-</span>
        </div>
        <div class="line-item">
            <span class="label">එකතු කිරීම්: ගමන්/වෙනත් දීමනා / Add: Allowance/Travelling</span>
            <span class="val">${f(E)}</span>
        </div>
        <div class="subtotal-line">
            <span>මුළු ඉපැයීම / Gross Pay</span>
            <span>${c(e.grossEarnings)}</span>
        </div>

        <!-- Section 2: Deductions -->
        <div class="section-header">අඩු කිරීම් / DEDUCTIONS</div>
        <div class="line-item">
            <span class="label">සේ.අ.අ. 8% / E.P.F. 8%</span>
            <span class="val">${f(e.employeeEpf8)}</span>
        </div>
        <div class="line-item">
            <span class="label">වැටුප් අත්තිකාරම් සහ වෙනත් / S. Adv. & Others</span>
            <span class="val">${f(e.advanceDeductions)}</span>
        </div>
        <div class="line-item">
            <span class="label">නිල ඇඳුම් පිරිවැය / Uniform Cost</span>
            <span class="val">-</span>
        </div>
        <div class="line-item">
            <span class="label">මුද්‍රා ගාස්තු / Stamp Duty</span>
            <span class="val">-</span>
        </div>
        <div class="line-item">
            <span class="label">අත්තිකාරම් පුද්ගල ආදායම් බද්ද / P.A.Y.E. (APIT)</span>
            <span class="val">${f(e.apitTax)}</span>
        </div>
        <div class="subtotal-line">
            <span>මුළු අඩු කිරීම් / Total Deductions</span>
            <span>${c(e.totalEmployeeDeductions)}</span>
        </div>

        <!-- Section 3: Net Pay -->
        <div class="net-pay-line">
            <span>ශුද්ධ වැටුප / NET PAY</span>
            <span>${c(e.netSalary)}</span>
        </div>

        <!-- Section 4: Employer Statutory Contributions -->
        <div class="line-item">
            <span class="label">සේ.අ.අ. සමාගමේ දායකත්වය 12% / EPF-Co. Contribution 12%</span>
            <span class="val">${c(e.employerEpf12)}</span>
        </div>
        <div class="line-item">
            <span class="label">මුළු සේ.අ.අ. 20% / Total EPF 20%</span>
            <span class="val">${c(e.totalEpfRemittance)}</span>
        </div>
        <div class="line-item">
            <span class="label">සේ.සේ.කා. 3% / ETF 3%</span>
            <span class="val">${c(e.employerEtf3)}</span>
        </div>

        <!-- Section 5: Receipt Section -->
        <div class="receipt-section">
            <div class="receipt-header">ලැබීම් පත්‍රය / RECEIPT</div>
            <div>ඉහත සඳහන් කරන ලද <b>${g} ${i}</b> මාසය සඳහා මට ලැබිය යුතු ශුද්ධ වැටුප <b>${o}</b> වෙතින් ස්තූති පූර්වකව ලැබුණි.</div>
            <div style="font-size: 11px; color: #334155; margin-top: 2px;">
                Received with thanks from <b>${o}</b> the under mentioned amount being the NET PAY due to me of <b>${b} ${i}</b>.
            </div>

            <div class="bank-details">
                <div><b>${e.bankName||"Commercial Bank"}</b></div>
                ${e.bankBranch?`<div>Branch: ${e.bankBranch}</div>`:""}
                ${e.bankAccount?`<div>Account No: ${e.bankAccount}</div>`:""}
            </div>

            <div class="sig-container">
                <div style="margin-top: 12px;">අත්සන / Signature: ____________________________________</div>
                <div style="margin-top: 4px;"><b>නම / NAME:</b> ${e.empName}</div>
                <div><b>සේ.අ.අ. අංකය / EPF NO:</b> ${e.epfNumber||e.empRegNo}</div>
                <div style="margin-top: 2px;"><b>ශුද්ධ වැටුප රු. / Net Pay Rs.</b> <b>${c(e.netSalary)}</b></div>
            </div>
        </div>
    </div>
</body>
</html>
    `}async function ge(e,s={}){if(!e)return null;if(typeof window>"u"||!window.html2pdf)return console.warn("html2pdf library is not available."),null;try{const o=s.storeId||(typeof window.getStoreId=="function"?window.getStoreId():"mec-book-shop"),p=(e.empName||e.empId||"Employee").trim().replace(/[^a-zA-Z0-9_-]/g,"_"),i=e.month||new Date().toISOString().slice(0,7),n=`Payslip_${i}_${p}.pdf`,d=document.createElement("div");d.style.position="fixed",d.style.left="-9999px",d.style.top="0",d.style.width="794px",d.style.background="#ffffff",d.innerHTML=pe(e,s,{isExport:!0}),document.body.appendChild(d);const t={margin:[8,8,8,8],filename:n,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0,logging:!1},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"}},l=await window.html2pdf().set(t).from(d).toPdf().output("blob");if(document.body.removeChild(d),!V)return console.warn("Firebase Storage is not initialized."),null;const b=`merchants/${o}/employees/${p}/payslips/${n}`,g=te(V,b),f=await ae(g,l,{contentType:"application/pdf",customMetadata:{empId:e.empId||"",empRegNo:e.empRegNo||"",empName:e.empName||"",month:i,storeId:o,netSalary:(e.netSalary||0).toString(),generatedAt:new Date().toISOString()}}),c=await ne(f.ref);e.pdfUrl=c,e.pdfStoragePath=b;const h=e.docId||`${e.empId}_${i}`;try{await se(oe("payroll",h),{pdfUrl:c,pdfStoragePath:b,pdfGeneratedAt:ie()},{merge:!0}),console.log(`✅ Payslip PDF saved & published to Cloud Storage: ${b} -> ${c}`)}catch(u){console.warn("Could not update Firestore document with pdfUrl:",u)}return c}catch(o){return console.error("generateAndUploadPayslipPDF failed:",o),null}}export{pe as a,ue as b,me as c,be as d,ye as e,ge as g};
