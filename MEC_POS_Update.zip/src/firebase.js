import { initializeApp } from "firebase/app";
import { 
    initializeFirestore, 
    persistentLocalCache,
    persistentMultipleTabManager
} from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";
import { getDatabase } from "firebase/database";

import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCFGweYcgmcfP5zS6M1ytOfKYKUbHfsols",
  authDomain: "mec-book-shop.firebaseapp.com",
  databaseURL: "https://mec-book-shop-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "mec-book-shop",
  storageBucket: "mec-book-shop.firebasestorage.app",
  messagingSenderId: "721921338336",
  appId: "1:721921338336:web:bcd6215a75b163145cd985",
  measurementId: "G-M0GZ9BXGBV"
};

const app = initializeApp(firebaseConfig);

// Initialize Firestore with Persistent Cache for fast loading and offline capabilities
const db = initializeFirestore(app, {
  localCache: persistentLocalCache({tabManager: persistentMultipleTabManager()}),
  experimentalForceLongPolling: true
});

const auth = getAuth(app);
let analytics = null;
try {
  if (typeof window !== 'undefined') {
    analytics = getAnalytics(app);
  }
} catch (e) {
  console.warn("Firebase Analytics is not supported in this environment:", e);
}
const rtdb = getDatabase(app);
const storage = getStorage(app);

export { db, auth, analytics, rtdb, storage };



