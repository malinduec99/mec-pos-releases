import { db } from './firebase.js';
import { 
    collection, 
    query, 
    where, 
    getDocs, 
    getDoc,
    setDoc,
    onSnapshot, 
    orderBy, 
    limit, 
    addDoc, 
    doc,
    updateDoc,
    serverTimestamp 
} from "firebase/firestore";

window.staffLogin = async () => {
    const rawPhone = (document.getElementById('staff-phone')?.value || '').trim();
    const pin = (document.getElementById('staff-pin')?.value || '').trim();

    if (!rawPhone || !pin) {
        return showToast("Please enter both Phone and PIN");
    }

    const loginSec = document.getElementById('section-login');
    const loadSec = document.getElementById('login-loading');
    const dashSec = document.getElementById('section-dashboard');
    const pinSetupSec = document.getElementById('section-pin-setup');

    if (loginSec) loginSec.style.display = 'none';
    if (loadSec) loadSec.style.display = 'block';

    try {
        const cleanPhone = rawPhone.replace(/\D/g, '');
        let snapshot = await getDocs(query(collection(db, 'employees'), where('phone', '==', rawPhone)));

        // Flexible phone match (07XXXXXXXX vs +947XXXXXXXX)
        if (snapshot.empty) {
            const allSnap = await getDocs(collection(db, 'employees'));
            const matched = allSnap.docs.find(d => {
                const ep = (d.data().phone || '').replace(/\D/g, '');
                return ep && cleanPhone && (ep === cleanPhone || ep.endsWith(cleanPhone.slice(-9)) || cleanPhone.endsWith(ep.slice(-9)));
            });
            if (matched) {
                snapshot = { empty: false, docs: [matched] };
            }
        }

        if (snapshot.empty) {
            throw new Error("Mobile number not registered.");
        }

        const staff = snapshot.docs[0].data();
        staff.docId = snapshot.docs[0].id;
        const empPin = (staff.pin || '').toString().trim();
        const empReg = (staff.regno || '').toString().trim();
        const empPass = (staff.password || '').toString().trim();
        const empUser = (staff.username || '').toString().trim();
        const enteredClean = pin.trim();

        // Check if employee has changed/confirmed their personal PIN
        const isPinChanged = !!staff.pinChanged;
        const mustReset = staff.mustResetPin === true || staff.isTemporaryPin === true || !isPinChanged;

        let isAuthenticated = false;
        let isFirstTime = false;

        // Matching: allow PIN, Password, Employee ID, or Username
        const matchesPin = empPin && (enteredClean === empPin);
        const matchesPass = empPass && (enteredClean === empPass);
        const matchesReg = empReg && (enteredClean.toLowerCase() === empReg.toLowerCase());
        const matchesUser = empUser && (enteredClean.toLowerCase() === empUser.toLowerCase());

        if (isPinChanged && !staff.mustResetPin) {
            // Already set personal PIN: allow personal PIN, password, or username.
            // Old initial temporary Employee ID is expired!
            if (matchesPin || matchesPass || matchesUser) {
                isAuthenticated = true;
            } else if (matchesReg && empReg !== empPin) {
                throw new Error("Initial Temporary ID has expired! Please enter your personal 4-6 digit Security PIN.");
            } else {
                throw new Error("Invalid Security PIN. (Check your 4-6 digit PIN or Password)");
            }
        } else {
            // First time login: accepts PIN, Employee ID, Password, or Username
            if (matchesPin || matchesReg || matchesPass || matchesUser) {
                isAuthenticated = true;
                isFirstTime = true;
            } else {
                throw new Error(`Invalid Security PIN or Password. (Expected PIN: ${empPin || empReg || 'PIN'} or Password: ${empPass || 'password'})`);
            }
        }

        if (!isAuthenticated) {
            throw new Error("Authentication failed.");
        }

        window.pendingAuthStaff = staff;

        // Force First-Time PIN Setup (One-time temporary PIN consumption)
        if (isFirstTime || mustReset) {
            if (loadSec) loadSec.style.display = 'none';
            if (pinSetupSec) {
                pinSetupSec.style.display = 'block';
                const nameEl = document.getElementById('pin-setup-staff-name');
                if (nameEl) nameEl.innerText = staff.name || 'Staff Member';
                const newPinInp = document.getElementById('staff-new-pin');
                if (newPinInp) {
                    newPinInp.value = '';
                    newPinInp.focus();
                }
                const confPinInp = document.getElementById('staff-confirm-pin');
                if (confPinInp) confPinInp.value = '';
            } else {
                finishStaffLogin(staff);
            }
            return;
        }

        finishStaffLogin(staff);

    } catch (err) {
        showToast(err.message);
        if (loadSec) loadSec.style.display = 'none';
        if (loginSec) loginSec.style.display = 'block';
    }
};

window.submitStaffPinSetup = async () => {
    const staff = window.pendingAuthStaff;
    if (!staff || !staff.docId) {
        showToast("Session expired, please try again.");
        window.location.reload();
        return;
    }

    const newPin = (document.getElementById('staff-new-pin')?.value || '').trim();
    const confPin = (document.getElementById('staff-confirm-pin')?.value || '').trim();

    if (!newPin || !confPin) {
        return showToast("Please enter and confirm your new PIN.");
    }

    if (!/^\d{4,6}$/.test(newPin)) {
        return showToast("PIN must be 4 to 6 numeric digits (0-9).");
    }

    if (newPin !== confPin) {
        return showToast("New PIN and Confirm PIN do not match.");
    }

    if (staff.regno && newPin.toLowerCase() === staff.regno.toLowerCase()) {
        return showToast("New PIN cannot be your old Employee ID.");
    }

    const btn = document.getElementById('btn-save-new-pin');
    if (btn) {
        btn.disabled = true;
        btn.innerText = "Securing PIN...";
    }

    try {
        await updateDoc(doc(db, 'employees', staff.docId), {
            pin: newPin,
            mustResetPin: false,
            isTemporaryPin: false,
            pinChanged: true,
            pinUpdatedAt: serverTimestamp()
        });

        staff.pin = newPin;
        staff.mustResetPin = false;
        staff.isTemporaryPin = false;
        staff.pinChanged = true;

        showToast("✅ Personal PIN saved! Welcome to your Portal.");

        const pinSetupSec = document.getElementById('section-pin-setup');
        if (pinSetupSec) pinSetupSec.style.display = 'none';

        finishStaffLogin(staff);
    } catch (err) {
        console.error(err);
        showToast("Error updating PIN: " + err.message);
        if (btn) {
            btn.disabled = false;
            btn.innerText = "Save & Unlock Portal";
        }
    }
};

window.toggleStaffPinVisibility = (inputId, btn) => {
    const input = document.getElementById(inputId);
    if (!input) return;
    if (input.type === 'password') {
        input.type = 'text';
        if (btn) btn.innerText = '🙈';
    } else {
        input.type = 'password';
        if (btn) btn.innerText = '👁️';
    }
};

window.openChangePinModal = () => {
    const m = document.getElementById('staff-change-pin-modal');
    if (m) {
        m.style.display = 'flex';
        const curInp = document.getElementById('change-pin-current');
        if (curInp) { curInp.value = ''; curInp.focus(); }
        const newInp = document.getElementById('change-pin-new');
        if (newInp) newInp.value = '';
        const confInp = document.getElementById('change-pin-confirm');
        if (confInp) confInp.value = '';
    }
};

window.closeChangePinModal = () => {
    const m = document.getElementById('staff-change-pin-modal');
    if (m) m.style.display = 'none';
};

window.submitChangePinInDashboard = async () => {
    const staff = window.currentStaff;
    if (!staff || !staff.docId) {
        return showToast("Session expired, please re-login.");
    }

    const cur = (document.getElementById('change-pin-current')?.value || '').trim();
    const next = (document.getElementById('change-pin-new')?.value || '').trim();
    const conf = (document.getElementById('change-pin-confirm')?.value || '').trim();

    if (!cur || !next || !conf) {
        return showToast("Please fill in all PIN fields.");
    }

    if (cur !== (staff.pin || '').toString().trim() && cur !== (staff.password || '').toString().trim()) {
        return showToast("Current PIN is incorrect.");
    }

    if (!/^\d{4,6}$/.test(next)) {
        return showToast("New PIN must be 4 to 6 numeric digits.");
    }

    if (next !== conf) {
        return showToast("New PIN and confirmation do not match.");
    }

    const btn = document.getElementById('btn-submit-change-pin');
    if (btn) {
        btn.disabled = true;
        btn.innerText = "Updating PIN...";
    }

    try {
        await updateDoc(doc(db, 'employees', staff.docId), {
            pin: next,
            mustResetPin: false,
            isTemporaryPin: false,
            pinChanged: true,
            pinUpdatedAt: serverTimestamp()
        });

        staff.pin = next;
        staff.mustResetPin = false;
        staff.isTemporaryPin = false;
        staff.pinChanged = true;
        window.currentStaff = staff;

        try {
            sessionStorage.setItem('mec_staff_session', JSON.stringify(staff));
            localStorage.setItem('mec_staff_session', JSON.stringify(staff));
        } catch (e) {}

        showToast("✅ PIN updated successfully!");
        window.closeChangePinModal();
    } catch (e) {
        showToast("Error updating PIN: " + e.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = "Update PIN";
        }
    }
};

function finishStaffLogin(staff) {
    window.currentStaff = staff;
    try {
        sessionStorage.setItem('mec_staff_session', JSON.stringify(staff));
        localStorage.setItem('mec_staff_session', JSON.stringify(staff));
    } catch (e) {}

    const loadSec = document.getElementById('login-loading');
    const dashSec = document.getElementById('section-dashboard');
    const loginSec = document.getElementById('section-login');
    const pinSetupSec = document.getElementById('section-pin-setup');

    if (loginSec) loginSec.remove();
    if (pinSetupSec) pinSetupSec.remove();
    if (loadSec) loadSec.style.display = 'none';
    if (dashSec) dashSec.style.display = 'block';

    loadDashboard(staff);
}

window.staffLogout = () => {
    try {
        sessionStorage.removeItem('mec_staff_session');
        localStorage.removeItem('mec_staff_session');
    } catch (e) {}
    window.location.reload();
};

// Auto-restore staff session if returning or page reloaded
function tryRestoreStaffSession() {
    try {
        const saved = sessionStorage.getItem('mec_staff_session') || localStorage.getItem('mec_staff_session');
        if (saved) {
            const staff = JSON.parse(saved);
            if (staff && (staff.docId || staff.phone)) {
                window.currentStaff = staff;
                const loginSec = document.getElementById('section-login');
                const loadSec = document.getElementById('login-loading');
                const dashSec = document.getElementById('section-dashboard');
                if (loginSec && dashSec) {
                    loginSec.style.display = 'none';
                    if (loadSec) loadSec.style.display = 'none';
                    dashSec.style.display = 'block';
                    loadDashboard(staff);
                }
            }
        }
    } catch (e) {}
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryRestoreStaffSession);
} else {
    tryRestoreStaffSession();
}

function loadDashboard(staff) {
    document.getElementById('disp-name').innerText = staff.name;
    document.getElementById('disp-role').innerText = staff.role;
    document.getElementById('disp-avatar').innerText = staff.name.charAt(0).toUpperCase();

    // Fetch Last Salary
    const payQ = query(
        collection(db, 'payroll'), 
        where('empId', '==', staff.docId),
        orderBy('timestamp', 'desc'),
        limit(1)
    );
    
    onSnapshot(payQ, (snap) => {
        if (!snap.empty) {
            const pay = snap.docs[0].data();
            document.getElementById('disp-salary').innerText = `LKR ${parseFloat(pay.amount).toLocaleString()}`;
            window.lastPaySlip = pay;
        }
    });

    // Fetch Attendance Count (This month)
    const now = new Date();
    const monthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const attQ = query(
        collection(db, 'attendance'),
        where('empId', '==', staff.docId)
    );

    onSnapshot(attQ, (snap) => {
        const records = snap.docs.map(d => ({ docId: d.id, ...d.data() }));
        const thisMonth = records.filter(r => r.date && r.date.startsWith(monthStr) && (r.status === 'Present' || r.status === 'Half Day'));
        document.getElementById('disp-attendance').innerText = `${thisMonth.length} Days`;
        window.myAttendanceRecords = records;

        const todayStr = new Date().toLocaleDateString("sv-SE");
        const todayRec = records.find(r => (r.empId === staff.docId || r.empId === staff.regno) && r.date === todayStr);
        updateStaffPortalShiftStatus(todayRec);
    });

    // Admin Store GPS Calibration Action is strictly hidden from staff dashboard
    const adminGpsBtn = document.getElementById('admin-calibrate-gps-btn');
    if (adminGpsBtn) {
        adminGpsBtn.style.display = 'none';
    }

    // Fetch My Staff Messages / Notices
    listenToStaffMails(staff);

    // Listen to Leave Requests (Approved card & notification tone)
    listenToStaffLeaveRequests(staff);
}

function isStaffAdmin(staff) {
    if (!staff) return false;
    const r = (staff.role || staff.role_access || '').toLowerCase();
    // Only True CEO / Owner / Super Admin can perform admin overrides
    return r.includes('ceo') || r.includes('founder') || r.includes('owner') || r.includes('superadmin') || r.includes('super admin');
}

let isStaffInitialMailLoad = true;
const knownStaffMailIds = new Set();

function playStaffMailChime() {
    try {
        const sound = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        sound.volume = 0.8;
        const p = sound.play();
        if (p !== undefined) {
            p.catch(() => {
                try {
                    const ctx = new (window.AudioContext || window.webkitAudioContext)();
                    if (ctx.state === 'suspended') ctx.resume();
                    const osc = ctx.createOscillator();
                    const gain = ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
                    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1);
                    gain.gain.setValueAtTime(0.25, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
                    osc.connect(gain);
                    gain.connect(ctx.destination);
                    osc.start();
                    osc.stop(ctx.currentTime + 0.5);
                } catch (e) {}
            });
        }
    } catch (e) {}
}

function listenToStaffMails(staff) {
    const storeId = staff.storeId || 'mec-book-shop';
    const staffId = staff.docId || staff.regno || staff.email;
    const staffRole = staff.role || 'Staff';
    const staffBranch = staff.branchId || 'Global';

    const mailQ = query(
        collection(db, 'internal_mails'),
        where('storeId', '==', storeId)
    );

    onSnapshot(mailQ, (snap) => {
        let mails = snap.docs.map(d => ({ docId: d.id, ...d.data() }));

        // Sort latest first
        mails.sort((a, b) => {
            const timeA = a.timestamp?.seconds ? a.timestamp.seconds * 1000 : (new Date(a.timestamp || 0).getTime() || 0);
            const timeB = b.timestamp?.seconds ? b.timestamp.seconds * 1000 : (new Date(b.timestamp || 0).getTime() || 0);
            return timeB - timeA;
        });

        // Filter messages designated for THIS SPECIFIC STAFF MEMBER ONLY
        const myMails = mails.filter(m => {
            const rId = m.recipientId || 'ALL';
            if (rId === 'ALL') return true;
            if (rId === staffId || rId === staff.regno || rId === staff.email || rId === staff.phone) return true;
            if (rId.startsWith('BRANCH_') && (rId.replace('BRANCH_', '') === staffBranch || rId.replace('BRANCH_', '') === staff.branchName)) return true;
            if (rId.startsWith('ROLE_') && rId.replace('ROLE_', '').toLowerCase() === staffRole.toLowerCase()) return true;
            if (rId === 'CASHIERS' && staffRole.toLowerCase().includes('cashier')) return true;
            if (rId === 'INVENTORY' && (staffRole.toLowerCase().includes('inventory') || staffRole.toLowerCase().includes('stock'))) return true;
            if (rId === 'TECH' && (staffRole.toLowerCase().includes('tech') || staffRole.toLowerCase().includes('repair'))) return true;
            if (rId === 'HR_ONLY' && (staffRole.toLowerCase().includes('hr') || staffRole.toLowerCase().includes('admin') || staffRole.toLowerCase().includes('manager'))) return true;
            return false;
        });

        // Live notification detection
        if (isStaffInitialMailLoad) {
            myMails.forEach(m => knownStaffMailIds.add(m.docId));
            isStaffInitialMailLoad = false;
        } else {
            const newMails = myMails.filter(m => !knownStaffMailIds.has(m.docId));
            if (newMails.length > 0) {
                newMails.forEach(nm => {
                    knownStaffMailIds.add(nm.docId);
                    playStaffMailChime();
                    showToast(`📩 New Notice from ${nm.senderName || 'HR'}: ${nm.subject || 'Staff Message'}`);
                });
            }
        }

        window.myStaffMails = myMails;

        // Calculate unread count
        const unreadCount = myMails.filter(m => !m.isRead).length;
        const unreadBadge = document.getElementById('staff-unread-badge');
        if (unreadBadge) {
            if (unreadCount > 0) {
                unreadBadge.innerText = unreadCount;
                unreadBadge.style.display = 'inline-block';
            } else {
                unreadBadge.style.display = 'none';
            }
        }

        renderStaffInboxList(myMails);
    }, (err) => {
        console.warn("Staff mail snapshot error:", err);
    });
}

function renderStaffInboxList(mails) {
    const listEl = document.getElementById('staff-inbox-list');
    if (!listEl) return;

    if (!mails || mails.length === 0) {
        listEl.innerHTML = `<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>`;
        return;
    }

    listEl.innerHTML = mails.map(m => {
        const timeStr = m.timestamp ? new Date(m.timestamp.seconds * 1000).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Just now';
        const isUrgent = m.priority === 'urgent';
        const hasAttachment = !!(m.attachment && m.attachment.url);
        const unreadDot = !m.isRead ? `<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>` : '';
        const priorityTag = isUrgent ? `<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>` : '';

        return `
            <div onclick="window.readStaffMailDetail('${m.docId}')" style="background: ${m.isRead ? 'rgba(255,255,255,0.03)' : 'rgba(56,189,248,0.08)'}; border: 1px solid ${m.isRead ? 'rgba(255,255,255,0.06)' : 'rgba(56,189,248,0.3)'}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${unreadDot}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${m.senderName || 'HR Management'}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${timeStr}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${m.subject || 'No Subject'}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${hasAttachment ? '<span title="Has Attachment" style="font-size:0.8rem;">📎</span>' : ''}
                        ${priorityTag}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

let isStaffInitialLeaveLoad = true;
const knownStaffLeaveStatuses = new Map();

function listenToStaffLeaveRequests(staff) {
    if (!staff || !staff.docId) return;

    const leaveQ = query(
        collection(db, 'leave_requests'),
        where('empId', '==', staff.docId)
    );

    onSnapshot(leaveQ, (snap) => {
        let requests = snap.docs.map(d => ({ docId: d.id, ...d.data() }));

        // Sort latest first
        requests.sort((a, b) => {
            const timeA = a.processedAt?.seconds ? a.processedAt.seconds * 1000 : (a.timestamp?.seconds ? a.timestamp.seconds * 1000 : (new Date(a.date || 0).getTime() || 0));
            const timeB = b.processedAt?.seconds ? b.processedAt.seconds * 1000 : (b.timestamp?.seconds ? b.timestamp.seconds * 1000 : (new Date(b.date || 0).getTime() || 0));
            return timeB - timeA;
        });

        // Trigger notification tone on status change to Approved or Rejected
        if (isStaffInitialLeaveLoad) {
            requests.forEach(r => knownStaffLeaveStatuses.set(r.docId, r.status));
            isStaffInitialLeaveLoad = false;
        } else {
            requests.forEach(r => {
                const prev = knownStaffLeaveStatuses.get(r.docId);
                if (prev && prev !== r.status) {
                    knownStaffLeaveStatuses.set(r.docId, r.status);
                    if (r.status === 'Approved') {
                        playStaffMailChime();
                        showToast(`🎉 Leave Request Approved by ${r.processedBy || 'Manager'}!`, 'success');
                    } else if (r.status === 'Rejected') {
                        playStaffMailChime();
                        showToast(`⚠️ Leave Request Rejected by ${r.processedBy || 'Manager'}. Remark: "${r.remark || ''}"`, 'error');
                    }
                } else if (!prev) {
                    knownStaffLeaveStatuses.set(r.docId, r.status);
                }
            });
        }

        window.allStaffLeaveRequests = requests;
        renderStaffLeaveStatusCard(requests);
        if (window.currentStaffLeaveHistoryFilter) {
            renderStaffLeaveHistoryList(window.currentStaffLeaveHistoryFilter);
        }
    }, (err) => {
        console.warn("Staff leave requests snapshot error:", err);
    });
}

function renderStaffLeaveStatusCard(requests) {
    const container = document.getElementById('staff-leave-status-container');
    if (!container) return;

    // Filter out expired leave requests (hide after 11:59:59 PM of requested leave date)
    const now = new Date();
    const activeRequests = (requests || []).filter(req => {
        if (!req || !req.date) return false;
        const rawDate = String(req.date).trim();
        let targetDateStr = rawDate;
        if (rawDate.includes('to') || rawDate.includes(' - ')) {
            const parts = rawDate.split(/\s+(?:to|-)\s+/);
            if (parts.length > 0) targetDateStr = parts[parts.length - 1].trim();
        }
        const dateParts = targetDateStr.split('-');
        if (dateParts.length === 3) {
            const year = parseInt(dateParts[0], 10);
            const month = parseInt(dateParts[1], 10) - 1;
            const day = parseInt(dateParts[2], 10);
            const endOfDay = new Date(year, month, day, 23, 59, 59, 999);
            return now <= endOfDay;
        }
        const parsed = new Date(targetDateStr);
        if (isNaN(parsed.getTime())) return false;
        const endOfDay = new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate(), 23, 59, 59, 999);
        return now <= endOfDay;
    });

    if (!activeRequests || activeRequests.length === 0) {
        container.style.display = 'none';
        container.innerHTML = '';
        return;
    }

    const req = activeRequests[0];
    container.style.display = 'block';

    const isApproved = req.status === 'Approved';
    const isRejected = req.status === 'Rejected';

    const statusColor = isApproved ? '#10b981' : (isRejected ? '#f43f5e' : '#f59e0b');
    const statusBg = isApproved ? 'rgba(16, 185, 129, 0.1)' : (isRejected ? 'rgba(244, 63, 94, 0.1)' : 'rgba(245, 158, 11, 0.08)');
    const statusBorder = isApproved ? 'rgba(16, 185, 129, 0.35)' : (isRejected ? 'rgba(244, 63, 94, 0.35)' : 'rgba(245, 158, 11, 0.25)');
    const statusBadge = isApproved ? '🟢 LEAVE APPROVED' : (isRejected ? '🔴 LEAVE REJECTED' : '⏳ PENDING REVIEW');

    let decisionHtml = '';
    if (isApproved || isRejected) {
        decisionHtml = `
            <div style="background: rgba(0,0,0,0.3); border-radius: 10px; padding: 10px 12px; margin-top: 8px; border: 1px solid ${statusBorder};">
                <div style="font-size: 0.78rem; color: #f8fafc; font-weight: 600; display:flex; align-items:center; gap:6px;">
                    <span>${isApproved ? '🛡️' : '⚠️'}</span>
                    <span>${isApproved ? 'Approved by:' : 'Rejected by:'} <b style="color:${statusColor}">${req.processedBy || 'Store Management'}</b> ${req.processorRole ? `<span style="color:#94a3b8; font-size:0.7rem;">(${req.processorRole})</span>` : ''}</span>
                </div>
                <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 5px; display:flex; align-items:flex-start; gap:6px;">
                    <span>💬</span>
                    <span>Remark: <i style="color:#fff;">"${req.remark || 'None'}"</i></span>
                </div>
                ${req.processedDate ? `
                <div style="font-size: 0.68rem; color: #64748b; margin-top: 4px; display:flex; align-items:center; gap:6px;">
                    <span>🕒</span>
                    <span>${req.processedDate}</span>
                </div>` : ''}
            </div>
        `;
    } else {
        decisionHtml = `
            <div style="font-size: 0.72rem; color: #f59e0b; margin-top: 6px; padding: 6px 10px; background: rgba(245, 158, 11, 0.08); border-radius: 8px; border: 1px solid rgba(245, 158, 11, 0.2);">
                ⏳ Awaiting authorization by Store Manager or HR.
            </div>
        `;
    }

    let medicalBillHtml = '';
    if (req.medicalBill) {
        medicalBillHtml = `
            <div style="margin-top: 10px; padding: 10px; background: rgba(16,185,129,0.08); border-radius: 10px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <img src="${req.medicalBill}" style="width: 36px; height: 36px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981;" />
                    <div>
                        <div style="font-size: 0.75rem; color: #10b981; font-weight: 700;">Medical Bill Attached ✓</div>
                        <div style="font-size: 0.68rem; color: #94a3b8;">Document attached for review</div>
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button onclick="window.viewStaffMedicalBill('${req.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: none; padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">View</button>
                    <button onclick="window.triggerStaffBillUpload('${req.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: none; padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">Replace</button>
                </div>
            </div>
        `;
    } else {
        medicalBillHtml = `
            <div style="margin-top: 10px;">
                <button onclick="window.triggerStaffBillUpload('${req.docId}')" style="width: 100%; background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.4); border-radius: 10px; padding: 8px 12px; color: #38bdf8; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span>📷</span> Upload Medical Bill / Document
                </button>
            </div>
        `;
    }

    let allowanceProtectionHtml = '';
    if (req.allowanceProtected || (isApproved && req.medicalBill)) {
        allowanceProtectionHtml = `
            <div style="margin-top: 8px; padding: 6px 10px; background: rgba(16,185,129,0.12); border-radius: 8px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 1rem;">🛡️</span>
                <div>
                    <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                    <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Monthly attendance allowance will not be deducted.</div>
                </div>
            </div>
        `;
    }

    container.innerHTML = `
        <div style="background: ${statusBg}; border: 1px solid ${statusBorder}; border-radius: 16px; padding: 14px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <span style="font-size: 0.7rem; font-weight: 800; letter-spacing: 0.8px; color: ${statusColor}; background: rgba(255,255,255,0.05); padding: 3px 8px; border-radius: 20px; border: 1px solid ${statusBorder};">
                    ${statusBadge}
                </span>
                <span style="font-size: 0.72rem; color: #38bdf8; font-weight: 700; background: rgba(56,189,248,0.1); padding: 2px 8px; border-radius: 6px;">
                    ${req.type || 'Day Off'}
                </span>
            </div>
            <div style="font-size: 1rem; font-weight: 800; color: #f8fafc; margin-bottom: 3px;">
                📅 ${req.date}
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; line-height: 1.3;">
                Reason: ${req.reason || '-'}
            </div>
            ${allowanceProtectionHtml}
            ${decisionHtml}
            ${medicalBillHtml}
        </div>
    `;
}

window.currentBillUploadReqId = null;
window.triggerStaffBillUpload = (docId) => {
    window.currentBillUploadReqId = docId;
    let input = document.getElementById('staff-bill-hidden-input');
    if (!input) {
        input = document.createElement('input');
        input.id = 'staff-bill-hidden-input';
        input.type = 'file';
        input.accept = 'image/*';
        input.style.display = 'none';
        input.onchange = async (e) => {
            const file = e.target.files?.[0];
            if (!file || !window.currentBillUploadReqId) return;
            const reader = new FileReader();
            reader.onload = async (re) => {
                const base64Data = re.target.result;
                try {
                    showToast("⏳ Uploading medical bill...", "info");
                    await updateDoc(doc(db, 'leave_requests', window.currentBillUploadReqId), {
                        medicalBill: base64Data,
                        medicalBillAt: serverTimestamp(),
                        medicalBillBy: window.currentStaff?.name || 'Staff'
                    });
                    showToast("✅ Medical bill uploaded successfully!", "success");
                } catch (err) {
                    showToast("❌ Failed to upload bill: " + err.message, "error");
                }
            };
            reader.readAsDataURL(file);
        };
        document.body.appendChild(input);
    }
    input.value = '';
    input.click();
};

window.viewStaffMedicalBill = (docId) => {
    const leaves = window.allStaffLeaveRequests || [];
    const req = leaves.find(l => l.docId === docId);
    if (!req || !req.medicalBill) return showToast("No medical bill found.", "warning");

    let modal = document.getElementById('staff-bill-lightbox-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'staff-bill-lightbox-modal';
        modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); backdrop-filter:blur(6px); display:flex; align-items:center; justify-content:center; padding:20px;';
        modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };
        document.body.appendChild(modal);
    }

    modal.innerHTML = `
        <div style="background:#0f172a; border:1px solid rgba(56,189,248,0.3); border-radius:16px; max-width:600px; width:100%; max-height:90vh; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 20px 50px rgba(0,0,0,0.7);">
            <div style="padding:14px 18px; border-bottom:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center;">
                <div style="font-weight:700; color:#f8fafc; font-size:1rem;">🩺 Medical Bill / Document</div>
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:transparent; border:none; color:#94a3b8; font-size:1.6rem; cursor:pointer;">&times;</button>
            </div>
            <div style="padding:16px; overflow:auto; text-align:center; background:#020617; flex:1;">
                <img src="${req.medicalBill}" style="max-width:100%; max-height:70vh; border-radius:8px; object-fit:contain;" alt="Medical Bill" />
            </div>
            <div style="padding:12px 18px; border-top:1px solid rgba(255,255,255,0.1); display:flex; justify-content:flex-end;">
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:rgba(255,255,255,0.1); color:white; border:none; padding:8px 18px; border-radius:8px; font-weight:600; cursor:pointer;">Close</button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
};

window.currentStaffLeaveHistoryFilter = 'All';

window.openLeaveHistoryModal = () => {
    const modal = document.getElementById('leave-history-modal');
    if (!modal) return;
    modal.style.display = 'flex';
    window.filterStaffLeaveHistory('All');
};

window.filterStaffLeaveHistory = (filter) => {
    window.currentStaffLeaveHistoryFilter = filter;
    
    ['All', 'Medical', 'Approved', 'Pending'].forEach(f => {
        const btn = document.getElementById(`filter-leave-${f.toLowerCase()}`);
        if (btn) {
            if (f === filter) {
                btn.style.background = '#38bdf8';
                btn.style.color = '#020617';
                btn.style.fontWeight = '700';
            } else {
                btn.style.background = 'rgba(255,255,255,0.08)';
                btn.style.color = '#94a3b8';
                btn.style.fontWeight = '600';
            }
        }
    });

    renderStaffLeaveHistoryList(filter);
};

function renderStaffLeaveHistoryList(filter) {
    const listEl = document.getElementById('staff-leave-history-list');
    if (!listEl) return;

    let leaves = window.allStaffLeaveRequests || [];
    if (filter === 'Medical') {
        leaves = leaves.filter(l => (l.type || '').toLowerCase().includes('medical') || (l.type || '').toLowerCase().includes('sick') || !!l.medicalBill);
    } else if (filter === 'Approved') {
        leaves = leaves.filter(l => (l.status || '').toLowerCase() === 'approved');
    } else if (filter === 'Pending') {
        leaves = leaves.filter(l => (l.status || '').toLowerCase() === 'pending');
    }

    if (leaves.length === 0) {
        listEl.innerHTML = `
            <div style="text-align: center; color: #64748b; padding: 2.5rem 1rem;">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📂</div>
                <div style="font-size: 0.9rem; font-weight: 700; color: #94a3b8;">No ${filter === 'All' ? '' : filter} leave records found.</div>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">Submit a new request or check other filters.</div>
            </div>
        `;
        return;
    }

    listEl.innerHTML = leaves.map(req => {
        const isApproved = req.status === 'Approved';
        const isRejected = req.status === 'Rejected';

        const statusColor = isApproved ? '#10b981' : (isRejected ? '#ef4444' : '#f59e0b');
        const statusBg = isApproved ? 'rgba(16, 185, 129, 0.12)' : (isRejected ? 'rgba(239, 68, 68, 0.12)' : 'rgba(245, 158, 11, 0.12)');
        const statusBorder = isApproved ? 'rgba(16, 185, 129, 0.35)' : (isRejected ? 'rgba(239, 68, 68, 0.35)' : 'rgba(245, 158, 11, 0.35)');
        const statusLabel = isApproved ? 'APPROVED' : (isRejected ? 'REJECTED' : 'PENDING REVIEW');

        const isAllowanceProtected = req.allowanceProtected === true || (isApproved && !!req.medicalBill);

        return `
            <div style="background: rgba(15, 23, 42, 0.85); border: 1px solid ${statusBorder}; border-radius: 16px; padding: 14px 16px; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                <!-- Top Row -->
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem; font-weight: 800; color: #f8fafc;">📅 ${req.date}</span>
                        <span style="background: rgba(56,189,248,0.12); color: #38bdf8; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 6px;">${req.type || 'Leave'}</span>
                    </div>
                    <span style="background: ${statusBg}; color: ${statusColor}; border: 1px solid ${statusBorder}; font-size: 0.68rem; font-weight: 800; padding: 3px 8px; border-radius: 20px; letter-spacing: 0.5px;">
                        ${statusLabel}
                    </span>
                </div>

                <!-- Reason -->
                <div style="font-size: 0.8rem; color: #cbd5e1; line-height: 1.3;">
                    <strong style="color: #94a3b8;">Reason:</strong> ${req.reason || '-'}
                </div>

                <!-- Allowance Protection Banner (Shop & Office Act) -->
                ${isAllowanceProtected ? `
                    <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 6px 10px; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem;">🛡️</span>
                        <div>
                            <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                            <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Validated by HR. No deduction from monthly attendance allowance.</div>
                        </div>
                    </div>
                ` : ''}

                <!-- Review & Remarks -->
                ${(isApproved || isRejected) ? `
                    <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 8px 10px; border-left: 3px solid ${statusColor}; font-size: 0.72rem; color: #cbd5e1;">
                        <div style="color: ${statusColor}; font-weight: 700;">
                            ${isApproved ? '✓ Approved' : '✕ Rejected'} by: ${req.processedBy || 'Store Management'} ${req.processorRole ? `(${req.processorRole})` : ''}
                        </div>
                        ${req.remark ? `<div style="margin-top: 2px; color: #94a3b8;">Remark: <i style="color:#fff;">"${req.remark}"</i></div>` : ''}
                        ${req.processedDate ? `<div style="margin-top: 2px; color: #64748b; font-size: 0.65rem;">🕒 ${req.processedDate}</div>` : ''}
                    </div>
                ` : `
                    <div style="font-size: 0.7rem; color: #f59e0b; font-style: italic;">
                        ⏳ Awaiting HR / Store Manager approval.
                    </div>
                `}

                <!-- Medical Bill / Document Section -->
                <div style="margin-top: 4px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    ${req.medicalBill ? `
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <img src="${req.medicalBill}" style="width: 34px; height: 34px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981; cursor: pointer;" onclick="window.viewStaffMedicalBill('${req.docId}')" />
                            <div>
                                <div style="font-size: 0.72rem; color: #10b981; font-weight: 700;">Medical Document Attached ✓</div>
                                <div style="font-size: 0.65rem; color: #94a3b8;">Prescription / Certificate verified</div>
                            </div>
                        </div>
                        <div style="display: flex; gap: 6px;">
                            <button type="button" onclick="window.viewStaffMedicalBill('${req.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: 1px solid rgba(16,185,129,0.4); padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">
                                View
                            </button>
                            <button type="button" onclick="window.triggerStaffBillUpload('${req.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: 1px solid rgba(255,255,255,0.15); padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">
                                Replace
                            </button>
                        </div>
                    ` : `
                        <div style="font-size: 0.72rem; color: #64748b;">
                            No medical document attached
                        </div>
                        <button type="button" onclick="window.triggerStaffBillUpload('${req.docId}')" style="background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.5); color: #38bdf8; padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                            <span>📷</span> Upload Medical Bill
                        </button>
                    `}
                </div>
            </div>
        `;
    }).join('');
}

window.openStaffInboxModal = () => {
    document.getElementById('staff-inbox-modal').style.display = 'flex';
    if (window.myStaffMails) {
        renderStaffInboxList(window.myStaffMails);
    }
};

window.readStaffMailDetail = async (mailId) => {
    const mail = (window.myStaffMails || []).find(m => m.docId === mailId);
    if (!mail) return;

    if (!mail.isRead) {
        try {
            await updateDoc(doc(db, 'internal_mails', mailId), { isRead: true });
            mail.isRead = true;
        } catch (e) {}
    }

    document.getElementById('staff-mail-view-subject').innerText = mail.subject || 'No Subject';
    document.getElementById('staff-mail-view-sender').innerText = `${mail.senderName || 'HR Management'} (${mail.senderEmail || 'System'})`;
    document.getElementById('staff-mail-view-date').innerText = mail.timestamp ? new Date(mail.timestamp.seconds * 1000).toLocaleString() : 'Just now';
    document.getElementById('staff-mail-view-body').innerText = mail.body || '';

    const badge = document.getElementById('staff-mail-view-badge');
    if (badge) {
        if (mail.priority === 'urgent') {
            badge.innerText = '🚨 Urgent Notice';
            badge.style.background = 'rgba(239,68,68,0.2)';
            badge.style.color = '#ef4444';
        } else if (mail.priority === 'confidential') {
            badge.innerText = '🔒 Confidential';
            badge.style.background = 'rgba(168,85,247,0.2)';
            badge.style.color = '#c084fc';
        } else {
            badge.innerText = '✉️ Staff Notice';
            badge.style.background = 'rgba(56,189,248,0.15)';
            badge.style.color = '#38bdf8';
        }
    }

    // Attachment Viewer
    const attContainer = document.getElementById('staff-mail-view-attachment');
    if (attContainer) {
        if (mail.attachment && mail.attachment.url) {
            const isImg = mail.attachment.type && mail.attachment.type.startsWith('image/');
            let attHtml = `
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${mail.attachment.name || 'File'}</span>
                        <a href="${mail.attachment.url}" download="${mail.attachment.name || 'download'}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;
            if (isImg) {
                attHtml += `<img src="${mail.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`;
            }
            attHtml += `</div>`;
            attContainer.innerHTML = attHtml;
            attContainer.style.display = 'block';
        } else {
            attContainer.innerHTML = '';
            attContainer.style.display = 'none';
        }
    }

    document.getElementById('staff-read-mail-modal').style.display = 'flex';
};

function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerText = msg;
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}

const downloadFile = (content, fileName) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
};

window.downloadMySlip = () => {
    if (!window.lastPaySlip) return showToast("No salary records found.");
    
    const p = window.lastPaySlip;
    const slipText = `
------------------------------------------
        MEC BOOK SHOP - PAY SLIP       
------------------------------------------
Employee: ${window.currentStaff.name}
Role:     ${window.currentStaff.role}
ID:       ${window.currentStaff.regno || '-'}
------------------------------------------
Month:    ${p.month}
Amount:   LKR ${parseFloat(p.amount).toLocaleString()}
Note:     ${p.note || 'Regular Salary'}
Date:     ${p.date || new Date(p.timestamp?.seconds * 1000).toLocaleDateString()}
------------------------------------------
Generated by MEC Staff Portal
    `;
    
    downloadFile(slipText, `payslip_${p.month}.txt`);
    showToast("📥 Payslip downloaded!");
};

window.viewMyAttendance = () => {
    if (!window.myAttendanceRecords || window.myAttendanceRecords.length === 0) {
        return showToast("No attendance records found.");
    }
    
    const staff = window.currentStaff;
    const records = [...window.myAttendanceRecords].sort((a,b) => b.date.localeCompare(a.date));
    
    const reportHtml = `
        <html>
        <head>
            <title>Attendance Report - ${staff.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${staff.name}<br>
                    <strong>Role:</strong> ${staff.role}<br>
                    <strong>Employee ID:</strong> ${staff.regno || '-'}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${records.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>In Time</th>
                        <th>Out Time</th>
                        <th>Worked</th>
                        <th>OT</th>
                        <th>Status</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${records.map(r => {
                        const inT = r.inTime || r.time || '--:--';
                        const outT = r.outTime || '--:--';
                        const dur = r.workedDuration || (r.inTime && !r.outTime ? '⏱️ In Shift' : '--');
                        const otMins = r.otMinutes ?? (r.otHours ? Math.round(r.otHours * 60) : 0);
                        const ot = otMins > 0 ? `+${otMins} mins` : '-';
                        return `
                        <tr>
                            <td>${r.date}</td>
                            <td style="font-weight:bold; color:#0284c7;">${inT}</td>
                            <td style="font-weight:bold; color:#d97706;">${outT}</td>
                            <td style="font-weight:600;">${dur}</td>
                            <td style="font-weight:bold; color:#059669;">${ot}</td>
                            <td class="status-${(r.status || '').toLowerCase().replace(' ', '')}">${r.status}</td>
                            <td style="font-size:0.8rem; color:#64748b;">${r.note || '-'}</td>
                        </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            </script>
        </body>
        </html>
    `;

    const reportWindow = window.open('', '_blank');
    reportWindow.document.write(reportHtml);
    reportWindow.document.close();
    showToast("📅 Generating PDF Report...");
};

window.openLeaveModal = () => {
    document.getElementById('leave-modal').style.display = 'flex';
    document.getElementById('leave-date').value = new Date().toISOString().split('T')[0];
};

window.submitLeaveRequest = async () => {
    const dateInput = document.getElementById('leave-date');
    const typeInput = document.getElementById('leave-type');
    const reasonInput = document.getElementById('leave-reason');

    const date = dateInput ? dateInput.value : '';
    const type = typeInput ? typeInput.value : 'Half Day';
    const reason = reasonInput ? reasonInput.value.trim() : '';
    
    if (!date || !reason) return showToast("⚠️ Please fill all fields (Date & Reason).");

    let staff = window.currentStaff;
    if (!staff) {
        try {
            staff = JSON.parse(sessionStorage.getItem('mec_staff_session') || localStorage.getItem('mec_staff_session') || '{}');
        } catch (e) {
            staff = {};
        }
    }

    const empId = staff.docId || staff.regno || staff.id || 'EMP-UNKNOWN';
    const empName = staff.name || document.getElementById('disp-name')?.innerText || 'Staff Member';
    const empRole = staff.role || document.getElementById('disp-role')?.innerText || 'Staff';
    const storeId = staff.storeId || 'mec-book-shop';

    const submitBtn = document.querySelector('#leave-modal button.btn-login:last-child');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerText = "Submitting...";
    }

    try {
        await addDoc(collection(db, 'leave_requests'), {
            empId: empId,
            empName: empName,
            empRole: empRole,
            empPhone: staff.phone || '',
            date: date,
            type: type,
            reason: reason,
            status: 'Pending',
            storeId: storeId,
            timestamp: serverTimestamp()
        });
        
        showToast("✅ Leave request submitted successfully!");
        const modal = document.getElementById('leave-modal');
        if (modal) modal.style.display = 'none';
        if (reasonInput) reasonInput.value = '';
    } catch (err) {
        console.error("Leave request error:", err);
        showToast(`❌ Error: ${err.message || "Failed to submit request"}`);
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = "Submit Request";
        }
    }
};

// --- GPS + QR MOBILE ATTENDANCE MODULE ---
let html5QrCode = null;
let currentFacingMode = "environment";
let employeeLatitude = null;
let employeeLongitude = null;
let pendingCalibrationStoreId = null;
let pendingShopLat = null;
let pendingShopLng = null;
let pendingDistanceMeters = null;

async function saveStoreGPSCoordinates(storeId, lat, lng) {
    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);
    const sId = storeId || window.currentStaff?.storeId || 'mec-book-shop';
    try {
        await setDoc(doc(db, 'config', sId), {
            storeLatitude: latNum,
            storeLongitude: lngNum
        }, { merge: true });
    } catch (e) {
        console.warn("Set config storeId error, attempting fallback:", e);
        try {
            await updateDoc(doc(db, 'config', sId), {
                storeLatitude: latNum,
                storeLongitude: lngNum
            });
        } catch (e2) {
            console.error("Config update error:", e2);
        }
    }
    try {
        await setDoc(doc(db, 'system', 'config'), {
            storeLatitude: latNum,
            storeLongitude: lngNum
        }, { merge: true });
    } catch(e) {}
    try {
        const cachedStr = localStorage.getItem(`mecpos_system_config_${sId}`);
        if (cachedStr) {
            const cached = JSON.parse(cachedStr);
            cached.storeLatitude = latNum;
            cached.storeLongitude = lngNum;
            localStorage.setItem(`mecpos_system_config_${sId}`, JSON.stringify(cached));
        }
    } catch(e) {}
}

function updateStaffPortalShiftStatus(rec) {
    const pill = document.getElementById('staff-shift-status-pill');
    if (!pill) return;

    if (!rec || (!rec.inTime && !rec.time)) {
        pill.innerHTML = `⚪ <b>Not Clocked In Today</b> — Tap above to Clock In`;
        pill.style.background = 'rgba(255,255,255,0.04)';
        pill.style.border = '1px solid rgba(255,255,255,0.08)';
        pill.style.color = '#94a3b8';
        return;
    }

    const inTime = rec.inTime || rec.time;

    // In Shift (Clocked in, but not yet clocked out)
    if (!rec.outTime) {
        pill.innerHTML = `🟢 <b>In Shift</b> (Clocked In: <b>${inTime}</b>)<br><span style="font-size:0.7rem; opacity:0.85;">Tap above to Clock-Out (15m Cooldown | 4h HD | 8h+ OT)</span>`;
        pill.style.background = 'rgba(16, 185, 129, 0.12)';
        pill.style.border = '1px solid rgba(16, 185, 129, 0.4)';
        pill.style.color = '#10b981';
        return;
    }

    // Shift completed for today
    const outTime = rec.outTime;
    const duration = rec.workedDuration || (rec.workedMinutes ? `${Math.floor(rec.workedMinutes/60)}h ${rec.workedMinutes%60}m` : '-');
    const otMins = rec.otMinutes ?? (rec.otHours ? Math.round(rec.otHours * 60) : 0);
    const ot = otMins > 0 ? `+${otMins} mins` : null;

    if (rec.status === 'Day Off') {
        pill.innerHTML = `🟣 <b>Day Off Recorded</b> (${duration})<br><span style="font-size:0.7rem;">In: ${inTime} | Out: ${outTime}</span>`;
        pill.style.background = 'rgba(168, 85, 247, 0.12)';
        pill.style.border = '1px solid rgba(168, 85, 247, 0.35)';
        pill.style.color = '#c084fc';
    } else if (rec.status === 'Half Day') {
        pill.innerHTML = `🟡 <b>Half Day Recorded</b> (${duration})<br><span style="font-size:0.7rem;">In: ${inTime} | Out: ${outTime}</span>`;
        pill.style.background = 'rgba(245, 158, 11, 0.12)';
        pill.style.border = '1px solid rgba(245, 158, 11, 0.35)';
        pill.style.color = '#f59e0b';
    } else {
        const otBadge = ot ? ` | <span style="color:#fde047; font-weight:800;">⚡ OT: ${ot}</span>` : '';
        pill.innerHTML = `🟢 <b>Shift Completed</b> (${duration})<br><span style="font-size:0.7rem;">In: ${inTime} | Out: ${outTime}${otBadge}</span>`;
        pill.style.background = 'rgba(16, 185, 129, 0.15)';
        pill.style.border = '1px solid rgba(16, 185, 129, 0.4)';
        pill.style.color = '#34d399';
    }
}
window.updateStaffPortalShiftStatus = updateStaffPortalShiftStatus;

async function processStaffAttendancePunch(distanceMeters = 0, isCalibration = false) {
    let staff = window.currentStaff;
    if (!staff) {
        try {
            staff = JSON.parse(sessionStorage.getItem('mec_staff_session') || localStorage.getItem('mec_staff_session') || '{}');
        } catch(e) {
            staff = {};
        }
    }
    if (!staff || (!staff.docId && !staff.regno)) {
        throw new Error("Staff session not found. Please log in again.");
    }

    const empId = staff.docId || staff.regno || 'EMP-UNKNOWN';
    const empName = staff.name || 'Staff Member';
    const storeId = staff.storeId || 'mec-book-shop';

    const now = new Date();
    const dateStr = now.toLocaleDateString("sv-SE"); // YYYY-MM-DD
    const nowTimeStr = now.toLocaleTimeString("en-US", { hour12: false, hour: '2-digit', minute: '2-digit' });
    const currentMs = now.getTime();

    // Check if attendance record already exists for today
    let todayRec = (window.myAttendanceRecords || []).find(r => (r.empId === empId || r.empId === staff.regno) && r.date === dateStr);

    if (!todayRec) {
        try {
            const q = query(
                collection(db, 'attendance'),
                where('empId', '==', empId),
                where('date', '==', dateStr)
            );
            const snap = await getDocs(q);
            if (!snap.empty) {
                todayRec = { docId: snap.docs[0].id, ...snap.docs[0].data() };
            }
        } catch (e) {
            console.warn("Error querying existing attendance:", e);
        }
    }

    const verificationNote = isCalibration 
        ? `GPS Calibrated to Store (${employeeLatitude?.toFixed(5) || 0}, ${employeeLongitude?.toFixed(5) || 0})`
        : `GPS+QR Verified (Distance: ${Number(distanceMeters).toFixed(1)}m)`;

    // CASE 1: No check-in today yet -> Mark TIME IN
    if (!todayRec || (!todayRec.inTime && !todayRec.time)) {
        const newRecord = {
            empId: empId,
            empName: empName,
            role: staff.role || 'Staff',
            date: dateStr,
            inTime: nowTimeStr,
            time: nowTimeStr,
            inTimestamp: currentMs,
            outTime: null,
            outTimestamp: null,
            workedMinutes: 0,
            workedDuration: '',
            otHours: 0,
            otMinutes: 0,
            otDuration: '',
            status: 'Present',
            note: `${verificationNote} | Shift Started`,
            storeId: storeId,
            timestamp: serverTimestamp()
        };

        const docRef = await addDoc(collection(db, 'attendance'), newRecord);
        showToast(`✅ Clocked In at ${nowTimeStr}! Have a great shift.`);
        updateStaffPortalShiftStatus({ ...newRecord, docId: docRef.id });
        return { type: 'IN', record: { ...newRecord, docId: docRef.id } };
    }

    // CASE 2: Already Clocked In. Check if already clocked out today
    if (todayRec.outTime) {
        showToast(`ℹ️ Shift already ended today (In: ${todayRec.inTime}, Out: ${todayRec.outTime} | Status: ${todayRec.status}).`);
        return { type: 'ALREADY_COMPLETED', record: todayRec };
    }

    // CASE 3: Clocked In, now Punching TIME OUT
    // Check 15-minute Anti-Double-Scan cooldown!
    let inMs = todayRec.inTimestamp;
    if (!inMs && (todayRec.inTime || todayRec.time)) {
        const tStr = todayRec.inTime || todayRec.time;
        if (tStr.includes(':')) {
            const parts = tStr.split(':').map(Number);
            const inDate = new Date();
            inDate.setHours(parts[0] || 0, parts[1] || 0, 0, 0);
            inMs = inDate.getTime();
        }
    }
    if (!inMs) inMs = currentMs;

    const diffMinutes = Math.max(0, Math.floor((currentMs - inMs) / 60000));

    // Rule: Cooldown: cannot punch again within 15 minutes of Time In
    if (diffMinutes < 15) {
        const remaining = 15 - diffMinutes;
        showToast(`⚠️ Cooldown Active: Clocked in at ${todayRec.inTime || todayRec.time}. Minimum 15 mins required before Clock-Out (${remaining} mins left).`);
        return { type: 'COOLDOWN_BLOCKED', remainingMins: remaining };
    }

    // Calculate duration in hours and exact minutes
    const workedHours = Math.floor(diffMinutes / 60);
    const workedMins = diffMinutes % 60;
    const workedDurationStr = workedHours > 0 
        ? `${workedHours} hrs ${workedMins} mins`
        : `${workedMins} mins`;

    let status = 'Present';
    let otHours = 0;
    let otMinutes = 0;
    let otDurationStr = '0 mins';
    let calculationSummary = '';

    // RULE 1: < 4 hours (0 to 239m) -> Day Off
    if (diffMinutes < 240) {
        status = 'Day Off';
        otHours = 0;
        otMinutes = 0;
        otDurationStr = '0 mins';
        calculationSummary = `Punched out after ${workedDurationStr} (< 4 hrs) — Recorded as Day Off`;
    }
    // RULE 2: 4 hours to < 8 hours (240m to 479m) -> Half Day
    else if (diffMinutes < 480) {
        status = 'Half Day';
        otHours = 0;
        otMinutes = 0;
        otDurationStr = '0 mins';
        calculationSummary = `Punched out after ${workedDurationStr} — Recorded as Half Day`;
    }
    // RULE 3: 8 hours or more (>= 480 mins) -> Full Day (Present) + OT to the exact minute if > 8 hrs!
    else {
        status = 'Present';
        if (diffMinutes > 480) {
            otMinutes = diffMinutes - 480; // Extra worked minutes beyond 8 hours
            otHours = +(otMinutes / 60).toFixed(2);
            otDurationStr = `${otMinutes} mins`;
            calculationSummary = `Shift Completed (${workedDurationStr}) — Full Day + ${otMinutes} mins OT`;
        } else {
            otHours = 0;
            otMinutes = 0;
            otDurationStr = '0 mins';
            calculationSummary = `Shift Completed (8 hrs) — Full Day (0 OT)`;
        }
    }

    const updateData = {
        outTime: nowTimeStr,
        outTimestamp: currentMs,
        workedMinutes: diffMinutes,
        workedDuration: workedDurationStr,
        otHours: otHours,
        otMinutes: otMinutes,
        otDuration: otDurationStr,
        status: status,
        note: `${verificationNote} | ${calculationSummary}`,
        updatedAt: serverTimestamp()
    };

    if (todayRec.docId) {
        await updateDoc(doc(db, 'attendance', todayRec.docId), updateData);
    } else {
        const q = query(
            collection(db, 'attendance'),
            where('empId', '==', empId),
            where('date', '==', dateStr)
        );
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, 'attendance', snap.docs[0].id), updateData);
        } else {
            await addDoc(collection(db, 'attendance'), {
                empId,
                empName,
                role: staff.role || 'Staff',
                date: dateStr,
                inTime: todayRec.inTime || nowTimeStr,
                time: todayRec.time || nowTimeStr,
                storeId,
                ...updateData
            });
        }
    }

    updateStaffPortalShiftStatus({ ...todayRec, ...updateData });

    let successMsg = `✅ Clocked Out at ${nowTimeStr} (${workedDurationStr})! Status: ${status}`;
    if (otHours > 0) {
        successMsg += ` | ⚡ OT: +${otDurationStr}`;
    }
    showToast(successMsg);
    return { type: 'OUT', status, workedDuration: workedDurationStr, otDuration: otDurationStr };
}
window.processStaffAttendancePunch = processStaffAttendancePunch;

window.calibrateStoreGPSFromPhone = async () => {
    const pin = prompt("🔒 Admin Verification Required:\nEnter Master Admin Security PIN or CEO Password to calibrate Shop GPS:");
    if (!pin) return;

    const validMasterPasswords = ['9556', '1234', 'admin', 'mecpos', 'mec123', 'malindu123', 'mecpos123'];
    if (!validMasterPasswords.includes(pin.trim().toLowerCase())) {
        return showToast("❌ Access Denied: Invalid Admin Security PIN or Password!");
    }

    if (!navigator.geolocation) {
        return showToast("GPS Geolocation not supported on this device.");
    }
    showToast("📍 Acquiring high-accuracy live GPS coordinates...");
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const acc = position.coords.accuracy ? ` (±${Math.round(position.coords.accuracy)}m)` : '';
            const confirmMsg = `Set current phone location as official Shop GPS?\n\n📍 Latitude: ${lat.toFixed(6)}\n📍 Longitude: ${lng.toFixed(6)}${acc}\n\nAll employee clock-in scans will be verified against this exact store location.`;
            if (confirm(confirmMsg)) {
                try {
                    const targetStore = window.currentStaff?.storeId || 'mec-book-shop';
                    await saveStoreGPSCoordinates(targetStore, lat, lng);
                    showToast("✅ Store GPS coordinates successfully updated!");
                } catch(e) {
                    showToast("❌ Failed to update GPS coordinates: " + e.message);
                }
            }
        },
        (error) => {
            console.error("GPS Error:", error);
            showToast("❌ Unable to acquire GPS location. Please ensure Location is enabled.");
        },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
};

window.confirmCalibrateStoreGPS = async () => {
    const pin = prompt("🔒 Admin Security Check:\nEnter Master Admin PIN to confirm Store GPS override:");
    if (!pin) return;
    const validMasterPasswords = ['9556', '1234', 'admin', 'mecpos', 'mec123', 'malindu123', 'mecpos123'];
    if (!validMasterPasswords.includes(pin.trim().toLowerCase())) {
        return showToast("❌ Access Denied: Invalid Security PIN!");
    }

    const btn = document.getElementById('btn-calibrate-gps');
    if (btn) {
        btn.disabled = true;
        btn.innerText = "⏳ Saving Store GPS...";
    }
    try {
        if (!employeeLatitude || !employeeLongitude) {
            throw new Error("Phone GPS coordinates not found. Please re-scan.");
        }
        const targetStore = pendingCalibrationStoreId || window.currentStaff?.storeId || 'mec-book-shop';
        await saveStoreGPSCoordinates(targetStore, employeeLatitude, employeeLongitude);

        document.getElementById('gps-mismatch-modal').style.display = 'none';
        showToast("📍 Shop GPS calibrated! Recording attendance...");

        // Immediately mark attendance punch
        await processStaffAttendancePunch(0, true);
    } catch (err) {
        console.error("Calibration error:", err);
        showToast(`❌ Error: ${err.message || "Failed to calibrate"}`);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = "📍 Set Shop GPS to My Phone & Clock-In";
        }
    }
};

window.startAttendanceClock = () => {
    if (!navigator.geolocation) {
        return showToast("GPS Geolocation not supported on this device.");
    }

    showToast("📍 Accessing live GPS coordinates...");
    navigator.geolocation.getCurrentPosition(
        (position) => {
            employeeLatitude = position.coords.latitude;
            employeeLongitude = position.coords.longitude;
            
            // Check accuracy - warn if signal is coarse cellular/IP estimate
            if (position.coords.accuracy && position.coords.accuracy > 300) {
                console.warn("Low GPS accuracy:", position.coords.accuracy);
                showToast(`⚠️ Low GPS signal accuracy (±${Math.round(position.coords.accuracy)}m). Please turn on High Accuracy Location.`);
            }

            // Fresh live GPS acquired. Now launch QR scanner
            document.getElementById('scanner-modal').style.display = 'flex';
            if (!html5QrCode) {
                html5QrCode = new Html5Qrcode("scanner-reader");
            }
            startCamera();
        },
        (error) => {
            console.error("GPS Error:", error);
            showToast("❌ Unable to verify live location. Please turn on Location / GPS on your phone.");
        },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
};

const startCamera = () => {
    const config = {
        fps: 20,
        qrbox: (width, height) => ({
            width: Math.floor(width * 0.7),
            height: Math.floor(height * 0.7)
        })
    };

    html5QrCode.start(
        { facingMode: currentFacingMode },
        config,
        onAttendanceQRScanned
    ).catch(err => {
        console.error("Camera access error:", err);
        showToast("Cannot open camera. Check permissions.");
    });
};

window.toggleCamera = () => {
    currentFacingMode = currentFacingMode === "environment" ? "user" : "environment";
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => startCamera());
    }
};

window.closeScanner = () => {
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
            document.getElementById('scanner-modal').style.display = 'none';
        });
    } else {
        document.getElementById('scanner-modal').style.display = 'none';
    }
};

const onAttendanceQRScanned = async (decodedText) => {
    const val = decodedText.trim();
    if (!val.startsWith("MEC-POS-ATTENDANCE-QR:")) {
        showToast("⚠️ Invalid QR Code. Scan the Shop QR Code.");
        return;
    }

    window.closeScanner();
    showToast("🔄 Verifying physical presence...");

    const parts = val.split(":");
    const targetStore = parts[1] || window.currentStaff?.storeId || 'mec-book-shop';
    let shopLat = parseFloat(parts[2]);
    let shopLng = parseFloat(parts[3]);

    // Check if store has updated/calibrated GPS in Firestore
    try {
        const storeDoc = await getDoc(doc(db, 'config', targetStore));
        if (storeDoc.exists()) {
            const data = storeDoc.data();
            if (data.storeLatitude && data.storeLongitude) {
                shopLat = parseFloat(data.storeLatitude);
                shopLng = parseFloat(data.storeLongitude);
            }
        }
    } catch(e) {
        console.warn("Could not fetch remote store config:", e);
    }

    // Haversine distance formula
    const R = 6371e3; // Earth radius in meters
    const rad1 = employeeLatitude * Math.PI / 180;
    const rad2 = shopLat * Math.PI / 180;
    const deltaLat = (shopLat - employeeLatitude) * Math.PI / 180;
    const deltaLng = (shopLng - employeeLongitude) * Math.PI / 180;

    const a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) +
              Math.cos(rad1) * Math.cos(rad2) *
              Math.sin(deltaLng/2) * Math.sin(deltaLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distanceMeters = R * c;

    // Tolerance: 150m (gives good room for mobile indoor GPS drift)
    if (distanceMeters > 150) {
        pendingCalibrationStoreId = targetStore;
        pendingShopLat = shopLat;
        pendingShopLng = shopLng;
        pendingDistanceMeters = distanceMeters;

        const distStr = distanceMeters >= 1000 
            ? `${(distanceMeters / 1000).toFixed(1)} km` 
            : `${distanceMeters.toFixed(1)} m`;

        const distEl = document.getElementById('mismatch-distance');
        if (distEl) distEl.innerText = distStr;
        const myCoordsEl = document.getElementById('mismatch-my-coords');
        if (myCoordsEl) myCoordsEl.innerText = `${employeeLatitude.toFixed(5)}, ${employeeLongitude.toFixed(5)}`;
        const qrCoordsEl = document.getElementById('mismatch-qr-coords');
        if (qrCoordsEl) qrCoordsEl.innerText = `${shopLat.toFixed(5)}, ${shopLng.toFixed(5)}`;

        const modal = document.getElementById('gps-mismatch-modal');
        if (modal) modal.style.display = 'flex';
        return;
    }

    // Save check-in / check-out
    try {
        await processStaffAttendancePunch(distanceMeters, false);
    } catch (err) {
        console.error(err);
        showToast("Error logging attendance to database: " + (err.message || ''));
    }
};
