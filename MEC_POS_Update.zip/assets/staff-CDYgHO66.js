import{g as z,q as A,c as P,d as h,w as M,u as N,b as B,s as H,l as ae,j as ie,o as _,a as G,f as se,e as J}from"./firebase-Bn3UcnFE.js";/* empty css              */window.staffLogin=async()=>{var i,s;const e=(((i=document.getElementById("staff-phone"))==null?void 0:i.value)||"").trim(),n=(((s=document.getElementById("staff-pin"))==null?void 0:s.value)||"").trim();if(!e||!n)return c("Please enter both Phone and PIN");const t=document.getElementById("section-login"),a=document.getElementById("login-loading");document.getElementById("section-dashboard");const o=document.getElementById("section-pin-setup");t&&(t.style.display="none"),a&&(a.style.display="block");try{const r=e.replace(/\D/g,"");let d=await z(A(P(h,"employees"),M("phone","==",e)));if(d.empty){const u=(await z(P(h,"employees"))).docs.find(S=>{const D=(S.data().phone||"").replace(/\D/g,"");return D&&r&&(D===r||D.endsWith(r.slice(-9))||r.endsWith(D.slice(-9)))});u&&(d={empty:!1,docs:[u]})}if(d.empty)throw new Error("Mobile number not registered.");const f=d.docs[0].data();f.docId=d.docs[0].id;const p=(f.pin||"").toString().trim(),l=(f.regno||"").toString().trim(),m=(f.password||"").toString().trim(),g=(f.username||"").toString().trim(),w=n.trim(),y=!!f.pinChanged,b=f.mustResetPin===!0||f.isTemporaryPin===!0||!y;let x=!1,v=!1;const I=p&&w===p,$=m&&w===m,E=l&&w.toLowerCase()===l.toLowerCase(),T=g&&w.toLowerCase()===g.toLowerCase();if(y&&!f.mustResetPin)if(I||$||T)x=!0;else throw E&&l!==p?new Error("Initial Temporary ID has expired! Please enter your personal 4-6 digit Security PIN."):new Error("Invalid Security PIN. (Check your 4-6 digit PIN or Password)");else if(I||E||$||T)x=!0,v=!0;else throw new Error(`Invalid Security PIN or Password. (Expected PIN: ${p||l||"PIN"} or Password: ${m||"password"})`);if(!x)throw new Error("Authentication failed.");if(window.pendingAuthStaff=f,v||b){if(a&&(a.style.display="none"),o){o.style.display="block";const R=document.getElementById("pin-setup-staff-name");R&&(R.innerText=f.name||"Staff Member");const u=document.getElementById("staff-new-pin");u&&(u.value="",u.focus());const S=document.getElementById("staff-confirm-pin");S&&(S.value="")}else U(f);return}U(f)}catch(r){c(r.message),a&&(a.style.display="none"),t&&(t.style.display="block")}};window.submitStaffPinSetup=async()=>{var o,i;const e=window.pendingAuthStaff;if(!e||!e.docId){c("Session expired, please try again."),window.location.reload();return}const n=(((o=document.getElementById("staff-new-pin"))==null?void 0:o.value)||"").trim(),t=(((i=document.getElementById("staff-confirm-pin"))==null?void 0:i.value)||"").trim();if(!n||!t)return c("Please enter and confirm your new PIN.");if(!/^\d{4,6}$/.test(n))return c("PIN must be 4 to 6 numeric digits (0-9).");if(n!==t)return c("New PIN and Confirm PIN do not match.");if(e.regno&&n.toLowerCase()===e.regno.toLowerCase())return c("New PIN cannot be your old Employee ID.");const a=document.getElementById("btn-save-new-pin");a&&(a.disabled=!0,a.innerText="Securing PIN...");try{await N(B(h,"employees",e.docId),{pin:n,mustResetPin:!1,isTemporaryPin:!1,pinChanged:!0,pinUpdatedAt:H()}),e.pin=n,e.mustResetPin=!1,e.isTemporaryPin=!1,e.pinChanged=!0,c("✅ Personal PIN saved! Welcome to your Portal.");const s=document.getElementById("section-pin-setup");s&&(s.style.display="none"),U(e)}catch(s){console.error(s),c("Error updating PIN: "+s.message),a&&(a.disabled=!1,a.innerText="Save & Unlock Portal")}};window.toggleStaffPinVisibility=(e,n)=>{const t=document.getElementById(e);t&&(t.type==="password"?(t.type="text",n&&(n.innerText="🙈")):(t.type="password",n&&(n.innerText="👁️")))};window.openChangePinModal=()=>{const e=document.getElementById("staff-change-pin-modal");if(e){e.style.display="flex";const n=document.getElementById("change-pin-current");n&&(n.value="",n.focus());const t=document.getElementById("change-pin-new");t&&(t.value="");const a=document.getElementById("change-pin-confirm");a&&(a.value="")}};window.closeChangePinModal=()=>{const e=document.getElementById("staff-change-pin-modal");e&&(e.style.display="none")};window.submitChangePinInDashboard=async()=>{var i,s,r;const e=window.currentStaff;if(!e||!e.docId)return c("Session expired, please re-login.");const n=(((i=document.getElementById("change-pin-current"))==null?void 0:i.value)||"").trim(),t=(((s=document.getElementById("change-pin-new"))==null?void 0:s.value)||"").trim(),a=(((r=document.getElementById("change-pin-confirm"))==null?void 0:r.value)||"").trim();if(!n||!t||!a)return c("Please fill in all PIN fields.");if(n!==(e.pin||"").toString().trim()&&n!==(e.password||"").toString().trim())return c("Current PIN is incorrect.");if(!/^\d{4,6}$/.test(t))return c("New PIN must be 4 to 6 numeric digits.");if(t!==a)return c("New PIN and confirmation do not match.");const o=document.getElementById("btn-submit-change-pin");o&&(o.disabled=!0,o.innerText="Updating PIN...");try{await N(B(h,"employees",e.docId),{pin:t,mustResetPin:!1,isTemporaryPin:!1,pinChanged:!0,pinUpdatedAt:H()}),e.pin=t,e.mustResetPin=!1,e.isTemporaryPin=!1,e.pinChanged=!0,window.currentStaff=e;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(e)),localStorage.setItem("mec_staff_session",JSON.stringify(e))}catch{}c("✅ PIN updated successfully!"),window.closeChangePinModal()}catch(d){c("Error updating PIN: "+d.message)}finally{o&&(o.disabled=!1,o.innerText="Update PIN")}};function U(e){window.currentStaff=e;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(e)),localStorage.setItem("mec_staff_session",JSON.stringify(e))}catch{}const n=document.getElementById("login-loading"),t=document.getElementById("section-dashboard"),a=document.getElementById("section-login"),o=document.getElementById("section-pin-setup");a&&a.remove(),o&&o.remove(),n&&(n.style.display="none"),t&&(t.style.display="block"),X(e)}window.staffLogout=()=>{try{sessionStorage.removeItem("mec_staff_session"),localStorage.removeItem("mec_staff_session")}catch{}window.location.reload()};function Q(){try{const e=sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session");if(e){const n=JSON.parse(e);if(n&&(n.docId||n.phone)){window.currentStaff=n;const t=document.getElementById("section-login"),a=document.getElementById("login-loading"),o=document.getElementById("section-dashboard");t&&o&&(t.style.display="none",a&&(a.style.display="none"),o.style.display="block",X(n))}}}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Q):Q();function X(e){document.getElementById("disp-name").innerText=e.name,document.getElementById("disp-role").innerText=e.role,document.getElementById("disp-avatar").innerText=e.name.charAt(0).toUpperCase();const n=A(P(h,"payroll"),M("empId","==",e.docId),ie("timestamp","desc"),ae(1));_(n,s=>{if(!s.empty){const r=s.docs[0].data();document.getElementById("disp-salary").innerText=`LKR ${parseFloat(r.amount).toLocaleString()}`,window.lastPaySlip=r}});const t=new Date,a=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}`,o=A(P(h,"attendance"),M("empId","==",e.docId));_(o,s=>{const r=s.docs.map(l=>({docId:l.id,...l.data()})),d=r.filter(l=>l.date&&l.date.startsWith(a)&&(l.status==="Present"||l.status==="Half Day"));document.getElementById("disp-attendance").innerText=`${d.length} Days`,window.myAttendanceRecords=r;const f=new Date().toLocaleDateString("sv-SE"),p=r.find(l=>(l.empId===e.docId||l.empId===e.regno)&&l.date===f);F(p)});const i=document.getElementById("admin-calibrate-gps-btn");i&&(i.style.display="none"),re(e),de(e)}let K=!0;const j=new Set;function q(){try{const e=new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");e.volume=.8;const n=e.play();n!==void 0&&n.catch(()=>{try{const t=new(window.AudioContext||window.webkitAudioContext);t.state==="suspended"&&t.resume();const a=t.createOscillator(),o=t.createGain();a.type="sine",a.frequency.setValueAtTime(587.33,t.currentTime),a.frequency.setValueAtTime(880,t.currentTime+.1),o.gain.setValueAtTime(.25,t.currentTime),o.gain.exponentialRampToValueAtTime(.001,t.currentTime+.45),a.connect(o),o.connect(t.destination),a.start(),a.stop(t.currentTime+.5)}catch{}})}catch{}}function re(e){const n=e.storeId||"mec-book-shop",t=e.docId||e.regno||e.email,a=e.role||"Staff",o=e.branchId||"Global",i=A(P(h,"internal_mails"),M("storeId","==",n));_(i,s=>{let r=s.docs.map(l=>({docId:l.id,...l.data()}));r.sort((l,m)=>{var y,b;const g=(y=l.timestamp)!=null&&y.seconds?l.timestamp.seconds*1e3:new Date(l.timestamp||0).getTime()||0;return((b=m.timestamp)!=null&&b.seconds?m.timestamp.seconds*1e3:new Date(m.timestamp||0).getTime()||0)-g});const d=r.filter(l=>{const m=l.recipientId||"ALL";return!!(m==="ALL"||m===t||m===e.regno||m===e.email||m===e.phone||m.startsWith("BRANCH_")&&(m.replace("BRANCH_","")===o||m.replace("BRANCH_","")===e.branchName)||m.startsWith("ROLE_")&&m.replace("ROLE_","").toLowerCase()===a.toLowerCase()||m==="CASHIERS"&&a.toLowerCase().includes("cashier")||m==="INVENTORY"&&(a.toLowerCase().includes("inventory")||a.toLowerCase().includes("stock"))||m==="TECH"&&(a.toLowerCase().includes("tech")||a.toLowerCase().includes("repair"))||m==="HR_ONLY"&&(a.toLowerCase().includes("hr")||a.toLowerCase().includes("admin")||a.toLowerCase().includes("manager")))});if(K)d.forEach(l=>j.add(l.docId)),K=!1;else{const l=d.filter(m=>!j.has(m.docId));l.length>0&&l.forEach(m=>{j.add(m.docId),q(),c(`📩 New Notice from ${m.senderName||"HR"}: ${m.subject||"Staff Message"}`)})}window.myStaffMails=d;const f=d.filter(l=>!l.isRead).length,p=document.getElementById("staff-unread-badge");p&&(f>0?(p.innerText=f,p.style.display="inline-block"):p.style.display="none"),Z(d)},s=>{console.warn("Staff mail snapshot error:",s)})}function Z(e){const n=document.getElementById("staff-inbox-list");if(n){if(!e||e.length===0){n.innerHTML='<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>';return}n.innerHTML=e.map(t=>{const a=t.timestamp?new Date(t.timestamp.seconds*1e3).toLocaleString([],{dateStyle:"short",timeStyle:"short"}):"Just now",o=t.priority==="urgent",i=!!(t.attachment&&t.attachment.url),s=t.isRead?"":'<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>',r=o?'<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>':"";return`
            <div onclick="window.readStaffMailDetail('${t.docId}')" style="background: ${t.isRead?"rgba(255,255,255,0.03)":"rgba(56,189,248,0.08)"}; border: 1px solid ${t.isRead?"rgba(255,255,255,0.06)":"rgba(56,189,248,0.3)"}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${s}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${t.senderName||"HR Management"}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${a}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${t.subject||"No Subject"}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${i?'<span title="Has Attachment" style="font-size:0.8rem;">📎</span>':""}
                        ${r}
                    </div>
                </div>
            </div>
        `}).join("")}}let Y=!0;const O=new Map;function de(e){if(!e||!e.docId)return;const n=A(P(h,"leave_requests"),M("empId","==",e.docId));_(n,t=>{let a=t.docs.map(o=>({docId:o.id,...o.data()}));a.sort((o,i)=>{var d,f,p,l;const s=(d=o.processedAt)!=null&&d.seconds?o.processedAt.seconds*1e3:(f=o.timestamp)!=null&&f.seconds?o.timestamp.seconds*1e3:new Date(o.date||0).getTime()||0;return((p=i.processedAt)!=null&&p.seconds?i.processedAt.seconds*1e3:(l=i.timestamp)!=null&&l.seconds?i.timestamp.seconds*1e3:new Date(i.date||0).getTime()||0)-s}),Y?(a.forEach(o=>O.set(o.docId,o.status)),Y=!1):a.forEach(o=>{const i=O.get(o.docId);i&&i!==o.status?(O.set(o.docId,o.status),o.status==="Approved"?(q(),c(`🎉 Leave Request Approved by ${o.processedBy||"Manager"}!`)):o.status==="Rejected"&&(q(),c(`⚠️ Leave Request Rejected by ${o.processedBy||"Manager"}. Remark: "${o.remark||""}"`))):i||O.set(o.docId,o.status)}),window.allStaffLeaveRequests=a,le(a),window.currentStaffLeaveHistoryFilter&&ee(window.currentStaffLeaveHistoryFilter)},t=>{console.warn("Staff leave requests snapshot error:",t)})}function le(e){const n=document.getElementById("staff-leave-status-container");if(!n)return;const t=new Date,a=(e||[]).filter(w=>{if(!w||!w.date)return!1;const y=String(w.date).trim();let b=y;if(y.includes("to")||y.includes(" - ")){const $=y.split(/\s+(?:to|-)\s+/);$.length>0&&(b=$[$.length-1].trim())}const x=b.split("-");if(x.length===3){const $=parseInt(x[0],10),E=parseInt(x[1],10)-1,T=parseInt(x[2],10),R=new Date($,E,T,23,59,59,999);return t<=R}const v=new Date(b);if(isNaN(v.getTime()))return!1;const I=new Date(v.getFullYear(),v.getMonth(),v.getDate(),23,59,59,999);return t<=I});if(!a||a.length===0){n.style.display="none",n.innerHTML="";return}const o=a[0];n.style.display="block";const i=o.status==="Approved",s=o.status==="Rejected",r=i?"#10b981":s?"#f43f5e":"#f59e0b",d=i?"rgba(16, 185, 129, 0.1)":s?"rgba(244, 63, 94, 0.1)":"rgba(245, 158, 11, 0.08)",f=i?"rgba(16, 185, 129, 0.35)":s?"rgba(244, 63, 94, 0.35)":"rgba(245, 158, 11, 0.25)",p=i?"🟢 LEAVE APPROVED":s?"🔴 LEAVE REJECTED":"⏳ PENDING REVIEW";let l="";i||s?l=`
            <div style="background: rgba(0,0,0,0.3); border-radius: 10px; padding: 10px 12px; margin-top: 8px; border: 1px solid ${f};">
                <div style="font-size: 0.78rem; color: #f8fafc; font-weight: 600; display:flex; align-items:center; gap:6px;">
                    <span>${i?"🛡️":"⚠️"}</span>
                    <span>${i?"Approved by:":"Rejected by:"} <b style="color:${r}">${o.processedBy||"Store Management"}</b> ${o.processorRole?`<span style="color:#94a3b8; font-size:0.7rem;">(${o.processorRole})</span>`:""}</span>
                </div>
                <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 5px; display:flex; align-items:flex-start; gap:6px;">
                    <span>💬</span>
                    <span>Remark: <i style="color:#fff;">"${o.remark||"None"}"</i></span>
                </div>
                ${o.processedDate?`
                <div style="font-size: 0.68rem; color: #64748b; margin-top: 4px; display:flex; align-items:center; gap:6px;">
                    <span>🕒</span>
                    <span>${o.processedDate}</span>
                </div>`:""}
            </div>
        `:l=`
            <div style="font-size: 0.72rem; color: #f59e0b; margin-top: 6px; padding: 6px 10px; background: rgba(245, 158, 11, 0.08); border-radius: 8px; border: 1px solid rgba(245, 158, 11, 0.2);">
                ⏳ Awaiting authorization by Store Manager or HR.
            </div>
        `;let m="";o.medicalBill?m=`
            <div style="margin-top: 10px; padding: 10px; background: rgba(16,185,129,0.08); border-radius: 10px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <img src="${o.medicalBill}" style="width: 36px; height: 36px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981;" />
                    <div>
                        <div style="font-size: 0.75rem; color: #10b981; font-weight: 700;">Medical Bill Attached ✓</div>
                        <div style="font-size: 0.68rem; color: #94a3b8;">Document attached for review</div>
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button onclick="window.viewStaffMedicalBill('${o.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: none; padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">View</button>
                    <button onclick="window.triggerStaffBillUpload('${o.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: none; padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">Replace</button>
                </div>
            </div>
        `:m=`
            <div style="margin-top: 10px;">
                <button onclick="window.triggerStaffBillUpload('${o.docId}')" style="width: 100%; background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.4); border-radius: 10px; padding: 8px 12px; color: #38bdf8; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span>📷</span> Upload Medical Bill / Document
                </button>
            </div>
        `;let g="";(o.allowanceProtected||i&&o.medicalBill)&&(g=`
            <div style="margin-top: 8px; padding: 6px 10px; background: rgba(16,185,129,0.12); border-radius: 8px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 1rem;">🛡️</span>
                <div>
                    <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                    <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Monthly attendance allowance will not be deducted.</div>
                </div>
            </div>
        `),n.innerHTML=`
        <div style="background: ${d}; border: 1px solid ${f}; border-radius: 16px; padding: 14px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <span style="font-size: 0.7rem; font-weight: 800; letter-spacing: 0.8px; color: ${r}; background: rgba(255,255,255,0.05); padding: 3px 8px; border-radius: 20px; border: 1px solid ${f};">
                    ${p}
                </span>
                <span style="font-size: 0.72rem; color: #38bdf8; font-weight: 700; background: rgba(56,189,248,0.1); padding: 2px 8px; border-radius: 6px;">
                    ${o.type||"Day Off"}
                </span>
            </div>
            <div style="font-size: 1rem; font-weight: 800; color: #f8fafc; margin-bottom: 3px;">
                📅 ${o.date}
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; line-height: 1.3;">
                Reason: ${o.reason||"-"}
            </div>
            ${g}
            ${l}
            ${m}
        </div>
    `}window.currentBillUploadReqId=null;window.triggerStaffBillUpload=e=>{window.currentBillUploadReqId=e;let n=document.getElementById("staff-bill-hidden-input");n||(n=document.createElement("input"),n.id="staff-bill-hidden-input",n.type="file",n.accept="image/*",n.style.display="none",n.onchange=async t=>{var i;const a=(i=t.target.files)==null?void 0:i[0];if(!a||!window.currentBillUploadReqId)return;const o=new FileReader;o.onload=async s=>{var d;const r=s.target.result;try{c("⏳ Uploading medical bill...","info"),await N(B(h,"leave_requests",window.currentBillUploadReqId),{medicalBill:r,medicalBillAt:H(),medicalBillBy:((d=window.currentStaff)==null?void 0:d.name)||"Staff"}),c("✅ Medical bill uploaded successfully!","success")}catch(f){c("❌ Failed to upload bill: "+f.message)}},o.readAsDataURL(a)},document.body.appendChild(n)),n.value="",n.click()};window.viewStaffMedicalBill=e=>{const t=(window.allStaffLeaveRequests||[]).find(o=>o.docId===e);if(!t||!t.medicalBill)return c("No medical bill found.");let a=document.getElementById("staff-bill-lightbox-modal");a||(a=document.createElement("div"),a.id="staff-bill-lightbox-modal",a.style.cssText="position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); backdrop-filter:blur(6px); display:flex; align-items:center; justify-content:center; padding:20px;",a.onclick=o=>{o.target===a&&(a.style.display="none")},document.body.appendChild(a)),a.innerHTML=`
        <div style="background:#0f172a; border:1px solid rgba(56,189,248,0.3); border-radius:16px; max-width:600px; width:100%; max-height:90vh; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 20px 50px rgba(0,0,0,0.7);">
            <div style="padding:14px 18px; border-bottom:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center;">
                <div style="font-weight:700; color:#f8fafc; font-size:1rem;">🩺 Medical Bill / Document</div>
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:transparent; border:none; color:#94a3b8; font-size:1.6rem; cursor:pointer;">&times;</button>
            </div>
            <div style="padding:16px; overflow:auto; text-align:center; background:#020617; flex:1;">
                <img src="${t.medicalBill}" style="max-width:100%; max-height:70vh; border-radius:8px; object-fit:contain;" alt="Medical Bill" />
            </div>
            <div style="padding:12px 18px; border-top:1px solid rgba(255,255,255,0.1); display:flex; justify-content:flex-end;">
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:rgba(255,255,255,0.1); color:white; border:none; padding:8px 18px; border-radius:8px; font-weight:600; cursor:pointer;">Close</button>
            </div>
        </div>
    `,a.style.display="flex"};window.currentStaffLeaveHistoryFilter="All";window.openLeaveHistoryModal=()=>{const e=document.getElementById("leave-history-modal");e&&(e.style.display="flex",window.filterStaffLeaveHistory("All"))};window.filterStaffLeaveHistory=e=>{window.currentStaffLeaveHistoryFilter=e,["All","Medical","Approved","Pending"].forEach(n=>{const t=document.getElementById(`filter-leave-${n.toLowerCase()}`);t&&(n===e?(t.style.background="#38bdf8",t.style.color="#020617",t.style.fontWeight="700"):(t.style.background="rgba(255,255,255,0.08)",t.style.color="#94a3b8",t.style.fontWeight="600"))}),ee(e)};function ee(e){const n=document.getElementById("staff-leave-history-list");if(!n)return;let t=window.allStaffLeaveRequests||[];if(e==="Medical"?t=t.filter(a=>(a.type||"").toLowerCase().includes("medical")||(a.type||"").toLowerCase().includes("sick")||!!a.medicalBill):e==="Approved"?t=t.filter(a=>(a.status||"").toLowerCase()==="approved"):e==="Pending"&&(t=t.filter(a=>(a.status||"").toLowerCase()==="pending")),t.length===0){n.innerHTML=`
            <div style="text-align: center; color: #64748b; padding: 2.5rem 1rem;">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📂</div>
                <div style="font-size: 0.9rem; font-weight: 700; color: #94a3b8;">No ${e==="All"?"":e} leave records found.</div>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">Submit a new request or check other filters.</div>
            </div>
        `;return}n.innerHTML=t.map(a=>{const o=a.status==="Approved",i=a.status==="Rejected",s=o?"#10b981":i?"#ef4444":"#f59e0b",r=o?"rgba(16, 185, 129, 0.12)":i?"rgba(239, 68, 68, 0.12)":"rgba(245, 158, 11, 0.12)",d=o?"rgba(16, 185, 129, 0.35)":i?"rgba(239, 68, 68, 0.35)":"rgba(245, 158, 11, 0.35)",f=o?"APPROVED":i?"REJECTED":"PENDING REVIEW",p=a.allowanceProtected===!0||o&&!!a.medicalBill;return`
            <div style="background: rgba(15, 23, 42, 0.85); border: 1px solid ${d}; border-radius: 16px; padding: 14px 16px; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                <!-- Top Row -->
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem; font-weight: 800; color: #f8fafc;">📅 ${a.date}</span>
                        <span style="background: rgba(56,189,248,0.12); color: #38bdf8; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 6px;">${a.type||"Leave"}</span>
                    </div>
                    <span style="background: ${r}; color: ${s}; border: 1px solid ${d}; font-size: 0.68rem; font-weight: 800; padding: 3px 8px; border-radius: 20px; letter-spacing: 0.5px;">
                        ${f}
                    </span>
                </div>

                <!-- Reason -->
                <div style="font-size: 0.8rem; color: #cbd5e1; line-height: 1.3;">
                    <strong style="color: #94a3b8;">Reason:</strong> ${a.reason||"-"}
                </div>

                <!-- Allowance Protection Banner (Shop & Office Act) -->
                ${p?`
                    <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 6px 10px; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem;">🛡️</span>
                        <div>
                            <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                            <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Validated by HR. No deduction from monthly attendance allowance.</div>
                        </div>
                    </div>
                `:""}

                <!-- Review & Remarks -->
                ${o||i?`
                    <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 8px 10px; border-left: 3px solid ${s}; font-size: 0.72rem; color: #cbd5e1;">
                        <div style="color: ${s}; font-weight: 700;">
                            ${o?"✓ Approved":"✕ Rejected"} by: ${a.processedBy||"Store Management"} ${a.processorRole?`(${a.processorRole})`:""}
                        </div>
                        ${a.remark?`<div style="margin-top: 2px; color: #94a3b8;">Remark: <i style="color:#fff;">"${a.remark}"</i></div>`:""}
                        ${a.processedDate?`<div style="margin-top: 2px; color: #64748b; font-size: 0.65rem;">🕒 ${a.processedDate}</div>`:""}
                    </div>
                `:`
                    <div style="font-size: 0.7rem; color: #f59e0b; font-style: italic;">
                        ⏳ Awaiting HR / Store Manager approval.
                    </div>
                `}

                <!-- Medical Bill / Document Section -->
                <div style="margin-top: 4px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    ${a.medicalBill?`
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <img src="${a.medicalBill}" style="width: 34px; height: 34px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981; cursor: pointer;" onclick="window.viewStaffMedicalBill('${a.docId}')" />
                            <div>
                                <div style="font-size: 0.72rem; color: #10b981; font-weight: 700;">Medical Document Attached ✓</div>
                                <div style="font-size: 0.65rem; color: #94a3b8;">Prescription / Certificate verified</div>
                            </div>
                        </div>
                        <div style="display: flex; gap: 6px;">
                            <button type="button" onclick="window.viewStaffMedicalBill('${a.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: 1px solid rgba(16,185,129,0.4); padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">
                                View
                            </button>
                            <button type="button" onclick="window.triggerStaffBillUpload('${a.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: 1px solid rgba(255,255,255,0.15); padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">
                                Replace
                            </button>
                        </div>
                    `:`
                        <div style="font-size: 0.72rem; color: #64748b;">
                            No medical document attached
                        </div>
                        <button type="button" onclick="window.triggerStaffBillUpload('${a.docId}')" style="background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.5); color: #38bdf8; padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                            <span>📷</span> Upload Medical Bill
                        </button>
                    `}
                </div>
            </div>
        `}).join("")}window.openStaffInboxModal=()=>{document.getElementById("staff-inbox-modal").style.display="flex",window.myStaffMails&&Z(window.myStaffMails)};window.readStaffMailDetail=async e=>{const n=(window.myStaffMails||[]).find(o=>o.docId===e);if(!n)return;if(!n.isRead)try{await N(B(h,"internal_mails",e),{isRead:!0}),n.isRead=!0}catch{}document.getElementById("staff-mail-view-subject").innerText=n.subject||"No Subject",document.getElementById("staff-mail-view-sender").innerText=`${n.senderName||"HR Management"} (${n.senderEmail||"System"})`,document.getElementById("staff-mail-view-date").innerText=n.timestamp?new Date(n.timestamp.seconds*1e3).toLocaleString():"Just now",document.getElementById("staff-mail-view-body").innerText=n.body||"";const t=document.getElementById("staff-mail-view-badge");t&&(n.priority==="urgent"?(t.innerText="🚨 Urgent Notice",t.style.background="rgba(239,68,68,0.2)",t.style.color="#ef4444"):n.priority==="confidential"?(t.innerText="🔒 Confidential",t.style.background="rgba(168,85,247,0.2)",t.style.color="#c084fc"):(t.innerText="✉️ Staff Notice",t.style.background="rgba(56,189,248,0.15)",t.style.color="#38bdf8"));const a=document.getElementById("staff-mail-view-attachment");if(a)if(n.attachment&&n.attachment.url){const o=n.attachment.type&&n.attachment.type.startsWith("image/");let i=`
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${n.attachment.name||"File"}</span>
                        <a href="${n.attachment.url}" download="${n.attachment.name||"download"}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;o&&(i+=`<img src="${n.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`),i+="</div>",a.innerHTML=i,a.style.display="block"}else a.innerHTML="",a.style.display="none";document.getElementById("staff-read-mail-modal").style.display="flex"};function c(e){const n=document.getElementById("toast");n.innerText=e,n.style.display="block",setTimeout(()=>n.style.display="none",3e3)}const ce=(e,n)=>{const t=new Blob([e],{type:"text/plain"}),a=window.URL.createObjectURL(t),o=document.createElement("a");o.href=a,o.download=n,o.click(),window.URL.revokeObjectURL(a)};window.downloadMySlip=()=>{var t;if(!window.lastPaySlip)return c("No salary records found.");const e=window.lastPaySlip,n=`
------------------------------------------
        MEC BOOK SHOP - PAY SLIP       
------------------------------------------
Employee: ${window.currentStaff.name}
Role:     ${window.currentStaff.role}
ID:       ${window.currentStaff.regno||"-"}
------------------------------------------
Month:    ${e.month}
Amount:   LKR ${parseFloat(e.amount).toLocaleString()}
Note:     ${e.note||"Regular Salary"}
Date:     ${e.date||new Date(((t=e.timestamp)==null?void 0:t.seconds)*1e3).toLocaleDateString()}
------------------------------------------
Generated by MEC Staff Portal
    `;ce(n,`payslip_${e.month}.txt`),c("📥 Payslip downloaded!")};window.viewMyAttendance=()=>{if(!window.myAttendanceRecords||window.myAttendanceRecords.length===0)return c("No attendance records found.");const e=window.currentStaff,n=[...window.myAttendanceRecords].sort((o,i)=>i.date.localeCompare(o.date)),t=`
        <html>
        <head>
            <title>Attendance Report - ${e.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${e.name}<br>
                    <strong>Role:</strong> ${e.role}<br>
                    <strong>Employee ID:</strong> ${e.regno||"-"}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${n.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>In Time</th>
                        <th>Out Time</th>
                        <th>Worked</th>
                        <th>OT</th>
                        <th>Status</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${n.map(o=>{const i=o.inTime||o.time||"--:--",s=o.outTime||"--:--",r=o.workedDuration||(o.inTime&&!o.outTime?"⏱️ In Shift":"--"),d=o.otMinutes??(o.otHours?Math.round(o.otHours*60):0),f=d>0?`+${d} mins`:"-";return`
                        <tr>
                            <td>${o.date}</td>
                            <td style="font-weight:bold; color:#0284c7;">${i}</td>
                            <td style="font-weight:bold; color:#d97706;">${s}</td>
                            <td style="font-weight:600;">${r}</td>
                            <td style="font-weight:bold; color:#059669;">${f}</td>
                            <td class="status-${(o.status||"").toLowerCase().replace(" ","")}">${o.status}</td>
                            <td style="font-size:0.8rem; color:#64748b;">${o.note||"-"}</td>
                        </tr>
                        `}).join("")}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            <\/script>
        </body>
        </html>
    `,a=window.open("","_blank");a.document.write(t),a.document.close(),c("📅 Generating PDF Report...")};window.openLeaveModal=()=>{document.getElementById("leave-modal").style.display="flex",document.getElementById("leave-date").value=new Date().toISOString().split("T")[0]};window.submitLeaveRequest=async()=>{var m,g;const e=document.getElementById("leave-date"),n=document.getElementById("leave-type"),t=document.getElementById("leave-reason"),a=e?e.value:"",o=n?n.value:"Half Day",i=t?t.value.trim():"";if(!a||!i)return c("⚠️ Please fill all fields (Date & Reason).");let s=window.currentStaff;if(!s)try{s=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{s={}}const r=s.docId||s.regno||s.id||"EMP-UNKNOWN",d=s.name||((m=document.getElementById("disp-name"))==null?void 0:m.innerText)||"Staff Member",f=s.role||((g=document.getElementById("disp-role"))==null?void 0:g.innerText)||"Staff",p=s.storeId||"mec-book-shop",l=document.querySelector("#leave-modal button.btn-login:last-child");l&&(l.disabled=!0,l.innerText="Submitting...");try{await G(P(h,"leave_requests"),{empId:r,empName:d,empRole:f,empPhone:s.phone||"",date:a,type:o,reason:i,status:"Pending",storeId:p,timestamp:H()}),c("✅ Leave request submitted successfully!");const w=document.getElementById("leave-modal");w&&(w.style.display="none"),t&&(t.value="")}catch(w){console.error("Leave request error:",w),c(`❌ Error: ${w.message||"Failed to submit request"}`)}finally{l&&(l.disabled=!1,l.innerText="Submit Request")}};let L=null,V="environment",k=null,C=null,te=null;async function oe(e,n,t){var s;const a=parseFloat(n),o=parseFloat(t),i=e||((s=window.currentStaff)==null?void 0:s.storeId)||"mec-book-shop";try{await J(B(h,"config",i),{storeLatitude:a,storeLongitude:o},{merge:!0})}catch(r){console.warn("Set config storeId error, attempting fallback:",r);try{await N(B(h,"config",i),{storeLatitude:a,storeLongitude:o})}catch(d){console.error("Config update error:",d)}}try{await J(B(h,"system","config"),{storeLatitude:a,storeLongitude:o},{merge:!0})}catch{}try{const r=localStorage.getItem(`mecpos_system_config_${i}`);if(r){const d=JSON.parse(r);d.storeLatitude=a,d.storeLongitude=o,localStorage.setItem(`mecpos_system_config_${i}`,JSON.stringify(d))}}catch{}}function F(e){const n=document.getElementById("staff-shift-status-pill");if(!n)return;if(!e||!e.inTime&&!e.time){n.innerHTML="⚪ <b>Not Clocked In Today</b> — Tap above to Clock In",n.style.background="rgba(255,255,255,0.04)",n.style.border="1px solid rgba(255,255,255,0.08)",n.style.color="#94a3b8";return}const t=e.inTime||e.time;if(!e.outTime){n.innerHTML=`🟢 <b>In Shift</b> (Clocked In: <b>${t}</b>)<br><span style="font-size:0.7rem; opacity:0.85;">Tap above to Clock-Out (15m Cooldown | 4h HD | 8h+ OT)</span>`,n.style.background="rgba(16, 185, 129, 0.12)",n.style.border="1px solid rgba(16, 185, 129, 0.4)",n.style.color="#10b981";return}const a=e.outTime,o=e.workedDuration||(e.workedMinutes?`${Math.floor(e.workedMinutes/60)}h ${e.workedMinutes%60}m`:"-"),i=e.otMinutes??(e.otHours?Math.round(e.otHours*60):0),s=i>0?`+${i} mins`:null;if(e.status==="Day Off")n.innerHTML=`🟣 <b>Day Off Recorded</b> (${o})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}</span>`,n.style.background="rgba(168, 85, 247, 0.12)",n.style.border="1px solid rgba(168, 85, 247, 0.35)",n.style.color="#c084fc";else if(e.status==="Half Day")n.innerHTML=`🟡 <b>Half Day Recorded</b> (${o})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}</span>`,n.style.background="rgba(245, 158, 11, 0.12)",n.style.border="1px solid rgba(245, 158, 11, 0.35)",n.style.color="#f59e0b";else{const r=s?` | <span style="color:#fde047; font-weight:800;">⚡ OT: ${s}</span>`:"";n.innerHTML=`🟢 <b>Shift Completed</b> (${o})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}${r}</span>`,n.style.background="rgba(16, 185, 129, 0.15)",n.style.border="1px solid rgba(16, 185, 129, 0.4)",n.style.color="#34d399"}}window.updateStaffPortalShiftStatus=F;async function W(e=0,n=!1){let t=window.currentStaff;if(!t)try{t=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{t={}}if(!t||!t.docId&&!t.regno)throw new Error("Staff session not found. Please log in again.");const a=t.docId||t.regno||"EMP-UNKNOWN",o=t.name||"Staff Member",i=t.storeId||"mec-book-shop",s=new Date,r=s.toLocaleDateString("sv-SE"),d=s.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit"}),f=s.getTime();let p=(window.myAttendanceRecords||[]).find(u=>(u.empId===a||u.empId===t.regno)&&u.date===r);if(!p)try{const u=A(P(h,"attendance"),M("empId","==",a),M("date","==",r)),S=await z(u);S.empty||(p={docId:S.docs[0].id,...S.docs[0].data()})}catch(u){console.warn("Error querying existing attendance:",u)}const l=n?`GPS Calibrated to Store (${(k==null?void 0:k.toFixed(5))||0}, ${(C==null?void 0:C.toFixed(5))||0})`:`GPS+QR Verified (Distance: ${Number(e).toFixed(1)}m)`;if(!p||!p.inTime&&!p.time){const u={empId:a,empName:o,role:t.role||"Staff",date:r,inTime:d,time:d,inTimestamp:f,outTime:null,outTimestamp:null,workedMinutes:0,workedDuration:"",otHours:0,otMinutes:0,otDuration:"",status:"Present",note:`${l} | Shift Started`,storeId:i,timestamp:H()},S=await G(P(h,"attendance"),u);return c(`✅ Clocked In at ${d}! Have a great shift.`),F({...u,docId:S.id}),{type:"IN",record:{...u,docId:S.id}}}if(p.outTime)return c(`ℹ️ Shift already ended today (In: ${p.inTime}, Out: ${p.outTime} | Status: ${p.status}).`),{type:"ALREADY_COMPLETED",record:p};let m=p.inTimestamp;if(!m&&(p.inTime||p.time)){const u=p.inTime||p.time;if(u.includes(":")){const S=u.split(":").map(Number),D=new Date;D.setHours(S[0]||0,S[1]||0,0,0),m=D.getTime()}}m||(m=f);const g=Math.max(0,Math.floor((f-m)/6e4));if(g<15){const u=15-g;return c(`⚠️ Cooldown Active: Clocked in at ${p.inTime||p.time}. Minimum 15 mins required before Clock-Out (${u} mins left).`),{type:"COOLDOWN_BLOCKED",remainingMins:u}}const w=Math.floor(g/60),y=g%60,b=w>0?`${w} hrs ${y} mins`:`${y} mins`;let x="Present",v=0,I=0,$="0 mins",E="";g<240?(x="Day Off",v=0,I=0,$="0 mins",E=`Punched out after ${b} (< 4 hrs) — Recorded as Day Off`):g<480?(x="Half Day",v=0,I=0,$="0 mins",E=`Punched out after ${b} — Recorded as Half Day`):(x="Present",g>480?(I=g-480,v=+(I/60).toFixed(2),$=`${I} mins`,E=`Shift Completed (${b}) — Full Day + ${I} mins OT`):(v=0,I=0,$="0 mins",E="Shift Completed (8 hrs) — Full Day (0 OT)"));const T={outTime:d,outTimestamp:f,workedMinutes:g,workedDuration:b,otHours:v,otMinutes:I,otDuration:$,status:x,note:`${l} | ${E}`,updatedAt:H()};if(p.docId)await N(B(h,"attendance",p.docId),T);else{const u=A(P(h,"attendance"),M("empId","==",a),M("date","==",r)),S=await z(u);S.empty?await G(P(h,"attendance"),{empId:a,empName:o,role:t.role||"Staff",date:r,inTime:p.inTime||d,time:p.time||d,storeId:i,...T}):await N(B(h,"attendance",S.docs[0].id),T)}F({...p,...T});let R=`✅ Clocked Out at ${d} (${b})! Status: ${x}`;return v>0&&(R+=` | ⚡ OT: +${$}`),c(R),{type:"OUT",status:x,workedDuration:b,otDuration:$}}window.processStaffAttendancePunch=W;window.calibrateStoreGPSFromPhone=async()=>{const e=prompt(`🔒 Admin Verification Required:
Enter Master Admin Security PIN or CEO Password to calibrate Shop GPS:`);if(!e)return;if(!["9556","1234","admin","mecpos","mec123","malindu123","mecpos123"].includes(e.trim().toLowerCase()))return c("❌ Access Denied: Invalid Admin Security PIN or Password!");if(!navigator.geolocation)return c("GPS Geolocation not supported on this device.");c("📍 Acquiring high-accuracy live GPS coordinates..."),navigator.geolocation.getCurrentPosition(async t=>{var r;const a=t.coords.latitude,o=t.coords.longitude,i=t.coords.accuracy?` (±${Math.round(t.coords.accuracy)}m)`:"",s=`Set current phone location as official Shop GPS?

📍 Latitude: ${a.toFixed(6)}
📍 Longitude: ${o.toFixed(6)}${i}

All employee clock-in scans will be verified against this exact store location.`;if(confirm(s))try{const d=((r=window.currentStaff)==null?void 0:r.storeId)||"mec-book-shop";await oe(d,a,o),c("✅ Store GPS coordinates successfully updated!")}catch(d){c("❌ Failed to update GPS coordinates: "+d.message)}},t=>{console.error("GPS Error:",t),c("❌ Unable to acquire GPS location. Please ensure Location is enabled.")},{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})};window.confirmCalibrateStoreGPS=async()=>{var a;const e=prompt(`🔒 Admin Security Check:
Enter Master Admin PIN to confirm Store GPS override:`);if(!e)return;if(!["9556","1234","admin","mecpos","mec123","malindu123","mecpos123"].includes(e.trim().toLowerCase()))return c("❌ Access Denied: Invalid Security PIN!");const t=document.getElementById("btn-calibrate-gps");t&&(t.disabled=!0,t.innerText="⏳ Saving Store GPS...");try{if(!k||!C)throw new Error("Phone GPS coordinates not found. Please re-scan.");const o=te||((a=window.currentStaff)==null?void 0:a.storeId)||"mec-book-shop";await oe(o,k,C),document.getElementById("gps-mismatch-modal").style.display="none",c("📍 Shop GPS calibrated! Recording attendance..."),await W(0,!0)}catch(o){console.error("Calibration error:",o),c(`❌ Error: ${o.message||"Failed to calibrate"}`)}finally{t&&(t.disabled=!1,t.innerText="📍 Set Shop GPS to My Phone & Clock-In")}};window.startAttendanceClock=()=>{if(!navigator.geolocation)return c("GPS Geolocation not supported on this device.");c("📍 Accessing live GPS coordinates..."),navigator.geolocation.getCurrentPosition(e=>{k=e.coords.latitude,C=e.coords.longitude,e.coords.accuracy&&e.coords.accuracy>300&&(console.warn("Low GPS accuracy:",e.coords.accuracy),c(`⚠️ Low GPS signal accuracy (±${Math.round(e.coords.accuracy)}m). Please turn on High Accuracy Location.`)),document.getElementById("scanner-modal").style.display="flex",L||(L=new Html5Qrcode("scanner-reader")),ne()},e=>{console.error("GPS Error:",e),c("❌ Unable to verify live location. Please turn on Location / GPS on your phone.")},{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})};const ne=()=>{const e={fps:20,qrbox:(n,t)=>({width:Math.floor(n*.7),height:Math.floor(t*.7)})};L.start({facingMode:V},e,pe).catch(n=>{console.error("Camera access error:",n),c("Cannot open camera. Check permissions.")})};window.toggleCamera=()=>{V=V==="environment"?"user":"environment",L&&L.isScanning&&L.stop().then(()=>ne())};window.closeScanner=()=>{L&&L.isScanning?L.stop().then(()=>{document.getElementById("scanner-modal").style.display="none"}):document.getElementById("scanner-modal").style.display="none"};const pe=async e=>{var w;const n=e.trim();if(!n.startsWith("MEC-POS-ATTENDANCE-QR:")){c("⚠️ Invalid QR Code. Scan the Shop QR Code.");return}window.closeScanner(),c("🔄 Verifying physical presence...");const t=n.split(":"),a=t[1]||((w=window.currentStaff)==null?void 0:w.storeId)||"mec-book-shop";let o=parseFloat(t[2]),i=parseFloat(t[3]);try{const y=await se(B(h,"config",a));if(y.exists()){const b=y.data();b.storeLatitude&&b.storeLongitude&&(o=parseFloat(b.storeLatitude),i=parseFloat(b.storeLongitude))}}catch(y){console.warn("Could not fetch remote store config:",y)}const s=6371e3,r=k*Math.PI/180,d=o*Math.PI/180,f=(o-k)*Math.PI/180,p=(i-C)*Math.PI/180,l=Math.sin(f/2)*Math.sin(f/2)+Math.cos(r)*Math.cos(d)*Math.sin(p/2)*Math.sin(p/2),m=2*Math.atan2(Math.sqrt(l),Math.sqrt(1-l)),g=s*m;if(g>150){te=a;const y=g>=1e3?`${(g/1e3).toFixed(1)} km`:`${g.toFixed(1)} m`,b=document.getElementById("mismatch-distance");b&&(b.innerText=y);const x=document.getElementById("mismatch-my-coords");x&&(x.innerText=`${k.toFixed(5)}, ${C.toFixed(5)}`);const v=document.getElementById("mismatch-qr-coords");v&&(v.innerText=`${o.toFixed(5)}, ${i.toFixed(5)}`);const I=document.getElementById("gps-mismatch-modal");I&&(I.style.display="flex");return}try{await W(g,!1)}catch(y){console.error(y),c("Error logging attendance to database: "+(y.message||""))}};
