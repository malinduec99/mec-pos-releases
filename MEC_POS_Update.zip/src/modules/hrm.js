import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot, 
    query, 
    orderBy, 
    doc, 
    updateDoc, 
    serverTimestamp,
    deleteDoc,
    where,
    getDocs
} from "firebase/firestore";

const leaveRequestsCol = collection(db, 'leave_requests');

export function initHRM() {
    let initialLoad = true;
    
    // RBAC: Check if user can see Leave Requests
    const currentRole = sessionStorage.getItem('userRole') || 'None';
    const canManageLeaves = ['SuperAdmin', 'CEO_Admin', 'Admin', 'HR_Manager', 'IT_Manager', 'Finance_Manager', 'Branch_Manager'].includes(currentRole);
    
    const leaveBtn = document.getElementById('hrm-btn-leaves');
    if (leaveBtn) {
        leaveBtn.style.display = canManageLeaves ? 'block' : 'none';
    }

    // Listen for leave requests
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';
    
    let qLeaves;
    if (isMaster) {
        qLeaves = leaveRequestsCol;
    } else {
        // Query only by storeId (eliminates Firestore composite index requirement)
        qLeaves = query(leaveRequestsCol, where('storeId', '==', storeId));
    }

    onSnapshot(qLeaves, (snapshot) => {
        const leaves = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        // Client-side sort by timestamp descending
        leaves.sort((a, b) => {
            const timeA = a.timestamp?.seconds ? a.timestamp.seconds * 1000 : (new Date(a.timestamp || 0).getTime() || 0);
            const timeB = b.timestamp?.seconds ? b.timestamp.seconds * 1000 : (new Date(b.timestamp || 0).getTime() || 0);
            return timeB - timeA;
        });
        window.allLeaveRequests = leaves;
        
        renderLeavesUI(leaves);
        updateLeaveBadge(leaves);
        
        // Sound notification for new requests (not on initial load)
        if (!initialLoad) {
            const hasNew = snapshot.docChanges().some(change => change.type === 'added');
            if (hasNew) {
                playNotifSound();
                window.showToast("🏠 New Leave Request Received!", "info");
            }
        }
        initialLoad = false;
    }, (err) => {
        console.warn("Leave requests snapshot error:", err.message);
    });
}

function renderLeavesUI(leaves) {
    const tbody = document.getElementById('hrm-leave-list-body');
    if (!tbody) return;
    
    if (leaves.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding: 3rem; opacity: 0.5;">No leave requests found.</td></tr>`;
        return;
    }
    
    tbody.innerHTML = leaves.map(req => {
        const dateSubmitted = req.timestamp ? new Date(req.timestamp.seconds * 1000).toLocaleString() : 'Just now';
        const statusClass = `status-${(req.status || 'pending').toLowerCase()}`;

        let decisionRemarkHtml = `<span style="color: #64748b; font-size: 0.75rem; font-style: italic;">⏳ Awaiting Review</span>`;

        if (req.status === 'Approved') {
            const isAllowanceProtected = req.allowanceProtected === true || (req.medicalBill && (req.type || '').toLowerCase().includes('medical'));
            decisionRemarkHtml = `
                <div>
                    <div style="font-size: 0.78rem; color: #10b981; font-weight: 800; display: flex; align-items: center; gap: 4px;">
                        <span>🟢</span> Approved by ${req.processedBy || 'Manager'} ${req.processorRole ? `<span style="font-size: 0.68rem; color: #94a3b8; font-weight: normal;">(${req.processorRole})</span>` : ''}
                    </div>
                    ${isAllowanceProtected ? `
                        <div style="margin-top: 4px; display: inline-flex; align-items: center; gap: 4px; background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 6px; padding: 2px 7px; font-size: 0.68rem; font-weight: 800;">
                            <span>🛡️</span> Allowance Protected (Shop & Office Act)
                        </div>
                    ` : ''}
                    ${req.remark ? `<div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 3px; background: rgba(16, 185, 129, 0.08); padding: 4px 8px; border-radius: 6px; border-left: 2px solid #10b981; word-break: break-word;">📝 ${req.remark}</div>` : ''}
                    ${req.processedDate ? `<div style="font-size: 0.68rem; color: #64748b; margin-top: 2px;">🕒 ${req.processedDate}</div>` : ''}
                </div>
            `;
        } else if (req.status === 'Rejected') {
            decisionRemarkHtml = `
                <div>
                    <div style="font-size: 0.78rem; color: #ef4444; font-weight: 800; display: flex; align-items: center; gap: 4px;">
                        <span>🔴</span> Rejected by ${req.processedBy || 'Manager'} ${req.processorRole ? `<span style="font-size: 0.68rem; color: #94a3b8; font-weight: normal;">(${req.processorRole})</span>` : ''}
                    </div>
                    ${req.remark ? `<div style="font-size: 0.75rem; color: #fca5a5; margin-top: 3px; background: rgba(239, 68, 68, 0.08); padding: 4px 8px; border-radius: 6px; border-left: 2px solid #ef4444; word-break: break-word;">📝 ${req.remark}</div>` : ''}
                    ${req.processedDate ? `<div style="font-size: 0.68rem; color: #64748b; margin-top: 2px;">🕒 ${req.processedDate}</div>` : ''}
                </div>
            `;
        }

        const hasDoc = !!req.medicalBill;
        
        return `
            <tr>
                <td style="font-size: 0.75rem; color: #94a3b8;">${dateSubmitted}</td>
                <td>
                    <div style="font-weight: 700; color: #f8fafc;">${req.empName || 'Unknown'}</div>
                    <div style="font-size: 0.7rem; color: #64748b;">ID: ${req.empId || '-'}</div>
                </td>
                <td style="font-weight: 700; color: #38bdf8;">${req.date}</td>
                <td><span style="padding: 4px 10px; background: rgba(56, 189, 248, 0.1); color: #38bdf8; border-radius: 50px; font-size: 0.75rem; font-weight: 700;">${req.type || 'Full Day'}</span></td>
                <td style="max-width: 170px; white-space: normal; font-size: 0.85rem; color: #cbd5e1; word-break: break-word;">
                    ${req.reason || '-'}
                </td>
                <td style="min-width: 150px;">
                    ${hasDoc ? `
                        <div style="display: flex; flex-direction: column; gap: 4px; align-items: flex-start;">
                            <button onclick="window.viewLeaveMedicalBill('${req.docId}')" class="action-btn" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.25)); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.45); padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(16, 185, 129, 0.2);" title="Click to view attached medical bill">
                                <span>🩺</span> View Document
                            </button>
                            <div style="font-size: 0.68rem; color: #94a3b8; display: flex; align-items: center; gap: 4px;">
                                <span>📎</span> ${req.medicalBillBy ? `By: <b>${req.medicalBillBy}</b>` : 'Attached'}
                                <button onclick="window.openLeaveDocUploadModal('${req.docId}')" style="background:none; border:none; color:#38bdf8; font-size:0.68rem; text-decoration:underline; cursor:pointer; padding:0 2px;" title="Upload a different document or replace">Replace</button>
                            </div>
                        </div>
                    ` : `
                        <div style="display: flex; flex-direction: column; gap: 4px; align-items: flex-start;">
                            <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.68rem; color: #94a3b8; background: rgba(255, 255, 255, 0.05); padding: 2px 7px; border-radius: 6px; border: 1px dashed rgba(255, 255, 255, 0.15);">
                                <span>⚠️</span> No Document
                            </span>
                            <button onclick="window.openLeaveDocUploadModal('${req.docId}')" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.4); padding: 5px 11px; border-radius: 8px; font-size: 0.73rem; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 5px;" title="Upload medical bill or certificate">
                                <span>📤</span> Upload Doc
                            </button>
                        </div>
                    `}
                </td>
                <td>
                    <span class="badge ${statusClass}" style="text-transform: uppercase; font-size: 0.65rem; letter-spacing: 1px;">${req.status || 'Pending'}</span>
                </td>
                <td style="min-width: 200px; max-width: 260px;">
                    ${decisionRemarkHtml}
                </td>
                <td style="text-align: right; min-width: 170px;">
                    <div style="display: flex; gap: 8px; justify-content: flex-end; align-items: center; flex-wrap: wrap;">
                        ${req.status === 'Pending' ? `
                            <button onclick="window.openLeaveApprovalModal('${req.docId}', 'Approved')" class="action-btn" style="background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 6px 14px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(16,185,129,0.3); display: inline-flex; align-items: center; gap: 4px;"><span>✓</span> Approve</button>
                            <button onclick="window.openLeaveApprovalModal('${req.docId}', 'Rejected')" class="action-btn" style="background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 6px 14px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(239,68,68,0.3); display: inline-flex; align-items: center; gap: 4px;"><span>✕</span> Reject</button>
                        ` : `
                            ${hasDoc ? `
                                <button onclick="window.viewLeaveMedicalBill('${req.docId}')" class="action-btn" style="background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.35); padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px;" title="View Attached Medical Bill">
                                    <span>👁️</span> View
                                </button>
                            ` : `
                                <button onclick="window.openLeaveDocUploadModal('${req.docId}')" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.4); padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px;" title="Upload Medical Document">
                                    <span>📤</span> Upload
                                </button>
                            `}
                            <button onclick="window.deleteLeaveRequest('${req.docId}')" class="action-btn" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.35); padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 5px;" title="Delete Record">
                                <span>🗑️</span> Delete
                            </button>
                        `}
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function updateLeaveBadge(leaves) {
    const badge = document.getElementById('hrm-leave-badge');
    if (!badge) return;
    
    const pendingCount = leaves.filter(l => l.status === 'Pending').length;
    if (pendingCount > 0) {
        badge.innerText = pendingCount;
        badge.style.display = 'block';
    } else {
        badge.style.display = 'none';
    }
}

window.currentLeaveApproval = null;

window.viewLeaveApprovalDoc = () => {
    if (window.currentLeaveApproval && window.currentLeaveApproval.docId) {
        window.viewLeaveMedicalBill(window.currentLeaveApproval.docId);
    }
};

window.openLeaveApprovalModal = (docId, action) => {
    const leaves = window.allLeaveRequests || [];
    const req = leaves.find(l => l.docId === docId);
    if (!req) return window.showToast?.("Leave request not found.", "error");

    window.currentLeaveApproval = { docId, action, req };

    const modal = document.getElementById('leave-approval-modal');
    if (!modal) return;

    const titleEl = document.getElementById('leave-approval-title');
    const empNameEl = document.getElementById('leave-modal-emp-name');
    const dateEl = document.getElementById('leave-modal-date');
    const typeEl = document.getElementById('leave-modal-type');
    const actionBadgeEl = document.getElementById('leave-modal-action-badge');
    const reasonEl = document.getElementById('leave-modal-reason');
    const passInput = document.getElementById('leave-approval-pass');
    const remarkInput = document.getElementById('leave-approval-remark');
    const submitBtn = document.getElementById('leave-approval-submit-btn');
    const docBox = document.getElementById('leave-modal-doc-preview-box');
    const protectCheck = document.getElementById('leave-protect-allowance-check');
    const protectBox = document.getElementById('leave-allowance-protection-box');

    if (titleEl) {
        titleEl.innerHTML = action === 'Approved' ? '<span>✅</span> Approve Leave Request' : '<span>❌</span> Reject Leave Request';
        titleEl.style.color = action === 'Approved' ? '#10b981' : '#ef4444';
    }
    if (empNameEl) empNameEl.textContent = `${req.empName || 'Unknown'} (ID: ${req.empId || '-'})`;
    if (dateEl) dateEl.textContent = req.date || '--';
    if (typeEl) typeEl.textContent = req.type || 'Full Day';
    if (actionBadgeEl) {
        actionBadgeEl.innerHTML = action === 'Approved'
            ? `<span style="background:rgba(16,185,129,0.18); color:#10b981; font-weight:800; padding:3px 8px; border-radius:6px; font-size:0.8rem; border:1px solid rgba(16,185,129,0.3);">🟢 APPROVE</span>`
            : `<span style="background:rgba(239,68,68,0.18); color:#ef4444; font-weight:800; padding:3px 8px; border-radius:6px; font-size:0.8rem; border:1px solid rgba(239,68,68,0.3);">🔴 REJECT</span>`;
    }
    if (reasonEl) reasonEl.textContent = req.reason || 'No reason provided';
    if (passInput) passInput.value = '';
    if (remarkInput) {
        remarkInput.value = '';
        remarkInput.placeholder = action === 'Approved'
            ? 'e.g. Approved - Medical report checked / Approved by Manager'
            : 'e.g. Rejected - Shortage of staff on requested date';
    }

    // Configure document preview & allowance protection
    const hasDoc = !!req.medicalBill;
    const isMedical = (req.type || '').toLowerCase().includes('medical');

    if (docBox) {
        docBox.style.display = hasDoc ? 'flex' : 'none';
    }

    if (protectBox) {
        protectBox.style.display = action === 'Approved' ? 'block' : 'none';
    }

    if (protectCheck) {
        // Pre-check if medical bill is provided or leave is medical
        protectCheck.checked = hasDoc || isMedical;
    }

    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.background = action === 'Approved'
            ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
            : 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
        submitBtn.style.color = '#ffffff';
        submitBtn.innerHTML = action === 'Approved' ? `<span>🛡️</span> Verify & Approve Leave` : `<span>🛡️</span> Verify & Reject Leave`;
    }

    modal.style.display = 'flex';
    setTimeout(() => passInput?.focus(), 50);
};

window.closeLeaveApprovalModal = () => {
    const modal = document.getElementById('leave-approval-modal');
    if (modal) modal.style.display = 'none';
    const passInput = document.getElementById('leave-approval-pass');
    const remarkInput = document.getElementById('leave-approval-remark');
    if (passInput) passInput.value = '';
    if (remarkInput) remarkInput.value = '';
    window.currentLeaveApproval = null;
};

window.submitLeaveApprovalDecision = async () => {
    const ctx = window.currentLeaveApproval;
    if (!ctx) return;

    const passInput = document.getElementById('leave-approval-pass');
    const remarkInput = document.getElementById('leave-approval-remark');
    const enteredPass = (passInput?.value || '').trim();
    const enteredRemark = (remarkInput?.value || '').trim();

    if (!enteredPass) {
        passInput?.focus();
        return window.showToast?.("🔑 Please enter your Manager / CEO / Admin password or PIN.", "warning");
    }

    if (!enteredRemark) {
        remarkInput?.focus();
        return window.showToast?.("📝 Please provide a decision remark / reason.", "warning");
    }

    const submitBtn = document.getElementById('leave-approval-submit-btn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span>⏳</span> Verifying...`;
    }

    try {
        let authorizerName = null;
        let authorizerRole = null;

        // 1. Master / Super Admin credentials
        if (enteredPass === 'malindu123' || enteredPass === 'mecpos123') {
            authorizerName = 'Malindu Shamesh';
            authorizerRole = 'Super Admin';
        }
        // 2. MEC CEO credentials
        else if (enteredPass === 'mec123') {
            authorizerName = 'CEO / Founder';
            authorizerRole = 'CEO';
        }
        // 3. Match against employee database
        else {
            const employees = window.allEmployees || [];
            const matchedStaff = employees.find(e => {
                const pin = (e.pin || '').toString().trim();
                const pass = (e.password || '').toString().trim();
                return (pin && pin === enteredPass) || (pass && pass === enteredPass);
            });

            if (matchedStaff) {
                const r = (matchedStaff.role || '').toLowerCase();
                const des = (matchedStaff.designation || '').toLowerCase();
                const acc = (matchedStaff.role_access || '').toLowerCase();

                const isCeo = r.includes('ceo') || des.includes('ceo') || r.includes('founder') || des.includes('founder') || r.includes('owner') || des.includes('owner') || r.includes('proprietor') || des.includes('proprietor');
                const isHr = r.includes('hr') || des.includes('hr') || r.includes('human resource') || des.includes('human resource') || acc.includes('hr');
                const isAdmin = r.includes('admin') || des.includes('admin') || acc.includes('admin');
                const isManager = r.includes('manager') || des.includes('manager') || acc.includes('manager');

                if (isCeo || isHr || isAdmin || isManager) {
                    authorizerName = matchedStaff.name || matchedStaff.fullName || 'Authorized Staff';
                    authorizerRole = isCeo ? 'CEO' : (isHr ? 'HR Manager' : (isManager ? 'Manager' : (matchedStaff.role || 'Admin')));
                } else {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = `<span>🛡️</span> Confirm Decision`;
                    }
                    return window.showToast?.(`🔒 Permission Denied: Staff "${matchedStaff.name}" (${matchedStaff.role}) is not authorized to approve or reject leaves. Manager, HR, CEO, or Admin credentials required.`, "error");
                }
            }
        }

        // 4. Active store owner credentials
        if (!authorizerName && window.storeInfo) {
            const storeOwnerPass = window.storeInfo.adminPassword || window.storeInfo.password;
            if (storeOwnerPass && storeOwnerPass.trim() === enteredPass) {
                authorizerName = window.storeInfo.ownerName || window.storeInfo.name || 'Store Owner';
                authorizerRole = 'CEO / Owner';
            }
        }

        if (!authorizerName) {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = `<span>🛡️</span> Confirm Decision`;
            }
            return window.showToast?.("❌ Authentication Failed: Invalid Password or PIN. Authorization requires Manager, CEO, HR, or Admin credentials.", "error");
        }

        const protectAllowance = (ctx.action === 'Approved') && (document.getElementById('leave-protect-allowance-check')?.checked ?? false);

        // Update Firestore
        const nowStr = new Date().toLocaleString();
        await updateDoc(doc(db, 'leave_requests', ctx.docId), {
            status: ctx.action,
            processedAt: serverTimestamp(),
            processedBy: authorizerName,
            processorRole: authorizerRole,
            remark: enteredRemark,
            processedDate: nowStr,
            allowanceProtected: protectAllowance
        });

        window.closeLeaveApprovalModal();
        window.showToast?.(`✅ Leave Request ${ctx.action.toLowerCase()} by ${authorizerName} (${authorizerRole})!`, "success");
    } catch (err) {
        console.error("Error updating leave request:", err);
        window.showToast?.("Error updating leave request.", "error");
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<span>🛡️</span> Confirm Decision`;
        }
    }
};

window.updateLeaveStatus = async (id, status) => {
    window.openLeaveApprovalModal(id, status);
};

window.deleteLeaveRequest = async (id) => {
    const docRef = doc(db, 'leave_requests', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    try {
        await deleteDoc(docRef);
        window.showToast("🗑️ Record deleted.", "info");
    } catch (err) {
        window.showToast("Error deleting record.", "error");
    }
};

window.clearApprovedLeaves = async () => {
    if (!await window.verifyDeletePermission()) return;
    try {
        const q = query(leaveRequestsCol, where('status', '!=', 'Pending'));
        const snap = await getDocs(q);
        
        if (snap.empty) return window.showToast("No history to clear.", "info");
        
        const promises = snap.docs.map(d => deleteDoc(d.ref));
        await Promise.all(promises);
        
        window.showToast("🧹 History cleared successfully!", "success");
    } catch (err) {
        window.showToast("Error clearing history.", "error");
    }
};

window.viewLeaveMedicalBill = (docId) => {
    const leaves = window.allLeaveRequests || [];
    const req = leaves.find(l => l.docId === docId);
    if (!req || !req.medicalBill) return window.showToast?.("No medical bill attached to this request.", "warning");

    let modal = document.getElementById('leave-medical-bill-viewer-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'leave-medical-bill-viewer-modal';
        modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.88); backdrop-filter:blur(8px); display:flex; align-items:center; justify-content:center; padding:20px;';
        modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };
        document.body.appendChild(modal);
    }

    const isPdf = typeof req.medicalBill === 'string' && (req.medicalBill.startsWith('data:application/pdf') || (req.medicalBillFileName && req.medicalBillFileName.endsWith('.pdf')));

    modal.innerHTML = `
        <div style="background:#0f172a; border:1px solid rgba(56,189,248,0.35); border-radius:18px; max-width:720px; width:100%; max-height:92vh; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 25px 60px rgba(0,0,0,0.85);">
            <div style="padding:14px 20px; border-bottom:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center; background: rgba(15, 23, 42, 0.95);">
                <div style="font-weight:800; color:#f8fafc; font-size:1.05rem; display:flex; align-items:center; gap:8px;">
                    <span>🩺</span> Medical Document — ${req.empName || 'Employee'} (${req.date || ''})
                </div>
                <button onclick="document.getElementById('leave-medical-bill-viewer-modal').style.display='none'" style="background:transparent; border:none; color:#94a3b8; font-size:1.6rem; cursor:pointer; line-height:1;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
            </div>
            
            <div style="padding:16px; overflow:auto; text-align:center; background:#020617; flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center;">
                ${isPdf ? `
                    <iframe src="${req.medicalBill}" style="width:100%; height:65vh; border:none; border-radius:8px;"></iframe>
                ` : `
                    <img src="${req.medicalBill}" style="max-width:100%; max-height:65vh; border-radius:10px; object-fit:contain; box-shadow:0 10px 30px rgba(0,0,0,0.6); cursor:zoom-in;" onclick="window.open('${req.medicalBill}', '_blank')" title="Click to view full image in new tab" alt="Medical Document" />
                `}
                ${req.medicalBillNote ? `
                    <div style="margin-top:12px; font-size:0.8rem; color:#cbd5e1; background:rgba(56,189,248,0.1); border:1px solid rgba(56,189,248,0.25); border-radius:8px; padding:6px 14px; text-align:left; max-width:90%;">
                        📝 <b>Doctor Note:</b> ${req.medicalBillNote}
                    </div>
                ` : ''}
            </div>

            <div style="padding:14px 20px; border-top:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center; background:rgba(15, 23, 42, 0.95); flex-wrap:wrap; gap:10px;">
                <div style="display:flex; align-items:center; gap:10px; font-size:0.75rem; color:#94a3b8;">
                    <span>Uploaded by: <b style="color:#f8fafc;">${req.medicalBillBy || req.empName || 'Staff'}</b> ${req.medicalBillUploadedAt ? `(${req.medicalBillUploadedAt})` : ''}</span>
                    ${req.allowanceProtected ? `<span style="background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); border-radius:4px; padding:2px 7px; font-weight:800;">🛡️ Allowance Protected</span>` : ''}
                </div>
                <div style="display:flex; gap:8px; align-items:center;">
                    <a href="${req.medicalBill}" download="Medical_Doc_${(req.empName || 'Employee').replace(/\s+/g, '_')}_${req.date || ''}.jpg" style="background:rgba(56,189,248,0.15); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); padding:6px 14px; border-radius:8px; font-size:0.75rem; font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:5px;">
                        <span>📥</span> Download
                    </a>
                    <button onclick="document.getElementById('leave-medical-bill-viewer-modal').style.display='none'; window.openLeaveDocUploadModal('${req.docId}');" style="background:rgba(255,255,255,0.1); color:#f8fafc; border:1px solid rgba(255,255,255,0.2); padding:6px 14px; border-radius:8px; font-size:0.75rem; font-weight:700; cursor:pointer; display:inline-flex; align-items:center; gap:5px;">
                        <span>🔄</span> Re-upload
                    </button>
                    <button onclick="document.getElementById('leave-medical-bill-viewer-modal').style.display='none'" style="background:rgba(255,255,255,0.08); color:#94a3b8; border:none; padding:6px 14px; border-radius:8px; font-weight:700; font-size:0.75rem; cursor:pointer;">Close</button>
                </div>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
};

window.currentLeaveDocUpload = null;

window.openLeaveDocUploadModal = (docId) => {
    const leaves = window.allLeaveRequests || [];
    const req = leaves.find(l => l.docId === docId);
    if (!req) return window.showToast?.("Leave request not found.", "error");

    window.currentLeaveDocUpload = { docId, req, fileData: null, fileName: null };

    let modal = document.getElementById('leave-doc-upload-modal');
    if (!modal) {
        console.warn("leave-doc-upload-modal not found in DOM");
        return;
    }

    const empNameEl = document.getElementById('leave-upload-emp-name');
    const dateEl = document.getElementById('leave-upload-date');
    const typeEl = document.getElementById('leave-upload-type');
    const statusEl = document.getElementById('leave-upload-status');
    const noteEl = document.getElementById('leave-upload-note');
    const protectCheck = document.getElementById('leave-upload-protect-allowance');
    const previewContainer = document.getElementById('leave-upload-preview-container');
    const imgPreview = document.getElementById('leave-upload-img-preview');
    const filenameEl = document.getElementById('leave-upload-filename');
    const fileInput = document.getElementById('leave-upload-file-input');

    if (empNameEl) empNameEl.textContent = `${req.empName || 'Unknown'} (ID: ${req.empId || '-'})`;
    if (dateEl) dateEl.textContent = req.date || '--';
    if (typeEl) typeEl.textContent = req.type || 'Full Day';
    if (statusEl) {
        statusEl.textContent = (req.status || 'Pending').toUpperCase();
        statusEl.style.color = req.status === 'Approved' ? '#10b981' : (req.status === 'Rejected' ? '#ef4444' : '#38bdf8');
    }
    if (noteEl) noteEl.value = req.medicalBillNote || '';
    if (protectCheck) protectCheck.checked = true;
    if (fileInput) fileInput.value = '';

    // If an existing medical bill exists, show it in preview
    if (req.medicalBill) {
        window.currentLeaveDocUpload.fileData = req.medicalBill;
        window.currentLeaveDocUpload.fileName = req.medicalBillFileName || 'Existing_Document.jpg';
        if (imgPreview) imgPreview.src = req.medicalBill;
        if (filenameEl) filenameEl.textContent = `${window.currentLeaveDocUpload.fileName} (Current)`;
        if (previewContainer) previewContainer.style.display = 'block';
    } else {
        if (previewContainer) previewContainer.style.display = 'none';
        if (imgPreview) imgPreview.src = '';
    }

    modal.style.display = 'flex';
};

window.closeLeaveDocUploadModal = () => {
    const modal = document.getElementById('leave-doc-upload-modal');
    if (modal) modal.style.display = 'none';
    window.currentLeaveDocUpload = null;
};

window.handleLeaveDocFileSelect = (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const rawData = e.target.result;
        if (file.type.startsWith('image/')) {
            // Compress using HTML5 Canvas to max 1280px dimension and JPEG 0.82
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const maxDim = 1280;
                if (width > maxDim || height > maxDim) {
                    if (width > height) {
                        height = Math.round((height * maxDim) / width);
                        width = maxDim;
                    } else {
                        width = Math.round((width * maxDim) / height);
                        height = maxDim;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                const compressed = canvas.toDataURL('image/jpeg', 0.82);

                if (window.currentLeaveDocUpload) {
                    window.currentLeaveDocUpload.fileData = compressed;
                    window.currentLeaveDocUpload.fileName = file.name;
                }

                const previewContainer = document.getElementById('leave-upload-preview-container');
                const imgPreview = document.getElementById('leave-upload-img-preview');
                const filenameEl = document.getElementById('leave-upload-filename');

                if (imgPreview) imgPreview.src = compressed;
                if (filenameEl) filenameEl.textContent = `${file.name} (~${Math.round(compressed.length * 0.75 / 1024)} KB)`;
                if (previewContainer) previewContainer.style.display = 'block';
            };
            img.src = rawData;
        } else {
            // PDF or other supported document
            if (window.currentLeaveDocUpload) {
                window.currentLeaveDocUpload.fileData = rawData;
                window.currentLeaveDocUpload.fileName = file.name;
            }

            const previewContainer = document.getElementById('leave-upload-preview-container');
            const imgPreview = document.getElementById('leave-upload-img-preview');
            const filenameEl = document.getElementById('leave-upload-filename');

            if (imgPreview) imgPreview.src = 'https://cdn-icons-png.flaticon.com/512/337/337946.png'; // PDF icon
            if (filenameEl) filenameEl.textContent = `${file.name} (${Math.round(file.size / 1024)} KB)`;
            if (previewContainer) previewContainer.style.display = 'block';
        }
    };
    reader.readAsDataURL(file);
};

window.removeLeaveUploadFile = () => {
    if (window.currentLeaveDocUpload) {
        window.currentLeaveDocUpload.fileData = null;
        window.currentLeaveDocUpload.fileName = null;
    }
    const previewContainer = document.getElementById('leave-upload-preview-container');
    const imgPreview = document.getElementById('leave-upload-img-preview');
    const fileInput = document.getElementById('leave-upload-file-input');
    if (previewContainer) previewContainer.style.display = 'none';
    if (imgPreview) imgPreview.src = '';
    if (fileInput) fileInput.value = '';
};

window.submitLeaveDocUpload = async () => {
    const ctx = window.currentLeaveDocUpload;
    if (!ctx) return;
    if (!ctx.fileData) {
        return window.showToast?.("⚠️ Please select an image or document file to upload.", "warning");
    }

    const saveBtn = document.getElementById('leave-upload-submit-btn');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = `<span>⏳</span> Uploading Document...`;
    }

    try {
        const protectCheck = document.getElementById('leave-upload-protect-allowance');
        const noteInput = document.getElementById('leave-upload-note');
        const isProtected = protectCheck ? protectCheck.checked : true;
        const note = (noteInput?.value || '').trim();

        const authorizer = sessionStorage.getItem('userName') || sessionStorage.getItem('userRole') || 'HR / Manager';
        const nowStr = new Date().toLocaleString();

        const updateData = {
            medicalBill: ctx.fileData,
            medicalBillFileName: ctx.fileName || 'document.jpg',
            medicalBillBy: authorizer,
            medicalBillUploadedAt: nowStr,
            hasMedicalCertificate: true,
            allowanceProtected: isProtected
        };
        if (note) {
            updateData.medicalBillNote = note;
        }

        await updateDoc(doc(db, 'leave_requests', ctx.docId), updateData);

        // Update local cache
        if (ctx.req) {
            Object.assign(ctx.req, updateData);
        }
        if (window.allLeaveRequests) {
            const idx = window.allLeaveRequests.findIndex(l => l.docId === ctx.docId);
            if (idx !== -1) {
                Object.assign(window.allLeaveRequests[idx], updateData);
                renderLeavesUI(window.allLeaveRequests);
            }
        }

        window.closeLeaveDocUploadModal();
        window.showToast?.("✅ Medical Document uploaded successfully! Attendance allowance protected.", "success");
    } catch (err) {
        console.error("Error uploading leave doc:", err);
        window.showToast?.("Error uploading document: " + err.message, "error");
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = `<span>💾</span> Save & Attach Document`;
        }
    }
};

window.toggleProtectLeaveAllowance = async (docId, protect) => {
    try {
        await updateDoc(doc(db, 'leave_requests', docId), {
            allowanceProtected: protect
        });
        if (window.allLeaveRequests) {
            const req = window.allLeaveRequests.find(l => l.docId === docId);
            if (req) {
                req.allowanceProtected = protect;
                renderLeavesUI(window.allLeaveRequests);
            }
        }
        window.showToast?.(protect ? "🛡️ Attendance allowance marked as protected!" : "Attendance allowance protection removed.", "info");
    } catch (err) {
        window.showToast?.("Failed to update allowance protection.", "error");
    }
};

function playNotifSound() {
    // Try to use existing sound or create a new one
    let sound = document.getElementById('notif-sound-leave');
    if (!sound) {
        sound = document.createElement('audio');
        sound.id = 'notif-sound-leave';
        sound.src = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'; // Standard notification ding
        document.body.appendChild(sound);
    }
    sound.play().catch(e => console.log("Sound play blocked by browser."));
}

// ─── INTERNAL MAIL & HR COMMUNICATIONS MODULE ──────────────────────────────
const internalMailsCol = collection(db, 'internal_mails');
let currentMailFilter = 'inbox';
window.allInternalMails = [];
let isInitialMailSnapshot = true;
const knownMailDocIds = new Set();

// Check if a mail document matches the currently logged-in user
export function isMailForCurrentUser(m) {
    if (!m) return false;
    const currentUserId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Admin';
    const currentUserEmail = (sessionStorage.getItem('userEmail') || '').toLowerCase().trim();
    const currentUserRole = sessionStorage.getItem('userRole') || 'Admin';
    const isHrOrAdmin = ['SuperAdmin', 'CEO_Admin', 'Admin', 'HR_Manager', 'IT_Manager'].includes(currentUserRole);
    const myBranch = sessionStorage.getItem('userBranchId') || 'Global';
    const myBranchName = (window.allBranches || []).find(b => b.docId === myBranch)?.name || myBranch;

    const rId = m.recipientId || 'ALL';
    const rEmail = (m.recipientEmail || '').toLowerCase().trim();

    if (rId === 'ALL') return true;
    if (rId === 'HR_ONLY' && isHrOrAdmin) return true;
    if (rId === 'CASHIERS' && (currentUserRole.toLowerCase().includes('cashier') || isHrOrAdmin)) return true;
    if (rId === 'INVENTORY' && (currentUserRole.toLowerCase().includes('inventory') || currentUserRole.toLowerCase().includes('stock') || isHrOrAdmin)) return true;
    if (rId === 'TECH' && (currentUserRole.toLowerCase().includes('tech') || currentUserRole.toLowerCase().includes('repair') || isHrOrAdmin)) return true;
    if (rId.startsWith('BRANCH_') && (rId.replace('BRANCH_', '') === myBranchName || rId.replace('BRANCH_', '') === myBranch || isHrOrAdmin)) return true;
    if (rId.startsWith('ROLE_') && (rId.replace('ROLE_', '').toLowerCase() === currentUserRole.toLowerCase() || isHrOrAdmin)) return true;
    if (rId === currentUserId) return true;
    if (currentUserEmail && (rEmail === currentUserEmail || rId.toLowerCase() === currentUserEmail)) return true;

    return false;
}

function playMailNotificationSound() {
    try {
        const sound = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        sound.volume = 0.8;
        const p = sound.play();
        if (p !== undefined) {
            p.catch(() => playWebAudioTone());
        }
    } catch (e) {
        playWebAudioTone();
    }
}

function playWebAudioTone() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        if (ctx.state === 'suspended') ctx.resume();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
    } catch (e) {}
}

function showMailIncomingNotification(mail) {
    if (!mail) return;

    // 1. Play audio chime
    playMailNotificationSound();

    // 2. OS / Browser Native Push Notification
    if ('Notification' in window) {
        if (Notification.permission === 'granted') {
            try {
                const notif = new Notification(`📩 ${mail.senderName || 'Staff Notice'}`, {
                    body: `${mail.subject || 'New Message'}\n${mail.body || ''}`.trim(),
                    icon: '/pos-logo.png',
                    tag: mail.docId
                });
                notif.onclick = () => {
                    window.focus();
                    if (typeof window.readInternalMailModal === 'function') {
                        window.readInternalMailModal(mail.docId);
                    } else if (typeof window.showTab === 'function') {
                        window.showTab('internal-mail');
                    }
                };
            } catch (e) {}
        } else if (Notification.permission !== 'denied') {
            try { Notification.requestPermission(); } catch (e) {}
        }
    }

    // 3. Floating Interactive Glassmorphism Banner at Top Header / Screen Top
    let toastContainer = document.getElementById('mail-notification-toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'mail-notification-toast-container';
        toastContainer.style.cssText = 'position:fixed; top:20px; right:20px; z-index:999999; display:flex; flex-direction:column; gap:10px; pointer-events:none; max-width:400px; width:calc(100vw - 40px);';
        document.body.appendChild(toastContainer);
    }

    const isUrgent = mail.priority === 'urgent';
    const priorityTag = isUrgent 
        ? '<span style="background:rgba(239,68,68,0.2); color:#ef4444; border:1px solid rgba(239,68,68,0.4); font-size:0.68rem; font-weight:800; padding:2px 6px; border-radius:6px; animation:pulse 1.5s infinite;">🚨 URGENT</span>'
        : (mail.priority === 'confidential' ? '<span style="background:rgba(168,85,247,0.2); color:#c084fc; border:1px solid rgba(168,85,247,0.3); font-size:0.68rem; font-weight:800; padding:2px 6px; border-radius:6px;">🔒 CONFIDENTIAL</span>' : '');

    const toast = document.createElement('div');
    toast.className = 'mail-live-toast';
    toast.style.cssText = 'pointer-events:auto; background:rgba(15, 23, 42, 0.95); backdrop-filter:blur(25px); border:1.5px solid ' + (isUrgent ? 'rgba(239, 68, 68, 0.5)' : 'rgba(56, 189, 248, 0.4)') + '; border-radius:18px; padding:16px 18px; box-shadow:0 20px 50px rgba(0,0,0,0.85), 0 0 30px ' + (isUrgent ? 'rgba(239,68,68,0.3)' : 'rgba(56,189,248,0.3)') + '; color:white; display:flex; flex-direction:column; gap:8px; transform:translateY(-20px); opacity:0; transition:all 0.35s cubic-bezier(0.16, 1, 0.3, 1);';
    
    toast.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
            <div style="display:flex; align-items:center; gap:10px;">
                <div style="width:36px; height:36px; border-radius:10px; background:linear-gradient(135deg, #0ea5e9, #0284c7); display:flex; align-items:center; justify-content:center; font-size:1.2rem; box-shadow:0 4px 12px rgba(14,165,233,0.4);">📩</div>
                <div>
                    <div style="font-size:0.88rem; font-weight:800; color:#f8fafc; line-height:1.2;">${mail.senderName || 'HR Management'}</div>
                    <div style="font-size:0.72rem; color:#94a3b8;">${mail.senderEmail || 'Official Communication'}</div>
                </div>
            </div>
            <div style="display:flex; align-items:center; gap:6px;">
                ${priorityTag}
                <button onclick="this.closest('.mail-live-toast').remove()" style="background:none; border:none; color:#64748b; font-size:1.3rem; cursor:pointer; padding:0 4px; line-height:1;" title="Dismiss">&times;</button>
            </div>
        </div>
        <div>
            <div style="font-size:0.84rem; font-weight:700; color:#38bdf8; margin-bottom:3px;">${mail.subject || 'No Subject'}</div>
            <div style="font-size:0.76rem; color:#cbd5e1; max-height:42px; overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; line-height:1.4;">${mail.body || ''}</div>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px; padding-top:8px; border-top:1px solid rgba(255,255,255,0.06);">
            <span style="font-size:0.7rem; color:#64748b;">⚡ Just now</span>
            <div style="display:flex; gap:8px;">
                <button id="toast-read-btn-${mail.docId}" style="background:linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); color:white; border:none; padding:5px 16px; border-radius:8px; font-size:0.76rem; font-weight:800; cursor:pointer; box-shadow:0 4px 12px rgba(14,165,233,0.4); display:flex; align-items:center; gap:5px;">📖 Read Message</button>
            </div>
        </div>
    `;

    toastContainer.appendChild(toast);

    requestAnimationFrame(() => {
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';
    });

    const readBtn = toast.querySelector(`#toast-read-btn-${mail.docId}`);
    if (readBtn) {
        readBtn.onclick = () => {
            if (typeof window.readInternalMailModal === 'function') {
                window.readInternalMailModal(mail.docId);
            } else if (typeof window.showTab === 'function') {
                window.showTab('internal-mail');
            }
            toast.remove();
        };
    }

    // Auto dismiss after 10 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.transform = 'translateY(-20px)';
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 400);
        }
    }, 10000);
}

// Toggle Top Header Mail Dropdown
window.toggleHeaderMailDropdown = (e) => {
    if (e) {
        e.stopPropagation();
        e.preventDefault();
    }
    const dropdown = document.getElementById('header-mail-dropdown');
    if (!dropdown) return;
    const isShowing = dropdown.style.display === 'block';
    dropdown.style.display = isShowing ? 'none' : 'block';
};

// Global click-away listener for header mail dropdown
if (typeof document !== 'undefined') {
    document.addEventListener('click', (e) => {
        const dropdown = document.getElementById('header-mail-dropdown');
        const wrap = document.getElementById('header-mail-notification-wrap');
        if (dropdown && wrap && !wrap.contains(e.target)) {
            dropdown.style.display = 'none';
        }
    });
}

export function initInternalMails() {
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    let qMails;
    if (isMaster) {
        qMails = query(internalMailsCol);
    } else {
        qMails = query(internalMailsCol, where('storeId', '==', storeId));
    }

    onSnapshot(qMails, (snapshot) => {
        const mails = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        // Client-side sort by timestamp descending (eliminates Firestore composite index requirement)
        mails.sort((a, b) => {
            const timeA = a.timestamp?.seconds ? a.timestamp.seconds * 1000 : (new Date(a.timestamp || 0).getTime() || 0);
            const timeB = b.timestamp?.seconds ? b.timestamp.seconds * 1000 : (new Date(b.timestamp || 0).getTime() || 0);
            return timeB - timeA;
        });
        window.allInternalMails = mails;

        // Check for new incoming mails after initial load
        if (isInitialMailSnapshot) {
            snapshot.docs.forEach(d => knownMailDocIds.add(d.id));
            isInitialMailSnapshot = false;
        } else {
            const currentUserId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Admin';
            const currentUserEmail = (sessionStorage.getItem('userEmail') || '').toLowerCase().trim();

            snapshot.docChanges().forEach(change => {
                if (change.type === 'added' && !knownMailDocIds.has(change.doc.id)) {
                    knownMailDocIds.add(change.doc.id);
                    const newMail = { ...change.doc.data(), docId: change.doc.id };
                    const isSender = (newMail.senderId === currentUserId || (currentUserEmail && (newMail.senderEmail || '').toLowerCase().trim() === currentUserEmail));
                    if (!isSender && isMailForCurrentUser(newMail)) {
                        showMailIncomingNotification(newMail);
                    }
                }
            });
        }

        populateMailRecipientDropdown();
        renderInternalMailsUI();
        updateMailUnreadBadge(mails);
        updateUserEmailBadge();
    }, (err) => {
        console.warn("Internal Mails snapshot error:", err.message);
    });
}

function updateUserEmailBadge() {
    const userEmail = sessionStorage.getItem('userEmail') || '';
    const userName = sessionStorage.getItem('userName') || 'Staff';
    const userRole = sessionStorage.getItem('userRole') || 'Staff';
    const isOwnerOrCeo = (userRole === 'CEO_Admin' || userRole === 'SuperAdmin' || userRole === 'Owner');

    const emailText = document.getElementById('hrm-mail-user-email-text');
    const emailBtn = document.getElementById('hrm-mail-user-email-btn');
    const gmailTabBtn = document.getElementById('hrm-mail-tab-gmail');

    if (emailText) {
        if (userEmail) {
            emailText.innerText = `${userEmail} (${userRole})`;
        } else {
            emailText.innerText = `${userName} (${userRole})`;
        }
    }

    if (emailBtn && userEmail) {
        emailBtn.title = `Logged in as ${userEmail}`;
    }

    // Only CEO_Admin / SuperAdmin can see the Store Webmail button in the sidebar
    if (gmailTabBtn) {
        if (isOwnerOrCeo) {
            gmailTabBtn.style.display = 'flex';
        } else {
            gmailTabBtn.style.display = 'none';
        }
    }
}

export async function populateMailRecipientDropdown() {
    const selects = document.querySelectorAll('#hrm-mail-to, .hrm-mail-to-select, #hrm-mail-to-inline');
    if (!selects || selects.length === 0) return;

    let employees = window.allEmployees || [];
    let branches = window.allBranches || [];

    // Fallback: If employees list not yet populated in window, fetch live from Firestore
    if (!employees || employees.length === 0) {
        try {
            const { getDocs } = await import("firebase/firestore");
            const snap = await getDocs(collection(db, 'employees'));
            employees = snap.docs.map(d => ({ docId: d.id, ...d.data() }));
            window.allEmployees = employees;
        } catch (e) {
            console.warn("Live fetch employees for mail dropdown:", e);
        }
    }

    // Fallback: If branches list not yet populated in window, fetch live from Firestore
    if (!branches || branches.length === 0) {
        try {
            const { getDocs } = await import("firebase/firestore");
            const snapB = await getDocs(collection(db, 'branches'));
            branches = snapB.docs.map(d => ({ docId: d.id, ...d.data() }));
            window.allBranches = branches;
        } catch (e) {
            console.warn("Live fetch branches for mail dropdown:", e);
        }
    }

    // Build branch lookup map
    const branchMap = {};
    branches.forEach(b => {
        branchMap[b.docId] = b.name || 'Branch';
    });

    // Group employees by Branch / Section
    const branchGroups = {};
    // Group employees by Role / Department
    const roleGroups = {};

    employees.forEach(emp => {
        const branchKey = emp.branchId || 'Main / Global';
        const branchName = emp.branchId === 'Global' ? 'Main Office' : (branchMap[emp.branchId] || emp.branchName || emp.branchId || 'Main Office');
        if (!branchGroups[branchName]) branchGroups[branchName] = [];
        branchGroups[branchName].push(emp);

        const roleKey = emp.role || emp.role_access || 'Staff';
        if (!roleGroups[roleKey]) roleGroups[roleKey] = [];
        roleGroups[roleKey].push(emp);
    });

    let optionsHtml = `
        <optgroup label="📢 Global & Department Broadcasts">
            <option value="ALL">📢 All Employees (Broadcast Circular)</option>
            <option value="HR_ONLY">🏢 HR & Management Only</option>
            <option value="CASHIERS">🛒 Cashiers & Sales Staff Only</option>
            <option value="INVENTORY">📦 Inventory & Store Keepers Only</option>
            <option value="TECH">💻 Tech & Repair Staff Only</option>
        </optgroup>
    `;

    // Branch / Section Group Broadcasts
    const branchNames = Object.keys(branchGroups).sort();
    if (branchNames.length > 0) {
        optionsHtml += `<optgroup label="🏢 By Section / Branch (Broadcast)">`;
        branchNames.forEach(bName => {
            optionsHtml += `<option value="BRANCH_${bName}">🏢 All Staff in ${bName} (${branchGroups[bName].length} members)</option>`;
        });
        optionsHtml += `</optgroup>`;
    }

    // Role / Department Broadcasts
    const roleNames = Object.keys(roleGroups).sort();
    if (roleNames.length > 0) {
        optionsHtml += `<optgroup label="👥 By Department / Role">`;
        roleNames.forEach(rName => {
            optionsHtml += `<option value="ROLE_${rName}">👥 All ${rName}s (${roleGroups[rName].length} members)</option>`;
        });
        optionsHtml += `</optgroup>`;
    }

    // Individual Employees grouped by Section / Branch
    if (branchNames.length > 0) {
        branchNames.forEach(bName => {
            optionsHtml += `<optgroup label="👤 Individual Staff — ${bName}">`;
            branchGroups[bName].forEach(emp => {
                const empName = emp.name || emp.username || emp.fullName || 'Employee';
                const empRole = emp.role || emp.role_access || 'Staff';
                const empReg = emp.regno ? `[${emp.regno}] ` : (emp.empId ? `[${emp.empId}] ` : '');
                const empId = emp.docId || emp.regno || emp.email || emp.phone;
                optionsHtml += `<option value="${empId}">👤 ${empReg}${empName} (${empRole})</option>`;
            });
            optionsHtml += `</optgroup>`;
        });
    } else if (employees.length > 0) {
        optionsHtml += `<optgroup label="👤 Individual Employees">`;
        employees.forEach(emp => {
            const empName = emp.name || emp.username || emp.fullName || 'Employee';
            const empRole = emp.role || emp.role_access || 'Staff';
            const empReg = emp.regno ? `[${emp.regno}] ` : (emp.empId ? `[${emp.empId}] ` : '');
            const empId = emp.docId || emp.regno || emp.email || emp.phone;
            optionsHtml += `<option value="${empId}">👤 ${empReg}${empName} (${empRole})</option>`;
        });
        optionsHtml += `</optgroup>`;
    }

    selects.forEach(sel => {
        sel.innerHTML = optionsHtml;
    });
}

let currentMailAttachment = null;

window.handleMailAttachmentChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
        window.showToast("Attachment file must be under 5MB.", "error");
        e.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = () => {
        currentMailAttachment = {
            name: file.name,
            size: file.size,
            type: file.type || 'application/octet-stream',
            url: reader.result
        };

        const preview = document.getElementById('hrm-mail-attachment-preview');
        const nameEl = document.getElementById('hrm-mail-attachment-name');
        if (preview && nameEl) {
            nameEl.innerText = file.name;
            preview.style.display = 'inline-flex';
        }
    };
    reader.onerror = () => {
        window.showToast("Failed to read attachment file.", "error");
    };
    reader.readAsDataURL(file);
};

window.removeMailAttachment = () => {
    currentMailAttachment = null;
    const fileInput = document.getElementById('hrm-mail-attachment-input');
    if (fileInput) fileInput.value = '';
    const preview = document.getElementById('hrm-mail-attachment-preview');
    if (preview) preview.style.display = 'none';
};

window.openComposeMailModal = async (replyToMail = null) => {
    const modal = document.getElementById('hrm-mail-compose-modal');
    if (!modal) return;

    window.removeMailAttachment();
    await populateMailRecipientDropdown();

    if (replyToMail) {
        const selectTo = document.getElementById('hrm-mail-to');
        const subjectInput = document.getElementById('hrm-mail-subject');
        const bodyInput = document.getElementById('hrm-mail-body');

        if (selectTo) selectTo.value = replyToMail.senderId || 'ALL';
        if (subjectInput) subjectInput.value = replyToMail.subject ? (replyToMail.subject.startsWith('Re:') ? replyToMail.subject : `Re: ${replyToMail.subject}`) : '';
        if (bodyInput) bodyInput.value = `\n\n--- Original Message from ${replyToMail.senderName || 'Staff'} ---\n${replyToMail.body || ''}`;
    }

    modal.style.display = 'flex';
};

window.closeComposeMailModal = () => {
    const modal = document.getElementById('hrm-mail-compose-modal');
    if (modal) modal.style.display = 'none';
    window.removeMailAttachment();
};

window.switchMailViewTab = (tabName) => {
    const internalView = document.getElementById('hrm-mail-internal-view');
    const gmailView = document.getElementById('hrm-mail-gmail-view');
    const pillsBar = document.getElementById('hrm-mail-category-pills');
    const gmailBtn = document.getElementById('hrm-mail-tab-gmail');

    if (tabName === 'gmail') {
        if (internalView) internalView.style.display = 'none';
        if (gmailView) gmailView.style.display = 'flex';
        if (pillsBar) pillsBar.style.display = 'none';
        if (gmailBtn) {
            gmailBtn.style.background = 'rgba(239, 68, 68, 0.25)';
            gmailBtn.style.borderColor = 'rgba(239, 68, 68, 0.5)';
        }
    } else {
        if (internalView) internalView.style.display = 'block';
        if (gmailView) gmailView.style.display = 'none';
        if (pillsBar) pillsBar.style.display = 'flex';
        if (gmailBtn) {
            gmailBtn.style.background = 'rgba(239, 68, 68, 0.08)';
            gmailBtn.style.borderColor = 'rgba(239, 68, 68, 0.2)';
        }
    }
};

window.filterInternalMails = (filterType) => {
    currentMailFilter = filterType;
    window.switchMailViewTab('internal');

    const folderIds = ['inbox', 'starred', 'sent', 'urgent', 'broadcast'];
    folderIds.forEach(f => {
        const btn = document.getElementById(`hrm-mail-filter-${f}`);
        if (!btn) return;
        if (f === filterType) {
            btn.style.background = 'rgba(14, 165, 233, 0.15)';
            btn.style.color = '#38bdf8';
            btn.style.borderColor = 'rgba(14, 165, 233, 0.3)';
        } else {
            btn.style.background = 'transparent';
            btn.style.color = '#94a3b8';
            btn.style.borderColor = 'transparent';
        }
    });

    const label = document.getElementById('hrm-mailbox-filter-label');
    if (label) {
        const titleMap = {
            inbox: 'Inbox',
            starred: 'Starred',
            sent: 'Sent',
            urgent: 'Urgent Notices',
            broadcast: 'Broadcast Circulars'
        };
        label.innerText = titleMap[filterType] || filterType;
    }
    renderInternalMailsUI();
};

window.searchInternalMails = () => {
    renderInternalMailsUI();
};

window.refreshMailboxUI = () => {
    window.showToast("🔄 Syncing Mailbox...", "info");
    renderInternalMailsUI();
};

window.toggleMailStar = async (mailId) => {
    const mail = (window.allInternalMails || []).find(m => m.docId === mailId);
    if (!mail) return;
    try {
        const newStar = !mail.starred;
        await updateDoc(doc(db, 'internal_mails', mailId), { starred: newStar });
        mail.starred = newStar;
        renderInternalMailsUI();
        window.showToast(newStar ? "⭐ Starred message" : "Unstarred message", "info");
    } catch (e) {
        console.error("Star toggle error:", e);
    }
};

window.deleteInternalMail = async (mailId) => {
    const docRef = doc(db, 'internal_mails', mailId);
    if (!await window.verifyDeletePermission(docRef)) return;
    try {
        await deleteDoc(docRef);
        window.showToast("🗑️ Mail deleted.", "info");
    } catch (err) {
        window.showToast("Error deleting mail.", "error");
    }
};

function renderInternalMailsUI() {
    const tbody = document.getElementById('hrm-mail-list-body');
    if (!tbody) return;

    const currentUserId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Admin';
    const currentUserRole = sessionStorage.getItem('userRole') || 'Admin';
    const isHrOrAdmin = ['SuperAdmin', 'CEO_Admin', 'Admin', 'HR_Manager', 'IT_Manager'].includes(currentUserRole);

    const mails = window.allInternalMails || [];
    const searchQuery = (document.getElementById('hrm-mail-search-input')?.value || '').toLowerCase().trim();

    let filtered = mails.filter(m => {
        // Folder filter
        if (currentMailFilter === 'sent') {
            if (!(m.senderId === currentUserId || m.senderEmail === sessionStorage.getItem('userEmail'))) return false;
        } else if (currentMailFilter === 'starred') {
            if (!m.starred) return false;
        } else if (currentMailFilter === 'urgent') {
            if (m.priority !== 'urgent') return false;
        } else if (currentMailFilter === 'broadcast') {
            if (m.recipientId !== 'ALL') return false;
        } else {
            // Inbox filter
            const myBranch = sessionStorage.getItem('userBranchId') || 'Global';
            const myBranchName = (window.allBranches || []).find(b => b.docId === myBranch)?.name || myBranch;
            const matchesInbox = (m.recipientId === 'ALL') || 
                                 (m.recipientId === 'HR_ONLY' && isHrOrAdmin) || 
                                 (m.recipientId === 'CASHIERS' && (currentUserRole.toLowerCase().includes('cashier') || isHrOrAdmin)) || 
                                 (m.recipientId === 'INVENTORY' && (currentUserRole.toLowerCase().includes('inventory') || currentUserRole.toLowerCase().includes('stock') || isHrOrAdmin)) || 
                                 (m.recipientId === 'TECH' && (currentUserRole.toLowerCase().includes('tech') || currentUserRole.toLowerCase().includes('repair') || isHrOrAdmin)) || 
                                 (m.recipientId.startsWith('BRANCH_') && (m.recipientId.replace('BRANCH_', '') === myBranchName || m.recipientId.replace('BRANCH_', '') === myBranch || isHrOrAdmin)) || 
                                 (m.recipientId.startsWith('ROLE_') && (m.recipientId.replace('ROLE_', '').toLowerCase() === currentUserRole.toLowerCase() || isHrOrAdmin)) || 
                                 (m.recipientId === currentUserId || m.recipientEmail === sessionStorage.getItem('userEmail'));
            if (!matchesInbox) return false;
        }

        // Text Search filter
        if (searchQuery) {
            const subject = (m.subject || '').toLowerCase();
            const body = (m.body || '').toLowerCase();
            const sender = (m.senderName || '').toLowerCase();
            const recipient = (m.recipientName || '').toLowerCase();
            return subject.includes(searchQuery) || body.includes(searchQuery) || sender.includes(searchQuery) || recipient.includes(searchQuery);
        }
        return true;
    });

    const countTag = document.getElementById('hrm-mail-count-tag');
    if (countTag) countTag.innerText = `Showing ${filtered.length} messages`;

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 4rem; color: #64748b;">No ${currentMailFilter} messages found.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(mail => {
        const timeStr = mail.timestamp ? new Date(mail.timestamp.seconds * 1000).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Just now';
        
        let priorityBadge = '<span style="color:#38bdf8; font-size: 0.72rem; font-weight:600;">Normal</span>';
        if (mail.priority === 'urgent') priorityBadge = '<span style="color:#ef4444; font-weight:800; font-size:0.72rem; background:rgba(239,68,68,0.15); padding:2px 8px; border-radius:4px;">🚨 Urgent</span>';
        if (mail.priority === 'confidential') priorityBadge = '<span style="color:#a855f7; font-weight:800; font-size:0.72rem; background:rgba(168,85,247,0.15); padding:2px 8px; border-radius:4px;">🔒 Confidential</span>';

        const displayPerson = currentMailFilter === 'sent' 
            ? `To: ${mail.recipientName || mail.recipientId}` 
            : `${mail.senderName || 'HR Management'}`;

        const starIcon = mail.starred ? '⭐' : '☆';
        const unreadStyle = !mail.isRead && currentMailFilter !== 'sent' ? 'background: rgba(14, 165, 233, 0.04); font-weight: 700;' : '';

        return `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); ${unreadStyle}">
                <td style="text-align: center; cursor: pointer; font-size: 1.1rem; padding: 10px;" onclick="window.toggleMailStar('${mail.docId}')">
                    ${starIcon}
                </td>
                <td style="padding: 12px;">
                    <div style="font-weight: 700; color: #f8fafc; font-size: 0.85rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 170px;">${displayPerson}</div>
                </td>
                <td style="padding: 12px; cursor: pointer;" onclick="window.readInternalMailModal('${mail.docId}')">
                    <div style="font-weight: 700; color: #38bdf8; font-size: 0.85rem;">${mail.subject || 'No Subject'}</div>
                    <div style="font-size: 0.78rem; color: #94a3b8; max-width: 480px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${mail.body || ''}</div>
                </td>
                <td style="padding: 12px;">${priorityBadge}</td>
                <td style="font-size: 0.75rem; color: #94a3b8; padding: 12px;">${timeStr}</td>
                <td style="text-align: right; padding: 12px 16px;">
                    <div style="display: flex; gap: 6px; justify-content: flex-end;">
                        <button onclick="window.readInternalMailModal('${mail.docId}')" title="Read Message" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 5px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">📖 Read</button>
                        <button onclick="window.deleteInternalMail('${mail.docId}')" title="Delete Message" class="action-btn" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); padding: 5px 8px; border-radius: 6px; font-size: 0.75rem; cursor: pointer;">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function updateMailUnreadBadge(mails) {
    const badge = document.getElementById('hrm-mail-badge');
    const navBadge = document.getElementById('nav-mail-badge');
    const headerBadge = document.getElementById('header-mail-badge');
    const headerDropdownCount = document.getElementById('header-mail-dropdown-count');
    const headerDropdownList = document.getElementById('header-mail-dropdown-list');
    
    const currentUserId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Admin';
    const currentUserEmail = (sessionStorage.getItem('userEmail') || '').toLowerCase().trim();
    const currentUserRole = sessionStorage.getItem('userRole') || 'Admin';
    const isHrOrAdmin = ['SuperAdmin', 'CEO_Admin', 'Admin', 'HR_Manager', 'IT_Manager'].includes(currentUserRole);

    const inboxMails = (mails || []).filter(isMailForCurrentUser);
    const unreadMails = inboxMails.filter(m => !m.isRead);
    const unreadCount = unreadMails.length;

    // Folder side counters
    const elInboxCount = document.getElementById('hrm-folder-inbox-count');
    const elStarredCount = document.getElementById('hrm-folder-starred-count');
    const elSentCount = document.getElementById('hrm-folder-sent-count');
    const elUrgentCount = document.getElementById('hrm-folder-urgent-count');
    const elBroadcastCount = document.getElementById('hrm-folder-broadcast-count');

    if (elInboxCount) elInboxCount.innerText = unreadCount || inboxMails.length;
    if (elStarredCount) elStarredCount.innerText = (mails || []).filter(m => m.starred).length;
    if (elSentCount) elSentCount.innerText = (mails || []).filter(m => m.senderId === currentUserId || (currentUserEmail && (m.senderEmail || '').toLowerCase().trim() === currentUserEmail)).length;
    if (elUrgentCount) elUrgentCount.innerText = inboxMails.filter(m => m.priority === 'urgent').length;
    if (elBroadcastCount) elBroadcastCount.innerText = (mails || []).filter(m => m.recipientId === 'ALL').length;

    if (badge) {
        if (unreadCount > 0) {
            badge.innerText = unreadCount;
            badge.style.display = 'block';
        } else {
            badge.style.display = 'none';
        }
    }

    if (navBadge) {
        if (unreadCount > 0) {
            navBadge.innerText = unreadCount;
            navBadge.style.display = 'inline-block';
        } else {
            navBadge.style.display = 'none';
        }
    }

    if (headerBadge) {
        if (unreadCount > 0) {
            headerBadge.innerText = unreadCount;
            headerBadge.style.display = 'inline-flex';
        } else {
            headerBadge.style.display = 'none';
        }
    }

    if (headerDropdownCount) {
        headerDropdownCount.innerText = `${unreadCount} Unread`;
    }

    if (headerDropdownList) {
        const displayList = unreadMails.length > 0 ? unreadMails.slice(0, 5) : inboxMails.slice(0, 5);
        if (displayList.length === 0) {
            headerDropdownList.innerHTML = `<div style="padding: 24px; text-align: center; color: #64748b; font-size: 0.8rem;">📭 No messages in mailbox</div>`;
        } else {
            headerDropdownList.innerHTML = displayList.map(m => {
                const timeStr = m.timestamp ? new Date(m.timestamp.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Now';
                const isUrgent = m.priority === 'urgent';
                const unreadBg = !m.isRead ? 'rgba(56, 189, 248, 0.08)' : 'transparent';
                const dot = !m.isRead ? '<span style="width: 7px; height: 7px; border-radius: 50%; background: #38bdf8; display: inline-block; flex-shrink: 0;"></span>' : '';
                return `
                    <div onclick="window.readInternalMailModal('${m.docId}'); const d = document.getElementById('header-mail-dropdown'); if(d) d.style.display='none';" style="padding: 10px 14px; display: flex; align-items: flex-start; gap: 10px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.04); background: ${unreadBg}; transition: background 0.15s;" onmouseover="this.style.background='rgba(56,189,248,0.15)'" onmouseout="this.style.background='${unreadBg}'">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #0284c7, #0ea5e9); color: white; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: 800; flex-shrink: 0;">
                            ${(m.senderName || 'S').charAt(0).toUpperCase()}
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                                <div style="font-weight: 700; color: #f8fafc; font-size: 0.8rem; display: flex; align-items: center; gap: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    ${dot} <span>${m.senderName || 'HR Management'}</span>
                                </div>
                                <span style="font-size: 0.68rem; color: #64748b; flex-shrink: 0;">${timeStr}</span>
                            </div>
                            <div style="font-size: 0.76rem; color: #38bdf8; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${m.subject || 'No Subject'}</div>
                            <div style="font-size: 0.72rem; color: #94a3b8; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${m.body || ''}</div>
                        </div>
                    </div>
                `;
            }).join('');
        }
    }
}

window.sendInternalMail = async (e) => {
    if (e) e.preventDefault();
    
    // Check if submitted from modal or inline form
    const form = e?.target || document.getElementById('hrm-mail-compose-form');
    const isInline = form?.id === 'hrm-mail-compose-form-inline';

    const toEl = isInline ? document.getElementById('hrm-mail-to-inline') : (document.getElementById('hrm-mail-to') || document.getElementById('hrm-mail-to-inline'));
    const subjectEl = isInline ? document.getElementById('hrm-mail-subject-inline') : (document.getElementById('hrm-mail-subject') || document.getElementById('hrm-mail-subject-inline'));
    const priorityEl = isInline ? document.getElementById('hrm-mail-priority-inline') : (document.getElementById('hrm-mail-priority') || document.getElementById('hrm-mail-priority-inline'));
    const bodyEl = isInline ? document.getElementById('hrm-mail-body-inline') : (document.getElementById('hrm-mail-body') || document.getElementById('hrm-mail-body-inline'));

    const recipientId = toEl?.value || 'ALL';
    const subject = (subjectEl?.value || '').trim();
    const priority = priorityEl?.value || 'normal';
    const body = (bodyEl?.value || '').trim();

    if (!subject || !body) {
        window.showToast("Please enter both subject and message body.", "error");
        return;
    }

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const senderName = sessionStorage.getItem('userName') || 'HR Management';
    const senderEmail = sessionStorage.getItem('userEmail') || 'admin@mecpos.web.lk';
    const senderId = sessionStorage.getItem('userId') || senderEmail;

    let recipientName = 'All Staff';
    if (recipientId === 'HR_ONLY') {
        recipientName = 'HR & Management';
    } else if (recipientId === 'CASHIERS') {
        recipientName = 'Cashiers & Sales Staff';
    } else if (recipientId === 'INVENTORY') {
        recipientName = 'Inventory & Store Staff';
    } else if (recipientId === 'TECH') {
        recipientName = 'Tech & Repair Staff';
    } else if (recipientId.startsWith('BRANCH_')) {
        recipientName = `Section: ${recipientId.replace('BRANCH_', '')}`;
    } else if (recipientId.startsWith('ROLE_')) {
        recipientName = `Dept: ${recipientId.replace('ROLE_', '')}s`;
    } else if (recipientId !== 'ALL') {
        const targetEmp = (window.allEmployees || []).find(emp => (emp.docId || emp.regno || emp.email) === recipientId);
        if (targetEmp) {
            const regTag = targetEmp.regno ? `[${targetEmp.regno}] ` : '';
            recipientName = `${regTag}${targetEmp.name || targetEmp.username || recipientId}`;
        }
    }

    try {
        const { addDoc } = await import("firebase/firestore");
        const mailDoc = {
            storeId,
            senderId,
            senderName,
            senderEmail,
            recipientId,
            recipientName,
            subject,
            priority,
            body,
            starred: false,
            isRead: false,
            timestamp: serverTimestamp()
        };

        if (currentMailAttachment) {
            mailDoc.attachment = currentMailAttachment;
        }

        await addDoc(internalMailsCol, mailDoc);

        window.showToast("✉️ Staff Message Sent Successfully!", "success");
        if (subjectEl) subjectEl.value = '';
        if (bodyEl) bodyEl.value = '';
        const modalSubject = document.getElementById('hrm-mail-subject');
        const modalBody = document.getElementById('hrm-mail-body');
        if (modalSubject) modalSubject.value = '';
        if (modalBody) modalBody.value = '';
        window.closeComposeMailModal();
    } catch (err) {
        console.error("Send mail error:", err);
        window.showToast("Failed to send internal mail.", "error");
    }
};

window.readInternalMailModal = async (mailId) => {
    const mail = (window.allInternalMails || []).find(m => m.docId === mailId);
    if (!mail) return;

    // Mark as read in Firestore
    if (!mail.isRead) {
        try {
            await updateDoc(doc(db, 'internal_mails', mailId), { isRead: true });
            mail.isRead = true;
        } catch (e) {}
    }

    let attachmentHtml = '';
    if (mail.attachment && mail.attachment.url) {
        const isImg = mail.attachment.type && mail.attachment.type.startsWith('image/');
        attachmentHtml = `
            <div style="margin-top: 1rem; background: rgba(0,0,0,0.5); padding: 12px; border-radius: 12px; border: 1px solid rgba(56, 189, 248, 0.3);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 6px;">
                    <span style="font-size:0.85rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${mail.attachment.name || 'File'}</span>
                    <a href="${mail.attachment.url}" download="${mail.attachment.name || 'download'}" class="action-btn primary" style="padding: 4px 12px; font-size: 0.75rem; text-decoration: none;">⬇️ Download</a>
                </div>
                ${isImg ? `<img src="${mail.attachment.url}" style="max-width:100%; max-height:220px; object-fit:contain; border-radius:8px; margin-top:6px;" />` : ''}
            </div>
        `;
    }

    const modalHtml = `
        <div id="hrm-mail-view-modal" style="position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.8); backdrop-filter:blur(10px); z-index:99999; display:flex; align-items:center; justify-content:center; padding:1rem;">
            <div style="background: #0f172a; border:1px solid rgba(56, 189, 248, 0.3); border-radius: 20px; width: 100%; max-width: 640px; padding: 2rem; box-shadow: 0 20px 50px rgba(0,0,0,0.8); color: white;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 1rem;">
                    <div>
                        <span style="font-size: 0.75rem; background: rgba(56, 189, 248, 0.15); color: #38bdf8; padding: 3px 10px; border-radius: 50px; font-weight: 700;">HR / Staff Official Communication</span>
                        <h2 style="margin: 0.5rem 0 0; color: #f8fafc; font-size: 1.35rem;">${mail.subject || 'No Subject'}</h2>
                    </div>
                    <button onclick="document.getElementById('hrm-mail-view-modal').remove()" style="background:none; border:none; color:#94a3b8; font-size:1.5rem; cursor:pointer;">&times;</button>
                </div>
                <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 1.5rem; line-height: 1.8;">
                    <div><b>From:</b> <span style="color:#f8fafc;">${mail.senderName} (${mail.senderEmail || 'System'})</span></div>
                    <div><b>To:</b> <span style="color:#38bdf8;">${mail.recipientName}</span></div>
                    <div><b>Date:</b> ${mail.timestamp ? new Date(mail.timestamp.seconds * 1000).toLocaleString() : 'Just now'}</div>
                </div>
                <div style="background: rgba(0,0,0,0.4); padding: 1.2rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); font-size: 0.95rem; color: #e2e8f0; line-height: 1.6; white-space: pre-wrap; max-height: 300px; overflow-y: auto;">${mail.body}</div>
                ${attachmentHtml}
                <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <button onclick="window.deleteInternalMail('${mail.docId}'); document.getElementById('hrm-mail-view-modal').remove();" class="action-btn" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer;">🗑️ Delete</button>
                    <div style="display: flex; gap: 10px;">
                        <button onclick="document.getElementById('hrm-mail-view-modal').remove(); window.openComposeMailModal({ senderId: '${mail.senderId}', senderName: '${mail.senderName}', subject: '${(mail.subject || '').replace(/'/g, "\\'")}', body: '${(mail.body || '').replace(/\n/g, '\\n').replace(/'/g, "\\'")}' });" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 8px 18px; border-radius: 8px; font-weight: 700; cursor: pointer;">↩️ Reply</button>
                        <button onclick="document.getElementById('hrm-mail-view-modal').remove()" class="action-btn primary" style="padding: 8px 20px; border-radius: 8px; font-weight: 700;">Close</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    const existing = document.getElementById('hrm-mail-view-modal');
    if (existing) existing.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);
};

// Export to window so admin.js (and auth.js showTab hooks) can call them
window.initHRM = initHRM;
window.initInternalMails = initInternalMails;
window.populateMailRecipientDropdown = populateMailRecipientDropdown;

// Initialize Internal Mail module listener on load
setTimeout(() => {
    try { initInternalMails(); } catch (e) { console.warn("Internal Mails init error", e); }
}, 1000);


