const CACHE_NAME = 'mec-pos-v3.38.40';
const STATIC_ASSETS = [
    '/',
    '/admin',
    '/login',
    '/track',
    '/contact',
    '/logo.png',
    '/src/admin-style.css'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(STATIC_ASSETS);
        }).catch(() => {})
    );
    self.skipWaiting();
});

self.addEventListener('activate', (e) => {
    e.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.map((key) => {
                    if (key !== CACHE_NAME) return caches.delete(key);
                })
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', (e) => {
    // Only handle http/https requests
    if (!e.request.url.startsWith('http')) return;
    
    // Ignore installers and compressed files
    if (e.request.url.includes('/updates/') || e.request.url.endsWith('.exe') || e.request.url.endsWith('.zip')) {
        return;
    }

    // Network-First strategy for HTML/Navigation requests to ensure the latest app version is loaded
    if (e.request.mode === 'navigate' || e.request.url.includes('.html')) {
        e.respondWith(
            fetch(e.request, { cache: 'no-cache' }).then((networkResponse) => {
                const responseToCache = networkResponse.clone();
                caches.open(CACHE_NAME).then((cache) => {
                    cache.put(e.request, responseToCache);
                });
                return networkResponse;
            }).catch(() => {
                return caches.match(e.request);
            })
        );
        return;
    }

    // Network-First strategy for all app assets with offline cache fallback
    e.respondWith(
        fetch(e.request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
                const responseToCache = networkResponse.clone();
                caches.open(CACHE_NAME).then((cache) => {
                    cache.put(e.request, responseToCache);
                });
            }
            return networkResponse;
        }).catch(() => {
            return caches.match(e.request).then((cachedResponse) => {
                if (cachedResponse) return cachedResponse;
                return new Response('Offline fallback content unavailable', { 
                    status: 503, 
                    statusText: 'Service Unavailable',
                    headers: { 'Content-Type': 'text/plain' }
                });
            });
        })
    );
});
