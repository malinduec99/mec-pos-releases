// [MANDATORY] Run .\MASTER_SYNC.bat after any changes to this file!
import './admin-style.css';
import './singlish.js';
import './modules/auth.js';
import './modules/inventory.js';
import './modules/orders.js';
import './modules/finance.js';
import './modules/bankManager.js';
import './modules/pos.js';
import './modules/theme.js';
import './modules/repairs.js';
import './modules/reports.js';
import './modules/mrp.js';
import './modules/hrm.js';
import './modules/promotions.js';
import './modules/lite-mode.js';
import './modules/aiCopilot.js';
import { initQuotationManager } from './modules/quotationManager.js';
import { initSupplyChain } from './modules/supply_chain.js';
import { initSystem, CLIENT_VERSION } from './modules/system.js';
import { initAutoBackup } from './modules/backup.js';
import { initReloadModule } from './modules/reload.js';
import { db, auth } from './firebase.js';
import { saveOfflineCache, loadOfflineCache } from './modules/cacheManager.js';

// Cloud logging bridge for remote diagnostics
window.uploadLogToCloud = async function(message, type = 'csharp') {
    try {
        const storeId = localStorage.getItem('mecpos_last_store_id') || 'unknown';
        await addDoc(collection(db, 'system_logs'), {
            storeId,
            type,
            message,
            timestamp: serverTimestamp(),
            userAgent: navigator.userAgent
        });
    } catch(e) {
        console.error("Cloud logging failed:", e);
    }
};

// --- Store Detection & Global Helpers ---
const urlParams = new URLSearchParams(window.location.search);
const pathParts = window.location.pathname.split('/').filter(p => p !== '');
const urlStore = urlParams.get('store') || (pathParts[0] === 'admin' ? pathParts[1] : null);
if (urlStore) sessionStorage.setItem('tempStoreSlug', urlStore);

window.getStoreId = () => sessionStorage.getItem('userStoreId') || sessionStorage.getItem('tempStoreSlug') || 'mec-book-shop';

window.getLocalYYYYMMDD = (d = new Date()) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// --- Scanner Global Logic ---
let html5QrCode;
let currentFacingMode = "environment";
let scannerCallback = null;

window.openScanner = (callback = null) => {
    scannerCallback = callback;
    const modal = document.getElementById('scanner-modal');
    if (modal) modal.style.display = 'flex';
    if (!html5QrCode) {
        html5QrCode = new Html5Qrcode("scanner-reader");
    }
    startScanning();
};

const startScanning = () => {
    const config = { 
        fps: 24, 
        qrbox: (width, height) => {
            return { width: Math.floor(width * 0.8), height: Math.floor(height * 0.5) };
        }
    };
    html5QrCode.start(
        { facingMode: currentFacingMode },
        config,
        onScanSuccess
    ).catch(err => {
        console.error("Camera Error:", err);
        window.showToast("Cannot access camera. Check permissions.", "error");
    });
};

window.toggleCamera = () => {
    currentFacingMode = currentFacingMode === "environment" ? "user" : "environment";
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => startScanning());
    }
};

window.closeScanner = () => {
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
            document.getElementById('scanner-modal').style.display = 'none';
        });
    } else {
        const modal = document.getElementById('scanner-modal');
        if (modal) modal.style.display = 'none';
    }
};

const onScanSuccess = (decodedText) => {
    const q = decodedText.trim();
    if (typeof scannerCallback === 'function') {
        scannerCallback(q);
        window.closeScanner();
        scannerCallback = null;
        return;
    }

    // [v3.12.15] Respect active tab for scanner logic
    const activeTab = document.querySelector('.nav-tab.active')?.id;

    if (activeTab === 'tab-supplier-invoices' || activeTab === 'tab-stock') {
        const searchQ = q.toLowerCase();
        const product = (window.allProducts || []).find(p => 
            (p.sku && p.sku.toLowerCase() === searchQ) ||
            (p.name && p.name.toLowerCase() === searchQ)
        );

        if (product) {
            window.addToSupplierInvoice(product.docId);
            window.showToast(`✅ Added to Batch: ${product.name}`, "success");
            const sound = document.getElementById('sound-pos-save');
            if (sound) sound.play().catch(() => {});
        } else {
            window.showToast("❌ Product not found in catalog", "warning");
        }
        return;
    }

    // Default POS logic
    if (window.addToPOSBill) {
        const searchQ = q.toLowerCase();
        const product = (window.allProducts || []).find(p => 
            (p.sku && p.sku.toLowerCase() === searchQ) ||
            (p.name && p.name.toLowerCase() === searchQ)
        );

        if (product) {
            if (window.directAddToPOSBill) {
                window.directAddToPOSBill(product.docId);
            } else {
                window.addToPOSBill(product.docId); // Fallback
            }
            window.showToast(`✅ Added to POS: ${product.name}`, "success");
            const sound = document.getElementById('sound-pos-save');
            if (sound) sound.play().catch(() => {});
        } else {
            window.showToast("❌ Product code not recognized", "warning");
        }
     }
};

// --- Inline POS Auto-Scanner Logic ---
let inlineHtml5QrCode = null;
let isInlineScannerRunning = false;

window.startInlineAutoScan = async () => {
    const wrap = document.getElementById('pos-inline-scanner-preview-wrap');
    if (!wrap) return;

    if (isInlineScannerRunning) return;

    wrap.style.display = 'block';
    if (!inlineHtml5QrCode) {
        inlineHtml5QrCode = new Html5Qrcode("pos-inline-scanner-reader");
    }

    const config = {
        fps: 24,
        aspectRatio: 1.0
    };

    try {
        await inlineHtml5QrCode.start(
            { facingMode: "environment" },
            config,
            (decodedText) => {
                const q = decodedText.trim();
                const sound = document.getElementById('sound-pos-save');
                if (sound) sound.play().catch(() => {});
                window.handleInlineScanResult(q);
            }
        );
        isInlineScannerRunning = true;
        console.log("Inline Auto-Scan active.");
    } catch (err) {
        console.error("Inline Auto-Scan Error:", err);
        wrap.style.display = 'none';
    }
};

window.stopInlineAutoScan = async () => {
    if (!isInlineScannerRunning) return;

    const wrap = document.getElementById('pos-inline-scanner-preview-wrap');
    if (inlineHtml5QrCode && inlineHtml5QrCode.isScanning) {
        try {
            await inlineHtml5QrCode.stop();
        } catch (err) {
            console.error("Error stopping inline scanner:", err);
        }
    }
    if (wrap) wrap.style.display = 'none';
    isInlineScannerRunning = false;
    console.log("Inline Auto-Scan stopped.");
};

window.togglePOSAutoScanSetting = (enabled) => {
    localStorage.setItem('mec_pos_auto_scan', enabled ? 'true' : 'false');
    if (enabled) {
        window.showToast("📷 Auto-Scanner enabled! It will start automatically when opening POS terminal.", "success");
        // Start immediately if we are currently on the POS tab
        if (window.currentActiveTab === 'pos') {
            window.startInlineAutoScan();
        }
    } else {
        window.showToast("✅ Auto-Scanner disabled.", "info");
        window.stopInlineAutoScan();
    }
};

window.handleInlineScanResult = (q) => {
    const cleanQ = q.trim();
    if (!cleanQ) return;

    const lowerQ = cleanQ.toLowerCase();
    
    // 1. Try to match a product SKU/barcode
    const product = (window.allProducts || []).find(p => 
        (p.sku && p.sku.toLowerCase() === lowerQ) ||
        (p.name && p.name.toLowerCase() === lowerQ)
    );

    if (product) {
        if (window.addToPOSBill) {
            if (window.directAddToPOSBill) {
                window.directAddToPOSBill(product.docId);
            } else {
                window.addToPOSBill(product.docId);
            }
            window.showToast(`✅ Added to POS: ${product.name}`, "success");
        }
        return;
    }

    // 2. Try to match a customer (phone / loyalty card)
    const customer = (window.allCustomers || []).find(c => {
        const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
        const qClean = lowerQ.replace(/\s/g, '');
        const cPhoneNormalized = cPhone.replace(/^0/, '');
        const qCleanNormalized = qClean.replace(/^0/, '');

        const phoneMatch = (cPhone === qClean) || 
                           (cPhoneNormalized === qCleanNormalized) ||
                           (cPhone.endsWith(qClean) && qClean.length >= 9) || 
                           (cPhoneNormalized.startsWith(qCleanNormalized) && qCleanNormalized.length >= 7);
                           
        const cardMatch = (c.loyaltyCardNo && c.loyaltyCardNo.toLowerCase() === lowerQ);
        
        return phoneMatch || cardMatch;
    });

    if (customer) {
        const phoneInput = document.getElementById('pos-cust-phone');
        if (phoneInput) {
            phoneInput.value = customer.loyaltyCardNo || customer.phone || cleanQ;
        }
        window.lookupPOSCustomer(customer.loyaltyCardNo || customer.phone || cleanQ);
        return;
    }

    window.showToast(`❌ Scanned code not recognized: ${cleanQ}`, "warning");
};

// --- UI Helper Logic ---
window.openModal = (id) => {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent background scroll
    }
};

window.closeModal = (id) => {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto'; // Restore scroll
    }
};

// Close modals when clicking outside
window.onclick = (event) => {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};
// Maintain compatibility between modules and old global-based receipt logic
Object.defineProperty(window, 'currentPOSBill', {
    get: function() {
        if (typeof window.getActiveBill === 'function') {
            const bill = window.getActiveBill();
            return (bill && bill.items) ? bill.items : [];
        }
        return [];
    },
    configurable: true
});
import { signInWithEmailAndPassword } from "firebase/auth";
import {
    collection,
    onSnapshot,
    doc,
    updateDoc,
    deleteDoc,
    addDoc,
    query,
    orderBy,
    where,
    limit,
    serverTimestamp,
    getDocs,
    getDoc,
    setDoc,
    writeBatch,
    Timestamp
} from "firebase/firestore";

window.applyLowEndOptimizations = () => {
    const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
    if (isLowEnd) {
        document.body.classList.add('low-end-mode');
        console.log("⚡ Low-End Performance Optimizations Applied (Blurs, Shadows & Animations disabled)");
    } else {
        document.body.classList.remove('low-end-mode');
    }
};

// --- Requirement: Sync Updates & Clean Session ---
window.addEventListener('DOMContentLoaded', () => {
    window.applyLowEndOptimizations();
    // 1. Instantly ensure splash screen doesn't block interactions after a short grace period
    const splash = document.getElementById('splash-screen');
    if (splash) {
        // [v3.12.50] Safety: Force hide splash faster to prevent non-responsive UI
        setTimeout(() => {
            splash.style.transition = 'opacity 0.4s ease-out';
            splash.style.opacity = '0';
            splash.style.pointerEvents = 'none';
            setTimeout(() => {
                splash.style.display = 'none';
                
                // [BACKUP] Trigger Daily Automated Backup
                if (typeof initAutoBackup === 'function') initAutoBackup();

                // [NEW] Auto-focus the login input after splash hides
                const loginSection = document.getElementById('login-section');
                const adminEmailField = document.getElementById('login-email');
                if (loginSection && loginSection.style.display !== 'none' && adminEmailField) {
                    adminEmailField.focus();
                }
            }, 400);
        }, 300); // 300ms is enough for initial paint
    }

    window.manualSyncFirestore = async () => {
        if (!navigator.onLine) {
            window.showToast("❌ Offline Mode: Cannot manual sync right now!", "error");
            return;
        }
        window.showToast("📡 Starting manual synchronization...", "info");
        try {
            const { waitForPendingWrites } = await import("firebase/firestore");
            await waitForPendingWrites(db);
            window.showToast("✅ Manual Sync Successful! All local data uploaded.", "success");
        } catch (err) {
            console.error(err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        }
    };

    // --- Connectivity Management ---
    let firestoreIsReachable = true;
    
    // Connectivity health check throttled to avoid noise
    const checkFirestoreHealth = async () => {
        if (!navigator.onLine) {
            firestoreIsReachable = false;
            updateConnectivityStatus();
            return;
        }
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2500); // 2.5 seconds timeout
        
        try {
            // Ping own domain to verify active internet connectivity
            await fetch('/csharp_version.json', { 
                mode: 'no-cors', 
                signal: controller.signal,
                cache: 'no-store'
            });
            firestoreIsReachable = true;
        } catch (e) {
            firestoreIsReachable = false;
        } finally {
            clearTimeout(timeoutId);
        }
        updateConnectivityStatus();
    };

    const updateConnectivityStatus = () => {
        const statusDiv = document.getElementById('conn-status');
        const statusText = document.getElementById('conn-text');
        if (!statusDiv || !statusText) return;

        if (!statusDiv.onclick) {
            statusDiv.onclick = window.manualSyncFirestore;
            statusDiv.title = "Click to manually upload local data to cloud";
            statusDiv.style.cursor = "pointer";
        }

        // True "Online" means navigator says yes AND Firestore is reachable
        if (navigator.onLine && firestoreIsReachable) {
            statusDiv.classList.remove('offline');
            statusDiv.classList.add('online');
            statusText.innerText = 'Cloud Online';
            if (window._wasOffline) {
                window.showToast("☁️ Back Online: Syncing changes...", "success");
                window._wasOffline = false;
            }
        } else {
            statusDiv.classList.remove('online');
            statusDiv.classList.add('offline');
            statusText.innerText = navigator.onLine ? 'Backend Lagging' : 'Offline Mode';
            
            if (!window._wasOffline) {
                if (!navigator.onLine) {
                    window.showToast("🔌 Offline: Working on Local Buffer", "warning");
                } else {
                    window.showToast("⏳ Sync Delay: Cloud unreachable", "info");
                }
                window._wasOffline = true;
            }
        }
    };

    window.addEventListener('online', () => { 
        updateConnectivityStatus(); 
        checkFirestoreHealth(); 
    });
    window.addEventListener('offline', () => {
        firestoreIsReachable = false;
        updateConnectivityStatus();
    });
    
    // Run initial and periodic health checks
    updateConnectivityStatus();
    checkFirestoreHealth();
    setInterval(checkFirestoreHealth, 10000); // Check every 10 seconds

    // --- Initialize Domain Modules (Safe Execution) ---
    try {
        initSystemBroadcastListener();
        if (typeof window.initSystem === 'function') window.initSystem();
        if (typeof window.initTheme === 'function') window.initTheme();
        if (typeof window.initAuth === 'function') window.initAuth();
        if (typeof window.initPromotions === 'function') window.initPromotions();
        if (typeof window.initInventory === 'function') window.initInventory();
        if (typeof window.initOrders === 'function') window.initOrders();
        if (typeof window.initFinance === 'function') window.initFinance();
        if (typeof window.initBankManager === 'function') window.initBankManager();
        if (typeof window.initPOS === 'function') window.initPOS();
        if (typeof window.initRepairs === 'function') window.initRepairs();
        if (typeof window.initReports === 'function') window.initReports();
        if (typeof window.initMRP === 'function') window.initMRP();
        if (typeof window.initHRM === 'function') window.initHRM();
        if (typeof window.initSupplyChain === 'function') window.initSupplyChain();
        initReloadModule(); // [FIXED] Initialize Reload Terminal listeners
        if (typeof window.loadSystemSettings === 'function') window.loadSystemSettings();

        // [NEW] Default all date inputs to today if empty
        const today = window.getLocalYYYYMMDD();
        document.querySelectorAll('input[type="date"]').forEach(input => {
            if (!input.value) input.value = today;
        });

        // [NEW] Initialize Desktop Window Controls for Admin Header
        const isDesktopApp = !!window.electron || !!window.electronAPI || !!window.chrome?.webview;
        if (isDesktopApp) {
            const winControls = document.getElementById('win-controls');
            const navBrand = document.querySelector('.admin-nav .nav-brand');
            if (winControls) {
                winControls.style.display = 'flex';
            }
            if (navBrand) {
                navBrand.style.marginTop = '1.5rem';
            }
        }
        document.getElementById('btn-close')?.addEventListener('click', () => {
            if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'close' });
            else if (window.electronAPI) window.electronAPI.close?.();
            else if (window.electron) window.electron.close?.();
        });
        document.getElementById('btn-minimize')?.addEventListener('click', () => {
            if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'minimize' });
            else if (window.electronAPI) window.electronAPI.minimize?.();
            else if (window.electron) window.electron.minimize?.();
        });

        // Deep Diagnostics for Sync Issues (Silent Background Mode)
        setTimeout(async () => {
            const prodSize = window.allProducts ? window.allProducts.length : 0;
            const orderSize = window.allOrders ? window.allOrders.length : 0;
            const branchSize = window.allBranches ? window.allBranches.length : 0;
            
            console.log("📊 SYNC REPORT:", { products: prodSize, orders: orderSize, branches: branchSize });
            
            // Collection Scanner
            const { getDocs, collection } = await import('firebase/firestore');
            ['products', 'orders', 'branches', 'employees', 'stores', 'pos-orders', 'web-orders'].forEach(c => {
                getDocs(collection(db, c)).then(s => {
                    console.log(`🔍 COLLECTION [${c}]: ${s.size} documents found.`);
                }).catch(e => console.error(`❌ FAILED TO SCAN [${c}]:`, e.message));
            });

            // Multi-Project Scanner (Deep Recovery)
            const projects = ['mec-book-shop', 'mec-platform-saas', 'mec-pos-center', 'mec-pos-shop'];
            const { initializeApp } = await import('firebase/app');
            const { getFirestore } = await import('firebase/firestore');

            projects.forEach(pId => {
                try {
                    const tempApp = initializeApp({ 
                        apiKey: "AIzaSyCFGweYcgmcfP5zS6M1ytOfKYKUbHfsols",
                        authDomain: `${pId}.firebaseapp.com`,
                        projectId: pId 
                    }, `temp-${pId}`);
                    const tempDb = getFirestore(tempApp);
                    getDocs(collection(tempDb, 'products')).then(s => {
                        console.log(`📡 SCAN [${pId}]: ${s.size} products found.`);
                        if (s.size > 0) {
                            localStorage.setItem('RECOVERY_PROJECT_ID', pId);
                        }
                    }).catch(e => console.log(`SCAN SILENT: ${pId} skipped.`));
                } catch (e) {}
            });
        }, 5000);
    } catch (e) {
        console.error("🏁 Startup Initialization Error:", e);
        // Force hide splash on critical fail so user can at least see the page
        const s = document.getElementById('splash-screen');
        if (s) s.style.display = 'none';
    }
});

// --- Global Error Capture for Debugging ---
window.addEventListener('error', (e) => {
    console.error("CRITICAL RUNTIME ERROR:", e.error);
    if (window.showToast) {
        window.showToast("⚠️ System Error: " + (e.error?.message || "Internal Crash"), "error");
    }
});

// --- Admin PWA & Session Protection ---
let deferredPrompt;
const installBtn = document.createElement('div');
installBtn.id = 'admin-install-banner';
installBtn.innerHTML = `
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:#002060; color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: adminSlideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC Admin</div>
            <div style="font-size:0.75rem; opacity:0.9;">Separate app for orders & stock</div>
        </div>
        <button id="pwa-close-admin" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes adminSlideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;
installBtn.style.display = 'none';
document.body.appendChild(installBtn);

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.style.display = 'block';
});

installBtn.addEventListener('click', async (e) => {
    if (e.target.id === 'pwa-close-admin') {
        installBtn.style.display = 'none';
        return;
    }
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') installBtn.style.display = 'none';
        deferredPrompt = null;
    }
});

// --- Notification Toast Utility ---
let lastToastTime = 0;
let lastToastMessage = "";

window.showToast = (message, type = 'info') => {
    const now = Date.now();
    if (now - lastToastTime < 1000 && lastToastMessage === message) return;
    lastToastTime = now;
    lastToastMessage = message;

    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast admin-notif ${type}`;
    let icon = '🔔';
    let text = message;
    const emojiMatch = message.match(/^([\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27BF])/);
    if (emojiMatch) {
        icon = emojiMatch[0];
        text = message.replace(icon, '').trim();
    }

    toast.innerHTML = `
        <span class="toast-icon">${icon}</span>
        <span class="toast-message">${text}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 5000);
};

// --- Custom Prompt & Confirmation Modal (Electron/Premium Compat) ---
window.asyncPrompt = (message, title = "Security Verification", inputType = "password", defaultValue = "") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.id = 'mec-custom-modal-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:400px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#38bdf8; margin-bottom:0.5rem; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-shield-halved"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.5rem; line-height:1.5;">${message}</div>
            <input type="${inputType}" id="mec-modal-input" value="${defaultValue}" placeholder="Enter details..." style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:1.5rem; outline:none; focus:border:#38bdf8;">
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="modal-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600; transition:0.2s;">Cancel</button>
                <button id="modal-ok" style="background:linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%); color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(37,99,235,0.3);">Continue <i class="fa-solid fa-arrow-right" style="margin-left:5px; font-size:0.8rem;"></i></button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        // Animation
        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        });

        const input = document.getElementById('mec-modal-input');
        const ok = document.getElementById('modal-ok');
        const cancel = document.getElementById('modal-cancel');

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        ok.onclick = () => finish(input.value);
        cancel.onclick = () => finish(null);
        input.onkeydown = (e) => { 
            if(e.key === 'Enter') ok.click();
            if(e.key === 'Escape') cancel.click();
        };
        input.focus();
    });
};

window.asyncAuthPrompt = (message, title = "Admin Required") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.id = 'mec-auth-prompt-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:400px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid #ef4444; transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#ef4444; margin-bottom:0.5rem; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-lock"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.5rem; line-height:1.5;">${message}</div>
            <input type="text" id="mec-auth-user" placeholder="Username (e.g. admin@mec.lk)" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:0.8rem; outline:none; focus:border:#ef4444;">
            <input type="password" id="mec-auth-pass" placeholder="Password" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:1.5rem; outline:none; focus:border:#ef4444;">
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="auth-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600; transition:0.2s;">Cancel</button>
                <button id="auth-ok" style="background:linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(239,68,68,0.3);">Verify & Execute</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
            document.getElementById('mec-auth-user').focus();
        });

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        const submitAuth = () => {
            const user = document.getElementById('mec-auth-user').value.trim();
            const pass = document.getElementById('mec-auth-pass').value;
            finish({ user, pass });
        };

        document.getElementById('auth-ok').onclick = submitAuth;
        document.getElementById('auth-cancel').onclick = () => finish(null);
        document.getElementById('mec-auth-pass').onkeydown = (e) => { if (e.key === 'Enter') submitAuth(); };
    });
};


window.asyncConfirm = (message, title = "Verification Required") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:400px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#ef4444; margin-bottom:0.5rem;"><i class="fa-solid fa-triangle-exclamation"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.5rem; line-height:1.5;">${message}</div>
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="conf-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600;">Cancel</button>
                <button id="conf-ok" style="background:#ef4444; color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(239,68,68,0.3);">Confirm Delete</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        });

        const ok = document.getElementById('conf-ok');
        const cancel = document.getElementById('conf-cancel');

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        ok.onclick = () => finish(true);
        cancel.onclick = () => finish(false);
        overlay.onclick = (e) => { if (e.target === overlay) cancel.click(); };
    });
};


// --- Admin Credentials moved to auth.js ---

const loginSection = document.getElementById('login-section');
const adminActions = document.getElementById('admin-actions');
const productListDiv = document.getElementById('admin-product-list');

const productsCol = collection(db, 'products');
const ordersCol = collection(db, 'orders');
const categoriesCol = collection(db, 'categories');
const expensesCol = collection(db, 'expenses');
const purchasesCol = collection(db, 'purchases');
const suppliersCol = collection(db, 'suppliers');
const incomeCol = collection(db, 'income');
const customersCol = collection(db, 'customers');
const employeesCol = collection(db, 'employees');
const attendanceCol = collection(db, 'attendance');
const payrollCol = collection(db, 'payroll');
const branchesCol = collection(db, 'branches');
const storesCol = collection(db, 'stores');
const repairJobsCol = collection(db, 'repairJobs');
const sinvoicesCol = collection(db, 'supplierInvoices');

let activeBranchFilter = 'All'; // Moved up to prevent RefError during snap load

window.currentInvoiceItems = [];
window.allSupplierInvoices = [];



// --- ERP System Logging ---
window.logAction = async (action, details = "") => {
    try {
        const storeId = window.getStoreId();
        const user = sessionStorage.getItem('userEmail') || 'Unknown';
        const role = sessionStorage.getItem('userRole') || 'None';
        
        await addDoc(collection(db, 'systemLogs'), {
            timestamp: serverTimestamp(),
            action,
            details,
            user,
            role,
            storeId,
            clientVersion: CLIENT_VERSION
        });
        
        // Update IT logs if visible
        const logContainer = document.getElementById('it-activity-logs');
        if (logContainer) {
            const entry = document.createElement('div');
            entry.style.padding = '0.75rem';
            entry.style.borderBottom = '1px solid #e2e8f0';
            entry.style.fontSize = '0.85rem';
            entry.innerHTML = `<span style="color:var(--primary-blue); font-weight:700;">[${new Date().toLocaleTimeString()}]</span> ${user} (${role}): <b>${action}</b> ${details}`;
            logContainer.prepend(entry);
        }
    } catch (e) { console.error("Log error:", e); }
};

// Global Security Check for Deletions
// Global Security Check for Deletions
// [v3.12.27] Enhanced: Soft-delete by default, Permanent only for SuperAdmin
window.verifyDeletePermission = async (docRef = null, softDeleteData = { status: 'Voided', isVoid: true }) => {
    const auth = await window.asyncAuthPrompt("Authorization required to remove this record.", "Security Verification");
    if (!auth) return false;

    // Resolve target store ID of the document
    let targetStoreId = null;
    if (docRef) {
        try {
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                targetStoreId = docSnap.data().storeId;
            }
        } catch (e) {
            console.error("Error fetching doc for storeId check:", e);
        }
    }
    if (!targetStoreId) {
        targetStoreId = window.getStoreId();
    }

    const userLower = auth.user.toLowerCase().trim();
    const passTrimmed = auth.pass.trim();

    const isSuperAdmin = (
        ( (userLower === 'malinduec@gmail.com' || userLower === 'malindu' || userLower === 'admin') && passTrimmed === 'malindu123' ) ||
        ( (userLower === 'mecposadmin@gmail.com' || userLower === 'admin' || userLower === 'admin@mec.lk') && passTrimmed === 'mecpos123' ) ||
        passTrimmed === 'malindu123' || passTrimmed === 'mecpos123' // Also allow just the master password
    );

    // MEC Book Shop CEO credentials: username: mecbookshop@gmail.com, pass: mec123
    const isMecCeo = ( (userLower === 'mecbookshop@gmail.com' || userLower === 'mecbookshop' || userLower === 'admin' || userLower === '') && passTrimmed === 'mec123' );
    const isMecStore = !targetStoreId || targetStoreId === 'mec-book-shop' || targetStoreId === 'mec-pos-shop' || targetStoreId === 'mec-pos' || targetStoreId === 'mec-pos-shop-v2';
    const isAuthorizedMecCeo = isMecCeo && isMecStore;

    // D & J Online Marketing CEO credentials: username: ireshadinali@gmail.com, pass: ireshadinali123
    const isDJCeo = ( (userLower === 'ireshadinali@gmail.com' || userLower === 'iresha' || userLower === 'admin') && passTrimmed === 'ireshadinali123' );
    const isDJStore = targetStoreId && (
        targetStoreId === 'd-and-j-online-marketing' ||
        targetStoreId === 'd-j-online-marketing' ||
        targetStoreId === 'd-and-j-online-mart' ||
        targetStoreId.includes('d-and-j') ||
        targetStoreId.includes('d-j') ||
        targetStoreId.includes('iresha') ||
        targetStoreId.includes('marketing')
    );
    const isAuthorizedDJCeo = isDJCeo && isDJStore;

    const isAuthorizedCeo = isAuthorizedMecCeo || isAuthorizedDJCeo;

    const isManager = (passTrimmed === 'mec123'); // Support legacy mec123 as manager pass

    const staff = (window.allEmployees || []).find(e => 
        (e.username?.toLowerCase().trim() === userLower || e.email?.toLowerCase().trim() === userLower) && 
        e.password === passTrimmed
    );

    if (isSuperAdmin || isAuthorizedCeo) {
        // Super Admin / Authorized CEO: Give choice of Hard Delete vs Soft Delete
        let operatorInfo = isSuperAdmin ? "SUPER ADMIN" : "CEO";
        if (isSuperAdmin) {
            operatorInfo = auth.user.toLowerCase() === 'malinduec@gmail.com' ? "System Admin (Malindu)" : "MEC POS Admin";
        } else if (isAuthorizedMecCeo) {
            operatorInfo = "MEC Owner (MEC Book Shop)";
        } else if (isAuthorizedDJCeo) {
            operatorInfo = "D&J Owner (Iresha)";
        } else if (staff) {
            operatorInfo = `${staff.role_access} (${staff.name})`;
        }
        const confirmMsg = `🚨 ${operatorInfo.toUpperCase()} DETECTED\n\nType 'DELETE' to permanently remove from database.\nLeave blank or type 'VOID' to just hide (Soft Delete):`;
        const choice = await window.asyncPrompt(confirmMsg, "Permanent Delete Confirmation", "text");
        
        if (choice && choice.trim().toUpperCase() === 'DELETE') {
            return true; // Return true to let the caller run deleteDoc()
        } else {
            // Soft delete instead
            if (docRef) {
                window.showToast("⏳ Voiding record instead of deletion...", "info");
                await updateDoc(docRef, { 
                    ...softDeleteData, 
                    voidedBy: auth.user, 
                    voidedAt: serverTimestamp(),
                    updatedAt: serverTimestamp() 
                });
                window.showToast("✅ Record has been VOIDED.", "success");
            }
            return false; // Return false to stop caller from running deleteDoc()
        }
    } else if (isManager) {
        // Manager: ONLY Soft Delete allowed
        if (docRef) {
            window.showToast("⏳ Voiding record...", "info");
            await updateDoc(docRef, { 
                ...softDeleteData, 
                voidedBy: auth.user || 'Manager', 
                voidedAt: serverTimestamp(),
                updatedAt: serverTimestamp() 
            });
            window.showToast("✅ Record has been VOIDED (Only Super Admin / Store CEO can hard delete).", "success");
        } else {
            window.showToast("❌ Permanent delete restricted to Super Admin or Store CEO.", "error");
        }
        return false; // Return false to stop caller from running deleteDoc()
    }

    window.showToast("❌ Unauthorized Credentials!", "error");
    return false;
};

// --- Theme Logic extracted to src/modules/theme.js ---

// Helper to filter data by current store
window.filterByStore = (list) => {
    const storeId = window.getStoreId();
    if (!list) return [];
    
    // Explicitly allow main MEC slugs to see data without a storeId (backward compatibility)
    const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'mec-pos-shop-v2');
    
    const filtered = list.filter(item => {
        if (storeId === 'master') return true; // Master account sees everything
        return (item.storeId === storeId) || 
               (isMainMec && (!item.storeId || item.storeId === 'mec-book-shop' || item.storeId === 'mec-pos-shop' || item.storeId === 'mec-pos' || item.storeId === 'mec-pos-shop-v2'));
    });
    
    if (list.length > 0 && filtered.length === 0) {
        console.warn(`Filter active: ${list.length} total items, 0 visible for store: ${storeId}`);
    }
    
    return filtered;
};

// --- Branding Logic extracted to system.js ---

// [FIX] Removed duplicate unfiltered employees snapshot listener to prevent cross-tenant data leak.
// All employee listening and filtering is consolidated inside modules/auth.js.




window.currentInvoiceItems = window.currentInvoiceItems || []; // Ensure initialization

// Consolidated Supplier Item Modal controls moved to Supplier Invoice section (line 5370+)


window._adminProductLetterFilter = ''; // Globalization for alphabet filter

// --- Admin Theme Logic extracted to theme module ---

// --- UI Versioning moved to system.js ---

document.addEventListener('DOMContentLoaded', () => {
    // UI Version and Branding handled by system.js
    
    // Add Enter key listener for Login
    const loginEmail = document.getElementById('login-email');
    const loginPass = document.getElementById('login-password');
    const loginBtn = document.getElementById('login-btn');

    const handleEnter = (e) => {
        if (e.key === 'Enter') {
            loginBtn?.click();
        }
    };

    loginEmail?.addEventListener('keydown', handleEnter);
    loginPass?.addEventListener('keydown', handleEnter);

    // Clock logic is now running independently inside admin.html

    // Re-apply saved theme
    // (Handled by theme module)
});

// --- Auth Listeners and RBAC extracted to auth.js ---

    // Immediately apply cached store branding and subscription details if available
    const cachedStoreId = sessionStorage.getItem('userStoreId') || sessionStorage.getItem('tempStoreSlug') || 'mec-book-shop';
    
    // Load from C# Native Wrapper cache for instant loading without being affected by WebView clear cache
    loadOfflineCache(`storeInfo_${cachedStoreId}`).then(cachedStore => {
        if (cachedStore) {
            window.storeInfo = cachedStore;
            const brandName = cachedStore.name || 'MEC BOOK SHOP';
            
            // Update Text
            document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
                el.innerText = brandName;
            });

            if (cachedStore.logoUrl) {
                document.querySelectorAll('.nav-brand img, .login-header img, #admin-install-banner img').forEach(img => {
                    img.src = cachedStore.logoUrl;
                });
            }

            // Update Sidebar Subscription Info
            if (typeof window.updateSidebarSubscription === 'function') {
                window.updateSidebarSubscription(cachedStore);
            }
        }
    });

    // Load Stores
    onSnapshot(storesCol, (snapshot) => {
        const stores = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allStores = stores;
        renderStoresUI(stores);

        // Dynamic branding for entire panel
        const currentStoreId = window.getStoreId();
        let storeInfo = stores.find(s => s.slug === currentStoreId);
        
        if (!storeInfo && (currentStoreId === 'mec-book-shop' || currentStoreId === 'mec-pos-shop' || currentStoreId === 'master' || !currentStoreId)) {
            storeInfo = stores.find(s => s.slug === 'mec-pos-shop' || s.slug === 'mec-book-shop');
            if (!storeInfo) storeInfo = stores[0];
        }

        if (storeInfo) {
            if (storeInfo.slug === 'mec-book-shop' || storeInfo.slug === 'mec-pos-shop' || !storeInfo.slug) {
                if (!storeInfo.logoUrl || storeInfo.logoUrl.includes('/logo.png') || storeInfo.logoUrl.includes('zenith_logo')) {
                    storeInfo.logoUrl = '/mec-logo.png';
                }
                if (!storeInfo.name) {
                    storeInfo.name = 'MEC Book Shop';
                }
            }

            window.storeInfo = storeInfo;
            const brandName = storeInfo.name || 'MEC BOOK SHOP';
            
            // Dynamic Merchant Company Name in Sidebar Header
            document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
                el.innerText = brandName;
            });

            // App Software Logo fixed in Sidebar (.nav-brand img)
            document.querySelectorAll('.nav-brand img').forEach(img => {
                img.src = '/pos-logo.png';
            });

            const effectiveLogo = (storeInfo.logoUrl && !storeInfo.logoUrl.includes('/logo.png') && !storeInfo.logoUrl.includes('zenith_logo')) 
                ? storeInfo.logoUrl 
                : '/mec-logo.png';

            document.querySelectorAll('.login-header img, #admin-install-banner img').forEach(img => {
                img.src = effectiveLogo;
            });

            // Update Sidebar Subscription Info
            if (typeof window.updateSidebarSubscription === 'function') {
                window.updateSidebarSubscription(storeInfo);
            }

            // Update Header Website Button URL dynamically
            const webBtn = document.getElementById('header-website-btn');
            if (webBtn) {
                const webUrl = (typeof window.getStoreWebsiteUrl === 'function') 
                    ? window.getStoreWebsiteUrl(storeInfo) 
                    : (storeInfo.domain ? `https://${storeInfo.domain}` : (storeInfo.slug === 'mec-book-shop' || !storeInfo.slug ? 'https://mecbookshop.web.lk' : `https://mecpos.web.lk/store/${storeInfo.slug}`));
                webBtn.href = webUrl;
                webBtn.title = `Website: ${webUrl}`;
                webBtn.onclick = (e) => {
                    e.preventDefault();
                    if (typeof window.openStoreWebsite === 'function') {
                        window.openStoreWebsite(storeInfo);
                    } else if (typeof window.openExternalUrl === 'function') {
                        window.openExternalUrl(webUrl);
                    } else {
                        window.open(webUrl, '_blank');
                    }
                };
            }
        }
    });

    // Branches and Stores are still managed here as they are global
    const storeId = window.getStoreId();
    const isMaster = storeId === 'master';

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    threeMonthsAgo.setHours(0,0,0,0);
    const threeMonthsAgoTimestamp = Timestamp.fromDate(threeMonthsAgo);

    const branchQ = isMaster ? branchesCol : query(branchesCol, where('storeId', '==', storeId));
    const categoriesQ = isMaster ? categoriesCol : query(categoriesCol, where('storeId', '==', storeId));
    const suppliersQ = isMaster ? suppliersCol : query(suppliersCol, where('storeId', '==', storeId));
    const customersQ = isMaster ? customersCol : query(customersCol, where('storeId', '==', storeId));

    // Limit transactional queries to past 3 months
    const attendanceQ = isMaster ?
        query(attendanceCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(attendanceCol, where('storeId', '==', storeId));
    const payrollQ = isMaster ?
        query(payrollCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(payrollCol, where('storeId', '==', storeId));
    const purchasesQ = isMaster ?
        query(purchasesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(purchasesCol, where('storeId', '==', storeId));
    const incomeQ = isMaster ?
        query(incomeCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(incomeCol, where('storeId', '==', storeId));
    const sinvoicesQ = isMaster ?
        query(sinvoicesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(sinvoicesCol, where('storeId', '==', storeId));

    const filterPastThreeMonths = (rawList) => {
        return rawList.filter(item => {
            const timeSecs = item.timestamp?.seconds || 0;
            return timeSecs >= threeMonthsAgoTimestamp.seconds;
        });
    };
    
    // Activity logs query: limit 100 per store, sorted client-side to prevent composite index errors
    const logsQuery = isMaster ? 
        query(collection(db, 'systemLogs'), orderBy("timestamp", "desc"), limit(100)) :
        query(collection(db, 'systemLogs'), where('storeId', '==', storeId), limit(100));

    onSnapshot(branchQ, (snapshot) => {
        const branches = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allBranches = branches;
        renderBranchesUI(branches);
        populateBranchDropdowns(branches);
        updateUserDisplay();
    });

    // NOTE: Products and Orders listeners are now managed in inventory.js and orders.js 
    // to avoid duplicate subscriptions and state conflicts. Logic for POS numbering 
    // and notifications is also centralized in the respective modules.

    onSnapshot(attendanceQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allAttendance = isMaster ? raw : filterPastThreeMonths(raw);
        syncAttendanceUI();
    });

    onSnapshot(payrollQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allPayroll = isMaster ? raw : filterPastThreeMonths(raw);
        renderAdminPayrollUI(window.allPayroll);
    });

    onSnapshot(categoriesQ, (snapshot) => {
        const categories = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allCategories = categories;
        renderCategoriesUI(categories);
        populateCategoryDropdowns(categories);
    });

    onSnapshot(purchasesQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allPurchases = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => renderPurchasesUI(window.allPurchases));
    });

    onSnapshot(suppliersQ, (snapshot) => {
        const suppliers = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id, id: doc.id }));
        window.allSuppliers = suppliers;
        requestAnimationFrame(() => {
            renderSuppliersUI(suppliers);
            if (window.populateSupplierInvoicesDropdown) window.populateSupplierInvoicesDropdown();
        });
    });

    onSnapshot(incomeQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allIncome = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => {
            renderIncomeUI(window.allIncome);
            if (window.allOrders && typeof window.generateReports === 'function') window.generateReports(window.allOrders);
        });
    });

    onSnapshot(sinvoicesQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allSupplierInvoices = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => {
            if (typeof window.renderSupplierInvoicesUI === 'function') window.renderSupplierInvoicesUI(window.allSupplierInvoices);
            if (typeof window.renderSupplierOverview === 'function') window.renderSupplierOverview();
            renderPurchasesUI(); // Keep Purchase History tab in sync
        });
    });

    onSnapshot(customersQ, (snapshot) => {
        const customers = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allCustomers = customers; 
        if (typeof window.renderCustomersUI === 'function') window.renderCustomersUI(customers);
        if (typeof window.renderCreditLedgerUI === 'function') window.renderCreditLedgerUI();
    });

    initReloadModule();

    // IT System Logs Listener
    onSnapshot(logsQuery, (snapshot) => {
        const logContainer = document.getElementById('it-activity-logs');
        if (!logContainer) return;
        
        // Sort logs client-side by timestamp descending to support both filtered and master queries
        const sortedDocs = [...snapshot.docs].sort((a, b) => {
            const timeA = a.data().timestamp?.seconds || 0;
            const timeB = b.data().timestamp?.seconds || 0;
            return timeB - timeA;
        });

        logContainer.innerHTML = sortedDocs.map(doc => {
            const data = doc.data();
            const time = data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleTimeString() : '...';
            const date = data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : '';
            return `
                <div style="padding: 0.75rem; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; border-left: 3px solid ${data.role === 'Admin' ? '#ef4444' : '#3b82f6'};">
                    <span style="color:var(--text-muted); font-size:0.7rem;">${date} ${time}</span><br>
                    <span style="font-weight: 700; color: var(--primary-blue);">${data.user}</span> [${data.role}]: 
                    <b>${data.action}</b> ${data.details}
                </div>
            `;
        }).join('');
    });
  
// Global Collections Sync
onSnapshot(storesCol, (snapshot) => {
    const stores = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
    window.allStores = stores;
    if (typeof window.renderStoresUI === 'function') window.renderStoresUI(stores);

    const currentStoreId = window.getStoreId();
    let storeInfo = stores.find(s => s.slug === currentStoreId);
    
    if (!storeInfo && (currentStoreId === 'mec-book-shop' || currentStoreId === 'mec-pos-shop')) {
        storeInfo = stores.find(s => s.slug === 'mec-pos-shop' || s.slug === 'mec-book-shop') || stores[0];
    }

    if (storeInfo) {
        window.storeInfo = storeInfo;
        
        // Cache plan data locally for instant UI rendering on next startup
        try {
            const planDataStr = JSON.stringify(storeInfo);
            localStorage.setItem('mecpos_plan_cache', planDataStr);
            // Save to physical file via C# wrapper (user requested physical file save in app folder)
            if (window.chrome?.webview) {
                const unifiedCache = {
                    storeInfo: storeInfo,
                    systemConfig: window.systemConfig || {}
                };
                window.chrome.webview.postMessage({ type: 'savePlanConfig', data: JSON.stringify(unifiedCache) });
            }
        } catch (e) {
            console.warn("Failed to cache plan data", e);
        }

        const brandName = storeInfo.name || 'MEC BOOK SHOP';
        document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
            el.innerText = brandName;
        });
        
        // Also ensure UI is updated with this new cached data
        if (window.showAdminActions) window.showAdminActions();
        if (window.updateSidebarSubscription) window.updateSidebarSubscription(storeInfo);
        
        // Render favorites and modules from local cache immediately
        if (window.systemConfig) {
            const favs = window.systemConfig.favorites || ['pos', 'orders', 'web-orders', 'reload'];
            if (window.renderFavoritesSidebar) window.renderFavoritesSidebar(favs);
            if (window.renderFavoritesSettings) window.renderFavoritesSettings(favs);
            if (window.updateModulesVisibility && window.systemConfig.modules) {
                window.updateModulesVisibility(window.systemConfig.modules);
            }
        }
    }
});


// --- Modularized Data Listeners handled by domain init functions ---

// POS & Form Initializers
if (window.generatePOSReceiptNo) window.generatePOSReceiptNo();
if (window.handlePOSSearch) window.handlePOSSearch('');

const productForm = document.getElementById('product-form');
if (productForm) {
    productForm.onsubmit = async (e) => {
        e.preventDefault();
        if (window.addProduct) await window.addProduct(e);
    };
}
const editProductForm = document.getElementById('edit-product-form');
if (editProductForm) {
    editProductForm.onsubmit = async (e) => {
        e.preventDefault();
        if (window.updateProduct) await window.updateProduct(e);
    };
}

document.getElementById('bulk-upload-btn')?.addEventListener('click', (e) => window.handleBulkUpload?.(e));
document.getElementById('branch-form')?.addEventListener('submit', (e) => window.addBranch?.(e));
document.getElementById('store-form')?.addEventListener('submit', (e) => window.addStore?.(e));
document.getElementById('category-form')?.addEventListener('submit', (e) => window.addCategory?.(e));
document.getElementById('supplier-form')?.addEventListener('submit', (e) => window.addSupplier?.(e));

// Role-based visibility initialization
const currentRole = sessionStorage.getItem('userRole');
if (currentRole === 'SuperAdmin') {
    const storeTab = document.getElementById('tab-stores');
    if (storeTab) storeTab.style.display = 'block';
    const purgeBtn = document.getElementById('clear-all-staff-btn');
    if (purgeBtn) purgeBtn.style.display = 'block';
}
if (['Admin', 'SuperAdmin', 'CEO_Admin'].includes(currentRole)) {
    const selector = document.getElementById('branch-selector-wrapper');
    if (selector) selector.style.display = 'block';
}


// --- Order Filtering Logic extracted to modules/orders.js ---

// --- POS Auth Logic moved to auth.js ---

// --- Navigation Logic extracted to auth.js ---

// --- Branch Management Logic ---
window.addBranch = async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const name = document.getElementById('branch-name').value;
    const location = document.getElementById('branch-location').value;
    const phone = document.getElementById('branch-phone').value;

    try {
        addDoc(branchesCol, {
            name,
            location,
            phone,
            storeId: window.getStoreId(),
            createdAt: serverTimestamp()
        }).catch(err => {
            console.error("Firestore add branch error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        window.showToast(`Branch "${name}" created.`, "success");
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("Error creating branch.", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderBranchesUI(branches) {
    const list = document.getElementById('admin-branch-list');
    if (!list) return;
    const filtered = window.filterByStore(branches);
    list.innerHTML = filtered.length === 0 ? '<div class="empty-state" style="grid-column: 1/-1; padding: 2rem; color: #64748b; background: #fff; border-radius:12px; border:1px dashed #cbd5e1; text-align:center;">No branches added yet.</div>' : filtered.map(b => `
        <div class="col-card branch-card" style="padding: 1.5rem; background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 1rem;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h3 style="margin: 0; color: var(--primary-blue);">${b.name}</h3>
                    <p style="margin: 5px 0 0 0; color: #64748b; font-size: 0.9rem;">📍 ${b.location}</p>
                    <p style="margin: 2px 0 0 0; color: #64748b; font-size: 0.85rem;">📞 ${b.phone || 'N/A'}</p>
                </div>
                <button class="icon-btn delete" onclick="confirmDeleteBranch('${b.docId}')">🗑️</button>
            </div>
        </div>
    `).join('');
}

window.confirmDeleteBranch = async (docId) => {
    const docRef = doc(db, 'branches', docId);
    if (!await window.verifyDeletePermission(docRef, { isDeleted: true, status: 'Void' })) return;
    await deleteDoc(docRef);
    window.showToast("Branch removed.", "info");
}

function populateBranchDropdowns(branches) {
    const empBranchSelect = document.getElementById('emp-branch-id');
    const globalBranchSelect = document.getElementById('global-branch-selector');
    const filtered = window.filterByStore(branches);

    if (empBranchSelect) {
        empBranchSelect.innerHTML = '<option value="Global">Master/Main Office</option>' + filtered.map(b => `
            <option value="${b.docId}">${b.name}</option>
        `).join('');
    }

    if (globalBranchSelect) {
        const currentVal = globalBranchSelect.value;
        globalBranchSelect.innerHTML = '<option value="All">All Branches</option><option value="Global">Main Office</option>' + filtered.map(b => `
            <option value="${b.docId}">${b.name}</option>
        `).join('');
        globalBranchSelect.value = currentVal || 'All';
    }
}

// --- Category Management Logic ---
window.addCategory = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('cat-name').value.trim();
    if (!name) return;

    const submitBtn = e && e.target ? (e.target.querySelector('button[type="submit"]') || e.target.querySelector('button')) : null;
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Saving category...", "info");
        addDoc(categoriesCol, {
            name,
            storeId: window.getStoreId(),
            createdAt: serverTimestamp()
        }).catch(err => {
            console.error("Firestore add category error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        document.getElementById('cat-name').value = '';
        window.showToast(`✅ Category "${name}" added!`, "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving category", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderCategoriesUI(categories) {
    const list = document.getElementById('admin-category-list');
    if (!list) return;

    const filtered = window.filterByStore(categories);
    
    list.innerHTML = filtered.length === 0 ? '<p style="opacity:0.5; padding: 20px; text-align:center;">No categories yet.</p>' : `
        <div style="display: grid; gap: 10px;">
            ${filtered.map(cat => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding: 12px 18px; background: rgba(255,255,255,0.03); border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                    <span style="font-weight: 700; color: white;">${cat.name}</span>
                    <button class="icon-btn delete" onclick="window.deleteCategory('${cat.docId}')" style="opacity:0.6;">🗑️</button>
                </div>
            `).join('')}
        </div>
    `;
    
    // Alias for inventory module
    window.renderAdminCategoriesUI = renderCategoriesUI;
}

window.deleteCategory = async (id) => {
    const docRef = doc(db, 'categories', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    try {
            await deleteDoc(docRef);
            window.showToast("🗑️ Category removed.", "success");
        } catch (err) {
            console.error(err);
            window.showToast("Error deleting category", "error");
        }
    };

function populateCategoryDropdowns(categories) {
    const pCatSelect = document.getElementById('p-category');
    const editPCatSelect = document.getElementById('edit-p-category');
    const qaCatSelect = document.getElementById('qa-prod-category');
    const filtered = window.filterByStore(categories);

    const options = '<option value="">-- No Category --</option>' + 
        filtered.map(c => `<option value="${c.name}">${c.name}</option>`).join('');

    if (pCatSelect) pCatSelect.innerHTML = options;
    if (editPCatSelect) editPCatSelect.innerHTML = options;
    if (qaCatSelect) qaCatSelect.innerHTML = options;
}

window.renderCategoriesUI = renderCategoriesUI;
window.populateCategoryDropdowns = populateCategoryDropdowns;

// --- Store Management Logic (SaaS) ---
window.addStore = async (e) => {
    e.preventDefault();
    const name = document.getElementById('store-name').value;
    const owner = document.getElementById('store-owner').value;
    const phone = document.getElementById('store-phone').value;
    const address = document.getElementById('store-address').value;
    const slug = document.getElementById('store-slug').value.toLowerCase().replace(/\s+/g, '-');

    try {
        await addDoc(storesCol, {
            name, owner, phone, address, slug,
            status: 'active',
            createdAt: serverTimestamp()
        });
        window.showToast(`Store "${name}" provisioned successfully!`, "success");
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("Deployment failed.", "error");
    }
};

function renderStoresUI(stores) {
    const list = document.getElementById('admin-store-list');
    if (!list) return;
    list.innerHTML = stores.length === 0 ? '<p>No merchant stores found.</p>' : stores.map(s => `
        <div class="col-card store-card" style="padding: 1.5rem; background: #fff; border-bottom: 4px solid var(--primary-blue);">
            <div style="display:flex; justify-content:space-between; align-items:start;">
                <div>
                    <span class="status-badge" style="margin-bottom: 10px; background: #dcfce7; color: #166534;">Active</span>
                    <h3 style="margin: 5px 0; color: #0f172a;">${s.name}</h3>
                    <p style="margin: 0; color: #64748b; font-size: 0.9rem;">👤 Owner: ${s.owner}</p>
                    <p style="margin: 5px 0; color: #64748b; font-size: 0.85rem;">🔗 Slug: <strong>${s.slug}</strong></p>
                    <div style="margin-top: 15px; display: flex; gap: 8px; flex-wrap: wrap;">
                        <button class="secondary-action-btn" onclick="copyStoreAdminLink('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem;">📋 Admin URL</button>
                        <button class="secondary-action-btn" onclick="openStoreDashboard('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem;">🔑 Login</button>
                        <button class="secondary-action-btn" onclick="openStoreWebsite('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem; background: var(--success-green); color: white; border: none;">🌐 Storefront</button>
                    </div>
                </div>
                <button class="icon-btn delete" onclick="confirmDeleteStore('${s.docId}')">🗑️</button>
            </div>
        </div>
    `).join('');
}

window.getStoreWebsiteUrl = (store = window.storeInfo) => {
    const s = store || window.storeInfo || {};
    const storeId = (s.slug || (typeof window.getStoreId === 'function' ? window.getStoreId() : '') || '').toLowerCase();

    // 1. Direct website URL configured on store profile
    if (s.websiteUrl && s.websiteUrl.trim() !== '') {
        const url = s.websiteUrl.trim();
        return url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;
    }

    // 2. Custom domain configured on store
    if (s.domain && s.domain.trim() !== '') {
        const dom = s.domain.trim();
        return dom.startsWith('http://') || dom.startsWith('https://') ? dom : `https://${dom}`;
    }

    // 3. Known default merchant: MEC Book Shop
    if (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'master' || !storeId || storeId.includes('mecbook')) {
        return 'https://mecbookshop.web.lk';
    }

    // 4. Multi-merchant storefront URL on mecpos.web.lk
    if (s.slug) {
        return `https://mecpos.web.lk/store/${s.slug}`;
    }

    return 'https://mecbookshop.web.lk';
};

window.copyStoreAdminLink = (slug) => {
    const baseUrl = window.location.hostname.includes('localhost') ? window.location.origin : 'https://mecpos.web.lk';
    const url = `${baseUrl}/admin/${slug}`;
    navigator.clipboard.writeText(url);
    window.showToast("Admin link copied!", "info");
};

window.openStoreDashboard = (slug) => {
    const baseUrl = window.location.hostname.includes('localhost') ? window.location.origin : 'https://mecpos.web.lk';
    window.open(`${baseUrl}/admin/${slug}`, '_blank');
};

window.openStoreWebsite = (storeOrSlug = window.storeInfo) => {
    let targetUrl = '';
    if (typeof storeOrSlug === 'string') {
        const matched = (window.allStores || []).find(s => s.slug === storeOrSlug);
        targetUrl = window.getStoreWebsiteUrl(matched || { slug: storeOrSlug });
    } else {
        targetUrl = window.getStoreWebsiteUrl(storeOrSlug);
    }

    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(targetUrl);
    } else {
        window.open(targetUrl, '_blank');
    }
};

window.confirmDeleteStore = async (docId) => {
    const docRef = doc(db, 'stores', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Store removed.", "info");
};

// --- Global Filter State ---
// (activeBranchFilter moved to top)

window.switchBranchFilter = (val) => {
    activeBranchFilter = val;
    // Trigger UI updates
    if (window.allOrders && typeof window.renderAdminOrdersUI === 'function') window.renderAdminOrdersUI(window.allOrders);
    if (window.allEmployees && typeof window.renderAdminEmployeesUI === 'function') window.renderAdminEmployeesUI(window.allEmployees);
    // Add other UI triggers if needed
    window.showToast(`Switched view to ${val === 'All' ? 'All Branches' : (window.allBranches.find(b => b.docId === val)?.name || val)}`, "info");
};

window.forceCloudSync = () => {
    // Reload the page to refresh data without logging out the user
    window.location.reload();
};

function resolveProductImage(img, name) {
    if (img && img.length > 50) return img;
    if (img && img.startsWith('http') && !img.includes('placehold.co')) return img;
    const colors = ['002060', '0ea5e9', '6366f1', '10b981', 'f59e0b', 'ef4444'];
    const charSum = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const color = colors[charSum % colors.length];
    return `https://placehold.co/600x400/${color}/FFF?text=${encodeURIComponent(name)}`;
}



// --- Modularized Domains (Inventory, Orders, Reports) ---


// --- POS Sharing & Printing ---
window.generatePOSReceiptNo = () => {
    const no = 'R-' + Math.floor(Math.random() * 900000 + 100000);
    document.getElementById('pos-receipt-no').innerText = no;
};

window.printPOSReceipt = (saleData = null) => { // TEST
    const isSnapshot = !!saleData;
    const snapshot = saleData || window.currentPendingPOSSale || window.lastSavedPOSOrder;
    const billItems = isSnapshot ? (snapshot.items || []) : (window.activePOSItems || []);
    if (billItems.length === 0) return;

    // Values either from snapshot parameter or UI elements
    const receiptNo = isSnapshot ? (snapshot.orderId || "POS-SALE") : (document.getElementById('pos-receipt-no')?.innerText || "POS-SALE");
    
    let subtotalText, discountVal, payableText, paidVal, cashBalanceText;
    
    if (isSnapshot) {
        const sub = billItems.reduce((s, i) => s + ((i.price - (i.discount || 0)) * i.quantity), 0);
        subtotalText = sub.toFixed(2);
        discountVal = Math.max(0, sub - (snapshot.baseAmount || snapshot.total || 0));
        payableText = (snapshot.baseAmount || snapshot.total || 0).toFixed(2);
        paidVal = snapshot.tenderedAmount !== undefined ? snapshot.tenderedAmount : (snapshot.baseAmount || snapshot.total || 0);
        cashBalanceText = (snapshot.cashBalance || 0).toFixed(2);
    } else {
        subtotalText = document.getElementById('pos-subtotal')?.innerText || "0.00";
        discountVal = parseFloat(document.getElementById('pos-bill-discount')?.value || 0);
        payableText = document.getElementById('pos-payable')?.innerText || "0.00";
        paidVal = parseFloat(document.getElementById('pay-modal-tendered')?.value || payableText);
        cashBalanceText = document.getElementById('pay-modal-cash-balance')?.innerText || "0.00";
    }

    // Computed Logic from current interaction / snapshot
    const redeemed = isSnapshot ? (snapshot.redeemedAmount || 0) : (window.appliedLoyaltyPointsOnThisBill || 0);
    const settled = snapshot?.outstandingIncluded ? (snapshot.outstandingAmount || 0) : 0;
    const manualPointsAdded = snapshot?.balanceToPoints ? (snapshot.changeAmount || 0) : 0;

    const pType = window.systemConfig?.printerType || 'thermal-80';
    
    let printHtml = '';

    if (pType === 'a4' || pType === 'a5') {
        const pageSize = pType === 'a4' ? 'A4' : 'A5';
        const maxWidth = pType === 'a4' ? '210mm' : '148mm';
        
        let a4ItemsHtml = billItems.map((item, idx) => `
            <tr>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee;">${idx + 1}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; font-weight: 600;">${item.name}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right;">${item.price.toFixed(2)}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right;">${(item.discount || 0).toFixed(2)}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold;">${((item.price - (item.discount || 0)) * item.quantity).toFixed(2)}</td>
            </tr>
        `).join('');

        const templateId = window.systemConfig?.invTemplate || 'classic';
        let themeColor = '#002060';
        let bgMeta = '#f8fafc';
        let borderRadius = '8px';
        let titleColor = '#002060';
        
        if (templateId === 'modern') {
            themeColor = '#0ea5e9';
            bgMeta = '#f1f5f9';
            borderRadius = '12px';
            titleColor = '#0ea5e9';
        } else if (templateId === 'minimal') {
            themeColor = '#1a1a1a';
            bgMeta = '#ffffff';
            borderRadius = '0px';
            titleColor = '#1a1a1a';
        }

        printHtml = `
            <html>
            <head>
                <title>Invoice ${receiptNo}</title>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
                    @page { size: ${pageSize} portrait; margin: 8mm; }
                    body { font-family: 'Inter', sans-serif; padding: 0; color: #1a1a1a; max-width: ${maxWidth}; margin: 0 auto; line-height: 1.3; font-size: 11px; }
                    .invoice-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; border-bottom: 2px solid ${themeColor}; padding-bottom: 10px; }
                    .logo { font-size: 20px; font-weight: 800; color: ${themeColor}; margin-bottom: 2px; }
                    .company-info { color: #555; font-size: 11px; }
                    .invoice-title { text-align: right; }
                    .invoice-title h1 { margin: 0 0 5px 0; font-size: 24px; color: ${titleColor}; text-transform: uppercase; letter-spacing: 1px; }
                    .invoice-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px; background: ${bgMeta}; padding: 10px; border-radius: ${borderRadius}; border: ${templateId === 'minimal' ? '1px solid #e2e8f0' : 'none'}; }
                    .meta-item label { display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 800; margin-bottom: 2px; }
                    .meta-item span { font-weight: 600; font-size: 12px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                    th { background: ${themeColor}; color: white; padding: 6px 5px; text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; ${templateId === 'minimal' ? 'border-bottom: 2px solid #1a1a1a; background: white; color: #1a1a1a;' : ''} }
                    td { border-bottom: 1px solid #e2e8f0; font-size: 11px; }
                    th:nth-child(3) { text-align: center; }
                    th:nth-child(4), th:nth-child(5), th:nth-child(6) { text-align: right; }
                    .summary-box { float: right; width: 250px; }
                    .summary-line { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px; color: #475569; }
                    .total-line { display: flex; justify-content: space-between; font-weight: 800; font-size: 16px; margin-top: 10px; padding-top: 10px; border-top: 2px solid ${themeColor}; color: ${themeColor}; }
                    .footer { clear: both; margin-top: 30px; text-align: center; font-size: 10px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class="invoice-header">
                    <div>
                        <div class="logo">${window.storeInfo?.name || 'MEC BOOK SHOP'}</div>
                        <div class="company-info">
                            ${window.storeInfo?.location || 'Yakkala • Panadura Road'}<br>
                            Tel: ${window.storeInfo?.phone || '+94 71 923 3388'}
                        </div>
                    </div>
                    <div class="invoice-title">
                        <h1>INVOICE</h1>
                    </div>
                </div>
                
                <div class="invoice-meta">
                    <div class="meta-item">
                        <label>Invoice Number</label>
                        <span>#${receiptNo}</span>
                    </div>
                    <div class="meta-item" style="text-align: right;">
                        <label>Date</label>
                        <span>${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</span>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th width="5%">#</th>
                            <th width="45%">Item Description</th>
                            <th width="10%">Qty</th>
                            <th width="15%">Unit Price</th>
                            <th width="10%">Disc.</th>
                            <th width="15%">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${a4ItemsHtml}
                    </tbody>
                </table>

                <div class="summary-box">
                    <div class="summary-line"><span>Subtotal</span><span>LKR ${subtotalText}</span></div>
                    <div class="summary-line"><span>Discount</span><span>- LKR ${discountVal.toFixed(2)}</span></div>
                    ${settled > 0 ? `<div class="summary-line" style="color: #e30030;"><span>Settled Outstanding</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                    <div class="total-line"><span>GRAND TOTAL</span><span>LKR ${payableText}</span></div>
                    
                    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px dashed #cbd5e1;"></div>
                    ${redeemed > 0 ? `<div class="summary-line" style="color: #16a34a;"><span>Redeemed Points</span><span>- LKR ${redeemed.toFixed(2)}</span></div>` : ''}
                    <div class="summary-line"><span>Amount Tendered</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                    <div class="summary-line" style="font-weight: 800; color: #0f172a;"><span>Balance</span><span>LKR ${cashBalanceText}</span></div>
                    ${manualPointsAdded > 0 ? `<div class="summary-line" style="font-style: italic; font-size: 11px;"><span>Loyalty Points Added</span><span>LKR ${manualPointsAdded.toFixed(2)}</span></div>` : ''}
                </div>

                    <p>Thank you for your business!</p>
                    <p>Software by MEC Global Solutions</p>
                    
                    <!-- Dialog Scan & Recharge Print Ticket Details -->
                    ${billItems.some(item => item.isReload && item.reloadDetails && item.reloadDetails.voucherPin) ? `
                    <div style="margin-top: 20px; border-top: 1px dashed #cbd5e1; padding-top: 15px; text-align: center;">
                        <h4 style="margin: 0 0 10px 0; color: #0284c7; text-transform: uppercase; font-size: 11px;">📱 Dialog Scan & Recharge Voucher</h4>
                        ${billItems.filter(item => item.isReload && item.reloadDetails && item.reloadDetails.voucherPin).map(item => `
                            <div style="margin-bottom: 12px;">
                                <div style="font-weight: 800; font-size: 13px; font-family: monospace; letter-spacing: 1px; color: #000;">PIN: ${item.reloadDetails.voucherPin}</div>
                                <div style="font-size: 9px; color: #64748b; margin-bottom: 5px;">Scan QR below to recharge LKR ${item.price} instantly</div>
                                <img src="https://api.qrserver.com/v1/create-qr-code/?size=110x110&data=${encodeURIComponent(item.reloadDetails.voucherUrl || `https://dialog.lk/scan-and-recharge?language=en#code=${btoa(item.reloadDetails.voucherPin)}`)}" 
                                     style="width: 100px; height: 100px; border: 1px solid #ddd; padding: 4px; border-radius: 8px; margin: 5px auto 0; display: block;" />
                            </div>
                        `).join('')}
                    </div>
                    ` : ''}
                </div>
                <script>
                    setTimeout(() => {
                        window.focus();
                        window.print();
                        window.close();
                    }, 300);
                </script>
            </body>
            </html>
        `;
    } else {
        // Thermal Receipt Template
        let itemsHtml = billItems.map(item => `
            <div class="receipt-row">
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-meta">${item.quantity} x LKR ${item.price.toFixed(2)}</div>
                </div>
                <div class="item-total">LKR ${((item.price - (item.discount || 0)) * item.quantity).toFixed(2)}</div>
            </div>
        `).join('');

        // Dialog Voucher Thermal QR Section
        let dialogVouchersThermalHtml = '';
        const dialogItems = billItems.filter(item => item.isReload && item.reloadDetails && item.reloadDetails.voucherPin);
        if (dialogItems.length > 0) {
            dialogVouchersThermalHtml = `
                <div class="divider"></div>
                <div style="text-align: center; font-size: 10px; margin-top: 10px;">
                    <div style="font-weight: 800; text-transform: uppercase; color: #000; margin-bottom: 8px;">📱 DIALOG SCAN & RECHARGE</div>
                    ${dialogItems.map(item => `
                        <div style="margin-bottom: 10px;">
                            <div style="font-weight: 800; font-size: 13px; font-family: monospace;">PIN: ${item.reloadDetails.voucherPin}</div>
                            <div style="font-size: 8px; color: #666;">Scan QR below to recharge LKR ${item.price}</div>
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=110x110&data=${encodeURIComponent(item.reloadDetails.voucherUrl || `https://dialog.lk/scan-and-recharge?language=en#code=${btoa(item.reloadDetails.voucherPin)}`)}" 
                                 style="width: 100px; height: 100px; border: 1px solid #ccc; padding: 3px; border-radius: 4px; margin: 5px auto 0; display: block;" />
                        </div>
                    `).join('')}
                </div>
            `;
        }

        printHtml = `
            <html>
            <head>
                <title>Receipt ${receiptNo}</title>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap');
                    body { font-family: 'Inter', sans-serif; padding: 20px; color: #1a1a1a; max-width: 380px; margin: 0 auto; line-height: 1.4; }
                    .header { text-align: center; margin-bottom: 20px; }
                    .logo { font-size: 22px; font-weight: 800; color: #002060; }
                    .divider { border-bottom: 1px dashed #ccc; margin: 15px 0; }
                    .receipt-info { font-size: 11px; display: flex; justify-content: space-between; margin-bottom: 5px; color: #666; }
                    .receipt-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 13px; }
                    .item-name { font-weight: 700; text-transform: uppercase; }
                    .item-meta { font-size: 10px; color: #777; }
                    .summary-line { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 12px; }
                    .total-line { display: flex; justify-content: space-between; font-weight: 800; font-size: 18px; margin-top: 5px; color: #002060; }
                    .footer { text-align: center; margin-top: 30px; font-size: 10px; color: #999; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="logo">${window.storeInfo?.name || 'MEC BOOK SHOP'}</div>
                    <div style="font-size: 11px;">Creative Stationery & Bookstore</div>
                    <div style="font-size: 10px;">${window.storeInfo?.location || 'Yakkala • Panadura Road'}</div>
                    <div style="font-size: 10px;">Tel: ${window.storeInfo?.phone || '+94 71 923 3388'}</div>
                </div>
                <div class="receipt-info"><span>Date: ${new Date().toLocaleDateString()}</span><span>Inv: #${receiptNo}</span></div>
                <div class="divider"></div>
                ${itemsHtml}
                <div class="divider"></div>
                <div class="summary-line"><span>Subtotal (Items)</span><span>LKR ${subtotalText}</span></div>
                <div class="summary-line"><span>Product Discount</span><span>- LKR ${discountVal.toFixed(2)}</span></div>
                ${settled > 0 ? `<div class="summary-line" style="color: #e30030;"><span>Settled Outstanding</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                <div class="total-line"><span>GRAND TOTAL</span><span>LKR ${payableText}</span></div>
                <div class="divider" style="border-style: solid;"></div>
                ${redeemed > 0 ? `<div class="summary-line" style="color: #16a34a;"><span>Redeemed Points</span><span>- LKR ${redeemed.toFixed(2)}</span></div>` : ''}
                <div class="summary-line"><span>Cash Tendered</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                <div class="summary-line" style="font-weight: 800; font-size: 14px; margin-top: 5px;"><span>CASH BALANCE</span><span>LKR ${cashBalanceText}</span></div>
                ${manualPointsAdded > 0 ? `<div class="summary-line" style="font-style: italic; font-size: 10px; color: #666; margin-top: 5px;"><span>(Pushed to Loyalty: LKR ${manualPointsAdded.toFixed(2)})</span></div>` : ''}
                
                ${dialogVouchersThermalHtml}
                
                <div class="footer">
                    <p>Thank you for shopping with us!</p>
                    <p>Software by MEC Global Solutions</p>
                </div>
                <script>
                    setTimeout(() => {
                        window.focus();
                        window.print();
                        window.close();
                    }, 300);
                </script>
            </body>
            </html>
        `;
    }

    if (window.electron) {
        window.electron.send('print-receipt', { 
            html: printHtml, 
            printerName: window.systemConfig?.printerName || '',
            printerType: pType 
        });
    } else {
        // Use a hidden iframe to print to bypass browser popup blockers
        let iframe = document.getElementById('pos-print-iframe');
        if (!iframe) {
            iframe = document.createElement('iframe');
            iframe.id = 'pos-print-iframe';
            iframe.style.position = 'fixed';
            iframe.style.top = '-9999px';
            iframe.style.left = '-9999px';
            iframe.style.width = '0';
            iframe.style.height = '0';
            iframe.style.border = 'none';
            document.body.appendChild(iframe);
        }
        
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        doc.open();
        doc.write(printHtml);
        doc.close();
        
        setTimeout(() => {
            try {
                iframe.contentWindow.focus();
                iframe.contentWindow.print();
            } catch (e) {
                console.error("Iframe print error:", e);
                // Fallback to window.open if iframe printing fails
                const width = (pType === 'a4' || pType === 'a5') ? 800 : 450;
                const height = (pType === 'a4' || pType === 'a5') ? 900 : 800;
                const printWindow = window.open('', 'POSReceipt', `width=${width},height=${height}`);
                if (printWindow) {
                    printWindow.document.write(printHtml);
                    printWindow.document.close();
                }
            }
        }, 500);
    }
};

// window.shareOnWhatsApp definition moved to end of file for consistency


// This function has been consolidated with the one above.
// SMSLENZ_API_KEY and other constants are now used in the main sendSMSBilling function.

function getBillPlainText() {
    const receiptNo = document.getElementById('pos-receipt-no').innerText;
    const subtotal = document.getElementById('pos-subtotal').innerText;
    const discInput = document.getElementById('pos-bill-discount').value || 0;
    const discType = document.getElementById('pos-discount-type').value;
    const payable = document.getElementById('pos-payable').innerText;
    const paidEl = document.getElementById('pay-modal-tendered');
    const changeEl = document.getElementById('pay-modal-change');
    const paid = paidEl ? paidEl.value || payable : payable;
    const change = changeEl ? changeEl.innerText : "0.00";

    let text = `*MEC PLATFORM ERP - RECEIPT*\n`;
    text += `Receipt: ${receiptNo}\n`;
    text += `Date: ${new Date().toLocaleDateString()}\n\n`;

    currentPOSBill.forEach(item => {
        const netPrice = item.price - (item.discount || 0);
        text += `${item.name} x ${item.quantity} ${item.discount > 0 ? `[Disc ${item.discount}]` : ''} = LKR ${(netPrice * item.quantity).toFixed(2)}\n`;
    });

    text += `\nSubtotal: LKR ${subtotal}\n`;
    if (parseFloat(discInput) > 0) {
        text += `Discount (${discType === '%' ? discInput + '%' : 'LKR ' + discInput}): -LKR ${(parseFloat(subtotal) - parseFloat(payable)).toFixed(2)}\n`;
    }
    text += `*TOTAL PAYABLE: LKR ${payable}*\n`;
    text += `Paid: LKR ${paid}\n`;
    text += `Change: LKR ${change}\n\n`;
    text += `Track Order: mecbookshop.com.lk\n`;
    text += `Thank you for choosing MEC Network!`;
    return text;
}

// --- Sync/Update Logic ---
// --- Stock Management & Purchase History ---
let currentStockInvoice = [];

window.searchProductsForStock = (val) => {
    const resultsDiv = document.getElementById('stock-search-results');
    if (!resultsDiv) return;
    if (!val) { resultsDiv.style.display = 'none'; return; }

    const q = val.toLowerCase();
    const filtered = (window.allProducts || []).filter(p => p.name.toLowerCase().includes(q));

    resultsDiv.innerHTML = filtered.map(p => `
        <div class="search-result-item" onclick="addToStockInvoice('${p.docId}')">
            ${p.name} (Stock: ${p.stock})
        </div>
    `).join('');
    resultsDiv.style.display = 'block';
};

window.addToStockInvoice = (docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;
    if (!currentStockInvoice.find(x => x.docId === docId)) {
        currentStockInvoice.push({ ...p, addedQty: 1 });
    }
    document.getElementById('stock-search').value = '';
    document.getElementById('stock-search-results').style.display = 'none';
    renderStockInvoiceUI();
};



// --- Expenses UI & Logic ---
window.addExpense = async (e) => {
    e.preventDefault();
    const title = document.getElementById('exp-title').value;
    const category = document.getElementById('exp-category').value;
    const amount = parseFloat(document.getElementById('exp-amount').value);
    const date = document.getElementById('exp-date').value;

    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    try {
        window.showToast(navigator.onLine ? "🚀 Recording expense..." : "💾 Saving expense locally...", "info");
        await addDoc(expensesCol, { title, category, amount, date, branchId, storeId, timestamp: serverTimestamp() });
        e.target.reset();
        window.showToast(navigator.onLine ? "✅ Expense recorded." : "✅ Recorded locally", "success");
    } catch (err) { 
        console.error(err);
        window.showToast("❌ Error saving expense", "error");
    }
};

function renderExpensesUI(expenses) {
    const div = document.getElementById('admin-expense-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();

    const startDateVal = document.getElementById('exp-filter-start-date')?.value;
    const endDateVal = document.getElementById('exp-filter-end-date')?.value;

    const filtered = expenses.filter(ex => {
        // Store filter
        if (ex.storeId && ex.storeId !== storeId) return false;
        if (!ex.storeId && storeId !== 'master') return false;

        // Branch filter
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            if (ex.branchId !== userBranch && (!ex.branchId && userBranch !== 'Global')) return false;
        } else if (activeBranchFilter !== 'All') {
            if (ex.branchId !== activeBranchFilter) return false;
        }

        // Date range filtering
        if (startDateVal && ex.date < startDateVal) return false;
        if (endDateVal && ex.date > endDateVal) return false;

        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    const totalAmount = sorted.reduce((sum, ex) => sum + (Number(ex.amount) || 0), 0);

    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8;">
            <span>Showing <strong>${sorted.length}</strong> record(s)</span>
            <span>Total Expense: <strong style="color: #ef4444; font-size: 1.05rem;">LKR ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
        </div>
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.length === 0 ? `<tr><td colspan="5" style="text-align:center; padding: 20px; color:#64748b;">No expenses found for selected range.</td></tr>` : ''}
                ${sorted.map(ex => `
                    <tr>
                        <td>${ex.date}</td>
                        <td>${ex.title}</td>
                        <td><span class="status-badge" style="background:#f1f5f9; color:#475569;">${ex.category}</span></td>
                        <td style="font-weight:700;">LKR ${(Number(ex.amount) || 0).toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteExpense('${ex.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteExpense = async (id) => {
    const docRef = doc(db, 'expenses', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Expense record removed.", "info");
};

// --- Purchases History UI ---
function renderPurchasesUI(_unused) {
    const div = document.getElementById('admin-purchase-history');
    if (!div) return;
    // Purchases are stored in supplierInvoices, not the old 'purchases' collection
    const allInvoices = window.allSupplierInvoices || [];
    const filtered = window.filterByStore(allInvoices);
    const sorted = [...filtered].sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
    if (sorted.length === 0) {
        div.innerHTML = '<p style="color:#94a3b8; padding: 2rem 0;">No purchase history yet. Add stock via Smart Procurement → New Invoice / Purchase.</p>';
        return;
    }
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr>
                <th>Date</th>
                <th>Invoice No</th>
                <th>Supplier</th>
                <th>Items</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Status</th>
            </tr></thead>
            <tbody>
                ${sorted.map(p => {
                    const total = parseFloat(p.grandTotal || p.totalAmount || p.totalCost || 0);
                    const paid = parseFloat(p.paidAmount || p.paid || 0);
                    const statusColor = p.status === 'Paid' ? '#10b981' : p.status === 'Partially Paid' ? '#f59e0b' : '#ef4444';
                    const itemsSummary = (p.items || []).map(i => `${i.name} (${i.qty})`).join(', ') || '—';
                    const invoiceJson = encodeURIComponent(JSON.stringify(p));
                    return `
                    <tr onclick="window.viewPurchaseDetails('${invoiceJson}')" style="cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='none'">
                        <td>${p.date || '—'}</td>
                        <td style="font-family:monospace; color:#38bdf8; font-weight: 700;">${p.invoiceNo || '—'}</td>
                        <td>${p.supplierName || '—'}</td>
                        <td style="font-size:0.8rem; max-width:250px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${itemsSummary}">${itemsSummary}</td>
                        <td style="font-weight:700;">LKR ${total.toFixed(2)}</td>
                        <td style="font-weight:700; color:#10b981;">LKR ${paid.toFixed(2)}</td>
                        <td><span class="status-badge" style="background:${statusColor}22; color:${statusColor}; border:1px solid ${statusColor}44;">${p.status || 'Unknown'}</span></td>
                    </tr>`;
                }).join('')}
            </tbody>
        </table>
    `;
}

window.viewPurchaseDetails = (encodedInvoice) => {
    try {
        const p = JSON.parse(decodeURIComponent(encodedInvoice));
        document.getElementById('pd-supplier').innerText = p.supplierName || '—';
        document.getElementById('pd-invoice-no').innerText = p.invoiceNo || '—';
        document.getElementById('pd-date').innerText = p.date || '—';
        document.getElementById('pd-status').innerText = p.status || 'Unknown';
        
        const total = parseFloat(p.grandTotal || p.totalAmount || p.totalCost || 0);
        const paid = parseFloat(p.paidAmount || p.paid || 0);
        const balance = total - paid;
        
        document.getElementById('pd-grand-total').innerText = `LKR ${total.toFixed(2)}`;
        document.getElementById('pd-paid').innerText = `LKR ${paid.toFixed(2)}`;
        document.getElementById('pd-balance').innerText = `LKR ${balance.toFixed(2)}`;
        
        const tbody = document.getElementById('pd-items-body');
        if (tbody) {
            const items = p.items || [];
            if (items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:15px; color:#94a3b8;">No items in this purchase log.</td></tr>';
            } else {
                tbody.innerHTML = items.map(item => {
                    const itemCost = parseFloat(item.costPrice || item.cost || item.buyingPrice || 0);
                    const qty = parseFloat(item.qty || item.quantity || 0);
                    const itemTotal = itemCost * qty;
                    return `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px 15px; font-weight:700; color:#fff;">${item.name || '—'}</td>
                            <td style="padding: 10px 15px; text-align: center;">${qty}</td>
                            <td style="padding: 10px 15px; text-align: right;">LKR ${itemCost.toFixed(2)}</td>
                            <td style="padding: 10px 15px; text-align: right; font-weight:700; color:#38bdf8;">LKR ${itemTotal.toFixed(2)}</td>
                        </tr>
                    `;
                }).join('');
            }
        }
        
        const modal = document.getElementById('purchase-details-modal');
        if (modal) modal.style.display = 'flex';
    } catch (err) {
        console.error("Error viewing purchase details:", err);
    }
};


// --- Suppliers UI & Logic ---
window.addSupplier = async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const idField = document.getElementById('sup-id');
    const existingId = idField ? idField.value : '';
    
    const name = document.getElementById('sup-name').value;
    const contact = document.getElementById('sup-contact').value;
    const phone = document.getElementById('sup-phone').value;
    const address = document.getElementById('sup-address').value;

    try {
        if (existingId) {
            const docRef = doc(db, 'suppliers', existingId);
            updateDoc(docRef, {
                name, contact, phone, address,
                lastUpdated: serverTimestamp()
            }).catch(err => {
                console.error("Firestore update supplier error:", err);
                window.showToast("❌ Sync failed: " + err.message, "error");
            });
            window.showToast("✅ Supplier updated.", "success");
            window.cancelEditSupplier?.();
        } else {
            const supId = `SUP-${name.substring(0, 3).toUpperCase().replace(/\s/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
            setDoc(doc(collection(db, 'suppliers'), supId), { 
                name, 
                contact, 
                phone, 
                address, 
                docId: supId,
                storeId: window.getStoreId(),
                timestamp: serverTimestamp() 
            }).catch(err => {
                console.error("Firestore add supplier error:", err);
                window.showToast("❌ Sync failed: " + err.message, "error");
            });
            window.showToast("✅ Supplier added.", "success");
        }
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving supplier", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

// Quick Category Logic
window.openQuickCategoryModal = (targetSelectId) => {
    const modal = document.getElementById('quick-category-modal');
    if (!modal) return;
    document.getElementById('qc-target-select').value = targetSelectId;
    document.getElementById('qc-name').value = '';
    modal.style.display = 'flex';
    document.getElementById('qc-name').focus();
};

window.saveQuickCategory = async (e) => {
    e.preventDefault();
    const name = document.getElementById('qc-name').value.trim();
    if (!name) return;

    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Adding category...", "info");
        addDoc(collection(db, 'categories'), {
            name,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp()
        }).catch(err => {
            console.error("Firestore quick add category error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        
        window.showToast("✅ Category added!", "success");
        document.getElementById('quick-category-modal').style.display = 'none';

        // Auto-select the new category in the target dropdown
        const targetId = document.getElementById('qc-target-select').value;
        const select = document.getElementById(targetId);
        if (select) {
            const option = document.createElement('option');
            option.value = name;
            option.text = name;
            option.selected = true;
            select.appendChild(option);
        }
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving category", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderSuppliersUI(suppliers) {
    const div = document.getElementById('admin-supplier-list');
    if (!div) return;
    const filtered = window.filterByStore(suppliers);
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr><th>Code</th><th>Name</th><th>Contact</th><th>Phone</th><th>Actions</th></tr></thead>
            <tbody>
                ${filtered.map(s => `
                    <tr>
                        <td style="color: #38bdf8; font-weight: bold; font-family: monospace;">${s.docId || '-'}</td>
                        <td><strong>${s.name}</strong></td>
                        <td>${s.contact || '-'}</td>
                        <td>${s.phone || '-'}</td>
                        <td>
                            <div style="display: flex; gap: 8px;">
                                <button class="icon-btn" onclick="window.editSupplier('${s.docId}')" style="color: #10b981; font-size: 1.2rem;">✏️</button>
                                <button class="icon-btn delete" onclick="deleteSupplier('${s.docId}')">🗑️</button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteSupplier = async (id) => {
    const docRef = doc(db, 'suppliers', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Supplier removed.", "info");
};

window.editSupplier = (id) => {
    const supplier = window.allSuppliers.find(s => s.docId === id);
    if (!supplier) return;
    
    document.getElementById('sup-id').value = supplier.docId;
    document.getElementById('sup-name').value = supplier.name || '';
    document.getElementById('sup-contact').value = supplier.contact || '';
    document.getElementById('sup-phone').value = supplier.phone || '';
    document.getElementById('sup-address').value = supplier.address || '';
    
    const submitBtn = document.querySelector('#supplier-form button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'Update Supplier Profile';
    
    document.getElementById('sup-cancel-btn').style.display = 'block';
    
    window.showSubTab('suppliers', 'add');
};

window.cancelEditSupplier = () => {
    document.getElementById('supplier-form').reset();
    document.getElementById('sup-id').value = '';
    
    const submitBtn = document.querySelector('#supplier-form button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'Save Supplier Profile';
    
    document.getElementById('sup-cancel-btn').style.display = 'none';
    window.showSubTab('suppliers', 'list');
};

window.openQuickSupplierModal = (targetSelectId) => {
    document.getElementById('qs-target-select').value = targetSelectId;
    document.getElementById('qs-name').value = '';
    document.getElementById('qs-phone').value = '';
    document.getElementById('quick-supplier-modal').style.display = 'flex';
    document.getElementById('qs-name').focus();
};

document.getElementById('quick-supplier-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('qs-name').value;
    const phone = document.getElementById('qs-phone').value;
    const targetSelectId = document.getElementById('qs-target-select').value;

    const supId = `SUP-${name.substring(0, 3).toUpperCase().replace(/\s/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    try {
        window.showToast("Saving supplier...", "info");
        const docRef = doc(suppliersCol, supId);
        await setDoc(docRef, { 
            name, 
            phone, 
            docId: supId,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp() 
        });

        // The Snapshot listener in admin.js will update window.allSuppliers automatically,
        // but we need to wait a moment for it to sync or manually trigger a select update.
        const newSupplierId = supId;
        
        // Manually update the target dropdown immediately for UX
        const targetSelect = document.getElementById(targetSelectId);
        if (targetSelect) {
            const option = new Option(name, newSupplierId);
            targetSelect.add(option);
            targetSelect.value = newSupplierId;
        }

        document.getElementById('quick-supplier-modal').style.display = 'none';
        window.showToast("✅ Supplier added and selected!", "success");
    } catch (err) {
        console.error(err);
        window.showToast("Error adding supplier", "error");
    }
});


// --- CSV Exports ---
window.downloadExpensesCSV = () => {
    const expenses = window.allExpenses || [];
    let csv = "Date,Title,Category,Amount\n";
    expenses.forEach(e => csv += `${e.date},${e.title},${e.category},${e.amount}\n`);
    downloadFile(csv, "expenses.csv");
};

window.downloadPurchasesCSV = () => {
    const purchases = window.allPurchases || [];
    let csv = "Date,Items,Total Cost\n";
    purchases.forEach(p => {
        const itemStr = p.items.map(i => `${i.name}(${i.qty})`).join(' | ');
        csv += `${p.date},"${itemStr}",${p.totalCost}\n`;
    });
    downloadFile(csv, "purchase_history.csv");
};

window.downloadFile = function(content, filename) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
};

window.escapeCSV = (str) => {
    if (str === null || str === undefined) return '';
    return str.toString().replace(/"/g, '""');
};


// --- Income UI & Logic ---
window.addIncome = async (e) => {
    e.preventDefault();
    const title = document.getElementById('inc-title').value;
    const amount = parseFloat(document.getElementById('inc-amount').value);
    const date = document.getElementById('inc-date').value;

    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    try {
        window.showToast(navigator.onLine ? "🚀 Recording income..." : "💾 Saving income locally...", "info");
        await addDoc(incomeCol, { title, amount, date, branchId, storeId, timestamp: serverTimestamp() });
        e.target.reset();
        window.showToast(navigator.onLine ? "✅ Income recorded." : "✅ Recorded locally", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving income", "error");
    }
};

function renderIncomeUI(income) {
    const div = document.getElementById('admin-income-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();

    const filtered = income.filter(inc => {
        // Store filter
        if (inc.storeId && inc.storeId !== storeId) return false;
        if (!inc.storeId && storeId !== 'master') return false;

        // Branch filter
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            return inc.branchId === userBranch || (!inc.branchId && userBranch === 'Global');
        } else if (activeBranchFilter !== 'All') {
            return inc.branchId === activeBranchFilter;
        }
        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Source</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.map(inc => `
                    <tr>
                        <td>${inc.date}</td>
                        <td>${inc.title}</td>
                        <td style="font-weight:700; color:#10b981;">+ LKR ${inc.amount.toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteIncome('${inc.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteIncome = async (id) => {
    const docRef = doc(db, 'income', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
};

// --- Customer ID Generation ---
window.generateCustomerID = () => {
    const custType = document.getElementById('cust-type').value;
    const custIdInput = document.getElementById('cust-id');
    const label = document.getElementById('cust-id-label');
    const filtered = window.filterByStore(window.allCustomers || []);

    if (!custIdInput) return;

    if (custType === 'wholesale') {
        const count = filtered.filter(c => c.customerType === 'wholesale').length;
        custIdInput.value = 'WHO-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Wholesale Shop ID';
    } else if (custType === 'loyalty') {
        const count = filtered.filter(c => c.customerType === 'loyalty').length;
        custIdInput.value = 'LO-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Loyalty Card No';
    } else {
        const count = filtered.filter(c => c.customerType === 'retail').length;
        custIdInput.value = 'RET-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Member ID';
    }

    // [v3.9.63] Fallback if auto-generation is stuck
    if (!custIdInput.value || custIdInput.value === "") {
        const prefix = custType === 'wholesale' ? 'WHO' : (custType === 'loyalty' ? 'LO' : 'RET');
        custIdInput.value = prefix + "-" + Math.floor(100 + Math.random() * 899);
    }
};

// --- Customer UI & Logic ---
window.addCustomer = async (e) => {
    e.preventDefault();
    const name = document.getElementById('cust-name').value;
    const phone = document.getElementById('cust-phone').value;
    const email = document.getElementById('cust-email').value;
    const address = document.getElementById('cust-address').value;
    const customerType = document.getElementById('cust-type').value;
    const loyaltyCardNo = document.getElementById('cust-id').value;

    if (!name || !phone) {
        window.showToast("⚠️ Name and Phone are required!", "error");
        return;
    }

    const cleanedPhone = phone.trim().replace(/\D/g, '');
    const currentStoreId = window.getStoreId();
    const phoneExists = (window.allCustomers || []).some(c => {
        const cPhone = (c.phone || '').trim().replace(/\D/g, '');
        return cPhone === cleanedPhone && c.storeId === currentStoreId;
    });

    if (phoneExists) {
        window.showToast("⚠️ A customer with this phone number already exists!", "error");
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Registering customer...", "info");
        addDoc(customersCol, { 
            name, phone, email, address, 
            loyaltyCardNo,
            customerType,
            storeId: window.getStoreId(), 
            timestamp: serverTimestamp(),
            outstanding: 0
        }).catch(err => {
            console.error("Firestore add customer error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        
        e.target.reset();
        window.generateCustomerID(); // Re-generate for next
        window.showToast(`✅ Customer registered! ID: ${loyaltyCardNo}`, "success");
        
        // Return to list view
        if (typeof window.showSubTab === 'function') window.showSubTab('customers', 'list');
    } catch (err) { 
        console.error(err);
        window.showToast("❌ Registration failed: " + err.message, "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderCustomersUI(customers) {
    const div = document.getElementById('admin-customer-list');
    if (!div) return;

    const filtered = window.filterByStore(customers || []);
    const allOrders = window.allOrders || [];
    const allRepairs = window.allRepairJobs || [];

    // Build enriched customer objects with stats from orders & repairs
    const enriched = filtered.map(c => {
        const custOrders = allOrders.filter(o =>
            (o.customerId && o.customerId === c.docId) ||
            (o.customerPhone && c.phone && o.customerPhone === c.phone) ||
            (o.userName && o.userName !== 'Walk-in Customer' && o.userName === c.name)
        );
        const totalSpent = custOrders.reduce((s, o) => s + parseFloat(o.total || o.grandTotal || 0), 0);
        const lastOrder = custOrders.length ? custOrders.slice().sort((a, b) => {
            const ta = a.timestamp && a.timestamp.seconds ? a.timestamp.seconds : new Date(a.date || 0).getTime()/1000;
            const tb = b.timestamp && b.timestamp.seconds ? b.timestamp.seconds : new Date(b.date || 0).getTime()/1000;
            return tb - ta;
        })[0] : null;
        const lastVisit = lastOrder ? (lastOrder.timestamp && lastOrder.timestamp.seconds
            ? new Date(lastOrder.timestamp.seconds * 1000).toLocaleDateString()
            : new Date(lastOrder.date || lastOrder.createdAt || '').toLocaleDateString()) : '—';
        const repairCount = allRepairs.filter(r =>
            (r.customerPhone && c.phone && r.customerPhone === c.phone) ||
            (r.customerId && r.customerId === c.docId)
        ).length;
        return Object.assign({}, c, {_orders: custOrders.length, _spent: totalSpent, _lastVisit: lastVisit, _repairs: repairCount});
    });

    // Stats
    const totalSpentAll = enriched.reduce((s, c) => s + c._spent, 0);
    const loyaltyCount = enriched.filter(c => c.customerType === 'loyalty').length;
    const wholesaleCount = enriched.filter(c => c.customerType === 'wholesale').length;
    const totalLoyaltyPoints = enriched.reduce((s, c) => s + parseInt(c.loyaltyPoints || 0, 10), 0);

    // Search & filter
    const searchVal = (document.getElementById('crm-search') ? document.getElementById('crm-search').value : '').toLowerCase();
    const typeFilter = document.getElementById('crm-type-filter') ? document.getElementById('crm-type-filter').value : 'all';
    const sortBy = document.getElementById('crm-sort') ? document.getElementById('crm-sort').value : 'name';

    let list = enriched.filter(c => {
        const matchSearch = !searchVal ||
            (c.name || '').toLowerCase().includes(searchVal) ||
            (c.phone || '').toLowerCase().includes(searchVal) ||
            (c.loyaltyCardNo || '').toLowerCase().includes(searchVal) ||
            (c.email || '').toLowerCase().includes(searchVal);
        const matchType = typeFilter === 'all' || c.customerType === typeFilter;
        return matchSearch && matchType;
    });

    list.sort((a, b) => {
        if (sortBy === 'spent') return b._spent - a._spent;
        if (sortBy === 'orders') return b._orders - a._orders;
        if (sortBy === 'recent') {
            const da = a._lastVisit === '—' ? 0 : new Date(a._lastVisit).getTime();
            const db2 = b._lastVisit === '—' ? 0 : new Date(b._lastVisit).getTime();
            return db2 - da;
        }
        return (a.name || '').localeCompare(b.name || '');
    });

    function typeTag(t) {
        if (t === 'loyalty') return '<span style="background:#eef2ff;color:#6366f1;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #6366f133;">💎 Loyalty</span>';
        if (t === 'wholesale') return '<span style="background:#fffbeb;color:#d97706;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #d9770633;">📦 Wholesale</span>';
        return '<span style="background:#f0fdf4;color:#059669;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #05996933;">🛍️ Retail</span>';
    }

    const rows = list.map(c => {
        const idTag = c.loyaltyCardNo ? '🪪 ' + c.loyaltyCardNo : '';
        const showPoints = c.customerType === 'loyalty' || (c.loyaltyPoints && c.loyaltyPoints > 0);
        const ptsTag = showPoints ? ' &nbsp;·&nbsp; ⭐ ' + (c.loyaltyPoints || 0) + ' pts' : '';
        const repairCell = c._repairs > 0 ? '<span style="color:#f59e0b;font-weight:800;">🔧 ' + c._repairs + '</span>' : '—';
        const did = c.docId;
        return '<tr style="border-bottom:1px solid rgba(255,255,255,0.04);cursor:pointer;" data-did="' + did + '">' +
            '<td style="padding:14px;"><div style="font-weight:800;font-size:0.95rem;">' + c.name + '</div>' +
            '<div style="font-size:0.72rem;color:#64748b;margin-top:2px;">' + idTag + ptsTag + '</div></td>' +
            '<td style="padding:14px;"><div style="font-size:0.85rem;">📱 ' + (c.phone || '—') + '</div>' +
            (c.email ? '<div style="font-size:0.72rem;color:#64748b;">✉️ ' + c.email + '</div>' : '') + '</td>' +
            '<td style="padding:14px;text-align:center;">' + typeTag(c.customerType) + '</td>' +
            '<td style="padding:14px;text-align:right;font-weight:800;color:#38bdf8;">' + c._orders + '</td>' +
            '<td style="padding:14px;text-align:right;font-weight:900;color:#10b981;">LKR ' + c._spent.toFixed(2) + '</td>' +
            '<td style="padding:14px;text-align:center;">' + repairCell + '</td>' +
            '<td style="padding:14px;text-align:center;font-size:0.82rem;color:#94a3b8;">' + c._lastVisit + '</td>' +
            '<td style="padding:14px;text-align:right;" data-stop="1">' +
            '<div style="display:flex;gap:6px;justify-content:flex-end;">' +
            '<button data-view="' + did + '" title="View Profile" style="background:rgba(99,102,241,0.15);border:1px solid rgba(99,102,241,0.3);color:#6366f1;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">👤</button>' +
            '<button data-qr="' + did + '" title="Print Loyalty QR Card" style="background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#10b981;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">🖨️</button>' +
            '<button data-edit="' + did + '" title="Edit" style="background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.2);color:#38bdf8;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">✏️</button>' +
            '<button data-del="' + did + '" title="Delete" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#ef4444;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">🗑️</button>' +
            '</div></td>' +
            '</tr>';
    }).join('');

    div.innerHTML = '<div style="padding:0 0 20px 0;">' +
    '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:22px;">' +
        '<div style="background:linear-gradient(135deg,#6366f133,#6366f111);border:1px solid #6366f133;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#6366f1;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Customers</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#6366f1;margin-top:4px;">' + enriched.length + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#10b98133,#10b98111);border:1px solid #10b98133;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#10b981;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Revenue</div>' +
            '<div style="font-size:1.4rem;font-weight:900;color:#10b981;margin-top:4px;">LKR ' + totalSpentAll.toFixed(2) + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#8b5cf633,#8b5cf611);border:1px solid #8b5cf633;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#8b5cf6;font-weight:800;letter-spacing:1px;text-transform:uppercase;">💎 Loyalty Members</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#8b5cf6;margin-top:4px;">' + loyaltyCount + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#f59e0b33,#f59e0b11);border:1px solid #f59e0b33;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#f59e0b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">📦 Wholesale</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#f59e0b;margin-top:4px;">' + wholesaleCount + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#06b6d433,#06b6d411);border:1px solid #06b6d433;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#06b6d4;font-weight:800;letter-spacing:1px;text-transform:uppercase;">⭐ Total Loyalty Points</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#06b6d4;margin-top:4px;">' + totalLoyaltyPoints + '</div></div>' +
    '</div>' +
    '<div style="display:flex;gap:12px;margin-bottom:18px;flex-wrap:wrap;align-items:center;">' +
        '<input id="crm-search" placeholder="🔍  Search name, phone, ID..." oninput="renderCustomersUI(window.allCustomers||[])" value="' + searchVal.replace(/"/g,'&quot;') + '" style="flex:1;min-width:200px;padding:10px 16px;border-radius:10px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.9rem;outline:none;">' +
        '<select id="crm-type-filter" onchange="renderCustomersUI(window.allCustomers||[])" style="padding:10px 14px;border-radius:10px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.85rem;">' +
            '<option value="all"' + (typeFilter==='all'?' selected':'') + '>All Types</option>' +
            '<option value="retail"' + (typeFilter==='retail'?' selected':'') + '>🛍️ Retail</option>' +
            '<option value="loyalty"' + (typeFilter==='loyalty'?' selected':'') + '>💎 Loyalty</option>' +
            '<option value="wholesale"' + (typeFilter==='wholesale'?' selected':'') + '>📦 Wholesale</option>' +
        '</select>' +
        '<select id="crm-sort" onchange="renderCustomersUI(window.allCustomers||[])" style="padding:10px 14px;border-radius:10px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.85rem;">' +
            '<option value="name"' + (sortBy==='name'?' selected':'') + '>Sort: Name A-Z</option>' +
            '<option value="spent"' + (sortBy==='spent'?' selected':'') + '>Sort: Top Spenders</option>' +
            '<option value="orders"' + (sortBy==='orders'?' selected':'') + '>Sort: Most Orders</option>' +
            '<option value="recent"' + (sortBy==='recent'?' selected':'') + '>Sort: Recent Visit</option>' +
        '</select>' +
        '<span style="font-size:0.8rem;color:#64748b;white-space:nowrap;">' + list.length + ' customers</span>' +
    '</div>' +
    (list.length === 0
        ? '<div style="text-align:center;padding:60px;color:#64748b;">No customers match your search.</div>'
        : '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;color:white;">' +
          '<thead><tr style="border-bottom:1px solid rgba(255,255,255,0.08);">' +
          '<th style="padding:12px 14px;text-align:left;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Customer</th>' +
          '<th style="padding:12px 14px;text-align:left;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Contact</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Type</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Orders</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Spent</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Repairs</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Last Visit</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Actions</th>' +
          '</tr></thead><tbody>' + rows + '</tbody></table></div>') +
    '</div>';

    // Event delegation for data-did rows and buttons
    div.addEventListener('click', function(ev) {
        var btn = ev.target.closest('button');
        if (btn) {
            ev.stopPropagation();
            if (btn.dataset.view) { window.viewCustomerProfile(btn.dataset.view); return; }
            if (btn.dataset.qr) { window.printCustomerQRCard(btn.dataset.qr); return; }
            if (btn.dataset.edit) { window.openCustomerEditModal(btn.dataset.edit); return; }
            if (btn.dataset.del) { window.deleteCustomer(btn.dataset.del); return; }
        }
        var tr = ev.target.closest('tr[data-did]');
        if (tr && !ev.target.closest('[data-stop]')) {
            window.viewCustomerProfile(tr.dataset.did);
        }
    }, { once: true });
}

// Customer Profile Popup
window.viewCustomerProfile = function(id) {
    var c = (window.allCustomers || []).find(function(x) { return x.docId === id; });
    if (!c) return;

    var allOrders = window.allOrders || [];
    var allRepairs = window.allRepairJobs || [];

    var custOrders = allOrders.filter(function(o) {
        return (o.customerId && o.customerId === c.docId) ||
            (o.customerPhone && c.phone && o.customerPhone === c.phone) ||
            (o.userName && o.userName !== 'Walk-in Customer' && o.userName === c.name);
    }).sort(function(a, b) {
        var ta = a.timestamp && a.timestamp.seconds ? a.timestamp.seconds : 0;
        var tb = b.timestamp && b.timestamp.seconds ? b.timestamp.seconds : 0;
        return tb - ta;
    });

    var custRepairs = allRepairs.filter(function(r) {
        return (r.customerPhone && c.phone && r.customerPhone === c.phone) ||
            (r.customerId && r.customerId === c.docId);
    });

    var totalSpent = custOrders.reduce(function(s, o) { return s + parseFloat(o.total || o.grandTotal || 0); }, 0);

    var orderRows = custOrders.slice(0, 20).map(function(o) {
        var dateStr = o.timestamp && o.timestamp.seconds ? new Date(o.timestamp.seconds*1000).toLocaleDateString() : (o.date || '—');
        return '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#94a3b8;">' + dateStr + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#fff;font-weight:700;">#' + (o.orderId || o.id || '—') + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#64748b;">' + (o.paymentMethod || '—') + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#10b981;font-weight:800;text-align:right;">LKR ' + parseFloat(o.total||o.grandTotal||0).toFixed(2) + '</td>' +
            '</tr>';
    }).join('');

    var repairRows = custRepairs.slice(0,5).map(function(r) {
        return '<div style="padding:8px 12px;background:rgba(245,158,11,0.08);border-radius:8px;font-size:0.8rem;margin-bottom:6px;">🔧 <strong>' + (r.deviceModel||r.device||r.itemDescription||'Device') + '</strong> — ' + (r.issue||r.description||'Repair') + ' <span style="float:right;color:#f59e0b;font-weight:800;">' + (r.status||'—') + '</span></div>';
    }).join('');

    document.getElementById('sinv-edit-modal-overlay') && document.getElementById('sinv-edit-modal-overlay').remove();
    var overlay = document.createElement('div');
    overlay.id = 'sinv-edit-modal-overlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:10000000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(10px);';
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = '<div style="width:600px;max-height:85vh;overflow-y:auto;background:#0f172a;border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:28px;box-shadow:0 30px 100px rgba(0,0,0,0.8);">' +
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:24px;">' +
            '<div style="display:flex;align-items:center;gap:14px;">' +
                '<div style="width:52px;height:52px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:900;color:white;">' + (c.name||'?')[0].toUpperCase() + '</div>' +
                '<div><div style="font-size:1.3rem;font-weight:900;color:#fff;">' + c.name + '</div>' +
                '<div style="font-size:0.8rem;color:#64748b;">📱 ' + (c.phone||'—') + ' &nbsp;·&nbsp; ' + (c.loyaltyCardNo||'No ID') + '</div></div>' +
            '</div>' +
            '<button onclick="document.getElementById(\'sinv-edit-modal-overlay\').remove()" style="background:rgba(255,255,255,0.05);border:none;color:white;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.2rem;">✕</button>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:24px;">' +
            '<div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#10b981;font-weight:800;letter-spacing:1px;">TOTAL SPENT</div>' +
                '<div style="font-size:1.2rem;font-weight:900;color:#10b981;">LKR ' + totalSpent.toFixed(2) + '</div></div>' +
            '<div style="background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#38bdf8;font-weight:800;letter-spacing:1px;">ORDERS</div>' +
                '<div style="font-size:1.3rem;font-weight:900;color:#38bdf8;">' + custOrders.length + '</div></div>' +
            '<div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#f59e0b;font-weight:800;letter-spacing:1px;">LOYALTY PTS</div>' +
                '<div style="font-size:1.3rem;font-weight:900;color:#f59e0b;">' + (c.loyaltyPoints||0) + '</div></div>' +
        '</div>' +
        '<div style="margin-bottom:20px;">' +
            '<div style="font-size:0.8rem;font-weight:900;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px;">📋 Purchase History</div>' +
            (custOrders.length === 0
                ? '<div style="color:#475569;font-size:0.85rem;padding:20px;text-align:center;">No purchases found.</div>'
                : '<table style="width:100%;border-collapse:collapse;"><thead><tr style="border-bottom:1px solid rgba(255,255,255,0.08);"><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Date</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Order</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Method</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:right;">Amount</th></tr></thead><tbody>' + orderRows + '</tbody></table>' +
                (custOrders.length > 20 ? '<div style="font-size:0.72rem;color:#64748b;padding:8px;text-align:center;">Showing 20 of ' + custOrders.length + ' orders</div>' : '')) +
        '</div>' +
        (custRepairs.length > 0 ? '<div><div style="font-size:0.8rem;font-weight:900;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px;">🔧 Service Center History</div>' + repairRows + '</div>' : '') +
        '<button id="crm-profile-edit-btn" style="width:100%;margin-top:20px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;color:white;padding:13px;border-radius:12px;font-weight:900;font-size:0.95rem;cursor:pointer;">✏️ Edit Customer Details</button>' +
    '</div>';

    document.body.appendChild(overlay);
    // Wire edit button
    var editBtn = document.getElementById('crm-profile-edit-btn');
    if (editBtn) {
        editBtn.onclick = function() {
            var ov = document.getElementById('sinv-edit-modal-overlay');
            if (ov) ov.remove();
            window.openCustomerEditModal(id);
        };
    }
};

window.openCustomerEditModal = (id) => {
    const cust = (window.allCustomers || []).find(c => c.docId === id);
    if (!cust) return;

    document.getElementById('edit-cust-id').value = id;
    document.getElementById('edit-cust-loyalty').value = cust.loyaltyCardNo || '-';
    document.getElementById('edit-cust-name').value = cust.name || '';
    document.getElementById('edit-cust-phone').value = cust.phone || '';
    document.getElementById('edit-cust-email').value = cust.email || '';
    document.getElementById('edit-cust-address').value = cust.address || '';
    document.getElementById('edit-cust-type').value = cust.customerType || 'retail';

    document.getElementById('customer-edit-modal').style.display = 'flex';
};

document.getElementById('edit-customer-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const id = document.getElementById('edit-cust-id').value;
    const data = {
        name: document.getElementById('edit-cust-name').value,
        phone: document.getElementById('edit-cust-phone').value,
        email: document.getElementById('edit-cust-email').value,
        address: document.getElementById('edit-cust-address').value,
        customerType: document.getElementById('edit-cust-type').value
    };

    try {
        updateDoc(doc(db, 'customers', id), data).catch(err => {
            console.error("Firestore update customer error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        document.getElementById('customer-edit-modal').style.display = 'none';
        window.showToast("✅ Customer updated successfully", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error updating customer", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
});

window.deleteCustomer = async (id) => {
    const docRef = doc(db, 'customers', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Customer record removed.", "info");
};

window.printCustomerQRCard = (id) => {
    const c = (window.allCustomers || []).find(x => x.docId === id);
    if (!c) {
        window.showToast("Customer not found!", "error");
        return;
    }
    document.getElementById('print-qr-cust-id').value = id;
    document.getElementById('customer-qr-print-modal').style.display = 'flex';
};

window.confirmPrintCustomerQRCard = (slot) => {
    document.getElementById('customer-qr-print-modal').style.display = 'none';
    
    const id = document.getElementById('print-qr-cust-id').value;
    const c = (window.allCustomers || []).find(x => x.docId === id);
    if (!c) {
        window.showToast("Customer not found!", "error");
        return;
    }
    
    const qrData = c.phone || c.loyaltyCardNo || c.docId;
    const storeName = window.STORE_CONFIG?.name || "MEC Book Shop";
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrData)}`;
    
    let positioningCss = '';
    if (slot > 0) {
        const row = Math.ceil(slot / 2) - 1;
        const col = (slot % 2 === 1) ? 0 : 1;
        const leftVal = 15 + col * 95;
        const topVal = 15 + row * 54;
        positioningCss = `position: absolute; left: ${leftVal}mm; top: ${topVal}mm; box-shadow: none; border: 1.5px solid #000;`;
    } else {
        positioningCss = `margin: auto; border: 2px solid #0ea5e9; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);`;
    }
    
    // Remove old iframe if it exists to ensure a clean lifecycle/reset in WebView2
    const oldIframe = document.getElementById('qr-print-iframe');
    if (oldIframe) {
        oldIframe.parentNode.removeChild(oldIframe);
    }
    
    // Create a fresh new iframe
    const iframe = document.createElement('iframe');
    iframe.id = 'qr-print-iframe';
    iframe.style.position = 'fixed';
    iframe.style.bottom = '0';
    iframe.style.right = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    document.body.appendChild(iframe);
    
    const iframeDoc = iframe.contentWindow.document;
    iframeDoc.open();
    iframeDoc.write(`
        <html>
        <head>
            <title>Print Loyalty Card</title>
            <style>
                @page {
                    size: A4;
                    margin: 0;
                }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    margin: 0;
                    padding: 0;
                    width: 210mm;
                    height: 297mm;
                    position: relative;
                    background: white;
                    -webkit-print-color-adjust: exact;
                }
                .card {
                    width: 85mm;
                    height: 50mm;
                    background: #ffffff;
                    border-radius: 8px;
                    padding: 4mm;
                    box-sizing: border-box;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                    ${positioningCss}
                }
                .header {
                    font-size: 0.75rem;
                    font-weight: 800;
                    color: #0284c7;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    border-bottom: 1px solid #e0f2fe;
                    padding-bottom: 2px;
                }
                .content {
                    display: flex;
                    align-items: center;
                    gap: 4mm;
                    margin: 2mm 0;
                    flex: 1;
                }
                .details {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                }
                .name {
                    font-size: 0.85rem;
                    font-weight: 800;
                    color: #1f2937;
                    margin-bottom: 2px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .info {
                    font-size: 0.65rem;
                    color: #4b5563;
                    margin: 1px 0;
                }
                .qr-code {
                    width: 22mm;
                    height: 22mm;
                    border: 1px solid #e5e7eb;
                    padding: 1px;
                    background: white;
                    border-radius: 4px;
                }
                .footer {
                    font-size: 0.55rem;
                    color: #9ca3af;
                    text-align: center;
                    margin-top: auto;
                    border-top: 1px dashed #f3f4f6;
                    padding-top: 2px;
                }
                @media print {
                    .card {
                        border: 1.5px solid #000;
                    }
                }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="header">${storeName}</div>
                <div class="content">
                    <div class="details">
                        <div class="name">${c.name}</div>
                        <div class="info"><b>ID:</b> ${c.loyaltyCardNo || "N/A"}</div>
                        <div class="info"><b>Phone:</b> ${c.phone || "—"}</div>
                        <div class="info"><b>Type:</b> ${c.customerType ? c.customerType.toUpperCase() : "RETAIL"}</div>
                    </div>
                    <img class="qr-code" src="${qrUrl}" alt="QR Code" id="qr-img">
                </div>
                <div class="footer">Scan at POS to retrieve customer profile</div>
            </div>
            <script>
                document.getElementById('qr-img').onload = function() {
                    setTimeout(function() {
                        window.focus();
                        window.print();
                    }, 300);
                };
            <\/script>
        </body>
        </html>
    `);
    iframeDoc.close();
};

// --- Sync & Clock ---
// Duplicate removed. Unified at line 3833.

// --- Power Tools: Emergency Cleanup ---
window.purgeBadProducts = async () => {
    if (!await window.verifyDeletePermission()) return;
    
    const batch = writeBatch(db);
    let deletedCount = 0;
    
    (window.allProducts || []).forEach(p => {
        const nameStr = p.name ? p.name.toString().trim() : '';
        // If name is purely numeric (digits/dots) and doesn't look like a real name
        // Also check if SKU is missing or if name is a long barcode ( > 5 digits)
        if (/^\d+(\.\d+)?$/.test(nameStr) && (nameStr.length > 5 || !p.sku)) {
            batch.delete(doc(db, 'products', p.docId));
            deletedCount++;
        }
    });
    
    if (deletedCount > 0) {
        await batch.commit();
        window.showToast(`✅ Successfully purged ${deletedCount} bad products!`, "success");
    } else {
        window.showToast("No products with numeric names were found.", "info");
    }
};

window.previewMainImage = (input, previewId) => {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 10px;">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
};

window.toggleVariantSection = (checked) => {
    document.getElementById('variants-container').style.display = checked ? 'block' : 'none';
    document.getElementById('p-main-image-group').style.display = checked ? 'none' : 'block';
    // Base fields are now inside the stocks tab, so we don't strictly need to hide them if we use a different approach, 
    // but the user wants variants to replace base stock.
};

window.addVariantField = () => {
    const list = document.getElementById('variant-list');
    if (!list) return;
    const id = Date.now();
    const div = document.createElement('div');
    div.className = 'variant-row';
    
    div.style = `
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(99,179,237,0.15);
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 14px;
        position: relative;
    `;
    
    const supplierOptions = (window.allSuppliers || []).map(s => 
        `<option value="${s.name}">${s.name}</option>`
    ).join('');

    const pName = document.getElementById('p-name')?.value || 'ITEM';
    const pSup = document.getElementById('p-supplier');
    const pSupId = pSup ? pSup.value : 'SUP-GEN-0000';
    
    // Generate a structured placeholder ID (Size/Color will be 0000 until edited)
    const baseId = window.generateStructuredSKU ? window.generateStructuredSKU({ name: pName, supplierId: pSupId, price: 0, cost: 0 }) : `SKU-TEMP-${Math.floor(Math.random()*1000)}`;

    div.innerHTML = `
        <!-- Header row: Variant ID + delete button -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:0.65rem; opacity:0.5; text-transform:uppercase; letter-spacing:0.08em;">Variant ID (SKU)</span>
                <input type="text" class="v-id" value="${baseId}" 
                    style="font-weight:700; color:#38bdf8; font-size:0.85rem; background:rgba(56,189,248,0.07); 
                           border:1px solid rgba(56,189,248,0.2); border-radius:8px; padding:4px 10px; width:180px; height:32px;">
            </div>
            <button type="button" onclick="this.closest('.variant-row').remove()" 
                style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.3); color:#f87171;
                       border-radius:8px; width:30px; height:30px; cursor:pointer; font-size:0.85rem;
                       display:flex; align-items:center; justify-content:center; flex-shrink:0;">✕</button>
        </div>

        <!-- Main fields grid: 2 columns -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Supplier</label>
                <select class="v-supplier" style="font-size:0.82rem; background: rgba(0,0,0,0.25); height: 36px; border-radius:8px;">
                    <option value="General">General</option>
                    ${supplierOptions}
                </select>
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Name/Batch</label>
                <input type="text" class="v-name" placeholder="e.g. New Stock" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Cost</label>
                <input type="number" class="v-cost" step="0.01" min="0" placeholder="Cost"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Price</label>
                <input type="number" class="v-price" step="0.01" min="0" placeholder="Price" oninput="window.autoCalculateVariantPrices(this)"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Wholesale</label>
                <input type="number" class="v-wholesale" step="0.01" min="0" placeholder="Wholesale"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Loyalty</label>
                <input type="number" class="v-loyalty" step="0.01" min="0" placeholder="Loyalty"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0; grid-column: 1 / -1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Stock</label>
                <input type="number" class="v-stock" step="1" min="0" placeholder="Stock"
                    style="font-size:0.9rem; font-weight:700; background:rgba(16,185,129,0.08); 
                           border:1px solid rgba(16,185,129,0.3); color:#10b981; height:40px; border-radius:8px;">
            </div>
        </div>

        <!-- Variant image row -->
        <div style="display:flex; align-items:center; gap:12px; margin-top:12px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.05);">
            <div id="v-prev-${id}" style="width:44px; height:44px; border-radius:10px; overflow:hidden; border:1px solid rgba(255,255,255,0.15); background:rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; font-size:0.55rem; color:#64748b; flex-shrink:0;">No Img</div>
            <div class="input-group" style="margin-bottom:0; flex:1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Variant Image (optional)</label>
                <input type="file" class="v-image-upload" onchange="window.previewVariantImage(this, 'v-prev-${id}')" 
                    style="font-size:0.75rem; width:100%;">
            </div>
        </div>
    `;
    list.appendChild(div);
};

window.toggleStockVisibility = (mode, stockInputId) => {
    const stockInput = document.getElementById(stockInputId);
    if (!stockInput) return;
    const group = stockInput.closest('.input-group');
    
    const wStockId = stockInputId.replace('-stock', '-wstock');
    const wStockInput = document.getElementById(wStockId);
    const wGroup = wStockInput?.closest('.input-group');

    const isEdit = stockInputId.includes('edit');
    const payBoxId = isEdit ? 'edit-p-pay-methods-box' : 'p-pay-methods-box';
    const payBox = document.getElementById(payBoxId);

    // Payment checkboxes
    const prefix = isEdit ? 'edit-' : '';
    const codBox = document.getElementById(`${prefix}p-pay-cod`);
    const bankBox = document.getElementById(`${prefix}p-pay-bank`);
    const shopBox = document.getElementById(`${prefix}p-pay-shop`);

    if (mode === 'Service' || mode === 'Technical') {
        if (group) group.style.display = 'none';
        if (wGroup) wGroup.style.display = 'none';
        if (payBox) payBox.style.display = 'none';
        stockInput.value = 999999;
        if (wStockInput) wStockInput.value = 999999;
        
        // Rules for Service/Repair (Payment options disabled/hidden)
        // We set them to true as a default but they won't be relevant for POS filtering usually
        if (codBox) codBox.checked = true;
        if (bankBox) bankBox.checked = true;
        if (shopBox) shopBox.checked = true;
    } else {
        if (group) group.style.display = 'block';
        if (wGroup) wGroup.style.display = 'block';
        if (payBox) payBox.style.display = 'block';
        if (stockInput.value === '999999') stockInput.value = 0;
        if (wStockInput && wStockInput.value === '999999') wStockInput.value = 0;

        if (mode === 'Shop') {
            if (codBox) codBox.checked = true;
            if (bankBox) bankBox.checked = true;
            if (shopBox) shopBox.checked = true;
        } else if (mode === 'Warehouse') {
            if (codBox) codBox.checked = true;
            if (bankBox) bankBox.checked = true;
            if (shopBox) shopBox.checked = false; // Warehouse/Web: No shop pickup
        }
    }
};



window.previewVariantImage = (input, previewId) => {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
};

window.addProduct = async function(e) {
    if (e && e.preventDefault) e.preventDefault();
    
    // Safety: ensure it is a form submission or we have the form reference
    const form = e?.target || document.getElementById('product-form');
    if (!form) {
        console.error("Product form not found during submission");
        return;
    }

    if (window._isPublishing) {
        window.showToast("⏳ Please wait, already publishing...", "warning");
        return;
    }
    const submitBtn = form.querySelector('button[type="submit"]');
    
    try {
        window._isPublishing = true;
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerText = "⌛ Publishing...";
        }
        window.showToast("🚀 Publishing product...", "info");

        const name = document.getElementById('p-name')?.value || 'Unnamed';
        const category = document.getElementById('p-category')?.value || '';
        const mode = document.getElementById('p-mode')?.value || 'Shop';
        const hasVariants = document.getElementById('p-has-variants')?.checked || false;

        let productData = {
            name,
            sku: document.getElementById('p-sku')?.value?.trim() || '',
            category,
            mode,
            hasVariants,
            expiryDate: document.getElementById('p-expiry')?.value || '',
            storeId: window.getStoreId(),
            timestamp: serverTimestamp(),
            payMethods: (mode === 'Service' || mode === 'Technical') ? 
                { cod: true, bank: true, shop: true } : 
                {
                    cod: document.getElementById('p-pay-cod')?.checked ?? true,
                    bank: document.getElementById('p-pay-bank')?.checked ?? true,
                    shop: document.getElementById('p-pay-shop')?.checked ?? true
                }
        };

        if (hasVariants) {
            const variants = [];
            const rows = document.querySelectorAll('#variant-list .variant-row');
            for (const row of rows) {
                const vImageFile = row.querySelector('input[type="file"]')?.files[0];
                let vImageUrl = "";
                if (vImageFile) vImageUrl = await window.toBase64(vImageFile);
                
                variants.push({
                    name: row.querySelector('.v-name').value,
                    cost: Math.round((parseFloat(row.querySelector('.v-cost').value) || 0) * 1000) / 1000,
                    price: Math.round((parseFloat(row.querySelector('.v-price').value) || 0) * 1000) / 1000,
                    wholesalePrice: Math.round((parseFloat(row.querySelector('.v-wholesale')?.value) || 0) * 1000) / 1000,
                    loyaltyPrice: Math.round((parseFloat(row.querySelector('.v-loyalty')?.value) || 0) * 1000) / 1000,
                    discount: Math.round((parseFloat(row.querySelector('.v-discount').value) || 0) * 1000) / 1000,
                    stock: parseInt(row.querySelector('.v-stock').value) || 0,
                    image: vImageUrl
                });
            }
            productData.variants = variants;
            if (variants.length > 0) {
                const first = variants[0];
                productData.cost = first.cost;
                productData.price = first.price;
                productData.wholesalePrice = first.wholesalePrice;
                productData.loyaltyPrice = first.loyaltyPrice;
                productData.discount = first.discount;
                productData.stock = variants.reduce((sum, v) => sum + v.stock, 0);
                productData.image = first.image;
            }
        } else {
            productData.cost = Math.round((parseFloat(document.getElementById('p-cost')?.value) || 0) * 1000) / 1000;
            productData.price = Math.round((parseFloat(document.getElementById('p-price')?.value) || 0) * 1000) / 1000;
            productData.wholesalePrice = Math.round((parseFloat(document.getElementById('p-wholesale-price')?.value) || 0) * 1000) / 1000;
            productData.loyaltyPrice = Math.round((parseFloat(document.getElementById('p-loyalty-price')?.value) || 0) * 1000) / 1000;
            productData.discount = Math.round((parseFloat(document.getElementById('p-discount')?.value) || 0) * 1000) / 1000;
            
            if (mode === 'Service' || mode === 'Technical') {
                productData.stock = 999999;
                productData.wStock = 999999;
            } else {
                productData.stock = parseInt(document.getElementById('p-stock')?.value) || 0;
                productData.wStock = parseInt(document.getElementById('p-wstock')?.value) || 0;
            }
            
            const imageFile = document.getElementById('p-image')?.files[0];
            if (imageFile) productData.image = await window.toBase64(imageFile);
        }

        const pRef = doc(productsCol);
        const pId = pRef.id;
        productData.docId = pId;

        setDoc(pRef, productData).catch(err => {
            console.error("Firestore add product error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });

        window.showToast("✅ Product published!", "success");
        document.getElementById('product-form-modal').style.display = 'none';
        form.reset();
        document.getElementById('p-image-preview').innerHTML = "";
        document.getElementById('variant-list').innerHTML = "";
        
        if (window._isFromSINV) {
            window._isFromSINV = false;
            window.allProducts = window.allProducts || [];
            window.allProducts.push(productData);
            
            const searchInput = document.getElementById('sinv-search');
            if (searchInput) {
                searchInput.value = productData.sku || productData.name;
                window.handleSINVSearch(searchInput.value);
            }
            setTimeout(() => {
                window.addToSupplierInvoice(pId);
            }, 500);
        }
    } catch (err) {
        console.error("Add Product Error:", err);
        window.showToast("❌ Error publishing product", "error");
    } finally {
        window._isPublishing = false;
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = "Create Product & Publish";
        }
    }
};

window.toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});

// --- Edit Product Logic & Modal Management ---
window.openEditModalByName = (encodedName) => {
    const name = decodeURIComponent(encodedName);
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim() === name);
    
    if (variants.length === 0) {
        window.showToast("Product variants not found!", "error");
        return;
    }

    // If only 1 variant exists, open the individual edit modal directly to expose all fields
    if (variants.length === 1) {
        window.openEditModal(variants[0].docId);
        return;
    }

    window.currentEditingGroupName = name;
    window.currentEditingId = null; // Mark as group edit
    
    const firstProduct = variants[0];
    const modal = document.getElementById('edit-modal');
    const variantSection = document.getElementById('edit-variants-section');
    const variantList = document.getElementById('edit-variants-list-container');
    const variantCount = document.getElementById('variant-count-badge');
    
    // 1. Reset View and pre-fill common fields from first variant
    document.getElementById('edit-p-name').value = name;
    
    const catSelect = document.getElementById('edit-p-category');
    if (catSelect) {
        window.populateCategoryDropdowns(window.allCategories || []);
        catSelect.value = firstProduct.category || '';
    }

    if (document.getElementById('edit-p-mode')) {
        document.getElementById('edit-p-mode').value = firstProduct.mode || 'Shop';
        window.toggleStockVisibility(firstProduct.mode || 'Shop', 'edit-p-stock');
    }

    const supSelect = document.getElementById('edit-p-supplier');
    if (supSelect) {
        const optionsHtml = (window.allSuppliers || []).map(s => `<option value="${s.docId || s.id}">${s.name}</option>`).join('');
        supSelect.innerHTML = '<option value="">None / General</option>' + optionsHtml;
        supSelect.value = firstProduct.supplierId || '';
    }

    if (firstProduct.payMethods) {
        document.getElementById('edit-p-pay-cod').checked = firstProduct.payMethods.cod !== false;
        document.getElementById('edit-p-pay-bank').checked = firstProduct.payMethods.bank !== false;
        document.getElementById('edit-p-pay-shop').checked = firstProduct.payMethods.shop !== false;
    } else {
        document.getElementById('edit-p-pay-cod').checked = true;
        document.getElementById('edit-p-pay-bank').checked = true;
        document.getElementById('edit-p-pay-shop').checked = true;
    }

    // Pre-fill variant-specific fields for group edit view
    document.getElementById('edit-p-sku').value = firstProduct.sku || '';
    document.getElementById('edit-p-sku').disabled = true;
    const scannerBtn = document.getElementById('edit-p-sku-scan');
    if (scannerBtn) scannerBtn.disabled = true;

    document.getElementById('edit-p-size').value = firstProduct.size || '';
    document.getElementById('edit-p-color').value = firstProduct.color || '';
    document.getElementById('edit-p-cost').value = firstProduct.cost || 0;
    document.getElementById('edit-p-price').value = firstProduct.price || 0;
    document.getElementById('edit-p-discount').value = firstProduct.discount || 0;
    // Auto-calculate wholesale/loyalty from retail if not stored on the product
    const _grpRetail = parseFloat(firstProduct.price) || 0;
    const _grpWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _grpLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('edit-p-wholesale-price').value = (parseFloat(firstProduct.wholesalePrice) > 0)
        ? firstProduct.wholesalePrice
        : (_grpRetail * (1 - _grpWsPct / 100)).toFixed(2);
    document.getElementById('edit-p-loyalty-price').value = (parseFloat(firstProduct.loyaltyPrice) > 0)
        ? firstProduct.loyaltyPrice
        : (_grpRetail * (1 - _grpLoyPct / 100)).toFixed(2);
    document.getElementById('edit-p-stock').value = firstProduct.stock || 0;
    document.getElementById('edit-p-wstock').value = firstProduct.wStock || 0;
    document.getElementById('edit-p-expiry').value = firstProduct.expiryDate || '';

    const mainImgPrev = document.getElementById('edit-p-image-preview');
    if (mainImgPrev) {
        mainImgPrev.innerHTML = firstProduct.image ? `<img src="${firstProduct.image}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">` : '';
    }

    // 2. Manage Visibility
    variantSection.style.display = 'block';
    variantCount.innerText = `${variants.length} VARIANTS`;
    
    // Show all fields, do not hide variant-specific ones
    const formGroups = document.querySelectorAll('#edit-product-form .input-group, #edit-p-pay-methods-box');
    formGroups.forEach(group => {
        group.style.display = 'block';
        if (group.parentElement.classList.contains('form-grid-3')) {
            group.parentElement.style.display = 'grid';
        }
    });
    
    // Render Variant Table
    variantList.innerHTML = `
        <table class="admin-table" style="font-size: 0.85rem;">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>SKU</th>
                    <th>Size</th>
                    <th>Color</th>
                    <th>Supplier</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th style="text-align: right;">Action</th>
                </tr>
            </thead>
            <tbody>
                ${variants.map(v => `
                    <tr>
                        <td>
                            <div style="width: 40px; height: 40px; border-radius: 8px; overflow: hidden; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);">
                                <img src="${v.image || '/logo.png'}" style="width: 100%; height: 100%; object-fit: cover; cursor: pointer;" onclick="window.viewFullImage('${v.image}')" onerror="this.src='/logo.png'">
                            </div>
                        </td>
                        <td style="font-family: monospace; font-weight: bold; color: #38bdf8;">${v.sku || '-'}</td>
                        <td style="font-weight: 600;">${v.size || '-'}</td>
                        <td style="font-weight: 600;">${v.color || '-'}</td>
                        <td>${v.supplierName || 'General'}</td>
                        <td style="font-weight: 700;">LKR ${(v.price || 0).toLocaleString()}</td>
                        <td style="font-weight: 700; color: ${(v.stock || 0) < 5 ? '#ef4444' : '#10b981'};">${v.stock || 0}</td>
                        <td style="text-align: right;">
                            <button type="button" class="icon-btn edit" onclick="window.openEditModal('${v.docId || v.id}', true)" title="Edit this variant">✏️</button>
                            <button type="button" class="icon-btn delete" onclick="window.confirmDeleteVariant('${v.docId || v.id}', '${v.variantId}')" title="Delete this variant">🗑️</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;

    modal.style.display = 'flex';
};

window.openEditModal = (id, isFromGroup = false) => {
    const product = (window.allProducts || []).find(p => p.docId === id);
    if (!product) {
        window.showToast("Product not found!", "error");
        return;
    }

    window.currentEditingId = id;
    
    document.getElementById('edit-variant-list').innerHTML = '';
    const epPreview = document.getElementById('edit-p-image-preview');
    if(epPreview) epPreview.innerHTML = '';

    // Render existing variants so they can be edited or removed
    if (product.variants && product.variants.length > 0) {
        product.variants.forEach(v => {
            window.addEditVariantField('edit-variant-list', v);
        });
    }

    // 1. Restore all fields visibility (Individual Mode)
    const variantSection = document.getElementById('edit-variants-section');
    if (variantSection) variantSection.style.display = 'none';
    
    const formGroups = document.querySelectorAll('#edit-product-form .input-group, #edit-p-pay-methods-box');
    formGroups.forEach(el => el.style.display = 'block');
    
    const grids = document.querySelectorAll('#edit-product-form .form-grid-3');
    grids.forEach(el => el.style.display = 'grid');

    // Enable SKU editing in individual edit mode
    document.getElementById('edit-p-sku').disabled = false;
    const scannerBtn = document.getElementById('edit-p-sku-scan');
    if (scannerBtn) scannerBtn.disabled = false;

    // 2. Populate Fields
    document.getElementById('edit-p-name').value = product.name || 'Unnamed';
    document.getElementById('edit-p-sku').value = product.sku || '';
    
    // 2. Category Dropdown
    const catSelect = document.getElementById('edit-p-category');
    if (catSelect) {
        window.populateCategoryDropdowns(window.allCategories || []);
        catSelect.value = product.category || '';
    }

    // 3. Mode & Base Fields
    if (document.getElementById('edit-p-mode')) {
        document.getElementById('edit-p-mode').value = product.mode || 'Shop';
        window.toggleStockVisibility(product.mode || 'Shop', 'edit-p-stock');
    }

    // [MOD] Populate and Set Primary Supplier
    const supSelect = document.getElementById('edit-p-supplier');
    if (supSelect) {
        const optionsHtml = (window.allSuppliers || []).map(s => `<option value="${s.docId || s.id}">${s.name}</option>`).join('');
        supSelect.innerHTML = '<option value="">None / General</option>' + optionsHtml;
        supSelect.value = product.supplierId || '';
    }

    document.getElementById('edit-p-size').value = product.size || '';
    document.getElementById('edit-p-color').value = product.color || '';

    document.getElementById('edit-p-cost').value = product.cost || 0;
    document.getElementById('edit-p-price').value = product.price || 0;
    document.getElementById('edit-p-discount').value = product.discount || 0;
    // Auto-calculate wholesale/loyalty from retail if not stored on the product
    const _editRetail = parseFloat(product.price) || 0;
    const _editWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _editLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('edit-p-wholesale-price').value = (parseFloat(product.wholesalePrice) > 0)
        ? product.wholesalePrice
        : (_editRetail * (1 - _editWsPct / 100)).toFixed(2);
    document.getElementById('edit-p-loyalty-price').value = (parseFloat(product.loyaltyPrice) > 0)
        ? product.loyaltyPrice
        : (_editRetail * (1 - _editLoyPct / 100)).toFixed(2);
    document.getElementById('edit-p-stock').value = product.stock || 0;
    document.getElementById('edit-p-wstock').value = product.wStock || 0;
    document.getElementById('edit-p-expiry').value = product.expiryDate || '';

    // 4. Payment Methods
    if (product.payMethods) {
        document.getElementById('edit-p-pay-cod').checked = product.payMethods.cod !== false;
        document.getElementById('edit-p-pay-bank').checked = product.payMethods.bank !== false;
        document.getElementById('edit-p-pay-shop').checked = product.payMethods.shop !== false;
    } else {
        document.getElementById('edit-p-pay-cod').checked = true;
        document.getElementById('edit-p-pay-bank').checked = true;
        document.getElementById('edit-p-pay-shop').checked = true;
    }

    // 5. Main Image Preview
    const mainImgPrev = document.getElementById('edit-p-image-preview');
    if (mainImgPrev) {
        mainImgPrev.innerHTML = product.image ? `<img src="${product.image}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">` : '';
    }

    const modal = document.getElementById('edit-modal');
    modal.style.display = 'flex';

    // If coming from group, add a back button or change footer
    const footer = modal.querySelector('.modal-footer');
    if (isFromGroup) {
        const backBtnId = 'edit-back-to-group-btn';
        if (!document.getElementById(backBtnId)) {
            const backBtn = document.createElement('button');
            backBtn.id = backBtnId;
            backBtn.type = 'button';
            backBtn.className = 'action-btn';
            backBtn.style = 'background: #334155; color: white; margin-right: auto;';
            backBtn.innerHTML = '← Back to Group';
            backBtn.onclick = () => window.openEditModalByName(encodeURIComponent(product.name));
            footer.prepend(backBtn);
        } else {
            document.getElementById(backBtnId).style.display = 'block';
            document.getElementById(backBtnId).onclick = () => window.openEditModalByName(encodeURIComponent(product.name));
        }
    } else {
        const backBtn = document.getElementById('edit-back-to-group-btn');
        if (backBtn) backBtn.style.display = 'none';
    }
};

window.closeEditModal = () => {
    document.getElementById('edit-modal').style.display = 'none';
};

window.toggleEditVariantSection = (checked) => {
    document.getElementById('edit-variants-container').style.display = checked ? 'block' : 'none';
    document.getElementById('edit-p-main-image-group').style.display = checked ? 'none' : 'block';
    document.getElementById('edit-p-base-fields').style.display = checked ? 'none' : 'block';
};

window.openBatchEditModal = (prodId, variantId) => {
    const product = (window.allProducts || []).find(p => p.docId === prodId);
    if (!product || !product.variants) return;

    const variant = product.variants.find(v => v.variantId === variantId);
    if (!variant) return;

    document.getElementById('be-product-id').value = prodId;
    document.getElementById('be-variant-id').value = variantId;
    document.getElementById('be-product-name').innerText = product.name;
    document.getElementById('be-batch-info').innerText = `Supplier: ${variant.supplierName || 'N/A'} | Variant: ${variant.variantLabel || 'General'}`;
    
    document.getElementById('be-buying').value = variant.buyingPrice || 0;
    const _beRetail = parseFloat(variant.sellingPrice) || 0;
    document.getElementById('be-retail').value = _beRetail;
    // Auto-calculate wholesale/loyalty from retail if not stored on the variant
    const _beWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _beLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('be-wholesale').value = (parseFloat(variant.wholesalePrice) > 0)
        ? variant.wholesalePrice
        : (_beRetail * (1 - _beWsPct / 100)).toFixed(2);
    document.getElementById('be-loyalty').value = (parseFloat(variant.loyaltyPrice) > 0)
        ? variant.loyaltyPrice
        : (_beRetail * (1 - _beLoyPct / 100)).toFixed(2);
    document.getElementById('be-stock').value = variant.stock || 0;
    document.getElementById('be-size').value = variant.size || '';
    document.getElementById('be-color').value = variant.color || '';
    
    document.getElementById('be-image').value = '';
    const imgPreview = document.getElementById('be-image-preview');
    if (variant.image) {
        imgPreview.innerHTML = `<img src="${variant.image}" style="max-width: 150px; border-radius: 8px;">`;
    } else {
        imgPreview.innerHTML = '';
    }

    document.getElementById('batch-edit-modal').style.display = 'flex';
};

window.closeBatchEditModal = () => {
    document.getElementById('batch-edit-modal').style.display = 'none';
};

window.saveBatchEdit = async () => {
    const prodId = document.getElementById('be-product-id').value;
    const variantId = document.getElementById('be-variant-id').value;

    const buying = Number(document.getElementById('be-buying').value);
    const retail = Number(document.getElementById('be-retail').value);
    const wholesale = Number(document.getElementById('be-wholesale').value);
    const loyalty = Number(document.getElementById('be-loyalty').value);
    const stock = Number(document.getElementById('be-stock').value);
    const size = document.getElementById('be-size').value.trim();
    const color = document.getElementById('be-color').value.trim();

    const saveBtn = document.querySelector('#batch-edit-modal .login-submit-btn');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerText = "💾 SAVING...";
    }

    try {
        const product = (window.allProducts || []).find(p => p.docId === prodId);
        if (!product) throw new Error("Product not found");

        const variants = [...(product.variants || [])];
        const vIdx = variants.findIndex(v => v.variantId === variantId);
        if (vIdx === -1) throw new Error("Batch not found");

        let newImage = variants[vIdx].image || '';
        const imageFile = document.getElementById('be-image').files[0];
        if (imageFile) {
            newImage = await window.resizeImageToBase64(imageFile, 200); // 200px max for variants
        }

        variants[vIdx] = {
            ...variants[vIdx],
            buyingPrice: Math.round(buying  * 100) / 100,
            sellingPrice: Math.round(retail  * 100) / 100,
            wholesalePrice: Math.round(wholesale  * 100) / 100,
            loyaltyPrice: Math.round(loyalty  * 100) / 100,
            stock: stock,
            size: size,
            color: color,
            image: newImage,
            lastUpdated: Date.now()
        };

        const totalStock = variants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
        
        // Optimistic UI update: close modal and show toast instantly
        window.closeBatchEditModal();
        window.showToast("Batch updated successfully!", "success");

        // Update Firestore in the background
        const pRef = doc(db, "products", prodId);
        updateDoc(pRef, {
            variants: variants,
            stock: totalStock,
            totalStock: totalStock,
            lastUpdated: serverTimestamp()
        }).catch(err => {
            console.error("Firestore batch update error:", err);
            window.showToast("Cloud update delay: " + err.message, "warning");
        });

    } catch (err) {
        console.error(err);
        window.showToast("Error updating batch: " + err.message, "error");
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerText = "💾 SAVE BATCH";
        }
    }
};

window.switchProdModalTab = (btn, tabId, formId) => {
    // tabId is either 'p-general', 'p-stocks', 'edit-p-general', or 'edit-p-stocks'
    const modal = btn.closest('.admin-modal');
    modal.querySelectorAll('.prod-tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    modal.querySelectorAll('.prod-tab-view').forEach(v => v.style.display = 'none');
    document.getElementById(tabId + '-tab').style.display = 'block';
};

window.addEditVariantField = (listId = 'edit-variant-list', v = null) => {
    const list = document.getElementById(listId);
    if (!list) return;

    // Detect mode to determine if supplier is needed
    const modeSelect = listId === 'variant-list' ? document.getElementById('p-mode') : document.getElementById('edit-p-mode');
    const isService = modeSelect ? (modeSelect.value === 'Service' || modeSelect.value === 'Technical') : false;

    // Get base values to pre-fill if possible
    const baseCost = v ? (v.buyingPrice || v.cost || 0) : (parseFloat(document.getElementById(listId === 'variant-list' ? 'p-cost' : 'edit-p-cost')?.value) || 0);
    const basePrice = v ? (v.sellingPrice || v.price || 0) : (parseFloat(document.getElementById(listId === 'variant-list' ? 'p-price' : 'edit-p-price')?.value) || 0);
    const baseWS = v ? (v.wholesalePrice || 0) : 0;
    const baseLoyalty = v ? (v.loyaltyPrice || 0) : 0;
    const baseStock = v ? (v.stock || 0) : 0;
    const baseSize = v ? (v.size || '') : '';
    const baseColor = v ? (v.color || '') : '';
    const baseVariantId = v ? (v.variantId || `VAR-${Math.floor(1000 + Math.random()*9000)}`) : `VAR-${Math.floor(1000 + Math.random()*9000)}`;

    const id = Date.now();
    const div = document.createElement('div');
    div.className = 'variant-row';
    
    div.style = `
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(99,179,237,0.15);
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 14px;
        position: relative;
    `;
    
    const supplierOptions = (window.allSuppliers || []).map(s => 
        `<option value="${s.name}" ${v && (v.supplierName === s.name || v.supplierId === s.id) ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    const supplierColHtml = isService ? '' : `
        <div class="input-group" style="margin-bottom:0;">
            <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Supplier</label>
            <select class="v-supplier" style="font-size:0.82rem; background: rgba(0,0,0,0.25); height: 36px; border-radius:8px;">
                <option value="General">General</option>
                ${supplierOptions}
            </select>
        </div>
    `;

    div.innerHTML = `
        <!-- Header row: Variant ID + delete button -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:0.65rem; opacity:0.5; text-transform:uppercase; letter-spacing:0.08em;">Variant ID</span>
                <input type="text" class="v-id" value="${baseVariantId}" 
                    style="font-weight:700; color:#38bdf8; font-size:0.85rem; background:rgba(56,189,248,0.07); 
                           border:1px solid rgba(56,189,248,0.2); border-radius:8px; padding:4px 10px; width:130px; height:32px;">
            </div>
            <button type="button" onclick="this.closest('.variant-row').remove()" 
                style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.3); color:#f87171;
                       border-radius:8px; width:30px; height:30px; cursor:pointer; font-size:0.85rem;
                       display:flex; align-items:center; justify-content:center; flex-shrink:0;">✕</button>
        </div>

        <!-- Main fields grid: 2 columns -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            ${supplierColHtml}
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Size</label>
                <input type="text" class="v-size" placeholder="L, XL, 500g" value="${baseSize}"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Color</label>
                <input type="text" class="v-color" placeholder="Red, Blue" value="${baseColor}"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Cost (Buying)</label>
                <input type="number" class="v-cost" value="${baseCost}" step="0.01" min="0" placeholder="Cost" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Price (Selling)</label>
                <input type="number" class="v-price" value="${basePrice}" step="0.01" min="0" placeholder="Selling" oninput="window.autoCalculateVariantPrices(this)" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">WS Price</label>
                <input type="number" class="v-wholesale" value="${baseWS}" step="0.01" min="0" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Loyalty Points</label>
                <input type="number" class="v-loyalty" value="${baseLoyalty}" step="0.01" min="0" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0; grid-column: 1 / -1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Stock</label>
                <input type="number" class="v-stock" value="${baseStock}" step="1" min="0" 
                    style="font-size:0.9rem; font-weight:700; background:rgba(16,185,129,0.08); 
                           border:1px solid rgba(16,185,129,0.3); color:#10b981; height:40px; border-radius:8px;">
            </div>
        </div>

        <!-- Variant image row -->
        <div style="display:flex; align-items:center; gap:12px; margin-top:12px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.05);">
            <div id="ev-prev-${id}" style="width:44px; height:44px; border-radius:10px; overflow:hidden; border:1px solid rgba(255,255,255,0.15); background:rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; font-size:0.55rem; color:#64748b; flex-shrink:0;">No Img</div>
            <div class="input-group" style="margin-bottom:0; flex:1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Variant Image (optional)</label>
                <input type="file" class="v-image-upload" onchange="window.previewVariantImage(this, 'ev-prev-${id}')" 
                    style="font-size:0.75rem; width:100%;">
            </div>
        </div>
    `;
    list.appendChild(div);
};




// --- Extended Product & Bulk Upload logic extracted to modules/inventory.js ---

window.calcInput = (val) => {
    const disp = document.getElementById('calc-display');
    if (disp) disp.value += val;
};
window.calcClear = () => {
    const disp = document.getElementById('calc-display');
    if (disp) disp.value = '';
};
window.viewFullImage = (src) => {
    if (!src || src === '/logo.png') return;
    const overlay = document.createElement('div');
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); z-index:999999; display:flex; align-items:center; justify-content:center; cursor:zoom-out;";
    overlay.onclick = () => overlay.remove();
    const img = document.createElement('img');
    img.src = src;
    img.style = "max-width:90%; max-height:90%; border-radius:12px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);";
    overlay.appendChild(img);
    document.body.appendChild(overlay);
};

window.calcResult = () => {
    const disp = document.getElementById('calc-display');
    if (!disp) return;
    try {
        const sanitized = disp.value.replace(/[^0-9+\-*/.]/g, '');
        disp.value = eval(sanitized);
    } catch (e) {
        disp.value = "Error";
    }
};

window.showCalculator = () => {
    document.getElementById('calc-display').value = '';
    document.getElementById('calc-modal').style.display = 'flex';
};

// Repair intake functions migrated to modules/repairs.js

// --- HRM System Logic ---
window.generateEmployeeID = (force = false) => {
    const regnoInput = document.getElementById('emp-regno');
    if (!regnoInput || window.editingEmployeeId) return;

    const filtered = window.filterByStore(window.allEmployees || []);
    const nextId = 'EMP-' + String(filtered.length + 1).padStart(3, '0');
    
    const currentVal = regnoInput.value.trim();
    // Only update if it's currently a default/placeholder value OR if we are forcing it (on page load)
    const isBlankOrDefault = !currentVal || currentVal === '' || currentVal === 'EMP-001' || currentVal === 'EMP-000';

    if (force || isBlankOrDefault) {
        if (regnoInput.value !== nextId) {
            regnoInput.value = nextId;
        }
    }
};

window.showHRMSubTab = (tab) => {
    document.querySelectorAll('.hrm-sub-content').forEach(c => c.style.display = 'none');
    document.querySelectorAll('.sub-tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`hrm-sub-${tab}`).style.display = 'block';
    document.getElementById(`hrm-btn-${tab}`).classList.add('active');

    if (tab === 'employees' && !window.editingEmployeeId) {
        window.generateEmployeeID();
    } else if (tab === 'attendance') {
        if (typeof syncAttendanceUI === 'function') syncAttendanceUI();
    }
};

window.shareStaffPortal = (phone, pin, username, password) => {
    if (!phone) return window.showToast("No phone number found!", "warning");
    
    const baseUrl = window.location.origin;
    const portalUrl = baseUrl.startsWith('file://') ? 'https://mecbookshop.com.lk/staff.html' : `${baseUrl}/staff.html`;
    let message = `*MEC STAFF PORTAL*\n\nHello! You can now access your Pay Slips and Attendance reports online.\n\n🔗 *Link:* ${portalUrl}\n🔑 *Your PIN:* ${pin}\n\nLogin with your Phone Number and the PIN provided above.`;
    
    const encoded = encodeURIComponent(message);
    const waUrl = `https://wa.me/${phone}?text=${encoded}`;
    
    if (window.electronAPI && window.electronAPI.openExternal) {
        window.electronAPI.openExternal(waUrl);
    } else {
        window.open(waUrl, '_blank');
    }
    window.showToast("📲 Portal credentials shared!", "success");
};

function renderAdminEmployeesUI(employees) {
    const listDiv = document.getElementById('admin-employee-list');
    const tableBody = document.getElementById('employee-list-table-body');
    if (!listDiv) return;
    const storeId = window.getStoreId();
    
    // Branch Filter Logic for HRM
    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');

    const filtered = employees.filter(emp => {
        // Store Filter (SaaS boundaries)
        const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master');
        
        if (emp.storeId && emp.storeId !== storeId) return false;
        if (!emp.storeId && !isMainMec) return false;

        // Branch Visibility
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            // Staff only see their own branch
            if (emp.branchId && emp.branchId !== userBranch) return false;
            if (!emp.branchId && userBranch !== 'Global') return false;
        } else {
            // Admins see all matching branches for the store, filtered by the dropdown
            if (activeBranchFilter !== 'All' && emp.branchId !== activeBranchFilter) return false;
        }
        return true;
    });

    listDiv.innerHTML = filtered.map(emp => {
        const branchName = emp.branchId === 'Global' ? 'Main Office' : (window.allBranches?.find(b => b.docId === emp.branchId)?.name || 'N/A');
        const safeName = emp.name || 'Unknown';
        return `
        <div class="employee-card">
            <div style="position:absolute; top:12px; left:12px; background:var(--primary-blue); color:white; font-size:0.65rem; padding:3px 8px; border-radius:10px; font-weight:800;">${emp.regno || 'NO-ID'}</div>
            <div class="emp-avatar">${safeName.charAt(0).toUpperCase()}</div>
            <div class="emp-name">${safeName}</div>
            <div class="emp-role">${emp.role}</div>
            <div style="font-size:0.75rem; color:var(--primary-blue); font-weight:700; margin-bottom:5px;">🏢 ${branchName}</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:8px;">📞 ${emp.phone}</div>
            <div style="font-weight:700; color:var(--success-green);">Basic: LKR ${emp.salary || 0}</div>
            <div style="font-size:0.85rem; font-weight:600; color:var(--primary-blue);">Commission: ${emp.commission || 0}%</div>
            <div style="position:absolute; top:12px; right:12px; display:flex; gap:8px; background: rgba(241, 245, 249, 0.9); padding: 6px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); backdrop-filter: blur(5px); border: 1px solid rgba(255,255,255,0.5);">
                <button onclick="window.sendEmployeeSMS('${emp.phone}', '${safeName}', '${emp.regno}', '${emp.username || ''}', '${emp.password || ''}')" style="border:none; background:white; color:#3b82f6; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(59,130,246,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Send SMS">💬</button>
                <button onclick="window.recordEmployeeLeave('${emp.docId}', '${safeName}')" style="border:none; background:white; color:#10b981; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(16,185,129,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Record Leave">🗓️</button>
                <button onclick="window.shareStaffPortal('${emp.phone}', '${emp.regno}', '${emp.username || ''}', '${emp.password || ''}')" style="border:none; background:white; color:#8b5cf6; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(139,92,246,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Send Portal Link">📲</button>
                <button onclick="window.editEmployee('${emp.docId}')" style="border:none; background:white; color:#f59e0b; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(245,158,11,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Edit Staff">✏️</button>
                <button onclick="confirmDeleteEmployee('${emp.docId}')" style="border:none; background:white; color:#ef4444; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(239,68,68,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Delete Staff">🗑️</button>
            </div>
        </div>
    `;
    }).join('');

    if (tableBody) {
        tableBody.innerHTML = filtered.map(emp => {
            return `
                <tr>
                    <td>${emp.regno || '-'}</td>
                    <td style="font-weight:bold; color:var(--primary-blue);">${emp.name || 'Unknown'}</td>
                    <td>${emp.phone}</td>
                    <td>${emp.address || '-'}</td>
                    <td>${emp.username || '-'}</td>
                    <td><span style="background:#f1f5f9; padding:3px 8px; border-radius:5px; font-family:monospace; user-select:all;">${emp.password || '-'}</span></td>
                    <td>
                        <button onclick="window.editEmployee('${emp.docId}')" class="icon-btn edit">✏️</button>
                        <button onclick="confirmDeleteEmployee('${emp.docId}')" class="icon-btn delete">🗑️</button>
                    </td>
                </tr>
            `;
        }).join('');
    }
}

window.downloadEmployeeExcel = () => {
    const tableBody = document.getElementById('employee-list-table-body');
    if (!tableBody) return;
    
    let csv = "Register No,Name,Phone,Address,System Username,System Password\n";
    const rows = tableBody.querySelectorAll('tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 6) {
            const reg = cols[0].innerText.trim();
            const name = cols[1].innerText.trim();
            const phone = cols[2].innerText.trim();
            const addr = cols[3].innerText.trim();
            const usr = cols[4].innerText.trim();
            const pwd = cols[5].innerText.trim();
            csv += `"${reg}","${name}","${phone}","${addr}","${usr}","${pwd}"\n`;
        }
    });

    downloadFile(csv, "employee_list.csv");
};

window.downloadAttendanceReport = () => {
    const date = document.getElementById('attendance-date-filter').value || new Date().toISOString().split('T')[0];
    const employees = window.allEmployees || [];
    const attendance = window.allAttendance || [];

    let csv = "Employee Name,Role,Status,Time,Note,Date\n";
    employees.forEach(emp => {
        const record = attendance.find(a => a.empId === emp.docId && a.date === date);
        const status = record ? record.status : 'Pending';
        const time = record?.time || '--:--';
        const note = record?.note || '-';
        csv += `"${emp.name}","${emp.role}","${status}","${time}","${note}","${date}"\n`;
    });

    downloadFile(csv, `attendance_report_${date}.csv`);
};

function syncAttendanceUI() {
    const tableBody = document.getElementById('attendance-log-body');
    const filterDateInput = document.getElementById('attendance-date-filter');
    if (!tableBody) return;

    if (!filterDateInput.value) filterDateInput.value = new Date().toISOString().split('T')[0];
    const selectedDate = filterDateInput.value;
    const employees = window.allEmployees || [];
    const attendance = window.allAttendance || [];

    const storeId = window.getStoreId();
    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');

    const filteredEmployees = employees.filter(emp => {
        const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master');
        if (emp.storeId && emp.storeId !== storeId) return false;
        if (!emp.storeId && !isMainMec) return false;

        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            if (emp.branchId && emp.branchId !== userBranch) return false;
            if (!emp.branchId && userBranch !== 'Global') return false;
        } else {
            if (activeBranchFilter !== 'All' && emp.branchId !== activeBranchFilter) return false;
        }
        return true;
    });

    tableBody.innerHTML = filteredEmployees.map(emp => {
        const record = attendance.find(a => a.empId === emp.docId && a.date === selectedDate);
        const status = record ? record.status : 'Pending';
        const badgeClass = status === 'Present' ? 'success' : (status === 'Absent' ? 'danger' : 'warning');

        return `
            <tr>
                <td style="font-weight:700;">${emp.name}</td>
                <td>${emp.role}</td>
                <td>
                    <div style="display:flex; gap:10px; align-items:center;">
                        <button onclick="markAttendance('${emp.docId}', 'Present')" class="action-btn ${status === 'Present' ? 'success' : ''}" style="padding:4px 8px; font-size:0.7rem;">Present</button>
                        <button onclick="markAttendance('${emp.docId}', 'Absent')" class="action-btn ${status === 'Absent' ? 'danger' : ''}" style="padding:4px 8px; font-size:0.7rem;">Absent</button>
                    </div>
                </td>
                <td>${record?.time || '--:--'}</td>
                <td>${record?.note || '-'}</td>
            </tr>
        `;
    }).join('');
}

window.markAttendance = async (empId, status) => {
    const date = document.getElementById('attendance-date-filter').value;
    const existing = (window.allAttendance || []).find(a => a.date === date && a.empId === empId);

    const data = {
        empId,
        date,
        status,
        storeId: window.getStoreId(),
        time: new Date().toLocaleTimeString(),
        timestamp: serverTimestamp()
    };

    if (existing) {
        await updateDoc(doc(db, 'attendance', existing.docId), data);
    } else {
        await addDoc(attendanceCol, data);
    }
    window.showToast(`Marked ${status} for Staff`, "success");
};

function renderAdminPayrollUI(payroll) {
    const listDiv = document.getElementById('admin-payroll-list');
    if (!listDiv) return;
    listDiv.innerHTML = payroll.length === 0 ? '<p>No history found.</p>' : payroll.map(p => `
        <div style="padding:15px; background:#f8fafc; border-radius:12px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <div style="font-weight:800; color:var(--primary-blue);">${p.empName}</div>
                <div style="font-size:0.8rem; color:var(--text-muted);">${p.month} | ${p.note}</div>
            </div>
            <div style="display:flex; align-items:center; gap:15px;">
                <div style="font-weight:900; color:var(--primary-blue);">LKR ${p.amount}</div>
                <button onclick="window.downloadPaysheet('${p.docId}')" style="border:none; background:none; cursor:pointer; font-size:1.2rem;" title="Download Paysheet">📥</button>
            </div>
        </div>
    `).join('');
}

window.downloadPaysheet = (pId) => {
    const p = (window.allPayroll || []).find(x => x.docId === pId);
    if (!p) return;

    let content = `------------------------------------------\n`;
    content += `        MEC BOOK SHOP - PAY SHEET       \n`;
    content += `------------------------------------------\n`;
    content += `Employee: ${p.empName}\n`;
    content += `Month:    ${p.month}\n`;
    content += `Amount:   LKR ${p.amount}\n`;
    content += `Note:     ${p.note || '-'}\n`;
    content += `Date:     ${new Date(p.timestamp?.seconds * 1000).toLocaleDateString()}\n`;
    content += `------------------------------------------\n`;
    content += `Generated by MEC HRM System\n`;

    downloadFile(content, `paysheet_${p.empName}_${p.month}.txt`);
};

window.sendEmployeeSMS = async (phone, name, pin, username, password) => {
    if (!phone) return window.showToast("No phone number found!", "warning");
    
    const baseUrl = window.location.origin;
    const portalUrl = baseUrl.startsWith('file://') ? 'https://mecbookshop.com.lk/staff.html' : `${baseUrl}/staff.html`;
    
    // Default message with credentials
    const bizName = window.systemConfig?.bizName || 'MEC';
    let defaultMsg = `Hello ${name}, ${bizName} Staff Portal Link: ${portalUrl} PIN: ${pin}`;


    const msg = await window.asyncPrompt(`Enter SMS message for ${name}:`, `SMS Dispatch`, "text", defaultMsg);
    if (!msg) return;

    // Format phone for SMSLenz (e.g., 071... -> 9471...)
    let formattedPhone = phone.replace(/\D/g, '');
    if (formattedPhone.startsWith('0')) {
        formattedPhone = '94' + formattedPhone.substring(1);
    }
    
    if (formattedPhone.length !== 11) {
        return window.showToast("Invalid phone number format for SMS.", "error");
    }

    const smsConf = window.systemConfig?.smsConfig || {};
    const apiBase = smsConf.apiBase || "https://www.smslenz.lk/api/send-sms";
    const apiKey = smsConf.apiKey;
    const userId = smsConf.userId;
    const senderId = smsConf.senderId || "MECPOS";

    if (!apiKey || !userId) {
        return window.showToast("⚠️ SMS Gateway not configured. Please enter API Key in Settings.", "warning");
    }

    try {
        const url = new URL(apiBase);
        url.searchParams.append("user_id", userId);
        url.searchParams.append("api_key", apiKey);
        url.searchParams.append("sender_id", senderId);
        url.searchParams.append("contact", '+' + formattedPhone);
        url.searchParams.append("message", msg);

        await fetch(url.toString(), {
            method: 'GET',
            mode: 'no-cors' 
        });

        window.showToast("📲 SMS dispatched via SMSLenz!", "success");
    } catch (error) {
        console.error("SMS Error:", error);
        window.showToast("Failed to send SMS.", "error");
    }
};

window.sendDirectSMS = async (phone, msg) => {
    if (!phone) return;
    let formattedPhone = phone.replace(/\D/g, '');
    if (formattedPhone.startsWith('0')) {
        formattedPhone = '94' + formattedPhone.substring(1);
    }
    if (formattedPhone.length !== 11) return;

    const smsConf = window.systemConfig?.smsConfig || {};
    const apiBase = smsConf.apiBase || "https://www.smslenz.lk/api/send-sms";
    const apiKey = smsConf.apiKey;
    const userId = smsConf.userId;
    const senderId = smsConf.senderId || "MECPOS";

    if (!apiKey || !userId) {
        console.warn("[Auto SMS] SMS Gateway not configured in Settings.");
        return;
    }

    try {
        const url = new URL(apiBase);
        url.searchParams.append("user_id", userId);
        url.searchParams.append("api_key", apiKey);
        url.searchParams.append("sender_id", senderId);
        url.searchParams.append("contact", '+' + formattedPhone);
        url.searchParams.append("message", msg);

        await fetch(url.toString(), {
            method: 'GET',
            mode: 'no-cors' 
        });
        console.log(`[Auto SMS] Dispatched to ${formattedPhone}`);

        // Log the SMS sent activity into Firestore
        const cleanPhoneToMatch = formattedPhone.replace(/\D/g, '');
        const matchedCust = (window.allCustomers || []).find(c => {
            const cleanCPhone = (c.phone || '').replace(/\D/g, '');
            return cleanCPhone !== '' && (
                cleanCPhone === cleanPhoneToMatch || 
                ('94' + cleanCPhone.substring(1) === cleanPhoneToMatch) || 
                (cleanCPhone.substring(2) === cleanPhoneToMatch.substring(2))
            );
        });
        const custName = matchedCust ? matchedCust.name : 'Unknown';
        const custId = matchedCust ? matchedCust.docId : null;

        await addDoc(collection(db, 'ai_copilot_logs'), {
            type: 'SMS',
            title: `Branded SMS Sent`,
            description: `Branded SMS successfully dispatched to ${custName} (${formattedPhone}). Message: "${msg}"`,
            phone: formattedPhone,
            customerName: custName,
            customerId: custId,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp()
        });
    } catch (error) {
        console.error("Auto SMS Error:", error);
    }
};

window.recordEmployeeLeave = async (empId, name) => {
    const reason = await window.asyncPrompt(`Record Leave for ${name}. Enter reason/type (e.g. Sick Leave, Annual):`, "Leave Registration", "text");
    if (reason === null) return;

    const date = await window.asyncPrompt(`Enter Date (YYYY-MM-DD):`, "Leave Date", "text", new Date().toISOString().split('T')[0]);
    if (!date) return;

    try {
        await addDoc(collection(db, 'attendance'), {
            empId,
            date,
            status: 'On Leave',
            note: reason,
            time: '--:--',
            storeId: window.getStoreId(),
            timestamp: serverTimestamp()
        });
        window.showToast(`✅ Leave recorded for ${name}`, "success");
        if (typeof syncAttendanceUI === 'function') syncAttendanceUI();
    } catch (err) {
        console.error(err);
        window.showToast("Failed to record leave.", "error");
    }
};

function populatePayrollStaffDropdown(employees) {
    const paySelect = document.getElementById('pay-emp-id');
    const posSelect = document.getElementById('pos-cashier-id');
    const filtered = window.filterByStore(employees);

    const options = '<option value="">Select Employee</option>' + filtered.map(e => `<option value="${e.docId}">${e.name}</option>`).join('');

    if (paySelect) paySelect.innerHTML = options;
    if (posSelect) posSelect.innerHTML = options;
}

window.calculateStaffPayroll = () => {
    const empId = document.getElementById('pay-emp-id').value;
    const monthStr = document.getElementById('pay-month').value; // YYYY-MM
    const infoBox = document.getElementById('payroll-calc-info');
    const amountInput = document.getElementById('pay-amount');

    if (!empId || !monthStr) {
        infoBox.style.display = 'none';
        return;
    }

    const emp = (window.allEmployees || []).find(e => e.docId === empId);
    if (!emp) return;

    // Filter sales for this employee in this month
    const [year, month] = monthStr.split('-');
    const yearInt = parseInt(year);
    const monthInt = parseInt(month);
    let totalSales = 0;
    
    for (let i = 0; i < (window.allOrders || []).length; i++) {
        const o = window.allOrders[i];
        if (!o.isPOS || o.staffId !== empId) continue;
        const d = (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : new Date(o.date));
        if (d.getFullYear() === yearInt && (d.getMonth() + 1) === monthInt) {
            totalSales += (o.total || 0);
        }
    }
    const commissionPct = parseFloat(emp.commission || 0);
    const commissionEarned = totalSales * (commissionPct / 100);
    const basicSalary = parseFloat(emp.salary || 0);
    const epfEmployee = (emp.epfEnabled !== false) ? (basicSalary * 0.08) : 0;
    const totalPayable = basicSalary + commissionEarned - epfEmployee;

    document.getElementById('calc-base-salary').innerText = `LKR ${basicSalary.toFixed(2)}`;
    document.getElementById('calc-monthly-sales').innerText = `LKR ${totalSales.toFixed(2)}`;
    document.getElementById('calc-commission').innerText = `LKR ${commissionEarned.toFixed(2)} (${commissionPct}%)`;
    
    // Add EPF deduction display
    const existingEpf = document.getElementById('calc-epf-deduction');
    if (existingEpf) existingEpf.innerText = `LKR ${epfEmployee.toFixed(2)}`;
    
    document.getElementById('calc-total-payable').innerText = `LKR ${totalPayable.toFixed(2)}`;

    amountInput.value = totalPayable.toFixed(2);
    infoBox.style.display = 'block';
};

window.runAIPayrollProcess = async () => {
    const monthStr = document.getElementById('pay-month').value;
    if (!monthStr) {
        return window.showToast("⚠️ Please select 'Payment For Month' first!", "warning");
    }

    const proceed = await window.asyncConfirm(`🤖 Run AI Auto-Payroll?\n\nThis will automatically calculate salaries, EPF, and sales commissions for ALL active employees for ${monthStr}.`, "AI Processor");
    if (!proceed) return;

    window.showToast("🤖 AI Analyzing Attendance & Sales Data...", "info");
    
    // Simulate AI reasoning delay for dramatic effect
    setTimeout(async () => {
        let totalProcessed = 0;
        let totalCost = 0;
        const [year, month] = monthStr.split('-');

        // Process each employee
        for (const emp of (window.allEmployees || [])) {
            // Check if already paid for this month to prevent duplicates
            const alreadyPaid = (window.allPayroll || []).some(p => p.empId === emp.docId && p.month === monthStr);
            if (alreadyPaid) continue;

            const sales = (window.allOrders || []).filter(o => {
                if (!o.isPOS || o.staffId !== emp.docId) return false;
                const d = (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : new Date(o.date));
                return d.getFullYear() === parseInt(year) && (d.getMonth() + 1) === parseInt(month);
            });

            const totalSales = sales.reduce((sum, o) => sum + (o.total || 0), 0);
            const commissionPct = parseFloat(emp.commission || 0);
            const commissionEarned = totalSales * (commissionPct / 100);
            const basicSalary = parseFloat(emp.salary || 0);
            const epfEmployee = (emp.epfEnabled !== false) ? (basicSalary * 0.08) : 0;
            const totalPayable = basicSalary + commissionEarned - epfEmployee;

            if (totalPayable > 0) {
                totalProcessed++;
                totalCost += totalPayable;
                
                // Construct payroll object
                const payload = {
                    empId: emp.docId,
                    empName: emp.name,
                    month: monthStr,
                    amount: totalPayable,
                    note: `AI Processed: Base ${basicSalary} | Comm ${commissionEarned.toFixed(2)} | EPF -${epfEmployee.toFixed(2)}`,
                    timestamp: window.firebase.firestore.FieldValue.serverTimestamp(),
                    storeId: window.getStoreId(),
                    branchId: emp.branchId || 'Global'
                };
                
                try {
                    await window.firebase.firestore().collection('payroll').add(payload);
                } catch(e) {
                    console.error("AI Save Error:", e);
                }
            }
        }
        
        if (totalProcessed === 0) {
            window.showToast("🤖 AI found no new payroll records to process (already paid or 0 salary).", "warning");
        } else {
            window.showToast(`✅ AI Processed ${totalProcessed} Employees.\nTotal Payout: LKR ${totalCost.toFixed(2)}`, "success");
        }
        document.getElementById('payroll-form').reset();
        document.getElementById('payroll-calc-info').style.display = 'none';
    }, 2500);
};


window.editingEmployeeId = null;

window.editEmployee = (docId) => {
    const emp = (window.allEmployees || []).find(e => e.docId === docId);
    if (!emp) return;

    window.showHRMSubTab('employees');
    window.editingEmployeeId = docId;
    document.getElementById('emp-name').value = emp.name || '';
    document.getElementById('emp-role').value = emp.role || 'Other';
    document.getElementById('emp-phone').value = emp.phone || '';
    document.getElementById('emp-regno').value = emp.regno || '';
    document.getElementById('emp-address').value = emp.address || '';
    document.getElementById('emp-salary').value = emp.salary || 0;
    document.getElementById('emp-commission').value = emp.commission || 0;
    document.getElementById('emp-ot-rate').value = emp.otRate || 0;
    document.getElementById('emp-late-rate').value = emp.latePenalty || 0;
    document.getElementById('emp-epf-enabled').checked = emp.epfEnabled !== false;
    document.getElementById('emp-apit-enabled').checked = !!emp.apitEnabled;
    document.getElementById('emp-hardware-id').value = emp.hardwareId || "";
    document.getElementById('emp-username').value = emp.username || "";
    document.getElementById('emp-password').value = emp.password || "";
    document.getElementById('emp-access-role').value = emp.role_access || 'none';
    document.getElementById('emp-branch-id').value = emp.branchId || 'Global';

    const submitBtn = document.querySelector('#employee-form button[type="submit"]');
    if (submitBtn) submitBtn.innerText = "💾 Save Changes";

    document.getElementById('emp-name').focus();
    // Scroll to form
    document.getElementById('employee-form').scrollIntoView({ behavior: 'smooth' });
};

document.getElementById('employee-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('emp-name')?.value || 'New Staff';
    const role = document.getElementById('emp-role')?.value || 'Staff';
    const phone = document.getElementById('emp-phone')?.value || '';
    const regno = document.getElementById('emp-regno')?.value || '';
    const address = document.getElementById('emp-address')?.value || '';
    const role_access = document.getElementById('emp-access-role')?.value || 'none';
    const branchId = document.getElementById('emp-branch-id')?.value || 'Global';
    const storeId = window.getStoreId();

    const staffData = { 
        name, role, phone, regno, address, 
        salary: parseFloat(document.getElementById('emp-salary')?.value) || 0,
        commission: parseFloat(document.getElementById('emp-commission')?.value) || 0,
        otRate: parseFloat(document.getElementById('emp-ot-rate')?.value) || 0,
        latePenalty: parseFloat(document.getElementById('emp-late-rate')?.value) || 0,
        epfEnabled: document.getElementById('emp-epf-enabled')?.checked ?? true,
        apitEnabled: !!document.getElementById('emp-apit-enabled')?.checked,
        hardwareId: document.getElementById('emp-hardware-id')?.value?.trim() || "",
        username: document.getElementById('emp-username')?.value || "",
        password: document.getElementById('emp-password')?.value || "",
        role_access, branchId, storeId, 
        timestamp: serverTimestamp() 
    };

    try {
        window.showToast(navigator.onLine ? "🚀 Syncing staff details..." : "💾 Saving staff record locally...", "info");
        if (window.editingEmployeeId) {
            await updateDoc(doc(db, 'employees', window.editingEmployeeId), staffData);
            window.showToast(navigator.onLine ? "✅ Staff Details Updated!" : "✅ Saved Locally", "success");
            window.editingEmployeeId = null;
            const submitBtn = document.querySelector('#employee-form button[type="submit"]');
            if (submitBtn) submitBtn.innerText = "Register Employee";
        } else {
            await addDoc(employeesCol, staffData);
            window.showToast(navigator.onLine ? "✅ Staff Registered Successfully!" : "✅ Registered Locally", "success");
        }
        e.target.reset();
        window.generateEmployeeID(); // Re-generate for next if new
    } catch (err) {
        console.error(err);
        window.showToast("Error processing request!", "error");
    }
});

// Hardware Sync Implementation Stub
window.testHardwareConnection = () => {
    const ip = document.getElementById('hrm-hw-ip').value;
    const port = document.getElementById('hrm-hw-port').value;
    const statusEl = document.getElementById('hrm-hw-status');
    const logsEl = document.getElementById('hrm-hw-logs');

    if (!ip) return window.showToast("Please enter Device IP", "warning");

    statusEl.innerText = "Connecting...";
    statusEl.style.color = "#fbbf24";
    logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] Pinging ${ip}:${port}...`;

    // Simulated Hardware Polling Logic
    setTimeout(() => {
        if (ip.includes('192.168')) {
            statusEl.innerText = "Online & Syncing";
            statusEl.style.color = "#10b981";
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] ✅ Device Connected!`;
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] 📥 Fetching 42 new attendance logs...`;
            window.showToast("Biometric Device Synced Successfully!", "success");
        } else {
            statusEl.innerText = "Connection Failed";
            statusEl.style.color = "#ef4444";
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] ❌ Network Timeout. Check IP.`;
            window.showToast("Device Connection Failed!", "error");
        }
    }, 2000);
};

document.getElementById('payroll-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const empId = document.getElementById('pay-emp-id').value;
    const amount = parseFloat(document.getElementById('pay-amount').value);
    const month = document.getElementById('pay-month').value;
    const note = document.getElementById('pay-note').value;

    const emp = window.allEmployees.find(e => e.docId === empId);
    if (!emp) return;

    window.showToast(navigator.onLine ? "🚀 Processing payroll..." : "💾 Saving payroll locally...", "info");
    await addDoc(payrollCol, { 
        empId, 
        empName: emp.name, 
        amount, 
        month, 
        note, 
        storeId: window.getStoreId(),
        timestamp: serverTimestamp() 
    });

    // Also log as Expense automatically
    await addDoc(expensesCol, {
        title: `Salary: ${emp.name} (${month})`,
        category: 'Salary',
        amount,
        date: new Date().toISOString().split('T')[0],
        storeId: window.getStoreId(),
        timestamp: serverTimestamp()
    });

    e.target.reset();
    window.showToast(navigator.onLine ? "✅ Salary Payment Recorded & Linked to Expenses!" : "✅ Salary Saved Locally & Linked", "success");
});

window.confirmDeleteEmployee = async (docId) => {
    const docRef = doc(db, 'employees', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'Terminated', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Staff Removed", "info");
};

// Initialized HRM sub-tab
window.showHRMSubTab('employees');

if (sessionStorage.getItem('isAdminLoggedIn')) showAdminActions();



// --- Bulk Deletion for MEC Book Shop (SuperAdmin Clean-up) ---
window.clearAllStaff = async () => {
    const role = sessionStorage.getItem('userRole');
    if (role !== 'SuperAdmin') {
        alert("CRITICAL: Only SuperAdmin can perform this action.");
        return;
    }

    const confirmPurge = confirm("🚨 CRITICAL WARNING!\n\nThis will PERMANENTLY delete ALL existing staff/employee usernames and passwords from the database.\n\nOnly the main 'mecbookshop@gmail.com' will remain.\n\nContinue with deletion?");
    
    if (!confirmPurge) return;

    try {
        const batch = writeBatch(db);
        const snapshot = await getDocs(employeesCol);
        
        if (snapshot.empty) {
            window.showToast("No employee records to clear.", "info");
            return;
        }

        snapshot.docs.forEach((docSnap) => {
            batch.delete(docSnap.ref);
        });

        await batch.commit();
        window.showToast(`System Cleaned: ${snapshot.size} employee records removed.`, "success");
        setTimeout(() => location.reload(), 2000);

    } catch (err) {
        console.error("Purge Error:", err);
        window.showToast("Failed to clear staff list.", "error");
    }
};



// --- Website Developer Functions (Web Studio) ---
window.handleWebBannerUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    window.showToast("⏳ Optimizing banner image...", "info");
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const maxSize = 1200;

            if (width > height) {
                if (width > maxSize) {
                    height *= maxSize / width;
                    width = maxSize;
                }
            } else {
                if (height > maxSize) {
                    width *= maxSize / height;
                    height = maxSize;
                }
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            
            const previewImg = document.getElementById('banner-preview-img');
            if (previewImg) {
                previewImg.src = compressedBase64;
                previewImg.style.display = 'block';
            }
            window.currentWebBannerBase64 = compressedBase64;
            window.showToast("🖼️ Banner optimized & preview updated! Remember to save.", "success");
        };
        img.onerror = () => {
            window.showToast("❌ Error loading image file.", "error");
        };
        img.src = e.target.result;
    };
    reader.onerror = () => {
        window.showToast("❌ Error reading file.", "error");
    };
    reader.readAsDataURL(file);
};

window.extractAndSetThemeColor = function(url) {
    if (!url) return;
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.onload = function() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const maxDim = 100;
        let w = img.width, h = img.height;
        if (w > maxDim || h > maxDim) {
             const ratio = Math.min(maxDim/w, maxDim/h);
             w *= ratio; h *= ratio;
        }
        canvas.width = w; canvas.height = h;
        ctx.drawImage(img, 0, 0, w, h);
        try {
            const data = ctx.getImageData(0, 0, w, h).data;
            const colors = {};
            let maxCount = 0;
            let dominantHex = "";
            for (let i = 0; i < data.length; i += 4) {
                if (data[i+3] < 128) continue; // ignore transparent
                const r = data[i], g = data[i+1], b = data[i+2];
                // ignore too white or too black
                if (r > 240 && g > 240 && b > 240) continue;
                if (r < 15 && g < 15 && b < 15) continue;
                
                // round to group similar colors
                const r10 = Math.round(r/10)*10;
                const g10 = Math.round(g/10)*10;
                const b10 = Math.round(b/10)*10;
                const key = `${r10},${g10},${b10}`;
                colors[key] = (colors[key] || 0) + 1;
                if (colors[key] > maxCount) {
                    maxCount = colors[key];
                    dominantHex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
                }
            }
            if (dominantHex) {
                const colorInput = document.getElementById('web-theme-primary');
                if (colorInput && colorInput.value !== dominantHex) {
                    colorInput.value = dominantHex;
                    window.showToast("✨ AI detected theme color from logo!", "success");
                    // Give a visual hint that it changed
                    colorInput.style.boxShadow = "0 0 10px " + dominantHex;
                    setTimeout(() => colorInput.style.boxShadow = "none", 2000);
                }
            }
        } catch(e) {
            console.log("Could not extract color (likely CORS)", e);
        }
    };
    img.src = url;
};

window.saveWebBranding = async (e) => {
    e.preventDefault();
    const title = document.getElementById('web-site-title').value;
    const desc = document.getElementById('web-site-desc').value;
    const logoUrl = document.getElementById('web-site-logo-url').value;
    const domain = document.getElementById('web-site-domain').value.trim().toLowerCase();
    const primaryColor = document.getElementById('web-theme-primary').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            const currentData = snap.docs[0].data();
            const webDesign = currentData.webDesign || {};
            webDesign.primary = primaryColor;
            
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webTitle: title,
                webDescription: desc,
                webLogo: logoUrl,
                domain: domain,
                webDesign: webDesign,
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Website branding updated successfully!", "success");
        } else {
            const webDesign = { primary: primaryColor };
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webTitle: title,
                webDescription: desc,
                webLogo: logoUrl,
                domain: domain,
                webDesign: webDesign,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Website branding created and updated successfully!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error updating branding", "error");
    }
};

window.saveWebDesign = async () => {
    const primary = document.getElementById('web-theme-primary').value;
    const accent = document.getElementById('web-theme-accent').value;
    const heroBg = document.getElementById('web-hero-bg').value;
    
    const settings = {
        primary,
        accent,
        heroBg,
        showFeatured: document.getElementById('web-show-featured').checked,
        showReviews: document.getElementById('web-show-reviews').checked,
        showServices: document.getElementById('web-show-services').checked,
        forceDarkMode: document.getElementById('web-enable-darkmode').checked,
        bannerUrl: window.currentWebBannerBase64 || null
    };

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webDesign: settings,
                updatedAt: serverTimestamp()
            });
            window.showToast("🎨 Design changes applied to live site!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webDesign: settings,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🎨 Design profile created and changes applied!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving design", "error");
    }
};

window.saveWebContent = async () => {
    const welcome = document.getElementById('web-hero-welcome').value;
    const announce = document.getElementById('web-announcement').value;
    const footer = document.getElementById('web-footer-name').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webContent: { welcome, announce, footer },
                updatedAt: serverTimestamp()
            });
            window.showToast("📝 Website content updated!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webContent: { welcome, announce, footer },
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("📝 Website content created and updated!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving content", "error");
    }
};

window.saveWebEpinics = async () => {
    const multiVendor = document.getElementById('web-enable-multivendor').checked;
    const affiliate = document.getElementById('web-enable-affiliate').checked;
    const liveTracking = document.getElementById('web-enable-live-tracking').checked;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webEpinics: { multiVendor, affiliate, liveTracking },
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Epinics Enterprise modules synced!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webEpinics: { multiVendor, affiliate, liveTracking },
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Epinics Enterprise modules created and synced!", "success");
        }
        if (typeof window.renderEpinicsManagement === 'function') {
            await window.renderEpinicsManagement();
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving Epinics settings", "error");
    }
};

window.loadWebSettings = async () => {
    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            const data = snap.docs[0].data();
            
            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.value = val;
            };
            const setChecked = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.checked = val;
            };

            // Branding
            setVal('web-site-title', data.webTitle || '');
            setVal('web-site-desc', data.webDescription || '');
            setVal('web-site-logo-url', data.webLogo || '');
            setVal('web-site-domain', data.domain || '');
            
            const preview = document.getElementById('web-logo-preview');
            if (preview && data.webLogo) {
                preview.innerHTML = '';
                preview.style.backgroundImage = `url(${data.webLogo})`;
                preview.style.backgroundSize = 'contain';
                preview.style.backgroundRepeat = 'no-repeat';
                preview.style.backgroundPosition = 'center';
            }

            // Design
            if (data.webDesign) {
                const wd = data.webDesign;
                setVal('web-theme-primary', wd.primary || '#002060');
                setVal('web-theme-accent', wd.accent || '#00aeef');
                setVal('web-hero-bg', wd.heroBg || 'gradient');
                setChecked('web-show-featured', wd.showFeatured !== false);
                setChecked('web-show-reviews', wd.showReviews !== false);
                setChecked('web-show-services', wd.showServices !== false);
                setChecked('web-enable-darkmode', wd.forceDarkMode === true);

                const bPreview = document.getElementById('banner-preview-img');
                if (bPreview) {
                    const firestoreBanner = wd.bannerUrl;
                    const bannerUrl = (firestoreBanner && firestoreBanner.length > 10)
                      ? firestoreBanner
                      : (window.getStoreId() === 'mec-book-shop' ? '/banner.png' : '');
                    
                    if (bannerUrl) {
                        bPreview.src = bannerUrl;
                        bPreview.style.display = 'block';
                        window.currentWebBannerBase64 = bannerUrl;
                    } else {
                        bPreview.src = '';
                        bPreview.style.display = 'none';
                        window.currentWebBannerBase64 = null;
                    }
                }
            }

            // Content
            if (data.webContent) {
                setVal('web-hero-welcome', data.webContent.welcome || '');
                setVal('web-announcement', data.webContent.announce || '');
                setVal('web-footer-name', data.webContent.footer || 'MEC Book Shop System');
            }

            // SEO & Analytics
            if (data.webSEO) {
                setVal('web-seo-keywords', data.webSEO.keywords || '');
                setVal('web-analytics-id', data.webSEO.analyticsId || '');
                setVal('web-pixel-id', data.webSEO.pixelId || '');
                setVal('web-contact-phone', data.webSEO.contactPhone || '');
                setVal('web-meta-desc', data.webSEO.metaDesc || '');
            }

            // Epinics
            if (data.webEpinics) {
                setChecked('web-enable-multivendor', !!data.webEpinics.multiVendor);
                setChecked('web-enable-affiliate', !!data.webEpinics.affiliate);
                setChecked('web-enable-live-tracking', data.webEpinics.liveTracking !== false);
            }
            
            if (typeof window.renderEpinicsManagement === 'function') {
                await window.renderEpinicsManagement();
            }
        }
    } catch (err) {
        console.error("Error loading web settings:", err);
    }
};

window.renderEpinicsManagement = async () => {
    const epinicsContainer = document.getElementById('epinics-admin-management');
    if (!epinicsContainer) return;

    const multiVendor = document.getElementById('web-enable-multivendor')?.checked;
    const affiliate = document.getElementById('web-enable-affiliate')?.checked;

    if (!multiVendor && !affiliate) {
        epinicsContainer.style.display = 'none';
        return;
    }
    epinicsContainer.style.display = 'block';

    const vendorShopsSec = document.getElementById('vendor-shops-admin-section');
    const vendorProdsSec = document.getElementById('vendor-products-admin-section');
    const affiliatesSec = document.getElementById('affiliates-admin-section');

    const storeId = window.getStoreId();

    if (multiVendor) {
        if (vendorShopsSec) vendorShopsSec.style.display = 'block';
        if (vendorProdsSec) vendorProdsSec.style.display = 'block';

        // Load Vendor Shops
        try {
            const qShops = query(collection(db, 'vendor_shops'), where('storeId', '==', storeId));
            const snapShops = await getDocs(qShops);
            const tbody = document.getElementById('admin-vendor-shops-tbody');
            if (tbody) {
                if (snapShops.empty) {
                    tbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">No vendor shops registered.</td></tr>`;
                } else {
                    let html = '';
                    snapShops.forEach(docSnap => {
                        const shop = docSnap.data();
                        const docId = docSnap.id;
                        const statusColor = shop.status === 'active' ? '#10b981' : '#fbbf24';
                        let actionsHtml = '';
                        if (shop.status === 'pending') {
                            actionsHtml = `
                                <button onclick="window.approveVendorShop('${docId}')" style="background:#10b981; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold; margin-right:5px;">Approve</button>
                                <button onclick="window.rejectVendorShop('${docId}')" style="background:#ef4444; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold;">Reject</button>
                            `;
                        } else {
                            actionsHtml = `<span style="color:#64748b; font-size:0.8rem;">None</span>`;
                        }
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${shop.shopName || ''}</td>
                                <td style="padding:12px;">${shop.ownerName || ''}</td>
                                <td style="padding:12px;">${shop.email || ''}</td>
                                <td style="padding:12px;">${shop.phone || ''}</td>
                                <td style="padding:12px; color:${statusColor}; font-weight:bold; text-transform:uppercase; font-size:0.85rem;">${shop.status || 'pending'}</td>
                                <td style="padding:12px;">${actionsHtml}</td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering vendor shops:", err);
        }

        // Load Pending Products
        try {
            const qProds = query(productsCol, where('status', '==', 'pending'), where('storeId', '==', storeId));
            const snapProds = await getDocs(qProds);
            const tbody = document.getElementById('admin-pending-products-tbody');
            if (tbody) {
                if (snapProds.empty) {
                    tbody.innerHTML = `<tr><td colspan="5" style="padding: 20px; text-align: center; color: #64748b;">No pending products.</td></tr>`;
                } else {
                    let html = '';
                    snapProds.forEach(docSnap => {
                        const prod = docSnap.data();
                        const docId = docSnap.id;
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${prod.name || ''}</td>
                                <td style="padding:12px;">${prod.category || ''}</td>
                                <td style="padding:12px; color:#fbbf24; font-weight:bold;">LKR ${prod.price || 0}</td>
                                <td style="padding:12px; color:#94a3b8;">${prod.vendorId || ''}</td>
                                <td style="padding:12px;">
                                    <button onclick="window.approveVendorProduct('${docId}')" style="background:#10b981; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold; margin-right:5px;">Approve</button>
                                    <button onclick="window.deleteVendorProduct('${docId}')" style="background:#ef4444; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold;">Reject</button>
                                </td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering pending products:", err);
        }
    } else {
        if (vendorShopsSec) vendorShopsSec.style.display = 'none';
        if (vendorProdsSec) vendorProdsSec.style.display = 'none';
    }

    if (affiliate) {
        if (affiliatesSec) affiliatesSec.style.display = 'block';

        // Load Affiliates
        try {
            const qAff = query(collection(db, 'affiliates'), where('storeId', '==', storeId));
            const snapAff = await getDocs(qAff);
            const tbody = document.getElementById('admin-affiliates-tbody');
            if (tbody) {
                if (snapAff.empty) {
                    tbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">No registered affiliates.</td></tr>`;
                } else {
                    let html = '';
                    snapAff.forEach(docSnap => {
                        const aff = docSnap.data();
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${aff.name || ''}</td>
                                <td style="padding:12px;">${aff.email || ''}</td>
                                <td style="padding:12px; color:#38bdf8; font-weight:bold;">${aff.code || ''}</td>
                                <td style="padding:12px;">${aff.clicks || 0}</td>
                                <td style="padding:12px;">${aff.salesCount || 0}</td>
                                <td style="padding:12px; color:#fbbf24; font-weight:bold;">LKR ${(aff.totalCommission || 0).toFixed(2)}</td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering affiliates:", err);
        }
    } else {
        if (affiliatesSec) affiliatesSec.style.display = 'none';
    }
};

window.approveVendorShop = async (docId) => {
    if (!confirm('Are you sure you want to approve this shop request?')) return;
    try {
        await updateDoc(doc(db, 'vendor_shops', docId), { status: 'active' });
        window.showToast("Shop approved successfully!", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error approving shop", "error");
    }
};

window.rejectVendorShop = async (docId) => {
    if (!confirm('Are you sure you want to reject and delete this shop request?')) return;
    try {
        await deleteDoc(doc(db, 'vendor_shops', docId));
        window.showToast("Shop request deleted.", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error rejecting shop", "error");
    }
};

window.approveVendorProduct = async (docId) => {
    if (!confirm('Are you sure you want to approve this product?')) return;
    try {
        await updateDoc(doc(db, 'products', docId), { status: 'active' });
        window.showToast("Product approved and is now live!", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error approving product", "error");
    }
};

window.deleteVendorProduct = async (docId) => {
    if (!confirm('Are you sure you want to reject and delete this product?')) return;
    try {
        await deleteDoc(doc(db, 'products', docId));
        window.showToast("Product rejected and deleted.", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error rejecting product", "error");
    }
};

window.saveWebSEO = async () => {
    const keywords = document.getElementById('web-seo-keywords').value;
    const analyticsId = document.getElementById('web-analytics-id').value;
    const pixelId = document.getElementById('web-pixel-id').value;
    const contactPhone = document.getElementById('web-contact-phone').value;
    const metaDesc = document.getElementById('web-meta-desc').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webSEO: { keywords, analyticsId, pixelId, contactPhone, metaDesc },
                updatedAt: serverTimestamp()
            });
            window.showToast("🔍 SEO & Analytics settings updated!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving SEO settings", "error");
    }
};

// --- SUPPLIER INVOICE MANAGEMENT [NEW] ---
window.currentInvoiceItems = [];

window.renderSupplierInvoicesUI = () => {
    const listBody = document.getElementById('supplier-invoices-body');
    if (!listBody) return;

    const invoices = window.allSupplierInvoices || [];
    
    if (invoices.length === 0) {
        listBody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 4rem; color: #64748b;">
            <div style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.2;">📁</div>
            <p style="font-weight: 700; font-size: 1.1rem; opacity: 0.5;">No invoices found in your system.</p>
        </td></tr>`;
        return;
    }

    // Sort DESC for list view
    invoices.sort((a,b) => {
        const da = a.timestamp?.seconds ? a.timestamp.seconds : new Date(a.date).getTime() / 1000;
        const db = b.timestamp?.seconds ? b.timestamp.seconds : new Date(b.date).getTime() / 1000;
        return db - da;
    });

    listBody.innerHTML = '';
    invoices.forEach(inv => {
        const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
        const paid = parseFloat(inv.paidAmount || inv.paid || 0);
        const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();

        // Auto-resolve cheque status: if chequeDate has passed, show Paid
        let status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
        const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
        if (isCheque && inv.chequeStatus === 'pending' && inv.chequeDate) {
            const today = new Date(); today.setHours(0,0,0,0);
            const chequeDay = new Date(inv.chequeDate); chequeDay.setHours(0,0,0,0);
            if (chequeDay <= today) status = 'Paid';
        }

        const statusColor = status === 'Paid' ? '#10b981' : status === 'Partially Paid' ? '#f59e0b' : '#fbbf24';
        const statusBg   = status === 'Paid' ? '#10b98133' : status === 'Partially Paid' ? '#f59e0b33' : '#fbbf2433';
        const methodIcon = isCheque ? '🧾' : (inv.paymentMethod === 'Bank' ? '🏦' : (inv.paymentMethod === 'Credit' ? '⏳' : '💵'));
        const chequeDateLabel = isCheque && inv.chequeDate ? `<div style="font-size:0.65rem; color:#f59e0b; margin-top:2px;">📅 ${inv.chequeDate}</div>` : '';
        const showMarkPaid = isCheque && status === 'Pending' && inv.chequeStatus === 'pending';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${dateStr}</td>
            <td style="font-weight: 800; color: #38bdf8; cursor: pointer; text-decoration: underline;" onclick="window.showSupplierInvoiceDetails('${inv.docId || inv.id}')" title="Click to view details">${inv.invoiceNo}</td>
            <td>${inv.supplierName}<br><span style="font-size:0.7rem; color:#64748b;">${methodIcon} ${inv.paymentMethod || 'Cash'}</span>${chequeDateLabel}</td>
            <td style="text-align: center;">${(inv.items || []).length} items</td>
            <td style="font-weight: 800;">LKR ${total.toLocaleString()}</td>
            <td>
                <span class="status-badge" style="background: ${statusBg}; color: ${statusColor}; padding: 4px 10px; border-radius: 8px; font-size: 0.65rem; font-weight:800;">${status}</span>
                ${showMarkPaid ? `<br><button onclick="window.markChequeAsPaid('${inv.docId || inv.id}')" style="margin-top:4px; font-size:0.6rem; padding:3px 8px; border-radius:6px; background:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.4); color:#10b981; cursor:pointer; font-weight:800;">✅ Mark Paid</button>` : ''}
            </td>
            <td style="text-align: right; display:flex; gap:6px; justify-content:flex-end; align-items:center; padding: 10px 12px;">
                <button onclick="window.viewSupplierInvoice('${inv.docId || inv.id}')" 
                    title="View / Print Invoice"
                    style="background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.3); color: #10b981; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(16,185,129,0.3)'" onmouseout="this.style.background='rgba(16,185,129,0.15)'">🖨️</button>
                <button onclick="window.editSupplierInvoice('${inv.docId || inv.id}')" 
                    title="Edit Invoice"
                    style="background: rgba(56,189,248,0.15); border: 1px solid rgba(56,189,248,0.3); color: #38bdf8; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(56,189,248,0.3)'" onmouseout="this.style.background='rgba(56,189,248,0.15)'">✏️</button>
                <button onclick="window.deleteSupplierInvoice('${inv.docId || inv.id}')" 
                    title="Delete Invoice"
                    style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); color: #ef4444; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(239,68,68,0.25)'" onmouseout="this.style.background='rgba(239,68,68,0.1)'">🗑️</button>
            </td>
        `;
        // Make the row clickable (except action buttons)
        tr.style.cursor = 'pointer';
        tr.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;
            window.showSupplierInvoiceDetails(inv.docId || inv.id);
        });
        listBody.appendChild(tr);
    });
};


// ─────────────────────────────────────────────────────────────────────────────
// VIEW / PRINT SUPPLIER INVOICE (A4 Printable)
// ─────────────────────────────────────────────────────────────────────────────
window.viewSupplierInvoice = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const balance = total - paid;
    const status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
    const statusColor = status === 'Paid' ? '#16a34a' : status === 'Partially Paid' ? '#d97706' : '#dc2626';
    const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
    const methodLabel = isCheque ? '🧾 Cheque' : ((inv.paymentMethod || '').toLowerCase() === 'bank' ? '🏦 Bank Transfer' : ((inv.paymentMethod || '').toLowerCase() === 'credit' ? '⏳ Credit' : '💵 Cash'));
    const storeName = (window.systemConfig && window.systemConfig.shopName) || 'MEC BOOK SHOP';
    const storeAddress = (window.systemConfig && window.systemConfig.address) || '';
    const storePhone = (window.systemConfig && window.systemConfig.phone) || '';

    const itemRows = (inv.items || []).map(function(item, i) {
        const cost = parseFloat(item.buying || item.buyingPrice || item.cost || item.netCost || 0);
        const qty  = parseFloat(item.qty || item.quantity || 0);
        const lineTotal = parseFloat(item.totalCost || item.total || (cost * qty) || 0);
        const desc = [item.sku ? 'SKU: ' + item.sku : '', item.variant || item.variantLabel || ''].filter(Boolean).join(' | ');
        return '<tr style="border-bottom:1px solid #e5e7eb;">' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;vertical-align:top;">' + (i+1) + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;font-weight:600;vertical-align:top;">' + (item.name || '—') + (desc ? '<br><span style="font-size:0.7rem;color:#6b7280;font-weight:400;">' + desc + '</span>' : '') + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:center;vertical-align:top;">' + qty + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:right;vertical-align:top;">LKR ' + cost.toFixed(2) + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:right;font-weight:700;vertical-align:top;">LKR ' + lineTotal.toFixed(2) + '</td>' +
            '</tr>';
    }).join('');

    const chequeLine = (isCheque && inv.chequeDate) ? '<br><small style="color:#92400e;">📅 Cheque Date: ' + inv.chequeDate + '</small>' : '';
    const sep = storeAddress && storePhone ? ' &nbsp;|&nbsp; ' : '';

    const printHTML = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Supplier Invoice #' + (inv.invoiceNo || '') + '</title>' +
'<style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:"Segoe UI",Arial,sans-serif;background:#f1f5f9;display:flex;justify-content:center;padding:20px;}' +
'.page{width:210mm;min-height:297mm;background:#fff;padding:32px 38px;box-shadow:0 4px 40px rgba(0,0,0,.12);position:relative;}' +
'.hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:26px;border-bottom:3px solid #0f172a;padding-bottom:18px;}' +
'.shop-name{font-size:1.55rem;font-weight:900;color:#0f172a;}.shop-sub{font-size:0.76rem;color:#64748b;margin-top:4px;}' +
'.inv-title{text-align:right;}.inv-title h2{font-size:1rem;font-weight:900;color:#0f172a;text-transform:uppercase;letter-spacing:2px;}' +
'.inv-no{font-size:1.6rem;font-weight:900;color:#6366f1;margin-top:4px;}' +
'.meta{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:22px;background:#f8fafc;border-radius:10px;padding:14px;border:1px solid #e2e8f0;}' +
'.meta label{font-size:0.63rem;font-weight:800;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;display:block;margin-bottom:3px;}' +
'.meta span{font-size:0.87rem;font-weight:700;color:#1e293b;}' +
'table{width:100%;border-collapse:collapse;margin-bottom:18px;}' +
'thead tr{background:#0f172a;}thead th{padding:10px 8px;font-size:0.7rem;font-weight:800;color:#fff;text-transform:uppercase;letter-spacing:.8px;text-align:left;}' +
'thead th:nth-child(3){text-align:center;}thead th:nth-child(4),thead th:nth-child(5){text-align:right;}' +
'tbody tr:nth-child(even){background:#f8fafc;}' +
'.tw{display:flex;justify-content:flex-end;margin-top:6px;}.tb{width:270px;}' +
'.tr{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:0.85rem;}' +
'.tg{font-size:1rem;font-weight:900;color:#0f172a;border-bottom:2px solid #0f172a;padding:10px 0;display:flex;justify-content:space-between;}' +
'.badge{display:inline-block;padding:4px 14px;border-radius:20px;font-size:0.72rem;font-weight:800;text-transform:uppercase;letter-spacing:1px;}' +
'.ftr{margin-top:36px;border-top:1px solid #e2e8f0;padding-top:14px;display:flex;justify-content:space-between;color:#94a3b8;font-size:0.7rem;}' +
'.wm{position:absolute;bottom:80px;right:36px;font-size:3.5rem;font-weight:900;color:rgba(99,102,241,.05);transform:rotate(-15deg);pointer-events:none;letter-spacing:4px;}' +
'@media print{body{background:white;padding:0;}.page{box-shadow:none;}.no-print{display:none!important;}}' +
'</style></head><body><div class="page">' +
'<div class="wm">MEC ERP</div>' +
'<div class="hdr">' +
'  <div><div class="shop-name">' + storeName + '</div><div class="shop-sub">' + storeAddress + sep + storePhone + '</div></div>' +
'  <div class="inv-title"><h2>Supplier Invoice</h2><div class="inv-no">#' + (inv.invoiceNo || '—') + '</div>' +
'    <div style="margin-top:8px;"><span class="badge" style="background:' + statusColor + '22;color:' + statusColor + ';border:1px solid ' + statusColor + '44;">' + status + '</span></div></div>' +
'</div>' +
'<div class="meta">' +
'  <div><label>Supplier</label><span>' + (inv.supplierName || '—') + '</span></div>' +
'  <div><label>Posting Date</label><span>' + (inv.date || '—') + '</span></div>' +
'  <div><label>Payment Method</label><span>' + methodLabel + chequeLine + '</span></div>' +
'  <div><label>Amount Paid</label><span style="color:#16a34a;">LKR ' + paid.toFixed(2) + '</span></div>' +
'</div>' +
'<table>' +
'  <thead><tr><th style="width:30px;">#</th><th>Item Description</th><th style="text-align:center;width:60px;">Qty</th><th style="text-align:right;width:120px;">Unit Cost</th><th style="text-align:right;width:130px;">Total Cost</th></tr></thead>' +
'  <tbody>' + itemRows + '</tbody>' +
'</table>' +
'<div class="tw"><div class="tb">' +
'  <div class="tg"><span>Grand Total</span><span>LKR ' + total.toFixed(2) + '</span></div>' +
'  <div class="tr"><span>Amount Paid</span><span style="color:#16a34a;">LKR ' + paid.toFixed(2) + '</span></div>' +
'  <div class="tr" style="font-weight:800;color:' + statusColor + ';"><span>' + (balance > 0 ? 'Balance Due' : 'Overpaid') + '</span><span>LKR ' + Math.abs(balance).toFixed(2) + '</span></div>' +
'</div></div>' +
'<div style="margin-top:20px;padding:12px 16px;background:' + statusColor + '11;border-radius:8px;border-left:4px solid ' + statusColor + ';display:flex;justify-content:space-between;align-items:center;">' +
'  <span style="font-size:0.8rem;color:' + statusColor + ';font-weight:700;">Payment Status: ' + status + '</span>' +
'  <span style="font-size:0.7rem;color:#6b7280;">Generated: ' + new Date().toLocaleString() + '</span>' +
'</div>' +
'<div class="ftr"><div>Computer generated document — No signature required.</div><div>' + storeName + ' &copy; ' + new Date().getFullYear() + '</div></div>' +
'<div class="no-print" style="text-align:center;margin-top:30px;">' +
'  <button onclick="window.print()" style="background:#0f172a;color:white;border:none;padding:14px 40px;border-radius:10px;font-size:1rem;font-weight:800;cursor:pointer;margin-right:12px;">🖨️ Print / Save PDF</button>' +
'  <button onclick="window.close()" style="background:#f1f5f9;color:#374151;border:1px solid #e5e7eb;padding:14px 30px;border-radius:10px;font-size:1rem;font-weight:700;cursor:pointer;">✕ Close</button>' +
'</div>' +
'</div></body></html>';

    // Use a hidden iframe to print to bypass browser popup blockers and "about:" protocols
    let iframe = document.getElementById('sinv-print-iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'sinv-print-iframe';
        iframe.style.position = 'fixed';
        iframe.style.top = '-9999px';
        iframe.style.left = '-9999px';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = 'none';
        document.body.appendChild(iframe);
    }
    
    const doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(printHTML);
    doc.close();
    
    setTimeout(() => {
        try {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        } catch (e) {
            console.error("Iframe print error:", e);
            window.showToast('Failed to open print dialog.', 'error');
        }
    }, 500);
};

window.showSupplierInvoiceDetails = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const balance = total - paid;
    const status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
    const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
    const methodLabel = isCheque ? '🧾 Cheque' : ((inv.paymentMethod || '').toLowerCase() === 'bank' ? '🏦 Bank Transfer' : ((inv.paymentMethod || '').toLowerCase() === 'credit' ? '⏳ Credit' : '💵 Cash'));
    const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();

    const noEl = document.getElementById('sinv-detail-no');
    const supEl = document.getElementById('sinv-detail-supplier');
    const dateEl = document.getElementById('sinv-detail-date');
    const methodEl = document.getElementById('sinv-detail-method');
    const itemsBody = document.getElementById('sinv-detail-items-body');
    const totalEl = document.getElementById('sinv-detail-total');
    const paidEl = document.getElementById('sinv-detail-paid');
    const balLabelEl = document.getElementById('sinv-detail-balance-label');
    const balEl = document.getElementById('sinv-detail-balance');

    if (noEl) noEl.innerText = inv.invoiceNo || '—';
    if (supEl) supEl.innerText = inv.supplierName || '—';
    if (dateEl) dateEl.innerText = dateStr;
    if (methodEl) methodEl.innerText = methodLabel + (isCheque && inv.chequeDate ? ` (Cheque Date: ${inv.chequeDate})` : '');
    if (totalEl) totalEl.innerText = 'LKR ' + total.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    if (paidEl) paidEl.innerText = 'LKR ' + paid.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    if (balLabelEl) balLabelEl.innerText = balance >= 0 ? 'Balance Due:' : 'Overpaid:';
    if (balEl) {
        balEl.innerText = 'LKR ' + Math.abs(balance).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        balEl.style.color = balance > 0 ? '#ef4444' : '#10b981';
    }

    if (itemsBody) {
        itemsBody.innerHTML = (inv.items || []).map(function(item, i) {
            const cost = parseFloat(item.buying || item.buyingPrice || item.cost || item.netCost || 0);
            const qty  = parseFloat(item.qty || item.quantity || 0);
            const lineTotal = parseFloat(item.totalCost || item.total || (cost * qty) || 0);
            const desc = [item.sku ? 'SKU: ' + item.sku : '', item.variant || item.variantLabel || ''].filter(Boolean).join(' | ');
            return `
                <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc;">${i + 1}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; font-weight:600;">
                        ${item.name || '—'}
                        ${desc ? `<br><span style="font-size:0.7rem; color:#94a3b8; font-weight:400;">${desc}</span>` : ''}
                    </td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:center;">${qty}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:right;">LKR ${cost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:right; font-weight:700;">LKR ${lineTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                </tr>
            `;
        }).join('');
    }

    const modal = document.getElementById('supplier-invoice-detail-modal');
    if (modal) modal.style.display = 'flex';
};

window.populateSupplierInvoicesDropdown = () => {
    const select = document.getElementById('sinv-supplier-id');
    if (!select) return;
    
    // Use the global list and our standardized filter for backward compatibility
    const suppliers = window.filterByStore(window.allSuppliers || []);
    
    select.innerHTML = '<option value="">-- Choose Supplier --</option>';
    suppliers.forEach(sup => {
        select.innerHTML += `<option value="${sup.docId}">${sup.name}</option>`;
    });
};

window.enterSupplierInvoiceNativeFS = () => {
    const el = document.getElementById('supplier-invoices-add-view');
    if (!el) return;
    
    // [NEW] Stock Entry Splash Screen Sequence
    const splash = document.getElementById('sinv-terminal-splash');
    if (splash) {
        splash.style.display = 'flex';
        splash.style.opacity = '1';
        setTimeout(() => {
            splash.style.transition = 'opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
            splash.style.opacity = '0';
            setTimeout(() => {
                splash.style.display = 'none';
            }, 400);
        }, 800);
    }

    // Add immersive class
    el.classList.add('native-fs');
    document.body.classList.add('pos-fullscreen-mode');
    
    const btn = document.getElementById('sinv-fs-btn');
    if (btn) btn.innerHTML = '🗗 EXIT FULLSCREEN';
    
    // Auto focus search
    setTimeout(() => {
        const searchInput = document.getElementById('sinv-search');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }, 1300);
};

window.exitSupplierInvoiceNativeFS = () => {
    const el = document.getElementById('supplier-invoices-add-view');
    if (!el) return;
    
    el.classList.remove('native-fs');
    document.body.classList.remove('pos-fullscreen-mode');
    
    const btn = document.getElementById('sinv-fs-btn');
    if (btn) btn.innerHTML = '🖥️ FULLSCREEN';
    
    // Exit true browser fullscreen (Disabled to match enter function)
    // try {
    //     if (document.fullscreenElement || document.webkitFullscreenElement) {
    //         if (document.exitFullscreen) document.exitFullscreen();
    //         else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    //     }
    // } catch (e) { console.warn("FS Exit Denied:", e); }
};

window.openVariantPickerForSINV = (name) => {
    // products sharing the same name (top-level doc per variant from products collection)
    const products = (window.allProducts || []).filter(p => (p.name || '').trim() === name);
    if (products.length === 0) return;

    // Collect ALL internal batch variants from all matching products
    const allBatches = [];
    products.forEach(p => {
        const internalVariants = p.variants || [];
        if (internalVariants.length > 0) {
            internalVariants.forEach((v, idx) => {
                allBatches.push({
                    docId: p.docId,
                    image: p.image,
                    sku: v.sku || p.sku,
                    batchLabel: v.variantLabel || v.supplierName || `Batch ${idx + 1}`,
                    cost: v.buyingPrice || v.cost || 0,
                    mrp: v.sellingPrice || p.price || 0,
                    stock: v.stock || 0,
                    variantId: v.variantId,
                    supplierName: v.supplierName || '',
                    addedDate: v.addedDate || ''
                });
            });
        } else {
            // No internal variants – treat the product itself as one batch
            allBatches.push({
                docId: p.docId,
                image: p.image,
                sku: p.sku,
                batchLabel: 'Standard',
                cost: p.cost || 0,
                mrp: p.price || 0,
                stock: p.stock || 0,
                variantId: null,
                supplierName: '',
                addedDate: ''
            });
        }
    });

    const totalStock = allBatches.reduce((s, b) => s + b.stock, 0);
    const lastMRP = allBatches.length > 0 ? allBatches[allBatches.length - 1].mrp : 0;

    const overlay = document.createElement('div');
    overlay.id = "sinv-variant-picker-overlay";
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:10000000; display:flex; align-items:center; justify-content:center; backdrop-filter: blur(8px); animation: fadeIn 0.2s ease;";
    overlay.onclick = (e) => { if(e.target === overlay) overlay.remove(); };
    
    const content = document.createElement('div');
    content.style = "width: 560px; max-height: 85vh; overflow-y: auto; padding: 25px; border-radius: 28px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 25px 100px rgba(0,0,0,0.8); position: relative; animation: slideUp 0.3s ease-out;";
    
    content.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; position: sticky; top: 0; background: #0f172a; padding: 10px 0; z-index: 10;">
            <div>
                <h3 style="margin: 0; font-size: 1.4rem; font-weight: 900; color: #fff; letter-spacing: -0.5px;">${name}</h3>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">${allBatches.length} BATCH${allBatches.length > 1 ? 'ES' : ''} &nbsp;•&nbsp; TOTAL STOCK: <span style="color:#10b981;font-weight:800;">${totalStock}</span> &nbsp;•&nbsp; LAST MRP: <span style="color:#fbbf24;font-weight:800;">LKR ${lastMRP.toLocaleString()}</span></div>
            </div>
            <button onclick="this.closest('#sinv-variant-picker-overlay').remove()" style="background: rgba(255,255,255,0.05); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">✕</button>
        </div>

        <!-- Summary bar -->
        <div style="display:flex; gap:10px; margin-bottom:18px; padding:12px 16px; background:rgba(56,189,248,0.06); border:1px solid rgba(56,189,248,0.15); border-radius:14px;">
            ${allBatches.map((b, i) => `
                <div style="flex:1; text-align:center; padding:8px; background:rgba(255,255,255,0.03); border-radius:10px; border:1px solid rgba(255,255,255,0.06);">
                    <div style="font-size:0.6rem; color:#64748b; font-weight:700; letter-spacing:0.5px;">BATCH ${i + 1}</div>
                    <div style="font-size:1.1rem; font-weight:900; color:${b.stock < 5 ? '#ef4444' : '#10b981'}; margin:4px 0;">${b.stock}</div>
                    <div style="font-size:0.65rem; color:#38bdf8; font-weight:700;">MRP ${b.mrp.toLocaleString()}</div>
                    <div style="font-size:0.6rem; color:#94a3b8;">COST ${b.cost.toLocaleString()}</div>
                </div>
            `).join('')}
        </div>

        <!-- SELECT heading -->
        <div style="font-size:0.7rem; color:#64748b; font-weight:700; letter-spacing:1px; margin-bottom:12px;">SELECT A BATCH TO ADD MORE STOCK →</div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
            ${products.map((v, pidx) => `
                <div class="variant-item-pick" onclick="window.selectVariantForSINV('${v.docId}')" 
                    style="padding: 16px 18px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 16px; cursor: pointer; transition: all 0.2s; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 14px;">
                        <div style="width: 38px; height: 38px; border-radius: 10px; overflow: hidden; background: #000; border: 1px solid rgba(255,255,255,0.1); flex-shrink:0;">
                            <img src="${v.image || '/logo.png'}" style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div>
                            <div style="font-weight: 800; color: #38bdf8; font-size: 0.95rem;">${v.size || 'Standard'}${v.color ? ` / ${v.color}` : ''}</div>
                            <div style="font-size: 0.65rem; color: #64748b; margin-top: 3px; font-family: monospace;">${v.sku || '-'}</div>
                            <div style="font-size: 0.65rem; color: #94a3b8; margin-top: 2px;">${(v.variants||[]).length} internal batch${(v.variants||[]).length !== 1 ? 'es' : ''}</div>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: 900; color: #fff; font-size: 1.05rem;">LKR ${(v.price || 0).toLocaleString()}</div>
                        <div style="font-size: 0.72rem; color: #38bdf8; font-weight: 800; margin-top: 2px;">COST: LKR ${(v.cost || 0).toLocaleString()}</div>
                        <div style="font-size: 0.68rem; color: ${(v.stock || 0) < 5 ? '#ef4444' : '#10b981'}; font-weight: 800; margin-top: 3px;">STOCK: ${v.stock || 0}</div>
                    </div>
                </div>
            `).join('')}
        </div>
        <style>
            .variant-item-pick:hover {
                background: rgba(56, 189, 248, 0.1) !important;
                border-color: #38bdf8 !important;
                transform: translateX(5px);
            }
        </style>
    `;
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
};

window.selectVariantForSINV = (docId) => {
    document.getElementById('sinv-variant-picker-overlay')?.remove();
    window.addToSupplierInvoice(docId);
};

window.sinvSelectedIndex = -1;
window.highlightSINVSearchItem = (items) => {
    for (let i = 0; i < items.length; i++) {
        if (i === window.sinvSelectedIndex) {
            items[i].style.background = 'rgba(56, 189, 248, 0.15)';
            items[i].style.borderLeft = '4px solid #38bdf8';
            items[i].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            items[i].style.background = 'rgba(255,255,255,0.02)';
            items[i].style.borderLeft = '4px solid transparent';
        }
    }
};

window.poSelectedIndex = -1;
window.highlightPOSearchItem = (items) => {
    for (let i = 0; i < items.length; i++) {
        if (i === window.poSelectedIndex) {
            items[i].style.background = 'rgba(56, 189, 248, 0.15)';
            items[i].style.borderLeft = '4px solid #38bdf8';
            items[i].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            items[i].style.background = 'transparent';
            items[i].style.borderLeft = '4px solid transparent';
        }
    }
};

window.handleSINVSearch = (val) => {
    console.log(`[SINV Debug] handleSINVSearch triggered with val: "${val}"`);
    const listDiv = document.getElementById('sinv-product-list');
    if (!listDiv) return;
    
    window.sinvSelectedIndex = -1;
    
    if (!window.allProducts || window.allProducts.length === 0) {
        console.warn("[SINV Debug] Catalog is empty during search.");
        listDiv.innerHTML = '<div style="color: #64748b; text-align: center; padding: 20px;">Loading catalog...</div>';
        return;
    }

    const q = (val || "").toLowerCase().trim();
    const sq = window.toSinhala ? window.toSinhala(val) : "";
    
    const filtered = (window.allProducts || []).filter(p => {
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return (p.name && (p.name.toLowerCase().includes(q) || (sq && p.name.includes(sq)))) || 
               window.matchProductSku(p.sku, q) ||
               matchesVariantSku;
    }).sort((a, b) => {
        const aStarts = a.name?.toLowerCase().startsWith(q) || a.sku?.toLowerCase().startsWith(q);
        const bStarts = b.name?.toLowerCase().startsWith(q) || b.sku?.toLowerCase().startsWith(q);
        if (aStarts && !bStarts) return -1;
        if (!aStarts && bStarts) return 1;
        return 0;
    });

    // Group by name
    const grouped = new Map();
    filtered.forEach(p => {
        const name = (p.name || '').trim();
        if (!grouped.has(name)) grouped.set(name, []);
        grouped.get(name).push(p);
    });

    listDiv.innerHTML = '';
    if (filtered.length === 0 && q) {
        listDiv.innerHTML = `
            <div style="color: #64748b; text-align: center; padding: 20px; border: 1px dashed rgba(255,255,255,0.1); border-radius: 12px; animation: fadeIn 0.3s ease;">
                <p style="margin-bottom: 12px; font-size: 0.85rem;">Not in catalog: "${val}"</p>
                <button onclick="window.openSINVQuickProductModal('${val.replace(/'/g, "\\'")}')" 
                    style="background: #38bdf8; color: #0f172a; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 900; cursor: pointer; font-size: 0.75rem; letter-spacing: 0.5px;">
                    ➕ ADD AS NEW PRODUCT
                </button>
            </div>`;
    }

    grouped.forEach((variants, name) => {
        const first = variants[0];
        const hasMultiple = variants.length > 1;
        
        const itemDiv = document.createElement('div');
        itemDiv.className = 'sinv-search-item';
        itemDiv.style.cssText = `
            display: flex; gap: 8px; align-items: center; padding: 6px 10px;
            background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05);
            border-radius: 10px; cursor: pointer; transition: all 0.2s;
            border-left: 3px solid transparent; animation: slideInX 0.2s ease-out;
            margin-bottom: 5px;
        `;
        itemDiv.onmouseover = () => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            window.sinvSelectedIndex = Array.from(items).indexOf(itemDiv);
            window.highlightSINVSearchItem(items);
        };
        itemDiv.onmouseout = () => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            const idx = Array.from(items).indexOf(itemDiv);
            if (window.sinvSelectedIndex !== idx) {
                itemDiv.style.background = 'rgba(255,255,255,0.02)';
                itemDiv.style.borderLeft = '4px solid transparent';
            }
        };
        
        const retailPrice = first.price || first.sellingPrice || 0;

        // [v3.12.17] Enhanced Search Result Template for SINV
        itemDiv.innerHTML = `
            <img src="${first.image || '/logo.png'}" style="width: 42px; height: 42px; border-radius: 10px; object-fit: cover; background: white; flex-shrink: 0; border: 1px solid rgba(255,255,255,0.1);">
            <div style="flex: 1; overflow: hidden; display: flex; flex-direction: column; gap: 2px;">
                <div style="font-weight: 800; color: white; font-size: 0.85rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; gap: 6px;">
                    ${name}
                </div>
                <div style="font-size: 0.65rem; color: #64748b; font-family: 'JetBrains Mono', monospace; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; background: rgba(0,0,0,0.3); padding: 2px 6px; border-radius: 5px; width: 100%; box-sizing: border-box;">
                    <span>${hasMultiple ? `<span style="color: #38bdf8; font-weight: 900;">${variants.length} BATCHES</span>` : `<span style="color: #10b981; font-weight: 900;">Stock: ${first.stock || 0}</span>`}</span>
                    <span style="color: #fff; font-weight: 900;">${hasMultiple ? 'SELECT' : `LKR ${retailPrice}`}</span>
                </div>
            </div>
        `;
        
        itemDiv.onclick = (e) => {
            e.stopPropagation();
            window.addToSupplierInvoice(first.docId);
        };
        listDiv.appendChild(itemDiv);
    });

    const searchInput = document.getElementById('sinv-search');
    if (searchInput) {
        searchInput.onkeydown = (e) => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (items.length > 0) {
                    window.sinvSelectedIndex = (window.sinvSelectedIndex + 1) % items.length;
                    window.highlightSINVSearchItem(items);
                }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (items.length > 0) {
                    window.sinvSelectedIndex = (window.sinvSelectedIndex - 1 + items.length) % items.length;
                    window.highlightSINVSearchItem(items);
                }
            } else if (e.key === 'Enter') {
                if (window.sinvSelectedIndex >= 0 && window.sinvSelectedIndex < items.length) {
                    e.preventDefault();
                    items[window.sinvSelectedIndex].click();
                    searchInput.value = '';
                    window.handleSINVSearch('');
                } else if (items.length > 0) {
                    e.preventDefault();
                    items[0].click();
                    searchInput.value = '';
                    window.handleSINVSearch('');
                }
            }
        };
    }
};

window.openSINVQuickProductModal = (suggestedName = '') => {
    const modal = document.getElementById('sinv-quick-product-modal');
    if (modal) {
        if (window.allCategories && window.populateCategoryDropdowns) {
            window.populateCategoryDropdowns(window.allCategories);
        }
        modal.style.display = 'flex';
        const nameInput = document.getElementById('qa-prod-name');
        if (nameInput) {
            nameInput.value = suggestedName || '';
            setTimeout(() => {
                nameInput.focus();
                if (suggestedName) {
                    nameInput.select();
                }
            }, 100);
        }
    }
};

window.addNewItemToInvoice = (suggestedName) => {
    window.openSINVQuickProductModal(suggestedName);
};


window.openSupplierItemModal = () => {
    const modal = document.getElementById('supplier-item-modal');
    if (modal) {
        modal.style.display = 'flex';
        modal.style.zIndex = '9999999';
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        console.log("Modal opened successfully");
        
        // Auto-focus Quantity for speed
        setTimeout(() => {
            const qtyInput = document.getElementById('sinv-item-qty');
            if (qtyInput) {
                qtyInput.focus();
                qtyInput.select();
            }
        }, 100);

        // Enter key to confirm inside modal
        modal.onkeydown = (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                window.confirmAddInvoiceItem();
            }
        };
    } else {
        alert("Error: supplier-item-modal not found");
    }
};

window.closeSupplierItemModal = () => {
    const modal = document.getElementById('supplier-item-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    window.quickStockAddMode = false;
    window.quickStockAddVariantId = null;
    window._sinvRefBuying = 0;
    window._sinvRefRetail = 0;
    
    const stockBadge = document.getElementById('sinv-modal-stock-badge');
    if (stockBadge) stockBadge.style.display = 'none';

    // Hide current price panel
    const priceWrap = document.getElementById('sinv-current-price-wrap');
    if (priceWrap) priceWrap.style.display = 'none';
    
    // Clear inputs safely for next entry
    const ids = ['sinv-item-search','sinv-item-id','sinv-item-qty','sinv-item-buying','sinv-item-disc','sinv-item-net-cost','sinv-item-retail','sinv-item-sd', 'sinv-item-loyalty', 'sinv-item-wholesale', 'sinv-item-serial', 'sinv-item-expiry', 'sinv-item-warranty', 'sinv-item-variant', 'sinv-item-code'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = (id === 'sinv-item-qty' ? '1' : (id === 'sinv-item-net-cost' ? 'Rs 0.00' : ''));
    });
};

window.addToSupplierInvoice = (docId) => {
    console.log(`[SINV Debug] addToSupplierInvoice triggered for docId: ${docId}`);
    // [v3.12.18] Reset quick modes to ensure we are in Batch Mode
    window.quickStockAddMode = false;
    window.quickStockAddVariantId = null;

    try {
        if (!docId) return;
        const p = (window.allProducts || []).find(x => x.docId === docId);
        if (!p) {
            console.error(`[SINV Debug] Product not found in addToSupplierInvoice for docId: ${docId}`);
            return;
        }

        window.showToast(`Selected: ${p.name}`, "info");
        window.selectProductForInvoice(docId);
        window.openSupplierItemModal();
    } catch (e) {
        console.error(e);
        alert("Error selecting product: " + e.message);
    }
};

window.selectProductForInvoice = (docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;

    // 1. Basic Info
    const displayName = p.name + (p.size ? ` (${p.size})` : '') + (p.color ? ` (${p.color})` : '');
    document.getElementById('sinv-modal-product-name').innerText = displayName;
    document.getElementById('sinv-modal-sku-badge').innerText = `SKU: ${p.sku || 'N/A'}`;
    document.getElementById('sinv-item-id').value = docId;
    document.getElementById('sinv-item-name').value = displayName;
    document.getElementById('sinv-item-code').value = p.sku || '';
    
    // 2. Default Prices – use the MOST RECENT batch prices if variants exist
    let lastCost = p.cost || 0;
    let lastRetail = p.price || 0;
    let lastWholesale = p.wholesalePrice || 0;
    let lastLoyalty = p.loyaltyPrice || 0;
    if (p.variants && p.variants.length > 0) {
        const sorted = [...p.variants].sort((a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0));
        const latest = sorted[0];
        lastCost = latest.buyingPrice || latest.cost || lastCost;
        lastRetail = latest.sellingPrice || lastRetail;
        lastWholesale = latest.wholesalePrice || lastWholesale;
        lastLoyalty = latest.loyaltyPrice || lastLoyalty;
    }
    document.getElementById('sinv-item-buying').value = lastCost;
    document.getElementById('sinv-item-retail').value = lastRetail;
    
    // Set editable new prices defaulting to current values
    document.getElementById('sinv-item-new-buying').value = lastCost;
    document.getElementById('sinv-item-new-retail').value = lastRetail;
    
    document.getElementById('sinv-item-wholesale').value = lastWholesale;
    document.getElementById('sinv-item-loyalty').value = lastLoyalty;
    document.getElementById('sinv-item-qty').value = 1;

    // 3. Show Current Price Panel (read-only reference bar)
    // Store the reference prices so checkSINVPriceMatch can compare
    window._sinvRefBuying = lastCost;
    window._sinvRefRetail = lastRetail;

    const priceWrap = document.getElementById('sinv-current-price-wrap');
    const buyingDisplay = document.getElementById('sinv-current-buying-display');
    const retailDisplay = document.getElementById('sinv-current-retail-display');

    if (priceWrap && buyingDisplay && retailDisplay) {
        // Only show if product already has a price on record
        if (lastCost > 0 || lastRetail > 0) {
            priceWrap.style.display = 'block';
            buyingDisplay.innerText = `LKR ${Number(lastCost).toFixed(2)}`;
            retailDisplay.innerText = `LKR ${Number(lastRetail).toFixed(2)}`;
        } else {
            priceWrap.style.display = 'none';
        }
    }

    // 4. Variant chips
    const variantWrap = document.getElementById('sinv-existing-variants-wrap');
    const variantList = document.getElementById('sinv-existing-variants-list');
    
    if (p.variants && p.variants.length > 0) {
        variantWrap.style.display = 'block';
        variantList.innerHTML = p.variants.map((v, idx) => `
            <div class="variant-chip" onclick="window.loadVariantPrices(${idx}, '${docId}')" 
                style="padding: 10px 15px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 12px; cursor: pointer; display: flex; flex-direction: column; gap: 4px;">
                <span style="font-size: 0.65rem; font-weight: 800; color: #7dd3fc; opacity: 0.7;">${v.supplierName ? v.supplierName.substring(0, 15).toUpperCase() : `VARIANT ${idx + 1}`}</span>
                <span style="font-weight: 900; font-size: 0.9rem;">Cost: ${v.buyingPrice || v.cost || 0}</span>
                <span style="font-size: 0.7rem; opacity: 0.8;">Stk: ${v.stock || 0}</span>
            </div>
        `).join('');
    } else {
        variantWrap.style.display = 'none';
        variantList.innerHTML = '';
    }

    window.calcInvoiceLineTotal();
    window.checkSINVPriceMatch();
};

// Checks if entered prices match the existing record, shows badge accordingly
window.checkSINVPriceMatch = () => {
    const badge = document.getElementById('sinv-price-match-badge');
    const buyingInput = document.getElementById('sinv-item-new-buying');
    const retailInput = document.getElementById('sinv-item-new-retail');
    if (!badge || !buyingInput || !retailInput) return;

    const refBuying = window._sinvRefBuying || 0;
    const refRetail = window._sinvRefRetail || 0;
    const newBuying = parseFloat(buyingInput.value) || 0;
    const newRetail = parseFloat(retailInput.value) || 0;

    const buyingChanged = Math.abs(newBuying - refBuying) >= 0.01;
    const retailChanged = Math.abs(newRetail - refRetail) >= 0.01;

    if (buyingChanged || retailChanged) {
        badge.innerText = '⚠️ NEW PRICE — New Variant Batch will be created';
        badge.style.background = 'rgba(251,191,36,0.15)';
        badge.style.color = '#fbbf24';
        badge.style.borderColor = 'rgba(251,191,36,0.4)';
        // Highlight the buying/retail inputs to show they're "new"
        buyingInput.style.borderColor = buyingChanged ? 'rgba(251,191,36,0.6)' : '';
        retailInput.style.borderColor = retailChanged ? 'rgba(251,191,36,0.6)' : '';
    } else {
        badge.innerText = '✓ SAME PRICE — Stock will be added to existing';
        badge.style.background = 'rgba(16,185,129,0.15)';
        badge.style.color = '#10b981';
        badge.style.borderColor = 'rgba(16,185,129,0.3)';
        buyingInput.style.borderColor = '';
        retailInput.style.borderColor = '';
    }
};

window.loadVariantPrices = (idx, docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p || !p.variants || !p.variants[idx]) return;
    
    const v = p.variants[idx];
    document.getElementById('sinv-item-new-buying').value = v.buyingPrice || v.cost || 0;
    document.getElementById('sinv-item-new-retail').value = v.sellingPrice || v.price || 0;
    document.getElementById('sinv-item-wholesale').value = v.wholesalePrice || 0;
    document.getElementById('sinv-item-loyalty').value = v.loyaltyPrice || 0;
    
    window.calcInvoiceLineTotal();
    window.showToast(`✅ Loaded Variant ${idx+1} pricing`, "info");
};


window.calcInvoiceLineTotal = () => {
    const buying = parseFloat(document.getElementById('sinv-item-new-buying').value) || 0;
    const disc = parseFloat(document.getElementById('sinv-item-disc').value) || 0;
    const qty = parseFloat(document.getElementById('sinv-item-qty').value) || 1;
    const retail = parseFloat(document.getElementById('sinv-item-new-retail').value) || 0;
    
    // Net Cost and Total
    const net = buying * (1 - disc / 100);
    const totalCost = net * qty;
    const netEl = document.getElementById('sinv-item-net-cost');
    if (netEl) netEl.value = net.toFixed(2);
    
    // Profit Margin evaluation (Gross Margin Calculation)
    // Formula: (Selling Price - Cost) / Selling Price
    const profitMarginSpan = document.getElementById('sinv-profit-margin-display');
    if (profitMarginSpan) {
        if (retail > 0 && retail > net) {
            const profit = retail - net;
            const margin = (profit / retail) * 100; 
            profitMarginSpan.innerText = `${margin.toFixed(2)}%`;
            
            // Professional Margin Indicators
            if (margin >= 25) profitMarginSpan.style.color = '#10b981'; // Healthy Margin
            else if (margin >= 5) profitMarginSpan.style.color = '#fbbf24'; // Narrow Margin
            else profitMarginSpan.style.color = '#ef4444'; // Critical Margin
        } else {
            profitMarginSpan.innerText = '0.00%';
            profitMarginSpan.style.color = '#ef4444';
        }
    }
};

window.quickStockAddMode = false;
window.quickStockAddVariantId = null;

window.openQuickStockAdd = (docId, variantId = '') => {
    window.quickStockAddMode = true;
    window.quickStockAddVariantId = variantId;
    
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;

    window.selectProductForInvoice(docId);
    
    // If variantId is provided, auto-load that variant's prices
    if (variantId && p.variants) {
        const vIdx = p.variants.findIndex(v => v.variantId === variantId);
        if (vIdx !== -1) {
            window.loadVariantPrices(vIdx, docId);
        }
    }

    // Change Modal Title for clarity
    const modalTitle = document.getElementById('sinv-modal-product-name');
    if (modalTitle) modalTitle.innerText = "Direct Stock Addition";
    
    // Show Current Stock Badge
    const stockBadge = document.getElementById('sinv-modal-stock-badge');
    if (stockBadge) {
        let currentQty = p.stock || 0;
        if (variantId && p.variants) {
            const v = p.variants.find(vx => vx.variantId === variantId);
            if (v) currentQty = v.stock || 0;
        }
        stockBadge.innerText = `Current Stock: ${currentQty}`;
        stockBadge.style.display = 'inline-block';
    }
    
    window.openSupplierItemModal();
};

window.confirmAddInvoiceItem = async (keepOpen = false) => {
    console.log("[SINV Debug] confirmAddInvoiceItem triggered.");
    if (!window.allProducts || window.allProducts.length === 0) {
        console.warn("[SINV Debug] window.allProducts is empty or undefined!");
        window.showToast("Catalog is loading, please wait...", "warning");
        return;
    }

    const id = document.getElementById('sinv-item-id').value;
    const nameStr = document.getElementById('sinv-item-name').value.trim();
    const qty = parseFloat(document.getElementById('sinv-item-qty').value) || 0;
    const buying = parseFloat(document.getElementById('sinv-item-new-buying').value) || 0;
    const disc = parseFloat(document.getElementById('sinv-item-disc').value) || 0;
    const retail = parseFloat(document.getElementById('sinv-item-new-retail').value) || 0;
    const sd = parseFloat(document.getElementById('sinv-item-sd').value) || 0;
    const loyalty = parseFloat(document.getElementById('sinv-item-loyalty').value) || 0;
    const wholesale = parseFloat(document.getElementById('sinv-item-wholesale').value) || 0;
    
    const expiry = document.getElementById('sinv-item-expiry').value;
    const warranty = document.getElementById('sinv-item-warranty').value.trim();
    const sku = document.getElementById('sinv-item-code').value.trim();
    const variant = document.getElementById('sinv-item-variant').value.trim();

    if (!nameStr || qty <= 0) return window.showToast("Please enter a valid product and quantity.", "warning");

    const netCost = buying * (1 - disc / 100);
    const totalCost = netCost * qty;

    if (window.quickStockAddMode) {
        // DIRECT SAVE TO FIRESTORE
        try {
            const pRef = doc(db, "products", id);
            const p = window.allProducts.find(x => x.docId === id);
            if (!p) throw new Error("Product not found");

            if (window.quickStockAddVariantId) {
                // Update specific variant with Weighted Average Cost (WAC)
                const variants = [...(p.variants || [])];
                const vIdx = variants.findIndex(v => v.variantId === window.quickStockAddVariantId);
                if (vIdx !== -1) {
                    const oldStock = parseFloat(variants[vIdx].stock) || 0;
                    const oldCost = parseFloat(variants[vIdx].cost || variants[vIdx].buyingPrice) || 0;
                    const newTotalStock = oldStock + qty;
                    // WAC: (old_stock × old_cost + new_qty × new_cost) / total_stock
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (qty * buying)) / newTotalStock
                        : buying;
                    variants[vIdx].stock = newTotalStock;
                    variants[vIdx].cost = parseFloat(wacCost.toFixed(4));
                    variants[vIdx].buyingPrice = parseFloat(wacCost.toFixed(4));
                    variants[vIdx].sellingPrice = retail;
                    variants[vIdx].wholesalePrice = wholesale;
                    variants[vIdx].loyaltyPrice = loyalty;
                    variants[vIdx].expiry = expiry;
                    variants[vIdx].warranty = warranty;
                }
                await updateDoc(pRef, { variants });
            } else {
                // Update base product with Weighted Average Cost (WAC)
                const hasVariants = p.variants && p.variants.length > 0;
                const priceDiffers = Math.abs((p.cost || 0) - buying) >= 0.01 || Math.abs((p.price || 0) - retail) >= 0.01;

                if (hasVariants || priceDiffers) {
                    let variants = [...(p.variants || [])];
                    if (variants.length === 0 && (parseFloat(p.stock) || 0) > 0) {
                        variants.push({
                            variantId: 'base-' + p.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: p.size || p.color || 'Existing Stock',
                            buyingPrice: parseFloat(p.cost) || 0,
                            cost: parseFloat(p.cost) || 0,
                            sellingPrice: parseFloat(p.price) || 0,
                            wholesalePrice: parseFloat(p.wholesalePrice) || 0,
                            loyaltyPrice: parseFloat(p.loyaltyPrice) || 0,
                            stock: parseFloat(p.stock) || 0,
                            sku: p.sku || '',
                            expiry: p.expiryDate || '',
                            warranty: p.warranty || '',
                            addedDate: p.addedDate || new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    // Look for variant with same price
                    const vIdx = variants.findIndex(v =>
                        Math.abs(Number(v.buyingPrice || v.cost) - buying) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - retail) < 0.01
                    );

                    if (vIdx !== -1) {
                        // Same price -> WAC merge
                        const oldVStock = parseFloat(variants[vIdx].stock) || 0;
                        const oldVCost = parseFloat(variants[vIdx].cost || variants[vIdx].buyingPrice) || 0;
                        const newTotalStock = oldVStock + qty;
                        const wacCost = newTotalStock > 0
                            ? ((oldVStock * oldVCost) + (qty * buying)) / newTotalStock
                            : buying;
                        variants[vIdx].stock = newTotalStock;
                        variants[vIdx].cost = parseFloat(wacCost.toFixed(4));
                        variants[vIdx].buyingPrice = parseFloat(wacCost.toFixed(4));
                        variants[vIdx].sellingPrice = retail;
                        variants[vIdx].wholesalePrice = wholesale;
                        variants[vIdx].loyaltyPrice = loyalty;
                        variants[vIdx].expiry = expiry;
                        variants[vIdx].warranty = warranty;
                    } else {
                        // Different price -> create new variant
                        variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: variant || '',
                            buyingPrice: buying,
                            cost: buying,
                            sellingPrice: retail,
                            wholesalePrice: wholesale,
                            loyaltyPrice: loyalty,
                            stock: qty,
                            sku: sku || p.sku || '',
                            expiry: expiry || '',
                            warranty: warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    const wacBaseCost = totalCalculatedStock > 0
                        ? variants.reduce((sum, v) => sum + ((parseFloat(v.cost || v.buyingPrice) || 0) * (parseFloat(v.stock) || 0)), 0) / totalCalculatedStock
                        : buying;

                    await updateDoc(pRef, {
                        variants: variants,
                        stock: totalCalculatedStock,
                        totalStock: totalCalculatedStock,
                        cost: parseFloat(wacBaseCost.toFixed(4)),
                        price: retail,
                        wholesalePrice: wholesale,
                        loyaltyPrice: loyalty,
                        expiryDate: expiry,
                        warranty: warranty
                    });
                } else {
                    // Update base product with Weighted Average Cost (WAC)
                    const oldStock = parseFloat(p.stock) || 0;
                    const oldCost = parseFloat(p.cost) || 0;
                    const newTotalStock = oldStock + qty;
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (qty * buying)) / newTotalStock
                        : buying;
                    await updateDoc(pRef, {
                        stock: newTotalStock,
                        cost: parseFloat(wacCost.toFixed(4)),
                        price: retail,
                        wholesalePrice: wholesale,
                        loyaltyPrice: loyalty,
                        expiryDate: expiry,
                        warranty: warranty
                    });
                }
            }

            // Success: Clean up
            window.quickStockAddMode = false;
            window.quickStockAddVariantId = null;
            
            window.closeSupplierItemModal();
            window.showToast("✅ Stock updated successfully!", "success");
            
            // Refresh product list globally
            if (typeof window.loadAllProducts === 'function') window.loadAllProducts();

        } catch (err) {
            console.error(err);
            window.showToast("Failed to update stock: " + err.message, "error");
        } finally {
            window.quickStockAddMode = false;
            window.quickStockAddVariantId = null;
            // Force table refresh in case it was partially updated
            if (typeof window.renderInvoiceItemsTable === 'function') window.renderInvoiceItemsTable();
        }
        return;
    }

    // BATCH MODE (Invoice)
    window.currentInvoiceItems.push({
        docId: id || 'NEW',
        sku: sku,
        name: nameStr,
        variant: variant,
        qty: qty,
        buying: buying,
        discount: disc,
        unitCost: netCost,
        totalCost: totalCost,
        retail: retail,
        sellingDiscount: sd,
        loyalty: loyalty,
        wholesale: wholesale,
        expiry: expiry,
        warranty: warranty
    });

    if (keepOpen) {
        document.getElementById('sinv-item-search').value = '';
        document.getElementById('sinv-item-id').value = '';
        
        const nameInput = document.getElementById('sinv-item-name');
        if (nameInput) {
            nameInput.value = '';
            nameInput.readOnly = false;
        }
        
        const skuInput = document.getElementById('sinv-item-code');
        if (skuInput) {
            skuInput.value = '';
            skuInput.readOnly = false;
        }
        
        document.getElementById('sinv-item-qty').value = '1';
        document.getElementById('sinv-item-new-buying').value = '';
        document.getElementById('sinv-item-new-retail').value = '';
        document.getElementById('sinv-item-disc').value = '0';
        document.getElementById('sinv-item-sd').value = '0';
        document.getElementById('sinv-item-wholesale').value = '';
        document.getElementById('sinv-item-loyalty').value = '';
        document.getElementById('sinv-item-variant').value = '';
        
        window.calcInvoiceLineTotal(); // Reset totals display
        
        // Let user search or type a new product name immediately
        document.getElementById('sinv-item-search').focus();
    } else {
        window.closeSupplierItemModal();
        setTimeout(() => document.getElementById('sinv-search')?.focus(), 300);
    }
    
    window.renderInvoiceItemsTable();
};

window.updateSinvCartQty = (index, newQty, inputEl) => {
    const qty = parseFloat(newQty) || 0;
    const item = window.currentInvoiceItems[index];
    if (!item) return;

    item.qty = qty;
    const discountRs = item.discountRs || 0;
    item.totalCost = Math.max(0, (item.unitCost * qty) - discountRs);
    item.discountedCost = item.totalCost;
    
    if (inputEl) {
        const tr = inputEl.closest('tr');
        if (tr) {
            const tdTotal = tr.querySelector('.sinv-total-cell');
            if (tdTotal) {
                tdTotal.innerText = item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2});
            }
        }
    }

    let grand = 0;
    window.currentInvoiceItems.forEach(i => grand += i.totalCost);
    const grandTotalEl = document.getElementById('sinv-grand-total');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;
};

// Update discount for a row item — called when either % or Rs input changes
window.updateSinvDiscount = (index, type, value, inputEl) => {
    const item = window.currentInvoiceItems[index];
    if (!item) return;

    const rawCost = item.unitCost * item.qty;
    const val = parseFloat(value) || 0;

    if (type === 'pct') {
        item.discountPct = Math.min(100, Math.max(0, val));
        item.discountRs = parseFloat(((rawCost * item.discountPct) / 100).toFixed(2));
    } else {
        item.discountRs = Math.min(rawCost, Math.max(0, val));
        item.discountPct = parseFloat(((item.discountRs / rawCost) * 100).toFixed(2));
    }

    item.totalCost = Math.max(0, rawCost - item.discountRs);
    item.discountedCost = item.totalCost;

    // Update sibling inputs in same row
    if (inputEl) {
        const tr = inputEl.closest('tr');
        if (tr) {
            const pctInput = tr.querySelector('.sinv-disc-pct');
            const rsInput  = tr.querySelector('.sinv-disc-rs');
            const totalCell = tr.querySelector('.sinv-total-cell');
            if (pctInput && type !== 'pct') pctInput.value = item.discountPct;
            if (rsInput  && type !== 'rs')  rsInput.value  = item.discountRs;
            if (totalCell) totalCell.innerText = item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2});
        }
    }

    // Recalculate grand total
    let grand = 0;
    window.currentInvoiceItems.forEach(i => grand += i.totalCost);
    const grandTotalEl = document.getElementById('sinv-grand-total');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;
};

window.renderInvoiceItemsTable = () => {
    const body = document.getElementById('sinv-items-body');
    if (!body) return;

    if (window.currentInvoiceItems.length === 0) {
        body.innerHTML = `<tr><td colspan="6" style="padding: 100px 0; text-align: center; color: rgba(255,255,255,0.2); font-weight: 800; font-size: 1rem;">No items added to this order.</td></tr>`;
    } else {
        body.innerHTML = '';
    }
    
    let grand = 0;

    window.currentInvoiceItems.forEach((item, index) => {
        // Ensure discount fields exist
        if (item.discountPct === undefined) item.discountPct = 0;
        if (item.discountRs  === undefined) item.discountRs  = 0;
        // Recalculate totalCost respecting discount
        const rawCost = item.unitCost * item.qty;
        item.totalCost = Math.max(0, rawCost - item.discountRs);
        item.discountedCost = item.totalCost;
        grand += item.totalCost;
        
        const tr = document.createElement('tr');
        tr.style.cssText = 'border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;';
        tr.onmouseover = () => tr.style.background = 'rgba(255,255,255,0.02)';
        tr.onmouseout = () => tr.style.background = 'transparent';

        tr.innerHTML = `
            <td style="padding: 18px 15px;">
                <div style="font-weight: 800; color: #fff; font-size: 1.05rem; letter-spacing: 0.3px;">${item.name}</div>
                <div style="font-size: 0.75rem; color: #64748b; font-family: 'JetBrains Mono', monospace; margin-top: 5px;">SKU: ${item.sku}</div>
            </td>
            <td style="padding: 15px; text-align: center; font-weight: 700; color: #94a3b8; font-size: 1.1rem;">${item.buying.toFixed(2)}</td>
            <td style="padding: 15px; text-align: center;">
                <input type="number" min="0" value="${item.qty}" step="any"
                    oninput="window.updateSinvCartQty(${index}, this.value, this)"
                    onblur="if(!this.value || this.value<=0) window.removeInvoiceItem(${index})"
                    style="background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 8px; border-radius: 12px; font-weight: 950; font-size: 1.2rem; border: 1px solid rgba(56, 189, 248, 0.2); width: 80px; text-align: center; outline: none;">
            </td>
            <td style="padding: 10px 15px; text-align: center; min-width: 160px;">
                <div style="display: flex; flex-direction: column; gap: 5px; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 4px; width: 100%;">
                        <input type="number" min="0" max="100" step="0.1" value="${item.discountPct || 0}"
                            class="sinv-disc-pct"
                            oninput="window.updateSinvDiscount(${index}, 'pct', this.value, this)"
                            style="background: rgba(245, 158, 11, 0.08); color: #f59e0b; padding: 6px 8px; border-radius: 8px; font-weight: 800; font-size: 0.9rem; border: 1px solid rgba(245, 158, 11, 0.25); width: 70px; text-align: center; outline: none;">
                        <span style="font-size: 0.75rem; color: #f59e0b; font-weight: 900;">%</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 4px; width: 100%;">
                        <input type="number" min="0" step="0.01" value="${item.discountRs || 0}"
                            class="sinv-disc-rs"
                            oninput="window.updateSinvDiscount(${index}, 'rs', this.value, this)"
                            style="background: rgba(245, 158, 11, 0.08); color: #fbbf24; padding: 6px 8px; border-radius: 8px; font-weight: 800; font-size: 0.9rem; border: 1px solid rgba(245, 158, 11, 0.25); width: 70px; text-align: center; outline: none;">
                        <span style="font-size: 0.75rem; color: #fbbf24; font-weight: 900;">Rs</span>
                    </div>
                </div>
            </td>
            <td class="sinv-total-cell" style="padding: 15px; text-align: right; font-weight: 950; color: #fff; font-size: 1.3rem; letter-spacing: 0.5px;">${item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
            <td style="padding: 15px; text-align: right;">
                <button onclick="window.removeInvoiceItem(${index})" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #ef4444; padding: 10px 15px; border-radius: 12px; cursor: pointer; transition: all 0.2s; font-size: 1.2rem;">🗑️</button>
            </td>
        `;
        if (window.currentInvoiceItems.length > 0) body.appendChild(tr);
    });

    const grandTotalEl = document.getElementById('sinv-grand-total');
    const itemCountEl = document.getElementById('sinv-item-count');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    if (itemCountEl) itemCountEl.innerText = window.currentInvoiceItems.length.toString();

    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;

    // Auto-scroll to bottom
    const scrollParent = body.parentElement.parentElement;
    if (scrollParent) scrollParent.scrollTop = scrollParent.scrollHeight;
};

window.removeInvoiceItem = (index) => {
    window.currentInvoiceItems.splice(index, 1);
    window.renderInvoiceItemsTable();
};

window.saveSupplierInvoice = async () => {
    const invNoEl = document.getElementById('sinv-no');
    const supplierEl = document.getElementById('sinv-supplier-id');
    const dateEl = document.getElementById('sinv-date');
    const payMethodEl = document.getElementById('sinv-pay-method');
    const paidEl = document.getElementById('sinv-paid');

    const invNo = invNoEl?.value?.trim();
    const supplierId = supplierEl?.value;
    const date = dateEl?.value;
    const payMethod = payMethodEl?.value;
    const paid = parseFloat(paidEl?.value) || 0;
    
    console.log("Attempting to save invoice:", { invNo, supplierId, date, itemsCount: window.currentInvoiceItems?.length });

    if (!invNo || invNo === 'INV-...') {
        return window.showToast("Please enter an Invoice Reference number.", "warning");
    }
    if (!supplierId || supplierId === "" || supplierEl.selectedIndex === 0) {
        return window.showToast("Please select a Primary Supplier.", "warning");
    }
    if (!date) {
        return window.showToast("Please select a Posting Date.", "warning");
    }
    if (!window.currentInvoiceItems || window.currentInvoiceItems.length === 0) {
        return window.showToast("Please add at least one item to the invoice.", "warning");
    }

    const supplierTxt = supplierEl.options[supplierEl.selectedIndex].text;
    const storeId = window.getStoreId();
    let total = 0;
    window.currentInvoiceItems.forEach(i => total += i.totalCost);

    try {
        window.showToast("⏳ Processing Inventory Update...", "info");
        
        // 1. Add to supplierInvoices
        const isCheque = (payMethod || '').toLowerCase() === 'cheque';
        const chequeDate = isCheque ? (window._confirmedChequeDate || null) : null;
        // Cheque invoices are always Pending until cheque date passes (even if full amount noted)
        const invoiceStatus = isCheque ? 'Pending' :
            (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));

        const invData = {
            invoiceNo: invNo,
            supplierId: supplierId,
            supplierName: supplierTxt,
            date: date,
            paymentMethod: payMethod,
            paid: paid,
            paidAmount: paid,
            grandTotal: total,
            totalAmount: total,
            status: invoiceStatus,
            chequeDate: chequeDate,
            chequeStatus: isCheque ? 'pending' : null,
            items: window.currentInvoiceItems,
            storeId: storeId,
            timestamp: serverTimestamp()
        };
        
        const invRef = await addDoc(sinvoicesCol, invData);
        console.log("Invoice document created:", invRef.id);

        // 2. Update Products Stock and Variants Logic
        const batch = writeBatch(db);
        let updateCount = 0;
        
        // Track accumulated updates for existing products to prevent overwrites in the same batch
        const accumulatedUpdates = {};
        // Track newly created products to prevent duplicate docs for the same new SKU
        const newProductsMap = {};

        for (const item of window.currentInvoiceItems) {
            if (item.docId && item.docId !== 'NEW') {
                const pRef = doc(db, "products", item.docId);
                
                // Get from accumulated updates first, or fallback to allProducts
                let p = accumulatedUpdates[item.docId];
                if (!p) {
                    const originalP = (window.allProducts || []).find(x => x.docId === item.docId);
                    if (originalP) {
                        p = JSON.parse(JSON.stringify(originalP)); // Deep clone
                        accumulatedUpdates[item.docId] = p;
                    }
                }
                
                if (p) {
                    let variants = p.variants || [];
                    const incomingBuyingPrice = Number(item.buying);
                    const incomingRetailPrice = Number(item.retail);

                    // If variants is empty and the product has existing stock, convert the base stock to a variant first!
                    if (variants.length === 0 && (parseFloat(p.stock) || 0) > 0) {
                        variants.push({
                            variantId: 'base-' + p.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: p.size || p.color || 'Existing Stock',
                            buyingPrice: parseFloat(p.cost) || 0,
                            cost: parseFloat(p.cost) || 0,
                            sellingPrice: parseFloat(p.price) || 0,
                            wholesalePrice: parseFloat(p.wholesalePrice) || 0,
                            loyaltyPrice: parseFloat(p.loyaltyPrice) || 0,
                            stock: parseFloat(p.stock) || 0,
                            sku: p.sku || '',
                            expiry: p.expiryDate || '',
                            warranty: p.warranty || '',
                            addedDate: p.addedDate || new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    // SMART BATCH LOGIC:
                    const existingVariantIndex = variants.findIndex(v =>
                        v.supplierId === supplierId &&
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                    );

                    if (existingVariantIndex !== -1) {
                        // Same price → WAC merge into existing batch
                        const oldStock = parseFloat(variants[existingVariantIndex].stock) || 0;
                        variants[existingVariantIndex].stock = oldStock + Number(item.qty);
                        variants[existingVariantIndex].lastUpdated = Date.now();
                    } else {
                        // Different price → NEW batch/variant
                        variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: incomingBuyingPrice,
                            cost: incomingBuyingPrice,
                            sellingPrice: incomingRetailPrice,
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    
                    // Update our accumulated record
                    p.variants = variants;
                    p.stock = totalCalculatedStock;
                    p.totalStock = totalCalculatedStock;
                    p.cost = incomingBuyingPrice; // update latest cost
                    p.price = incomingRetailPrice; // update latest price
                    
                    // Note: We'll do the actual batch.update() outside the loop!
                }
            } else if (item.docId === 'NEW') {
                const skuKey = (item.sku || ('temp-' + Date.now())).toLowerCase();
                
                // If we already created a new product for this SKU in the SAME invoice, just add as a variant
                if (newProductsMap[skuKey]) {
                    const existingNewP = newProductsMap[skuKey];
                    const existingVariantIndex = existingNewP.variants.findIndex(v =>
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - Number(item.buying)) < 0.01
                    );
                    
                    if (existingVariantIndex !== -1) {
                        existingNewP.variants[existingVariantIndex].stock += Number(item.qty);
                    } else {
                        existingNewP.variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5), 
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: Number(item.buying),
                            sellingPrice: Number(item.retail),
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }
                    existingNewP.stock += Number(item.qty);
                    existingNewP.totalStock += Number(item.qty);
                } else {
                    const pRef = doc(collection(db, "products"));
                    newProductsMap[skuKey] = {
                        ref: pRef,
                        name: item.name,
                        sku: item.sku || '',
                        cost: Number(item.buying),
                        price: Number(item.retail),
                        stock: Number(item.qty),
                        totalStock: Number(item.qty),
                        mode: "Shop", // ADDED MODE HERE
                        variants: [{
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5), 
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: Number(item.buying),
                            sellingPrice: Number(item.retail),
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        }],
                        category: "General",
                        brand: "SINV Auto-Added",
                        storeId: storeId,
                        lastUpdated: serverTimestamp(),
                        timestamp: serverTimestamp()
                    };
                }
            }
        }
        
        // Execute accumulated updates
        for (const [docId, pData] of Object.entries(accumulatedUpdates)) {
            const pRef = doc(db, "products", docId);
            batch.update(pRef, {
                variants: pData.variants,
                stock: pData.stock,
                totalStock: pData.totalStock,
                cost: pData.cost,
                price: pData.price,
                lastStockUpdate: serverTimestamp(),
                lastUpdated: serverTimestamp()
            });
            updateCount++;
        }
        
        // Execute accumulated new products
        for (const [skuKey, newPData] of Object.entries(newProductsMap)) {
            const pRef = newPData.ref;
            delete newPData.ref; // remove ref from data
            batch.set(pRef, newPData);
            updateCount++;
        }
        
        await batch.commit();
        console.log(`Success: ${updateCount} products updated in inventory.`);

        window.showToast("🚀 Inventory Updated Successfully!", "success");
        window.clearCurrentInvoice();
        if (window.showSubTab) window.showSubTab('supplier-invoices', 'list');
        
    } catch (err) {
        console.error("Critical error saving invoice:", err);
        window.showToast("Critical Error: " + err.message, "error");
    }
};

window.quickAddProductForSINV = async () => {
    const name = document.getElementById('qa-prod-name').value.trim();
    const price = Math.round((parseFloat(document.getElementById('qa-prod-price').value) || 0) * 1000) / 1000;
    const cost = Math.round((parseFloat(document.getElementById('qa-prod-cost').value) || 0) * 1000) / 1000;
    const category = document.getElementById('qa-prod-category').value || "General";
    const mode = document.getElementById('qa-prod-mode').value || "Shop";
    let sku = document.getElementById('qa-prod-sku').value.trim();

    if(!name || isNaN(price) || isNaN(cost)) {
        window.showToast("Please enter product name, price, and cost.", "error");
        return;
    }
    if(!sku) {
        sku = 'QA' + Math.floor(Math.random() * 1000000);
    }

    try {
        const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
        const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;

        const prodData = {
            name,
            sellingPrice: price,
            totalStock: 0,
            cost: cost,
            price: price,
            wholesalePrice: Math.round((price * (1 - wholesalePct / 100)) * 1000) / 1000,
            loyaltyPrice: Math.round((price * (1 - loyaltyPct / 100)) * 1000) / 1000,
            sku,
            brand: "Quick Add",
            category,
            mode,
            stock: 0,
            searchRef: name.toLowerCase(),
            storeId: window.getStoreId(),
            createdAt: new Date()
        };
        
        // Use globally imported addDoc and collection from admin.js top
        const docRef = await addDoc(collection(db, 'products'), prodData);
        window.showToast("Product added successfully!", "success");
        document.getElementById('sinv-quick-product-modal').style.display = 'none';
        
        // Push locally so it's instantly available in search & selection
        const createdProd = { id: docRef.id, docId: docRef.id, ...prodData };
        if (!window.allProducts) window.allProducts = [];
        window.allProducts.unshift(createdProd);

        // Clear fields
        document.getElementById('qa-prod-name').value = '';
        document.getElementById('qa-prod-price').value = '';
        document.getElementById('qa-prod-cost').value = '';
        document.getElementById('qa-prod-sku').value = '';
        document.getElementById('qa-prod-category').value = '';
        document.getElementById('qa-prod-mode').value = 'Shop';
        
        // Auto select and open in supplier invoice item modal
        if (typeof window.addToSupplierInvoice === 'function') {
            window.addToSupplierInvoice(docRef.id);
        } else {
            const searchInput = document.getElementById('sinv-search');
            if (searchInput) {
                searchInput.value = sku;
                window.handleSINVSearch(sku);
            }
        }
    } catch(err) {
        console.error(err);
        window.showToast("Failed to add product.", "error");
    }
};

window.clearCurrentInvoice = () => {
    window.currentInvoiceItems = [];
    if (document.getElementById('sinv-no')) document.getElementById('sinv-no').value = '';
    if (document.getElementById('sinv-paid')) document.getElementById('sinv-paid').value = '0';
    if (document.getElementById('sinv-search')) document.getElementById('sinv-search').value = '';
    window.renderInvoiceItemsTable();
    window.handleSINVSearch('');
};

window.handleSupplierInvoiceBulkCSV = (input) => {
    if (!input.files[0]) return;
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
        const text = e.target.result;
        const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
        if (lines.length < 2) return window.showToast("CSV is empty.", "error");

        const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
        const rows = lines.slice(1);

        // Map columns
        const colMap = {
            sku: headers.findIndex(h => h.includes('sku') || h.includes('code')),
            name: headers.findIndex(h => h.includes('name') || h.includes('product')),
            qty: headers.findIndex(h => h.includes('qty') || h.includes('quantity')),
            buying: headers.findIndex(h => h.includes('buying') || h.includes('cost')),
            disc: headers.findIndex(h => h.includes('discount') || h.includes('disc')),
            retail: headers.findIndex(h => h.includes('retail') || h.includes('price')),
            sd: headers.findIndex(h => h.includes('selling discount')),
            loyalty: headers.findIndex(h => h.includes('loyalty')),
            wholesale: headers.findIndex(h => h.includes('wholesale'))
        };

        if (colMap.name === -1 && colMap.sku === -1) {
             return window.showToast("CSV must have 'Name' or 'SKU' column.", "error");
        }

        let foundCount = 0;
        rows.forEach(row => {
            const cols = row.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
            const name = colMap.name !== -1 ? cols[colMap.name] : '';
            const sku = colMap.sku !== -1 ? cols[colMap.sku] : '';
            
            if (!name && !sku) return;

            // Find existing product by SKU or Name
            const p = window.allProducts.find(x => (sku && x.sku === sku) || (name && (x.name || '').toLowerCase() === name.toLowerCase()));
            
            if (p) {
                const qty = parseFloat(cols[colMap.qty]) || 1;
                const buying = parseFloat(cols[colMap.buying]) || p.cost || 0;
                const disc = parseFloat(cols[colMap.disc]) || 0;
                const net = buying * (1 - disc / 100);
                
                window.currentInvoiceItems.push({
                    docId: p.docId,
                    sku: p.sku || sku,
                    name: p.name || name,
                    qty: qty,
                    buying: buying,
                    discount: disc,
                    unitCost: net,
                    totalCost: net * qty,
                    retail: parseFloat(cols[colMap.retail]) || p.price || 0,
                    sellingDiscount: parseFloat(cols[colMap.sd]) || p.discount || 0,
                    loyalty: parseFloat(cols[colMap.loyalty]) || p.loyaltyPrice || 0,
                    wholesale: parseFloat(cols[colMap.wholesale]) || p.wholesalePrice || 0
                });
                foundCount++;
            }
        });

        window.showToast(`📥 Processed ${foundCount} items from CSV.`, "success");
        window.renderInvoiceItemsTable();
        input.value = ''; // Reset input
    };

    reader.readAsText(file);
};

window.deleteSupplierInvoice = async (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const docRef = doc(db, "supplierInvoices", id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    
    try {
        window.showToast("⏳ Reverting stock...", "info");
        const batch = writeBatch(db);
        let updateCount = 0;

        for (const item of (inv.items || [])) {
            if (item.docId && item.docId !== 'NEW') {
                const p = (window.allProducts || []).find(x => x.docId === item.docId);
                if (p) {
                    const pRef = doc(db, "products", item.docId);
                    let variants = [...(p.variants || [])];
                    const incomingBuyingPrice = Number(item.buying);
                    const incomingRetailPrice = Number(item.retail);
                    const qtyToRemove = parseFloat(item.qty) || 0;

                    const existingVariantIndex = variants.findIndex(v =>
                        v.supplierId === inv.supplierId &&
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                    );

                    if (existingVariantIndex !== -1) {
                        variants[existingVariantIndex].stock = Math.max(0, (parseFloat(variants[existingVariantIndex].stock) || 0) - qtyToRemove);
                    }

                    const newTotalStock = Math.max(0, (parseFloat(p.stock) || 0) - qtyToRemove);
                    
                    batch.update(pRef, {
                        variants: variants,
                        stock: newTotalStock,
                        totalStock: newTotalStock,
                        lastUpdated: Date.now()
                    });
                    updateCount++;
                }
            }
        }

        if (updateCount > 0) {
            await batch.commit();
        }

        await deleteDoc(docRef);
        window.showToast("🗑️ Invoice record deleted and stock reverted.", "success");
    } catch(err) { console.error(err); }
};

// ─── EDIT SUPPLIER INVOICE MODAL ──────────────────────────────────────────────
window.editSupplierInvoice = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const currentStatus = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));

    // Build suppliers options
    const suppOptions = (window.allSuppliers || []).map(s =>
        `<option value="${s.docId}" ${s.docId === inv.supplierId ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    // Remove any previous modal
    document.getElementById('sinv-edit-modal-overlay')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'sinv-edit-modal-overlay';
    overlay.style = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:10000000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(10px);animation:fadeIn 0.2s ease;';
    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = `
    <div style="width:480px;background:#0f172a;border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:28px;box-shadow:0 30px 100px rgba(0,0,0,0.8);animation:slideUp 0.3s ease-out;">

        <!-- Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
            <div>
                <div style="font-size:1.3rem;font-weight:900;color:#fff;">✏️ Edit Invoice</div>
                <div style="font-size:0.75rem;color:#64748b;margin-top:3px;">Invoice #${inv.invoiceNo} &nbsp;•&nbsp; ${(inv.items||[]).length} items &nbsp;•&nbsp; Grand Total: <span style="color:#38bdf8;font-weight:800;">LKR ${total.toLocaleString()}</span></div>
            </div>
            <button onclick="document.getElementById('sinv-edit-modal-overlay').remove()" style="background:rgba(255,255,255,0.05);border:none;color:white;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.2rem;">✕</button>
        </div>

        <!-- Fields -->
        <div style="display:flex;flex-direction:column;gap:16px;">

            <!-- Invoice No -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">INVOICE REFERENCE</label>
                <input id="sinv-edit-invno" value="${inv.invoiceNo || ''}" 
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;font-weight:700;box-sizing:border-box;">
            </div>

            <!-- Date -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">POSTING DATE</label>
                <input id="sinv-edit-date" type="date" value="${inv.date || ''}" 
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
            </div>

            <!-- Supplier -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">SUPPLIER</label>
                <select id="sinv-edit-supplier" style="width:100%;margin-top:6px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
                    ${suppOptions}
                </select>
            </div>

            <!-- Payment Method -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">PAYMENT METHOD</label>
                <select id="sinv-edit-paymethod" style="width:100%;margin-top:6px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
                    <option value="CASH" ${(inv.paymentMethod||'CASH')==='CASH'?'selected':''}>Cash</option>
                    <option value="CREDIT" ${(inv.paymentMethod||'')==='CREDIT'?'selected':''}>Credit</option>
                    <option value="BANK_TRANSFER" ${(inv.paymentMethod||'')==='BANK_TRANSFER'?'selected':''}>Bank Transfer</option>
                    <option value="CHEQUE" ${(inv.paymentMethod||'')==='CHEQUE'?'selected':''}>Cheque</option>
                </select>
            </div>

            <!-- Paid Amount -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">CASH PAID (LKR)</label>
                <input id="sinv-edit-paid" type="number" min="0" step="0.01" value="${paid}" 
                    oninput="window.updateEditInvoiceStatus()"
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:1.1rem;font-weight:900;box-sizing:border-box;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;">
                    <div style="font-size:0.72rem;color:#64748b;">Grand Total: <span style="color:#38bdf8;font-weight:800;">LKR ${total.toLocaleString()}</span></div>
                    <div id="sinv-edit-status-preview" style="font-size:0.72rem;font-weight:800;padding:3px 10px;border-radius:6px;"></div>
                </div>
                <!-- Quick fill buttons -->
                <div style="display:flex;gap:8px;margin-top:8px;">
                    <button onclick="document.getElementById('sinv-edit-paid').value=${total};window.updateEditInvoiceStatus()" 
                        style="flex:1;background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#10b981;padding:7px;border-radius:8px;cursor:pointer;font-size:0.72rem;font-weight:800;">✅ FULL PAID (${total.toLocaleString()})</button>
                    <button onclick="document.getElementById('sinv-edit-paid').value=0;window.updateEditInvoiceStatus()" 
                        style="flex:1;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#ef4444;padding:7px;border-radius:8px;cursor:pointer;font-size:0.72rem;font-weight:800;">🔴 PENDING (0)</button>
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <button onclick="window.saveEditedSupplierInvoice('${id}', ${total})" 
            style="width:100%;margin-top:24px;background:linear-gradient(135deg,#38bdf8,#6366f1);border:none;color:#fff;padding:14px;border-radius:14px;font-size:1rem;font-weight:900;cursor:pointer;letter-spacing:0.5px;transition:all 0.2s;"
            onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">
            💾 SAVE CHANGES
        </button>
    </div>`;

    document.body.appendChild(overlay);
    // Set initial status preview
    window.updateEditInvoiceStatus();
};

window.updateEditInvoiceStatus = () => {
    const paidEl = document.getElementById('sinv-edit-paid');
    const previewEl = document.getElementById('sinv-edit-status-preview');
    if (!paidEl || !previewEl) return;
    const paidVal = parseFloat(paidEl.value) || 0;
    // Get total from the nearby span (stored as text)
    const totalSpan = document.querySelector('#sinv-edit-modal-overlay [style*="Grand Total"] span');
    const totalText = totalSpan ? totalSpan.innerText.replace(/[^0-9.]/g, '') : '0';
    const totalVal = parseFloat(totalText) || 0;

    if (paidVal >= totalVal && totalVal > 0) {
        previewEl.innerText = '✅ PAID';
        previewEl.style.background = 'rgba(16,185,129,0.2)';
        previewEl.style.color = '#10b981';
    } else if (paidVal > 0) {
        previewEl.innerText = '🟡 PARTIALLY PAID';
        previewEl.style.background = 'rgba(245,158,11,0.2)';
        previewEl.style.color = '#f59e0b';
    } else {
        previewEl.innerText = '🔴 PENDING';
        previewEl.style.background = 'rgba(251,191,36,0.15)';
        previewEl.style.color = '#fbbf24';
    }
};

window.saveEditedSupplierInvoice = async (id, total) => {
    const invNo  = document.getElementById('sinv-edit-invno')?.value.trim();
    const date   = document.getElementById('sinv-edit-date')?.value;
    const suppEl = document.getElementById('sinv-edit-supplier');
    const suppId = suppEl?.value;
    const suppName = suppEl?.options[suppEl.selectedIndex]?.text || '';
    const payMethod = document.getElementById('sinv-edit-paymethod')?.value;
    const paid  = parseFloat(document.getElementById('sinv-edit-paid')?.value) || 0;

    if (!invNo) return window.showToast('Invoice number required', 'warning');

    const newStatus = paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending');

    try {
        await updateDoc(doc(db, 'supplierInvoices', id), {
            invoiceNo: invNo,
            date: date,
            supplierId: suppId,
            supplierName: suppName,
            paymentMethod: payMethod,
            paid: paid,
            paidAmount: paid,
            status: newStatus,
            lastEditedAt: serverTimestamp()
        });
        document.getElementById('sinv-edit-modal-overlay')?.remove();
        window.showToast(`✅ Invoice updated! Status: ${newStatus}`, 'success');
        // Refresh the list
        if (typeof window.loadSupplierInvoices === 'function') window.loadSupplierInvoices();
        else if (typeof window.renderSupplierInvoicesList === 'function') window.renderSupplierInvoicesList();
    } catch(err) {
        console.error(err);
        window.showToast('Failed to update invoice: ' + err.message, 'error');
    }
};

// --- PROFESSIONAL CHARTERED ACCOUNTING MODULES ---
// window.switchReportView (REMOVED)

    // 1. UI Toggling
    // const views = ['summary', 'ledger', 'recon', 'aging', 'forecast', 'tax'];

/*
    views.forEach(v => {

        const el = document.getElementById(`report-view-${v}`);
        const nav = document.getElementById(`rep-nav-${v}`);
        if (el) el.style.display = (v === view) ? 'block' : 'none';
        if (nav) {
            if (v === view) nav.classList.add('active');
            else nav.classList.remove('active');
        }
    });

    // 2. Data Rendering

*/
// };



// [MIGRATED TO reports.js]

window.renderSupplierOverview = () => {
    const body = document.getElementById('sup-overview-recent-body');
    const monthlyTotalEl = document.getElementById('sup-stat-monthly-total');
    const pendingEl = document.getElementById('sup-stat-pending');
    const countEl = document.getElementById('sup-stat-count');
    if (!body) return;

    const invoices = window.allSupplierInvoices || [];
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    let monthlyTotal = 0;
    let pendingPayables = 0;

    invoices.forEach(inv => {
        const date = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000) : new Date(inv.date);
        if (date.getMonth() === currentMonth && date.getFullYear() === currentYear) {
            monthlyTotal += inv.totalAmount || inv.grandTotal || 0;
        }
        if (inv.status === 'Pending' || inv.status === 'Partially Paid') {
            pendingPayables += ((inv.totalAmount || inv.grandTotal || 0) - (inv.paidAmount || inv.paid || 0));
        }
    });

    if (monthlyTotalEl) monthlyTotalEl.innerText = `LKR ${monthlyTotal.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    if (pendingEl) pendingEl.innerText = `LKR ${pendingPayables.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    if (countEl) countEl.innerText = (window.allSuppliers || []).length.toString();

    // Show latest 10
    const latest = [...invoices].sort((a,b) => {
        const da = a.timestamp?.seconds ? a.timestamp.seconds : new Date(a.date).getTime() / 1000;
        const db = b.timestamp?.seconds ? b.timestamp.seconds : new Date(b.date).getTime() / 1000;
        return db - da;
    }).slice(0, 10);

    body.innerHTML = latest.map(inv => {
        const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();
        const total = inv.totalAmount || inv.grandTotal || 0;
        const paid = inv.paidAmount || inv.paid || 0;
        const status = paid >= total ? 'Paid' : 'Pending';
        return `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="font-size: 0.7rem; opacity: 0.7;">${dateStr}</td>
                <td style="font-weight: 700;">${inv.invoiceNo}</td>
                <td>${inv.supplierName}</td>
                <td style="text-align: right; font-weight: 800; color: #7dd3fc;">LKR ${total.toLocaleString()}</td>
                <td><span class="status-badge" style="background: ${status === 'Paid' ? '#10b98133' : '#fbbf2433'}; color: ${status === 'Paid' ? '#10b981' : '#fbbf24'}; padding: 4px 10px; border-radius: 8px; font-size: 0.65rem;">${status}</span></td>
            </tr>
        `;
    }).join('');
};

window.searchProductForComparison = () => {
    const query = document.getElementById('comp-search-product').value.toLowerCase();
    const dropdown = document.getElementById('comp-results-dropdown');
    if (!query || query.length < 2) { dropdown.style.display = 'none'; return; }

    const results = (window.allProducts || []).filter(p => 
        (p.name || '').toLowerCase().includes(query) || 
        (p.barcode && p.barcode.toLowerCase().includes(query))
    ).slice(0, 8);

    if (results.length === 0) { dropdown.style.display = 'none'; return; }

    dropdown.style.display = 'block';
    dropdown.innerHTML = results.map(p => `
        <div class="result-item" style="padding: 12px; border-bottom: 1px solid rgba(0,0,0,0.05); cursor: pointer;" onclick="window.selectProductForComparison('${p.docId}')">
            <div style="font-weight: 700; font-size: 0.85rem;">${p.name}</div>
            <div style="font-size: 0.7rem; opacity: 0.7;">Barcode: ${p.barcode || 'N/A'}</div>
        </div>
    `).join('');
};

window.selectProductForComparison = (pid) => {
    const dropdown = document.getElementById('comp-results-dropdown');
    const area = document.getElementById('comparison-analysis-area');
    const input = document.getElementById('comp-search-product');
    if (!dropdown || !area || !input) return;
    dropdown.style.display = 'none';

    const product = (window.allProducts || []).find(p => p.docId === pid);
    if (!product) return;
    input.value = product.name;

    // Search historical invoices for this product
    let history = [];
    (window.allSupplierInvoices || []).forEach(inv => {
        const item = (inv.items || []).find(it => it.docId === pid);
        if (item) {
            history.push({
                date: inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000) : new Date(inv.date),
                supplier: inv.supplierName,
                cost: item.buying || item.unitCost,
                qty: item.qty
            });
        }
    });

    if (history.length === 0) {
        area.innerHTML = `<p style="text-align: center; color: #ef4444; padding: 2rem;">⚠️ No purchase history found for this product.</p>`;
        return;
    }

    // Sort by cost (Cheapest first)
    const sorted = [...history].sort((a,b) => a.cost - b.cost);
    const cheapest = sorted[0];

    area.innerHTML = `
        <div style="margin-bottom: 2rem; padding: 2rem; background: rgba(16, 185, 129, 0.1); border-radius: 20px; border: 1px solid rgba(16, 185, 129, 0.3);">
            <div style="font-size: 0.7rem; font-weight: 800; color: #10b981; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 5px;">✨ Procurement Insight: Cheapest Source</div>
            <div style="font-size: 1.8rem; font-weight: 900; color: white;">${cheapest.supplier}</div>
            <div style="font-size: 1.2rem; margin-top: 5px; color: #10b981; font-weight: 800;">LKR ${cheapest.cost.toFixed(2)} <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: 400;">per unit</span></div>
        </div>

        <h4 style="margin: 0 0 1rem; opacity: 0.7; font-weight: 800; font-size: 0.8rem;">FULL SUPPLIER PRICE HISTORY</h4>
        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Supplier</th>
                        <th style="text-align: right;">Unit Cost</th>
                        <th style="text-align: right;">Diff vs Best</th>
                    </tr>
                </thead>
                <tbody>
                    ${history.sort((a,b) => b.date - a.date).map(h => {
                        const diff = h.cost - cheapest.cost;
                        return `
                            <tr>
                                <td style="font-size: 0.75rem; opacity: 0.6;">${h.date.toLocaleDateString()}</td>
                                <td style="font-weight: 700;">${h.supplier}</td>
                                <td style="text-align: right; font-weight: 800; color: #7dd3fc;">LKR ${h.cost.toFixed(2)}</td>
                                <td style="text-align: right; color: ${diff === 0 ? '#10b981' : '#ef4444'}; font-weight: 800;">
                                    ${diff === 0 ? '<span style="font-size: 0.65rem;">★ BEST PRIZE</span>' : `+LKR ${diff.toFixed(2)}`}
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
};


// --- Professional Procurement & PO System ---
window.currentPOItems = [];
window.selectedPOProduct = null;

window.initPOForm = function() {
    const supSelect = document.getElementById('po-supplier-id');
    if (supSelect) {
        const optionsHtml = (window.allSuppliers || []).map(s => `<option value="${s.docId || s.id}">${s.name}</option>`).join('');
        supSelect.innerHTML = '<option value="">-- Choose Supplier --</option>' + optionsHtml;
    }
    
    const currentDateEl = document.getElementById('po-current-date');
    if (currentDateEl) {
        currentDateEl.innerText = new Date().toLocaleDateString(undefined, {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    const postingDateInput = document.getElementById('po-posting-date');
    if (postingDateInput) {
        postingDateInput.value = new Date().toISOString().split('T')[0];
    }
    
    window.renderPOItems();
};
window.handlePOSelection = (name, docId) => {
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim().toLowerCase() === name.toLowerCase());
    if (variants.length > 1) {
        window.openVariantPickerForPO(name);
    } else {
        window.selectPOProduct(docId);
    }
};

window.openVariantPickerForPO = (name) => {
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim().toLowerCase() === name.toLowerCase());
    if (variants.length === 0) return;

    const overlay = document.createElement('div');
    overlay.id = "po-variant-picker-overlay";
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:10000000; display:flex; align-items:center; justify-content:center; backdrop-filter: blur(8px); animation: fadeIn 0.2s ease;";
    overlay.onclick = (e) => { if(e.target === overlay) overlay.remove(); };
    
    const content = document.createElement('div');
    content.style = "width: 500px; max-height: 80vh; overflow-y: auto; padding: 25px; border-radius: 28px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 25px 100px rgba(0,0,0,0.8); position: relative; animation: slideUp 0.3s ease-out;";
    
    content.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; position: sticky; top: 0; background: #0f172a; padding: 10px 0; z-index: 10;">
            <div>
                <h3 style="margin: 0; font-size: 1.4rem; font-weight: 900; color: #fff; letter-spacing: -0.5px;">${name}</h3>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">SELECT VARIANT FOR STOCK ENTRY</div>
            </div>
            <button onclick="this.closest('#po-variant-picker-overlay').remove()" style="background: rgba(255,255,255,0.05); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">✕</button>
        </div>
        <div style="display: flex; flex-direction: column; gap: 12px;">
            ${variants.map(v => `
                <div class="variant-item-pick-po" onclick="window.confirmPOVariant('${v.docId}')" 
                    style="padding: 18px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 16px; cursor: pointer; transition: all 0.2s; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 40px; height: 40px; border-radius: 10px; overflow: hidden; background: #000; border: 1px solid rgba(255,255,255,0.1);">
                            <img src="${v.image || '/logo.png'}" style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div>
                            <div style="font-weight: 800; color: #38bdf8; font-size: 1rem;">${v.size || 'Standard'} ${v.color ? ` / ${v.color}` : ''}</div>
                            <div style="font-size: 0.7rem; color: #64748b; margin-top: 4px;">SKU: ${v.sku || '-'}</div>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: 900; color: #fff; font-size: 1.1rem;">LKR ${(v.price || 0).toLocaleString()}</div>
                        <div style="font-size: 0.7rem; color: ${(v.stock || 0) < 5 ? '#ef4444' : '#10b981'}; font-weight: 800; margin-top: 4px;">STOCK: ${v.stock || 0}</div>
                    </div>
                </div>
            `).join('')}
        </div>
        <style>
            .variant-item-pick-po:hover {
                background: rgba(56, 189, 248, 0.1) !important;
                border-color: #38bdf8 !important;
                transform: translateX(5px);
            }
        </style>
    `;
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
};

window.confirmPOVariant = (docId) => {
    document.getElementById('po-variant-picker-overlay')?.remove();
    window.selectPOProduct(docId);
};

window.searchPOProducts = function(query) {
    const resultsContainer = document.getElementById('po-search-results');
    const supplierSelect = document.getElementById('po-supplier-id');
    const supplierId = supplierSelect?.value;
    const supplierName = supplierSelect?.options[supplierSelect.selectedIndex]?.text;
    
    window.poSelectedIndex = -1;
    
    if (!query || query.length < 2) {
        if(resultsContainer) resultsContainer.style.display = 'none';
        return;
    }
    
    const invoices = window.allSupplierInvoices || [];
    const supplierItemsNames = new Set();
    if (supplierId && supplierId !== "") {
        invoices.forEach(inv => {
            if (inv.supplierId === supplierId || inv.supplierName === supplierName) {
                (inv.items || []).forEach(item => {
                    if (item.name) supplierItemsNames.add(item.name.toLowerCase().trim());
                });
            }
        });
    }

    const products = window.allProducts || [];
    const filtered = products.filter(p => {
        if (!p.name) return false;
        const q = query.toLowerCase();
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return p.name.toLowerCase().includes(q) || 
               window.matchProductSku(p.sku, q) ||
               matchesVariantSku;
    });

    const grouped = {};
    filtered.forEach(p => {
        const key = p.name.trim().toLowerCase();
        if (!grouped[key]) grouped[key] = { ...p, variantCount: 0, variants: [] };
        grouped[key].variants.push(p);
        grouped[key].variantCount++;
    });

    const results = Object.values(grouped);
    results.sort((a, b) => {
        const aHas = supplierItemsNames.has(a.name.toLowerCase().trim()) ? 1 : 0;
        const bHas = supplierItemsNames.has(b.name.toLowerCase().trim()) ? 1 : 0;
        if (aHas !== bHas) return bHas - aHas;
        return a.name.localeCompare(b.name);
    });
    
    const finalResults = results.slice(0, 15);
    console.log(`PO Search for "${query}": found ${finalResults.length} results`);

    if (finalResults.length > 0) {
        resultsContainer.innerHTML = finalResults.map(p => {
            const isFromSupplier = supplierItemsNames.has(p.name.toLowerCase().trim());
            return `
                <div class="result-item po-search-item" onclick="window.handlePOSelection('${p.name.replace(/'/g, "\\'")}', '${p.docId}')" style="padding: 12px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05); color: white; display: flex; justify-content: space-between; align-items: center; border-left: 4px solid transparent; transition: all 0.2s;">
                    <div>
                        <div style="font-weight: 800;">${p.name}</div>
                        <div style="font-size: 0.85rem; color: #38bdf8; margin-top: 4px;">
                            ${p.variantCount > 1 ? `<span style="color: #fbbf24; font-weight: 900;">${p.variantCount} VARIANTS AVAILABLE</span>` : `<span style="color: #10b981; font-weight: 900; background: rgba(16, 185, 129, 0.1); padding: 2px 6px; border-radius: 4px;">Stock: ${p.stock || 0}</span> | <span style="color: #fff; font-weight: 900; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px;">LKR ${p.price || 0}</span>`} 
                        </div>
                    </div>
                    ${isFromSupplier ? `
                        <span style="font-size: 0.6rem; background: #10b98133; color: #10b981; padding: 4px 8px; border-radius: 6px; font-weight: 900; letter-spacing: 0.5px;">YOUR BRAND</span>
                    ` : `
                    `}
                </div>
            `;
        }).join('');
        resultsContainer.style.display = 'block';

        const items = resultsContainer.querySelectorAll('.po-search-item');
        items.forEach((item, idx) => {
            item.onmouseover = () => {
                window.poSelectedIndex = idx;
                window.highlightPOSearchItem(items);
            };
            item.onmouseout = () => {
                if (window.poSelectedIndex !== idx) {
                    item.style.background = 'transparent';
                    item.style.borderLeft = '4px solid transparent';
                }
            };
        });
    } else {
        resultsContainer.innerHTML = '<div style="padding: 20px; text-align: center; color: #64748b; font-size: 0.8rem;">No matching products found.</div>';
        resultsContainer.style.display = 'block';
    }

    const searchInput = document.getElementById('po-product-search');
    if (searchInput) {
        searchInput.onkeydown = (e) => {
            const items = resultsContainer.querySelectorAll('.po-search-item');
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (items.length > 0) {
                    window.poSelectedIndex = (window.poSelectedIndex + 1) % items.length;
                    window.highlightPOSearchItem(items);
                }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (items.length > 0) {
                    window.poSelectedIndex = (window.poSelectedIndex - 1 + items.length) % items.length;
                    window.highlightPOSearchItem(items);
                }
            } else if (e.key === 'Enter') {
                if (window.poSelectedIndex >= 0 && window.poSelectedIndex < items.length) {
                    e.preventDefault();
                    items[window.poSelectedIndex].click();
                } else if (items.length > 0) {
                    e.preventDefault();
                    items[0].click();
                }
            }
        };
    }
};

window.selectPOProduct = async function(docId) {
    const products = window.allProducts || [];
    const product = products.find(p => p.docId === docId);
    if (!product) return;
    
    window.poSelectedIndex = -1;
    window.selectedPOProduct = product;
    const displayName = product.name + (product.size ? ` (${product.size})` : '') + (product.color ? ` (${product.color})` : '');
    document.getElementById('po-product-search').value = displayName;
    document.getElementById('po-search-results').style.display = 'none';
    document.getElementById('po-item-price').value = product.cost || 0;
    document.getElementById('po-item-retail').value = product.price || 0;
    
    // Set editable new fields defaulting to current pricing
    document.getElementById('po-item-new-buying').value = product.cost || 0;
    document.getElementById('po-item-new-retail').value = product.price || 0;
    
    // Show Price Comparison
    const comparisonBox = document.getElementById('po-price-comparison-box');
    const priceList = document.getElementById('po-price-list');
    if (!comparisonBox || !priceList) return;
    
    comparisonBox.style.display = 'block';
    window.checkPOPriceMatch();
    
    // Get historical prices from other suppliers (using supplier invoices)
    const invoices = window.allSupplierInvoices || [];
    const history = [];
    
    invoices.forEach(inv => {
        const item = inv.items.find(i => (i.docId === docId || i.id === docId));
        if (item) {
            history.push({
                supplierName: inv.supplierName,
                cost: parseFloat(item.buyingPrice || item.netCost || 0),
                date: inv.date
            });
        }
    });
    
    // Consolidate best price per supplier
    const bestPrices = {};
    history.forEach(h => {
        if (!bestPrices[h.supplierName] || h.cost < bestPrices[h.supplierName]) {
            bestPrices[h.supplierName] = h.cost;
        }
    });

    const comparisonItems = Object.entries(bestPrices).map(([name, price]) => `
        <div onclick="document.getElementById('po-item-new-buying').value = ${price}; window.checkPOPriceMatch();" style="display: flex; justify-content: space-between; padding: 8px 12px; background: rgba(0,0,0,0.2); border-radius: 8px; cursor: pointer;">
            <span style="font-size: 0.8rem; color: #94a3b8;">${name}</span>
            <span style="font-weight: 800; color: ${price <= (product.cost || 0) ? '#10b981' : '#f59e0b'}">LKR ${price.toFixed(2)}</span>
        </div>
    `);
    
    if (comparisonItems.length > 0) {
        priceList.innerHTML = comparisonItems.join('');
    } else {
        priceList.innerHTML = '<div style="color: #64748b; font-size: 0.8rem; text-align: center;">No history found</div>';
    }
};

// Checks if entered prices in Procure Terminal match existing records
window.checkPOPriceMatch = () => {
    const badge = document.getElementById('po-price-match-badge');
    const buyingInput = document.getElementById('po-item-new-buying');
    const retailInput = document.getElementById('po-item-new-retail');
    if (!badge || !buyingInput || !retailInput) return;

    const refBuying = parseFloat(document.getElementById('po-item-price').value) || 0;
    const refRetail = parseFloat(document.getElementById('po-item-retail').value) || 0;
    const newBuying = parseFloat(buyingInput.value) || 0;
    const newRetail = parseFloat(retailInput.value) || 0;

    const buyingChanged = Math.abs(newBuying - refBuying) >= 0.01;
    const retailChanged = Math.abs(newRetail - refRetail) >= 0.01;

    badge.style.display = 'block';
    if (buyingChanged || retailChanged) {
        badge.innerText = '⚠️ NEW PRICE — New Variant Batch will be created';
        badge.style.background = 'rgba(251,191,36,0.15)';
        badge.style.color = '#fbbf24';
        badge.style.borderColor = 'rgba(251,191,36,0.4)';
        buyingInput.style.borderColor = buyingChanged ? 'rgba(251,191,36,0.6)' : '';
        retailInput.style.borderColor = retailChanged ? 'rgba(251,191,36,0.6)' : '';
    } else {
        badge.innerText = '✓ SAME PRICE — Stock will be added to existing';
        badge.style.background = 'rgba(16,185,129,0.15)';
        badge.style.color = '#10b981';
        badge.style.borderColor = 'rgba(16,185,129,0.3)';
        buyingInput.style.borderColor = '';
        retailInput.style.borderColor = '';
    }
};

window.addItemToPO = function() {
    if (!window.selectedPOProduct) {
        alert("Please select a product first.");
        return;
    }
    
    const price = parseFloat(document.getElementById('po-item-new-buying').value);
    const retail = parseFloat(document.getElementById('po-item-new-retail').value);
    const qty = parseFloat(document.getElementById('po-item-qty').value);
    
    if (isNaN(price) || price < 0 || isNaN(qty) || qty <= 0) {
        alert("Enter valid price and quantity.");
        return;
    }
    
    if (window.poSelectedIndex !== undefined && window.poSelectedIndex > -1) {
        // Updating existing selected item from list
        const item = window.currentPOItems[window.poSelectedIndex];
        if (item) {
            item.price = price;
            item.retail = retail;
            item.qty = qty;
            item.total = price * qty;
        }
        window.poSelectedIndex = -1;
    } else {
        const existing = window.currentPOItems.find(item => 
            item.id === window.selectedPOProduct.docId && 
            Math.abs(item.price - price) < 0.01 && 
            Math.abs(item.retail - retail) < 0.01
        );
        if (existing) {
            existing.qty += qty;
            existing.total = existing.qty * existing.price;
        } else {
            window.currentPOItems.push({
                id: window.selectedPOProduct.docId,
                name: window.selectedPOProduct.name,
                price: price,
                retail: retail,
                qty: qty,
                total: price * qty,
                baseMetadata: { ...window.selectedPOProduct } // Store metadata for new variant creation
            });
        }
    }
    
    // Clear item inputs but NOT supplier
    window.selectedPOProduct = null;
    document.getElementById('po-product-search').value = '';
    document.getElementById('po-item-price').value = '0';
    document.getElementById('po-item-retail').value = '0';
    document.getElementById('po-item-new-buying').value = '0';
    document.getElementById('po-item-new-retail').value = '0';
    document.getElementById('po-item-qty').value = '1';
    
    const badge = document.getElementById('po-price-match-badge');
    if (badge) badge.style.display = 'none';
    
    document.getElementById('po-price-comparison-box').style.display = 'none';
    
    window.renderPOItems();
};

window.renderPOItems = function() {
    const body = document.getElementById('po-items-body');
    const grandTotalEl = document.getElementById('po-grand-total');
    const totalSkusEl = document.getElementById('po-total-skus');
    
    if (!body) return;
    
    let total = 0;
    body.innerHTML = window.currentPOItems.map((item, idx) => {
        total += item.total;
        return `
            <tr onclick="window.editPOItem(${idx})" style="border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.02)'" onmouseout="this.style.background='transparent'">
                <td style="padding: 15px 10px; font-weight: 600;">${item.name}</td>
                <td style="text-align: right; padding: 15px 10px; color: #94a3b8;">${item.price.toFixed(2)}</td>
                <td style="text-align: center; padding: 15px 10px; font-weight: 800; color: #38bdf8;">${item.qty}</td>
                <td style="text-align: right; padding: 15px 10px; font-weight: 800; color: #10b981;">${item.total.toFixed(2)}</td>
                <td style="text-align: center; padding: 15px 10px;" onclick="event.stopPropagation()">
                    <button onclick="window.removeItemFromPO(${idx})" style="background: rgba(220, 38, 38, 0.1); border: 1px solid rgba(220, 38, 38, 0.2); color: #ef4444; font-size: 1rem; cursor: pointer; border-radius: 6px; width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; transition: all 0.2s;" onmouseover="this.style.background='rgba(220, 38, 38, 0.2)'" onmouseout="this.style.background='rgba(220, 38, 38, 0.1)'">🗑️</button>
                </td>
            </tr>
        `;
    }).join('');
    
    if (window.currentPOItems.length === 0) {
        body.innerHTML = '<tr><td colspan="5" style="text-align: center; color: #64748b; padding: 3rem; font-weight: 600;">No items added to this order.</td></tr>';
    }
    
    grandTotalEl.innerText = total.toFixed(2);
    if (totalSkusEl) totalSkusEl.innerText = window.currentPOItems.length;
};

window.editPOItem = function(index) {
    const item = window.currentPOItems[index];
    if (!item) return;
    
    window.poSelectedIndex = index;
    window.selectedPOProduct = item.baseMetadata || { docId: item.id, name: item.name };
    
    document.getElementById('po-product-search').value = item.name;
    document.getElementById('po-item-price').value = item.baseMetadata?.cost || item.price;
    document.getElementById('po-item-retail').value = item.baseMetadata?.price || item.retail;
    
    document.getElementById('po-item-new-buying').value = item.price;
    document.getElementById('po-item-new-retail').value = item.retail;
    document.getElementById('po-item-qty').value = item.qty;
    
    const comparisonBox = document.getElementById('po-price-comparison-box');
    if (comparisonBox) {
        comparisonBox.style.display = 'block';
        window.checkPOPriceMatch();
    }
};

window.removeItemFromPO = function(index) {
    window.currentPOItems.splice(index, 1);
    window.renderPOItems();
};

window.clearPOForm = function() {
    if (confirm("Reset current order?")) {
        window.currentPOItems = [];
        window.selectedPOProduct = null;
        window.poSelectedIndex = -1;
        document.getElementById('po-product-search').value = '';
        document.getElementById('po-item-price').value = '0';
        document.getElementById('po-item-retail').value = '0';
        document.getElementById('po-item-new-buying').value = '0';
        document.getElementById('po-item-new-retail').value = '0';
        document.getElementById('po-item-qty').value = '1';
        if(document.getElementById('po-invoice-ref')) document.getElementById('po-invoice-ref').value = '';
        if(document.getElementById('po-cash-paid')) document.getElementById('po-cash-paid').value = '0';
        
        const badge = document.getElementById('po-price-match-badge');
        if (badge) badge.style.display = 'none';
        
        document.getElementById('po-price-comparison-box').style.display = 'none';
        window.renderPOItems();
    }
};

window.savePurchaseOrder = async function() {
    if (window.currentPOItems.length === 0) {
        alert("Add some items to the order first.");
        return;
    }
    
    const supplierId = document.getElementById('po-supplier-id').value;
    const supplier = (window.allSuppliers || []).find(s => s.docId === supplierId);
    if (!supplier) return alert("Invalid Supplier (" + supplierId + ")");
    
    const invoiceRef = document.getElementById('po-invoice-ref')?.value || '';
    const postingDate = document.getElementById('po-posting-date')?.value || new Date().toISOString().split('T')[0];
    const settlementType = document.getElementById('po-settlement-type')?.value || 'cash';
    const cashPaid = parseFloat(document.getElementById('po-cash-paid')?.value) || 0;
    
    const totalAmount = window.currentPOItems.reduce((acc, item) => acc + item.total, 0);
    
    if (!confirm(`Finalize this order from ${supplier.name} for LKR ${totalAmount.toFixed(2)}? Stock will be updated.`)) return;
    
    try {
        const batch = writeBatch(db); // Use imported writeBatch
        
        // 1. Create Supplier Invoice record (uses supplierInvoices collection)
        const invRef = doc(collection(db, "supplierInvoices"));
        batch.set(invRef, {
            supplierId: supplierId,
            supplierName: supplier.name,
            invoiceNo: invoiceRef || `PO-${Date.now()}`,
            date: postingDate,
            totalAmount: totalAmount,
            grandTotal: totalAmount,
            paidAmount: totalAmount,
            cashPaid: totalAmount,
            paid: totalAmount,
            settlementType: settlementType,
            storeId: window.getStoreId() || 'master',
            items: window.currentPOItems.map(item => ({
                id: item.id || 'N/A',
                docId: item.id || 'N/A',
                name: item.name,
                buyingPrice: item.price,
                netCost: item.price,
                buying: item.price,
                qty: item.qty
            })),
            status: 'Paid',
            paymentStatus: 'Paid',
            timestamp: serverTimestamp()
        });
        
        // 2. Update Product Stocks (Auto-Variant Logic)
        for (const item of window.currentPOItems) {
            // Find existing product by ID (since item.id holds the docId) or name fallback
            let existingProduct = (window.allProducts || []).find(p => p.docId === item.id);
            if (!existingProduct) {
                existingProduct = (window.allProducts || []).find(p => 
                    p.name.trim().toLowerCase() === item.name.trim().toLowerCase()
                );
            }

            if (existingProduct) {
                // UPDATE EXISTING VARIANT WITH VARIANT-AWARE LOGIC
                const pRef = doc(db, "products", existingProduct.docId);
                let variants = [...(existingProduct.variants || [])];
                const incomingBuyingPrice = Number(item.price);
                const incomingRetailPrice = Number(item.retail);

                // If variants is empty and the product has existing stock, convert the base stock to a variant first!
                if (variants.length === 0 && (parseFloat(existingProduct.stock) || 0) > 0) {
                    variants.push({
                        variantId: 'base-' + existingProduct.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                        supplierId: existingProduct.supplierId || supplierId,
                        supplierName: existingProduct.supplierName || supplier.name,
                        variantLabel: existingProduct.size || existingProduct.color || 'Existing Stock',
                        buyingPrice: parseFloat(existingProduct.cost) || 0,
                        cost: parseFloat(existingProduct.cost) || 0,
                        sellingPrice: parseFloat(existingProduct.price) || 0,
                        wholesalePrice: parseFloat(existingProduct.wholesalePrice) || 0,
                        loyaltyPrice: parseFloat(existingProduct.loyaltyPrice) || 0,
                        stock: parseFloat(existingProduct.stock) || 0,
                        sku: existingProduct.sku || '',
                        expiry: existingProduct.expiryDate || '',
                        warranty: existingProduct.warranty || '',
                        addedDate: existingProduct.addedDate || new Date().toISOString(),
                        lastUpdated: Date.now()
                    });
                }

                const existingVariantIndex = variants.findIndex(v =>
                    v.supplierId === supplierId &&
                    Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                    Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                );

                if (existingVariantIndex !== -1) {
                    const oldStock = parseFloat(variants[existingVariantIndex].stock) || 0;
                    const oldCost = parseFloat(variants[existingVariantIndex].buyingPrice || variants[existingVariantIndex].cost) || 0;
                    const newTotalStock = oldStock + item.qty;
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (item.qty * incomingBuyingPrice)) / newTotalStock
                        : incomingBuyingPrice;
                    variants[existingVariantIndex].stock = newTotalStock;
                    variants[existingVariantIndex].buyingPrice = parseFloat(wacCost.toFixed(4));
                    variants[existingVariantIndex].cost = parseFloat(wacCost.toFixed(4));
                    variants[existingVariantIndex].sellingPrice = incomingRetailPrice;
                    variants[existingVariantIndex].lastUpdated = Date.now();
                } else {
                    variants.push({
                        variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                        supplierId: supplierId,
                        supplierName: supplier.name,
                        variantLabel: '',
                        buyingPrice: incomingBuyingPrice,
                        cost: incomingBuyingPrice,
                        sellingPrice: incomingRetailPrice,
                        wholesalePrice: incomingRetailPrice,
                        loyaltyPrice: incomingRetailPrice,
                        stock: item.qty,
                        sku: existingProduct.sku || '',
                        expiry: '',
                        warranty: '',
                        addedDate: new Date().toISOString(),
                        lastUpdated: Date.now()
                    });
                }

                const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                const wacBaseCost = totalCalculatedStock > 0
                    ? variants.reduce((sum, v) => sum + ((parseFloat(v.cost || v.buyingPrice) || 0) * (parseFloat(v.stock) || 0)), 0) / totalCalculatedStock
                    : incomingBuyingPrice;

                batch.update(pRef, {
                    variants: variants,
                    stock: totalCalculatedStock,
                    totalStock: totalCalculatedStock,
                    cost: parseFloat(wacBaseCost.toFixed(4)),
                    price: incomingRetailPrice,
                    lastStockUpdate: serverTimestamp()
                });
            } else {
                // CREATE NEW VARIANT
                const newProductRef = doc(collection(db, "products"));
                const meta = item.baseMetadata || {};
                
                // Construct new SKU for variant if base exists
                const baseSku = meta.sku || `MEC-${Date.now()}`;
                const variantSku = `${baseSku}-V${Math.floor(item.retail)}`;

                batch.set(newProductRef, {
                    name: item.name,
                    sku: variantSku,
                    category: meta.category || 'General',
                    mode: meta.mode || 'Inventory',
                    image: meta.image || '/logo.png',
                    barcode: meta.barcode || '',
                    unit: meta.unit || 'pcs',
                    cost: item.price,
                    price: item.retail,
                    stock: item.qty,
                    wStock: 0,
                    totalStock: item.qty,
                    storeId: window.getStoreId(),
                    timestamp: serverTimestamp(),
                    salesToday: 0,
                    wholesalePrice: meta.wholesalePrice || item.retail,
                    loyaltyPrice: meta.loyaltyPrice || item.retail
                });
            }
        }
        
        // 3. Log as Expense (Inventory Purchase)
        const expRef = doc(collection(db, "expenses"));
        batch.set(expRef, {
            title: `Inventory Purchase: ${supplier.name}`,
            amount: totalAmount,
            date: postingDate,
            category: 'Inventory',
            timestamp: serverTimestamp()
        });

        await batch.commit();
        window.showToast("🚀 Stock Inbound Successful!", "success");
        window.currentPOItems = [];
        window.renderPOItems();
        window.showTab('supplier-invoices');
        if (window.showSubTab) window.showSubTab('supplier-invoices', 'list');
        
    } catch (e) {
        console.error("PO Error:", e);
        alert("Error saving order: " + e.message);
    }
};



// --- System Update & Cache Clearing (Renamed to prevent collisions) ---
window.systemUpgradeInternal = async () => {
    window.showToast("🔄 Fetching latest system updates...", "info");
    
    const btn = document.getElementById('system-upgrade-btn');
    if (btn) {
        btn.classList.add('updating');
        const icon = btn.querySelector('.icon');
        if (icon) icon.style.animationPlayState = 'running';
    }

    try {
        if ('caches' in window) {
            try {
                const keys = await caches.keys();
                await Promise.all(keys.map(k => caches.delete(k)));
                console.log("Caches cleared success.");
            } catch (cacheErr) {
                console.warn("Failed to clear caches:", cacheErr);
            }
        }
        
        if ('serviceWorker' in navigator) {
            try {
                const registrations = await navigator.serviceWorker.getRegistrations();
                for (const registration of registrations) {
                   await registration.unregister();
                }
                console.log("SW Unregistered.");
            } catch (swErr) {
                console.warn("Failed to unregister SW:", swErr);
            }
        }

        if (window.chrome && window.chrome.webview) {
            try {
                window.chrome.webview.postMessage({ type: 'checkExeUpdates' });
            } catch (exeErr) {
                console.warn("Failed to check WebView2 exe updates:", exeErr);
            }
        }
        if (window.electronAPI && window.electronAPI.checkExeUpdates) {
            try {
                window.electronAPI.checkExeUpdates();
            } catch (exeErr) {
                console.warn("Failed to check exe updates:", exeErr);
            }
        }

        window.showToast("✅ System updated. Refreshing...", "success");
        setTimeout(() => {
            // Add a cache-busting timestamp and reload
            const url = new URL(window.location.href);
            url.searchParams.set('v', Date.now());
            window.location.href = url.href;
        }, 1500);

    } catch (err) {
        console.error("Update fail:", err);
        window.showToast("Update failed. Please check connection.", "error");
        if (btn) {
            btn.classList.remove('updating');
            const icon = btn.querySelector('.icon');
            if (icon) icon.style.animationPlayState = 'paused';
        }
    }
};

// --- Modern Graphic Invoice & Sharing Logic ---
window.openModernInvoice = (orderId) => {
    // Priority 1: Check if this is the immediate POS sale we just made
    let order = null;
    if (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId)) {
        order = window.lastSavedPOSOrder;
    }
    
    // Priority 2: If not found, look in allOrders (historical)
    if (!order) {
        order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId);
    }
    
    // Priority 3: Repair job fallback
    if (!order && orderId) {
        order = (window.allOrders || []).find(o => o.repairJobId === orderId);
    }

    if (!order) {
        window.showToast("Invoice data not found. Please wait 1-2 seconds and try again.", "info");
        return;
    }
    window._currentViewingInvoiceId = order.docId || order.orderId;

    console.log("Generating Premium Graphic Invoice for:", orderId);
    
    // Populate Modal Fields
    const modal = document.getElementById('modern-invoice-modal');
    if (!modal) return;

    // Store Info
    document.getElementById('mi-store-name').innerText = window.storeInfo?.name || 'MEC Book Shop';
    document.getElementById('mi-store-tagline').innerText = window.storeInfo?.tagline || 'Premium Book Shop & Stationery Hub';
    document.getElementById('mi-auth-store').innerText = window.storeInfo?.name || 'MEC BOOK SHOP';
    
    // Customer Info
    document.getElementById('mi-cust-name').innerText = order.userName || 'Walk-in Customer';
    document.getElementById('mi-cust-phone').innerText = order.phone || order.customerPhone || 'N/A';
    
    // Bill Info
    let displayId = order.orderId || order.docId;
    if (displayId && !displayId.startsWith('#')) displayId = '#' + displayId;
    document.getElementById('mi-inv-no').innerText = displayId;

    document.getElementById('mi-rep').innerText = order.staffName || 'Admin';
    document.getElementById('mi-date').innerText = order.date || new Date().toLocaleDateString();
    
    // Table Body
    const tbody = document.getElementById('mi-table-body');
    let itemsMarkup = '';

    // If it's a repair, show a summary row first
    if (order.type === 'RepairBill') {
        itemsMarkup += `
            <tr style="background: rgba(0, 32, 96, 0.03); border-bottom: 2px solid #002060;">
                <td colspan="4" style="padding: 15px 20px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Repair Job ID</div>
                            <div style="font-weight: 900; color: #002060; font-size: 1.1rem;">${order.repairJobId || 'N/A'}</div>
                        </div>
                        <div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Device / Item</div>
                            <div style="font-weight: 700; color: #334155;">${(order.itemDescription || 'Electronic Item').toUpperCase()}</div>
                        </div>
                        <div style="grid-column: span 2;">
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Reported Problem / Service</div>
                            <div style="font-weight: 600; color: #475569;">${order.problem || 'General Technical Service'}</div>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }

    let itemDiscountsSum = 0;
    let originalSubtotal = 0;

    itemsMarkup += (order.items || []).map(item => {
        const itemDiscount = parseFloat(item.discount || 0);
        const itemPrice = parseFloat(item.price || 0);
        const qty = parseFloat(item.quantity || item.qty || 1);
        const lineTotal = (itemPrice - itemDiscount) * qty;
        
        itemDiscountsSum += (itemDiscount * qty);
        originalSubtotal += (itemPrice * qty);
        
        return `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 8px 12px; font-weight: 700; color: #333;">${item.name}</td>
                <td style="padding: 8px 12px; text-align: center; color: #555;">${qty}</td>
                <td style="padding: 8px 12px; text-align: center; color: #555;">Rs. ${itemPrice.toLocaleString()}</td>
                <td style="padding: 8px 12px; text-align: center; color: #e30030; font-weight: 600;">${itemDiscount > 0 ? 'Rs. ' + itemDiscount.toLocaleString() : '-'}</td>
                <td style="padding: 8px 12px; text-align: right; font-weight: 800; color: #000;">Rs. ${lineTotal.toLocaleString()}</td>
            </tr>
        `;
    }).join('');

    tbody.innerHTML = itemsMarkup;

    // Totals Breakdown
    const billDiscount = parseFloat(order.discount || 0);
    const totalDiscount = itemDiscountsSum + billDiscount;
    
    document.getElementById('mi-subtotal').innerText = `Rs. ${originalSubtotal.toLocaleString()}`;
    document.getElementById('mi-discount').innerText = `Rs. ${totalDiscount.toLocaleString()}`;
    
    // Summary logic for Modern Invoice
    const miSummaryBody = document.getElementById('mi-summary-extra');
    if (miSummaryBody) {
        let extraHtml = '';
        
        // Show Settled Outstanding if any
        if (order.outstandingIncluded && order.outstandingAmount > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #b91c1c; font-weight: 600;">Settled Debt (Debt Paid)</td><td style="font-weight: 800; color: #b91c1c;">Rs. ${order.outstandingAmount.toLocaleString()}</td></tr>`;
        }
        
        // Show Redeemed Points (Discount)
        const redeemed = order.redeemedAmount || 0;
        if (redeemed > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #0369a1; font-weight: 600;">Points Redeemed (Used)</td><td style="font-weight: 800; color: #0369a1;">- Rs. ${redeemed.toLocaleString()}</td></tr>`;
        }

        // Show Amount Paid (Tendered)
        const tendered = order.tenderedAmount || (order.total + (order.cashBalance || 0));
        if (tendered > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #555; border-top: 1px dashed #ddd;">Cash Paid (Tendered)</td><td style="font-weight: 800; color: #222; border-top: 1px dashed #ddd;">Rs. ${tendered.toLocaleString()}</td></tr>`;
        }

        // Show Cash Balance (Change Given)
        const cashBal = order.cashBalance || 0;
        if (cashBal > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #16a34a; font-weight: 600;">Cash Balance (Change)</td><td style="font-weight: 800; color: #16a34a;">Rs. ${cashBal.toLocaleString()}</td></tr>`;
        }

        // Show Repair Advance if any
        if (order.advancePaid > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #10b981; font-weight: 600;">Advance Payment (-)</td><td style="font-weight: 800; color: #10b981;">Rs. ${order.advancePaid.toLocaleString()}</td></tr>`;
        }

        // Show Points Added from Change
        const pointsAdded = order.isPOS ? (order.changeAmount || 0) : 0;
        if (pointsAdded > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #0ea5e9; font-weight: 600;">Loyalty Points Saved</td><td style="font-weight: 800; color: #0ea5e9;">+ 💎 ${pointsAdded.toLocaleString()}</td></tr>`;
        }

        miSummaryBody.innerHTML = extraHtml;
    }

    document.getElementById('mi-grandtotal').innerText = `Rs. ${order.total.toLocaleString()}`;
    const payMethod = order.paymentMethod || 'Cash';
    const chequeSuffix = (payMethod.toLowerCase() === 'cheque' && order.chequeDate) ? ` (Due: ${order.chequeDate})` : '';
    document.getElementById('mi-paymethod').innerText = payMethod + chequeSuffix;

    // Toggle PAID stamp
    const paidStamp = document.getElementById('mi-paid-stamp');
    if (paidStamp) {
        const isCredit = (
            payMethod.toLowerCase().includes('credit') || 
            payMethod.toLowerCase().includes('unpaid') || 
            payMethod.toLowerCase().includes('debt') || 
            payMethod.toLowerCase().includes('due')
        ) && !payMethod.toLowerCase().includes('settled');
        const isVoid = (order.status || '').toLowerCase() === 'void';
        const isPaid = !isCredit && !isVoid;
        paidStamp.style.display = isPaid ? 'flex' : 'none';
    }

    modal.style.display = 'flex';
};

window.downloadModernInvoice = async (format) => {
    const area = document.getElementById('modern-invoice-capture-area');
    const orderId = document.getElementById('mi-inv-no').innerText;

    if (!area) return;
    
    const btn = event?.target || null;
    const originalText = btn ? btn.innerText : "";
    if (btn) {
        btn.disabled = true;
        btn.innerText = "Processing...";
    }

    window.showToast(`📸 Generating ${format}... Please wait.`, "info");

    try {
        if (format === 'JPG') {
            const canvas = await html2canvas(area, { 
                scale: 2, // Optimized from 3 to 2 for better speed
                useCORS: true, 
                backgroundColor: '#ffffff',
                logging: false
            });
            const link = document.createElement('a');
            link.download = `MEC_INVOICE_${orderId}.jpg`;
            link.href = canvas.toDataURL('image/jpeg', 0.9);
            link.click();
            window.showToast("✅ JPG downloaded!", "success");
        } else {
            // PDF
            const opt = {
                margin:       0,
                filename:     `MEC_INVOICE_${orderId}.pdf`,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true }, // Optimized scale
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            if (window.html2pdf) {
                await window.html2pdf().set(opt).from(area).save();
                window.showToast("✅ PDF generated!", "success");
            }
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error generating document.", "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = originalText;
        }
    }
};

window.shareOnWhatsApp = () => {
    const order = window.currentPendingPOSSale || window.lastSavedPOSOrder;
    if (!order) return window.showToast("No active order to share.", "warning");

    let phone = order.customerPhone || "";
    if (phone.startsWith('0')) phone = '94' + phone.substring(1);
    phone = phone.replace(/\D/g, '');

    if (!phone) {
        window.showToast("Customer phone required for WhatsApp.", "warning");
        return;
    }

    const itemLines = (order.items || []).map(i => `• ${i.name} (x${i.quantity || 1}) - LKR ${((i.price || 0) * (i.quantity || 1)).toLocaleString()}`).join('\n');
    
    const message = `*INVOICE: #${order.orderId}*\n*MEC BOOK SHOP*\n----------------------------------\n*Customer:* ${order.userName || 'Valued Customer'}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${itemLines}\n----------------------------------\n*TOTAL: LKR ${order.total.toLocaleString()}*\n*Method:* ${order.paymentMethod || 'Cash'}\n\nThank you for shopping @ MEC! 📚✨`;

    const encoded = encodeURIComponent(message);
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    // Use direct web URL for desktop to bypass the "Open App" landing page
    const url = isMobile 
        ? `https://wa.me/${phone}?text=${encoded}`
        : `https://web.whatsapp.com/send?phone=${phone}&text=${encoded}`;
    
    if (window.electronAPI && window.electronAPI.openExternal) {
        // For Electron desktop app, wa.me is better as it triggers the system protocol
        const electronUrl = `https://wa.me/${phone}?text=${encoded}`;
        window.electronAPI.openExternal(electronUrl);
    } else {
        window.open(url, '_blank');
    }
    
    window.showToast("📲 WhatsApp invoice dispatched!", "success");
};

window.showSettingsSubTab = (tabId) => {
    document.querySelectorAll('.settings-view').forEach(view => {
        view.style.setProperty('display', 'none', 'important');
    });
    document.querySelectorAll('.settings-nav-btn').forEach(btn => btn.classList.remove('active'));
    
    const target = document.getElementById(`set-sub-${tabId}`);
    if (target) {
        target.style.setProperty('display', 'block', 'important');
    }
    
    const targetBtn = document.getElementById(`btn-set-${tabId}`);
    if (targetBtn) targetBtn.classList.add('active');

    // Auto-refresh printers when hardware tab is opened
    if (tabId === 'hardware') {
        window.refreshSystemPrinters();
    }
};

window.refreshSystemPrinters = async () => {
    const printerSelect = document.getElementById('set-printer-name');
    if (!printerSelect) return;
    
    const currentVal = printerSelect.value || (window.systemConfig?.printerName || '');
    printerSelect.innerHTML = '<option value="">Searching...</option>';
    
    try {
        if (!window.electron || !window.electron.getPrinters) {
            printerSelect.innerHTML = '<option value="">(Browser Mode)</option>';
            if (currentVal) {
                const opt = document.createElement('option');
                opt.value = currentVal;
                opt.innerText = `${currentVal} (Manual)`;
                opt.selected = true;
                printerSelect.appendChild(opt);
            }
            return;
        }

        const printers = await window.electron.getPrinters();
        printerSelect.innerHTML = '';
        
        if (printers.length === 0) {
            printerSelect.innerHTML = '<option value="">No printers detected</option>';
        } else {
            printers.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.name;
                opt.innerText = `${p.displayName} ${p.isDefault ? '(Default)' : ''}`;
                if (p.name === currentVal) opt.selected = true;
                printerSelect.appendChild(opt);
            });
        }
        
        if (currentVal && !printers.find(p => p.name === currentVal)) {
            const opt = document.createElement('option');
            opt.value = currentVal;
            opt.innerText = `${currentVal} (Saved)`;
            opt.selected = true;
            printerSelect.appendChild(opt);
        }
    } catch (err) {
        console.error(err);
        printerSelect.innerHTML = '<option value="">Error!</option>';
    }
};

window.saveGlobalSettings = async () => {
    const storeLogoUrl = document.getElementById('set-store-logo-url')?.value.trim() || "";
    const config = {
        bizName: document.getElementById('set-biz-name').value,
        storeLogoUrl: storeLogoUrl,
        logoUrl: storeLogoUrl,
        currency: document.getElementById('set-currency').value,
        taxRate: parseFloat(document.getElementById('set-tax').value) || 0,
        wholesaleDiscount: parseFloat(document.getElementById('set-wholesale-discount').value) || 0,
        loyaltyDiscount: parseFloat(document.getElementById('set-loyalty-discount').value) || 0,
        loyaltyRate: parseFloat(document.getElementById('set-loyalty-rate')?.value) || 0,
        profitMargin: document.getElementById('set-profit-margin') ? parseFloat(document.getElementById('set-profit-margin').value) : 0,
        storeLatitude: parseFloat(document.getElementById('set-store-latitude')?.value) || 0,
        storeLongitude: parseFloat(document.getElementById('set-store-longitude')?.value) || 0,
        aiLanguage: document.getElementById('set-ai-language')?.value || "english",
        printerType: document.getElementById('set-printer-type').value,
        printerName: document.getElementById('set-printer-name').value,
        autoPrint: document.getElementById('set-auto-print').value,
        invTemplate: document.getElementById('set-inv-template').value,
        invAddress: document.getElementById('set-inv-address').value,
        invPhone: document.getElementById('set-inv-phone').value,
        invFooter: document.getElementById('set-inv-footer').value,
        showLogo: document.getElementById('set-show-logo').checked,
        modules: {
            mrp: document.getElementById('toggle-mrp')?.checked ?? true,
            hrm: document.getElementById('toggle-hrm')?.checked ?? true,
            web: document.getElementById('toggle-web')?.checked ?? true
        },
        favorites: Array.from(document.querySelectorAll('.favorite-checkbox:checked')).map(cb => cb.value),
        smsConfig: {
            apiBase: document.getElementById('set-sms-api-base')?.value.trim() || "",
            apiKey: document.getElementById('set-sms-api-key')?.value.trim() || "",
            userId: document.getElementById('set-sms-user-id')?.value.trim() || "",
            senderId: document.getElementById('set-sms-sender-id')?.value.trim() || ""
        },
        payhereConfig: {
            merchantId: document.getElementById('set-payhere-merchant-id')?.value.trim() || "",
            merchantSecret: document.getElementById('set-payhere-merchant-secret')?.value.trim() || "",
            mode: document.getElementById('set-payhere-mode')?.value || "sandbox"
        },
        dialogQrUrl: document.getElementById('set-dialog-qr-url')?.value.trim() || "",
        lastUpdated: serverTimestamp()
    };

    try {
        window.showToast("Saving system configuration...", "info");
        const storeId = window.getStoreId();
        await updateDoc(doc(db, 'config', storeId), config);
        try {
            await updateDoc(doc(db, 'stores', storeId), { logoUrl: storeLogoUrl, name: config.bizName });
        } catch(stErr) {}
        if (storeLogoUrl) localStorage.setItem('mecpos_store_logo', storeLogoUrl);
        window.showToast("✅ Settings Saved Successfully!", "success");
    } catch (err) {
        // If doc doesn't exist, try setDoc
        try {
            await setDoc(doc(db, 'config', window.getStoreId()), config);
            window.showToast("✅ Initial Settings Created!", "success");
        } catch (setErr) {
            console.error(setErr);
            window.showToast("Error saving settings!", "error");
        }
    }
};

window.loadSystemSettings = async () => {
    const storeId = window.getStoreId();
    
    // safe helper utilities for rendering
    const safeSetVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val !== undefined && val !== null ? val : "";
    };
    const safeSetChecked = (id, checked) => {
        const el = document.getElementById(id);
        if (el) el.checked = !!checked;
    };

    // --- Synchronously load from store-isolated local cache first for instant offline/errored rendering ---
    try {
        const storeCacheKey = `mecpos_system_config_${storeId}`;
        const cachedDataStr = localStorage.getItem(storeCacheKey) || localStorage.getItem('mecpos_system_config_cache');
        if (cachedDataStr) {
            const localData = JSON.parse(cachedDataStr);
            window.systemConfig = localData;
            const localFavs = localData.favorites || ['pos', 'orders', 'web-orders', 'reload'];
            window.renderFavoritesSidebar(localFavs);
            if (localData.modules) {
                window.applyModuleVisibility(localData.modules);
            }
            if (document.getElementById('set-biz-name')) {
                safeSetVal('set-biz-name', localData.bizName);
                safeSetVal('set-store-logo-url', localData.storeLogoUrl || localData.logoUrl || "");
                const localLogoPreview = document.getElementById('set-store-logo-preview');
                const defaultLogo = '/logo.png';
                if (localLogoPreview) localLogoPreview.src = localData.storeLogoUrl || localData.logoUrl || defaultLogo;
                safeSetVal('set-currency', localData.currency || "LKR");
                safeSetVal('set-tax', localData.taxRate || 0);
                safeSetVal('set-wholesale-discount', localData.wholesaleDiscount || 0);
                safeSetVal('set-loyalty-discount', localData.loyaltyDiscount || 0);
                safeSetVal('set-loyalty-rate', localData.loyaltyRate || 0);
                safeSetVal('set-profit-margin', localData.profitMargin !== undefined ? localData.profitMargin : 0);
                safeSetVal('set-store-latitude', localData.storeLatitude);
                safeSetVal('set-store-longitude', localData.storeLongitude);
                safeSetVal('set-ai-language', localData.aiLanguage || "english");
                safeSetVal('set-printer-type', localData.printerType || "thermal-80");
                const pSelect = document.getElementById('set-printer-name');
                if (pSelect) pSelect.value = localData.printerName || "";
                safeSetVal('set-inv-address', localData.invAddress);
                safeSetVal('set-inv-phone', localData.invPhone);
                safeSetVal('set-inv-footer', localData.invFooter);
                safeSetVal('set-auto-print', localData.autoPrint || "yes");
                safeSetChecked('set-show-logo', localData.showLogo !== false);
                const tplValue = localData.invTemplate || "classic";
                safeSetVal('set-inv-template', tplValue);
                if (window.selectInvoiceTemplate) window.selectInvoiceTemplate(tplValue, true);
                const smsConf = localData.smsConfig || {};
                safeSetVal('set-sms-api-base', smsConf.apiBase);
                safeSetVal('set-sms-api-key', smsConf.apiKey);
                safeSetVal('set-sms-user-id', smsConf.userId);
                safeSetVal('set-sms-sender-id', smsConf.senderId);
                const payhereConf = localData.payhereConfig || {};
                safeSetVal('set-payhere-merchant-id', payhereConf.merchantId);
                safeSetVal('set-payhere-merchant-secret', payhereConf.merchantSecret);
                safeSetVal('set-payhere-mode', payhereConf.mode || "sandbox");
                safeSetVal('set-dialog-qr-url', localData.dialogQrUrl || "");
                window._configuredDialogQrUrl = localData.dialogQrUrl || "";
                window.renderFavoritesSettings(localFavs);
                if (localData.modules) {
                    safeSetChecked('toggle-mrp', localData.modules.mrp !== false);
                    safeSetChecked('toggle-hrm', localData.modules.hrm !== false);
                    safeSetChecked('toggle-web', localData.modules.web !== false);
                }
            }
        } else {
            // Render basic defaults immediately if no cache
            const defaultFavs = ['pos', 'orders', 'web-orders', 'reload'];
            window.renderFavoritesSidebar(defaultFavs);
            window.renderFavoritesSettings(defaultFavs);
        }
    } catch (cacheErr) {
        console.warn("Failed to load settings from local storage cache", cacheErr);
    }

    onSnapshot(doc(db, 'config', storeId), (snapshot) => {
        try {
            if (snapshot.exists()) {
                const data = snapshot.data();
                window.systemConfig = data;
                
                // Cache system config isolated per merchant locally
                try {
                    const storeCacheKey = `mecpos_system_config_${storeId}`;
                    localStorage.setItem(storeCacheKey, JSON.stringify(data));
                    localStorage.setItem('mecpos_system_config_cache', JSON.stringify(data));
                    if (window.chrome?.webview) {
                        const unifiedCache = {
                            storeId: storeId,
                            storeInfo: window.storeInfo || {},
                            systemConfig: data
                        };
                        window.chrome.webview.postMessage({ type: 'savePlanConfig', data: JSON.stringify(unifiedCache) });
                    }
                } catch (e) {
                    console.warn("Failed to cache system config", e);
                }
                
                // Render favorites and modules globally first
                const favs = data.favorites || ['pos', 'orders', 'web-orders', 'reload'];
                window.renderFavoritesSidebar(favs);
                if (data.modules) {
                    window.applyModuleVisibility(data.modules);
                }
                
                // Helper functions to safely update DOM values
                const safeSetVal = (id, val) => {
                    const el = document.getElementById(id);
                    if (el) el.value = val !== undefined && val !== null ? val : "";
                };
                const safeSetChecked = (id, checked) => {
                    const el = document.getElementById(id);
                    if (el) el.checked = !!checked;
                };

                // Populate UI if in settings tab
                if (document.getElementById('set-biz-name')) {
                    safeSetVal('set-biz-name', data.bizName);
                    safeSetVal('set-store-logo-url', data.storeLogoUrl || data.logoUrl || "");
                    const logoPreview = document.getElementById('set-store-logo-preview');
                    const defaultLogo = '/logo.png';
                    if (logoPreview) logoPreview.src = data.storeLogoUrl || data.logoUrl || defaultLogo;
                    if (data.storeLogoUrl || data.logoUrl) {
                        const activeLogoUrl = data.storeLogoUrl || data.logoUrl;
                        document.querySelectorAll('.nav-brand img, .login-header img, #mi-logo-actual').forEach(img => {
                            img.src = activeLogoUrl;
                        });
                    }
                    safeSetVal('set-currency', data.currency || "LKR");
                    safeSetVal('set-tax', data.taxRate || 0);
                    safeSetVal('set-wholesale-discount', data.wholesaleDiscount || 0);
                    safeSetVal('set-loyalty-discount', data.loyaltyDiscount || 0);
                    safeSetVal('set-loyalty-rate', data.loyaltyRate || 0);
                    safeSetVal('set-profit-margin', data.profitMargin !== undefined ? data.profitMargin : 0);
                    safeSetVal('set-store-latitude', data.storeLatitude);
                    safeSetVal('set-store-longitude', data.storeLongitude);
                    safeSetVal('set-ai-language', data.aiLanguage || "english");
                    safeSetVal('set-printer-type', data.printerType || "thermal-80");
                    
                    const pSelect = document.getElementById('set-printer-name');
                    if (pSelect) {
                        pSelect.value = data.printerName || "";
                    }
                    safeSetVal('set-inv-address', data.invAddress);
                    safeSetVal('set-inv-phone', data.invPhone);
                    safeSetVal('set-inv-footer', data.invFooter);
                    safeSetVal('set-auto-print', data.autoPrint || "yes");
                    safeSetChecked('set-show-logo', data.showLogo !== false);
                    
                    const tplValue = data.invTemplate || "classic";
                    safeSetVal('set-inv-template', tplValue);
                    if (window.selectInvoiceTemplate) {
                        window.selectInvoiceTemplate(tplValue, true);
                    }

                    // Populate SMS Config
                    const smsConf = data.smsConfig || {};
                    safeSetVal('set-sms-api-base', smsConf.apiBase);
                    safeSetVal('set-sms-api-key', smsConf.apiKey);
                    safeSetVal('set-sms-user-id', smsConf.userId);
                    safeSetVal('set-sms-sender-id', smsConf.senderId);

                    // Populate Payhere Config
                    const payhereConf = data.payhereConfig || {};
                    safeSetVal('set-payhere-merchant-id', payhereConf.merchantId);
                    safeSetVal('set-payhere-merchant-secret', payhereConf.merchantSecret);
                    safeSetVal('set-payhere-mode', payhereConf.mode || "sandbox");

                    // Populate Dialog QR Reload URL
                    safeSetVal('set-dialog-qr-url', data.dialogQrUrl || "");
                    // Also cache it globally so openDialogPortalPopup can read it instantly
                    window._configuredDialogQrUrl = data.dialogQrUrl || "";

                    window.renderFavoritesSettings(favs);

                    // Apply Module Toggles in settings inputs
                    if (data.modules) {
                        safeSetChecked('toggle-mrp', data.modules.mrp !== false);
                        safeSetChecked('toggle-hrm', data.modules.hrm !== false);
                        safeSetChecked('toggle-web', data.modules.web !== false);
                    }

                    if (document.getElementById('set-low-end-mode')) {
                        const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
                        document.getElementById('set-low-end-mode').checked = isLowEnd;
                        if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                        setTimeout(() => {
                            if (window.isLowEndModeEnabled === true) {
                                safeSetChecked('set-low-end-mode', true);
                                localStorage.setItem('mec_low_end_mode', 'true');
                                if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                            }
                        }, 1000);
                    }

                    if (document.getElementById('set-pos-auto-scan')) {
                        document.getElementById('set-pos-auto-scan').checked = localStorage.getItem('mec_pos_auto_scan') === 'true';
                    }
                }
            } else {
                // No config yet, render default favorites
                const defaultFavs = ['pos', 'orders', 'web-orders', 'reload'];
                window.renderFavoritesSettings(defaultFavs);
                window.renderFavoritesSidebar(defaultFavs);
                
                const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
                const lem = document.getElementById('set-low-end-mode');
                if (lem) lem.checked = isLowEnd;
                if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                setTimeout(() => {
                    if (window.isLowEndModeEnabled === true) {
                        const lem2 = document.getElementById('set-low-end-mode');
                        if (lem2) lem2.checked = true;
                        localStorage.setItem('mec_low_end_mode', 'true');
                        if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                    }
                }, 1000);

                const pas = document.getElementById('set-pos-auto-scan');
                if (pas) pas.checked = localStorage.getItem('mec_pos_auto_scan') === 'true';
            }
        } catch (err) {
            console.error("Error in loadSystemSettings snapshot listener:", err);
            if (window.showToast) window.showToast("Settings Load Error: " + err.message, "error");
        }
    });
};

window.toggleLowEndMode = async (enabled) => {
    localStorage.setItem('mec_low_end_mode', enabled ? 'true' : 'false');
    if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();

    // ── Permanently save to Firebase so fresh installs auto-apply this setting ──
    try {
        await setDoc(doc(db, 'appConfig', 'performance'), {
            lowPerformanceMode: enabled,
            updatedAt: new Date().toISOString(),
            updatedBy: sessionStorage.getItem('userName') || 'Admin'
        }, { merge: true });
        console.log('[PerfSettings] Firebase updated: lowPerformanceMode =', enabled);
    } catch (e) {
        console.warn('[PerfSettings] Firebase save failed:', e.message);
    }

    if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage({ type: 'toggleLowEndMode', disableGpu: enabled });
        window.showToast(
            enabled
                ? "⚡ Low-End Mode Saved to Firebase! Please restart MEC POS to apply."
                : "✅ Low-End Mode Disabled & Saved! Please restart MEC POS.",
            "success"
        );
    } else {
        window.showToast("This feature is only available in the MEC POS Desktop App.", "error");
        document.getElementById('set-low-end-mode').checked = !enabled;
    }
};

window.renderFavoritesSettings = (favorites = []) => {
    const grid = document.getElementById('favorites-selection-grid');
    if (!grid) return;

    const modules = [
        { id: 'pos', name: 'POS Terminal', icon: '💻' },
        { id: 'orders', name: 'Sales & Orders', icon: '📦' },
        { id: 'web-orders', name: 'Web Store Orders', icon: '🛒' },
        { id: 'reload', name: 'Reload Terminal', icon: '📱' },
        { id: 'products', name: 'Product Master', icon: '📚' },
        { id: 'stock', name: 'Smart Procurement', icon: '📥' },
        { id: 'stocks-view', name: 'Current Stocks', icon: '📦' },
        { id: 'categories', name: 'Categories', icon: '🏷️' },
        { id: 'mrp', name: 'MRP Hub', icon: '🏭' },
        { id: 'reports', name: 'Final Reports', icon: '📊' },
        { id: 'expenses', name: 'Expenditure', icon: '💸' },
        { id: 'income', name: 'Misc Income', icon: '💰' },
        { id: 'credit', name: 'Credit Ledger', icon: '⏳' },
        { id: 'suppliers', name: 'Supplier Database', icon: '🤝' },
        { id: 'supplier-invoices', name: 'Supplier Invoices', icon: '📑' },
        { id: 'purchases', name: 'Purchase Logs', icon: '🛍️' },
        { id: 'promotions', name: 'Promotions', icon: '🎁' },
        { id: 'customers', name: 'Customer Database', icon: '👥' },
        { id: 'repairs', name: 'Service Center', icon: '🔧' },
        { id: 'hrm', name: 'HRM & Payroll', icon: '👔' },
        { id: 'branches', name: 'Branch Network', icon: '🏢' },
        { id: 'it-system', name: 'IT & Security', icon: '🛡️' },
        { id: 'appearance', name: 'Appearance', icon: '✨' },
        { id: 'web-dev', name: 'Website Studio', icon: '🌐' }
    ];

    grid.innerHTML = modules.map(m => `
        <label class="module-toggle-card" style="cursor: pointer; transition: 0.2s; color: #fff; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px; display: flex; justify-content: space-between; align-items: center; ${favorites.includes(m.id) ? 'border-color: #38bdf8; background: rgba(56, 189, 248, 0.05);' : ''}">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 1.5rem;">${m.icon}</span>
                <div>
                    <div style="font-weight: 700; font-size: 0.85rem; color: #fff;">${m.name}</div>
                    <div style="font-size: 0.65rem; color: #94a3b8;">Tab ID: ${m.id}</div>
                </div>
            </div>
            <input type="checkbox" class="favorite-checkbox toggle-switch" value="${m.id}" ${favorites.includes(m.id) ? 'checked' : ''} 
                   onchange="this.closest('.module-toggle-card').style.borderColor = this.checked ? '#38bdf8' : 'rgba(255,255,255,0.1)'; this.closest('.module-toggle-card').style.background = this.checked ? 'rgba(56, 189, 248, 0.05)' : 'rgba(255,255,255,0.03)';">
        </label>
    `).join('');
}

window.renderFavoritesSidebar = (favorites = []) => {
    const container = document.getElementById('favorite-apps-container');
    const list = document.getElementById('favorite-apps-list');
    if (!container || !list) return;

    if (!favorites || favorites.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';

    const modules = {
        'pos': ['POS Terminal', '💻'],
        'orders': ['Sales & Orders', '📦'],
        'web-orders': ['Web Store Orders', '🛒'],
        'reload': ['Reload Terminal', '📱'],
        'products': ['Product Master', '📚'],
        'stock': ['Smart Procurement', '📥'],
        'stocks-view': ['Current Stocks', '📦'],
        'categories': ['Categories', '🏷️'],
        'mrp': ['MRP Hub', '🏭'],
        'reports': ['Final Reports', '📊'],
        'expenses': ['Expenditure', '💸'],
        'income': ['Misc Income', '💰'],
        'credit': ['Credit Ledger', '⏳'],
        'suppliers': ['Supplier Database', '🤝'],
        'supplier-invoices': ['Supplier Invoices', '📑'],
        'purchases': ['Purchase Logs', '🛍️'],
        'promotions': ['Promotions', '🎁'],
        'customers': ['Customer Database', '👥'],
        'repairs': ['Service Center', '🔧'],
        'hrm': ['HRM & Payroll', '👔'],
        'branches': ['Branch Network', '🏢'],
        'it-system': ['IT & Security', '🛡️'],
        'appearance': ['Appearance', '✨'],
        'web-dev': ['Website Studio', '🌐']
    };

    list.innerHTML = favorites.map(id => {
        const mod = modules[id];
        // Hide if module doesn't exist or if tab isn't allowed by current plan/role
        if (!mod || (window.allowedTabs && !window.allowedTabs.includes(id))) return '';
        return `
            <button class="nav-tab favorite-pin" onclick="showTab('${id}')" style="margin-bottom: 4px; background: rgba(56, 189, 248, 0.03); border-left: 3px solid transparent; transition: all 0.2s;">
                <span class="icon">${mod[1]}</span> <span>${mod[0]}</span>
            </button>
        `;
    }).join('');
}

// --- Global UI Render Exports ---
window.renderBranchesUI = renderBranchesUI;
window.renderCategoriesUI = renderCategoriesUI;
window.renderStoresUI = renderStoresUI;
window.renderExpensesUI = renderExpensesUI;
window.renderPurchasesUI = renderPurchasesUI;
window.renderSuppliersUI = renderSuppliersUI;
window.renderIncomeUI = renderIncomeUI;
window.renderCustomersUI = renderCustomersUI;
window.renderAdminEmployeesUI = renderAdminEmployeesUI;
window.renderAdminPayrollUI = renderAdminPayrollUI;
window.syncAttendanceUI = syncAttendanceUI;


window.selectInvoiceTemplate = (tpl, isLoad = false) => {
    const input = document.getElementById('set-inv-template');
    if (input) input.value = tpl;
    document.querySelectorAll('.template-card').forEach(card => {
        card.classList.remove('active');
        card.style.borderColor = 'transparent';
        card.style.background = 'rgba(255,255,255,0.02)';
    });
    const activeCard = document.getElementById('tpl-card-' + tpl);
    if (activeCard) {
        activeCard.classList.add('active');
        activeCard.style.borderColor = '#38bdf8';
        activeCard.style.background = 'rgba(56, 189, 248, 0.05)';
    }
    if (!isLoad) window.showToast('Template set to ' + tpl.toUpperCase(), "info");
};

window.viewTemplateJPG = (src, title) => {
    const modal = document.getElementById('modal-template-view');
    const img = document.getElementById('tpl-view-img');
    const titleEl = document.getElementById('tpl-view-title');
    if (modal && img && titleEl) {
        img.src = src;
        titleEl.innerText = title;
        modal.style.display = 'flex';
    }
};

window.previewInvoiceTemplate = (tpl) => {
    const dummyItems = [{ name: "Leather Journal", quantity: 2, price: 1250, discount: 50 }];
    window.showToast('🚀 Generating ' + tpl.toUpperCase() + ' Preview...', "info");
    const originalConfig = window.systemConfig;
    window.systemConfig = { ...originalConfig, invTemplate: tpl, printerType: 'a4' };
    const originalItems = window.activePOSItems;
    window.activePOSItems = dummyItems;
    window.printPOSReceipt();
    window.activePOSItems = originalItems;
    window.systemConfig = originalConfig;
};

window.toggleModule = (mod, enabled) => {
    // Check package permissions first
    const permKey = mod === 'web' ? 'web-orders' : mod;
    if (enabled && window.allowedTabs && !window.allowedTabs.includes(permKey)) {
        // Find the toggle and revert it to unchecked
        const toggleEl = document.getElementById(`toggle-${mod}`);
        if (toggleEl) toggleEl.checked = false;
        
        // Let the user know they need to upgrade
        window.showToast(`To enable this feature, please upgrade to the package that supports it.`, 'error');
        return;
    }

    const modules = window.systemConfig?.modules || { mrp: true, hrm: true, repairs: true };
    modules[mod] = enabled;
    window.applyModuleVisibility(modules);
    window.saveGlobalSettings();
};

window.applyModuleVisibility = (modules) => {
    if (!modules) return;

    // MRP Visibility
    const mrpItems = [
        document.getElementById('tab-mrp'),
        document.getElementById('nav-label-mrp')
    ];
    mrpItems.forEach(el => { if (el) el.style.display = modules.mrp === false ? 'none' : 'block'; });

    // HRM Visibility
    const hrmItems = [
        document.getElementById('tab-hrm')
    ];
    hrmItems.forEach(el => { if (el) el.style.display = modules.hrm === false ? 'none' : 'block'; });

    // Repairs Visibility
    const repairsItems = [
        document.getElementById('tab-repairs')
    ];
    repairsItems.forEach(el => { if (el) el.style.display = modules.repairs === false ? 'none' : 'block'; });

    // Web Store Visibility
    const webItems = [
        document.getElementById('tab-web-orders')
    ];
    webItems.forEach(el => { 
        if (el) {
            const isAllowed = !window.allowedTabs || window.allowedTabs.includes('web-orders');
            el.style.display = (modules.web !== false && isAllowed) ? 'flex' : 'none'; 
        }
    });
};


window.clearSINVBatch = () => {
    if (!window.currentInvoiceItems || window.currentInvoiceItems.length === 0) return;
    if (confirm("Are you sure you want to CLEAR the entire batch? All added items will be removed.")) {
        window.currentInvoiceItems = [];
        window.renderInvoiceItemsTable();
        window.showToast("Batch Cleared", "info");
    }
};

window.updateSidebarSubscription = (storeInfo) => {
    const planEl = document.getElementById('sidebar-sub-plan');
    const expiryEl = document.getElementById('sidebar-sub-expiry');
    const statusEl = document.getElementById('sidebar-sub-status');
    const dotEl = document.getElementById('sidebar-sub-dot');

    if (!planEl || !expiryEl || !statusEl || !dotEl) return;

    // Cache the store info for fast future renders
    try {
        if (storeInfo && storeInfo.slug) {
            saveOfflineCache(`storeInfo_${storeInfo.slug}`, storeInfo);
        }
    } catch(e) {}

    // Plan Display
    const planName = storeInfo.plan || 'Ultimate Package';
    planEl.innerText = planName;

    // Status & Color Dot mapping
    let status = (storeInfo.status || 'Ultimate').toUpperCase();

    // Check expiration locally
    let isExpired = false;
    if (storeInfo.expiryDate) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const localToday = `${year}-${month}-${day}`;
        if (storeInfo.expiryDate < localToday) {
            isExpired = true;
            status = 'EXPIRED';
        }
    }
    statusEl.innerText = status;

    // Reset dot classes
    dotEl.className = 'status-dot';
    if (status === 'ACTIVE') {
        dotEl.classList.add('green');
    } else if (status === 'TRIAL') {
        statusIndicator.style.background = '#3b82f6';
        statusIndicator.style.boxShadow = '0 0 10px rgba(59, 130, 246, 0.4)';
    } else if (status === 'ULTIMATE') {
        dotEl.classList.add('blue');
    } else if (status === 'SUSPENDED' || status === 'EXPIRED') {
        dotEl.classList.add('red');
    } else {
        dotEl.classList.add('yellow');
    }

    // Expiration date formatting
    if (storeInfo.expiryDate) {
        try {
            const date = new Date(storeInfo.expiryDate);
            const formatted = date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
            expiryEl.innerText = formatted;
        } catch (e) {
            expiryEl.innerText = storeInfo.expiryDate;
        }
    } else {
        expiryEl.innerText = 'Never';
    }

    // Manage Fullscreen Blocker Overlay
    const overlay = document.getElementById('subscription-blocker-overlay');
    if (overlay) {
        if (isExpired || status === 'SUSPENDED') {
            overlay.style.display = 'flex';
        } else {
            overlay.style.display = 'none';
        }
    }

    // Trigger tab filtering dynamically based on the updated storeInfo plan
    if (typeof window.showAdminActions === 'function') {
        window.showAdminActions();
    }
};

window.openUpgradeModal = () => {
    const modal = document.getElementById('modal-upgrade');
    if (modal) {
        modal.style.display = 'flex';
        // Prefill current store info plan if available
        if (window.storeInfo) {
            const planStr = window.storeInfo.plan || 'Ultimate Package';
            let tier = 'Starter';
            if (planStr.toLowerCase().includes('ultimate') || planStr.toLowerCase().includes('enterprise')) tier = 'Enterprise';
            else if (planStr.toLowerCase().includes('professional') || planStr.toLowerCase().includes('business')) tier = 'Business';
            else if (planStr.toLowerCase().includes('trial')) tier = 'Trial';
            else if (planStr.toLowerCase().includes('ultimate')) tier = 'Ultimate';

            let billing = window.storeInfo.billing || 'monthly';
            
            const tierEl = document.getElementById('upgrade-plan-tier');
            const billingEl = document.getElementById('upgrade-plan-billing');
            if (tierEl) tierEl.value = tier;
            if (billingEl) billingEl.value = billing;
            if (typeof window.updateUpgradePriceDisplay === 'function') {
                window.updateUpgradePriceDisplay();
            }
        }
    }
};

window.closeUpgradeModal = () => {
    const modal = document.getElementById('modal-upgrade');
    if (modal) modal.style.display = 'none';
};

window.updateUpgradePriceDisplay = () => {
    const tier = document.getElementById('upgrade-plan-tier').value;
    const billing = document.getElementById('upgrade-plan-billing').value;
    const priceEl = document.getElementById('upgrade-price-display');
    if (!priceEl) return;

    let priceText = 'Price: LKR 0';
    if (tier === 'Starter') {
        if (billing === 'monthly') priceText = 'Price: LKR 4,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 4,083/mo (LKR 49,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 99,000 one-time';
    } else if (tier === 'Business') {
        if (billing === 'monthly') priceText = 'Price: LKR 9,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 8,250/mo (LKR 99,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 149,900 one-time';
    } else if (tier === 'Enterprise') {
        if (billing === 'monthly') priceText = 'Price: LKR 24,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 20,750/mo (LKR 249,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 299,000 one-time';
    } else if (tier === 'Trial') {
        priceText = 'Price: LKR 0 (Free Trial)';
    } else if (tier === 'Ultimate') {
        priceText = 'One-time Payment';
    }
    priceEl.innerText = priceText;
};

window.confirmUpgradePlan = async () => {
    const btn = document.getElementById('btn-confirm-upgrade');
    if (btn) {
        btn.disabled = true;
        btn.innerText = 'Updating Package...';
    }
    try {
        const tier = document.getElementById('upgrade-plan-tier').value;
        const billing = document.getElementById('upgrade-plan-billing').value;
        const storeId = window.getStoreId();

        let tierPrefix = 'Starter Plan';
        if (tier === 'Business') tierPrefix = 'Professional Plan';
        else if (tier === 'Enterprise') tierPrefix = 'Ultimate Plan';
        else if (tier === 'Trial') tierPrefix = 'Trial Plan';
        else if (tier === 'Ultimate') tierPrefix = 'Ultimate Package';

        let billingSuffix = '(Month)';
        if (billing === 'annual') billingSuffix = '(Year)';
        else if (billing === 'lifetime') billingSuffix = '(Full)';

        const plan = `${tierPrefix} ${billingSuffix}`;

        let expiryDate = '';
        const expDateObj = new Date();
        if (billing === 'monthly') {
            expDateObj.setDate(expDateObj.getDate() + 30);
            expiryDate = expDateObj.toISOString().split('T')[0];
        } else if (billing === 'annual') {
            expDateObj.setDate(expDateObj.getDate() + 365);
            expiryDate = expDateObj.toISOString().split('T')[0];
        } else if (billing === 'lifetime') {
            expiryDate = '';
        }

        const q = query(collection(db, "stores"), where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                plan,
                billing,
                expiryDate,
                status: 'Active',
                updatedAt: serverTimestamp()
            });
            window.showToast("⚡ Package updated successfully!", "success");
            window.closeUpgradeModal();
        } else {
            window.showToast("❌ Store profile not found.", "error");
        }
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error upgrading package: " + err.message, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = 'Upgrade Now ⚡';
        }
    }
};

// ─── Realtime System Broadcast Banner ────────────────────────
function initSystemBroadcastListener() {
    const broadcastDoc = doc(db, 'system', 'broadcast');
    onSnapshot(broadcastDoc, (docSnap) => {
        if (!docSnap.exists()) return;
        const data = docSnap.data();
        const msg = data.message ? data.message.trim() : "";
        const active = data.active === true;
        const type = data.type || "info"; // info, warning, critical, success
        
        let banner = document.getElementById('system-broadcast-banner');
        
        if (!active || !msg) {
            if (banner) banner.style.display = 'none';
            return;
        }
        
        // Dynamic banner creation if not exists
        if (!banner) {
            banner = document.createElement('div');
            banner.id = 'system-broadcast-banner';
            // Insert it at the very top of the admin-main container
            const adminMain = document.querySelector('.admin-main');
            if (adminMain) {
                adminMain.insertBefore(banner, adminMain.firstChild);
            } else {
                document.body.insertBefore(banner, document.body.firstChild);
            }
        }
        
        // Styling based on notice status/banner type
        let bg = 'rgba(0, 245, 255, 0.15)';
        let border = '1px solid rgba(0, 245, 255, 0.3)';
        let color = '#00F5FF';
        let icon = 'ℹ️';
        
        if (type === 'warning' || type.includes('warning') || type.includes('Yellow')) {
            bg = 'rgba(234, 179, 8, 0.15)';
            border = '1px solid rgba(234, 179, 8, 0.3)';
            color = '#fbbf24';
            icon = '⚠️';
        } else if (type === 'critical' || type.includes('critical') || type.includes('Red')) {
            bg = 'rgba(239, 68, 68, 0.15)';
            border = '1px solid rgba(239, 68, 68, 0.3)';
            color = '#f87171';
            icon = '🚨';
        } else if (type === 'success' || type.includes('success') || type.includes('Green')) {
            bg = 'rgba(16, 185, 129, 0.15)';
            border = '1px solid rgba(16, 185, 129, 0.3)';
            color = '#34d399';
            icon = '✅';
        }
        
        banner.style.cssText = `
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            padding: 12px 24px;
            background: ${bg};
            border-bottom: ${border};
            color: ${color};
            font-weight: 700;
            font-size: 0.9rem;
            z-index: 1000;
            position: sticky;
            top: 0;
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            font-family: 'Outfit', sans-serif;
        `;
        
        banner.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.2rem;">${icon}</span>
                <span>${msg}</span>
            </div>
            <button onclick="this.parentElement.style.display='none'" style="background: none; border: none; color: inherit; font-size: 1.2rem; cursor: pointer; padding: 4px; line-height: 1; opacity: 0.7; transition: opacity 0.2s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.7">&times;</button>
        `;
        
        // Ensure displayed
        banner.style.display = 'flex';
    }, (err) => {
        console.error("System broadcast listener error:", err);
    });
}

window.autoCalculateProductPrices = (type) => {
    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    if (type === 'add') {
        const price = parseFloat(document.getElementById('p-price').value) || 0;
        document.getElementById('p-wholesale-price').value = (price * (1 - wholesalePct / 100)).toFixed(2);
        document.getElementById('p-loyalty-price').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
    } else if (type === 'edit') {
        const price = parseFloat(document.getElementById('edit-p-price').value) || 0;
        document.getElementById('edit-p-wholesale-price').value = (price * (1 - wholesalePct / 100)).toFixed(2);
        document.getElementById('edit-p-loyalty-price').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
    }
};

window.autoCalculateVariantPrices = (inputEl) => {
    const row = inputEl.closest('.variant-row');
    if (!row) return;
    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const price = parseFloat(inputEl.value) || 0;
    const wsInput = row.querySelector('.v-wholesale');
    if (wsInput) wsInput.value = (price * (1 - wholesalePct / 100)).toFixed(2);
    const loyInput = row.querySelector('.v-loyalty');
    if (loyInput) loyInput.value = (price * (1 - loyaltyPct / 100)).toFixed(2);
};

window.autoCalculateSinvPrices = () => {
    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const price = parseFloat(document.getElementById('sinv-item-new-retail').value) || 0;
    document.getElementById('sinv-item-wholesale').value = (price * (1 - wholesalePct / 100)).toFixed(2);
    document.getElementById('sinv-item-loyalty').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
};

window.autoCalculateBatchPrices = () => {
    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const price = parseFloat(document.getElementById('be-retail').value) || 0;
    document.getElementById('be-wholesale').value = (price * (1 - wholesalePct / 100)).toFixed(2);
    document.getElementById('be-loyalty').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
};


// ─────────────────────────────────────────────
// CHEQUE PAYMENT HANDLING
// ─────────────────────────────────────────────
window._chequeModalSource = null;
window._confirmedChequeDate = null;

window.onSettlementChange = (value, source) => {
    const v = value.toLowerCase();
    if (v === 'cheque') {
        window._chequeModalSource = source;
        window._confirmedChequeDate = null;
        const today = new Date().toISOString().split('T')[0];
        const inp = document.getElementById('cheque-date-input');
        if (inp) inp.value = today;
        const modal = document.getElementById('cheque-date-modal');
        if (modal) modal.style.display = 'flex';
    } else {
        window._confirmedChequeDate = null;
    }
};

window.closeChequeModal = () => {
    const modal = document.getElementById('cheque-date-modal');
    if (modal) modal.style.display = 'none';
    if (!window._confirmedChequeDate) {
        const src = window._chequeModalSource;
        if (src === 'pos') {
            const posPayModal = document.getElementById('pos-payment-modal');
            if (posPayModal) posPayModal.style.display = 'flex';
        } else {
            const sel = document.getElementById(src === 'po' ? 'po-settlement-type' : 'sinv-pay-method');
            if (sel) sel.value = src === 'po' ? 'cash' : 'Cash';
        }
    }
};

window.confirmChequeDate = () => {
    const inp = document.getElementById('cheque-date-input');
    const dateVal = inp ? inp.value : '';
    if (!dateVal) { window.showToast('Please pick a cheque date.', 'warning'); return; }
    window._confirmedChequeDate = dateVal;
    const modal = document.getElementById('cheque-date-modal');
    if (modal) modal.style.display = 'none';
    window.showToast('Cheque date set: ' + dateVal + '. Invoice will auto-clear on that date.', 'info');
    if (window._chequeModalSource === 'pos') {
        window.processPOSSale('Cheque');
    }
};

window.markChequeAsPaid = async (docId) => {
    if (!confirm('Mark this cheque invoice as PAID?')) return;
    try {
        await updateDoc(doc(db, 'supplierInvoices', docId), {
            status: 'Paid',
            chequeStatus: 'cleared',
            paidAt: serverTimestamp()
        });
        window.showToast('Invoice marked as Paid!', 'success');
    } catch (err) {
        window.showToast('Error: ' + err.message, 'error');
    }
};

window.syncAllMissingProductDiscounts = async () => {
    try {
        const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
        const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;

        if (wholesalePct <= 0 && loyaltyPct <= 0) {
            window.showToast("⚠️ Global Wholesale/Loyalty discount percentages are not configured yet!", "warning");
            return;
        }

        if (!confirm("⚠️ This will scan all products in the database and automatically calculate & update missing/zero Wholesale or Loyalty prices based on your global settings. Proceed?")) {
            return;
        }

        window.showToast("🚀 Scanning and updating database, please wait...", "info");

        const products = window.allProducts || [];
        if (products.length === 0) {
            window.showToast("❌ No products loaded in memory to scan. Try reloading.", "error");
            return;
        }

        let updateCount = 0;
        let batch = writeBatch(db);
        let batchCount = 0;

        for (const p of products) {
            let needsUpdate = false;
            const updates = {};

            // 1. Check base product prices
            const basePrice = parseFloat(p.price) || 0;
            if (basePrice > 0) {
                const currentWS = parseFloat(p.wholesalePrice) || 0;
                const currentLoy = parseFloat(p.loyaltyPrice) || 0;

                if (currentWS <= 0) {
                    updates.wholesalePrice = Math.round((basePrice * (1 - wholesalePct / 100)) * 1000) / 1000;
                    needsUpdate = true;
                }
                if (currentLoy <= 0) {
                    updates.loyaltyPrice = Math.round((basePrice * (1 - loyaltyPct / 100)) * 1000) / 1000;
                    needsUpdate = true;
                }
            }

            // 2. Check variant prices
            if (p.variants && p.variants.length > 0) {
                const updatedVariants = p.variants.map(v => {
                    let vChanged = false;
                    const vPrice = parseFloat(v.sellingPrice || v.price) || 0;
                    const vWS = parseFloat(v.wholesalePrice) || 0;
                    const vLoy = parseFloat(v.loyaltyPrice) || 0;

                    const newV = { ...v };

                    if (vPrice > 0) {
                        if (vWS <= 0) {
                            newV.wholesalePrice = Math.round((vPrice * (1 - wholesalePct / 100)) * 1000) / 1000;
                            vChanged = true;
                        }
                        if (vLoy <= 0) {
                            newV.loyaltyPrice = Math.round((vPrice * (1 - loyaltyPct / 100)) * 1000) / 1000;
                            vChanged = true;
                        }
                    }

                    if (vChanged) needsUpdate = true;
                    return newV;
                });

                if (needsUpdate) {
                    updates.variants = updatedVariants;
                    // Also update the base fields if variants updated
                    if (updatedVariants.length > 0) {
                        updates.wholesalePrice = updatedVariants[0].wholesalePrice;
                        updates.loyaltyPrice = updatedVariants[0].loyaltyPrice;
                    }
                }
            }

            if (needsUpdate) {
                const docRef = doc(db, 'products', p.docId);
                batch.update(docRef, updates);
                updateCount++;
                batchCount++;

                if (batchCount >= 400) {
                    await batch.commit();
                    batch = writeBatch(db);
                    batchCount = 0;
                }
            }
        }

        if (batchCount > 0) {
            await batch.commit();
        }

        window.showToast(`✅ Successfully updated ${updateCount} products/variants with missing prices!`, "success");
    } catch (err) {
        console.error("Error syncing missing discounts:", err);
        window.showToast("❌ Error: " + err.message, "error");
    }
};

// Register Service Worker for Offline Administration capability
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then(reg => {
            console.log('Admin SW Registered', reg.scope);
        }).catch(err => {
            console.log('Admin SW Registration Failed', err);
        });
    });
}

window.shareModernInvoiceWhatsApp = () => {
    const orderId = window._currentViewingInvoiceId;
    if (!orderId) {
        window.showToast("No active invoice to share.", "warning");
        return;
    }
    const order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId) 
                  || (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId) ? window.lastSavedPOSOrder : null)
                  || window.currentPendingRepairOrder;
                  
    if (!order) return window.showToast("Invoice not found in memory.", "warning");

    let phone = order.phone || order.customerPhone || "";
    let formattedPhone = phone.replace(/\D/g, '');
    if (formattedPhone.startsWith('0')) formattedPhone = '94' + formattedPhone.substring(1);

    if (!formattedPhone) {
        window.showToast("Customer phone required for WhatsApp.", "warning");
        return;
    }

    const itemLines = (order.items || []).map(i => `• ${i.name} (x${i.quantity || 1}) - LKR ${((i.price || 0) * (i.quantity || 1)).toLocaleString()}`).join('\n');
    
    let message = `*INVOICE: #${order.orderId}*\n*MEC BOOK SHOP*\n----------------------------------\n*Customer:* ${order.userName || 'Valued Customer'}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${itemLines}\n----------------------------------\n*TOTAL: LKR ${order.total.toLocaleString()}*\n*Method:* ${order.paymentMethod || 'Cash'}\n\nThank you for shopping @ MEC! 📚✨`;
    
    if (order.type === 'RepairBill') {
        message = `*REPAIR BILL: #${order.orderId}*\n*MEC BOOK SHOP SERVICE*\n----------------------------------\n*Customer:* ${order.userName || 'Valued Customer'}\n*Device:* ${order.itemDescription || 'Device'}\n*Issue:* ${order.problem || 'Repair'}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${itemLines}\n----------------------------------\n*TOTAL: LKR ${order.total.toLocaleString()}*\n*Method:* ${order.paymentMethod || 'Cash'}\n\nThank you for trusting MEC Book Shop Repairs! 🛠️✨`;
    }

    const encoded = encodeURIComponent(message);
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    const url = isMobile 
        ? `https://wa.me/${formattedPhone}?text=${encoded}`
        : `https://web.whatsapp.com/send?phone=${formattedPhone}&text=${encoded}`;
    
    if (window.electronAPI && window.electronAPI.openExternal) {
        const electronUrl = `https://wa.me/${formattedPhone}?text=${encoded}`;
        window.electronAPI.openExternal(electronUrl);
    } else {
        window.open(url, '_blank');
    }
    
    window.showToast("📲 WhatsApp invoice shared!", "success");
};

window.shareModernInvoiceSMS = async () => {
    const orderId = window._currentViewingInvoiceId;
    if (!orderId) {
        window.showToast("No active invoice to share.", "warning");
        return;
    }
    const order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId) 
                  || (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId) ? window.lastSavedPOSOrder : null)
                  || window.currentPendingRepairOrder;
                  
    if (!order) return window.showToast("Invoice not found in memory.", "warning");

    let phone = order.phone || order.customerPhone || "";
    let formattedPhone = phone.replace(/\D/g, '');
    if (formattedPhone.startsWith('0')) {
        formattedPhone = '94' + formattedPhone.substring(1);
    }
    
    if (formattedPhone.length !== 11) {
        window.showToast("Invalid phone number format for SMS.", "error");
        return;
    }

    const billId = order.orderId;
    const total = order.total.toFixed(2);
    const date = order.date || new Date().toLocaleDateString();

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    let message = `Thank you for shopping at ${bizName}!\nInvoice: ${billId}\nDate: ${date}\nTotal: LKR ${total}\nWe hope to see you again!\nmecbookshop.com.lk/track.html?id=${billId}`;
    if (order.type === 'RepairBill') {
        message = `Thank you for using ${bizName} Repairs!\nRepair Invoice: ${billId}\nDevice: ${order.itemDescription || 'Device'}\nTotal: LKR ${total}\nWe hope to see you again!\nmecbookshop.com.lk/track.html?id=${billId}`;
    }

    const smsConf = window.systemConfig?.smsConfig || {};
    const apiBase = smsConf.apiBase || "https://www.smslenz.lk/api/send-sms";
    const apiKey = smsConf.apiKey;
    const userId = smsConf.userId;
    const senderId = smsConf.senderId || "MECPOS";

    if (!apiKey || !userId) {
        return window.showToast("⚠️ SMS Gateway not configured. Please configure in Settings.", "warning");
    }

    try {
        const url = new URL(apiBase);
        url.searchParams.append("user_id", userId);
        url.searchParams.append("api_key", apiKey);
        url.searchParams.append("sender_id", senderId);
        url.searchParams.append("contact", '+' + formattedPhone);
        url.searchParams.append("message", message);

        await fetch(url.toString(), {
            method: 'GET',
            mode: 'no-cors' 
        });

        window.showToast("📲 SMS dispatched via SMSLenz!", "success");
    } catch (error) {
        console.error("SMS Error:", error);
        window.showToast("Failed to send SMS.", "error");
    }
};

window.fetchCurrentStoreGPS = () => {
    if (!navigator.geolocation) {
        return window.showToast("Geolocation is not supported by your browser.", "error");
    }
    window.showToast("📍 Fetching GPS location...", "info");
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude.toFixed(6);
            const lng = position.coords.longitude.toFixed(6);
            document.getElementById('set-store-latitude').value = lat;
            document.getElementById('set-store-longitude').value = lng;
            window.showToast("✅ GPS Location Captured Successfully!", "success");
        },
        (error) => {
            console.error("GPS Error:", error);
            window.showToast("Failed to fetch GPS coordinates. Please enter manually.", "error");
        },
        { enableHighAccuracy: true, timeout: 5000 }
    );
};

window.showStoreAttendanceQRCode = () => {
    const lat = parseFloat(document.getElementById('set-store-latitude').value) || 0;
    const lng = parseFloat(document.getElementById('set-store-longitude').value) || 0;
    if (lat === 0 || lng === 0) {
        return window.showToast("❌ Please set and save GPS Coordinates first!", "warning");
    }
    const storeId = window.getStoreId();
    const qrData = encodeURIComponent(`MEC-POS-ATTENDANCE-QR:${storeId}:${lat}:${lng}`);
    const qrImg = document.getElementById('attendance-qr-img');
    if (qrImg) {
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${qrData}`;
        window.openModal('attendance-qr-modal');
    }
};

window.printAttendanceQR = () => {
    const qrSrc = document.getElementById('attendance-qr-img').src;
    const bizName = window.systemConfig?.bizName || 'MEC POS STORE';
    
    // Create temporary print container
    const printContainer = document.createElement('div');
    printContainer.id = 'print-qr-temp-container';
    printContainer.innerHTML = `
        <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; padding: 50px; color: #333; background: white; min-height: 100vh;">
            <h1 style="font-size: 2.5rem; margin-bottom: 5px; color: #020617; font-weight: 800;">${bizName}</h1>
            <p style="font-size: 1.1rem; color: #64748b; margin-bottom: 30px;">Scan this QR code with your phone to Clock-In / Clock-Out</p>
            <div style="border: 4px solid #10b981; border-radius: 24px; padding: 30px; display: inline-block; margin-top: 30px; background: white;">
                <img src="${qrSrc}" style="width: 350px; height: 350px; display: block;">
            </div>
            <div style="margin-top: 50px; font-size: 0.9rem; color: #94a3b8;">
                Attendance Geofencing Radius: 100m
            </div>
        </div>
    `;
    
    // Add print styles
    const style = document.createElement('style');
    style.id = 'print-qr-temp-style';
    style.innerHTML = `
        @media print {
            body > *:not(#print-qr-temp-container) {
                display: none !important;
            }
            #print-qr-temp-container, #print-qr-temp-container * {
                display: block !important;
            }
            body {
                background: white !important;
                color: black !important;
            }
        }
    `;
    
    document.body.appendChild(printContainer);
    document.head.appendChild(style);
    
    window.print();
    
    // Clean up
    setTimeout(() => {
        printContainer.remove();
        style.remove();
    }, 1000);
};

window.addEventListener('beforeunload', function (e) {
  if (!navigator.onLine) {
    e.preventDefault();
    e.returnValue = 'You are currently offline. Unsaved data will be lost if you close the app.';
  }
});

window.handleStoreLogoFileUpload = async (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;
    if (typeof window.showToast === 'function') window.showToast("⚡ Compressing & preparing store logo...", "info");
    try {
        const compressedBase64 = typeof window.resizeImageToBase64 === 'function' ? await window.resizeImageToBase64(file, 800) : await new Promise(r => {
            const rd = new FileReader();
            rd.onload = e => r(e.target.result);
            rd.readAsDataURL(file);
        });
        const urlInput = document.getElementById('set-store-logo-url');
        const previewImg = document.getElementById('set-store-logo-preview');
        if (urlInput) urlInput.value = compressedBase64;
        if (previewImg) previewImg.src = compressedBase64;
        if (typeof window.showToast === 'function') window.showToast("✅ Store logo ready! Click 'Save Global Config' to save.", "success");
    } catch (e) {
        console.error("Logo upload error:", e);
        if (typeof window.showToast === 'function') window.showToast("❌ Failed to process logo image.", "error");
    }
};

window.clearStoreLogo = () => {
    const urlInput = document.getElementById('set-store-logo-url');
    const previewImg = document.getElementById('set-store-logo-preview');
    if (urlInput) urlInput.value = "";
    if (previewImg) previewImg.src = "/logo.png";
    if (typeof window.showToast === 'function') window.showToast("Cleared store logo field. Save config to apply.", "info");
};

// --- DYNAMIC MULTI-THEME ENGINE (VISUAL APPEARANCE) ---
const THEME_CLASS_MAP = {
    'cyber-neon': 'theme-cyber-neon',
    'pearl-light': 'theme-pearl-light',
    'corporate-royal': 'theme-corporate-royal',
    'emerald-pro': 'theme-emerald-pro',
    'crimson-lux': 'theme-crimson-lux',
    'obsidian-midnight': 'theme-obsidian-midnight',
    // Legacy aliases
    'cyber': 'theme-cyber-neon',
    'mec-light': 'theme-pearl-light',
    'original': 'theme-corporate-royal',
    'emerald': 'theme-emerald-pro',
    'crimson': 'theme-crimson-lux'
};

window.setAdminTheme = (themeKey, skipToast = false) => {
    try {
        const canonicalKey = THEME_CLASS_MAP[themeKey] ? (THEME_CLASS_MAP[themeKey].replace('theme-', '')) : 'emerald-pro';
        const targetClass = THEME_CLASS_MAP[canonicalKey] || 'theme-emerald-pro';

        // 1. Remove all existing theme classes from body
        Object.values(THEME_CLASS_MAP).forEach(cls => {
            document.body.classList.remove(cls);
        });

        // 2. Add new target theme class
        document.body.classList.add(targetClass);

        // 3. Save to localStorage
        localStorage.setItem('mec_active_theme', canonicalKey);

        // 4. Update UI active badges and card highlight rings
        document.querySelectorAll('.theme-active-badge').forEach(b => b.style.display = 'none');
        document.querySelectorAll('.theme-card').forEach(c => {
            c.style.boxShadow = '0 10px 30px rgba(0,0,0,0.3)';
            c.style.transform = 'scale(1)';
        });

        const activeBadge = document.getElementById(`badge-theme-${canonicalKey}`);
        if (activeBadge) activeBadge.style.display = 'inline-block';

        const activeCard = document.getElementById(`card-theme-${canonicalKey}`);
        if (activeCard) {
            activeCard.style.boxShadow = '0 0 0 3px var(--primary-blue), 0 20px 40px rgba(0,0,0,0.4)';
            activeCard.style.transform = 'scale(1.02)';
        }

        if (!skipToast && typeof window.showToast === 'function') {
            const themeNames = {
                'cyber-neon': '🌌 Cyber Neon Dark',
                'pearl-light': '🕊️ Pure Minimalist Pearl',
                'corporate-royal': '💎 Modern Corporate Royal',
                'emerald-pro': '🌲 Emerald Forest Pro',
                'crimson-lux': '🍷 Crimson Luxury',
                'obsidian-midnight': '🪐 Obsidian Midnight'
            };
            window.showToast(`✨ Applied theme: ${themeNames[canonicalKey] || canonicalKey}`, 'success');
        }
    } catch (e) {
        console.error("Theme switch error:", e);
    }
};

// Bootstrap active theme on load
(function() {
    const savedTheme = localStorage.getItem('mec_active_theme') || 'emerald-pro';
    window.setAdminTheme(savedTheme, true);
})();
