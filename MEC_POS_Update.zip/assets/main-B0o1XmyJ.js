/* empty css              */import{G as bt}from"./index-D2360V5-.js";import{a as re,c as E,d as k,s as G,o as Ie,q as T,w as S,g as A,b as W,e as ce,i as xe,f as st,h as yt,u as lt,j as wt,l as ht,k as vt,m as xt,n as Xe}from"./firebase-CVcZ1MF3.js";window.uploadLogToCloud=async(e,t="error")=>{try{const n=window.currentStoreId||"unknown",i=window.HostPCName||navigator.userAgent||"WebBrowser";await re(E(k,"systemLogs"),{message:e,level:t,storeId:n,pcName:i,timestamp:G()})}catch(n){console.error("Failed to upload log:",n)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function kt(){try{const e=localStorage.getItem("mecThemeColors");if(e){const t=JSON.parse(e),n=document.documentElement;n.style.setProperty("--primary-blue",t.primary),n.style.setProperty("--accent-blue",t.accent),n.style.setProperty("--admin-bg",t.bg),n.style.setProperty("--glass-bg",t.glass),n.style.setProperty("--primary-color",t.primary),n.style.setProperty("--secondary-color",t.accent),n.style.setProperty("--deep-bg",t.bg),t.bg==="#0f172a"||t.bg==="#11011c"||t.bg==="#022c22"?(n.style.setProperty("--text-dark","#f8fafc"),n.style.setProperty("--text-muted","#94a3b8")):(n.style.setProperty("--text-dark","#0f172a"),n.style.setProperty("--text-muted","#64748b"))}}catch{}}kt();function be(){const e=document.querySelector("header");if(e){const n=e.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(n)}px`)}const t=document.getElementById("product-grid-header");if(t&&e){const n=e.getBoundingClientRect().height,o=t.getBoundingClientRect().top<=Math.round(n)+2;t.classList.toggle("is-stuck",o)}}window.addEventListener("resize",be);window.addEventListener("scroll",be,{passive:!0});document.addEventListener("DOMContentLoaded",be);setTimeout(be,200);setTimeout(be,800);const dt=new URLSearchParams(window.location.search),ne=window.location.pathname.split("/").filter(e=>e!=="");let ze=null;ne[0]==="store"&&ne[1]?ze=ne[1]:ne[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(ne[0])&&(ze=ne[0]);const St=dt.get("store")||ze;window.currentStoreId=St||null;window.currentStoreData=null;try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const ve=E(k,"stores"),le=window.location.hostname;async function It(){let e=null;try{if(window.currentStoreId){const t=T(ve,S("slug","==",window.currentStoreId)),n=await A(t);if(!n.empty)e={...n.docs[0].data(),docId:n.docs[0].id};else try{const i=W(k,"stores",window.currentStoreId),o=await st(i);o.exists()&&(e={...o.data(),docId:o.id})}catch{}}else if(["mecbookshop.web.lk","mecbookshop.com.lk","mec-book-shop.web.app","localhost","127.0.0.1"].includes(le)){window.currentStoreId="mec-book-shop";const n=T(ve,S("slug","==","mec-book-shop")),i=await A(n);i.empty||(e={...i.docs[0].data(),docId:i.docs[0].id})}else if(le==="mecpos.web.lk"||le==="mec-pos-shop.web.app"||le==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const n=le.replace(/^www\./,""),i=T(ve,S("domain","==",n)),o=await A(i);o.empty||(e={...o.docs[0].data(),docId:o.docs[0].id})}}catch(t){console.error("Store resolution query failed:",t)}if(e)window.currentStoreData=e,window.currentStoreId=e.slug||e.storeSlug||e.docId||"mec-book-shop",console.log("Resolved Store ID:",window.currentStoreId),Ze(),tt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{window.currentStoreId||(window.currentStoreId="mec-book-shop");try{const n=T(ve,S("slug","==","mec-book-shop")),i=await A(n);i.empty||window.currentStoreId==="mec-book-shop"&&(window.currentStoreData=i.docs[0].data())}catch(n){console.error("Error loading fallback store data:",n)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),Ze(),tt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}It();function Ze(){var x,u,f,g,b,w,B,h,P,I,$,L,z,M,_;let e=(x=window.currentStoreData)==null?void 0:x.name;e||(window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?e=window.currentStoreId.split("-").map(C=>C.charAt(0).toUpperCase()+C.slice(1)).join(" "):e="MEC Book Shop"),e==="MEC POS"&&(e="MEC Book Shop"),document.title=`${e} | Official Store`;const t=(f=(u=window.currentStoreData)==null?void 0:u.webDesign)==null?void 0:f.primary,n=(b=(g=window.currentStoreData)==null?void 0:g.webDesign)==null?void 0:b.accent;t&&document.documentElement.style.setProperty("--primary-color",t),n&&document.documentElement.style.setProperty("--secondary-color",n),document.querySelectorAll(".logo-text").forEach(C=>{C.innerText=e});const i=window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master";i?(document.querySelectorAll(".bookshop-brand-banner").forEach(C=>C.style.display="none"),document.querySelectorAll(".merchant-only").forEach(C=>C.style.display="")):(document.querySelectorAll(".bookshop-brand-banner").forEach(C=>C.style.display="block"),document.querySelectorAll(".merchant-only").forEach(C=>C.style.display="none"));const o=(w=window.currentStoreData)==null?void 0:w.logoUrl,s=o&&o.trim()!==""&&!o.includes("zenith_logo")&&!o.includes("/logo.png")?o:"/mec-logo.png";document.querySelectorAll(".logo-img, #pwa-install-banner img").forEach(C=>{C.src=s,C.style.display=i?"":C.classList.contains("merchant-only")?"none":""});const r=document.getElementById("hero");if(r){const C=(h=(B=window.currentStoreData)==null?void 0:B.webDesign)==null?void 0:h.bannerUrl,D=C&&C.length>10?C:window.currentStoreId==="mec-book-shop"?"/banner.png":null;if(D)r.innerHTML=`
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${D}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `;else{const X=((I=(P=window.currentStoreData)==null?void 0:P.webContent)==null?void 0:I.welcome)||`Welcome to ${e}`,Le=((L=($=window.currentStoreData)==null?void 0:$.webContent)==null?void 0:L.announce)||"Your premium destination for high-quality products and services.";r.innerHTML=`
        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">
          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${X}</h1>
          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${Le}</p>
          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>
        </div>
      `}}const d=document.getElementById("page-title");d&&(d.innerText=`${e} | Official Store`);const a=document.getElementById("footer-copy");a&&(a.innerText=`© 2026 ${e}. All rights reserved.`);const l=((z=window.currentStoreData)==null?void 0:z.webEpinics)||{},c=!!l.multiVendor,p=!!l.affiliate;(M=document.getElementById("nav-sell-with-us"))==null||M.remove(),(_=document.getElementById("nav-affiliate-program"))==null||_.remove();const m=document.getElementById("nav-menu");if(m){const C=document.getElementById("nav-auth-item");if(c){const D=document.createElement("li");D.id="nav-sell-with-us",D.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',C?m.insertBefore(D,C):m.appendChild(D)}if(p){const D=document.createElement("li");D.id="nav-affiliate-program",D.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',C?m.insertBefore(D,C):m.appendChild(D)}}document.documentElement.classList.remove("loading-merchant")}let de;const Y=document.createElement("div");Y.id="pwa-install-banner";Y.innerHTML=`
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>
            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>
        </div>
        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;Y.style.display="none";document.body.appendChild(Y);window.addEventListener("beforeinstallprompt",e=>{e.preventDefault(),de=e,Y.style.display="block"});Y.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){Y.style.display="none";return}if(de){de.prompt();const{outcome:t}=await de.userChoice;t==="accepted"&&(Y.style.display="none"),de=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const j=document.getElementById("menu-toggle"),J=document.getElementById("nav-menu"),K=document.getElementById("mobile-menu-overlay"),Ce=()=>{J==null||J.classList.remove("active"),j==null||j.classList.remove("active"),K==null||K.classList.remove("active")};j==null||j.addEventListener("click",()=>{const e=J==null?void 0:J.classList.toggle("active");j==null||j.classList.toggle("active"),e?K==null||K.classList.add("active"):K==null||K.classList.remove("active")});const Ae=document.getElementById("close-menu");Ae==null||Ae.addEventListener("click",Ce);K==null||K.addEventListener("click",Ce);J==null||J.querySelectorAll("a").forEach(e=>{e.addEventListener("click",Ce)});function ye(e,t){var i;if(typeof e=="string"&&e.trim()!==""){const o=e.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const n=(i=window.currentStoreData)==null?void 0:i.logoUrl;return n&&n.trim()!==""&&!n.includes("zenith_logo.png")&&!n.includes("/logo.png")?n:"/mec-logo.png"}const Ct=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}],qe=E(k,"products"),Pt=E(k,"orders"),Bt=E(k,"promotions"),Et=E(k,"branches"),$t=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let et=[];Ie(Et,e=>{et=e.docs.map(t=>({...t.data(),docId:t.id})),window.allStoreBranches=et,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function pe(){var i,o,s,r;const e=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master";let t=(window.allStoreBranches||[]).filter(d=>e||d.storeId===window.currentStoreId||!d.storeId);const n={docId:"main",name:(((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop")+" - Main Branch",location:((o=window.currentStoreData)==null?void 0:o.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",address:((s=window.currentStoreData)==null?void 0:s.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",city:"Horana",district:"Kalutara",phone:((r=window.currentStoreData)==null?void 0:r.phone)||"071 923 3388"};return t.length===0&&(t=[n]),t}window.getAllAvailableShops=pe;function ct(){const t=pe().map(i=>(i.location||i.city||"").trim()).filter(i=>i.length>0);return Array.from(new Set([...t,...$t])).filter(Boolean).sort((i,o)=>i.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=ct;let O=[],we=0,v=[],te="All",R=1,Ne=12,ae="recommended",V="",De=null;document.getElementById("cart-count");window.webStoreBankAccounts={slot1:{docId:"ndb_default",bankName:"National Development Bank (NDB)",badge:"NDB",accountName:"MEC BOOK SHOP & COMMUNICATION",accountType:"Regular Current",bankCode:"7214",swiftCode:"NDBSLKLX",accountNo:"111000391437"},slot2:{docId:"boc_default",bankName:"Bank of Ceylon (BOC)",badge:"BOC",accountName:"WPM Shamesh",branch:"Horana Branch",bankCode:"",swiftCode:"",accountType:"Savings",accountNo:"0084334885"}};window.selectedWebStoreBankSlot="slot1";window.selectWebStoreBankSlot=e=>{window.selectedWebStoreBankSlot=e;const t=document.getElementById("web-bank-card-1"),n=document.getElementById("web-bank-card-2"),i=document.getElementById("web-slot-1-radio"),o=document.getElementById("web-slot-2-radio"),s=document.getElementById("web-bank-1-badge"),r=document.getElementById("web-bank-2-badge");e==="slot1"?(i&&(i.checked=!0),o&&(o.checked=!1),t&&(t.style.background="#f0fdf4",t.style.borderColor="#16a34a",t.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),n&&(n.style.background="#ffffff",n.style.borderColor="#cbd5e1",n.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),s&&(s.style.background="#16a34a",s.style.color="#ffffff",s.innerText="✓ Selected"),r&&(r.style.background="#f1f5f9",r.style.color="#64748b",r.innerText="Click to select")):(i&&(i.checked=!1),o&&(o.checked=!0),n&&(n.style.background="#f0fdf4",n.style.borderColor="#16a34a",n.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),t&&(t.style.background="#ffffff",t.style.borderColor="#cbd5e1",t.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),r&&(r.style.background="#16a34a",r.style.color="#ffffff",r.innerText="✓ Selected"),s&&(s.style.background="#f1f5f9",s.style.color="#64748b",s.innerText="Click to select"))};window.copyBankDetails=(e,t)=>{const n=document.getElementById(e);if(!n)return;const i=n.innerText.trim();navigator.clipboard.writeText(i),alert(`${t} Copied: ${i}`)};window.updateWebStoreBankCardsUI=()=>{var n,i;const e=(n=window.webStoreBankAccounts)==null?void 0:n.slot1,t=(i=window.webStoreBankAccounts)==null?void 0:i.slot2;if(e){const o=document.getElementById("web-bank-1-title"),s=document.getElementById("web-bank-1-accname"),r=document.getElementById("web-bank-1-accno"),d=document.getElementById("web-bank-1-acctype"),a=document.getElementById("web-bank-1-code"),l=document.getElementById("web-bank-1-swift");o&&e.bankName&&(o.innerText=`🏦 ${e.bankName}`),s&&e.accountName&&(s.innerText=e.accountName),r&&e.accountNo&&(r.innerText=e.accountNo),d&&e.accountType&&(d.innerText=e.accountType),a&&e.bankCode&&(a.innerText=e.bankCode),l&&e.swiftCode&&(l.innerText=e.swiftCode)}if(t){const o=document.getElementById("web-bank-2-title"),s=document.getElementById("web-bank-2-accname"),r=document.getElementById("web-bank-2-accno"),d=document.getElementById("web-bank-2-branch");o&&t.bankName&&(o.innerText=`🏦 ${t.bankName}`),s&&t.accountName&&(s.innerText=t.accountName),r&&t.accountNo&&(r.innerText=t.accountNo),d&&t.branch&&(d.innerText=t.branch)}};function Lt(){try{const e=localStorage.getItem("mec_webstore_bank_config");if(e){const t=JSON.parse(e);t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data})}}catch{}try{Ie(W(k,"config","webstore_bank_accounts"),e=>{if(e.exists()){const t=e.data();t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data}),window.updateWebStoreBankCardsUI()}},e=>console.warn("Web store banks config snapshot warning:",e))}catch(e){console.warn("Could not setup webstore banks listener:",e)}}Lt();function tt(){let e=window.currentStoreId||"mec-book-shop";e==="master"&&(e="mec-book-shop");const t=E(k,"stores",e,"products");let n=T(t);Ie(n,i=>{const o=i.docs.map(r=>({...r.data(),id:r.id,docId:r.id,sku:r.data().sku||r.id}));if((window.currentStoreId==="mec-book-shop"||window.currentStoreId==="O8ywuZTKSwdL4z77RQ9M"||window.currentStoreId==="master")&&!o.some(d=>d.name&&d.name.trim().toLowerCase()==="other")&&i.docs.length>0){console.log("Auto-creating 'Other' product for MEC Book Shop...");const d={name:"Other",sku:"SKU-OTHER-0000-GEN-P1C0",category:"Uncategorized",mode:"Shop",supplierId:"General",supplierName:"General",cost:0,price:1,wholesalePrice:1,loyaltyPrice:1,discount:0,stock:999999,wStock:0,totalStock:999999,timestamp:G(),salesToday:0,image:"",variants:[],payMethods:{cod:!0,bank:!0,shop:!0},storeId:window.currentStoreId};d.docId=d.sku,ce(W(k,"products",d.sku),d).catch(a=>console.error("Error creating 'Other' product:",a))}O=o.filter(r=>{const a=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?r.storeId==="mec-book-shop"||r.storeId==="master"||!r.storeId:r.storeId===window.currentStoreId,l=r.mode==="Shop"||r.mode==="Warehouse"||r.mode===void 0,c=r.status!=="pending";return a&&l&&c}),O.sort((r,d)=>{var a,l;return(((a=d.timestamp)==null?void 0:a.seconds)||0)-(((l=r.timestamp)==null?void 0:l.seconds)||0)}),O.length===0&&window.currentStoreId==="master"&&Ct.forEach(async r=>{await re(qe,r)}),U(),Pe()})}var rt;(rt=document.getElementById("product-sort"))==null||rt.addEventListener("change",e=>{ae=e.target.value,R=1,U()});const Tt=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.addEventListener("input",t=>{V=t.target.value.toLowerCase(),window.searchQuery=V,document.querySelectorAll("#store-search, .store-search-input").forEach(n=>{n!==t.target&&(n.value=t.target.value)}),R=1,U()})})};Tt();window.renderProducts=U;window.clearSearch=()=>{V="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.value=""}),R=1,U()};function Ue(){localStorage.setItem("mec_cart",JSON.stringify(v))}function At(){const e=localStorage.getItem("mec_cart");e&&(v=JSON.parse(e),we=v.reduce((t,n)=>t+(n.quantity||1),0),Ee())}const ue=document.createElement("div");ue.id="cart-modal";document.body.appendChild(ue);const me=document.createElement("div");me.id="cart-overlay";document.body.appendChild(me);window.toggleCart=e=>{e?(ue.classList.add("active"),me.classList.add("active"),$e(),document.body.style.overflow="hidden"):(ue.classList.remove("active"),me.classList.remove("active"),document.body.style.overflow="")};const he=window.toggleCart;me.onclick=()=>he(!1);const Nt=document.querySelectorAll('a[href="#cart"]');Nt.forEach(e=>{e.onclick=t=>{t.preventDefault(),Ce(),he(!0)}});const ot=document.getElementById("shop-now-btn");ot&&ot.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const pt={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function Dt(){return["All",...new Set(O.map(t=>t.category))]}function Pe(){const e=Dt(),t=document.getElementById("sidebar-category-list"),n=document.getElementById("mobile-category-bar");t&&(t.innerHTML=e.map(r=>`
      <li class="sidebar-cat-item ${r===te?"active":""}" data-category="${r}">
        <div class="cat-icon-text">
          <span class="cat-icon">${pt[r]||"📁"}</span>
          <span>${r}</span>
        </div>
        <span class="arrow">›</span>
      </li>
    `).join("")),n&&(n.innerHTML=e.map(r=>`
      <button class="mobile-cat-btn ${r===te?"active":""}" data-category="${r}">
        ${r}
      </button>
    `).join(""));const i=r=>{var a;te=r;const d=document.getElementById("featured-title");d&&(d.innerText=r==="All"?"Featured Collection":`${r} Collection`),U(),Pe(),Q(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(r=>{r.addEventListener("click",d=>{d.stopPropagation(),i(d.currentTarget.dataset.category)}),r.addEventListener("mouseenter",d=>{const a=d.currentTarget.dataset.category;a!=="All"?zt(a,d.currentTarget):Q()})}),document.querySelectorAll(".mobile-cat-btn").forEach(r=>{r.addEventListener("click",d=>i(d.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),s=document.getElementById("nav-category-btn");s&&o&&(s.onclick=r=>{r.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),Q()})}document.addEventListener("click",e=>{const t=document.querySelector(".category-menu-wrapper");t&&!t.contains(e.target)&&(t.classList.remove("active"),typeof Q=="function"&&Q())});const H=document.getElementById("mega-menu");let Be;function zt(e,t){if(!H)return;clearTimeout(Be),document.querySelectorAll(".sidebar-cat-item").forEach(a=>a.classList.remove("active")),t==null||t.classList.add("active");const n=(O||[]).filter(a=>a.category===e),i={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`
      <div style="margin-bottom: 1.1rem;">
        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>
        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">
          <span>${pt[e]||"📁"}</span>
          <span>${e}</span>
        </div>
        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${n.length} Items Available</div>
      </div>
      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">
        <span>View All</span>
        <span>→</span>
      </button>
      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        ${i.map(a=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${a}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${a}</a>`).join("")}
      </div>
    `);const s=document.getElementById("mega-products-heading");s&&(s.innerText=`${e} Products (${n.length})`);const r=document.getElementById("mega-products-list");r&&(r.innerHTML=n.length>0?n.map(a=>`
          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${a.docId}')">
            <img src="${ye(a.image,a.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">
            <div class="mega-prod-info">
              <h5 title="${a.name}">${a.name}</h5>
              <div class="price">LKR ${Number(a.price||0).toFixed(2)}</div>
            </div>
          </a>
        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),H.style.top="calc(100% + 8px)",H.style.left="248px",H.classList.add("active");const d=H.getBoundingClientRect();if(d.right>window.innerWidth-16){const a=d.right-(window.innerWidth-16);H.style.left=`${Math.max(0,248-a)}px`}}function Q(){Be=setTimeout(()=>{H==null||H.classList.remove("active")},400)}H==null||H.addEventListener("mouseenter",()=>clearTimeout(Be));var it;(it=document.getElementById("sidebar-category-list"))==null||it.addEventListener("mouseenter",()=>clearTimeout(Be));window.filterByCategoryAndScroll=e=>{var n;te=e;const t=document.getElementById("featured-title");t&&(t.innerText=e==="All"?"Featured Collection":`${e} Collection`),U(),Pe(),Q(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,t)=>{var i;te=t,U(),Pe();const n=document.getElementById("featured-title");n&&(n.innerText=`${e} in ${t}`),(i=document.getElementById("shop-section"))==null||i.scrollIntoView({behavior:"smooth"}),Q()};window.scrollToProduct=e=>{const t=document.getElementById(`product-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"center"}),t.classList.add("highlight-pulse"),setTimeout(()=>t.classList.remove("highlight-pulse"),3e3),Q())};function ie(e,t=null,n=null){var p;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const i=(n||((p=window.currentUserProfile)==null?void 0:p.customerType)||"retail").toLowerCase();let o=0,s=0,r=0;t?(o=Number(t.price),(isNaN(o)||o<=0)&&(o=Number(e.price)||0),s=Number(t.wholesalePrice),(isNaN(s)||s<=0)&&(s=Number(e.wholesalePrice)||0),r=Number(t.loyaltyPrice),(isNaN(r)||r<=0)&&(r=Number(e.loyaltyPrice)||0)):(o=Number(e.price)||0,s=Number(e.wholesalePrice)||0,r=Number(e.loyaltyPrice)||0),isNaN(o)&&(o=0);let d=o,a=!1;i==="wholesale"&&s>0?(d=s,a=s!==o):i==="loyalty"&&r>0&&(d=r,a=r!==o);const l=Number(e.discount)||0,c=d*(1-(l>0?l/100:0));return{retailPrice:isNaN(o)?0:o,effectivePrice:isNaN(d)?0:d,discountedPrice:isNaN(c)?0:c,isSpecial:a,userType:i}}window.getCustomerEffectivePrice=ie;function ge(e,t=null){return Fe(e,t,"web")}function Fe(e,t=null,n="web"){if(!e)return 0;if(n==="ShopPay"||n==="shop"||n==="Shop"){if(t){const s=parseFloat(t.stock)||0;if(s>0)return s}const o=parseFloat(e.stock||0);return o>0?o:0}else{if(t){const a=parseFloat(t.stock)||0,l=parseFloat(t.wStock)||0,c=a+l;if(c>0)return c}if(e.variants&&e.variants.length>0){const a=e.variants.reduce((l,c)=>l+(parseFloat(c.stock)||0)+(parseFloat(c.wStock)||0),0);if(a>0)return a}const o=parseFloat(e.stock||0),s=parseFloat(e.wStock||0),r=parseFloat(e.totalStock||0),d=o+s;return d>0?d:r>0?r:0}}const fe=document.getElementById("product-detail-modal"),Ke=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const t=(window.groupedProducts||[]).find(u=>u.docId===e)||O.find(u=>u.docId===e);if(!t)return;const n=Number(t.discount)||0,i=t.variants&&t.variants.length>0,o=i?t.variants[0]:null;let s=t.image;o&&(o.image?s=o.image:o.images&&o.images.length>0&&(s=o.images[0]));const r=ie(t,o),d=r.userType,a=r.isSpecial,l=r.retailPrice,c=r.discountedPrice,p=ge(t,o),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let x="";if(i){const u=[...new Set(t.variants.map(g=>g.size).filter(Boolean))],f=[...new Set(t.variants.map(g=>g.color).filter(Boolean))];if(u.length>0||f.length>0){let g="";f.length>0&&(g=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Color</span>
              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||f[0]}</span>
            </div>
            <div class="variant-pill-container" id="color-pill-group">
              ${f.map(w=>{const B=m[w.toLowerCase()]||"#64748b";return`
                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||f[0])===w?"active":""}" 
                    style="background-color: ${B};" 
                    title="${w}" data-color="${w}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'color', '${w}')">
                  </button>
                `}).join("")}
            </div>
          </div>
        `);let b="";u.length>0&&(b=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Style / Size</span>
              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>
            </div>
            <div class="variant-pill-container" id="size-pill-group">
              ${u.map(w=>`
                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===w?"active":""}" 
                    data-size="${w}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'size', '${w}')">
                    ${w}
                  </button>
                `).join("")}
            </div>
          </div>
        `),x=`${g}${b}`}else x=`
        <div class="variant-selector-group">
          <div class="variant-selector-label">
            <span>Choose Option / MRP</span>
          </div>
          <div class="variant-pill-container">
            ${t.variants.map((g,b)=>{const w=ge(t,g);return`
              <div class="variant-mrp-card ${b===0?"active":""}" id="v-card-${b}"
                   onclick="window.updateDetailDisplay('${t.docId}', ${b})">
                <div style="flex:1;">
                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${g.name||g.variantLabel||g.color||g.size||`Option ${b+1}`}</div>
                  <div style="font-size: 0.75rem; color: #64748b;">${w>0?`In Stock (${w})`:"Out of stock"}</div>
                </div>
                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">
                  LKR ${(g.price||t.price||0).toLocaleString()}
                </div>
              </div>
            `}).join("")}
          </div>
        </div>
      `}fe.innerHTML=`
        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>
        <div class="detail-content">
            <div class="detail-image-sec">
                <img src="${ye(s,t.name)}" id="detail-main-img" 
                    alt="${t.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">
            </div>

            <div class="detail-info-sec">
                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${t.category}</div>
                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${t.name}</h2>
                ${a?`<div style="font-size: 0.8rem; color: ${d==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${d.toUpperCase()} APPLIED</div>`:""}
                
                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">
                    ${n>0||a?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}
                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${c.toFixed(2)}</span>
                </div>
                
                ${x}

                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">
                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}
                </div>
                
                <div class="detail-actions-sec">
                    <button class="add-to-cart-btn detail-add-btn" 
                            onclick="window.handleDetailAddToCart('${t.docId}')">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `,window.activeDetailVariantIndex=0,fe.classList.add("active"),Ke.classList.add("active"),document.body.style.overflow="hidden",Q(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,t,n)=>{const i=(window.groupedProducts||[]).find(r=>r.docId===e)||O.find(r=>r.docId===e);if(!i||!i.variants)return;const o=window.activeDetailVariantIndex||0;i.variants[o]||i.variants[0];let s=i.variants.findIndex(r=>t==="color"?r.color===n:t==="size"?r.size===n:!1);if(s===-1&&(s=0),t==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(d=>{d.classList.toggle("active",d.dataset.color===n)});const r=document.getElementById("detail-selected-color");r&&(r.innerText=n)}if(t==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(d=>{d.classList.toggle("active",d.dataset.size===n)});const r=document.getElementById("detail-selected-size");r&&(r.innerText=n)}window.updateDetailDisplay(e,s)};window.closeProductDetail=()=>{fe.classList.remove("active"),Ke.classList.remove("active"),document.body.style.overflow=""};Ke.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,t)=>{window.activeDetailVariantIndex=Number(t);const n=(window.groupedProducts||[]).find(c=>c.docId===e)||O.find(c=>c.docId===e);if(!n)return;const i=n.variants&&n.variants.length>0?n.variants[t]:null,o=document.getElementById("detail-main-img"),s=document.getElementById("detail-stock"),r=fe.querySelector(".detail-original-price"),d=fe.querySelector(".detail-final-price");if(o){let c=n.image;i&&(i.image?c=i.image:i.images&&i.images.length>0&&(c=i.images[0])),o.src=ye(c,n.name)}document.querySelectorAll(".variant-mrp-card").forEach((c,p)=>{c.classList.toggle("active",p===Number(t))}),Number(n.discount);const a=ie(n,i);r&&(r.innerText=`LKR ${a.retailPrice.toFixed(2)}`),d&&(d.innerText=`LKR ${a.discountedPrice.toFixed(2)}`);const l=ge(n,i);if(s){const c=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";s.innerHTML=c,s.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const t=(window.groupedProducts||[]).find(p=>p.docId===e)||O.find(p=>p.docId===e);if(!t)return;const n=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let i="Default",o=null;t.variants&&t.variants.length>0&&(o=t.variants[n]||t.variants[0],i=o.name||o.variantLabel||o.color||o.size||"Default");const r=ie(t,o).effectivePrice,d=o&&o.cost!==void 0?Number(o.cost):Number(t.cost)||0,a=ge(t,o),l=v.findIndex(p=>p.docId===t.docId&&p.selectedVariant===i),c=l!==-1?(v[l].quantity||1)+1:1;if(t.mode!=="Service"&&t.mode!=="Technical"&&c>a){alert(`Sorry, out of stock! Only ${a} available.`);return}Mt(t,i,r,d),window.closeProductDetail(),he(!0)};function Mt(e,t,n,i){const o=v.findIndex(s=>s.docId===e.docId&&s.selectedVariant===t);o!==-1?v[o].quantity=(v[o].quantity||1)+1:v.push({...e,selectedVariant:t,price:n,cost:i,quantity:1}),we=v.reduce((s,r)=>s+(r.quantity||1),0),Ue(),Ee()}window.changeCartQty=(e,t,n)=>{var o;const i=v.findIndex(s=>s.docId===e&&s.selectedVariant===t);if(i!==-1){if(n>0){const s=O.find(r=>r.docId===e);if(s&&s.mode!=="Service"&&s.mode!=="Technical"){let r=null;t!=="Default"&&s.variants&&(r=s.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===t));const d=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",a=Fe(s,r,d);if((v[i].quantity||1)+n>a){alert(d==="ShopPay"?`Sorry! Only ${a} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${a} available.`);return}}}v[i].quantity=(v[i].quantity||1)+n,v[i].quantity<=0&&v.splice(i,1),we=v.reduce((s,r)=>s+(r.quantity||1),0),Ue(),Ee(),$e()}};function Ee(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(t=>{t&&(t.innerText=we,t.classList.add("bump"),setTimeout(()=>t.classList.remove("bump"),300))})}function He(e,t,n){if(!e||!t||t.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let i=t;if(e.targetType==="specific_products"){const r=(e.selectedProducts||[]).map(d=>(d||"").trim().toLowerCase());if(i=t.filter(d=>{const a=(d.name||"").trim().toLowerCase(),l=(d.docId||"").trim().toLowerCase();return r.includes(a)||r.includes(l)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const r=(e.selectedCategories||[]).map(d=>(d||"").trim().toLowerCase());if(i=t.filter(d=>{const a=(d.category||"").trim().toLowerCase();return r.includes(a)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const o=i.reduce((r,d)=>{const a=d.discount||0,l=d.price*(1-a/100),c=d.quantity||1;return r+l*c},0);let s=0;return e.type==="Percentage"?s=o*(Number(e.value)/100):s=Math.min(o,Number(e.value)||0),{discountAmount:s,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function $e(){var i;const e=v.reduce((o,s)=>{const r=s.discount||0,d=s.price*(1-r/100),a=s.quantity||1;return o+d*a},0);let t=0;if(window.appliedCoupon){const o=He(window.appliedCoupon,v);o.isValidForCart?t=o.discountAmount:window.appliedCoupon=null}const n=Math.max(0,e-t);ue.innerHTML=`
        <div class="cart-header">
            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>
            <button class="close-cart" id="close-cart-btn">&times;</button>
        </div>
        
        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">
            <div class="cart-body">
                ${v.length===0?`
                    <div class="cart-empty-state">
                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>
                        <p>Your cart is empty</p>
                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>
                    </div>
                `:v.map(o=>{const s=o.discount||0,r=o.price*(1-s/100),d=o.quantity||1,a=r*d;return`
                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">
                            <div class="cart-item-info" style="flex: 1;">
                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>
                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>
                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">
                                    ${s>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}
                                    LKR ${r.toFixed(2)} ${d>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${d} = LKR ${a.toFixed(2)}</span>`:""}
                                </div>
                            </div>
                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 
                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">
                                    -
                                </button>
                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${d}</span>
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 
                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">
                                    +
                                </button>
                            </div>
                        </div>
                    `}).join("")}
            </div>

            ${v.length>0?`
                <div class="cart-footer">
                    <div class="delivery-info-banner">
                        <span>🚚</span>
                        <span>COD LKR 400 | Bank Transfer LKR 250</span>
                    </div>

                    <!-- Promo / Coupon Code Section -->
                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; gap: 0.5rem;">
                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>
                            ${window.appliedCoupon?`
                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>
                            `:`
                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>
                            `}
                        </div>
                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">
                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}
                        </div>
                    </div>
                    
                    ${window.appliedCoupon?`
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">
                            <span>Subtotal</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">
                            <span>Coupon Discount (${window.appliedCoupon.code})</span>
                            <span>- LKR ${t.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">
                            <span>Total Payable</span>
                            <span>LKR ${n.toFixed(2)}</span>
                        </div>
                    `:`
                        <div class="cart-subtotal">
                            <span>Total Payable</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="checkout-form-section">
                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>
                        <div class="input-group">
                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">
                        </div>
                        <div class="input-group">
                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">
                        </div>
                        <div class="input-group" id="delivery-address-group">
                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">
                        </div>
                        <div class="input-group" id="delivery-city-group">
                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">
                        </div>

                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>
                        <div class="payment-method-selector">
                            ${v.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">
                                <span class="method-label">COD</span>
                            </label>
                            `:""}
                            ${v.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="Bank" ${v.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">
                                <span class="method-label">Transfer</span>
                            </label>
                            `:""}
                            ${v.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="ShopPay" ${!v.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!v.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">
                                <span class="method-label">Shop Cash</span>
                            </label>
                            `:""}
                        </div>
                        
                        <!-- Bank Transfer Info Box -->
                        <div id="bank-details-box" style="display: none;">
                            <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.75rem;">
                                <p style="color: #065f46; font-weight: 800; margin: 0; font-size: 0.82rem; display: flex; align-items: center; gap: 6px;">
                                    <span>✨</span> Lower delivery charge (LKR 250)
                                </p>
                                <p style="color: #047857; margin: 3px 0 0; font-size: 0.75rem; font-weight: 600;">
                                    👇 Select the Bank Account you transferred to (ඔබ මුදල් තැන්පත් කළ ගිණුම තෝරන්න):
                                </p>
                            </div>

                            <!-- Account 1: Slot 1 (e.g. NDB) -->
                            <div id="web-bank-card-1" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot1')" style="background: #f0fdf4 !important; color: #0f172a !important; border: 2px solid #16a34a !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.15); cursor: pointer; transition: all 0.2s; position: relative;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-1-radio" value="slot1" checked style="accent-color: #16a34a; width: 18px; height: 18px; cursor: pointer;">
                                        <span id="web-bank-1-title" style="font-weight: 900; color: #b91c1c; font-size: 0.95rem;">🏦 National Development Bank (NDB)</span>
                                    </div>
                                    <span id="web-bank-1-badge" style="font-size: 0.72rem; background: #16a34a; color: #ffffff; padding: 3px 8px; border-radius: 6px; font-weight: 800;">✓ Selected</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">
                                    <span>Account Name: <span id="web-bank-1-accname" style="color: #0f172a; font-weight: 700;">MEC BOOK SHOP & COMMUNICATION</span></span>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div id="web-bank-1-type-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">
                                    Account Type: <span id="web-bank-1-acctype" style="color: #0f172a; font-weight: 700;">Regular Current</span>
                                </div>
                                <div id="web-bank-1-codes-row" style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">
                                    <span>Bank Code: <strong id="web-bank-1-code" style="color: #334155;">7214</strong></span>
                                    <span>Swift Code: <strong id="web-bank-1-swift" style="color: #334155;">NDBSLKLX</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; border: 1.5px dashed #16a34a; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span id="web-bank-1-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>
                                    </div>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accno', 'Account Number');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <!-- Account 2: Slot 2 (e.g. BOC) -->
                            <div id="web-bank-card-2" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot2')" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1 !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: all 0.2s; position: relative;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-2-radio" value="slot2" style="accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">
                                        <span id="web-bank-2-title" style="font-weight: 900; color: #0284c7; font-size: 0.95rem;">🏦 Bank of Ceylon (BOC)</span>
                                    </div>
                                    <span id="web-bank-2-badge" style="font-size: 0.72rem; background: #f1f5f9; color: #64748b; padding: 3px 8px; border-radius: 6px; font-weight: 700;">Click to select</span>
                                </div>
                                <div id="web-bank-2-branch-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600; padding-left: 26px;">
                                    Branch: <span id="web-bank-2-branch" style="color: #0f172a; font-weight: 700;">Horana Branch</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">
                                    <span>Account Name: <span id="web-bank-2-accname" style="color: #0f172a; font-weight: 700;">WPM Shamesh</span></span>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span id="web-bank-2-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>
                                    </div>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accno', 'Account Number');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <div style="margin-top: 1rem;">
                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>
                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">
                            </div>
                        </div>

                        <!-- Shop Pickup / Branch Selection Box -->
                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch
                            </p>

                            <!-- City / Town Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>
                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>
                                  ${ct().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}
                                </select>
                            </div>

                            <!-- Shop / Branch List Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>
                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <!-- Injected by populatePickupShops -->
                                </select>
                            </div>

                            <!-- Selected Shop Info Card -->
                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">
                            </div>
                        </div>
                    </div>

                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">
                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">
                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">
                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 
                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 
                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.
                        </label>
                    </div>

                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">
                        Confirm Order
                    </button>
                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->
                </div>
            `:""}
        </div>
    `,document.getElementById("close-cart-btn").onclick=()=>he(!1),(i=document.getElementById("checkout-btn"))==null||i.addEventListener("click",Rt),setTimeout(()=>{typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI()},50),window.toggleBankDetails=o=>{const s=document.getElementById("bank-details-box");s&&(s.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const s=document.getElementById("bank-details-box"),r=document.getElementById("shop-pickup-box"),d=document.getElementById("delivery-address-group"),a=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(s&&(s.style.display="block"),typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI(),r&&(r.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(s&&(s.style.display="none"),r&&(r.style.display="block",window.populatePickupShops()),d&&(d.style.display="none"),a&&(a.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(s&&(s.style.display="none"),r&&(r.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var c,p,m,x;const o=document.getElementById("pickup-town-select"),s=document.getElementById("pickup-shop-select"),r=document.getElementById("selected-shop-info-card");if(!s)return;const d=o?o.value:"All",a=pe();let l=a;d&&d!=="All"&&(l=a.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(d.toLowerCase()))),l.length===0?(s.innerHTML=a.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),r&&(r.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${d}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((c=a[0])==null?void 0:c.docId)||((p=a[0])==null?void 0:p.id)||0)):(s.innerHTML=l.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((x=l[0])==null?void 0:x.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const s=document.getElementById("selected-shop-info-card");if(!s)return;const r=pe(),d=r.find(a=>a.docId===o||a.id===o)||r[0];d&&(s.innerHTML=`
        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${d.name||d.shopName||"Main Branch"}</div>
        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${d.location||d.address||"In-store Pickup Counter"}</div>
        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${d.phone?`Contact: <b>${d.phone}</b>`:"Store Pickup Active"}</div>
        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">
          <span>✓</span> Collect & Pay Cash at this shop counter
        </div>
      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),t=document.getElementById("promo-message");if(!e)return;const n=e.value.trim().toUpperCase();if(!n){t&&(t.innerText="❌ Please enter a promo code.",t.style.color="#ef4444");return}t&&(t.innerText="⏳ Validating coupon...",t.style.color="var(--primary-color)");try{const i=T(Bt,S("code","==",n),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty){t&&(t.innerText="❌ Invalid or expired coupon code.",t.style.color="#ef4444");return}const s=o.docs[0],r={...s.data(),id:s.id},d=new Date().toISOString().split("T")[0];if(r.expiryDate<d){t&&(t.innerText="❌ This coupon has expired.",t.style.color="#ef4444");return}if(r.status!=="Active"){t&&(t.innerText="❌ This coupon is inactive.",t.style.color="#ef4444");return}const a=v.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=He(r,v,a);if(!l.isValidForCart){t&&(t.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,t.style.color="#ef4444");return}window.appliedCoupon=r,$e();const c=document.getElementById("promo-message");if(c){const p=r.targetType==="specific_products"?" (Selected Items)":r.targetType==="specific_categories"?" (Selected Categories)":"";c.innerText=`✅ Coupon applied: ${r.type==="Percentage"?`${r.value}% OFF`:`LKR ${r.value} OFF`}${p}`,c.style.color="#10b981"}}catch(i){console.error("Error validating coupon:",i),t&&(t.innerText="❌ Error validating coupon code.",t.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,$e()};async function Rt(){var m,x,u,f,g,b,w,B;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!"),window.location.href="/login.html";return}if(v.length===0)return;const t=document.getElementById("terms-agree");if(t&&!t.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const n=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),i=(x=document.getElementById("delivery-phone-2"))==null?void 0:x.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),s=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),r=((g=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:g.value)||"COD",d=(b=document.getElementById("deposit-slip"))==null?void 0:b.files[0],a=r==="ShopPay";let l=null,c="All";if(a){c=((w=document.getElementById("pickup-town-select"))==null?void 0:w.value)||"All";const h=(B=document.getElementById("pickup-shop-select"))==null?void 0:B.value,P=pe();if(l=P.find(I=>I.docId===h||I.id===h)||P[0],!h&&(!P||P.length===0)){alert("Please select a pickup shop / branch!");return}}if(!n||!a&&(!o||!s)){alert(a?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",n),localStorage.setItem("mec_saved_phone2",i),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",s),r==="Bank"&&!d){alert("Please upload your bank deposit slip!");return}for(const h of v){const P=O.find(I=>I.docId===h.docId)||(window.groupedProducts||[]).find(I=>I.docId===h.docId);if(P&&P.mode!=="Service"&&P.mode!=="Technical"){let I=null;h.selectedVariant&&h.selectedVariant!=="Default"&&P.variants&&(I=P.variants.find(L=>(L.name||L.variantLabel||L.color||L.size||"Variant")===h.selectedVariant));const $=Fe(P,I,r);if((h.quantity||1)>$){alert(r==="ShopPay"?`Sorry! "${h.name}" only has ${$} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${h.name}" only has ${$} available in stock.`);return}}}const p=async(h=null)=>{var P,I;try{const $=v.reduce((y,q)=>y+q.price*(1-(q.discount||0)/100)*(q.quantity||1),0);let L=0,z="";if(window.appliedCoupon){z=window.appliedCoupon.code;const y=He(window.appliedCoupon,v,$);y.isValidForCart&&(L=y.discountAmount)}const M=Math.max(0,$-L),_=sessionStorage.getItem("mec_ref_code");let C="",D=0;if(_)try{const y=T(E(k,"affiliates"),S("code","==",_),S("storeId","==",window.currentStoreId));(await A(y)).empty||(C=_,D=Number((M*.05).toFixed(2)))}catch(y){console.error("Error verifying affiliate referral code at checkout:",y)}const X=window.currentStoreId||"mec-book-shop",Le=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),We=e&&(e.name||e.email)?e.name||e.email:n||"Guest Customer",je=window.selectedWebStoreBankSlot||"slot1",N=window.webStoreBankAccounts&&window.webStoreBankAccounts[je]||((P=window.webStoreBankAccounts)==null?void 0:P.slot1),Z={orderId:"ORD-"+Date.now(),userId:Le,userName:We,userEmail:e&&e.email?e.email:"",phone:n||"",phone2:i||"",branchId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:a?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:a?c:"",pickupShopPhone:a&&(l==null?void 0:l.phone)||"",pickupShopAddress:a&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:a?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:a?c!=="All"?c:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":s||"",items:v.map(y=>({id:y.id||y.docId||"",docId:y.docId||y.id||"",name:y.name||"",price:Number(y.price)||0,cost:Number(y.cost)||0,quantity:Number(y.quantity)||1,discount:Number(y.discount)||0,finalPrice:Number(y.price)*(1-(Number(y.discount)||0)/100)})),subtotal:Number($)||0,discount:Number(L)||0,couponCode:z||"",total:Number(M)||0,status:"Pending",customerType:(((I=window.currentUserProfile)==null?void 0:I.customerType)||"retail").toLowerCase(),paymentMethod:r||"COD",targetBankSlot:r==="Bank"?je:null,targetBankAccountId:r==="Bank"&&(N==null?void 0:N.docId)||null,targetBankName:r==="Bank"?(N==null?void 0:N.bankName)||"Bank":null,targetAccountNo:r==="Bank"?(N==null?void 0:N.accountNo)||"":null,targetAccountTitle:r==="Bank"?(N==null?void 0:N.accountName)||"":null,bankCredited:r==="Bank",slipImage:h||"",codCharge:r==="COD"?400:r==="Bank"?250:0,isShopPending:r==="ShopPay",storeId:X,numericStoreId:"1001",timestamp:G(),date:new Date().toLocaleString(),referredBy:C||"",referredCommission:Number(D)||0},Ve=W(E(k,"stores",X,"orders")),Ge=Ve.id;Z.docId=Ge,await Promise.all([ce(Ve,Z),ce(W(Pt,Ge),Z)]);try{const y=yt(k);let q=!1;for(const F of v){const Te=F.docId||F.id;if(Te&&Te!=="N/A"){const Je=W(k,"stores",X,"products",Te),Qe=await st(Je);if(Qe.exists()){const se=Qe.data(),Ye=Number(F.quantity)||1;let ee={};if(se.variants&&Array.isArray(se.variants)&&F.variantIndex!==void 0&&se.variants[F.variantIndex]){const oe=[...se.variants],mt=parseFloat(oe[F.variantIndex].stock)||0;oe[F.variantIndex].stock=Math.max(0,mt-Ye),ee.variants=oe,ee.stock=oe.reduce((gt,ft)=>gt+(parseFloat(ft.stock)||0),0)}else{const oe=parseFloat(se.stock)||0;ee.stock=Math.max(0,oe-Ye)}ee.totalStock=ee.stock,ee.updatedAt=G(),y.update(Je,ee),q=!0}}}q&&(await y.commit(),console.log("[Web Store Checkout] Stock deducted successfully for Order #"+Z.orderId))}catch(y){console.warn("[Web Store Checkout] Stock deduction error (order recorded):",y)}if(r==="Bank"&&N)try{let y=N.docId;if(!y||y==="ndb_default"||y==="boc_default"){const q=T(E(k,"bank_accounts"),S("accountNo","==",N.accountNo)),F=await A(q);F.empty||(y=F.docs[0].id)}if(y&&y!=="ndb_default"&&y!=="boc_default"){const q=W(k,"bank_accounts",y);await lt(q,{balance:xe(M),updatedAt:G()}),await re(E(k,"bank_transactions"),{accountId:y,bankName:N.bankName||"Bank Transfer",accountNo:N.accountNo||"",amount:M,type:"Credit",description:`Web Store Bank Transfer: Order #${Z.orderId} (${We})`,referenceNo:Z.orderId,orderId:Z.orderId,source:"Web Store",date:new Date().toLocaleDateString("sv-SE"),timestamp:G(),isReconciled:!1,storeId:X}),console.log(`[Web Store Checkout] Credited LKR ${M} to ${N.bankName} (${N.accountNo})`)}}catch(y){console.warn("Error crediting web store bank account:",y)}if(C)try{const y=T(E(k,"affiliates"),S("code","==",C),S("storeId","==",X)),q=await A(y);if(!q.empty){const F=q.docs[0].id;await ce(W(k,"affiliates",F),{salesCount:xe(1),totalCommission:xe(D)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(y){console.error("Error updating affiliate statistics post-order:",y)}v=[],we=0,window.appliedCoupon=null,Ue(),Ee(),he(!1),alert(r==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":a?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch($){console.error("Order error:",$),alert("Error placing order: "+($.message||"Please try again."))}};if(d){const h=new FileReader;h.onload=P=>{const I=new Image;I.onload=()=>{const $=document.createElement("canvas"),L=1e3,z=1e3;let M=I.width,_=I.height;M>_?M>L&&(_*=L/M,M=L):_>z&&(M*=z/_,_=z),$.width=M,$.height=_,$.getContext("2d").drawImage(I,0,0,M,_);const D=$.toDataURL("image/jpeg",.6);p(D)},I.onerror=()=>{p(P.target.result)},I.src=P.target.result},h.onerror=P=>{console.error("FileReader Error:",P),alert("Error reading slip file. Please try selecting the image again.")},h.readAsDataURL(d)}else p()}function U(){const e=document.querySelector("#product-grid"),t=document.getElementById("pagination-controls");if(!e)return;let n=O.filter(a=>{if(a.mode==="Service"||a.mode==="Technical"||a.mode==="POS")return!1;const l=(a.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const c=te==="All"||a.category===te,p=window.matchProductSearch?window.matchProductSearch(a,V):a.name.toLowerCase().includes(V)||a.category.toLowerCase().includes(V)||a.sku&&a.sku.toLowerCase().includes(V);return c&&p});ae==="recommended"?((!De||De.length!==n.length)&&(De=n.map((a,l)=>({id:l,sort:Math.random()})).sort((a,l)=>a.sort-l.sort).map(a=>a.id)),n.sort(()=>Math.random()-.5)):n.sort((a,l)=>{if(ae==="az")return a.name.localeCompare(l.name);if(ae==="za")return l.name.localeCompare(a.name);if(ae==="low"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return c-p}if(ae==="high"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-c}return 0});const i=new Map;n.forEach(a=>{const l=a.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),c=l?l[1].trim():a.name.trim(),p=l?l[2].trim():(a.size||a.color)&&`${a.size?a.size:""} ${a.color?a.color:""}`.trim()||"Default",m=c.toLowerCase();if(i.has(m)){const x=i.get(m);x.totalStock+=a.totalStock!==void 0?a.totalStock:a.stock||0;const u=(a.variants||[]).map(f=>({...f,sourceDocId:a.docId}));u.length===0&&u.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),x.variants=[...x.variants,...u]}else{const x=(a.variants||[]).map(u=>({...u,sourceDocId:a.docId}));x.length===0&&x.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),i.set(m,{...a,name:c,totalStock:a.totalStock!==void 0?a.totalStock:a.stock||0,variants:x})}}),window.groupedProducts=Array.from(i.values());const o=window.groupedProducts.length,s=Math.ceil(o/Ne);R>s&&s>0&&(R=s),R<1&&(R=1);const r=(R-1)*Ne,d=window.groupedProducts.slice(r,r+Ne);if(window.groupedProducts.length===0){e.innerHTML=`
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>
        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${V}</strong>".<br>Try a different keyword or browse all categories.</p>
        <button onclick="window.clearSearch()" 
          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"
          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
          Clear Search
        </button>
      </div>`,t&&(t.innerHTML="");return}if(e.innerHTML=d.map(a=>{const l=a.variants&&a.variants.length>0,c=l?a.variants[0]:null,p=ie(a,c),m=p.retailPrice,x=p.discountedPrice,u=p.isSpecial,f=p.userType,g=Number(a.discount)||0;let b=ge(a,c);isNaN(b)&&(b=0);let w=a.image;(!w||w.trim()===""||w.includes("/logo.png"))&&c&&(c.images&&c.images.length>0?w=c.images[0]:c.image&&(w=c.image)),w=ye(w,a.name);const B=a.timestamp?typeof a.timestamp.toMillis=="function"?a.timestamp.toMillis():typeof a.timestamp=="number"?a.timestamp:0:0,h=B>0&&Date.now()-B<10080*60*1e3;return`
    <div class="product-card" id="product-${a.docId}">
      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${a.docId}')">
        <div class="image-slider-container" style="height: 100%; width: 100%;">
            <img src="${w}" class="main-product-img" alt="${a.name}" 
                loading="lazy" decoding="async"
                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 
                style="width:100%; height:100%; object-fit:cover;">
        </div>
        ${b<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}
        ${g>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${g}% OFF</div>`:h?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}
        
        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">
            ${((c==null?void 0:c.images)||[a.image]).map((P,I)=>`<div class="dot ${I===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${I===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}
        </div>

        ${l?`
          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')">
            Select Options
          </button>
        `:`
          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')" ${b<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>
            ${b<=0?"Out of Stock":"Add to Cart"}
          </button>
        `}
      </div>
      <div class="product-info">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">
          <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px;">${a.category||"General"}</div>
          <div class="stock-display" style="font-size: 0.72rem; font-weight:700;">
            ${b<=0?'<span style="color:#ef4444; background:rgba(239,68,68,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Out of Stock</span>':b<5?`<span style="color:#f59e0b; background:rgba(245,158,11,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Only ${b} left</span>`:`<span style="color:#10b981; font-weight:700;">Stock: ${b}</span>`}
          </div>
        </div>
        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${a.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">
          ${a.name}
        </div>
        


        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">
            ${g>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${m.toFixed(2)}</span>`:""}
            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${x.toFixed(2)}</span>
            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}
        </div>
      </div>
    </div>`}).join(""),t)if(s>1){let a=`<button class="pag-nav-btn" ${R===1?"disabled":""} onclick="window.changePage(${R-1})">‹ Previous</button>`;const l=5;let c=Math.max(1,R-2),p=Math.min(s,c+l-1);p===s&&(c=Math.max(1,p-l+1)),c>1&&(a+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',c>2&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=c;m<=p;m++)a+=`<button class="pag-page-btn ${m===R?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<s&&(p<s-1&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),a+=`<button class="pag-page-btn" onclick="window.changePage(${s})">${s}</button>`),a+=`<button class="pag-nav-btn" ${R===s?"disabled":""} onclick="window.changePage(${R+1})">Next ›</button>`,t.innerHTML=a}else t.innerHTML=""}window.changePage=e=>{var t;R=e,U(),(t=document.getElementById("shop-section"))==null||t.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,t)=>{const n=window.groupedProducts?window.groupedProducts.find(B=>B.docId===e):null,i=document.getElementById(`product-${e}`);if(!n||!i)return;const o=n.variants&&n.variants[t]?n.variants[t]:null,s=ie(n,o),r=s.retailPrice,d=s.discountedPrice,a=s.isSpecial,l=Number(n.discount)||0,c=o&&o.stock!==void 0?o.stock:n.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:n.images&&n.images.length>0?p=n.images:p=[n.image];const m=p.map(B=>ye(B,n.name)),x=i.querySelector(".original-price"),u=i.querySelector(".final-price");x&&(x.innerText=`LKR ${r.toFixed(2)}`,x.style.display=l>0||a?"inline":"none"),u&&(u.innerText=`LKR ${d.toFixed(2)}`);const f=i.querySelector(".stock-display");f.innerText=`Stock: ${c}`,f.style.color=c<5?"#ef4444":"#10b981";const g=i.querySelector(".add-to-cart-btn");c<=0?(g.disabled=!0,g.innerText="Out of Stock",g.style.background="#cbd5e1",g.style.cursor="not-allowed"):(g.disabled=!1,g.innerText="Add to Cart",g.style.background="",g.style.cursor="pointer");const b=i.querySelector(".main-product-img");b.src=m[0];const w=i.querySelector(".image-dots");if(w.innerHTML=m.map((B,h)=>`<div class="dot ${h===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${h===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let B=0;i.imageInterval&&clearInterval(i.imageInterval),i.imageInterval=setInterval(()=>{B=(B+1)%m.length,b.style.opacity="0.5",setTimeout(()=>{b.src=m[B],b.style.opacity="1",w.querySelectorAll(".dot").forEach((P,I)=>{P.style.background=I===B?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else i.imageInterval&&clearInterval(i.imageInterval)};function Ot(){const e=document.getElementById("nav-auth-item"),t=document.getElementById("user-profile");document.getElementById("user-display-name"),wt(Xe,n=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),n){const i={name:n.displayName||n.email.split("@")[0],email:n.email,id:n.uid};sessionStorage.setItem("mec_user",JSON.stringify(i));const o=()=>{var B,h,P,I,$;if(!e)return;const l=(((B=window.currentUserProfile)==null?void 0:B.customerType)||"retail").toLowerCase(),c=((h=window.currentUserProfile)==null?void 0:h.phone)||((P=window.currentUserProfile)==null?void 0:P.contact)||"",p=n.photoURL||((I=window.currentUserProfile)==null?void 0:I.photoURL)||(($=window.currentUserProfile)==null?void 0:$.avatar)||"",x=(L=>{if(!L)return"U";const z=L.trim().split(" ");return z.length>=2?(z[0][0]+z[1][0]).toUpperCase():L.slice(0,2).toUpperCase()})(i.name),u=l==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':l==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=l==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">
               <span>👑</span> Wholesale Customer (Wholesale Price Active)
             </div>`:l==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>💎</span> Loyalty Card Member Active
                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>🛍️</span> Standard Retail Customer
                 </div>`;e.innerHTML=`
          <div style="position: relative; display: inline-block;">
            <!-- Circular Avatar Only Trigger Button -->
            <button id="user-profile-trigger" style="
              background: transparent;
              border: none;
              padding: 2px;
              cursor: pointer;
              outline: none;
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
            " title="${i.name}">
              
              <!-- Circular Avatar Photo / Initials -->
              <div style="
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0284c7, #6366f1);
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 800;
                font-size: 0.88rem;
                color: white;
                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);
                border: 2px solid ${l==="wholesale"?"#eab308":l==="loyalty"?"#10b981":"#38bdf8"};
                overflow: hidden;
                flex-shrink: 0;
                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 
                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">
                ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:x}
              </div>

              <!-- Status Badge Dot -->
              ${l==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':l==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}
            </button>

            <!-- Modern Floating Profile Card Dropdown -->
            <div id="user-profile-dropdown" style="
              display: none;
              position: absolute;
              right: 0;
              top: calc(100% + 12px);
              width: 290px;
              background: #0f172a;
              border: 1px solid rgba(255, 255, 255, 0.15);
              border-radius: 16px;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);
              padding: 1.25rem;
              z-index: 10000;
              text-align: left;
            ">
              <!-- Profile Card Header -->
              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div style="
                  width: 46px;
                  height: 46px;
                  border-radius: 50%;
                  background: linear-gradient(135deg, #0284c7, #8b5cf6);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 1.1rem;
                  color: white;
                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
                  border: 2px solid rgba(255,255,255,0.6);
                  overflow: hidden;
                  flex-shrink: 0;
                ">
                  ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:x}
                </div>
                <div style="overflow: hidden; flex: 1;">
                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">
                      ${i.name}
                    </span>
                    ${u}
                  </div>
                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                    ${i.email||"Registered Customer"}
                  </div>
                </div>
              </div>

              <!-- Account Details & Benefits -->
              <div style="margin: 12px 0;">
                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">
                  Account Membership
                </div>
                ${f}
                
                ${c?`
                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">
                    <span style="color:#38bdf8;">📞</span> <span>${c}</span>
                  </div>
                `:""}
              </div>

              <!-- Quick Actions -->
              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">
                <a href="/track.html" style="
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  padding: 8px 12px;
                  background: rgba(255, 255, 255, 0.05);
                  border: 1px solid rgba(255, 255, 255, 0.08);
                  border-radius: 8px;
                  color: #f1f5f9;
                  text-decoration: none;
                  font-size: 0.82rem;
                  font-weight: 600;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">
                  <span style="display:flex; align-items:center; gap:8px;">
                    <span>📦</span> Track My Orders
                  </span>
                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>
                </a>
              </div>

              <!-- Divider & Logout Button -->
              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">
                <button id="nav-logout-btn" style="
                  width: 100%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 8px;
                  background: rgba(239, 68, 68, 0.12);
                  border: 1px solid rgba(239, 68, 68, 0.3);
                  color: #f87171;
                  padding: 8px 12px;
                  border-radius: 8px;
                  font-size: 0.85rem;
                  font-weight: 700;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"
                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">
                  <span>🚪</span> Log Out
                </button>
              </div>
            </div>
          </div>
        `;const g=document.getElementById("user-profile-trigger"),b=document.getElementById("user-profile-dropdown");g&&b&&(g.onclick=L=>{L.stopPropagation();const z=b.style.display==="block";b.style.display=z?"none":"block"});const w=document.getElementById("nav-logout-btn");w&&(w.onclick=async L=>{if(L.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await xt(Xe),window.location.href="/"}catch(z){console.error("Logout Error:",z),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",l=>{const c=document.getElementById("user-profile-trigger"),p=document.getElementById("user-profile-dropdown");p&&c&&!c.contains(l.target)&&!p.contains(l.target)&&(p.style.display="none")}),o();const s=(n.email||"").trim(),r=s.toLowerCase(),d=T(E(k,"customers"),S("email","==",s)),a=T(E(k,"customers"),S("email","==",r));Promise.all([A(d),A(a)]).then(([l,c])=>{let p=null;if(l.empty?c.empty||(p=c.docs[0].data()):p=l.docs[0].data(),p){const m=(p.customerType||p.type||(p.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...p,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()}else{const m=window.currentStoreId||"mec-book-shop";A(T(E(k,"customers"),S("storeId","==",m))).then(x=>{const u=(n.displayName||n.email.split("@")[0]||"").trim().toLowerCase(),f=x.docs.find(g=>{const b=g.data(),w=(b.email||"").trim().toLowerCase(),B=(b.phone||"").trim(),h=(b.name||"").trim().toLowerCase(),P=w&&w===r,I=n.phoneNumber&&B&&(B===n.phoneNumber||n.phoneNumber.includes(B)),$=h&&u&&(h===u||u.includes(h)||h.includes(u)||u.split(" ")[0]===h);return P||I||$});if(f){const g=f.data(),b=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:b,docId:f.id},!g.email&&n.email&&lt(W(k,"customers",f.id),{email:n.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()})}}).catch(l=>{console.error("Error fetching user profile:",l),window.currentUserProfile={customerType:"retail"},o(),U()})}else sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},U(),e&&(e.innerHTML='<a href="/login">Login</a>'),t&&(t.style.display="none")})}function _t(){const e=document.getElementById("reviews-container");if(!e)return;const t=E(k,"reviews"),n=T(t,vt("timestamp","desc"),ht(15));Ie(n,i=>{const o=i.docs.map(s=>s.data());if(o.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=o.map(s=>`
      <div class="review-card">
        <div class="review-stars">
          ${"★".repeat(s.rating)}${"☆".repeat(5-s.rating)}
        </div>
        <p class="review-comment">"${s.comment||"No comment provided."}"</p>
        <div class="review-footer">
          <span class="review-author">${s.userName}</span>
          <span class="review-date">${s.date}</span>
        </div>
      </div>
    `).join("")})}At();Ot();_t();const Me="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let Re=null;try{Me&&(Re=new bt(Me))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function nt(e,t){if(!O||O.length===0)return t?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const i=(e||"").toLowerCase().split(/\s+/).filter(s=>s.length>2),o=O.map(s=>{let r=0;const d=(s.name||"").toLowerCase(),a=(s.category||"").toLowerCase(),l=(s.description||"").toLowerCase();return i.forEach(c=>{d.includes(c)&&(r+=3),a.includes(c)&&(r+=2),l.includes(c)&&(r+=1)}),{product:s,score:r}}).filter(s=>s.score>0).sort((s,r)=>r.score-s.score);if(o.length>0){const s=o.slice(0,3).map(r=>r.product);return t?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${s.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=d.wholesalePrice?` | තොග මිල: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${s.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"In Stock":"Out of Stock",l=d.wholesalePrice?` | Wholesale: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return t?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function qt(e,t){var i,o,s,r,d,a;const n=/[\u0D80-\u0DFF]/.test(e)||t==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop, Horana",c=(O||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(g=>`${g.name||g.variantLabel||"Var"}-Stock:${g.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.
Available Inventory & Prices:
${c}

CRITICAL RULES:
1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).
2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.
3. Keep answers concise, clear, and direct (max 2-3 short sentences).
4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(Re)try{const b=(await(await Re.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(b)return b}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Me)}`,x=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(x.ok){const u=await x.json(),f=(a=(d=(r=(s=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:s.content)==null?void 0:r.parts)==null?void 0:d[0])==null?void 0:a.text;if(f&&f.trim())return f.trim()}return nt(e,n)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),nt(e,n)}}window.toggleGeminiChat=e=>{var o;const t=document.getElementById("gemini-chat-window"),n=document.getElementById("gemini-bubble");if(!t)return;(e!=null?!!e:!t.classList.contains("active"))?(t.classList.add("active"),n&&n.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):t.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),t=document.getElementById("gemini-chat-messages");if(!e||!t||!e.value.trim())return;const n=e.value.trim();e.value="";const i=document.createElement("div");i.className="user-msg",i.textContent=n,t.appendChild(i),t.scrollTop=t.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",t.appendChild(o),t.scrollTop=t.scrollHeight;const s=n.toLowerCase(),r=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let d=n,a=!1;if(r.forEach(m=>{s.includes(m)&&(a=!0)}),a&&(r.forEach(m=>{d=d.replace(new RegExp(m,"gi"),"")}),d=d.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),d.length>1)){window.searchQuery=d,V=d;const m=document.getElementById("store-search");m&&(m.value=d),R=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(n)||["mata","thiyenawada","tiyenawada","poth"].some(m=>s.includes(m)),c=await qt(n,l?"si":"en");o.textContent=c,t.scrollTop=t.scrollHeight};window.talkToAgentWhatsApp=()=>{var s,r,d;const e=document.getElementById("gemini-chat-messages");let t="";e&&(t=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let n=((s=window.currentStoreData)==null?void 0:s.phone)||((r=window.systemConfig)==null?void 0:r.invPhone)||"94770658356";n=n.replace(/[^0-9]/g,""),n.startsWith("0")&&(n="94"+n.substring(1));const i=`Hi ${((d=window.currentStoreData)==null?void 0:d.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(i+t);window.open(`https://wa.me/${n}?text=${o}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const at=document.getElementById("gemini-orb-btn");at&&at.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=dt.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const t=T(E(k,"affiliates"),S("code","==",e),S("storeId","==",window.currentStoreId)),n=await A(t);if(!n.empty){const i=W(k,"affiliates",n.docs[0].id);await ce(i,{clicks:xe(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(t){console.error("Error incrementing referral click:",t)}}};function Ut(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="aff-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>
        
        <!-- Tab navigation inside modal -->
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>
        </div>

        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>
        </form>
      </div>

      <div id="aff-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>
        
        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">
          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>
          <div style="display:flex; gap:10px; align-items:center;">
            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">
            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>
          </div>
        </div>

        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}function Ft(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="seller-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>
        
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>
        </div>

        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>
        </form>
      </div>

      <div id="seller-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>
            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>
          </div>
          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">
            Pending
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">
          
          <!-- Add Product Form -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>
            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">
              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>
              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>
            </form>
          </div>

          <!-- Product List -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>
            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">
              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>
            </div>
          </div>
        </div>

        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{Ut();const t=document.getElementById("affiliate-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_affiliate_user");if(n){const i=JSON.parse(n);try{const o=T(E(k,"affiliates"),S("email","==",i.email),S("storeId","==",window.currentStoreId)),s=await A(o);if(s.empty)localStorage.removeItem("mec_affiliate_user"),Oe();else{const r={...s.docs[0].data(),docId:s.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(r)),ke(r)}}catch(o){console.error(o),ke(i)}}else Oe()}};function Oe(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const t=document.getElementById("aff-login-form"),n=document.getElementById("aff-register-form"),i=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const t=document.getElementById("aff-login-email").value.trim(),n=document.getElementById("aff-login-pass").value;try{const i=T(E(k,"affiliates"),S("email","==",t),S("password","==",n),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const s={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),ke(s)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const t=document.getElementById("aff-reg-name").value.trim(),n=document.getElementById("aff-reg-email").value.trim(),i=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const s=T(E(k,"affiliates"),S("email","==",n),S("storeId","==",window.currentStoreId));if(!(await A(s)).empty){alert("An account with this email is already registered as a partner.");return}const d=t.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),a={name:t,email:n,phone:i,password:o,code:d,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:G()},l=await re(E(k,"affiliates"),a);a.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(a)),ke(a)}catch(s){console.error(s),alert("Registration failed. Please try again.")}};function ke(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const t=window.location.protocol,n=window.location.host,i=window.location.pathname;let o=`${t}//${n}${i}`;window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?o+=`?store=${window.currentStoreId}&ref=${e.code}`:o+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),Oe()};window.toggleSellerPortal=async e=>{Ft();const t=document.getElementById("seller-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_seller_user");if(n){const i=JSON.parse(n);try{const o=T(E(k,"vendor_shops"),S("email","==",i.email),S("storeId","==",window.currentStoreId)),s=await A(o);if(s.empty)localStorage.removeItem("mec_seller_user"),_e();else{const r={...s.docs[0].data(),docId:s.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(r)),Se(r)}}catch(o){console.error(o),Se(i)}}else _e()}};function _e(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const t=document.getElementById("seller-login-form"),n=document.getElementById("seller-register-form"),i=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const t=document.getElementById("seller-login-email").value.trim(),n=document.getElementById("seller-login-pass").value;try{const i=T(E(k,"vendor_shops"),S("email","==",t),S("password","==",n),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const s={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),Se(s)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{e.preventDefault();const t=document.getElementById("seller-reg-shopname").value.trim(),n=document.getElementById("seller-reg-owner").value.trim(),i=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),s=document.getElementById("seller-reg-pass").value;try{const r=T(E(k,"vendor_shops"),S("shopName","==",t),S("storeId","==",window.currentStoreId));if(!(await A(r)).empty){alert("This shop name is already registered.");return}const a=T(E(k,"vendor_shops"),S("email","==",i),S("storeId","==",window.currentStoreId));if(!(await A(a)).empty){alert("This email is already registered to a shop.");return}const c={shopName:t,ownerName:n,email:i,phone:o,password:s,status:"pending",storeId:window.currentStoreId,timestamp:G()},p=await re(E(k,"vendor_shops"),c);c.docId=p.id,localStorage.setItem("mec_seller_user",JSON.stringify(c)),Se(c);try{const m="+94770658356",x=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${t}
Owner: ${n}
Phone: ${o}
Email: ${i}`,u=`https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(m)}&message=${encodeURIComponent(x)}`;fetch(u,{method:"GET",mode:"no-cors"}).catch(()=>{})}catch(m){console.error("Vendor SMS alert error:",m)}}catch(r){console.error(r),alert("Shop registration failed. Please try again.")}};async function Se(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const t=document.getElementById("seller-dash-status-badge");t&&(t.innerText=e.status||"pending",e.status==="active"?(t.style.background="rgba(16, 185, 129, 0.2)",t.style.color="#10b981"):(t.style.background="rgba(251, 191, 36, 0.2)",t.style.color="#fbbf24")),await ut(e.email)}async function ut(e){const t=document.getElementById("seller-products-list");if(t){t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const n=T(qe,S("vendorId","==",e),S("storeId","==",window.currentStoreId)),i=await A(n);if(i.empty)t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";i.forEach(s=>{const r=s.data(),d=r.status==="active"?"#10b981":"#fbbf24";o+=`
          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-weight:bold; font-size:0.85rem; display:block;">${r.name||""}</span>
              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${r.price||0}</span>
            </div>
            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${d};">${r.status||"pending"}</span>
          </div>
        `}),t.innerHTML=o}}catch(n){console.error(n),t.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const t=localStorage.getItem("mec_seller_user");if(!t)return;const n=JSON.parse(t),i=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),s=document.getElementById("seller-prod-category").value.trim(),r=document.getElementById("seller-prod-image").value.trim(),d=document.getElementById("seller-prod-desc").value.trim();try{const a={name:i,price:Number(o),category:s,image:r||"",description:d||"",status:"pending",vendorId:n.email,storeId:window.currentStoreId,timestamp:G(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await re(qe,a),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await ut(n.email)}catch(a){console.error(a),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),_e()};window.addEventListener("beforeunload",function(e){var t;(t=window.chrome)!=null&&t.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
