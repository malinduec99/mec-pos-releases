/* empty css              */import{G as kt}from"./index-D2360V5-.js";import{a as de,c as $,d as P,s as oe,o as be,q as T,w as E,g as N,b as V,e as Ee,i as Be,f as ft,h as St,u as yt,j as It,l as Ct,k as Pt,m as Et,n as it}from"./firebase-B8pSeYS_.js";window.uploadLogToCloud=async(t,e="error")=>{try{const a=window.currentStoreId||"unknown",i=window.HostPCName||navigator.userAgent||"WebBrowser";await de($(P,"systemLogs"),{message:t,level:e,storeId:a,pcName:i,timestamp:oe()})}catch(a){console.error("Failed to upload log:",a)}};window.addEventListener("error",t=>{window.uploadLogToCloud(`Web Error: ${t.message} at ${t.filename}:${t.lineno}`,"error")});window.addEventListener("unhandledrejection",t=>{window.uploadLogToCloud(`Promise Rejection: ${t.reason}`,"error")});function Bt(){try{const t=localStorage.getItem("mecThemeColors");if(t){const e=JSON.parse(t),a=document.documentElement;a.style.setProperty("--primary-blue",e.primary),a.style.setProperty("--accent-blue",e.accent),a.style.setProperty("--admin-bg",e.bg),a.style.setProperty("--glass-bg",e.glass),a.style.setProperty("--primary-color",e.primary),a.style.setProperty("--secondary-color",e.accent),a.style.setProperty("--deep-bg",e.bg),e.bg==="#0f172a"||e.bg==="#11011c"||e.bg==="#022c22"?(a.style.setProperty("--text-dark","#f8fafc"),a.style.setProperty("--text-muted","#94a3b8")):(a.style.setProperty("--text-dark","#0f172a"),a.style.setProperty("--text-muted","#64748b"))}}catch{}}Bt();function he(){const t=document.querySelector("header");if(t){const a=t.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(a)}px`)}const e=document.getElementById("product-grid-header");if(e&&t){const a=t.getBoundingClientRect().height,o=e.getBoundingClientRect().top<=Math.round(a)+2;e.classList.toggle("is-stuck",o)}}window.addEventListener("resize",he);window.addEventListener("scroll",he,{passive:!0});document.addEventListener("DOMContentLoaded",he);setTimeout(he,200);setTimeout(he,800);const wt=new URLSearchParams(window.location.search),le=window.location.pathname.split("/").filter(t=>t!=="");let We=null;le[0]==="store"&&le[1]?We=le[1]:le[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(le[0])&&(We=le[0]);const Lt=wt.get("store")||We;window.currentStoreId=Lt||null;window.currentStoreData=null;if(typeof document<"u"){const t=()=>{const e=document.getElementById("nav-auth-item");e&&window.currentStoreId&&!sessionStorage.getItem("mec_user")&&(e.innerHTML=`<a href="/login.html?store=${encodeURIComponent(window.currentStoreId)}">Login</a>`)};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",t):t()}try{const t=sessionStorage.getItem("mec_customer_profile");t?window.currentUserProfile=JSON.parse(t):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const Fe=$(P,"stores"),Pe=window.location.hostname;async function $t(){let t=null;try{if(window.currentStoreId){const e=T(Fe,E("slug","==",window.currentStoreId)),a=await N(e);if(!a.empty)t={...a.docs[0].data(),docId:a.docs[0].id};else try{const i=V(P,"stores",window.currentStoreId),o=await ft(i);o.exists()&&(t={...o.data(),docId:o.id})}catch{}}else if(Pe==="mecpos.web.lk"||Pe==="mec-pos-shop.web.app"||Pe==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const e=Pe.replace(/^www\./,""),a=T(Fe,E("domain","==",e)),i=await N(a);i.empty||(t={...i.docs[0].data(),docId:i.docs[0].id})}}catch(e){console.error("Store resolution query failed:",e)}if(t)window.currentStoreData=t,window.currentStoreId=t.slug||t.storeSlug||t.docId||"",console.log("Resolved Store ID:",window.currentStoreId),st(),ct(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{const e=window.currentStoreId;if(e)try{const a=T(Fe,E("slug","==",e)),i=await N(a);i.empty||(window.currentStoreData=i.docs[0].data())}catch(a){console.error("Error loading store data:",a)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),st(),ct(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}$t();function st(){var u,f,y,b,w,k,v,S,C,L,A,R,B,F,ee,te;let t=(u=window.currentStoreData)==null?void 0:u.name;t||(window.currentStoreId?t=window.currentStoreId.split("-").map(I=>I.charAt(0).toUpperCase()+I.slice(1)).join(" "):t="Web Store"),document.title=`${t} | Official Store`;const e=(y=(f=window.currentStoreData)==null?void 0:f.webDesign)==null?void 0:y.primary,a=(w=(b=window.currentStoreData)==null?void 0:b.webDesign)==null?void 0:w.accent;e&&document.documentElement.style.setProperty("--primary-color",e),a&&document.documentElement.style.setProperty("--secondary-color",a),document.querySelectorAll(".logo-text").forEach(I=>{I.innerText=t});const i=!!window.currentStoreId;if(i){document.querySelectorAll(".bookshop-brand-banner, .bookshop-only").forEach(z=>z.style.display="none"),document.querySelectorAll(".merchant-only").forEach(z=>z.style.display="");const I=document.getElementById("pwa-install-banner");I&&(I.style.display="none")}else document.querySelectorAll(".bookshop-brand-banner, .bookshop-only").forEach(I=>I.style.display=""),document.querySelectorAll(".merchant-only").forEach(I=>I.style.display="none");const o=((k=window.currentStoreData)==null?void 0:k.logoUrl)||((v=window.currentStoreData)==null?void 0:v.webLogo),s=o&&o.trim()!==""&&!o.includes("/logo.png")&&!o.includes("zenith_logo")&&!o.includes("/pos-logo.png")&&!o.includes("/mec-logo.png")&&!o.includes("mecpos-default-logo")?o:"/mecpos-default-logo.png";document.querySelectorAll(".logo-img").forEach(I=>{I.src=s,I.style.display=i?"":I.classList.contains("merchant-only")?"none":""});const c=document.getElementById("hero");if(c){const I=(C=(S=window.currentStoreData)==null?void 0:S.webDesign)==null?void 0:C.bannerUrl,z=I&&I.length>10?I:null;if(z)c.innerHTML=`

        <div class="banner-container" id="banner-container" style="width: 100%;">

          <img id="main-banner" src="${z}" alt="${t} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">

        </div>

      `;else{const Se=((A=(L=window.currentStoreData)==null?void 0:L.webContent)==null?void 0:A.welcome)||`Welcome to ${t}`,Ie=((B=(R=window.currentStoreData)==null?void 0:R.webContent)==null?void 0:B.announce)||"Your premium destination for high-quality products and services.";c.innerHTML=`

        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">

          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${Se}</h1>

          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${Ie}</p>

          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>

        </div>

      `}}const n=document.getElementById("page-title");n&&(n.innerText=`${t} | Official Store`);const l=document.getElementById("footer-copy");l&&(l.innerText=`© 2026 ${t}. All rights reserved.`);const d=((F=window.currentStoreData)==null?void 0:F.webEpinics)||{},p=!!d.multiVendor,g=!!d.affiliate;(ee=document.getElementById("nav-sell-with-us"))==null||ee.remove(),(te=document.getElementById("nav-affiliate-program"))==null||te.remove();const m=document.getElementById("nav-menu");if(m){const I=document.getElementById("nav-auth-item");if(p){const z=document.createElement("li");z.id="nav-sell-with-us",z.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',I?m.insertBefore(z,I):m.appendChild(z)}if(g){const z=document.createElement("li");z.id="nav-affiliate-program",z.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',I?m.insertBefore(z,I):m.appendChild(z)}}document.documentElement.classList.remove("loading-merchant")}let ue;const Y=document.createElement("div");Y.id="pwa-install-banner";Y.innerHTML=`

    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">

        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">

        <div>

            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>

            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>

        </div>

        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>

    </div>

    <style>

        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }

    </style>

`;Y.style.display="none";document.body.appendChild(Y);window.addEventListener("beforeinstallprompt",t=>{var a,i;t.preventDefault(),ue=t,!!((a=window.currentStoreData)!=null&&a.downloadUrl||(i=window.currentStoreData)!=null&&i.appDownloadUrl)?Y.style.display="block":Y.style.display="none"});Y.addEventListener("click",async t=>{if(t.target.id==="pwa-close"){Y.style.display="none";return}if(ue){ue.prompt();const{outcome:e}=await ue.userChoice;e==="accepted"&&(Y.style.display="none"),ue=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(t=>{console.log("SW Registered",t.scope)}).catch(t=>{console.log("SW Registration Failed",t)})});const J=document.getElementById("menu-toggle"),Z=document.getElementById("nav-menu"),K=document.getElementById("mobile-menu-overlay"),Te=()=>{Z==null||Z.classList.remove("active"),J==null||J.classList.remove("active"),K==null||K.classList.remove("active")};J==null||J.addEventListener("click",()=>{const t=Z==null?void 0:Z.classList.toggle("active");J==null||J.classList.toggle("active"),t?K==null||K.classList.add("active"):K==null||K.classList.remove("active")});const qe=document.getElementById("close-menu");qe==null||qe.addEventListener("click",Te);K==null||K.addEventListener("click",Te);Z==null||Z.querySelectorAll("a").forEach(t=>{t.addEventListener("click",Te)});function ve(t,e){var i;if(typeof t=="string"&&t.trim()!==""){const o=t.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const a=(i=window.currentStoreData)==null?void 0:i.logoUrl;return a&&a.trim()!==""&&!a.includes("zenith_logo.png")&&!a.includes("/logo.png")?a:"/mec-logo.png"}const Tt=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}];function Ae(t){let e=window.currentStoreId||window.sessionStorage&&(sessionStorage.getItem("userStoreId")||sessionStorage.getItem("tempStoreSlug"))||"";return(!e||e==="null"||e==="undefined")&&(e="default"),$(P,"stores",e,t)}const Ge=Ae("products"),At=Ae("orders"),Dt=Ae("promotions"),Nt=Ae("branches"),zt=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let lt=[];be(Nt,t=>{lt=t.docs.map(e=>({...e.data(),docId:e.id})),window.allStoreBranches=lt,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function me(){var a,i,o,r,s,c;let t=(window.allStoreBranches||[]).filter(n=>n.storeId===window.currentStoreId||!n.storeId);const e={docId:"main",name:(((a=window.currentStoreData)==null?void 0:a.name)||"Store")+" - Main Branch",location:((i=window.currentStoreData)==null?void 0:i.address)||"",address:((o=window.currentStoreData)==null?void 0:o.address)||"",city:((r=window.currentStoreData)==null?void 0:r.city)||"",district:((s=window.currentStoreData)==null?void 0:s.district)||"",phone:((c=window.currentStoreData)==null?void 0:c.phone)||""};return t.length===0&&(t=[e]),t}window.getAllAvailableShops=me;function bt(){const e=me().map(i=>(i.location||i.city||"").trim()).filter(i=>i.length>0);return Array.from(new Set([...e,...zt])).filter(Boolean).sort((i,o)=>i.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=bt;let M=[],xe=0,x=[],ie="All",_=1,Oe=12,ce="recommended",Q="",Ue=null;document.getElementById("cart-count");window.webStoreBankAccounts={slot1:null,slot2:null};window.selectedWebStoreBankSlot="slot1";window.selectWebStoreBankSlot=t=>{window.selectedWebStoreBankSlot=t;const e=document.getElementById("web-bank-card-1"),a=document.getElementById("web-bank-card-2"),i=document.getElementById("web-slot-1-radio"),o=document.getElementById("web-slot-2-radio"),r=document.getElementById("web-bank-1-badge"),s=document.getElementById("web-bank-2-badge");t==="slot1"?(i&&(i.checked=!0),o&&(o.checked=!1),e&&(e.style.background="#f0fdf4",e.style.borderColor="#16a34a",e.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),a&&(a.style.background="#ffffff",a.style.borderColor="#cbd5e1",a.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),r&&(r.style.background="#16a34a",r.style.color="#ffffff",r.innerText="✓ Selected"),s&&(s.style.background="#f1f5f9",s.style.color="#64748b",s.innerText="Click to select")):(i&&(i.checked=!1),o&&(o.checked=!0),a&&(a.style.background="#f0fdf4",a.style.borderColor="#16a34a",a.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),e&&(e.style.background="#ffffff",e.style.borderColor="#cbd5e1",e.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),s&&(s.style.background="#16a34a",s.style.color="#ffffff",s.innerText="✓ Selected"),r&&(r.style.background="#f1f5f9",r.style.color="#64748b",r.innerText="Click to select"))};window.copyBankDetails=(t,e)=>{const a=document.getElementById(t);if(!a)return;const i=a.innerText.trim();navigator.clipboard.writeText(i),alert(`${e} Copied: ${i}`)};window.updateWebStoreBankCardsUI=()=>{var a,i;const t=(a=window.webStoreBankAccounts)==null?void 0:a.slot1,e=(i=window.webStoreBankAccounts)==null?void 0:i.slot2;if(t){const o=document.getElementById("web-bank-1-title"),r=document.getElementById("web-bank-1-accname"),s=document.getElementById("web-bank-1-accno"),c=document.getElementById("web-bank-1-acctype"),n=document.getElementById("web-bank-1-code"),l=document.getElementById("web-bank-1-swift");o&&t.bankName&&(o.innerText=`🏦 ${t.bankName}`),r&&t.accountName&&(r.innerText=t.accountName),s&&t.accountNo&&(s.innerText=t.accountNo),c&&t.accountType&&(c.innerText=t.accountType),n&&t.bankCode&&(n.innerText=t.bankCode),l&&t.swiftCode&&(l.innerText=t.swiftCode)}if(e){const o=document.getElementById("web-bank-2-title"),r=document.getElementById("web-bank-2-accname"),s=document.getElementById("web-bank-2-accno"),c=document.getElementById("web-bank-2-branch");o&&e.bankName&&(o.innerText=`🏦 ${e.bankName}`),r&&e.accountName&&(r.innerText=e.accountName),s&&e.accountNo&&(s.innerText=e.accountNo),c&&e.branch&&(c.innerText=e.branch)}};function Mt(){try{const t=localStorage.getItem("mec_webstore_bank_config");if(t){const e=JSON.parse(t);e.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...e.slot1Data}),e.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...e.slot2Data})}}catch{}try{be(V(P,"config","webstore_bank_accounts"),t=>{if(t.exists()){const e=t.data();e.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...e.slot1Data}),e.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...e.slot2Data}),window.updateWebStoreBankCardsUI()}},t=>console.warn("Web store banks config snapshot warning:",t))}catch(t){console.warn("Could not setup webstore banks listener:",t)}}Mt();function Rt(){let t=window.currentStoreId||"";try{const e=localStorage.getItem(`mecpos_system_config_${t}`)||localStorage.getItem("mecpos_system_config_cache");e&&(window.systemConfig=JSON.parse(e))}catch{}try{be(V(P,"config",t),e=>{if(e.exists()){const a=e.data();window.systemConfig=a;try{localStorage.setItem(`mecpos_system_config_${t}`,JSON.stringify(a)),localStorage.setItem("mecpos_system_config_cache",JSON.stringify(a))}catch{}typeof window.renderProducts=="function"&&Array.isArray(M)&&M.length>0&&window.renderProducts()}},e=>console.warn("System config snapshot warning:",e))}catch(e){console.warn("Could not setup system config listener:",e)}}Rt();function ct(){let t=window.currentStoreId||"";const e=$(P,"stores",t,"products");let a=T(e);be(a,i=>{M=i.docs.map(r=>({...r.data(),id:r.id,docId:r.id,sku:r.data().sku||r.id})).filter(r=>{const s=!r.storeId||r.storeId===window.currentStoreId,c=r.mode==="Shop"||r.mode==="Warehouse"||r.mode===void 0,n=r.status!=="pending";return s&&c&&n}),M.sort((r,s)=>{var c,n;return(((c=s.timestamp)==null?void 0:c.seconds)||0)-(((n=r.timestamp)==null?void 0:n.seconds)||0)}),M.length===0&&window.currentStoreId==="master"&&Tt.forEach(async r=>{await de(Ge,r)}),O(),De()})}var mt;(mt=document.getElementById("product-sort"))==null||mt.addEventListener("change",t=>{ce=t.target.value,_=1,O()});const _t=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(t=>{t.addEventListener("input",e=>{Q=e.target.value.toLowerCase(),window.searchQuery=Q,document.querySelectorAll("#store-search, .store-search-input").forEach(a=>{a!==e.target&&(a.value=e.target.value)}),_=1,O()})})};_t();window.renderProducts=O;window.clearSearch=()=>{Q="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(t=>{t.value=""}),_=1,O()};function Je(){localStorage.setItem("mec_cart",JSON.stringify(x))}function Ft(){const t=localStorage.getItem("mec_cart");t&&(x=JSON.parse(t),xe=x.reduce((e,a)=>e+(a.quantity||1),0),ze())}const ge=document.createElement("div");ge.id="cart-modal";document.body.appendChild(ge);const fe=document.createElement("div");fe.id="cart-overlay";document.body.appendChild(fe);window.toggleCart=t=>{t?(ge.classList.add("active"),fe.classList.add("active"),Me(),document.body.style.overflow="hidden"):(ge.classList.remove("active"),fe.classList.remove("active"),document.body.style.overflow="")};const ke=window.toggleCart;fe.onclick=()=>ke(!1);const qt=document.querySelectorAll('a[href="#cart"]');qt.forEach(t=>{t.onclick=e=>{e.preventDefault(),Te(),ke(!0)}});const dt=document.getElementById("shop-now-btn");dt&&dt.addEventListener("click",()=>{const t=document.getElementById("shop-section");t&&t.scrollIntoView({behavior:"smooth"})});const ht={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function Ot(){return["All",...new Set(M.map(e=>e.category))]}function De(){const t=Ot(),e=document.getElementById("sidebar-category-list"),a=document.getElementById("mobile-category-bar");e&&(e.innerHTML=t.map(s=>`

      <li class="sidebar-cat-item ${s===ie?"active":""}" data-category="${s}">

        <div class="cat-icon-text">

          <span class="cat-icon">${ht[s]||"📁"}</span>

          <span>${s}</span>

        </div>

        <span class="arrow">›</span>

      </li>

    `).join("")),a&&(a.innerHTML=t.map(s=>`

      <button class="mobile-cat-btn ${s===ie?"active":""}" data-category="${s}">

        ${s}

      </button>

    `).join(""));const i=s=>{var n;ie=s;const c=document.getElementById("featured-title");c&&(c.innerText=s==="All"?"Featured Collection":`${s} Collection`),O(),De(),X(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(s=>{s.addEventListener("click",c=>{c.stopPropagation(),i(c.currentTarget.dataset.category)}),s.addEventListener("mouseenter",c=>{const n=c.currentTarget.dataset.category;n!=="All"?Ut(n,c.currentTarget):X()})}),document.querySelectorAll(".mobile-cat-btn").forEach(s=>{s.addEventListener("click",c=>i(c.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),r=document.getElementById("nav-category-btn");r&&o&&(r.onclick=s=>{s.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),X()})}document.addEventListener("click",t=>{const e=document.querySelector(".category-menu-wrapper");e&&!e.contains(t.target)&&(e.classList.remove("active"),typeof X=="function"&&X())});const H=document.getElementById("mega-menu");let Ne;function Ut(t,e){if(!H)return;clearTimeout(Ne),document.querySelectorAll(".sidebar-cat-item").forEach(n=>n.classList.remove("active")),e==null||e.classList.add("active");const a=(M||[]).filter(n=>n.category===t),i={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[t]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`

      <div style="margin-bottom: 1.1rem;">

        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>

        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">

          <span>${ht[t]||"📁"}</span>

          <span>${t}</span>

        </div>

        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${a.length} Items Available</div>

      </div>

      <button type="button" onclick="window.filterByCategoryAndScroll('${t}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">

        <span>View All</span>

        <span>→</span>

      </button>

      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>

      <div style="display: flex; flex-direction: column; gap: 4px;">

        ${i.map(n=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${n}', '${t}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${n}</a>`).join("")}

      </div>

    `);const r=document.getElementById("mega-products-heading");r&&(r.innerText=`${t} Products (${a.length})`);const s=document.getElementById("mega-products-list");s&&(s.innerHTML=a.length>0?a.map(n=>`

          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${n.docId}')">

            <img src="${ve(n.image,n.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">

            <div class="mega-prod-info">

              <h5 title="${n.name}">${n.name}</h5>

              <div class="price">LKR ${Number(n.price||0).toFixed(2)}</div>

            </div>

          </a>

        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),H.style.top="calc(100% + 8px)",H.style.left="248px",H.classList.add("active");const c=H.getBoundingClientRect();if(c.right>window.innerWidth-16){const n=c.right-(window.innerWidth-16);H.style.left=`${Math.max(0,248-n)}px`}}function X(){Ne=setTimeout(()=>{H==null||H.classList.remove("active")},400)}H==null||H.addEventListener("mouseenter",()=>clearTimeout(Ne));var gt;(gt=document.getElementById("sidebar-category-list"))==null||gt.addEventListener("mouseenter",()=>clearTimeout(Ne));window.filterByCategoryAndScroll=t=>{var a;ie=t;const e=document.getElementById("featured-title");e&&(e.innerText=t==="All"?"Featured Collection":`${t} Collection`),O(),De(),X(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(t,e)=>{var i;ie=e,O(),De();const a=document.getElementById("featured-title");a&&(a.innerText=`${t} in ${e}`),(i=document.getElementById("shop-section"))==null||i.scrollIntoView({behavior:"smooth"}),X()};window.scrollToProduct=t=>{const e=document.getElementById(`product-${t}`);e&&(e.scrollIntoView({behavior:"smooth",block:"center"}),e.classList.add("highlight-pulse"),setTimeout(()=>e.classList.remove("highlight-pulse"),3e3),X())};function Wt(t,e,a=""){var d,p,g,m;t=parseFloat(t)||0,e=parseFloat(e)||0;const i=((d=window.systemConfig)==null?void 0:d.categoryWholesaleRules)||window.categoryWholesaleRules||[],o=(a||"").trim().toLowerCase(),r=i.find(u=>{var y,b;if(!u)return!1;const f=(typeof u.category=="string"?u.category:((y=u.category)==null?void 0:y.name)||((b=u.category)==null?void 0:b.category)||"").trim().toLowerCase();return f&&f===o});let s=r?r.mode:((p=window.systemConfig)==null?void 0:p.wholesalePricingMode)||"cost_markup",c=r?parseFloat(r.value):parseFloat((g=window.systemConfig)==null?void 0:g.wholesaleDiscount)||(s==="cost_markup"?8:15);isNaN(c)&&(c=0);let n=0;s==="cost_markup"?t>0?n=t*(1+c/100):e>0&&(n=e*.9):e>0?n=e*(1-c/100):t>0&&(n=t*1.1);const l=parseFloat((m=window.systemConfig)==null?void 0:m.profitMargin)||0;if(t>0&&l>0){const u=t*(1+l/100);n<u&&(n=u)}return Math.round(n*100)/100}window.calculateDynamicWholesalePrice=Wt;function pe(t,e=null,a=null){var f,y,b;if(!t)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const i=(a||((f=window.currentUserProfile)==null?void 0:f.customerType)||"retail").toLowerCase(),o=Number(t.price||t.sellingPrice)||0,r=Number(t.wholesalePrice)||0,s=Number(t.loyaltyPrice)||0,c=Number(e?e.cost||e.buyingPrice:t.cost||t.buyingPrice)||0,n=Number(e?e.price||e.sellingPrice:o)||o;let l=0,d=0;if(e){const w=Number(e.wholesalePrice)||0,k=Number(e.loyaltyPrice)||0;r>0&&(w<=0||Math.abs(n-o)<.01)?l=r:w>0?l=w:r>0&&(l=o>0?Math.round(n*(r/o)*100)/100:r),s>0&&(k<=0||Math.abs(n-o)<.01)?d=s:k>0?d=k:s>0&&(d=o>0?Math.round(n*(s/o)*100)/100:s)}else l=r,d=s;if(i==="wholesale"){l<=0&&typeof window.calculateDynamicWholesalePrice=="function"&&(l=window.calculateDynamicWholesalePrice(c,n,t.category));const w=parseFloat((y=window.systemConfig)==null?void 0:y.wholesaleDiscount)||0;l<=0&&w>0&&(l=Math.round(n*(1-w/100)*100)/100)}else if(i==="loyalty"){const w=parseFloat((b=window.systemConfig)==null?void 0:b.loyaltyDiscount)||0;d<=0&&w>0&&(d=Math.round(n*(1-w/100)*100)/100)}isNaN(n)&&(n=0);let p=n,g=!1;i==="wholesale"&&l>0?(p=l,g=l!==n):i==="loyalty"&&d>0&&(p=d,g=d!==n);const m=Number(t.discount)||0;let u=p;return i==="retail"&&m>0&&(u=p*(1-m/100)),{retailPrice:isNaN(n)?0:n,effectivePrice:isNaN(p)?0:p,discountedPrice:isNaN(u)?0:u,isSpecial:g,userType:i}}window.getCustomerEffectivePrice=pe;function ye(t,e=null){return Qe(t,e,"web")}function Qe(t,e=null,a="web"){if(!t)return 0;if(a==="ShopPay"||a==="shop"||a==="Shop"){if(e){const r=parseFloat(e.stock)||0;if(r>0)return r}const o=parseFloat(t.stock||0);return o>0?o:0}else{if(e){const n=parseFloat(e.stock)||0,l=parseFloat(e.wStock)||0,d=n+l;if(d>0)return d}if(t.variants&&t.variants.length>0){const n=t.variants.reduce((l,d)=>l+(parseFloat(d.stock)||0)+(parseFloat(d.wStock)||0),0);if(n>0)return n}const o=parseFloat(t.stock||0),r=parseFloat(t.wStock||0),s=parseFloat(t.totalStock||0),c=o+r;return c>0?c:s>0?s:0}}function Ye(t,e="",a=0){if(!t||!Array.isArray(t)||t.length===0)return[];const i=new Map;return t.forEach((o,r)=>{const s=Number(o.price||o.sellingPrice||a||0),c=(o.size||"").trim(),n=(o.color||"").trim();let l=(o.name||o.variantLabel||"").trim();const p=!l||l.toLowerCase()==="default"||l.toLowerCase()==="existing stock"||l.toLowerCase()==="option"||l.toLowerCase()===(e||"").trim().toLowerCase()?"":l,g=`${s}_${c.toLowerCase()}_${n.toLowerCase()}_${p.toLowerCase()}`,m=parseFloat(o.stock)||0,u=parseFloat(o.wStock)||0;if(!i.has(g))i.set(g,{...o,price:s,sellingPrice:s,size:c,color:n,variantLabel:p,name:p||(c||n?`${c} ${n}`.trim():`MRP LKR ${s.toLocaleString()}`),stock:m,wStock:u,totalStock:m+u,batchSources:[{sourceDocId:o.sourceDocId,origIndex:r,stock:m,wStock:u}]});else{const f=i.get(g);f.stock+=m,f.wStock+=u,f.totalStock+=m+u;const y=parseFloat(f.wholesalePrice)||0,b=parseFloat(o.wholesalePrice)||0;b>0&&(y<=0||m>0&&f.stock<=m)&&(f.wholesalePrice=b);const w=parseFloat(f.loyaltyPrice)||0,k=parseFloat(o.loyaltyPrice)||0;k>0&&(w<=0||m>0&&f.stock<=m)&&(f.loyaltyPrice=k),f.batchSources.push({sourceDocId:o.sourceDocId,origIndex:r,stock:m,wStock:u})}}),Array.from(i.values())}window.consolidateVariants=Ye;const we=document.getElementById("product-detail-modal"),Ze=document.getElementById("product-detail-overlay");window.openProductDetail=t=>{const e=(window.groupedProducts||[]).find(u=>u.docId===t)||M.find(u=>u.docId===t);if(!e)return;e.variants=Ye(e.variants,e.name,e.price);const a=Number(e.discount)||0,i=e.variants&&e.variants.length>1,o=e.variants&&e.variants.length>0?e.variants[0]:null;let r=e.image;o&&(o.image?r=o.image:o.images&&o.images.length>0&&(r=o.images[0]));const s=pe(e,o),c=s.userType,n=s.isSpecial,l=s.retailPrice,d=s.discountedPrice,p=ye(e,o),g={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let m="";if(i){const u=[...new Set(e.variants.map(y=>y.size).filter(Boolean))],f=[...new Set(e.variants.map(y=>y.color).filter(Boolean))];if(u.length>0||f.length>0){let y="";f.length>0&&(y=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Color</span>

              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||f[0]}</span>

            </div>

            <div class="variant-pill-container" id="color-pill-group">

              ${f.map(w=>{const k=g[w.toLowerCase()]||"#64748b";return`

                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||f[0])===w?"active":""}" 

                    style="background-color: ${k};" 

                    title="${w}" data-color="${w}"

                    onclick="window.selectVariantByAttribute('${e.docId}', 'color', '${w}')">

                  </button>

                `}).join("")}

            </div>

          </div>

        `);let b="";u.length>0&&(b=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Style / Size</span>

              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>

            </div>

            <div class="variant-pill-container" id="size-pill-group">

              ${u.map(w=>`

                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===w?"active":""}" 

                    data-size="${w}"

                    onclick="window.selectVariantByAttribute('${e.docId}', 'size', '${w}')">

                    ${w}

                  </button>

                `).join("")}

            </div>

          </div>

        `),m=`${y}${b}`}else m=`

        <div class="variant-selector-group">

          <div class="variant-selector-label">

            <span>Choose Option / MRP</span>

          </div>

          <div class="variant-pill-container">

            ${e.variants.map((y,b)=>{const w=ye(e,y);return`

              <div class="variant-mrp-card ${b===0?"active":""}" id="v-card-${b}"

                   onclick="window.updateDetailDisplay('${e.docId}', ${b})">

                <div style="flex:1;">

                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${y.variantLabel&&y.variantLabel.toLowerCase()!==e.name.toLowerCase()&&y.variantLabel.toLowerCase()!=="default"?y.variantLabel:y.size||y.color?`${y.size||""} ${y.color||""}`.trim():`MRP LKR ${(y.price||e.price||0).toLocaleString()}`}</div>

                  <div style="font-size: 0.75rem; color: #64748b;">${w>0?`In Stock (${w})`:"Out of stock"}</div>

                </div>

                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">

                  LKR ${(y.price||e.price||0).toLocaleString()}

                </div>

              </div>

            `}).join("")}

          </div>

        </div>

      `}we.innerHTML=`

        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>

        <div class="detail-content">

            <div class="detail-image-sec">

                <img src="${ve(r,e.name)}" id="detail-main-img" 

                    alt="${e.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') && !window.currentStoreData.logoUrl.includes('mec-logo') ? window.currentStoreData.logoUrl : 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='80' height='80' fill='none'%3E%3Crect width='80' height='80' rx='14' fill='%231e293b'/%3E%3Cpath d='M40 20L62 31.5V56.5L40 68L18 56.5V31.5L40 20Z' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M18 31.5L40 43L62 31.5' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M40 43V68' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E');">

            </div>



            <div class="detail-info-sec">

                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${e.category}</div>

                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${e.name}</h2>

                ${n?`<div style="font-size: 0.8rem; color: ${c==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${c.toUpperCase()} APPLIED</div>`:""}

                

                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">

                    ${a>0||n?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}

                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${d.toFixed(2)}</span>

                </div>

                

                ${m}



                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">

                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}

                </div>

                

                <div class="detail-actions-sec">

                    <button class="add-to-cart-btn detail-add-btn" 

                            onclick="window.handleDetailAddToCart('${e.docId}')">

                        🛒 Add to Cart

                    </button>

                </div>

            </div>

        </div>

    `,window.activeDetailVariantIndex=0,we.classList.add("active"),Ze.classList.add("active"),document.body.style.overflow="hidden",X(),window.updateDetailDisplay(t,0)};window.selectVariantByAttribute=(t,e,a)=>{const i=(window.groupedProducts||[]).find(s=>s.docId===t)||M.find(s=>s.docId===t);if(!i||!i.variants)return;const o=window.activeDetailVariantIndex||0;i.variants[o]||i.variants[0];let r=i.variants.findIndex(s=>e==="color"?s.color===a:e==="size"?s.size===a:!1);if(r===-1&&(r=0),e==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(c=>{c.classList.toggle("active",c.dataset.color===a)});const s=document.getElementById("detail-selected-color");s&&(s.innerText=a)}if(e==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(c=>{c.classList.toggle("active",c.dataset.size===a)});const s=document.getElementById("detail-selected-size");s&&(s.innerText=a)}window.updateDetailDisplay(t,r)};window.closeProductDetail=()=>{we.classList.remove("active"),Ze.classList.remove("active"),document.body.style.overflow=""};Ze.onclick=window.closeProductDetail;window.updateDetailDisplay=(t,e)=>{window.activeDetailVariantIndex=Number(e);const a=(window.groupedProducts||[]).find(d=>d.docId===t)||M.find(d=>d.docId===t);if(!a)return;const i=a.variants&&a.variants.length>0?a.variants[e]:null,o=document.getElementById("detail-main-img"),r=document.getElementById("detail-stock"),s=we.querySelector(".detail-original-price"),c=we.querySelector(".detail-final-price");if(o){let d=a.image;i&&(i.image?d=i.image:i.images&&i.images.length>0&&(d=i.images[0])),o.src=ve(d,a.name)}document.querySelectorAll(".variant-mrp-card").forEach((d,p)=>{d.classList.toggle("active",p===Number(e))}),Number(a.discount);const n=pe(a,i);s&&(s.innerText=`LKR ${n.retailPrice.toFixed(2)}`),c&&(c.innerText=`LKR ${n.discountedPrice.toFixed(2)}`);const l=ye(a,i);if(r){const d=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";r.innerHTML=d,r.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=t=>{const e=(window.groupedProducts||[]).find(p=>p.docId===t)||M.find(p=>p.docId===t);if(!e)return;const a=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let i="Default",o=null;e.variants&&e.variants.length>0&&(o=e.variants[a]||e.variants[0],i=o.name||o.variantLabel||o.color||o.size||"Default");const s=pe(e,o).effectivePrice,c=o&&o.cost!==void 0?Number(o.cost):Number(e.cost)||0,n=ye(e,o),l=x.findIndex(p=>p.docId===e.docId&&p.selectedVariant===i),d=l!==-1?(x[l].quantity||1)+1:1;if(e.mode!=="Service"&&e.mode!=="Technical"&&d>n){alert(`Sorry, out of stock! Only ${n} available.`);return}Kt(e,i,s,c),window.closeProductDetail(),ke(!0)};function Kt(t,e,a,i){const o=x.findIndex(r=>r.docId===t.docId&&r.selectedVariant===e);o!==-1?x[o].quantity=(x[o].quantity||1)+1:x.push({...t,selectedVariant:e,price:a,cost:i,quantity:1}),xe=x.reduce((r,s)=>r+(s.quantity||1),0),Je(),ze()}window.changeCartQty=(t,e,a)=>{var o;const i=x.findIndex(r=>r.docId===t&&r.selectedVariant===e);if(i!==-1){if(a>0){const r=M.find(s=>s.docId===t);if(r&&r.mode!=="Service"&&r.mode!=="Technical"){let s=null;e!=="Default"&&r.variants&&(s=r.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===e));const c=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",n=Qe(r,s,c);if((x[i].quantity||1)+a>n){alert(c==="ShopPay"?`Sorry! Only ${n} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${n} available.`);return}}}x[i].quantity=(x[i].quantity||1)+a,x[i].quantity<=0&&x.splice(i,1),xe=x.reduce((r,s)=>r+(s.quantity||1),0),Je(),ze(),Me()}};function ze(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(e=>{e&&(e.innerText=xe,e.classList.add("bump"),setTimeout(()=>e.classList.remove("bump"),300))})}function Xe(t,e,a){if(!t||!e||e.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let i=e;if(t.targetType==="specific_products"){const s=(t.selectedProducts||[]).map(c=>(c||"").trim().toLowerCase());if(i=e.filter(c=>{const n=(c.name||"").trim().toLowerCase(),l=(c.docId||"").trim().toLowerCase();return s.includes(n)||s.includes(l)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(t.targetType==="specific_categories"){const s=(t.selectedCategories||[]).map(c=>(c||"").trim().toLowerCase());if(i=e.filter(c=>{const n=(c.category||"").trim().toLowerCase();return s.includes(n)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(t.selectedCategories||[]).join(", ")}`}}const o=i.reduce((s,c)=>{const n=c.discount||0,l=c.price*(1-n/100),d=c.quantity||1;return s+l*d},0);let r=0;return t.type==="Percentage"?r=o*(Number(t.value)/100):r=Math.min(o,Number(t.value)||0),{discountAmount:r,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function Me(){var i;const t=x.reduce((o,r)=>{const s=r.discount||0,c=r.price*(1-s/100),n=r.quantity||1;return o+c*n},0);let e=0;if(window.appliedCoupon){const o=Xe(window.appliedCoupon,x);o.isValidForCart?e=o.discountAmount:window.appliedCoupon=null}const a=Math.max(0,t-e);ge.innerHTML=`

        <div class="cart-header">

            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>

            <button class="close-cart" id="close-cart-btn">&times;</button>

        </div>

        

        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">

            <div class="cart-body">

                ${x.length===0?`

                    <div class="cart-empty-state">

                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>

                        <p>Your cart is empty</p>

                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>

                    </div>

                `:x.map(o=>{const r=o.discount||0,s=o.price*(1-r/100),c=o.quantity||1,n=s*c;return`

                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">

                            <div class="cart-item-info" style="flex: 1;">

                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>

                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>

                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">

                                    ${r>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}

                                    LKR ${s.toFixed(2)} ${c>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${c} = LKR ${n.toFixed(2)}</span>`:""}

                                </div>

                            </div>

                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 

                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">

                                    -

                                </button>

                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${c}</span>

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 

                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">

                                    +

                                </button>

                            </div>

                        </div>

                    `}).join("")}

            </div>



            ${x.length>0?`

                <div class="cart-footer">

                    <div class="delivery-info-banner">

                        <span>🚚</span>

                        <span>COD LKR 400 | Bank Transfer LKR 250</span>

                    </div>



                    <!-- Promo / Coupon Code Section -->

                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">

                        <div style="display: flex; gap: 0.5rem;">

                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>

                            ${window.appliedCoupon?`

                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>

                            `:`

                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>

                            `}

                        </div>

                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">

                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}

                        </div>

                    </div>

                    

                    ${window.appliedCoupon?`

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">

                            <span>Subtotal</span>

                            <span>LKR ${t.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">

                            <span>Coupon Discount (${window.appliedCoupon.code})</span>

                            <span>- LKR ${e.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">

                            <span>Total Payable</span>

                            <span>LKR ${a.toFixed(2)}</span>

                        </div>

                    `:`

                        <div class="cart-subtotal">

                            <span>Total Payable</span>

                            <span>LKR ${t.toFixed(2)}</span>

                        </div>

                    `}



                    <div class="checkout-form-section">

                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>

                        <div class="input-group">

                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">

                        </div>

                        <div class="input-group">

                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">

                        </div>

                        <div class="input-group" id="delivery-address-group">

                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">

                        </div>

                        <div class="input-group" id="delivery-city-group">

                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">

                        </div>



                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>

                        <div class="payment-method-selector">

                            ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">

                                <span class="method-label">COD</span>

                            </label>

                            `:""}

                            ${x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="Bank" ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">

                                <span class="method-label">Transfer</span>

                            </label>

                            `:""}

                            ${x.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="ShopPay" ${!x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">

                                <span class="method-label">Shop Cash</span>

                            </label>

                            `:""}

                        </div>

                        

                        <!-- Bank Transfer Info Box -->

                        <div id="bank-details-box" style="display: none;">

                            <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.75rem;">

                                <p style="color: #065f46; font-weight: 800; margin: 0; font-size: 0.82rem; display: flex; align-items: center; gap: 6px;">

                                    <span>✨</span> Lower delivery charge (LKR 250)

                                </p>

                                <p style="color: #047857; margin: 3px 0 0; font-size: 0.75rem; font-weight: 600;">

                                    👇 Select the Bank Account you transferred to (ඔබ මුදල් තැන්පත් කළ ගිණුම තෝරන්න):

                                </p>

                            </div>



                            <!-- Account 1: Slot 1 (e.g. NDB) -->

                            <div id="web-bank-card-1" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot1')" style="background: #f0fdf4 !important; color: #0f172a !important; border: 2px solid #16a34a !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.15); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-1-radio" value="slot1" checked style="accent-color: #16a34a; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-1-title" style="font-weight: 900; color: #b91c1c; font-size: 0.95rem;">🏦 National Development Bank (NDB)</span>

                                    </div>

                                    <span id="web-bank-1-badge" style="font-size: 0.72rem; background: #16a34a; color: #ffffff; padding: 3px 8px; border-radius: 6px; font-weight: 800;">✓ Selected</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-1-accname" style="color: #0f172a; font-weight: 700;">-</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div id="web-bank-1-type-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    Account Type: <span id="web-bank-1-acctype" style="color: #0f172a; font-weight: 700;">Regular Current</span>

                                </div>

                                <div id="web-bank-1-codes-row" style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Bank Code: <strong id="web-bank-1-code" style="color: #334155;">7214</strong></span>

                                    <span>Swift Code: <strong id="web-bank-1-swift" style="color: #334155;">NDBSLKLX</strong></span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; border: 1.5px dashed #16a34a; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-1-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accno', 'Account Number');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <!-- Account 2: Slot 2 (e.g. BOC) -->

                            <div id="web-bank-card-2" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot2')" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1 !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-2-radio" value="slot2" style="accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-2-title" style="font-weight: 900; color: #0284c7; font-size: 0.95rem;">🏦 Bank of Ceylon (BOC)</span>

                                    </div>

                                    <span id="web-bank-2-badge" style="font-size: 0.72rem; background: #f1f5f9; color: #64748b; padding: 3px 8px; border-radius: 6px; font-weight: 700;">Click to select</span>

                                </div>

                                <div id="web-bank-2-branch-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600; padding-left: 26px;">

                                    Branch: <span id="web-bank-2-branch" style="color: #0f172a; font-weight: 700;">Main Branch</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-2-accname" style="color: #0f172a; font-weight: 700;">Account Holder</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-2-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accno', 'Account Number');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <div style="margin-top: 1rem;">

                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>

                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">

                            </div>

                        </div>



                        <!-- Shop Pickup / Branch Selection Box -->

                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">

                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">

                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch

                            </p>



                            <!-- City / Town Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>

                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>

                                  ${bt().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}

                                </select>

                            </div>



                            <!-- Shop / Branch List Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>

                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <!-- Injected by populatePickupShops -->

                                </select>

                            </div>



                            <!-- Selected Shop Info Card -->

                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">

                            </div>

                        </div>

                    </div>



                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">

                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">

                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">

                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 

                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 

                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.

                        </label>

                    </div>



                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">

                        Confirm Order

                    </button>

                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->

                </div>

            `:""}

        </div>

    `,document.getElementById("close-cart-btn").onclick=()=>ke(!1),(i=document.getElementById("checkout-btn"))==null||i.addEventListener("click",Ht),setTimeout(()=>{typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI()},50),window.toggleBankDetails=o=>{const r=document.getElementById("bank-details-box");r&&(r.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const r=document.getElementById("bank-details-box"),s=document.getElementById("shop-pickup-box"),c=document.getElementById("delivery-address-group"),n=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(r&&(r.style.display="block"),typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI(),s&&(s.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(r&&(r.style.display="none"),s&&(s.style.display="block",window.populatePickupShops()),c&&(c.style.display="none"),n&&(n.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(r&&(r.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var d,p,g,m;const o=document.getElementById("pickup-town-select"),r=document.getElementById("pickup-shop-select"),s=document.getElementById("selected-shop-info-card");if(!r)return;const c=o?o.value:"All",n=me();let l=n;c&&c!=="All"&&(l=n.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(c.toLowerCase()))),l.length===0?(r.innerHTML=n.map((u,f)=>`

        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),s&&(s.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${c}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((d=n[0])==null?void 0:d.docId)||((p=n[0])==null?void 0:p.id)||0)):(r.innerHTML=l.map((u,f)=>`

        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),window.onPickupShopSelected(((g=l[0])==null?void 0:g.docId)||((m=l[0])==null?void 0:m.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const r=document.getElementById("selected-shop-info-card");if(!r)return;const s=me(),c=s.find(n=>n.docId===o||n.id===o)||s[0];c&&(r.innerHTML=`

        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${c.name||c.shopName||"Main Branch"}</div>

        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${c.location||c.address||"In-store Pickup Counter"}</div>

        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${c.phone?`Contact: <b>${c.phone}</b>`:"Store Pickup Active"}</div>

        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">

          <span>✓</span> Collect & Pay Cash at this shop counter

        </div>

      `)}}window.applyCouponCode=async()=>{const t=document.getElementById("cart-promo-input"),e=document.getElementById("promo-message");if(!t)return;const a=t.value.trim().toUpperCase();if(!a){e&&(e.innerText="❌ Please enter a promo code.",e.style.color="#ef4444");return}e&&(e.innerText="⏳ Validating coupon...",e.style.color="var(--primary-color)");try{const i=T(Dt,E("code","==",a),E("storeId","==",window.currentStoreId)),o=await N(i);if(o.empty){e&&(e.innerText="❌ Invalid or expired coupon code.",e.style.color="#ef4444");return}const r=o.docs[0],s={...r.data(),id:r.id},c=new Date().toISOString().split("T")[0];if(s.expiryDate<c){e&&(e.innerText="❌ This coupon has expired.",e.style.color="#ef4444");return}if(s.status!=="Active"){e&&(e.innerText="❌ This coupon is inactive.",e.style.color="#ef4444");return}const n=x.reduce((p,g)=>p+g.price*(1-(g.discount||0)/100)*(g.quantity||1),0),l=Xe(s,x,n);if(!l.isValidForCart){e&&(e.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,e.style.color="#ef4444");return}window.appliedCoupon=s,Me();const d=document.getElementById("promo-message");if(d){const p=s.targetType==="specific_products"?" (Selected Items)":s.targetType==="specific_categories"?" (Selected Categories)":"";d.innerText=`✅ Coupon applied: ${s.type==="Percentage"?`${s.value}% OFF`:`LKR ${s.value} OFF`}${p}`,d.style.color="#10b981"}}catch(i){console.error("Error validating coupon:",i),e&&(e.innerText="❌ Error validating coupon code.",e.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,Me()};async function Ht(){var g,m,u,f,y,b,w,k;const t=JSON.parse(sessionStorage.getItem("mec_user"));if(!t){alert("Please login to place an order!");const v=window.currentStoreId?`/login.html?store=${encodeURIComponent(window.currentStoreId)}`:"/login.html";window.location.href=v;return}if(x.length===0)return;const e=document.getElementById("terms-agree");if(e&&!e.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const a=(g=document.getElementById("delivery-phone"))==null?void 0:g.value.trim(),i=(m=document.getElementById("delivery-phone-2"))==null?void 0:m.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),r=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),s=((y=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:y.value)||"COD",c=(b=document.getElementById("deposit-slip"))==null?void 0:b.files[0],n=s==="ShopPay";let l=null,d="All";if(n){d=((w=document.getElementById("pickup-town-select"))==null?void 0:w.value)||"All";const v=(k=document.getElementById("pickup-shop-select"))==null?void 0:k.value,S=me();if(l=S.find(C=>C.docId===v||C.id===v)||S[0],!v&&(!S||S.length===0)){alert("Please select a pickup shop / branch!");return}}if(!a||!n&&(!o||!r)){alert(n?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",a),localStorage.setItem("mec_saved_phone2",i),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",r),s==="Bank"&&!c){alert("Please upload your bank deposit slip!");return}for(const v of x){const S=M.find(C=>C.docId===v.docId)||(window.groupedProducts||[]).find(C=>C.docId===v.docId);if(S&&S.mode!=="Service"&&S.mode!=="Technical"){let C=null;v.selectedVariant&&v.selectedVariant!=="Default"&&S.variants&&(C=S.variants.find(A=>(A.name||A.variantLabel||A.color||A.size||"Variant")===v.selectedVariant));const L=Qe(S,C,s);if((v.quantity||1)>L){alert(s==="ShopPay"?`Sorry! "${v.name}" only has ${L} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${v.name}" only has ${L} available in stock.`);return}}}const p=async(v=null)=>{var S,C;try{const L=x.reduce((h,q)=>h+q.price*(1-(q.discount||0)/100)*(q.quantity||1),0);let A=0,R="";if(window.appliedCoupon){R=window.appliedCoupon.code;const h=Xe(window.appliedCoupon,x,L);h.isValidForCart&&(A=h.discountAmount)}const B=Math.max(0,L-A),F=sessionStorage.getItem("mec_ref_code");let ee="",te=0;if(F)try{const h=T($(P,"affiliates"),E("code","==",F),E("storeId","==",window.currentStoreId));(await N(h)).empty||(ee=F,te=Number((B*.05).toFixed(2)))}catch(h){console.error("Error verifying affiliate referral code at checkout:",h)}const I=window.currentStoreId||"",z=t&&(t.id||t.uid)?t.id||t.uid:"guest-"+Date.now(),Se=t&&(t.name||t.email)?t.name||t.email:a||"Guest Customer",Ie=window.selectedWebStoreBankSlot||"slot1",D=window.webStoreBankAccounts&&window.webStoreBankAccounts[Ie]||((S=window.webStoreBankAccounts)==null?void 0:S.slot1),ne={orderId:"ORD-"+Date.now(),userId:z,userName:Se,userEmail:t&&t.email?t.email:"",phone:a||"",phone2:i||"",branchId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:n?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:n?d:"",pickupShopPhone:n&&(l==null?void 0:l.phone)||"",pickupShopAddress:n&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:n?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:n?d!=="All"?d:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":r||"",items:x.map(h=>({id:h.id||h.docId||"",docId:h.docId||h.id||"",name:h.name||"",price:Number(h.price)||0,cost:Number(h.cost)||0,quantity:Number(h.quantity)||1,discount:Number(h.discount)||0,finalPrice:Number(h.price)*(1-(Number(h.discount)||0)/100)})),subtotal:Number(L)||0,discount:Number(A)||0,couponCode:R||"",total:Number(B)||0,status:"Pending",customerType:(((C=window.currentUserProfile)==null?void 0:C.customerType)||"retail").toLowerCase(),paymentMethod:s||"COD",targetBankSlot:s==="Bank"?Ie:null,targetBankAccountId:s==="Bank"&&(D==null?void 0:D.docId)||null,targetBankName:s==="Bank"?(D==null?void 0:D.bankName)||"Bank":null,targetAccountNo:s==="Bank"?(D==null?void 0:D.accountNo)||"":null,targetAccountTitle:s==="Bank"?(D==null?void 0:D.accountName)||"":null,bankCredited:s==="Bank",slipImage:v||"",codCharge:s==="COD"?400:s==="Bank"?250:0,isShopPending:s==="ShopPay",storeId:I,numericStoreId:"1001",stockDeducted:!0,stockReturned:!1,timestamp:oe(),date:new Date().toLocaleString(),referredBy:ee||"",referredCommission:Number(te)||0},et=V($(P,"stores",I,"orders")),tt=et.id;ne.docId=tt,await Promise.all([Ee(et,ne),Ee(V(At,tt),ne)]);try{const h=St(P);let q=!1;for(const U of x){const Re=U.docId||U.id;if(Re&&Re!=="N/A"){const ot=V(P,"stores",I,"products",Re),nt=await ft(ot);if(nt.exists()){const se=nt.data(),at=Number(U.quantity)||1;let ae={};if(se.variants&&Array.isArray(se.variants)&&se.variants.length>0){const G=[...se.variants];let re=at;for(let j=0;j<G.length&&!(re<=0);j++){const W=G[j],Ce=Number(W.price||W.sellingPrice||se.price||0),xt=Number(U.price||0);if(!U.selectedVariant||U.selectedVariant==="Default"||W.name===U.selectedVariant||W.variantLabel===U.selectedVariant||Math.abs(Ce-xt)<.01){const _e=parseFloat(W.stock)||0;if(_e>0){const rt=Math.min(_e,re);W.stock=_e-rt,re-=rt}}}if(re>0)for(let j=0;j<G.length&&!(re<=0);j++){const W=parseFloat(G[j].stock)||0;if(W>0){const Ce=Math.min(W,re);G[j].stock=W-Ce,re-=Ce}}ae.variants=G,ae.stock=G.reduce((j,W)=>j+(parseFloat(W.stock)||0),0)}else{const G=parseFloat(se.stock)||0;ae.stock=Math.max(0,G-at)}ae.totalStock=ae.stock,ae.updatedAt=oe(),h.update(ot,ae),q=!0}}}q&&(await h.commit(),console.log("[Web Store Checkout] Stock deducted successfully for Order #"+ne.orderId))}catch(h){console.warn("[Web Store Checkout] Stock deduction error (order recorded):",h)}if(s==="Bank"&&D)try{let h=D.docId;if(!h||h==="ndb_default"||h==="boc_default"){const q=T($(P,"stores",I,"bank_accounts"),E("accountNo","==",D.accountNo)),U=await N(q);U.empty||(h=U.docs[0].id)}if(h&&h!=="ndb_default"&&h!=="boc_default"){const q=V(P,"stores",I,"bank_accounts",h);await yt(q,{balance:Be(B),updatedAt:oe()}),await de($(P,"stores",I,"bank_transactions"),{accountId:h,bankName:D.bankName||"Bank Transfer",accountNo:D.accountNo||"",amount:B,type:"Credit",description:`Web Store Bank Transfer: Order #${ne.orderId} (${Se})`,referenceNo:ne.orderId,orderId:ne.orderId,source:"Web Store",date:new Date().toLocaleDateString("sv-SE"),timestamp:oe(),isReconciled:!1,storeId:I}),console.log(`[Web Store Checkout] Credited LKR ${B} to ${D.bankName} (${D.accountNo})`)}}catch(h){console.warn("Error crediting web store bank account:",h)}if(ee)try{const h=T($(P,"affiliates"),E("code","==",ee),E("storeId","==",I)),q=await N(h);if(!q.empty){const U=q.docs[0].id;await Ee(V(P,"affiliates",U),{salesCount:Be(1),totalCommission:Be(te)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(h){console.error("Error updating affiliate statistics post-order:",h)}x=[],xe=0,window.appliedCoupon=null,Je(),ze(),ke(!1),alert(s==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":n?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch(L){console.error("Order error:",L),alert("Error placing order: "+(L.message||"Please try again."))}};if(c){const v=new FileReader;v.onload=S=>{const C=new Image;C.onload=()=>{const L=document.createElement("canvas"),A=1e3,R=1e3;let B=C.width,F=C.height;B>F?B>A&&(F*=A/B,B=A):F>R&&(B*=R/F,F=R),L.width=B,L.height=F,L.getContext("2d").drawImage(C,0,0,B,F);const te=L.toDataURL("image/jpeg",.6);p(te)},C.onerror=()=>{p(S.target.result)},C.src=S.target.result},v.onerror=S=>{console.error("FileReader Error:",S),alert("Error reading slip file. Please try selecting the image again.")},v.readAsDataURL(c)}else p()}function O(){const t=document.querySelector("#product-grid"),e=document.getElementById("pagination-controls");if(!t)return;let a=M.filter(n=>{if(n.mode==="Service"||n.mode==="Technical"||n.mode==="POS")return!1;const l=(n.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const d=ie==="All"||n.category===ie,p=window.matchProductSearch?window.matchProductSearch(n,Q):n.name.toLowerCase().includes(Q)||n.category.toLowerCase().includes(Q)||n.sku&&n.sku.toLowerCase().includes(Q);return d&&p});ce==="recommended"?((!Ue||Ue.length!==a.length)&&(Ue=a.map((n,l)=>({id:l,sort:Math.random()})).sort((n,l)=>n.sort-l.sort).map(n=>n.id)),a.sort(()=>Math.random()-.5)):a.sort((n,l)=>{if(ce==="az")return n.name.localeCompare(l.name);if(ce==="za")return l.name.localeCompare(n.name);if(ce==="low"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return d-p}if(ce==="high"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-d}return 0});const i=new Map;a.forEach(n=>{const l=n.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),d=l?l[1].trim():n.name.trim(),p=l?l[2].trim():(n.size||n.color)&&`${n.size?n.size:""} ${n.color?n.color:""}`.trim()||"Default",g=d.toLowerCase();if(i.has(g)){const m=i.get(g);m.totalStock+=n.totalStock!==void 0?n.totalStock:n.stock||0;const u=parseFloat(n.wholesalePrice)||0,f=parseFloat(n.stock)||0,y=parseFloat(m.wholesalePrice)||0;u>0&&(y<=0||f>0&&(m.stock||0)<=0)&&(m.wholesalePrice=u,parseFloat(n.loyaltyPrice)>0&&(m.loyaltyPrice=n.loyaltyPrice),parseFloat(n.price)>0&&(m.price=n.price),parseFloat(n.cost)>0&&(m.cost=n.cost));const b=(n.variants||[]).map(w=>({...w,sourceDocId:n.docId}));b.length===0&&b.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),m.variants=[...m.variants,...b]}else{const m=(n.variants||[]).map(u=>({...u,sourceDocId:n.docId}));m.length===0&&m.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),i.set(g,{...n,name:d,totalStock:n.totalStock!==void 0?n.totalStock:n.stock||0,variants:m})}}),i.forEach(n=>{if(n.variants=Ye(n.variants,n.name,n.price),n.variants&&n.variants.length>0){const d=n.variants.find(p=>parseFloat(p.wholesalePrice)>0&&parseFloat(p.stock)>0)||n.variants.find(p=>parseFloat(p.wholesalePrice)>0);d&&(parseFloat(d.wholesalePrice)>0&&(n.wholesalePrice=parseFloat(d.wholesalePrice)),parseFloat(d.loyaltyPrice)>0&&(n.loyaltyPrice=parseFloat(d.loyaltyPrice)))}const l=n.variants.reduce((d,p)=>d+(parseFloat(p.stock)||0)+(parseFloat(p.wStock)||0),0);l>0&&(n.stock=l,n.totalStock=l)}),window.groupedProducts=Array.from(i.values());const o=window.groupedProducts.length,r=Math.ceil(o/Oe);_>r&&r>0&&(_=r),_<1&&(_=1);const s=(_-1)*Oe,c=window.groupedProducts.slice(s,s+Oe);if(window.groupedProducts.length===0){t.innerHTML=`

      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">

        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>

        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>

        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${Q}</strong>".<br>Try a different keyword or browse all categories.</p>

        <button onclick="window.clearSearch()" 

          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"

          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">

          Clear Search

        </button>

      </div>`,e&&(e.innerHTML="");return}if(t.innerHTML=c.map(n=>{const l=n.variants&&n.variants.length>1,d=n.variants&&n.variants.length>0?n.variants[0]:null,p=pe(n,d),g=p.retailPrice,m=p.discountedPrice,u=p.isSpecial,f=p.userType,y=Number(n.discount)||0;let b=ye(n,d);isNaN(b)&&(b=0);let w=n.image;(!w||w.trim()===""||w.includes("/logo.png"))&&d&&(d.images&&d.images.length>0?w=d.images[0]:d.image&&(w=d.image)),w=ve(w,n.name);const k=n.timestamp?typeof n.timestamp.toMillis=="function"?n.timestamp.toMillis():typeof n.timestamp=="number"?n.timestamp:0:0,v=k>0&&Date.now()-k<10080*60*1e3;return`

    <div class="product-card" id="product-${n.docId}">

      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${n.docId}')">

        <div class="image-slider-container" style="height: 100%; width: 100%;">

            <img src="${w}" class="main-product-img" alt="${n.name}" 

                loading="lazy" decoding="async"

                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') && !window.currentStoreData.logoUrl.includes('mec-logo') ? window.currentStoreData.logoUrl : 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='80' height='80' fill='none'%3E%3Crect width='80' height='80' rx='14' fill='%231e293b'/%3E%3Cpath d='M40 20L62 31.5V56.5L40 68L18 56.5V31.5L40 20Z' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M18 31.5L40 43L62 31.5' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M40 43V68' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E');" 

                style="width:100%; height:100%; object-fit:cover;">

        </div>

        ${b<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}

        ${y>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${y}% OFF</div>`:v?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}

        

        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">

            ${((d==null?void 0:d.images)||[n.image]).map((S,C)=>`<div class="dot ${C===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${C===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}

        </div>



        ${l?`

          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')">

            Select Options

          </button>

        `:`

          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')" ${b<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>

            ${b<=0?"Out of Stock":"Add to Cart"}

          </button>

        `}

      </div>

      <div class="product-info">

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">

          <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px;">${n.category||"General"}</div>

          <div class="stock-display" style="font-size: 0.72rem; font-weight:700;">

            ${b<=0?'<span style="color:#ef4444; background:rgba(239,68,68,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Out of Stock</span>':b<5?`<span style="color:#f59e0b; background:rgba(245,158,11,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Only ${b} left</span>`:`<span style="color:#10b981; font-weight:700;">Stock: ${b}</span>`}

          </div>

        </div>

        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${n.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">

          ${n.name}

        </div>

        





        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">

            ${y>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${g.toFixed(2)}</span>`:""}

            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${m.toFixed(2)}</span>

            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}

        </div>

      </div>

    </div>`}).join(""),e)if(r>1){let n=`<button class="pag-nav-btn" ${_===1?"disabled":""} onclick="window.changePage(${_-1})">‹ Previous</button>`;const l=5;let d=Math.max(1,_-2),p=Math.min(r,d+l-1);p===r&&(d=Math.max(1,p-l+1)),d>1&&(n+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',d>2&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let g=d;g<=p;g++)n+=`<button class="pag-page-btn ${g===_?"active":""}" onclick="window.changePage(${g})">${g}</button>`;p<r&&(p<r-1&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),n+=`<button class="pag-page-btn" onclick="window.changePage(${r})">${r}</button>`),n+=`<button class="pag-nav-btn" ${_===r?"disabled":""} onclick="window.changePage(${_+1})">Next ›</button>`,e.innerHTML=n}else e.innerHTML=""}window.changePage=t=>{var e;_=t,O(),(e=document.getElementById("shop-section"))==null||e.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(t,e)=>{const a=window.groupedProducts?window.groupedProducts.find(k=>k.docId===t):null,i=document.getElementById(`product-${t}`);if(!a||!i)return;const o=a.variants&&a.variants[e]?a.variants[e]:null,r=pe(a,o),s=r.retailPrice,c=r.discountedPrice,n=r.isSpecial,l=Number(a.discount)||0,d=o&&o.stock!==void 0?o.stock:a.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:a.images&&a.images.length>0?p=a.images:p=[a.image];const g=p.map(k=>ve(k,a.name)),m=i.querySelector(".original-price"),u=i.querySelector(".final-price");m&&(m.innerText=`LKR ${s.toFixed(2)}`,m.style.display=l>0||n?"inline":"none"),u&&(u.innerText=`LKR ${c.toFixed(2)}`);const f=i.querySelector(".stock-display");f.innerText=`Stock: ${d}`,f.style.color=d<5?"#ef4444":"#10b981";const y=i.querySelector(".add-to-cart-btn");d<=0?(y.disabled=!0,y.innerText="Out of Stock",y.style.background="#cbd5e1",y.style.cursor="not-allowed"):(y.disabled=!1,y.innerText="Add to Cart",y.style.background="",y.style.cursor="pointer");const b=i.querySelector(".main-product-img");b.src=g[0];const w=i.querySelector(".image-dots");if(w.innerHTML=g.map((k,v)=>`<div class="dot ${v===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${v===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),g.length>1){let k=0;i.imageInterval&&clearInterval(i.imageInterval),i.imageInterval=setInterval(()=>{k=(k+1)%g.length,b.style.opacity="0.5",setTimeout(()=>{b.src=g[k],b.style.opacity="1",w.querySelectorAll(".dot").forEach((S,C)=>{S.style.background=C===k?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else i.imageInterval&&clearInterval(i.imageInterval)};function jt(){const t=document.getElementById("nav-auth-item"),e=document.getElementById("user-profile");document.getElementById("user-display-name"),It(it,a=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),a){const i={name:a.displayName||a.email.split("@")[0],email:a.email,id:a.uid};sessionStorage.setItem("mec_user",JSON.stringify(i));const o=()=>{var v,S,C,L,A;if(!t)return;const d=(((v=window.currentUserProfile)==null?void 0:v.customerType)||"retail").toLowerCase(),p=((S=window.currentUserProfile)==null?void 0:S.phone)||((C=window.currentUserProfile)==null?void 0:C.contact)||"",g=a.photoURL||((L=window.currentUserProfile)==null?void 0:L.photoURL)||((A=window.currentUserProfile)==null?void 0:A.avatar)||"",u=(R=>{if(!R)return"U";const B=R.trim().split(" ");return B.length>=2?(B[0][0]+B[1][0]).toUpperCase():R.slice(0,2).toUpperCase()})(i.name),f=d==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':d==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",y=d==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">

               <span>👑</span> Wholesale Customer (Wholesale Price Active)

             </div>`:d==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>💎</span> Loyalty Card Member Active

                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>🛍️</span> Standard Retail Customer

                 </div>`;t.innerHTML=`

          <div style="position: relative; display: inline-block;">

            <!-- Circular Avatar Only Trigger Button -->

            <button id="user-profile-trigger" style="

              background: transparent;

              border: none;

              padding: 2px;

              cursor: pointer;

              outline: none;

              display: flex;

              align-items: center;

              justify-content: center;

              position: relative;

            " title="${i.name}">

              

              <!-- Circular Avatar Photo / Initials -->

              <div style="

                width: 38px;

                height: 38px;

                border-radius: 50%;

                background: linear-gradient(135deg, #0284c7, #6366f1);

                display: flex;

                align-items: center;

                justify-content: center;

                font-weight: 800;

                font-size: 0.88rem;

                color: white;

                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);

                border: 2px solid ${d==="wholesale"?"#eab308":d==="loyalty"?"#10b981":"#38bdf8"};

                overflow: hidden;

                flex-shrink: 0;

                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;

              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 

                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">

                ${g?`<img src="${g}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:u}

              </div>



              <!-- Status Badge Dot -->

              ${d==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':d==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}

            </button>



            <!-- Modern Floating Profile Card Dropdown -->

            <div id="user-profile-dropdown" style="

              display: none;

              position: absolute;

              right: 0;

              top: calc(100% + 12px);

              width: 290px;

              background: #0f172a;

              border: 1px solid rgba(255, 255, 255, 0.15);

              border-radius: 16px;

              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);

              padding: 1.25rem;

              z-index: 10000;

              text-align: left;

            ">

              <!-- Profile Card Header -->

              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">

                <div style="

                  width: 46px;

                  height: 46px;

                  border-radius: 50%;

                  background: linear-gradient(135deg, #0284c7, #8b5cf6);

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  font-weight: 900;

                  font-size: 1.1rem;

                  color: white;

                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);

                  border: 2px solid rgba(255,255,255,0.6);

                  overflow: hidden;

                  flex-shrink: 0;

                ">

                  ${g?`<img src="${g}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:u}

                </div>

                <div style="overflow: hidden; flex: 1;">

                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">

                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">

                      ${i.name}

                    </span>

                    ${f}

                  </div>

                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">

                    ${i.email||"Registered Customer"}

                  </div>

                </div>

              </div>



              <!-- Account Details & Benefits -->

              <div style="margin: 12px 0;">

                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">

                  Account Membership

                </div>

                ${y}

                

                ${p?`

                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">

                    <span style="color:#38bdf8;">📞</span> <span>${p}</span>

                  </div>

                `:""}

              </div>



              <!-- Quick Actions -->

              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">

                <a href="/track.html" style="

                  display: flex;

                  align-items: center;

                  justify-content: space-between;

                  padding: 8px 12px;

                  background: rgba(255, 255, 255, 0.05);

                  border: 1px solid rgba(255, 255, 255, 0.08);

                  border-radius: 8px;

                  color: #f1f5f9;

                  text-decoration: none;

                  font-size: 0.82rem;

                  font-weight: 600;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"

                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">

                  <span style="display:flex; align-items:center; gap:8px;">

                    <span>📦</span> Track My Orders

                  </span>

                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>

                </a>

              </div>



              <!-- Divider & Logout Button -->

              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">

                <button id="nav-logout-btn" style="

                  width: 100%;

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  gap: 8px;

                  background: rgba(239, 68, 68, 0.12);

                  border: 1px solid rgba(239, 68, 68, 0.3);

                  color: #f87171;

                  padding: 8px 12px;

                  border-radius: 8px;

                  font-size: 0.85rem;

                  font-weight: 700;

                  cursor: pointer;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"

                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">

                  <span>🚪</span> Log Out

                </button>

              </div>

            </div>

          </div>

        `;const b=document.getElementById("user-profile-trigger"),w=document.getElementById("user-profile-dropdown");b&&w&&(b.onclick=R=>{R.stopPropagation();const B=w.style.display==="block";w.style.display=B?"none":"block"});const k=document.getElementById("nav-logout-btn");k&&(k.onclick=async R=>{if(R.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await Et(it),window.location.href="/"}catch(B){console.error("Logout Error:",B),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",d=>{const p=document.getElementById("user-profile-trigger"),g=document.getElementById("user-profile-dropdown");g&&p&&!p.contains(d.target)&&!g.contains(d.target)&&(g.style.display="none")}),o();const r=(a.email||"").trim(),s=r.toLowerCase(),c=window.currentStoreId||"",n=T($(P,"stores",c,"customers"),E("email","==",r)),l=T($(P,"stores",c,"customers"),E("email","==",s));Promise.all([N(n),N(l)]).then(([d,p])=>{let g=null;if(d.empty?p.empty||(g=p.docs[0].data()):g=d.docs[0].data(),g){const m=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),O()}else{const m=window.currentStoreId||"";N(T($(P,"stores",m,"customers"))).then(u=>{const f=(a.displayName||a.email.split("@")[0]||"").trim().toLowerCase(),y=u.docs.find(b=>{const w=b.data(),k=(w.email||"").trim().toLowerCase(),v=(w.phone||"").trim(),S=(w.name||"").trim().toLowerCase(),C=k&&k===s,L=a.phoneNumber&&v&&(v===a.phoneNumber||a.phoneNumber.includes(v)),A=S&&f&&(S===f||f.includes(S)||S.includes(f)||f.split(" ")[0]===S);return C||L||A});if(y){const b=y.data(),w=(b.customerType||b.type||(b.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...b,customerType:w,docId:y.id},!b.email&&a.email&&yt(V(P,"stores",m,"customers",y.id),{email:a.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),O()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),O()})}}).catch(d=>{console.error("Error fetching user profile:",d),window.currentUserProfile={customerType:"retail"},o(),O()})}else{if(sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},O(),t){const i=window.currentStoreId?`/login.html?store=${encodeURIComponent(window.currentStoreId)}`:"/login.html";t.innerHTML=`<a href="${i}">Login</a>`}e&&(e.style.display="none")}})}function Vt(){const t=document.getElementById("reviews-container");if(!t)return;const e=$(P,"reviews"),a=T(e,Pt("timestamp","desc"),Ct(15));be(a,i=>{const o=i.docs.map(r=>r.data());if(o.length===0){t.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}t.innerHTML=o.map(r=>`

      <div class="review-card">

        <div class="review-stars">

          ${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}

        </div>

        <p class="review-comment">"${r.comment||"No comment provided."}"</p>

        <div class="review-footer">

          <span class="review-author">${r.userName}</span>

          <span class="review-date">${r.date}</span>

        </div>

      </div>

    `).join("")})}Ft();jt();Vt();const Ke="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let He=null;try{Ke&&(He=new kt(Ke))}catch(t){console.warn("Could not instantiate GoogleGenerativeAI client:",t)}function pt(t,e){if(!M||M.length===0)return e?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const i=(t||"").toLowerCase().split(/\s+/).filter(r=>r.length>2),o=M.map(r=>{let s=0;const c=(r.name||"").toLowerCase(),n=(r.category||"").toLowerCase(),l=(r.description||"").toLowerCase();return i.forEach(d=>{c.includes(d)&&(s+=3),n.includes(d)&&(s+=2),l.includes(d)&&(s+=1)}),{product:r,score:s}}).filter(r=>r.score>0).sort((r,s)=>s.score-r.score);if(o.length>0){const r=o.slice(0,3).map(s=>s.product);return e?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${r.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=c.wholesalePrice?` | තොග මිල: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${r.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"In Stock":"Out of Stock",l=c.wholesalePrice?` | Wholesale: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return e?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function Gt(t,e){var i,o,r,s,c,n;const a=/[\u0D80-\u0DFF]/.test(t)||e==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(t||"").toLowerCase().includes(l));try{const l=((i=window.currentStoreData)==null?void 0:i.name)||"Official Store",d=(M||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(y=>`${y.name||y.variantLabel||"Var"}-Stock:${y.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.

Available Inventory & Prices:

${d}



CRITICAL RULES:

1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).

2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.

3. Keep answers concise, clear, and direct (max 2-3 short sentences).

4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(He)try{const b=(await(await He.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${t}"`)).response).text().trim();if(b)return b}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const g=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Ke)}`,m=await fetch(g,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${t}"`}]}]})});if(m.ok){const u=await m.json(),f=(n=(c=(s=(r=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:r.content)==null?void 0:s.parts)==null?void 0:c[0])==null?void 0:n.text;if(f&&f.trim())return f.trim()}return pt(t,a)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),pt(t,a)}}window.toggleGeminiChat=t=>{var o;const e=document.getElementById("gemini-chat-window"),a=document.getElementById("gemini-bubble");if(!e)return;(t!=null?!!t:!e.classList.contains("active"))?(e.classList.add("active"),a&&a.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):e.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const t=document.getElementById("gemini-chat-input"),e=document.getElementById("gemini-chat-messages");if(!t||!e||!t.value.trim())return;const a=t.value.trim();t.value="";const i=document.createElement("div");i.className="user-msg",i.textContent=a,e.appendChild(i),e.scrollTop=e.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",e.appendChild(o),e.scrollTop=e.scrollHeight;const r=a.toLowerCase(),s=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let c=a,n=!1;if(s.forEach(g=>{r.includes(g)&&(n=!0)}),n&&(s.forEach(g=>{c=c.replace(new RegExp(g,"gi"),"")}),c=c.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),c.length>1)){window.searchQuery=c,Q=c;const g=document.getElementById("store-search");g&&(g.value=c),_=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(a)||["mata","thiyenawada","tiyenawada","poth"].some(g=>r.includes(g)),d=await Gt(a,l?"si":"en");o.textContent=d,e.scrollTop=e.scrollHeight};window.talkToAgentWhatsApp=()=>{var r,s,c;const t=document.getElementById("gemini-chat-messages");let e="";t&&(e=Array.from(t.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let a=((r=window.currentStoreData)==null?void 0:r.phone)||((s=window.systemConfig)==null?void 0:s.invPhone)||"94770658356";a=a.replace(/[^0-9]/g,""),a.startsWith("0")&&(a="94"+a.substring(1));const i=`Hi ${((c=window.currentStoreData)==null?void 0:c.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(i+e);window.open(`https://wa.me/${a}?text=${o}`,"_blank")};setTimeout(()=>{const t=document.getElementById("gemini-bubble");t&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(t.classList.add("active"),setTimeout(()=>t.classList.remove("active"),8e3))},5e3);const ut=document.getElementById("gemini-orb-btn");ut&&ut.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const t=wt.get("ref");if(t&&(sessionStorage.setItem("mec_ref_code",t),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const e=T($(P,"affiliates"),E("code","==",t),E("storeId","==",window.currentStoreId)),a=await N(e);if(!a.empty){const i=V(P,"affiliates",a.docs[0].id);await Ee(i,{clicks:Be(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${t}`)}}catch(e){console.error("Error incrementing referral click:",e)}}};function Jt(){if(document.getElementById("affiliate-portal-modal"))return;const t=document.createElement("div");t.id="affiliate-portal-modal",t.className="modal-overlay",t.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",t.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="aff-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>

        

        <!-- Tab navigation inside modal -->

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>

        </div>



        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>

        </form>

      </div>



      <div id="aff-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>

        

        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">

          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>

          <div style="display:flex; gap:10px; align-items:center;">

            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">

            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>

          </div>

        </div>



        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(t)}function Qt(){if(document.getElementById("seller-portal-modal"))return;const t=document.createElement("div");t.id="seller-portal-modal",t.className="modal-overlay",t.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",t.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="seller-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>

        

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>

        </div>



        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>

        </form>

      </div>



      <div id="seller-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">

          <div>

            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>

            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>

          </div>

          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">

            Pending

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">

          

          <!-- Add Product Form -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>

            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">

              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>

              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>

            </form>

          </div>



          <!-- Product List -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>

            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">

              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>

            </div>

          </div>

        </div>



        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(t)}window.toggleAffiliatePortal=async t=>{Jt();const e=document.getElementById("affiliate-portal-modal");if(e&&(e.style.display=t?"flex":"none",e.classList.toggle("active",t),t)){const a=localStorage.getItem("mec_affiliate_user");if(a){const i=JSON.parse(a);try{const o=T($(P,"affiliates"),E("email","==",i.email),E("storeId","==",window.currentStoreId)),r=await N(o);if(r.empty)localStorage.removeItem("mec_affiliate_user"),je();else{const s={...r.docs[0].data(),docId:r.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),Le(s)}}catch(o){console.error(o),Le(i)}}else je()}};function je(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=t=>{const e=document.getElementById("aff-login-form"),a=document.getElementById("aff-register-form"),i=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");t==="login"?(e&&(e.style.display="flex"),a&&(a.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(e&&(e.style.display="none"),a&&(a.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async t=>{t.preventDefault();const e=document.getElementById("aff-login-email").value.trim(),a=document.getElementById("aff-login-pass").value;try{const i=T($(P,"affiliates"),E("email","==",e),E("password","==",a),E("storeId","==",window.currentStoreId)),o=await N(i);if(o.empty)alert("Invalid email address or password.");else{const r={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(r)),Le(r)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async t=>{t.preventDefault();const e=document.getElementById("aff-reg-name").value.trim(),a=document.getElementById("aff-reg-email").value.trim(),i=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const r=T($(P,"affiliates"),E("email","==",a),E("storeId","==",window.currentStoreId));if(!(await N(r)).empty){alert("An account with this email is already registered as a partner.");return}const c=e.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),n={name:e,email:a,phone:i,password:o,code:c,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:oe()},l=await de($(P,"affiliates"),n);n.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(n)),Le(n)}catch(r){console.error(r),alert("Registration failed. Please try again.")}};function Le(t){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=t.name||"Promoter";const e=window.location.protocol,a=window.location.host,i=window.location.pathname;let o=`${e}//${a}${i}`;window.currentStoreId?o+=`?store=${window.currentStoreId}&ref=${t.code}`:o+=`?ref=${t.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=t.clicks||0,document.getElementById("aff-sales").innerText=t.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(t.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const t=document.getElementById("aff-referral-url");t&&(t.select(),t.setSelectionRange(0,99999),navigator.clipboard.writeText(t.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),je()};window.toggleSellerPortal=async t=>{Qt();const e=document.getElementById("seller-portal-modal");if(e&&(e.style.display=t?"flex":"none",e.classList.toggle("active",t),t)){const a=localStorage.getItem("mec_seller_user");if(a){const i=JSON.parse(a);try{const o=T($(P,"vendor_shops"),E("email","==",i.email),E("storeId","==",window.currentStoreId)),r=await N(o);if(r.empty)localStorage.removeItem("mec_seller_user"),Ve();else{const s={...r.docs[0].data(),docId:r.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),$e(s)}}catch(o){console.error(o),$e(i)}}else Ve()}};function Ve(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=t=>{const e=document.getElementById("seller-login-form"),a=document.getElementById("seller-register-form"),i=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");t==="login"?(e&&(e.style.display="flex"),a&&(a.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(e&&(e.style.display="none"),a&&(a.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async t=>{t.preventDefault();const e=document.getElementById("seller-login-email").value.trim(),a=document.getElementById("seller-login-pass").value;try{const i=T($(P,"vendor_shops"),E("email","==",e),E("password","==",a),E("storeId","==",window.currentStoreId)),o=await N(i);if(o.empty)alert("Invalid email address or password.");else{const r={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(r)),$e(r)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleSellerRegister=async t=>{var s;t.preventDefault();const e=document.getElementById("seller-reg-shopname").value.trim(),a=document.getElementById("seller-reg-owner").value.trim(),i=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),r=document.getElementById("seller-reg-pass").value;try{const c=T($(P,"vendor_shops"),E("shopName","==",e),E("storeId","==",window.currentStoreId));if(!(await N(c)).empty){alert("This shop name is already registered.");return}const l=T($(P,"vendor_shops"),E("email","==",i),E("storeId","==",window.currentStoreId));if(!(await N(l)).empty){alert("This email is already registered to a shop.");return}const p={shopName:e,ownerName:a,email:i,phone:o,password:r,status:"pending",storeId:window.currentStoreId,timestamp:oe()},g=await de($(P,"vendor_shops"),p);p.docId=g.id,localStorage.setItem("mec_seller_user",JSON.stringify(p)),$e(p);try{const m=(s=window.systemConfig)==null?void 0:s.smsConfig;if(m!=null&&m.apiKey&&(m!=null&&m.userId)){const u="+94770658356",f=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${e}
Owner: ${a}
Phone: ${o}
Email: ${i}`,y=`${m.apiBase||"https://www.smslenz.lk/api/send-sms"}?user_id=${m.userId}&api_key=${m.apiKey}&sender_id=${m.senderId||"MECPOS"}&contact=${encodeURIComponent(u)}&message=${encodeURIComponent(f)}`;fetch(y,{method:"GET",mode:"no-cors"}).catch(()=>{})}}catch(m){console.warn("Vendor registration alert:",m)}}catch(c){console.error(c),alert("Shop registration failed. Please try again.")}};async function $e(t){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=t.shopName||"My Brand Shop";const e=document.getElementById("seller-dash-status-badge");e&&(e.innerText=t.status||"pending",t.status==="active"?(e.style.background="rgba(16, 185, 129, 0.2)",e.style.color="#10b981"):(e.style.background="rgba(251, 191, 36, 0.2)",e.style.color="#fbbf24")),await vt(t.email)}async function vt(t){const e=document.getElementById("seller-products-list");if(e){e.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const a=T(Ge,E("vendorId","==",t),E("storeId","==",window.currentStoreId)),i=await N(a);if(i.empty)e.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";i.forEach(r=>{const s=r.data(),c=s.status==="active"?"#10b981":"#fbbf24";o+=`

          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">

            <div>

              <span style="font-weight:bold; font-size:0.85rem; display:block;">${s.name||""}</span>

              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${s.price||0}</span>

            </div>

            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${c};">${s.status||"pending"}</span>

          </div>

        `}),e.innerHTML=o}}catch(a){console.error(a),e.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async t=>{t.preventDefault();const e=localStorage.getItem("mec_seller_user");if(!e)return;const a=JSON.parse(e),i=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),r=document.getElementById("seller-prod-category").value.trim(),s=document.getElementById("seller-prod-image").value.trim(),c=document.getElementById("seller-prod-desc").value.trim();try{const n={name:i,price:Number(o),category:r,image:s||"",description:c||"",status:"pending",vendorId:a.email,storeId:window.currentStoreId,timestamp:oe(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await de(Ge,n),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await vt(a.email)}catch(n){console.error(n),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),Ve()};window.addEventListener("beforeunload",function(t){var e;(e=window.chrome)!=null&&e.webview||window.electron||window.electronAPI||navigator.onLine||(t.preventDefault(),t.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
