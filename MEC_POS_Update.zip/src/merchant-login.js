    // ─── Modular Firebase SDK ──────────────────────────────────
    import { db, auth } from './firebase.js';
    import { signInWithEmailAndPassword } from 'firebase/auth';
    import { collection, query, where, limit, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
    import { CLIENT_VERSION } from './modules/system.js';

    // Cloud logging bridge for remote diagnostics
    window.uploadLogToCloud = async function(message, type = 'csharp') {
        try {
            const storeId = localStorage.getItem('mecpos_last_store_id') || 'unknown';
            await addDoc(collection(db, 'system_logs'), {
                storeId,
                type,
                message,
                timestamp: serverTimestamp(),
                userAgent: navigator.userAgent
            });
        } catch(e) {
            console.error("Cloud logging failed:", e);
        }
    };

    // ─── SaaS Store & Merchant Logo Resolution ───────────────────
    async function syncMerchantBranding() {
        try {
            const urlParams = new URLSearchParams(window.location.search);
            const storeParam = urlParams.get('store');
            const hostname = window.location.hostname;
            const cleanHostname = hostname.replace(/^www\./, '');
            const isPlatformDomain = ['mecpos.web.lk', 'mec-pos-shop.web.app', 'localhost', '127.0.0.1'].includes(cleanHostname);

            // On main platform domain without explicit ?store= parameter, maintain MEC POS ZENITH branding
            if (isPlatformDomain && !storeParam) {
                document.querySelectorAll('.brand-title').forEach(el => {
                    el.textContent = 'MEC POS ZENITH';
                });
                document.querySelectorAll('.brand-subtitle').forEach(el => {
                    el.textContent = `THE BEST SOFT SOLUTIONS • v${CLIENT_VERSION}`;
                });
                document.title = `Merchant Login — MEC POS ZENITH v${CLIENT_VERSION}`;
                return;
            }

            let matchedStore = null;
            if (storeParam) {
                const q = query(collection(db, 'stores'), where('slug', '==', storeParam));
                const snap = await getDocs(q);
                if (!snap.empty) matchedStore = snap.docs[0].data();
            }

            if (!matchedStore && !isPlatformDomain) {
                const qDom = query(collection(db, 'stores'), where('domain', '==', cleanHostname));
                const snapDom = await getDocs(qDom);
                if (!snapDom.empty) matchedStore = snapDom.docs[0].data();
            }

            if (matchedStore) {
                console.log("[Merchant Login] Dynamic logo resolved for:", matchedStore.name || matchedStore.storeName || storeParam);

                if (matchedStore.logoUrl) {
                    document.querySelectorAll('.logo-ring img, .logo-3d-img').forEach(img => {
                        img.src = matchedStore.logoUrl;
                    });
                }

                const name = matchedStore.name || matchedStore.storeName;
                if (name) {
                    document.querySelectorAll('.brand-title').forEach(el => {
                        el.textContent = name;
                    });
                    document.title = `${name} — Merchant Login`;
                }
            }
        } catch(e) {
            console.error("[Merchant Login] Branding sync error:", e);
        }
    }
    syncMerchantBranding();

    // ─── Super Admin Email Identifiers ─────────────────────
    const SUPER_ADMIN_EMAILS = [
        'mecbookshop@gmail.com',
        'malinduec@gmail.com',
        'mecposadmin@gmail.com'
    ];

    // ─── Sliding Overlay Panel Toggle State ─────────────────────
    const mainContainer = document.getElementById('main-auth-container');
    const btnToggleToRegister = document.getElementById('btn-toggle-to-register');
    const btnToggleToLogin = document.getElementById('btn-toggle-to-login');
    const btnMobileSwitchReg = document.getElementById('btn-switch-mobile-reg');
    const btnMobileSwitchLogin = document.getElementById('btn-switch-mobile-login');

    function switchToRegister() {
        if (mainContainer) {
            mainContainer.classList.add('is-register');
        }
    }

    function switchToLogin() {
        if (mainContainer) {
            mainContainer.classList.remove('is-register');
        }
    }

    btnToggleToRegister?.addEventListener('click', switchToRegister);
    btnToggleToLogin?.addEventListener('click', switchToLogin);
    btnMobileSwitchReg?.addEventListener('click', (e) => { e.preventDefault(); switchToRegister(); });
    btnMobileSwitchLogin?.addEventListener('click', (e) => { e.preventDefault(); switchToLogin(); });

    // ─── Desktop app detection with retry loop ───────────────────
    function initDesktopAppControls() {
        const isDesktop = !!window.electron || !!window.electronAPI || !!window.chrome?.webview;
        if (isDesktop) {
            const winControls = document.getElementById('win-controls');
            if (winControls && !winControls.classList.contains('visible')) {
                winControls.classList.add('visible');
                console.log("[Desktop] Window controls initialized and shown.");
                
                // Ensure not fullscreen on login page
                if (window.electron) {
                    window.electron.setAppFullscreen?.(false);
                } else if (window.chrome?.webview) {
                    window.chrome.webview.postMessage({ type: 'setAppFullscreen', flag: false });
                }

                // Window control buttons (macOS style — Close & Minimize only)
                document.getElementById('btn-close')?.addEventListener('click', () => {
                    if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'close' });
                    else if (window.electronAPI) window.electronAPI.close?.();
                    else if (window.electron) window.electron.close?.();
                });
                document.getElementById('btn-minimize')?.addEventListener('click', () => {
                    if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'minimize' });
                    else if (window.electronAPI) window.electronAPI.minimize?.();
                    else if (window.electron) window.electron.minimize?.();
                });
            }
            return true;
        }
        return false;
    }

    // Try immediately and poll if not detected (WebView2 init race condition)
    if (!initDesktopAppControls()) {
        let attempts = 0;
        const intervalId = setInterval(() => {
            attempts++;
            if (initDesktopAppControls() || attempts >= 30) {
                clearInterval(intervalId);
            }
        }, 150);
    }

    // ─── Password toggle handlers ─────────────────────────────
    document.getElementById('toggle-pass')?.addEventListener('click', () => {
        const inp = document.getElementById('login-pass');
        const btn = document.getElementById('toggle-pass');
        if (inp && btn) {
            const isPass = inp.type === 'password';
            inp.type = isPass ? 'text' : 'password';
            btn.textContent = isPass ? '🔒' : '👁️';
        }
    });

    document.getElementById('toggle-reg-pass')?.addEventListener('click', () => {
        const inp = document.getElementById('reg-pass');
        const btn = document.getElementById('toggle-reg-pass');
        if (inp && btn) {
            const isPass = inp.type === 'password';
            inp.type = isPass ? 'text' : 'password';
            btn.textContent = isPass ? '🔒' : '👁️';
        }
    });

    // ─── Dynamic Plan Pricing & Slug Auto-fill ──────────────
    const PLAN_PRICES = {
        'POSLite':     { Monthly: 'LKR 1,000/mo', Yearly: 'LKR 9,996/yr (Save 17%)',  Lifetime: 'LKR 35,000 (One-Time)' },
        'POSStandard': { Monthly: 'LKR 1,500/mo', Yearly: 'LKR 15,000/yr (Save 17%)', Lifetime: 'LKR 49,000 (One-Time)' },
        'POSPro':      { Monthly: 'LKR 1,800/mo', Yearly: 'LKR 18,000/yr (Save 17%)', Lifetime: 'LKR 59,000 (One-Time)' },
        'Starter':     { Monthly: 'LKR 4,900/mo', Yearly: 'LKR 48,996/yr (Save 17%)', Lifetime: 'LKR 99,000 (One-Time)' },
        'Business':    { Monthly: 'LKR 9,900/mo', Yearly: 'LKR 99,000/yr (Save 17%)', Lifetime: 'LKR 149,900 (One-Time)' },
        'Enterprise':  { Monthly: 'LKR 24,900/mo', Yearly: 'LKR 249,000/yr (Save 17%)', Lifetime: 'LKR 299,000 (One-Time)' },
        'Trial':       { Monthly: 'Free (1 Month)', Yearly: 'Free (1 Month)', Lifetime: 'Free (1 Month)' }
    };

    function updateRegPriceBadge() {
        const tier = document.getElementById('reg-plan-tier')?.value || 'POSStandard';
        const cycle = document.getElementById('reg-billing-cycle')?.value || 'Monthly';
        const badge = document.getElementById('reg-price-badge');
        if (badge && PLAN_PRICES[tier]) {
            badge.textContent = `Price: ${PLAN_PRICES[tier][cycle] || PLAN_PRICES[tier].Monthly}`;
        }
    }

    document.getElementById('reg-plan-tier')?.addEventListener('change', updateRegPriceBadge);
    document.getElementById('reg-billing-cycle')?.addEventListener('change', updateRegPriceBadge);
    updateRegPriceBadge();

    // Auto-generate slug as store name is typed
    document.getElementById('reg-store-name')?.addEventListener('input', (e) => {
        const slugInput = document.getElementById('reg-slug');
        if (slugInput && !slugInput.dataset.manuallyEdited) {
            slugInput.value = e.target.value
                .toLowerCase()
                .trim()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-');
        }
    });

    document.getElementById('reg-slug')?.addEventListener('input', (e) => {
        e.target.dataset.manuallyEdited = 'true';
    });

    // ─── Full Store Registration Handler ─────────────────────
    async function doRegister() {
        const planTier = document.getElementById('reg-plan-tier')?.value || 'POSStandard';
        const billingCycle = document.getElementById('reg-billing-cycle')?.value || 'Monthly';
        const ownerName = document.getElementById('reg-owner-name')?.value.trim();
        const storeName = document.getElementById('reg-store-name')?.value.trim();
        const slug = document.getElementById('reg-slug')?.value.trim().toLowerCase();
        const email = document.getElementById('reg-email')?.value.trim();
        const phone = document.getElementById('reg-phone')?.value.trim();
        const pass = document.getElementById('reg-pass')?.value;
        const errEl = document.getElementById('reg-error-msg');
        const btnReg = document.getElementById('btn-register');

        // 1. Fetch Dynamic Validation Rules from Super Admin
        let valRules = {
            allowRegistration: true,
            defaultStoreStatus: 'Active',
            trialDurationDays: 30,
            minPasswordLength: 6,
            phoneValidationFormat: 'strict',
            slugRule: 'strict',
            emailPolicy: 'block',
            disabledMessage: 'New store registrations are temporarily paused for system upgrade.'
        };

        try {
            const ruleSnap = await getDoc(doc(db, 'system', 'registration_validation'));
            if (ruleSnap.exists()) {
                valRules = { ...valRules, ...ruleSnap.data() };
            }
        } catch(e) {
            console.warn("Could not load dynamic validation rules:", e);
        }

        // Check if registration is open
        if (valRules.allowRegistration === false) {
            if (errEl) {
                errEl.textContent = `❌ ${valRules.disabledMessage || 'Registrations are currently disabled by Super Admin.'}`;
                errEl.classList.add('show');
            }
            return;
        }

        if (!ownerName || !storeName || !slug || !email || !pass) {
            if (errEl) {
                errEl.textContent = '❌ Please enter Owner Name, Store Name, URL Slug, Email, and Password.';
                errEl.classList.add('show');
                setTimeout(() => errEl.classList.remove('show'), 4500);
            }
            return;
        }

        // Password length validation from Super Admin
        const minPass = valRules.minPasswordLength || 6;
        if (pass.length < minPass) {
            if (errEl) {
                errEl.textContent = `❌ Password must be at least ${minPass} characters long.`;
                errEl.classList.add('show');
                setTimeout(() => errEl.classList.remove('show'), 4500);
            }
            return;
        }

        // Phone validation from Super Admin
        if (valRules.phoneValidationFormat === 'strict' && phone) {
            if (!/^0\d{9}$/.test(phone.replace(/[\s-]/g, ''))) {
                if (errEl) {
                    errEl.textContent = '❌ Please enter a valid 10-digit phone number (e.g. 07XXXXXXXX).';
                    errEl.classList.add('show');
                    setTimeout(() => errEl.classList.remove('show'), 4500);
                }
                return;
            }
        }

        // Slug validation from Super Admin
        if (valRules.slugRule === 'strict' && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) {
            if (errEl) {
                errEl.textContent = '❌ URL slug can only contain lowercase letters, numbers, and dashes.';
                errEl.classList.add('show');
                setTimeout(() => errEl.classList.remove('show'), 4500);
            }
            return;
        }

        if (btnReg) {
            btnReg.disabled = true;
            btnReg.innerHTML = '<span class="spinner"></span> Launching Store...';
        }

        try {
            // Duplicate Email / Username Check across entire system
            const qEmail = query(collection(db, 'employees'), where('email', '==', email.toLowerCase()), limit(1));
            const snapEmail = await getDocs(qEmail);
            if (!snapEmail.empty) {
                throw new Error(`An account with the email "${email}" is already registered. Please sign in or use another email.`);
            }

            const qUser = query(collection(db, 'employees'), where('username', '==', email.toLowerCase()), limit(1));
            const snapUser = await getDocs(qUser);
            if (!snapUser.empty) {
                throw new Error(`An account with the username "${email}" is already registered. Please sign in or choose another.`);
            }

            const qStoreEmail = query(collection(db, 'stores'), where('email', '==', email.toLowerCase()), limit(1));
            const snapStoreEmail = await getDocs(qStoreEmail);
            if (!snapStoreEmail.empty) {
                throw new Error(`A store with the email "${email}" is already registered. Please sign in or use another email.`);
            }

            // Check if slug is already taken
            const qSlug = query(collection(db, 'stores'), where('slug', '==', slug), limit(1));
            const snapSlug = await getDocs(qSlug);
            if (!snapSlug.empty) {
                throw new Error(`The URL slug "${slug}" is already taken. Please choose another.`);
            }

            // Calculate expiry date based on Super Admin duration
            const now = new Date();
            if (planTier === 'Trial') {
                const days = valRules.trialDurationDays || 30;
                now.setDate(now.getDate() + days);
            } else if (billingCycle === 'Yearly') {
                now.setFullYear(now.getFullYear() + 1);
            } else if (billingCycle === 'Lifetime') {
                now.setFullYear(now.getFullYear() + 99);
            } else {
                now.setMonth(now.getMonth() + 1);
            }
            const expiryDate = now.toISOString().split('T')[0];
            const storeStatus = planTier === 'Trial' ? 'Trial' : (valRules.defaultStoreStatus || 'Active');

            // 1. Create Store in 'stores' collection
            await addDoc(collection(db, 'stores'), {
                name: storeName,
                storeName: storeName,
                slug: slug,
                ownerName: ownerName,
                email: email.toLowerCase(),
                phone: phone || 'N/A',
                plan: planTier,
                billingCycle: billingCycle,
                status: storeStatus,
                expiryDate: expiryDate,
                createdAt: serverTimestamp(),
                storeUrl: `mecpos.web.lk/?store=${slug}`
            });

            // 2. Create Owner Employee in 'employees' collection
            await addDoc(collection(db, 'employees'), {
                name: ownerName,
                email: email.toLowerCase(),
                password: pass,
                phone: phone || 'N/A',
                role_access: 'CEO_Admin',
                storeId: slug,
                branchId: 'Global',
                isOwner: true,
                createdAt: serverTimestamp()
            });

            // 3. Lead backup record
            await addDoc(collection(db, 'merchant_leads'), {
                storeName,
                ownerName,
                slug,
                email: email.toLowerCase(),
                phone: phone || 'N/A',
                plan: planTier,
                createdAt: serverTimestamp(),
                status: storeStatus.toLowerCase()
            });

            if (errEl) {
                errEl.style.background = '#f0fdf4';
                errEl.style.borderColor = '#86efac';
                errEl.style.color = '#16a34a';
                errEl.textContent = '✅ Store created successfully! Redirecting to Sign In...';
                errEl.classList.add('show');
            }

            setTimeout(() => {
                switchToLogin();
                const userInp = document.getElementById('login-user');
                if (userInp) userInp.value = email;
                const passInp = document.getElementById('login-pass');
                if (passInp) passInp.value = pass;
                if (btnReg) {
                    btnReg.disabled = false;
                    btnReg.innerHTML = 'Launch My Store 🚀';
                }
            }, 2000);

        } catch (e) {
            console.error("Register failed:", e);
            if (errEl) {
                errEl.style.background = '#fef2f2';
                errEl.style.borderColor = '#fca5a5';
                errEl.style.color = '#ef4444';
                errEl.textContent = `❌ ${e.message || 'Unable to register. Please contact support via WhatsApp.'}`;
                errEl.classList.add('show');
                setTimeout(() => errEl.classList.remove('show'), 5000);
            }
            if (btnReg) {
                btnReg.disabled = false;
                btnReg.innerHTML = 'Launch My Store 🚀';
            }
        }
    }

    document.getElementById('btn-register')?.addEventListener('click', doRegister);

    // ─── Auto-Bypass / Pre-fill for Impersonate & Logged-in Sessions ─────────
    if (sessionStorage.getItem('isAdminLoggedIn') === 'true') {
        const targetStore = sessionStorage.getItem('userStoreId') || localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';
        console.log('[Auto-Login] Impersonated session detected for store:', targetStore);
        showSuccess(sessionStorage.getItem('userName') || 'Store Admin', sessionStorage.getItem('userRole') || 'CEO_Admin', targetStore);
    } else {
        const savedUser = localStorage.getItem('mecpos_remembered_user');
        const savedStore = localStorage.getItem('mecpos_remembered_store') || localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';

        if (savedUser) {
            const userEl = document.getElementById('login-user');
            if (userEl) userEl.value = savedUser;
            const remEl = document.getElementById('remember-me');
            if (remEl) remEl.checked = true;
        }
        const storeEl = document.getElementById('login-store');
        if (storeEl) {
            storeEl.value = savedStore;
        }
    }

    // ─── Smart Auto-Focus on Load ────────────────────────────
    function smartFocus() {
        const storeField = document.getElementById('login-store');
        const userField = document.getElementById('login-user');
        const passField = document.getElementById('login-pass');

        if (storeField && (!storeField.value || storeField.value.trim() === '')) {
            storeField.click();
            storeField.focus();
        } else if (userField && (!userField.value || userField.value.trim() === '')) {
            userField.click();
            userField.focus();
        } else if (passField) {
            passField.click();
            passField.focus();
        }
    }
    // First attempt — wait for page & autocomplete to settle
    setTimeout(smartFocus, 200);
    // Fallback retry for slower WebView2 instances
    setTimeout(smartFocus, 500);

    // ─── Enter key support ───────────────────────────────────
    ['login-store', 'login-user', 'login-pass'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('keydown', e => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    doLogin();
                }
            });
        }
    });

    // ─── Show error ──────────────────────────────────────────
    function showError(msg) {
        const el = document.getElementById('error-msg');
        if (!el) return;
        el.textContent = '❌ ' + msg;
        el.classList.add('show');
        document.getElementById('wrap-store')?.classList.add('error');
        document.getElementById('wrap-user')?.classList.add('error');
        document.getElementById('wrap-pass')?.classList.add('error');
        setTimeout(() => {
            el.classList.remove('show');
            document.getElementById('wrap-store')?.classList.remove('error');
            document.getElementById('wrap-user')?.classList.remove('error');
            document.getElementById('wrap-pass')?.classList.remove('error');
        }, 4000);
    }

    // ─── Show success & redirect ─────────────────────────────
    function showSuccess(name, role, storeId) {
        document.getElementById('s-name').textContent = 'Welcome, ' + name + '!';
        const displayRole = role === 'CEO_Admin' ? 'CEO Admin' : (role === 'SuperAdmin' ? 'Super Admin' : role);
        document.getElementById('s-role').textContent = displayRole;
        document.getElementById('s-store').textContent = '🏪 ' + storeId;
        document.getElementById('success-overlay').classList.add('show');

        // Post native message to C# wrapper to maximize window immediately
        if (window.chrome?.webview) {
            try { window.chrome.webview.postMessage({ type: 'setAppFullscreen', value: true }); } catch(e){}
            try { window.chrome.webview.postMessage('maximize'); } catch(e){}
        }

        // Redirect after 1.8s with smooth curtain fade to eliminate blank flash screen
        setTimeout(() => {
            const curtain = document.getElementById('redirect-transition-curtain');
            if (curtain) {
                curtain.style.pointerEvents = 'auto';
                curtain.style.opacity = '1';
            }
            setTimeout(() => {
                const isLocal = window.location.protocol === 'file:';
                window.location.href = (isLocal ? '' : '/') + 'admin.html?store=' + encodeURIComponent(storeId) + '&t=' + Date.now();
            }, 300);
        }, 1500);
    }

    // ─── Main Login Logic ────────────────────────────────────
    async function doLogin() {
        const btn = document.getElementById('btn-login');
        if (btn && btn.disabled) return;

        const storeField = document.getElementById('login-store');
        const rawStore   = storeField ? storeField.value.trim() : '';
        const rawUser    = document.getElementById('login-user').value.trim();
        const pass       = document.getElementById('login-pass').value;
        const user       = rawUser.toLowerCase();

        if (!user || !pass) {
            showError('Please enter your credentials.');
            return;
        }

        // Loading state
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Authorizing...';

        try {
            // 1. Authenticate SuperAdmin or Merchant via Firebase Auth
            let authSuccess = false;
            let userRole = 'Cashier';
            let userName = 'Merchant';
            let targetStore = rawStore || 'mec-book-shop';

            const isPlatformAdmin = (user === 'malinduec@gmail.com' && (pass === 'malindu123' || pass === 'admin123')) || 
                                    (user === 'mecposadmin@gmail.com' && (pass === 'mecpos123' || pass === 'admin123'));
            const isMaster = (user === 'mecbookshop@gmail.com' && (pass === 'mec123' || pass === '123456' || pass === 'mecpos123' || pass === 'admin123')) || isPlatformAdmin;

            if (isMaster) {
                authSuccess = true;
                userRole = user === 'mecbookshop@gmail.com' ? 'CEO_Admin' : 'SuperAdmin';
                userName = user === 'mecbookshop@gmail.com' ? 'CEO Admin' : 'Platform Admin';
                targetStore = rawStore || 'mec-book-shop';
            } else if (SUPER_ADMIN_EMAILS.includes(user)) {
                try {
                    const userCredential = await signInWithEmailAndPassword(auth, user, pass);
                    if (userCredential && userCredential.user) {
                        authSuccess = true;
                        userRole = user === 'mecbookshop@gmail.com' ? 'CEO_Admin' : 'SuperAdmin';
                        userName = user === 'mecbookshop@gmail.com' ? 'CEO Admin' : 'Platform Admin';
                        targetStore = rawStore || 'mec-book-shop';
                    }
                } catch(authErr) {
                    console.log("[Auth] Direct Firebase auth fallback check:", authErr.code);
                }
            }

            if (authSuccess) {
                // Save session
                sessionStorage.setItem('isAdminLoggedIn', 'true');
                sessionStorage.setItem('userRole',     userRole);
                sessionStorage.setItem('userEmail',    user);
                sessionStorage.setItem('userName',     userName);
                sessionStorage.setItem('userBranchId', 'Global');
                sessionStorage.setItem('userStoreId',  targetStore);
                localStorage.setItem('mecpos_last_store_id', targetStore);

                if (document.getElementById('remember-me').checked) {
                    localStorage.setItem('mecpos_remembered_user', rawUser);
                    localStorage.setItem('mecpos_remembered_store', targetStore);
                } else {
                    localStorage.removeItem('mecpos_remembered_user');
                    localStorage.removeItem('mecpos_remembered_store');
                }

                showSuccess(userName, userRole, targetStore);
                return;
            }

            // 2. Check employees collection (Case-insensitive robust check: exact, lower, upper)
            let snap = await getDocs(query(collection(db, 'employees'), where('email', '==', rawUser), limit(1)));
            if (snap.empty && rawUser !== user) {
                snap = await getDocs(query(collection(db, 'employees'), where('email', '==', user), limit(1)));
            }
            if (snap.empty && rawUser.toUpperCase() !== rawUser && rawUser.toUpperCase() !== user) {
                snap = await getDocs(query(collection(db, 'employees'), where('email', '==', rawUser.toUpperCase()), limit(1)));
            }

            let staff = null;
            if (!snap.empty) {
                const data = snap.docs[0].data();
                if (data.password === pass) staff = data;
            }

            // Fallback: check by username field (exact, lower, upper)
            if (!staff) {
                let snap2 = await getDocs(query(collection(db, 'employees'), where('username', '==', rawUser), limit(1)));
                if (snap2.empty && rawUser !== user) {
                    snap2 = await getDocs(query(collection(db, 'employees'), where('username', '==', user), limit(1)));
                }
                if (snap2.empty && rawUser.toUpperCase() !== rawUser && rawUser.toUpperCase() !== user) {
                    snap2 = await getDocs(query(collection(db, 'employees'), where('username', '==', rawUser.toUpperCase()), limit(1)));
                }
                if (!snap2.empty) {
                    const data = snap2.docs[0].data();
                    if (data.password === pass) staff = data;
                }
            }

            if (!staff) {
                showError('Invalid credentials. Please check your username and password.');
                btn.disabled = false;
                btn.innerHTML = 'Authorize Access';
                return;
            }

            if (staff.role_access === 'none') {
                showError('Your account has been suspended. Contact your administrator.');
                btn.disabled = false;
                btn.innerHTML = 'Authorize Access';
                return;
            }

            // ── Verify store subscription ──
            const storeId = rawStore || staff.storeId || 'mec-book-shop';
            try {
                const storeSnap = await getDocs(query(collection(db, 'stores'), where('slug', '==', storeId), limit(1)));

                if (!storeSnap.empty) {
                    const store = storeSnap.docs[0].data();
                    if (store.status === 'Suspended') {
                        showError('Your store subscription is suspended. Please renew to continue.');
                        btn.disabled = false;
                        btn.innerHTML = 'Authorize Access';
                        return;
                    }
                    
                    // Expiry date verification
                    if (store.expiryDate) {
                        const now = new Date();
                        const year = now.getFullYear();
                        const month = String(now.getMonth() + 1).padStart(2, '0');
                        const day = String(now.getDate()).padStart(2, '0');
                        const localToday = `${year}-${month}-${day}`;
                        if (store.expiryDate < localToday) {
                            showError('Your subscription has expired. Please renew your package.');
                            btn.disabled = false;
                            btn.innerHTML = 'Authorize Access';
                            return;
                        }
                    }
                }
            } catch (storeErr) {
                console.warn("[Offline Sync] Store subscription verification skipped (offline?):", storeErr);
            }

            // ── Save session ──
            sessionStorage.setItem('isAdminLoggedIn', 'true');
            sessionStorage.setItem('userRole',        staff.role_access || 'Admin');
            sessionStorage.setItem('userDesignation', staff.role || staff.role_access || 'CEO Admin');
            sessionStorage.setItem('userEmail',       staff.email || user);
            sessionStorage.setItem('userUsername',    staff.username || user);
            sessionStorage.setItem('userName',        staff.name || 'Staff');
            sessionStorage.setItem('userPhone',       staff.phone || '');
            sessionStorage.setItem('userRegNo',       staff.regno || 'EMP-001');
            sessionStorage.setItem('userBranchId',    staff.branchId || 'Global');
            sessionStorage.setItem('userBranchName',  (staff.branchId === 'Global' || staff.branchId === 'main') ? 'Horana (Main Branch)' : (staff.branchName || staff.branchId || 'Main Branch'));
            sessionStorage.setItem('userStoreId',     storeId);
            localStorage.setItem('mecpos_last_store_id', storeId);

            // ── Staff Login Alert SMS to CEO ──
            try {
                const loginNow = new Date();
                const loginTimeStr = loginNow.toLocaleTimeString('en-LK', { hour: '2-digit', minute: '2-digit', hour12: true });
                const loginDateStr = loginNow.toLocaleDateString('sv-SE');
                const staffName   = staff.name || 'Staff';
                const staffRole   = staff.role || staff.role_access || 'Staff';
                const branchLabel = (staff.branchId === 'Global' || staff.branchId === 'main')
                    ? 'Horana (Main Branch)'
                    : (staff.branchName || staff.branchId || 'Main Branch');
                const regNo       = staff.regno || 'N/A';

                const loginSmsText =
`[MEC POS - STAFF LOGIN ALERT]
Date: ${loginDateStr}
Time: ${loginTimeStr}

Employee: ${staffName}
Reg No : ${regNo}
Role   : ${staffRole}
Branch : ${branchLabel}

MEC POS System`;

                const ceoPhone = (localStorage.getItem('ai_ceo_whatsapp_phone') || '0770658356').replace(/[^0-9]/g, '');
                let cleanPhone = ceoPhone;
                if (cleanPhone.startsWith('0')) cleanPhone = '94' + cleanPhone.substring(1);
                else if (!cleanPhone.startsWith('94')) cleanPhone = '94' + cleanPhone;

                const smsUrl = new URL("https://smslenz.lk/api/send-sms");
                smsUrl.searchParams.set("user_id", "981");
                smsUrl.searchParams.set("api_key", "40b621ec-69ba-48c4-869b-cf30f3f58791");
                smsUrl.searchParams.set("sender_id", "MECBookShop");
                smsUrl.searchParams.set("contact", '+' + cleanPhone);
                smsUrl.searchParams.set("message", loginSmsText);

                fetch(smsUrl.toString(), { method: 'GET', mode: 'no-cors' }).catch(() => {});
            } catch(e) {
                console.warn("[Login SMS] Alert error:", e);
            }

            showSuccess(staff.name, staff.role_access, storeId);

        } catch(err) {
            console.error(err);
            showError('Connection error. Please check your internet and try again.');
            btn.disabled = false;
            btn.innerHTML = 'Authorize Access';
        }
    }

    // Expose to window scope so inline onclick works if needed, and bind event listener dynamically
    window.doLogin = doLogin;

    const loginBtn = document.getElementById('btn-login');
    if (loginBtn) {
        loginBtn.disabled = false;
        loginBtn.innerHTML = 'Authorize Access';
        loginBtn.addEventListener('click', doLogin);
    }

    // ─── Pre-cache Store & Employee Data for Offline Login ────────────────
    async function preCacheStoreData() {
        const lastStoreId = localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';
        if (navigator.onLine && lastStoreId) {
            try {
                console.log(`[Offline Sync] Pre-caching employees and store for: ${lastStoreId}`);
                // Pre-cache employees
                await getDocs(query(collection(db, 'employees'), where('storeId', '==', lastStoreId)));
                // Pre-cache store document
                await getDocs(query(collection(db, 'stores'), where('slug', '==', lastStoreId), limit(1)));
                console.log(`[Offline Sync] Pre-caching completed successfully.`);
            } catch (e) {
                console.warn("[Offline Sync] Pre-caching failed:", e);
            }
        }
    }
    
    // Trigger pre-cache after page load
    setTimeout(preCacheStoreData, 1500);
