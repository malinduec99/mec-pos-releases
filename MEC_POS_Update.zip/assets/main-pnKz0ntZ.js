/* empty css              */import{G as Xe}from"./index-BpRkNtKl.js";import{a as Y,c as L,d as C,s as Z,o as Le,q as B,w as k,g as A,b as le,e as Te,i as Se,f as et,h as tt,l as ot,j as rt,u as at,k as it,m as Ne}from"./firebase-Bn3UcnFE.js";window.uploadLogToCloud=async(e,o="error")=>{try{const r=window.currentStoreId||"unknown",n=window.HostPCName||navigator.userAgent||"WebBrowser";await Y(L(C,"systemLogs"),{message:e,level:o,storeId:r,pcName:n,timestamp:Z()})}catch(r){console.error("Failed to upload log:",r)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function nt(){try{const e=localStorage.getItem("mecThemeColors");if(e){const o=JSON.parse(e),r=document.documentElement;r.style.setProperty("--primary-blue",o.primary),r.style.setProperty("--accent-blue",o.accent),r.style.setProperty("--admin-bg",o.bg),r.style.setProperty("--glass-bg",o.glass),r.style.setProperty("--primary-color",o.primary),r.style.setProperty("--secondary-color",o.accent),r.style.setProperty("--deep-bg",o.bg),o.bg==="#0f172a"||o.bg==="#11011c"||o.bg==="#022c22"?(r.style.setProperty("--text-dark","#f8fafc"),r.style.setProperty("--text-muted","#94a3b8")):(r.style.setProperty("--text-dark","#0f172a"),r.style.setProperty("--text-muted","#64748b"))}}catch{}}nt();const je=new URLSearchParams(window.location.search),J=window.location.pathname.split("/").filter(e=>e!=="");let Pe=null;J[0]==="store"&&J[1]?Pe=J[1]:J[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(J[0])&&(Pe=J[0]);const st=je.get("store")||Pe;window.currentStoreId=st||null;window.currentStoreData=null;try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const ue=L(C,"stores"),ee=window.location.hostname;async function lt(){let e=null;try{if(window.currentStoreId){const o=B(ue,k("slug","==",window.currentStoreId)),r=await A(o);if(!r.empty)e={...r.docs[0].data(),docId:r.docs[0].id};else try{const n=le(C,"stores",window.currentStoreId),t=await et(n);t.exists()&&(e={...t.data(),docId:t.id})}catch{}}else if(["mecbookshop.web.lk","mecbookshop.com.lk","mec-book-shop.web.app","localhost","127.0.0.1"].includes(ee)){window.currentStoreId="mec-book-shop";const r=B(ue,k("slug","==","mec-book-shop")),n=await A(r);n.empty||(e={...n.docs[0].data(),docId:n.docs[0].id})}else if(ee==="mecpos.web.lk"||ee==="mec-pos-shop.web.app"||ee==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const r=ee.replace(/^www\./,""),n=B(ue,k("domain","==",r)),t=await A(n);t.empty||(e={...t.docs[0].data(),docId:t.docs[0].id})}}catch(o){console.error("Store resolution query failed:",o)}if(e)window.currentStoreData=e,window.currentStoreId=e.slug||e.storeSlug||e.docId||"mec-book-shop",console.log("Resolved Store ID:",window.currentStoreId),Re(),qe(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{window.currentStoreId||(window.currentStoreId="mec-book-shop");try{const r=B(ue,k("slug","==","mec-book-shop")),n=await A(r);n.empty||window.currentStoreId==="mec-book-shop"&&(window.currentStoreData=n.docs[0].data())}catch(r){console.error("Error loading fallback store data:",r)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),Re(),qe(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}lt();function Re(){var m,b,u,f,g,y,h,P,w,I,v,T,$,D,R;let e=(m=window.currentStoreData)==null?void 0:m.name;e||(window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?e=window.currentStoreId.split("-").map(S=>S.charAt(0).toUpperCase()+S.slice(1)).join(" "):e="MEC Book Shop"),e==="MEC POS"&&(e="MEC Book Shop"),document.title=`${e} | Official Store`;const o=(u=(b=window.currentStoreData)==null?void 0:b.webDesign)==null?void 0:u.primary,r=(g=(f=window.currentStoreData)==null?void 0:f.webDesign)==null?void 0:g.accent;o&&document.documentElement.style.setProperty("--primary-color",o),r&&document.documentElement.style.setProperty("--secondary-color",r),document.querySelectorAll(".logo-text").forEach(S=>{S.innerText=e});const n=(y=window.currentStoreData)==null?void 0:y.logoUrl,t=n&&n.trim()!==""&&!n.includes("zenith_logo")&&!n.includes("/logo.png")?n:"/mec-logo.png";document.querySelectorAll(".logo-img, #pwa-install-banner img").forEach(S=>{S.src=t,S.style.display=""});const i=document.getElementById("hero");if(i){const S=(P=(h=window.currentStoreData)==null?void 0:h.webDesign)==null?void 0:P.bannerUrl,z=S&&S.length>10?S:window.currentStoreId==="mec-book-shop"?"/banner.png":null;if(z)i.innerHTML=`
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${z}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `;else{const G=((I=(w=window.currentStoreData)==null?void 0:w.webContent)==null?void 0:I.welcome)||`Welcome to ${e}`,ve=((T=(v=window.currentStoreData)==null?void 0:v.webContent)==null?void 0:T.announce)||"Your premium destination for high-quality products and services.";i.innerHTML=`
        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">
          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${G}</h1>
          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${ve}</p>
          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>
        </div>
      `}}const s=document.getElementById("page-title");s&&(s.innerText=`${e} | Official Store`);const d=document.getElementById("footer-copy");d&&(d.innerText=`© 2026 ${e}. All rights reserved.`);const a=(($=window.currentStoreData)==null?void 0:$.webEpinics)||{},l=!!a.multiVendor,c=!!a.affiliate;(D=document.getElementById("nav-sell-with-us"))==null||D.remove(),(R=document.getElementById("nav-affiliate-program"))==null||R.remove();const p=document.getElementById("nav-menu");if(p){const S=document.getElementById("nav-auth-item");if(l){const z=document.createElement("li");z.id="nav-sell-with-us",z.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',S?p.insertBefore(z,S):p.appendChild(z)}if(c){const z=document.createElement("li");z.id="nav-affiliate-program",z.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',S?p.insertBefore(z,S):p.appendChild(z)}}document.documentElement.classList.remove("loading-merchant")}let te;const W=document.createElement("div");W.id="pwa-install-banner";W.innerHTML=`
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>
            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>
        </div>
        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;W.style.display="none";document.body.appendChild(W);window.addEventListener("beforeinstallprompt",e=>{e.preventDefault(),te=e,W.style.display="block"});W.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){W.style.display="none";return}if(te){te.prompt();const{outcome:o}=await te.userChoice;o==="accepted"&&(W.style.display="none"),te=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const F=document.getElementById("menu-toggle"),U=document.getElementById("nav-menu"),q=document.getElementById("mobile-menu-overlay"),fe=()=>{U==null||U.classList.remove("active"),F==null||F.classList.remove("active"),q==null||q.classList.remove("active")};F==null||F.addEventListener("click",()=>{const e=U==null?void 0:U.classList.toggle("active");F==null||F.classList.toggle("active"),e?q==null||q.classList.add("active"):q==null||q.classList.remove("active")});const xe=document.getElementById("close-menu");xe==null||xe.addEventListener("click",fe);q==null||q.addEventListener("click",fe);U==null||U.querySelectorAll("a").forEach(e=>{e.addEventListener("click",fe)});function de(e,o){var n;if(typeof e=="string"&&e.trim()!==""){const t=e.trim();if((t.startsWith("data:")||t.startsWith("blob:")||t.startsWith("http")||t.startsWith("/"))&&!t.includes("placehold.co")&&!t.includes("zenith_logo.png")&&!t.includes("/logo.png"))return t}const r=(n=window.currentStoreData)==null?void 0:n.logoUrl;return r&&r.trim()!==""&&!r.includes("zenith_logo.png")&&!r.includes("/logo.png")?r:"/mec-logo.png"}const dt=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}],oe=L(C,"products"),ct=L(C,"orders"),pt=L(C,"promotions"),ut=L(C,"branches"),mt=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let _e=[];Le(ut,e=>{_e=e.docs.map(o=>({...o.data(),docId:o.id})),window.allStoreBranches=_e,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function re(){var n,t,i,s;const e=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master";let o=(window.allStoreBranches||[]).filter(d=>e||d.storeId===window.currentStoreId||!d.storeId);const r={docId:"main",name:(((n=window.currentStoreData)==null?void 0:n.name)||"MEC Book Shop")+" - Main Branch",location:((t=window.currentStoreData)==null?void 0:t.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",address:((i=window.currentStoreData)==null?void 0:i.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",city:"Horana",district:"Kalutara",phone:((s=window.currentStoreData)==null?void 0:s.phone)||"071 923 3388"};return o.length===0&&(o=[r]),o}window.getAllAvailableShops=re;function Ve(){const o=re().map(n=>(n.location||n.city||"").trim()).filter(n=>n.length>0);return Array.from(new Set([...o,...mt])).filter(Boolean).sort((n,t)=>n.localeCompare(t,void 0,{sensitivity:"base"}))}window.getAvailableTowns=Ve;let N=[],ce=0,x=[],V="All",M=1,ke=12,Q="recommended",H="",Ie=null;document.getElementById("cart-count");function qe(){let e;window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?e=B(oe):e=B(oe,k("storeId","==",window.currentStoreId)),Le(e,o=>{const r=o.docs.map(t=>({...t.data(),id:t.id,docId:t.id,sku:t.data().sku||t.id}));if((window.currentStoreId==="mec-book-shop"||window.currentStoreId==="O8ywuZTKSwdL4z77RQ9M"||window.currentStoreId==="master")&&!r.some(i=>i.name&&i.name.trim().toLowerCase()==="other")&&o.docs.length>0){console.log("Auto-creating 'Other' product for MEC Book Shop...");const i={name:"Other",sku:"SKU-OTHER-0000-GEN-P1C0",category:"Uncategorized",mode:"Shop",supplierId:"General",supplierName:"General",cost:0,price:1,wholesalePrice:1,loyaltyPrice:1,discount:0,stock:999999,wStock:0,totalStock:999999,timestamp:Z(),salesToday:0,image:"",variants:[],payMethods:{cod:!0,bank:!0,shop:!0},storeId:window.currentStoreId};i.docId=i.sku,Te(le(C,"products",i.sku),i).catch(s=>console.error("Error creating 'Other' product:",s))}N=r.filter(t=>{const s=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?t.storeId==="mec-book-shop"||t.storeId==="master"||!t.storeId:t.storeId===window.currentStoreId,d=t.mode==="Shop"||t.mode==="Warehouse"||t.mode===void 0,a=t.status!=="pending";return s&&d&&a}),N.sort((t,i)=>{var s,d;return(((s=i.timestamp)==null?void 0:s.seconds)||0)-(((d=t.timestamp)==null?void 0:d.seconds)||0)}),N.length===0&&window.currentStoreId==="master"&&dt.forEach(async t=>{await Y(oe,t)}),_(),ye()})}var Ke;(Ke=document.getElementById("product-sort"))==null||Ke.addEventListener("change",e=>{Q=e.target.value,M=1,_()});var He;(He=document.getElementById("store-search"))==null||He.addEventListener("input",e=>{H=e.target.value.toLowerCase(),window.searchQuery=H,M=1,_()});window.renderProducts=_;window.clearSearch=()=>{H="",window.searchQuery="";const e=document.getElementById("store-search");e&&(e.value=""),M=1,_()};function Ae(){localStorage.setItem("mec_cart",JSON.stringify(x))}function gt(){const e=localStorage.getItem("mec_cart");e&&(x=JSON.parse(e),ce=x.reduce((o,r)=>o+(r.quantity||1),0),we())}const ae=document.createElement("div");ae.id="cart-modal";document.body.appendChild(ae);const ie=document.createElement("div");ie.id="cart-overlay";document.body.appendChild(ie);window.toggleCart=e=>{e?(ae.classList.add("active"),ie.classList.add("active"),be(),document.body.style.overflow="hidden"):(ae.classList.remove("active"),ie.classList.remove("active"),document.body.style.overflow="")};const pe=window.toggleCart;ie.onclick=()=>pe(!1);const ft=document.querySelectorAll('a[href="#cart"]');ft.forEach(e=>{e.onclick=o=>{o.preventDefault(),fe(),pe(!0)}});const Oe=document.getElementById("shop-now-btn");Oe&&Oe.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const Ge={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function yt(){return["All",...new Set(N.map(o=>o.category))]}function ye(){const e=yt(),o=document.getElementById("sidebar-category-list"),r=document.getElementById("mobile-category-bar");o&&(o.innerHTML=e.map(s=>`
      <li class="sidebar-cat-item ${s===V?"active":""}" data-category="${s}">
        <div class="cat-icon-text">
          <span class="cat-icon">${Ge[s]||"📁"}</span>
          <span>${s}</span>
        </div>
        <span class="arrow">›</span>
      </li>
    `).join("")),r&&(r.innerHTML=e.map(s=>`
      <button class="mobile-cat-btn ${s===V?"active":""}" data-category="${s}">
        ${s}
      </button>
    `).join(""));const n=s=>{var a;V=s;const d=document.getElementById("featured-title");d&&(d.innerText=s==="All"?"Featured Collection":`${s} Collection`),_(),ye(),K(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(s=>{s.addEventListener("click",d=>{d.stopPropagation(),n(d.currentTarget.dataset.category)}),s.addEventListener("mouseenter",d=>{const a=d.currentTarget.dataset.category;a!=="All"?ht(a,d.currentTarget):K()})}),document.querySelectorAll(".mobile-cat-btn").forEach(s=>{s.addEventListener("click",d=>n(d.target.dataset.category))});const t=document.querySelector(".category-menu-wrapper"),i=document.getElementById("nav-category-btn");i&&t&&(i.onclick=s=>{s.stopPropagation(),t.classList.toggle("active")}),t==null||t.addEventListener("mouseleave",()=>{t.classList.remove("active"),K()})}document.addEventListener("click",e=>{const o=document.querySelector(".category-menu-wrapper");o&&!o.contains(e.target)&&(o.classList.remove("active"),typeof K=="function"&&K())});const O=document.getElementById("mega-menu");let he;function ht(e,o){if(!O)return;clearTimeout(he),document.querySelectorAll(".sidebar-cat-item").forEach(d=>d.classList.remove("active")),o==null||o.classList.add("active");const r=(N||[]).filter(d=>d.category===e),n={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],t=document.getElementById("mega-sidebar-col");t&&(t.innerHTML=`
      <div style="margin-bottom: 1.1rem;">
        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>
        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">
          <span>${Ge[e]||"📁"}</span>
          <span>${e}</span>
        </div>
        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${r.length} Items Available</div>
      </div>
      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">
        <span>View All</span>
        <span>→</span>
      </button>
      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        ${n.map(d=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${d}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${d}</a>`).join("")}
      </div>
    `);const i=document.getElementById("mega-products-heading");i&&(i.innerText=`${e} Products (${r.length})`);const s=document.getElementById("mega-products-list");s&&(s.innerHTML=r.length>0?r.map(d=>`
          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${d.docId}')">
            <img src="${de(d.image,d.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">
            <div class="mega-prod-info">
              <h5 title="${d.name}">${d.name}</h5>
              <div class="price">LKR ${Number(d.price||0).toFixed(2)}</div>
            </div>
          </a>
        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),O.style.top="calc(100% + 8px)",O.style.left="248px",O.classList.add("active")}function K(){he=setTimeout(()=>{O==null||O.classList.remove("active")},400)}O==null||O.addEventListener("mouseenter",()=>clearTimeout(he));var We;(We=document.getElementById("sidebar-category-list"))==null||We.addEventListener("mouseenter",()=>clearTimeout(he));window.filterByCategoryAndScroll=e=>{var r;V=e;const o=document.getElementById("featured-title");o&&(o.innerText=e==="All"?"Featured Collection":`${e} Collection`),_(),ye(),K(),(r=document.getElementById("shop-section"))==null||r.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,o)=>{var n;V=o,_(),ye();const r=document.getElementById("featured-title");r&&(r.innerText=`${e} in ${o}`),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"}),K()};window.scrollToProduct=e=>{const o=document.getElementById(`product-${e}`);o&&(o.scrollIntoView({behavior:"smooth",block:"center"}),o.classList.add("highlight-pulse"),setTimeout(()=>o.classList.remove("highlight-pulse"),3e3),K())};function X(e,o=null,r=null){var p;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const n=(r||((p=window.currentUserProfile)==null?void 0:p.customerType)||"retail").toLowerCase();let t=0,i=0,s=0;o?(t=Number(o.price),(isNaN(t)||t<=0)&&(t=Number(e.price)||0),i=Number(o.wholesalePrice),(isNaN(i)||i<=0)&&(i=Number(e.wholesalePrice)||0),s=Number(o.loyaltyPrice),(isNaN(s)||s<=0)&&(s=Number(e.loyaltyPrice)||0)):(t=Number(e.price)||0,i=Number(e.wholesalePrice)||0,s=Number(e.loyaltyPrice)||0),isNaN(t)&&(t=0);let d=t,a=!1;n==="wholesale"&&i>0?(d=i,a=i!==t):n==="loyalty"&&s>0&&(d=s,a=s!==t);const l=Number(e.discount)||0,c=d*(1-(l>0?l/100:0));return{retailPrice:isNaN(t)?0:t,effectivePrice:isNaN(d)?0:d,discountedPrice:isNaN(c)?0:c,isSpecial:a,userType:n}}window.getCustomerEffectivePrice=X;function ne(e,o=null){return De(e,o,"web")}function De(e,o=null,r="web"){if(!e)return 0;if(r==="ShopPay"||r==="shop"||r==="Shop"){if(o){const i=parseFloat(o.stock)||0;if(i>0)return i}const t=parseFloat(e.stock||0);return t>0?t:0}else{if(o){const a=parseFloat(o.stock)||0,l=parseFloat(o.wStock)||0,c=a+l;if(c>0)return c}if(e.variants&&e.variants.length>0){const a=e.variants.reduce((l,c)=>l+(parseFloat(c.stock)||0)+(parseFloat(c.wStock)||0),0);if(a>0)return a}const t=parseFloat(e.stock||0),i=parseFloat(e.wStock||0),s=parseFloat(e.totalStock||0),d=t+i;return d>0?d:s>0?s:0}}const se=document.getElementById("product-detail-modal"),ze=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const o=(window.groupedProducts||[]).find(u=>u.docId===e)||N.find(u=>u.docId===e);if(!o)return;const r=Number(o.discount)||0,n=o.variants&&o.variants.length>0,t=n?o.variants[0]:null;let i=o.image;t&&(t.image?i=t.image:t.images&&t.images.length>0&&(i=t.images[0]));const s=X(o,t),d=s.userType,a=s.isSpecial,l=s.retailPrice,c=s.discountedPrice,p=ne(o,t),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let b="";if(n){const u=[...new Set(o.variants.map(g=>g.size).filter(Boolean))],f=[...new Set(o.variants.map(g=>g.color).filter(Boolean))];if(u.length>0||f.length>0){let g="";f.length>0&&(g=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Color</span>
              <span class="selected-val" id="detail-selected-color">${(t==null?void 0:t.color)||f[0]}</span>
            </div>
            <div class="variant-pill-container" id="color-pill-group">
              ${f.map(h=>{const P=m[h.toLowerCase()]||"#64748b";return`
                  <button type="button" class="variant-color-btn ${((t==null?void 0:t.color)||f[0])===h?"active":""}" 
                    style="background-color: ${P};" 
                    title="${h}" data-color="${h}"
                    onclick="window.selectVariantByAttribute('${o.docId}', 'color', '${h}')">
                  </button>
                `}).join("")}
            </div>
          </div>
        `);let y="";u.length>0&&(y=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Style / Size</span>
              <span class="selected-val" id="detail-selected-size">${(t==null?void 0:t.size)||u[0]}</span>
            </div>
            <div class="variant-pill-container" id="size-pill-group">
              ${u.map(h=>`
                  <button type="button" class="variant-size-btn ${((t==null?void 0:t.size)||u[0])===h?"active":""}" 
                    data-size="${h}"
                    onclick="window.selectVariantByAttribute('${o.docId}', 'size', '${h}')">
                    ${h}
                  </button>
                `).join("")}
            </div>
          </div>
        `),b=`${g}${y}`}else b=`
        <div class="variant-selector-group">
          <div class="variant-selector-label">
            <span>Choose Option / MRP</span>
          </div>
          <div class="variant-pill-container">
            ${o.variants.map((g,y)=>{const h=ne(o,g);return`
              <div class="variant-mrp-card ${y===0?"active":""}" id="v-card-${y}"
                   onclick="window.updateDetailDisplay('${o.docId}', ${y})">
                <div style="flex:1;">
                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${g.name||g.variantLabel||g.color||g.size||`Option ${y+1}`}</div>
                  <div style="font-size: 0.75rem; color: #64748b;">${h>0?`In Stock (${h})`:"Out of stock"}</div>
                </div>
                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">
                  LKR ${(g.price||o.price||0).toLocaleString()}
                </div>
              </div>
            `}).join("")}
          </div>
        </div>
      `}se.innerHTML=`
        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>
        <div class="detail-content">
            <div class="detail-image-sec">
                <img src="${de(i,o.name)}" id="detail-main-img" 
                    alt="${o.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">
            </div>

            <div class="detail-info-sec">
                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${o.category}</div>
                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${o.name}</h2>
                ${a?`<div style="font-size: 0.8rem; color: ${d==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${d.toUpperCase()} APPLIED</div>`:""}
                
                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">
                    ${r>0||a?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}
                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${c.toFixed(2)}</span>
                </div>
                
                ${b}

                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">
                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}
                </div>
                
                <div class="detail-actions-sec">
                    <button class="add-to-cart-btn detail-add-btn" 
                            onclick="window.handleDetailAddToCart('${o.docId}')">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `,window.activeDetailVariantIndex=0,se.classList.add("active"),ze.classList.add("active"),document.body.style.overflow="hidden",K(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,o,r)=>{const n=(window.groupedProducts||[]).find(s=>s.docId===e)||N.find(s=>s.docId===e);if(!n||!n.variants)return;const t=window.activeDetailVariantIndex||0;n.variants[t]||n.variants[0];let i=n.variants.findIndex(s=>o==="color"?s.color===r:o==="size"?s.size===r:!1);if(i===-1&&(i=0),o==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(d=>{d.classList.toggle("active",d.dataset.color===r)});const s=document.getElementById("detail-selected-color");s&&(s.innerText=r)}if(o==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(d=>{d.classList.toggle("active",d.dataset.size===r)});const s=document.getElementById("detail-selected-size");s&&(s.innerText=r)}window.updateDetailDisplay(e,i)};window.closeProductDetail=()=>{se.classList.remove("active"),ze.classList.remove("active"),document.body.style.overflow=""};ze.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,o)=>{window.activeDetailVariantIndex=Number(o);const r=(window.groupedProducts||[]).find(c=>c.docId===e)||N.find(c=>c.docId===e);if(!r)return;const n=r.variants&&r.variants.length>0?r.variants[o]:null,t=document.getElementById("detail-main-img"),i=document.getElementById("detail-stock"),s=se.querySelector(".detail-original-price"),d=se.querySelector(".detail-final-price");if(t){let c=r.image;n&&(n.image?c=n.image:n.images&&n.images.length>0&&(c=n.images[0])),t.src=de(c,r.name)}document.querySelectorAll(".variant-mrp-card").forEach((c,p)=>{c.classList.toggle("active",p===Number(o))}),Number(r.discount);const a=X(r,n);s&&(s.innerText=`LKR ${a.retailPrice.toFixed(2)}`),d&&(d.innerText=`LKR ${a.discountedPrice.toFixed(2)}`);const l=ne(r,n);if(i){const c=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";i.innerHTML=c,i.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const o=(window.groupedProducts||[]).find(p=>p.docId===e)||N.find(p=>p.docId===e);if(!o)return;const r=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let n="Default",t=null;o.variants&&o.variants.length>0&&(t=o.variants[r]||o.variants[0],n=t.name||t.variantLabel||t.color||t.size||"Default");const s=X(o,t).effectivePrice,d=t&&t.cost!==void 0?Number(t.cost):Number(o.cost)||0,a=ne(o,t),l=x.findIndex(p=>p.docId===o.docId&&p.selectedVariant===n),c=l!==-1?(x[l].quantity||1)+1:1;if(o.mode!=="Service"&&o.mode!=="Technical"&&c>a){alert(`Sorry, out of stock! Only ${a} available.`);return}wt(o,n,s,d),window.closeProductDetail(),pe(!0)};function wt(e,o,r,n){const t=x.findIndex(i=>i.docId===e.docId&&i.selectedVariant===o);t!==-1?x[t].quantity=(x[t].quantity||1)+1:x.push({...e,selectedVariant:o,price:r,cost:n,quantity:1}),ce=x.reduce((i,s)=>i+(s.quantity||1),0),Ae(),we()}window.changeCartQty=(e,o,r)=>{var t;const n=x.findIndex(i=>i.docId===e&&i.selectedVariant===o);if(n!==-1){if(r>0){const i=N.find(s=>s.docId===e);if(i&&i.mode!=="Service"&&i.mode!=="Technical"){let s=null;o!=="Default"&&i.variants&&(s=i.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===o));const d=((t=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:t.value)||"COD",a=De(i,s,d);if((x[n].quantity||1)+r>a){alert(d==="ShopPay"?`Sorry! Only ${a} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${a} available.`);return}}}x[n].quantity=(x[n].quantity||1)+r,x[n].quantity<=0&&x.splice(n,1),ce=x.reduce((i,s)=>i+(s.quantity||1),0),Ae(),we(),be()}};function we(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(o=>{o&&(o.innerText=ce,o.classList.add("bump"),setTimeout(()=>o.classList.remove("bump"),300))})}function Me(e,o,r){if(!e||!o||o.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let n=o;if(e.targetType==="specific_products"){const s=(e.selectedProducts||[]).map(d=>(d||"").trim().toLowerCase());if(n=o.filter(d=>{const a=(d.name||"").trim().toLowerCase(),l=(d.docId||"").trim().toLowerCase();return s.includes(a)||s.includes(l)}),n.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const s=(e.selectedCategories||[]).map(d=>(d||"").trim().toLowerCase());if(n=o.filter(d=>{const a=(d.category||"").trim().toLowerCase();return s.includes(a)}),n.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const t=n.reduce((s,d)=>{const a=d.discount||0,l=d.price*(1-a/100),c=d.quantity||1;return s+l*c},0);let i=0;return e.type==="Percentage"?i=t*(Number(e.value)/100):i=Math.min(t,Number(e.value)||0),{discountAmount:i,eligibleSubtotal:t,isValidForCart:!0,reason:""}}function be(){var n;const e=x.reduce((t,i)=>{const s=i.discount||0,d=i.price*(1-s/100),a=i.quantity||1;return t+d*a},0);let o=0;if(window.appliedCoupon){const t=Me(window.appliedCoupon,x);t.isValidForCart?o=t.discountAmount:window.appliedCoupon=null}const r=Math.max(0,e-o);ae.innerHTML=`
        <div class="cart-header">
            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>
            <button class="close-cart" id="close-cart-btn">&times;</button>
        </div>
        
        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">
            <div class="cart-body">
                ${x.length===0?`
                    <div class="cart-empty-state">
                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>
                        <p>Your cart is empty</p>
                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>
                    </div>
                `:x.map(t=>{const i=t.discount||0,s=t.price*(1-i/100),d=t.quantity||1,a=s*d;return`
                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">
                            <div class="cart-item-info" style="flex: 1;">
                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${t.name}</h4>
                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${t.selectedVariant||"Default"}</div>
                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">
                                    ${i>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${t.price.toFixed(2)}</span>`:""}
                                    LKR ${s.toFixed(2)} ${d>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${d} = LKR ${a.toFixed(2)}</span>`:""}
                                </div>
                            </div>
                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                                <button onclick="window.changeCartQty('${t.docId}', '${t.selectedVariant}', -1)" 
                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">
                                    -
                                </button>
                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${d}</span>
                                <button onclick="window.changeCartQty('${t.docId}', '${t.selectedVariant}', 1)" 
                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">
                                    +
                                </button>
                            </div>
                        </div>
                    `}).join("")}
            </div>

            ${x.length>0?`
                <div class="cart-footer">
                    <div class="delivery-info-banner">
                        <span>🚚</span>
                        <span>COD LKR 400 | Bank Transfer LKR 250</span>
                    </div>

                    <!-- Promo / Coupon Code Section -->
                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; gap: 0.5rem;">
                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>
                            ${window.appliedCoupon?`
                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>
                            `:`
                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>
                            `}
                        </div>
                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">
                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}
                        </div>
                    </div>
                    
                    ${window.appliedCoupon?`
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">
                            <span>Subtotal</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">
                            <span>Coupon Discount (${window.appliedCoupon.code})</span>
                            <span>- LKR ${o.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">
                            <span>Total Payable</span>
                            <span>LKR ${r.toFixed(2)}</span>
                        </div>
                    `:`
                        <div class="cart-subtotal">
                            <span>Total Payable</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="checkout-form-section">
                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>
                        <div class="input-group">
                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">
                        </div>
                        <div class="input-group">
                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">
                        </div>
                        <div class="input-group" id="delivery-address-group">
                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">
                        </div>
                        <div class="input-group" id="delivery-city-group">
                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">
                        </div>

                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>
                        <div class="payment-method-selector">
                            ${x.every(t=>t.payMethods?t.payMethods.cod!==!1:t.payCOD!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">
                                <span class="method-label">COD</span>
                            </label>
                            `:""}
                            ${x.every(t=>t.payMethods?t.payMethods.bank!==!1:t.payBank!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="Bank" ${x.every(t=>t.payMethods?t.payMethods.cod!==!1:t.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">
                                <span class="method-label">Transfer</span>
                            </label>
                            `:""}
                            ${x.every(t=>t.payMethods?t.payMethods.shop!==!1:t.payShop!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="ShopPay" ${!x.every(t=>t.payMethods?t.payMethods.cod!==!1:t.payCOD!==!1)&&!x.every(t=>t.payMethods?t.payMethods.bank!==!1:t.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">
                                <span class="method-label">Shop Cash</span>
                            </label>
                            `:""}
                        </div>
                        
                        <!-- Bank Transfer Info Box -->
                        <div id="bank-details-box" style="display: none;">
                            <p style="color: #166534; font-weight: bold; margin-bottom: 0.5rem; font-size: 0.75rem;">✨ Lower delivery charge (LKR 250)</p>
                            <div class="bank-info-card">
                                <strong>Bank of Ceylon</strong><br>
                                Horana Branch | WPM Shamesh<br>
                                A/C: 0084334885
                            </div>
                            <div style="margin-top: 1rem;">
                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>
                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">
                            </div>
                        </div>

                        <!-- Shop Pickup / Branch Selection Box -->
                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch
                            </p>

                            <!-- City / Town Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>
                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>
                                  ${Ve().map(t=>`<option value="${t}" style="color:#0f172a; background:#ffffff;">${t}</option>`).join("")}
                                </select>
                            </div>

                            <!-- Shop / Branch List Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>
                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <!-- Injected by populatePickupShops -->
                                </select>
                            </div>

                            <!-- Selected Shop Info Card -->
                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">
                            </div>
                        </div>
                    </div>

                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">
                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">
                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">
                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 
                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 
                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.
                        </label>
                    </div>

                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">
                        Confirm Order
                    </button>
                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->
                </div>
            `:""}
        </div>
    `,document.getElementById("close-cart-btn").onclick=()=>pe(!1),(n=document.getElementById("checkout-btn"))==null||n.addEventListener("click",bt),window.toggleBankDetails=t=>{const i=document.getElementById("bank-details-box");i&&(i.style.display=t?"block":"none")},window.onPaymentMethodChange=t=>{const i=document.getElementById("bank-details-box"),s=document.getElementById("shop-pickup-box"),d=document.getElementById("delivery-address-group"),a=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");t==="Bank"?(i&&(i.style.display="block"),s&&(s.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details")):t==="ShopPay"?(i&&(i.style.display="none"),s&&(s.style.display="block",window.populatePickupShops()),d&&(d.style.display="none"),a&&(a.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(i&&(i.style.display="none"),s&&(s.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var c,p,m,b;const t=document.getElementById("pickup-town-select"),i=document.getElementById("pickup-shop-select"),s=document.getElementById("selected-shop-info-card");if(!i)return;const d=t?t.value:"All",a=re();let l=a;d&&d!=="All"&&(l=a.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(d.toLowerCase()))),l.length===0?(i.innerHTML=a.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),s&&(s.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${d}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((c=a[0])==null?void 0:c.docId)||((p=a[0])==null?void 0:p.id)||0)):(i.innerHTML=l.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((b=l[0])==null?void 0:b.id)||0))},window.filterShopsByTown=t=>{window.populatePickupShops()},window.onPickupShopSelected=t=>{const i=document.getElementById("selected-shop-info-card");if(!i)return;const s=re(),d=s.find(a=>a.docId===t||a.id===t)||s[0];d&&(i.innerHTML=`
        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${d.name||d.shopName||"Main Branch"}</div>
        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${d.location||d.address||"In-store Pickup Counter"}</div>
        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${d.phone?`Contact: <b>${d.phone}</b>`:"Store Pickup Active"}</div>
        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">
          <span>✓</span> Collect & Pay Cash at this shop counter
        </div>
      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),o=document.getElementById("promo-message");if(!e)return;const r=e.value.trim().toUpperCase();if(!r){o&&(o.innerText="❌ Please enter a promo code.",o.style.color="#ef4444");return}o&&(o.innerText="⏳ Validating coupon...",o.style.color="var(--primary-color)");try{const n=B(pt,k("code","==",r),k("storeId","==",window.currentStoreId)),t=await A(n);if(t.empty){o&&(o.innerText="❌ Invalid or expired coupon code.",o.style.color="#ef4444");return}const i=t.docs[0],s={...i.data(),id:i.id},d=new Date().toISOString().split("T")[0];if(s.expiryDate<d){o&&(o.innerText="❌ This coupon has expired.",o.style.color="#ef4444");return}if(s.status!=="Active"){o&&(o.innerText="❌ This coupon is inactive.",o.style.color="#ef4444");return}const a=x.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=Me(s,x,a);if(!l.isValidForCart){o&&(o.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,o.style.color="#ef4444");return}window.appliedCoupon=s,be();const c=document.getElementById("promo-message");if(c){const p=s.targetType==="specific_products"?" (Selected Items)":s.targetType==="specific_categories"?" (Selected Categories)":"";c.innerText=`✅ Coupon applied: ${s.type==="Percentage"?`${s.value}% OFF`:`LKR ${s.value} OFF`}${p}`,c.style.color="#10b981"}}catch(n){console.error("Error validating coupon:",n),o&&(o.innerText="❌ Error validating coupon code.",o.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,be()};async function bt(){var m,b,u,f,g,y,h,P;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!"),window.location.href="/login.html";return}if(x.length===0)return;const o=document.getElementById("terms-agree");if(o&&!o.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const r=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),n=(b=document.getElementById("delivery-phone-2"))==null?void 0:b.value.trim(),t=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),i=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),s=((g=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:g.value)||"COD",d=(y=document.getElementById("deposit-slip"))==null?void 0:y.files[0],a=s==="ShopPay";let l=null,c="All";if(a){c=((h=document.getElementById("pickup-town-select"))==null?void 0:h.value)||"All";const w=(P=document.getElementById("pickup-shop-select"))==null?void 0:P.value,I=re();if(l=I.find(v=>v.docId===w||v.id===w)||I[0],!w&&(!I||I.length===0)){alert("Please select a pickup shop / branch!");return}}if(!r||!a&&(!t||!i)){alert(a?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",r),localStorage.setItem("mec_saved_phone2",n),localStorage.setItem("mec_saved_address",t),localStorage.setItem("mec_saved_city",i),s==="Bank"&&!d){alert("Please upload your bank deposit slip!");return}for(const w of x){const I=N.find(v=>v.docId===w.docId)||(window.groupedProducts||[]).find(v=>v.docId===w.docId);if(I&&I.mode!=="Service"&&I.mode!=="Technical"){let v=null;w.selectedVariant&&w.selectedVariant!=="Default"&&I.variants&&(v=I.variants.find($=>($.name||$.variantLabel||$.color||$.size||"Variant")===w.selectedVariant));const T=De(I,v,s);if((w.quantity||1)>T){alert(s==="ShopPay"?`Sorry! "${w.name}" only has ${T} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${w.name}" only has ${T} available in stock.`);return}}}const p=async(w=null)=>{var I;try{const v=x.reduce((E,j)=>E+j.price*(1-(j.discount||0)/100)*(j.quantity||1),0);let T=0,$="";if(window.appliedCoupon){$=window.appliedCoupon.code;const E=Me(window.appliedCoupon,x,v);E.isValidForCart&&(T=E.discountAmount)}const D=Math.max(0,v-T),R=sessionStorage.getItem("mec_ref_code");let S="",z=0;if(R)try{const E=B(L(C,"affiliates"),k("code","==",R),k("storeId","==",window.currentStoreId));(await A(E)).empty||(S=R,z=Number((D*.05).toFixed(2)))}catch(E){console.error("Error verifying affiliate referral code at checkout:",E)}const G=window.currentStoreId||"mec-book-shop",ve=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),Qe=e&&(e.name||e.email)?e.name||e.email:r||"Guest Customer",Ye={orderId:"ORD-"+Date.now(),userId:ve,userName:Qe,userEmail:e&&e.email?e.email:"",phone:r||"",phone2:n||"",branchId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:a?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:a?c:"",pickupShopPhone:a&&(l==null?void 0:l.phone)||"",pickupShopAddress:a&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:a?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:t||"",city:a?c!=="All"?c:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":i||"",items:x.map(E=>({id:E.id||E.docId||"",docId:E.docId||E.id||"",name:E.name||"",price:Number(E.price)||0,cost:Number(E.cost)||0,quantity:Number(E.quantity)||1,discount:Number(E.discount)||0,finalPrice:Number(E.price)*(1-(Number(E.discount)||0)/100)})),subtotal:Number(v)||0,discount:Number(T)||0,couponCode:$||"",total:Number(D)||0,status:"Pending",customerType:(((I=window.currentUserProfile)==null?void 0:I.customerType)||"retail").toLowerCase(),paymentMethod:s||"COD",slipImage:w||"",codCharge:s==="COD"?400:s==="Bank"?250:0,isShopPending:s==="ShopPay",storeId:G,numericStoreId:"1001",timestamp:Z(),date:new Date().toLocaleString(),referredBy:S||"",referredCommission:Number(z)||0};if(await Y(ct,Ye),S)try{const E=B(L(C,"affiliates"),k("code","==",S),k("storeId","==",G)),j=await A(E);if(!j.empty){const Ze=j.docs[0].id;await Te(le(C,"affiliates",Ze),{salesCount:Se(1),totalCommission:Se(z)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(E){console.error("Error updating affiliate statistics post-order:",E)}x=[],ce=0,window.appliedCoupon=null,Ae(),we(),pe(!1),alert(s==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":a?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch(v){console.error("Order error:",v),alert("Error placing order: "+(v.message||"Please try again."))}};if(d){const w=new FileReader;w.onload=I=>{const v=new Image;v.onload=()=>{const T=document.createElement("canvas"),$=1e3,D=1e3;let R=v.width,S=v.height;R>S?R>$&&(S*=$/R,R=$):S>D&&(R*=D/S,S=D),T.width=R,T.height=S,T.getContext("2d").drawImage(v,0,0,R,S);const G=T.toDataURL("image/jpeg",.6);p(G)},v.onerror=()=>{p(I.target.result)},v.src=I.target.result},w.onerror=I=>{console.error("FileReader Error:",I),alert("Error reading slip file. Please try selecting the image again.")},w.readAsDataURL(d)}else p()}function _(){const e=document.querySelector("#product-grid"),o=document.getElementById("pagination-controls");if(!e)return;let r=N.filter(a=>{if(a.mode==="Service"||a.mode==="Technical"||a.mode==="POS")return!1;const l=(a.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const c=V==="All"||a.category===V,p=a.name.toLowerCase().includes(H)||a.category.toLowerCase().includes(H)||a.sku&&a.sku.toLowerCase().includes(H);return c&&p});Q==="recommended"?((!Ie||Ie.length!==r.length)&&(Ie=r.map((a,l)=>({id:l,sort:Math.random()})).sort((a,l)=>a.sort-l.sort).map(a=>a.id)),r.sort(()=>Math.random()-.5)):r.sort((a,l)=>{if(Q==="az")return a.name.localeCompare(l.name);if(Q==="za")return l.name.localeCompare(a.name);if(Q==="low"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return c-p}if(Q==="high"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-c}return 0});const n=new Map;r.forEach(a=>{const l=a.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),c=l?l[1].trim():a.name.trim(),p=l?l[2].trim():(a.size||a.color)&&`${a.size?a.size:""} ${a.color?a.color:""}`.trim()||"Default",m=c.toLowerCase();if(n.has(m)){const b=n.get(m);b.totalStock+=a.totalStock!==void 0?a.totalStock:a.stock||0;const u=(a.variants||[]).map(f=>({...f,sourceDocId:a.docId}));u.length===0&&u.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),b.variants=[...b.variants,...u]}else{const b=(a.variants||[]).map(u=>({...u,sourceDocId:a.docId}));b.length===0&&b.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),n.set(m,{...a,name:c,totalStock:a.totalStock!==void 0?a.totalStock:a.stock||0,variants:b})}}),window.groupedProducts=Array.from(n.values());const t=window.groupedProducts.length,i=Math.ceil(t/ke);M>i&&i>0&&(M=i),M<1&&(M=1);const s=(M-1)*ke,d=window.groupedProducts.slice(s,s+ke);if(window.groupedProducts.length===0){e.innerHTML=`
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>
        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${H}</strong>".<br>Try a different keyword or browse all categories.</p>
        <button onclick="window.clearSearch()" 
          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"
          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
          Clear Search
        </button>
      </div>`,o&&(o.innerHTML="");return}if(e.innerHTML=d.map(a=>{const l=a.variants&&a.variants.length>0,c=l?a.variants[0]:null,p=X(a,c),m=p.retailPrice,b=p.discountedPrice,u=p.isSpecial,f=p.userType,g=Number(a.discount)||0;let y=ne(a,c);isNaN(y)&&(y=0);let h=a.image;(!h||h.trim()===""||h.includes("/logo.png"))&&c&&(c.images&&c.images.length>0?h=c.images[0]:c.image&&(h=c.image)),h=de(h,a.name);const P=a.timestamp?typeof a.timestamp.toMillis=="function"?a.timestamp.toMillis():typeof a.timestamp=="number"?a.timestamp:0:0,w=P>0&&Date.now()-P<10080*60*1e3;return`
    <div class="product-card" id="product-${a.docId}">
      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${a.docId}')">
        <div class="image-slider-container" style="height: 100%; width: 100%;">
            <img src="${h}" class="main-product-img" alt="${a.name}" 
                loading="lazy" decoding="async"
                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 
                style="width:100%; height:100%; object-fit:cover;">
        </div>
        ${y<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}
        ${g>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${g}% OFF</div>`:w?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}
        
        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">
            ${((c==null?void 0:c.images)||[a.image]).map((I,v)=>`<div class="dot ${v===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${v===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}
        </div>

        ${l?`
          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')">
            Select Options
          </button>
        `:`
          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')" ${y<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>
            ${y<=0?"Out of Stock":"Add to Cart"}
          </button>
        `}
      </div>
      <div class="product-info">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">
          <div style="font-size: 0.8rem; color: var(--text-light);">${a.category}</div>
          <div class="stock-display" style="font-size: 0.75rem; color: ${y<5?"#ef4444":"#10b981"}; font-weight:700;">Stock: ${y}</div>
        </div>
        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${a.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">
          ${a.name}
        </div>
        


        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">
            ${g>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${m.toFixed(2)}</span>`:""}
            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${b.toFixed(2)}</span>
            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}
        </div>
      </div>
    </div>`}).join(""),o)if(i>1){let a=`<button class="pag-nav-btn" ${M===1?"disabled":""} onclick="window.changePage(${M-1})">‹ Previous</button>`;const l=5;let c=Math.max(1,M-2),p=Math.min(i,c+l-1);p===i&&(c=Math.max(1,p-l+1)),c>1&&(a+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',c>2&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=c;m<=p;m++)a+=`<button class="pag-page-btn ${m===M?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<i&&(p<i-1&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),a+=`<button class="pag-page-btn" onclick="window.changePage(${i})">${i}</button>`),a+=`<button class="pag-nav-btn" ${M===i?"disabled":""} onclick="window.changePage(${M+1})">Next ›</button>`,o.innerHTML=a}else o.innerHTML=""}window.changePage=e=>{var o;M=e,_(),(o=document.getElementById("shop-section"))==null||o.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,o)=>{const r=window.groupedProducts?window.groupedProducts.find(P=>P.docId===e):null,n=document.getElementById(`product-${e}`);if(!r||!n)return;const t=r.variants&&r.variants[o]?r.variants[o]:null,i=X(r,t),s=i.retailPrice,d=i.discountedPrice,a=i.isSpecial,l=Number(r.discount)||0,c=t&&t.stock!==void 0?t.stock:r.stock||0;let p=[];t&&t.images&&t.images.length>0?p=t.images:t&&t.image?p=[t.image]:r.images&&r.images.length>0?p=r.images:p=[r.image];const m=p.map(P=>de(P,r.name)),b=n.querySelector(".original-price"),u=n.querySelector(".final-price");b&&(b.innerText=`LKR ${s.toFixed(2)}`,b.style.display=l>0||a?"inline":"none"),u&&(u.innerText=`LKR ${d.toFixed(2)}`);const f=n.querySelector(".stock-display");f.innerText=`Stock: ${c}`,f.style.color=c<5?"#ef4444":"#10b981";const g=n.querySelector(".add-to-cart-btn");c<=0?(g.disabled=!0,g.innerText="Out of Stock",g.style.background="#cbd5e1",g.style.cursor="not-allowed"):(g.disabled=!1,g.innerText="Add to Cart",g.style.background="",g.style.cursor="pointer");const y=n.querySelector(".main-product-img");y.src=m[0];const h=n.querySelector(".image-dots");if(h.innerHTML=m.map((P,w)=>`<div class="dot ${w===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${w===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let P=0;n.imageInterval&&clearInterval(n.imageInterval),n.imageInterval=setInterval(()=>{P=(P+1)%m.length,y.style.opacity="0.5",setTimeout(()=>{y.src=m[P],y.style.opacity="1",h.querySelectorAll(".dot").forEach((I,v)=>{I.style.background=v===P?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else n.imageInterval&&clearInterval(n.imageInterval)};function vt(){const e=document.getElementById("nav-auth-item"),o=document.getElementById("user-profile");document.getElementById("user-display-name"),tt(Ne,r=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),r){const n={name:r.displayName||r.email.split("@")[0],email:r.email,id:r.uid};sessionStorage.setItem("mec_user",JSON.stringify(n));const t=()=>{var P,w,I,v,T;if(!e)return;const l=(((P=window.currentUserProfile)==null?void 0:P.customerType)||"retail").toLowerCase(),c=((w=window.currentUserProfile)==null?void 0:w.phone)||((I=window.currentUserProfile)==null?void 0:I.contact)||"",p=r.photoURL||((v=window.currentUserProfile)==null?void 0:v.photoURL)||((T=window.currentUserProfile)==null?void 0:T.avatar)||"",b=($=>{if(!$)return"U";const D=$.trim().split(" ");return D.length>=2?(D[0][0]+D[1][0]).toUpperCase():$.slice(0,2).toUpperCase()})(n.name),u=l==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':l==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=l==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">
               <span>👑</span> Wholesale Customer (Wholesale Price Active)
             </div>`:l==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>💎</span> Loyalty Card Member Active
                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>🛍️</span> Standard Retail Customer
                 </div>`;e.innerHTML=`
          <div style="position: relative; display: inline-block;">
            <!-- Circular Avatar Only Trigger Button -->
            <button id="user-profile-trigger" style="
              background: transparent;
              border: none;
              padding: 2px;
              cursor: pointer;
              outline: none;
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
            " title="${n.name}">
              
              <!-- Circular Avatar Photo / Initials -->
              <div style="
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0284c7, #6366f1);
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 800;
                font-size: 0.88rem;
                color: white;
                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);
                border: 2px solid ${l==="wholesale"?"#eab308":l==="loyalty"?"#10b981":"#38bdf8"};
                overflow: hidden;
                flex-shrink: 0;
                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 
                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">
                ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:b}
              </div>

              <!-- Status Badge Dot -->
              ${l==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':l==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}
            </button>

            <!-- Modern Floating Profile Card Dropdown -->
            <div id="user-profile-dropdown" style="
              display: none;
              position: absolute;
              right: 0;
              top: calc(100% + 12px);
              width: 290px;
              background: #0f172a;
              border: 1px solid rgba(255, 255, 255, 0.15);
              border-radius: 16px;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);
              padding: 1.25rem;
              z-index: 10000;
              text-align: left;
            ">
              <!-- Profile Card Header -->
              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div style="
                  width: 46px;
                  height: 46px;
                  border-radius: 50%;
                  background: linear-gradient(135deg, #0284c7, #8b5cf6);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 1.1rem;
                  color: white;
                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
                  border: 2px solid rgba(255,255,255,0.6);
                  overflow: hidden;
                  flex-shrink: 0;
                ">
                  ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:b}
                </div>
                <div style="overflow: hidden; flex: 1;">
                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">
                      ${n.name}
                    </span>
                    ${u}
                  </div>
                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                    ${n.email||"Registered Customer"}
                  </div>
                </div>
              </div>

              <!-- Account Details & Benefits -->
              <div style="margin: 12px 0;">
                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">
                  Account Membership
                </div>
                ${f}
                
                ${c?`
                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">
                    <span style="color:#38bdf8;">📞</span> <span>${c}</span>
                  </div>
                `:""}
              </div>

              <!-- Quick Actions -->
              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">
                <a href="/track.html" style="
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  padding: 8px 12px;
                  background: rgba(255, 255, 255, 0.05);
                  border: 1px solid rgba(255, 255, 255, 0.08);
                  border-radius: 8px;
                  color: #f1f5f9;
                  text-decoration: none;
                  font-size: 0.82rem;
                  font-weight: 600;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">
                  <span style="display:flex; align-items:center; gap:8px;">
                    <span>📦</span> Track My Orders
                  </span>
                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>
                </a>
              </div>

              <!-- Divider & Logout Button -->
              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">
                <button id="nav-logout-btn" style="
                  width: 100%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 8px;
                  background: rgba(239, 68, 68, 0.12);
                  border: 1px solid rgba(239, 68, 68, 0.3);
                  color: #f87171;
                  padding: 8px 12px;
                  border-radius: 8px;
                  font-size: 0.85rem;
                  font-weight: 700;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"
                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">
                  <span>🚪</span> Log Out
                </button>
              </div>
            </div>
          </div>
        `;const g=document.getElementById("user-profile-trigger"),y=document.getElementById("user-profile-dropdown");g&&y&&(g.onclick=$=>{$.stopPropagation();const D=y.style.display==="block";y.style.display=D?"none":"block"});const h=document.getElementById("nav-logout-btn");h&&(h.onclick=async $=>{if($.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await it(Ne),window.location.href="/"}catch(D){console.error("Logout Error:",D),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",l=>{const c=document.getElementById("user-profile-trigger"),p=document.getElementById("user-profile-dropdown");p&&c&&!c.contains(l.target)&&!p.contains(l.target)&&(p.style.display="none")}),t();const i=(r.email||"").trim(),s=i.toLowerCase(),d=B(L(C,"customers"),k("email","==",i)),a=B(L(C,"customers"),k("email","==",s));Promise.all([A(d),A(a)]).then(([l,c])=>{let p=null;if(l.empty?c.empty||(p=c.docs[0].data()):p=l.docs[0].data(),p){const m=(p.customerType||p.type||(p.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...p,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),t(),_()}else{const m=window.currentStoreId||"mec-book-shop";A(B(L(C,"customers"),k("storeId","==",m))).then(b=>{const u=(r.displayName||r.email.split("@")[0]||"").trim().toLowerCase(),f=b.docs.find(g=>{const y=g.data(),h=(y.email||"").trim().toLowerCase(),P=(y.phone||"").trim(),w=(y.name||"").trim().toLowerCase(),I=h&&h===s,v=r.phoneNumber&&P&&(P===r.phoneNumber||r.phoneNumber.includes(P)),T=w&&u&&(w===u||u.includes(w)||w.includes(u)||u.split(" ")[0]===w);return I||v||T});if(f){const g=f.data(),y=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:y,docId:f.id},!g.email&&r.email&&at(le(C,"customers",f.id),{email:r.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),t(),_()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),t(),_()})}}).catch(l=>{console.error("Error fetching user profile:",l),window.currentUserProfile={customerType:"retail"},t(),_()})}else sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},_(),e&&(e.innerHTML='<a href="/login">Login</a>'),o&&(o.style.display="none")})}function xt(){const e=document.getElementById("reviews-container");if(!e)return;const o=L(C,"reviews"),r=B(o,rt("timestamp","desc"),ot(15));Le(r,n=>{const t=n.docs.map(i=>i.data());if(t.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=t.map(i=>`
      <div class="review-card">
        <div class="review-stars">
          ${"★".repeat(i.rating)}${"☆".repeat(5-i.rating)}
        </div>
        <p class="review-comment">"${i.comment||"No comment provided."}"</p>
        <div class="review-footer">
          <span class="review-author">${i.userName}</span>
          <span class="review-date">${i.date}</span>
        </div>
      </div>
    `).join("")})}gt();vt();xt();const Ce="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let Ee=null;try{Ce&&(Ee=new Xe(Ce))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function Fe(e,o){if(!N||N.length===0)return o?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const n=(e||"").toLowerCase().split(/\s+/).filter(i=>i.length>2),t=N.map(i=>{let s=0;const d=(i.name||"").toLowerCase(),a=(i.category||"").toLowerCase(),l=(i.description||"").toLowerCase();return n.forEach(c=>{d.includes(c)&&(s+=3),a.includes(c)&&(s+=2),l.includes(c)&&(s+=1)}),{product:i,score:s}}).filter(i=>i.score>0).sort((i,s)=>s.score-i.score);if(t.length>0){const i=t.slice(0,3).map(s=>s.product);return o?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${i.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=d.wholesalePrice?` | තොග මිල: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${i.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"In Stock":"Out of Stock",l=d.wholesalePrice?` | Wholesale: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return o?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function kt(e,o){var n,t,i,s,d,a;const r=/[\u0D80-\u0DFF]/.test(e)||o==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((n=window.currentStoreData)==null?void 0:n.name)||"MEC Book Shop, Horana",c=(N||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(g=>`${g.name||g.variantLabel||"Var"}-Stock:${g.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.
Available Inventory & Prices:
${c}

CRITICAL RULES:
1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).
2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.
3. Keep answers concise, clear, and direct (max 2-3 short sentences).
4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(Ee)try{const y=(await(await Ee.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(y)return y}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Ce)}`,b=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(b.ok){const u=await b.json(),f=(a=(d=(s=(i=(t=u==null?void 0:u.candidates)==null?void 0:t[0])==null?void 0:i.content)==null?void 0:s.parts)==null?void 0:d[0])==null?void 0:a.text;if(f&&f.trim())return f.trim()}return Fe(e,r)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),Fe(e,r)}}window.toggleGeminiChat=e=>{var t;const o=document.getElementById("gemini-chat-window"),r=document.getElementById("gemini-bubble");if(!o)return;(e!=null?!!e:!o.classList.contains("active"))?(o.classList.add("active"),r&&r.classList.remove("active"),(t=document.getElementById("gemini-chat-input"))==null||t.focus()):o.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),o=document.getElementById("gemini-chat-messages");if(!e||!o||!e.value.trim())return;const r=e.value.trim();e.value="";const n=document.createElement("div");n.className="user-msg",n.textContent=r,o.appendChild(n),o.scrollTop=o.scrollHeight;const t=document.createElement("div");t.className="ai-msg",t.textContent="Thinking...",o.appendChild(t),o.scrollTop=o.scrollHeight;const i=r.toLowerCase(),s=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let d=r,a=!1;if(s.forEach(m=>{i.includes(m)&&(a=!0)}),a&&(s.forEach(m=>{d=d.replace(new RegExp(m,"gi"),"")}),d=d.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),d.length>1)){window.searchQuery=d,H=d;const m=document.getElementById("store-search");m&&(m.value=d),M=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(r)||["mata","thiyenawada","tiyenawada","poth"].some(m=>i.includes(m)),c=await kt(r,l?"si":"en");t.textContent=c,o.scrollTop=o.scrollHeight};window.talkToAgentWhatsApp=()=>{var i,s,d;const e=document.getElementById("gemini-chat-messages");let o="";e&&(o=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let r=((i=window.currentStoreData)==null?void 0:i.phone)||((s=window.systemConfig)==null?void 0:s.invPhone)||"94770658356";r=r.replace(/[^0-9]/g,""),r.startsWith("0")&&(r="94"+r.substring(1));const n=`Hi ${((d=window.currentStoreData)==null?void 0:d.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,t=encodeURIComponent(n+o);window.open(`https://wa.me/${r}?text=${t}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const Ue=document.getElementById("gemini-orb-btn");Ue&&Ue.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=je.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const o=B(L(C,"affiliates"),k("code","==",e),k("storeId","==",window.currentStoreId)),r=await A(o);if(!r.empty){const n=le(C,"affiliates",r.docs[0].id);await Te(n,{clicks:Se(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(o){console.error("Error incrementing referral click:",o)}}};function It(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="aff-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>
        
        <!-- Tab navigation inside modal -->
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>
        </div>

        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>
        </form>
      </div>

      <div id="aff-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>
        
        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">
          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>
          <div style="display:flex; gap:10px; align-items:center;">
            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">
            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>
          </div>
        </div>

        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}function St(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="seller-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>
        
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>
        </div>

        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>
        </form>
      </div>

      <div id="seller-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>
            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>
          </div>
          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">
            Pending
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">
          
          <!-- Add Product Form -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>
            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">
              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>
              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>
            </form>
          </div>

          <!-- Product List -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>
            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">
              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>
            </div>
          </div>
        </div>

        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{It();const o=document.getElementById("affiliate-portal-modal");if(o&&(o.style.display=e?"flex":"none",o.classList.toggle("active",e),e)){const r=localStorage.getItem("mec_affiliate_user");if(r){const n=JSON.parse(r);try{const t=B(L(C,"affiliates"),k("email","==",n.email),k("storeId","==",window.currentStoreId)),i=await A(t);if(i.empty)localStorage.removeItem("mec_affiliate_user"),$e();else{const s={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),me(s)}}catch(t){console.error(t),me(n)}}else $e()}};function $e(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const o=document.getElementById("aff-login-form"),r=document.getElementById("aff-register-form"),n=document.getElementById("aff-tab-login"),t=document.getElementById("aff-tab-register");e==="login"?(o&&(o.style.display="flex"),r&&(r.style.display="none"),n&&(n.style.color="#38bdf8",n.style.borderBottom="2px solid #38bdf8"),t&&(t.style.color="#94a3b8",t.style.borderBottom="none")):(o&&(o.style.display="none"),r&&(r.style.display="flex"),n&&(n.style.color="#94a3b8",n.style.borderBottom="none"),t&&(t.style.color="#10b981",t.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const o=document.getElementById("aff-login-email").value.trim(),r=document.getElementById("aff-login-pass").value;try{const n=B(L(C,"affiliates"),k("email","==",o),k("password","==",r),k("storeId","==",window.currentStoreId)),t=await A(n);if(t.empty)alert("Invalid email address or password.");else{const i={...t.docs[0].data(),docId:t.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(i)),me(i)}}catch(n){console.error(n),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const o=document.getElementById("aff-reg-name").value.trim(),r=document.getElementById("aff-reg-email").value.trim(),n=document.getElementById("aff-reg-phone").value.trim(),t=document.getElementById("aff-reg-pass").value;try{const i=B(L(C,"affiliates"),k("email","==",r),k("storeId","==",window.currentStoreId));if(!(await A(i)).empty){alert("An account with this email is already registered as a partner.");return}const d=o.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),a={name:o,email:r,phone:n,password:t,code:d,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:Z()},l=await Y(L(C,"affiliates"),a);a.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(a)),me(a)}catch(i){console.error(i),alert("Registration failed. Please try again.")}};function me(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const o=window.location.protocol,r=window.location.host,n=window.location.pathname;let t=`${o}//${r}${n}`;window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?t+=`?store=${window.currentStoreId}&ref=${e.code}`:t+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=t,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),$e()};window.toggleSellerPortal=async e=>{St();const o=document.getElementById("seller-portal-modal");if(o&&(o.style.display=e?"flex":"none",o.classList.toggle("active",e),e)){const r=localStorage.getItem("mec_seller_user");if(r){const n=JSON.parse(r);try{const t=B(L(C,"vendor_shops"),k("email","==",n.email),k("storeId","==",window.currentStoreId)),i=await A(t);if(i.empty)localStorage.removeItem("mec_seller_user"),Be();else{const s={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),ge(s)}}catch(t){console.error(t),ge(n)}}else Be()}};function Be(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const o=document.getElementById("seller-login-form"),r=document.getElementById("seller-register-form"),n=document.getElementById("seller-tab-login"),t=document.getElementById("seller-tab-register");e==="login"?(o&&(o.style.display="flex"),r&&(r.style.display="none"),n&&(n.style.color="#38bdf8",n.style.borderBottom="2px solid #38bdf8"),t&&(t.style.color="#94a3b8",t.style.borderBottom="none")):(o&&(o.style.display="none"),r&&(r.style.display="flex"),n&&(n.style.color="#94a3b8",n.style.borderBottom="none"),t&&(t.style.color="#10b981",t.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const o=document.getElementById("seller-login-email").value.trim(),r=document.getElementById("seller-login-pass").value;try{const n=B(L(C,"vendor_shops"),k("email","==",o),k("password","==",r),k("storeId","==",window.currentStoreId)),t=await A(n);if(t.empty)alert("Invalid email address or password.");else{const i={...t.docs[0].data(),docId:t.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(i)),ge(i)}}catch(n){console.error(n),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{e.preventDefault();const o=document.getElementById("seller-reg-shopname").value.trim(),r=document.getElementById("seller-reg-owner").value.trim(),n=document.getElementById("seller-reg-email").value.trim(),t=document.getElementById("seller-reg-phone").value.trim(),i=document.getElementById("seller-reg-pass").value;try{const s=B(L(C,"vendor_shops"),k("shopName","==",o),k("storeId","==",window.currentStoreId));if(!(await A(s)).empty){alert("This shop name is already registered.");return}const a=B(L(C,"vendor_shops"),k("email","==",n),k("storeId","==",window.currentStoreId));if(!(await A(a)).empty){alert("This email is already registered to a shop.");return}const c={shopName:o,ownerName:r,email:n,phone:t,password:i,status:"pending",storeId:window.currentStoreId,timestamp:Z()},p=await Y(L(C,"vendor_shops"),c);c.docId=p.id,localStorage.setItem("mec_seller_user",JSON.stringify(c)),ge(c);try{const m="+94770658356",b=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${o}
Owner: ${r}
Phone: ${t}
Email: ${n}`,u=`https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(m)}&message=${encodeURIComponent(b)}`;fetch(u,{method:"GET",mode:"no-cors"}).catch(()=>{})}catch(m){console.error("Vendor SMS alert error:",m)}}catch(s){console.error(s),alert("Shop registration failed. Please try again.")}};async function ge(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const o=document.getElementById("seller-dash-status-badge");o&&(o.innerText=e.status||"pending",e.status==="active"?(o.style.background="rgba(16, 185, 129, 0.2)",o.style.color="#10b981"):(o.style.background="rgba(251, 191, 36, 0.2)",o.style.color="#fbbf24")),await Je(e.email)}async function Je(e){const o=document.getElementById("seller-products-list");if(o){o.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const r=B(oe,k("vendorId","==",e),k("storeId","==",window.currentStoreId)),n=await A(r);if(n.empty)o.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let t="";n.forEach(i=>{const s=i.data(),d=s.status==="active"?"#10b981":"#fbbf24";t+=`
          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-weight:bold; font-size:0.85rem; display:block;">${s.name||""}</span>
              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${s.price||0}</span>
            </div>
            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${d};">${s.status||"pending"}</span>
          </div>
        `}),o.innerHTML=t}}catch(r){console.error(r),o.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const o=localStorage.getItem("mec_seller_user");if(!o)return;const r=JSON.parse(o),n=document.getElementById("seller-prod-name").value.trim(),t=document.getElementById("seller-prod-price").value.trim(),i=document.getElementById("seller-prod-category").value.trim(),s=document.getElementById("seller-prod-image").value.trim(),d=document.getElementById("seller-prod-desc").value.trim();try{const a={name:n,price:Number(t),category:i,image:s||"",description:d||"",status:"pending",vendorId:r.email,storeId:window.currentStoreId,timestamp:Z(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await Y(oe,a),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await Je(r.email)}catch(a){console.error(a),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),Be()};window.addEventListener("beforeunload",function(e){var o;(o=window.chrome)!=null&&o.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
