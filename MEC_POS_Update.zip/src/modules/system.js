export const CLIENT_VERSION = "3.38.43";

// --- Disable Zooming & Window Snapping (Ctrl+Wheel, Ctrl +/-, Win+Arrows) â€” Native Desktop App Lock ---
if (typeof window !== 'undefined') {
    window.addEventListener('wheel', (e) => {
        if (e.ctrlKey) {
            e.preventDefault();
        }
    }, { passive: false });

    window.addEventListener('keydown', (e) => {
        // Block Ctrl Zoom (+, -, 0, =)
        if (e.ctrlKey && (
            e.key === '+' || e.key === '-' || e.key === '=' || e.key === '_' || e.key === '0' || 
            e.code === 'NumpadAdd' || e.code === 'NumpadSubtract' || e.code === 'Digit0' || e.code === 'Numpad0'
        )) {
            e.preventDefault();
        }
        // Block Windows / Meta + Arrow Keys (Windows Snap / Resize)
        if (e.metaKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, { capture: true });

    window.addEventListener('touchmove', (e) => {
        if (e.touches && e.touches.length > 1) {
            e.preventDefault();
        }
    }, { passive: false });
}

export function handleCloseApp() {
    // Try sending Daily Brief on app close if evening
    try {
        if (typeof window.checkAndDispatchCeoNightlyWhatsApp === 'function') {
            const hour = new Date().getHours();
            if (hour >= 18) { // 6 PM onwards
                window.checkAndDispatchCeoNightlyWhatsApp(true);
            }
        }
    } catch(e) {}

    if (window.electronAPI?.close) {
        window.electronAPI.close();
    } else if (window.electron?.close) {
        window.electron.close();
    } else if (window.chrome?.webview) {
        try { window.chrome.webview.postMessage({ type: 'close' }); } catch(e){}
        try { window.chrome.webview.postMessage('close'); } catch(e){}
    } else {
        window.close();
    }
}

export function handleMinimizeApp() {
    if (window.electronAPI?.minimize) {
        window.electronAPI.minimize();
    } else if (window.electron?.minimize) {
        window.electron.minimize();
    } else if (window.chrome?.webview) {
        try { window.chrome.webview.postMessage({ type: 'minimize' }); } catch(e){}
        try { window.chrome.webview.postMessage('minimize'); } catch(e){}
    }
}

export function openExternalUrl(url) {
    if (!url) return;
    if (window.electronAPI?.openExternal) {
        window.electronAPI.openExternal(url);
    } else if (window.electron?.openExternal) {
        window.electron.openExternal(url);
    } else if (window.chrome?.webview) {
        try {
            window.chrome.webview.postMessage(JSON.stringify({ type: 'openExternalUrl', action: 'openExternalUrl', url: url }));
        } catch (e) {
            console.error('WebView postMessage error:', e);
            window.open(url, '_blank');
        }
    } else {
        try { window.open(url, '_blank', 'noopener,noreferrer'); } catch (e) { console.error(e); }
    }
}

window.showSettingsSubTab = (subTabId = 'general') => {
    document.querySelectorAll('.settings-view').forEach(view => {
        view.style.setProperty('display', 'none', 'important');
    });
    document.querySelectorAll('.settings-nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    const targetView = document.getElementById(`set-sub-${subTabId}`);
    if (targetView) {
        targetView.style.setProperty('display', 'block', 'important');
    }
    const targetBtn = document.getElementById(`btn-set-${subTabId}`);
    if (targetBtn) {
        targetBtn.classList.add('active');
    }
};

window.renderITSystemLogs = () => {
    const logsContainer = document.getElementById('it-activity-logs');
    if (!logsContainer) return;
    
    const now = new Date().toLocaleString();
    const currentRole = sessionStorage.getItem('userRole') || 'Admin';
    const currentEmail = sessionStorage.getItem('userEmail') || 'mecbookshop@gmail.com';

    logsContainer.innerHTML = `
        <div style="padding: 0.8rem 1rem; border-bottom: 1px solid rgba(255,255,255,0.06); font-size: 0.82rem; display: flex; align-items: center; justify-content: space-between;">
            <div><span style="font-weight: 800; color: #10b981;">[SYSTEM OK]</span> Monitoring active. All cloud microservices responding.</div>
            <div style="color: #64748b; font-size: 0.75rem;">${now}</div>
        </div>
        <div style="padding: 0.8rem 1rem; border-bottom: 1px solid rgba(255,255,255,0.06); font-size: 0.82rem; display: flex; align-items: center; justify-content: space-between;">
            <div><span style="font-weight: 800; color: #38bdf8;">[SECURITY]</span> Session active for <b>${currentEmail}</b> (${currentRole}).</div>
            <div style="color: #64748b; font-size: 0.75rem;">${now}</div>
        </div>
        <div style="padding: 0.8rem 1rem; border-bottom: 1px solid rgba(255,255,255,0.06); font-size: 0.82rem; display: flex; align-items: center; justify-content: space-between;">
            <div><span style="font-weight: 800; color: #a855f7;">[FIREBASE]</span> Realtime sync listener connected to Firestore DB.</div>
            <div style="color: #64748b; font-size: 0.75rem;">${now}</div>
        </div>
        <div style="padding: 0.8rem 1rem; font-size: 0.82rem; display: flex; align-items: center; justify-content: space-between;">
            <div><span style="font-weight: 800; color: #eab308;">[SNAPSHOT]</span> Local C# backup pipeline active (C:\\MEC_BACKUPS).</div>
            <div style="color: #64748b; font-size: 0.75rem;">${now}</div>
        </div>
    `;
};

export async function fetchWithRetry(url, options = {}, retries = 3, delay = 1000) {
    try {
        const response = await fetch(url, options);
        if (response.status === 503 && retries > 0) {
            console.warn(`[Network] Got 503 from ${url}. Retrying in ${delay}ms... (${retries} attempts left)`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return fetchWithRetry(url, options, retries - 1, delay * 2);
        }
        return response;
    } catch (err) {
        if (retries > 0) {
            console.warn(`[Network] Fetch error for ${url}. Retrying in ${delay}ms...`, err);
            await new Promise(resolve => setTimeout(resolve, delay));
            return fetchWithRetry(url, options, retries - 1, delay * 2);
        }
        throw err;
    }
}

let _isOpeningDownloads = false;
export function openLocalExportsFolder() {
    if (_isOpeningDownloads) return;
    _isOpeningDownloads = true;
    setTimeout(() => { _isOpeningDownloads = false; }, 2000);

    if (window.chrome?.webview) {
        try {
            window.chrome.webview.postMessage(JSON.stringify({ action: 'openDownloadsFolder', type: 'open-downloads-folder' }));
            window.showToast?.("📁 Opening Downloads folder...", "info");
            return;
        } catch(e) {
            console.error(e);
        }
    }
    if (window.electronAPI?.openExportsFolder) {
        window.electronAPI.openExportsFolder();
        return;
    }
    if (window.electron?.send) {
        window.electron.send('open-exports-folder');
        return;
    }
    window.showToast?.("📁 Downloaded files are saved to Downloads folder.", "info");
}

window.openLocalExportsFolder = openLocalExportsFolder;
window.openDownloadsFolder = openLocalExportsFolder;

let _isOpeningBackup = false;
export function openBackupFolder() {
    if (_isOpeningBackup) return;
    _isOpeningBackup = true;
    setTimeout(() => { _isOpeningBackup = false; }, 2000);

    if (window.chrome?.webview) {
        try {
            window.chrome.webview.postMessage(JSON.stringify({ action: 'openBackupFolder' }));
            window.showToast?.("📁 Opening Backup folder on Desktop...", "info");
            return;
        } catch(e) {
            console.error(e);
        }
    }
    if (window.electronAPI?.openBackupFolder) {
        window.electronAPI.openBackupFolder();
        return;
    }
    if (window.electron?.send) {
        window.electron.send('open-backup-folder');
        return;
    }
    window.showToast?.("📁 Backups are saved to Desktop 'mecpos bacup' folder.", "info");
}

window.handleCloseApp = handleCloseApp;
window.handleMinimizeApp = handleMinimizeApp;
window.openExternalUrl = openExternalUrl;
window.fetchWithRetry = fetchWithRetry;
window.openLocalExportsFolder = openLocalExportsFolder;
window.openBackupFolder = openBackupFolder;

// â”€â”€â”€ Native Hardware / Device Tracking & Firebase Registration â”€â”€â”€
export function getDeviceId() {
    let devId = localStorage.getItem('mecpos_device_id');
    if (!devId) {
        devId = 'dev_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now().toString(36);
        localStorage.setItem('mecpos_device_id', devId);
    }
    return devId;
}

export function getCustomDeviceName() {
    const saved = localStorage.getItem('mecpos_device_custom_name');
    if (saved && saved.trim() !== '') return saved.trim();
    const detected = localStorage.getItem('mecpos_machine_name');
    if (detected && detected.trim() !== '') return detected.trim();
    return 'MEC PC 1';
}

export function saveDeviceNameSetting(newName) {
    if (!newName) return;
    const cleanName = newName.trim();
    localStorage.setItem('mecpos_device_custom_name', cleanName);
    const storeId = (typeof window.getStoreId === 'function' ? window.getStoreId() : (sessionStorage.getItem('userStoreId') || 'mec-book-shop'));
    const storeSpecificKey = `mecpos_device_name_${storeId}`;
    localStorage.setItem(storeSpecificKey, cleanName);
    window.registerDeviceToFirebase(cleanName);
    if (typeof window.showToast === 'function') {
        window.showToast(`ðŸ’» Device Name updated to: "${cleanName}"`, 'success');
    }
}

export function fetchNativeDeviceInfo(userTriggered = false) {
    if (window.chrome?.webview) {
        try {
            window.chrome.webview.postMessage(JSON.stringify({ action: 'getDeviceInfo' }));
            window.chrome.webview.postMessage('get-device-info');
        } catch (e) {
            console.warn('[DeviceInfo] WebView postMessage failed:', e);
        }
    } else if (window.electronAPI?.getDeviceInfo) {
        window.electronAPI.getDeviceInfo().then(info => window.__onDeviceInfoReceived?.(info)).catch(() => {});
    } else {
        // Fallback for browser testing
        const fallbackName = localStorage.getItem('mecpos_machine_name') || 'WEB-CLIENT';
        window.__onDeviceInfoReceived?.({
            machineName: fallbackName,
            userName: 'BrowserUser',
            osVersion: navigator.userAgent,
            appVersion: CLIENT_VERSION,
            isDesktopApp: false
        });
    }

    if (userTriggered && typeof window.showToast === 'function') {
        window.showToast('ðŸ” Detecting local PC device info...', 'info');
    }
}

window.__onDeviceInfoReceived = function(info) {
    if (!info) return;
    try {
        if (info.machineName) {
            localStorage.setItem('mecpos_machine_name', info.machineName);
            const mEl = document.getElementById('set-detected-machine-name');
            if (mEl) mEl.innerText = `${info.machineName} (${info.userName || 'PC'})`;
        }
        if (info.osVersion) localStorage.setItem('mecpos_os_version', info.osVersion);
        if (info.appVersion) localStorage.setItem('mecpos_app_version', info.appVersion);

        const currentCustomName = localStorage.getItem('mecpos_device_custom_name');
        const dInput = document.getElementById('set-device-name');
        if (dInput) {
            if (currentCustomName) {
                dInput.value = currentCustomName;
            } else if (info.machineName) {
                dInput.value = info.machineName;
                localStorage.setItem('mecpos_device_custom_name', info.machineName);
            }
        }

        window.registerDeviceToFirebase(currentCustomName || info.machineName || 'MEC PC 1', info);
    } catch (e) {
        console.error('[DeviceInfo] Callback processing error:', e);
    }
};

export async function registerDeviceToFirebase(customName = null, nativeInfo = null) {
    try {
        const deviceId = getDeviceId();
        const storeId = (typeof window.getStoreId === 'function' ? window.getStoreId() : (sessionStorage.getItem('userStoreId') || 'mec-book-shop'));
        const name = customName || getCustomDeviceName();
        const machineName = nativeInfo?.machineName || localStorage.getItem('mecpos_machine_name') || 'Unknown Host';
        const osVer = nativeInfo?.osVersion || localStorage.getItem('mecpos_os_version') || navigator.userAgent;
        const appVer = nativeInfo?.appVersion || CLIENT_VERSION;

        const payload = {
            deviceId: deviceId,
            deviceName: name,
            machineName: machineName,
            osVersion: osVer,
            appVersion: appVer,
            storeId: storeId,
            branchId: (localStorage.getItem('mec_terminal_branch') || sessionStorage.getItem('userBranchId') || 'main'),
            lastUser: sessionStorage.getItem('userName') || sessionStorage.getItem('userUsername') || 'System',
            lastActive: new Date().toISOString(),
            isOnline: true
        };

        if (window.db) {
            import('firebase/firestore').then(async ({ doc, setDoc, serverTimestamp }) => {
                try {
                    payload.updatedAt = serverTimestamp();
                    await setDoc(doc(window.db, 'pos_terminals', deviceId), payload, { merge: true });
                    console.log(`ðŸ’» [DeviceInfo] Device registered in Firebase: pos_terminals/${deviceId} ("${name}")`);
                } catch (dbErr) {
                    console.warn('[DeviceInfo] Firestore device save error:', dbErr);
                }
            }).catch(() => {});
        }
    } catch (e) {
        console.warn('[DeviceInfo] registerDeviceToFirebase error:', e);
    }
}

window.getDeviceId = getDeviceId;
window.getCustomDeviceName = getCustomDeviceName;
window.saveDeviceNameSetting = saveDeviceNameSetting;
window.fetchNativeDeviceInfo = fetchNativeDeviceInfo;
window.registerDeviceToFirebase = registerDeviceToFirebase;

export function initSystem() {
    displayUIVersion();
    updateLoginBranding();
    initKeyboardNavigation();
    fetchNativeDeviceInfo();
    if (typeof window.refreshSystemPrinters === 'function') {
        window.refreshSystemPrinters();
    }
    
    // Profile Trigger Listener
    document.addEventListener('click', (e) => {
        const trigger = document.getElementById('profile-trigger');
        const dropdown = document.getElementById('profile-dropdown');
        if (!trigger || !dropdown) return;

        if (trigger.contains(e.target)) {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.toggle('show');
            }
        } else {
            dropdown.classList.remove('show');
        }
    });
}

window.initSystem = initSystem;

// Keyboard Navigation Coordinator (Sidebar tabs <-> Tab Content items)
export function initKeyboardNavigation() {
    window.keyboardNavigationState = {
        currentFocusArea: 'sidebar', // 'sidebar' or 'content'
        sidebarIndex: 0,
        contentIndex: -1
    };

    document.addEventListener('keydown', (e) => {
        // Suspend system keyboard navigation if in POS mode or inside any modal
        const isPosMode = document.body.classList.contains('pos-fullscreen-mode') || 
                          (document.getElementById('section-pos') && document.getElementById('section-pos').style.display !== 'none');
        if (isPosMode) {
            return; // In POS mode, all key handling is exclusively managed by POS module
        }

        // Exclude system keys or typing in input/select/textarea fields
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT')) {
            if (e.key === 'Escape') {
                activeEl.blur();
                window.keyboardNavigationState.currentFocusArea = 'sidebar';
                highlightActiveSidebarTab();
                removeContentHighlights();
                e.preventDefault();
            }
            return;
        }

        const state = window.keyboardNavigationState;

        // Get visible sidebar tabs
        const sidebarTabs = Array.from(document.querySelectorAll('.nav-links .nav-tab')).filter(tab => tab.style.display !== 'none');
        if (sidebarTabs.length === 0) return;

        // Sync with actual active tab if index has drifted (e.g. click by user)
        const activeTabIndex = sidebarTabs.findIndex(tab => tab.classList.contains('active'));
        if (activeTabIndex !== -1 && state.contentIndex === -1 && activeTabIndex !== state.sidebarIndex && state.currentFocusArea === 'sidebar') {
            state.sidebarIndex = activeTabIndex;
        }

        if (state.currentFocusArea === 'sidebar') {
            removeContentHighlights();
            
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                if (e.key === 'ArrowDown') {
                    state.sidebarIndex = Math.min(state.sidebarIndex + 1, sidebarTabs.length - 1);
                } else {
                    state.sidebarIndex = Math.max(state.sidebarIndex - 1, 0);
                }
                
                const targetTab = sidebarTabs[state.sidebarIndex];
                if (targetTab) {
                    let tabId = targetTab.id?.replace('tab-', '') || targetTab.getAttribute('data-tab');
                    if (!tabId) {
                        const onclick = targetTab.getAttribute('onclick') || '';
                        const match = onclick.match(/showTab\(['"]([^'"]+)['"]\)/);
                        if (match) tabId = match[1];
                    }
                    
                    // Don't auto-open fullscreen tabs (POS Terminal & Smart Procurement)
                    if (tabId !== 'pos' && tabId !== 'stock') {
                        targetTab.click();
                    } else {
                        // Visually highlight it as active, even though we don't click/open it yet
                        document.querySelectorAll('.nav-tab').forEach(link => link.classList.remove('active'));
                        document.querySelectorAll('.nav-tab').forEach(link => {
                            const matchesId = link.id === `tab-${tabId}`;
                            const matchesData = link.getAttribute('data-tab') === tabId;
                            const matchesOnclick = link.getAttribute('onclick')?.includes(`'${tabId}'`) || link.getAttribute('onclick')?.includes(`"${tabId}"`);
                            if (matchesId || matchesData || matchesOnclick) {
                                link.classList.add('active');
                            }
                        });
                    }
                    
                    targetTab.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    highlightActiveSidebarTab();
                }
            } else if (e.key === 'ArrowRight' || e.key === 'Enter') {
                e.preventDefault();
                const targetTab = sidebarTabs[state.sidebarIndex];
                if (targetTab) {
                    targetTab.click(); // Open it (especially for fullscreen tabs)
                    
                    let tabId = targetTab.id?.replace('tab-', '') || targetTab.getAttribute('data-tab');
                    if (!tabId) {
                        const onclick = targetTab.getAttribute('onclick') || '';
                        const match = onclick.match(/showTab\(['"]([^'"]+)['"]\)/);
                        if (match) tabId = match[1];
                    }
                    
                    // Shift focus inside the tab content (except fullscreen tabs which handle their own UI)
                    if (tabId !== 'pos' && tabId !== 'stock') {
                        state.currentFocusArea = 'content';
                        state.contentIndex = 0;
                        highlightContentItem();
                    }
                }
            }
        } else if (state.currentFocusArea === 'content') {
            // Content Navigation (e.g. order cards, product items, active sub-tabs, etc.)
            const tabId = window.currentActiveTab;
            let items = [];

            if (tabId === 'orders') {
                items = document.querySelectorAll('#admin-order-list .order-card');
            } else if (tabId === 'products') {
                items = document.querySelectorAll('#admin-product-list .product-card, #admin-product-list tr');
            } else if (tabId === 'web-orders') {
                items = document.querySelectorAll('#web-orders-page-list .order-card');
            } else if (tabId === 'repairs') {
                items = document.querySelectorAll('#repairs-New-view tr, #repairs-Processing-view tr, #repairs-Completed-view tr, #repairs-Delivered-view tr');
            }

            // Fallback: select buttons, cards inside active section
            if (items.length === 0) {
                const activeSection = document.getElementById(`section-${tabId}`);
                if (activeSection) {
                    items = activeSection.querySelectorAll('button, .card, .order-card, .product-card, tr');
                }
            }

            const visibleItems = Array.from(items).filter(item => item.offsetHeight > 0);
            if (visibleItems.length === 0) {
                if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    state.currentFocusArea = 'sidebar';
                    highlightActiveSidebarTab();
                }
                return;
            }

            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                state.currentFocusArea = 'sidebar';
                state.contentIndex = -1;
                removeContentHighlights();
                highlightActiveSidebarTab();
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                state.contentIndex = Math.min(state.contentIndex + 1, visibleItems.length - 1);
                highlightContentItem(visibleItems);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                state.contentIndex = Math.max(state.contentIndex - 1, 0);
                highlightContentItem(visibleItems);
            } else if (e.key === 'Enter') {
                if (state.contentIndex >= 0 && state.contentIndex < visibleItems.length) {
                    e.preventDefault();
                    visibleItems[state.contentIndex].click();
                }
            }
        }
    });

    // Run initial highlight after load
    setTimeout(highlightActiveSidebarTab, 500);
}

function highlightActiveSidebarTab() {
    const sidebarTabs = Array.from(document.querySelectorAll('.nav-links .nav-tab')).filter(tab => tab.style.display !== 'none');
    sidebarTabs.forEach((tab, idx) => {
        if (idx === window.keyboardNavigationState.sidebarIndex) {
            tab.style.borderColor = '#38bdf8';
            tab.style.boxShadow = '0 0 15px rgba(56, 189, 248, 0.4)';
        } else {
            tab.style.borderColor = 'transparent';
            tab.style.boxShadow = 'none';
        }
    });
}

function removeContentHighlights() {
    document.querySelectorAll('.order-card, .product-card, tr, button').forEach(el => {
        if (el.classList.contains('nav-tab')) return;
        el.style.borderColor = '';
        el.style.boxShadow = '';
        el.classList.remove('keyboard-focused');
    });
}

function highlightContentItem(visibleItems) {
    if (!visibleItems || visibleItems.length === 0) {
        const tabId = window.currentActiveTab;
        let items = [];
        if (tabId === 'orders') {
            items = document.querySelectorAll('#admin-order-list .order-card');
        } else if (tabId === 'products') {
            items = document.querySelectorAll('#admin-product-list .product-card, #admin-product-list tr');
        } else if (tabId === 'web-orders') {
            items = document.querySelectorAll('#web-orders-page-list .order-card');
        } else if (tabId === 'repairs') {
            items = document.querySelectorAll('#repairs-New-view tr, #repairs-Processing-view tr, #repairs-Completed-view tr, #repairs-Delivered-view tr');
        }
        visibleItems = Array.from(items).filter(item => item.offsetHeight > 0);
    }
    
    removeContentHighlights();
    if (!visibleItems || visibleItems.length === 0) return;
    
    // Ensure index is within boundaries
    if (window.keyboardNavigationState.contentIndex < 0) window.keyboardNavigationState.contentIndex = 0;
    if (window.keyboardNavigationState.contentIndex >= visibleItems.length) window.keyboardNavigationState.contentIndex = visibleItems.length - 1;
    
    const idx = window.keyboardNavigationState.contentIndex;
    const item = visibleItems[idx];
    if (item) {
        item.style.borderColor = '#38bdf8';
        item.style.boxShadow = '0 0 20px rgba(56, 189, 248, 0.4)';
        item.classList.add('keyboard-focused');
        item.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

export function updateLoginBranding() {
    const loginTitle = document.querySelector('.login-header h2');
    const splashText = document.querySelector('#splash-screen p');
    const loginImg = document.querySelector('.login-header img');

    let brandName = "MEC POS";
    
    if (loginTitle) loginTitle.innerText = brandName;
    if (splashText) splashText.innerText = "Syncing with MEC POS Cloud";
    if (loginImg) {
        loginImg.src = "/logo.png";
    }
}

export function displayUIVersion() {
    const badge = document.getElementById('admin-version-badge');
    const label = document.getElementById('login-version-label');
    const loginSub = document.getElementById('login-subtitle');
    const brandSub = document.querySelector('.nav-brand .sub');
    
    let planName = 'Managed';
    if (window.storeInfo && window.storeInfo.plan) {
        if (typeof window.getCleanPlanName === 'function') {
            planName = window.getCleanPlanName(window.storeInfo.plan);
        } else {
            planName = window.storeInfo.plan;
        }
    }
    
    if (badge) badge.innerText = `v${CLIENT_VERSION}`;
    if (brandSub) brandSub.innerText = `v${CLIENT_VERSION}`;
    if (label) label.innerText = `Username / Email (v${CLIENT_VERSION})`;
    if (loginSub) loginSub.innerText = `Universal Merchant Portal (v${CLIENT_VERSION})`;
}

export function updateUserDisplay() {
    const currentRole = sessionStorage.getItem('userRole') || 'Admin';
    const email = sessionStorage.getItem('userEmail');
    const username = sessionStorage.getItem('userUsername') || (email ? email.split('@')[0] : 'Staff');
    const name = sessionStorage.getItem('userName') || (email ? email.split('@')[0] : 'Staff');
    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const branchName = sessionStorage.getItem('userBranchName') || (branchId === 'Global' || branchId === 'main' ? 'Horana (Main Branch)' : branchId);
    const designation = sessionStorage.getItem('userDesignation') || (currentRole === 'CEO_Admin' ? 'CEO / Founder' : (currentRole === 'SuperAdmin' ? 'Super Administrator' : currentRole));
    const phone = sessionStorage.getItem('userPhone') || '0770658356';
    const regno = sessionStorage.getItem('userRegNo') || (currentRole === 'CEO_Admin' ? 'EMP-001' : 'EMP-003');

    const initial = name ? name[0].toUpperCase() : (username ? username[0].toUpperCase() : 'M');
    
    const nameLabel = document.getElementById('dropdown-name');
    const emailLabel = document.getElementById('dropdown-email');
    const roleLabel = document.getElementById('dropdown-role');
    const branchLabel = document.getElementById('dropdown-branch');
    const desigLabel = document.getElementById('dropdown-designation');
    const phoneLabel = document.getElementById('dropdown-phone');
    const regnoLabel = document.getElementById('dropdown-regno');

    const avatar = document.getElementById('admin-avatar');
    const avatarLarge = document.getElementById('admin-avatar-large');
    const posUserName = document.getElementById('pos-user-name');

    if (nameLabel) nameLabel.innerText = name;
    if (emailLabel) emailLabel.innerText = username || email || 'mec@123';
    
    let displayRole = currentRole;
    if (currentRole === 'CEO_Admin') displayRole = 'CEO Admin';
    if (currentRole === 'SuperAdmin') displayRole = 'Super Admin';
    
    if (roleLabel) roleLabel.innerText = displayRole;
    if (branchLabel) branchLabel.innerText = branchName;
    if (desigLabel) desigLabel.innerText = designation;
    if (phoneLabel) phoneLabel.innerText = phone;
    if (regnoLabel) regnoLabel.innerText = regno;

    if (avatar) avatar.innerText = initial;
    if (avatarLarge) avatarLarge.innerText = initial;
    if (posUserName) posUserName.innerText = name;

    const storedPic = localStorage.getItem(`profile_pic_${email}`) || localStorage.getItem(`profile_pic_${username}`);
    if (storedPic) {
        if (avatar) { avatar.innerText = ''; avatar.style.backgroundImage = `url(${storedPic})`; avatar.style.backgroundSize = 'cover'; }
        if (avatarLarge) { avatarLarge.innerText = ''; avatarLarge.style.backgroundImage = `url(${storedPic})`; avatarLarge.style.backgroundSize = 'cover'; }
    }
}

window.handleProfileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const email = sessionStorage.getItem('userEmail');
    const reader = new FileReader();
    reader.onload = (e) => {
        const base64 = e.target.result;
        localStorage.setItem(`profile_pic_${email}`, base64);
        updateUserDisplay();
        window.showToast("ðŸ“¸ Profile picture updated!", "success");
    };
    reader.readAsDataURL(file);
};

// Expose globals
window.updateUserDisplay = updateUserDisplay;
window.displayUIVersion = displayUIVersion;
window.updateLoginBranding = updateLoginBranding;

// --- Automatic Diagnostic & Crash Telemetry Robot ---
let lastReportedErrorTime = 0;

export function reportSystemCrash(errorDetails) {
    try {
        const now = Date.now();
        // Throttle crash reporting to once per 10 seconds to avoid spam
        if (now - lastReportedErrorTime < 10000) return;
        lastReportedErrorTime = now;

        const storeId = sessionStorage.getItem('userStoreId') || localStorage.getItem('mecpos_last_store_id') || 'unknown';
        const clientVer = CLIENT_VERSION || '3.26.33';
        
        const payload = {
            storeId: storeId,
            version: clientVer,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            error: errorDetails
        };

        console.error("ðŸ¤– [Diagnostic Robot] Crash telemetry logged:", payload);
        
        // Push error safely to Firestore sys_crash_logs if db is available
        if (window.db) {
            import('firebase/firestore').then(({ collection, addDoc }) => {
                addDoc(collection(window.db, 'sys_crash_logs'), payload).catch(() => {});
            }).catch(() => {});
        }
    } catch(e) {}
}

window.addEventListener('error', (event) => {
    reportSystemCrash({
        type: 'JS_UNHANDLED_ERROR',
        message: event.message,
        source: event.filename,
        line: event.lineno,
        col: event.colno,
        stack: event.error ? event.error.stack : ''
    });
});

window.addEventListener('unhandledrejection', (event) => {
    reportSystemCrash({
        type: 'PROMISE_REJECTION',
        message: event.reason?.message || String(event.reason),
        stack: event.reason?.stack || ''
    });
});

window.reportSystemCrash = reportSystemCrash;


