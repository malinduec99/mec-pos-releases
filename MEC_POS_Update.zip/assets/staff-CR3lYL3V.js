import{q as b,c as y,d as f,w as S,g as k,l as P,j as D,o as v,u as N,b as H,a as R,s as B}from"./firebase-Bn3UcnFE.js";/* empty css              */window.staffLogin=async()=>{var i;const e=document.getElementById("staff-phone").value.trim(),n=document.getElementById("staff-pin").value.trim();if(!e||!n)return d("Please enter both Phone and PIN");const t=document.getElementById("section-login"),o=document.getElementById("login-loading"),a=document.getElementById("section-dashboard");t.style.display="none",o.style.display="block";try{const l=b(y(f,"employees"),S("phone","==",e)),m=await k(l);if(m.empty)throw new Error("Mobile number not registered.");const r=m.docs[0].data();if(r.docId=m.docs[0].id,n===r.regno||n===r.password)window.currentStaff=r,O(r),o.style.display="none",a.style.display="block",(i=document.getElementById("section-login"))==null||i.remove();else throw new Error("Invalid Security PIN.")}catch(l){d(l.message),o.style.display="none",t.style.display="block"}};function O(e){document.getElementById("disp-name").innerText=e.name,document.getElementById("disp-role").innerText=e.role,document.getElementById("disp-avatar").innerText=e.name.charAt(0).toUpperCase();const n=b(y(f,"payroll"),S("empId","==",e.docId),D("timestamp","desc"),P(1));v(n,i=>{if(!i.empty){const l=i.docs[0].data();document.getElementById("disp-salary").innerText=`LKR ${parseFloat(l.amount).toLocaleString()}`,window.lastPaySlip=l}});const t=new Date,o=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}`,a=b(y(f,"attendance"),S("empId","==",e.docId));v(a,i=>{const l=i.docs.map(r=>r.data()),m=l.filter(r=>r.date.startsWith(o)&&r.status==="Present");document.getElementById("disp-attendance").innerText=`${m.length} Days`,window.myAttendanceRecords=l}),q(e)}let T=!0;const x=new Set;function j(){try{const e=new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");e.volume=.8;const n=e.play();n!==void 0&&n.catch(()=>{try{const t=new(window.AudioContext||window.webkitAudioContext);t.state==="suspended"&&t.resume();const o=t.createOscillator(),a=t.createGain();o.type="sine",o.frequency.setValueAtTime(587.33,t.currentTime),o.frequency.setValueAtTime(880,t.currentTime+.1),a.gain.setValueAtTime(.25,t.currentTime),a.gain.exponentialRampToValueAtTime(.001,t.currentTime+.45),o.connect(a),a.connect(t.destination),o.start(),o.stop(t.currentTime+.5)}catch{}})}catch{}}function q(e){const n=e.storeId||"mec-book-shop",t=e.docId||e.regno||e.email,o=e.role||"Staff",a=e.branchId||"Global",i=b(y(f,"internal_mails"),S("storeId","==",n));v(i,l=>{let m=l.docs.map(c=>({docId:c.id,...c.data()}));m.sort((c,s)=>{var h,L;const g=(h=c.timestamp)!=null&&h.seconds?c.timestamp.seconds*1e3:new Date(c.timestamp||0).getTime()||0;return((L=s.timestamp)!=null&&L.seconds?s.timestamp.seconds*1e3:new Date(s.timestamp||0).getTime()||0)-g});const r=m.filter(c=>{const s=c.recipientId||"ALL";return!!(s==="ALL"||s===t||s===e.regno||s===e.email||s===e.phone||s.startsWith("BRANCH_")&&(s.replace("BRANCH_","")===a||s.replace("BRANCH_","")===e.branchName)||s.startsWith("ROLE_")&&s.replace("ROLE_","").toLowerCase()===o.toLowerCase()||s==="CASHIERS"&&o.toLowerCase().includes("cashier")||s==="INVENTORY"&&(o.toLowerCase().includes("inventory")||o.toLowerCase().includes("stock"))||s==="TECH"&&(o.toLowerCase().includes("tech")||o.toLowerCase().includes("repair"))||s==="HR_ONLY"&&(o.toLowerCase().includes("hr")||o.toLowerCase().includes("admin")||o.toLowerCase().includes("manager")))});if(T)r.forEach(c=>x.add(c.docId)),T=!1;else{const c=r.filter(s=>!x.has(s.docId));c.length>0&&c.forEach(s=>{x.add(s.docId),j(),d(`📩 New Notice from ${s.senderName||"HR"}: ${s.subject||"Staff Message"}`)})}window.myStaffMails=r;const w=r.filter(c=>!c.isRead).length,u=document.getElementById("staff-unread-badge");u&&(w>0?(u.innerText=w,u.style.display="inline-block"):u.style.display="none"),$(r)},l=>{console.warn("Staff mail snapshot error:",l)})}function $(e){const n=document.getElementById("staff-inbox-list");if(n){if(!e||e.length===0){n.innerHTML='<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>';return}n.innerHTML=e.map(t=>{const o=t.timestamp?new Date(t.timestamp.seconds*1e3).toLocaleString([],{dateStyle:"short",timeStyle:"short"}):"Just now",a=t.priority==="urgent",i=!!(t.attachment&&t.attachment.url),l=t.isRead?"":'<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>',m=a?'<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>':"";return`
            <div onclick="window.readStaffMailDetail('${t.docId}')" style="background: ${t.isRead?"rgba(255,255,255,0.03)":"rgba(56,189,248,0.08)"}; border: 1px solid ${t.isRead?"rgba(255,255,255,0.06)":"rgba(56,189,248,0.3)"}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${l}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${t.senderName||"HR Management"}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${o}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${t.subject||"No Subject"}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${i?'<span title="Has Attachment" style="font-size:0.8rem;">📎</span>':""}
                        ${m}
                    </div>
                </div>
            </div>
        `}).join("")}}window.openStaffInboxModal=()=>{document.getElementById("staff-inbox-modal").style.display="flex",window.myStaffMails&&$(window.myStaffMails)};window.readStaffMailDetail=async e=>{const n=(window.myStaffMails||[]).find(a=>a.docId===e);if(!n)return;if(!n.isRead)try{await N(H(f,"internal_mails",e),{isRead:!0}),n.isRead=!0}catch{}document.getElementById("staff-mail-view-subject").innerText=n.subject||"No Subject",document.getElementById("staff-mail-view-sender").innerText=`${n.senderName||"HR Management"} (${n.senderEmail||"System"})`,document.getElementById("staff-mail-view-date").innerText=n.timestamp?new Date(n.timestamp.seconds*1e3).toLocaleString():"Just now",document.getElementById("staff-mail-view-body").innerText=n.body||"";const t=document.getElementById("staff-mail-view-badge");t&&(n.priority==="urgent"?(t.innerText="🚨 Urgent Notice",t.style.background="rgba(239,68,68,0.2)",t.style.color="#ef4444"):n.priority==="confidential"?(t.innerText="🔒 Confidential",t.style.background="rgba(168,85,247,0.2)",t.style.color="#c084fc"):(t.innerText="✉️ Staff Notice",t.style.background="rgba(56,189,248,0.15)",t.style.color="#38bdf8"));const o=document.getElementById("staff-mail-view-attachment");if(o)if(n.attachment&&n.attachment.url){const a=n.attachment.type&&n.attachment.type.startsWith("image/");let i=`
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${n.attachment.name||"File"}</span>
                        <a href="${n.attachment.url}" download="${n.attachment.name||"download"}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;a&&(i+=`<img src="${n.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`),i+="</div>",o.innerHTML=i,o.style.display="block"}else o.innerHTML="",o.style.display="none";document.getElementById("staff-read-mail-modal").style.display="flex"};function d(e){const n=document.getElementById("toast");n.innerText=e,n.style.display="block",setTimeout(()=>n.style.display="none",3e3)}const G=(e,n)=>{const t=new Blob([e],{type:"text/plain"}),o=window.URL.createObjectURL(t),a=document.createElement("a");a.href=o,a.download=n,a.click(),window.URL.revokeObjectURL(o)};window.downloadMySlip=()=>{var t;if(!window.lastPaySlip)return d("No salary records found.");const e=window.lastPaySlip,n=`
------------------------------------------
        MEC BOOK SHOP - PAY SLIP       
------------------------------------------
Employee: ${window.currentStaff.name}
Role:     ${window.currentStaff.role}
ID:       ${window.currentStaff.regno||"-"}
------------------------------------------
Month:    ${e.month}
Amount:   LKR ${parseFloat(e.amount).toLocaleString()}
Note:     ${e.note||"Regular Salary"}
Date:     ${e.date||new Date(((t=e.timestamp)==null?void 0:t.seconds)*1e3).toLocaleDateString()}
------------------------------------------
Generated by MEC Staff Portal
    `;G(n,`payslip_${e.month}.txt`),d("📥 Payslip downloaded!")};window.viewMyAttendance=()=>{if(!window.myAttendanceRecords||window.myAttendanceRecords.length===0)return d("No attendance records found.");const e=window.currentStaff,n=[...window.myAttendanceRecords].sort((a,i)=>i.date.localeCompare(a.date)),t=`
        <html>
        <head>
            <title>Attendance Report - ${e.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${e.name}<br>
                    <strong>Role:</strong> ${e.role}<br>
                    <strong>Employee ID:</strong> ${e.regno||"-"}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${n.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Time</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${n.map(a=>`
                        <tr>
                            <td>${a.date}</td>
                            <td class="status-${(a.status||"").toLowerCase().replace(" ","")}">${a.status}</td>
                            <td>${a.time||"--:--"}</td>
                            <td>${a.note||"-"}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            <\/script>
        </body>
        </html>
    `,o=window.open("","_blank");o.document.write(t),o.document.close(),d("📅 Generating PDF Report...")};window.openLeaveModal=()=>{document.getElementById("leave-modal").style.display="flex",document.getElementById("leave-date").value=new Date().toISOString().split("T")[0]};window.submitLeaveRequest=async()=>{const e=document.getElementById("leave-date").value,n=document.getElementById("leave-type").value,t=document.getElementById("leave-reason").value.trim();if(!e||!t)return d("Please fill all fields.");try{await R(y(f,"leave_requests"),{empId:window.currentStaff.docId,empName:window.currentStaff.name,date:e,type:n,reason:t,status:"Pending",storeId:window.currentStaff.storeId||"mec-book-shop",timestamp:B()}),d("✅ Leave request submitted!"),document.getElementById("leave-modal").style.display="none",document.getElementById("leave-reason").value=""}catch(o){console.error(o),d("Error submitting request.")}};let p=null,I="environment",E=null,C=null;window.startAttendanceClock=()=>{if(!navigator.geolocation)return d("GPS Geolocation not supported on this device.");d("📍 Accessing GPS coordinates..."),navigator.geolocation.getCurrentPosition(e=>{E=e.coords.latitude,C=e.coords.longitude,document.getElementById("scanner-modal").style.display="flex",p||(p=new Html5Qrcode("scanner-reader")),A()},e=>{console.error("GPS Error:",e),d("❌ Unable to verify location. Enable GPS/Location Services.")},{enableHighAccuracy:!0,timeout:6e3})};const A=()=>{const e={fps:20,qrbox:(n,t)=>({width:Math.floor(n*.7),height:Math.floor(t*.7)})};p.start({facingMode:I},e,_).catch(n=>{console.error("Camera access error:",n),d("Cannot open camera. Check permissions.")})};window.toggleCamera=()=>{I=I==="environment"?"user":"environment",p&&p.isScanning&&p.stop().then(()=>A())};window.closeScanner=()=>{p&&p.isScanning?p.stop().then(()=>{document.getElementById("scanner-modal").style.display="none"}):document.getElementById("scanner-modal").style.display="none"};const _=async e=>{const n=e.trim();if(!n.startsWith("MEC-POS-ATTENDANCE-QR:")){d("⚠️ Invalid QR Code. Scan the Shop QR Code.");return}window.closeScanner(),d("🔄 Verifying physical presence...");const t=n.split(":");t[1];const o=parseFloat(t[2]),a=parseFloat(t[3]),i=6371e3,l=E*Math.PI/180,m=o*Math.PI/180,r=(o-E)*Math.PI/180,w=(a-C)*Math.PI/180,u=Math.sin(r/2)*Math.sin(r/2)+Math.cos(l)*Math.cos(m)*Math.sin(w/2)*Math.sin(w/2),c=2*Math.atan2(Math.sqrt(u),Math.sqrt(1-u)),s=i*c;if(s>100){d(`❌ Out of range: you must be within 100m. Current distance: ${s.toFixed(1)}m`);return}try{const g=new Date,M=g.toLocaleDateString("sv-SE"),h=g.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit"});await R(y(f,"attendance"),{empId:window.currentStaff.docId,empName:window.currentStaff.name,date:M,time:h,status:"Present",note:`GPS+QR Verified (Distance: ${s.toFixed(1)}m)`,storeId:window.currentStaff.storeId||"mec-book-shop",timestamp:B()}),d("✅ Attendance Marked successfully!")}catch(g){console.error(g),d("Error logging attendance to database.")}};
