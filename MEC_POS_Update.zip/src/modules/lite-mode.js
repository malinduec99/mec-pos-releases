(function() {
    // Check if MEC POS is running in low-performance (low-end) mode.
    // Low performance mode is determined by either:
    // 1. The custom environment option / command line argument in WebView2 --disable-gpu
    // 2. The presence of 'disable_gpu.txt' configured by the installer or Firestore.
    
    window.enableMecLiteMode = function(enable) {
        const checkbox = document.getElementById('set-low-end-mode');
        if (enable) {
            document.body.classList.add('mec-lite');
            localStorage.setItem('mec_lite_mode', 'true');
            if (checkbox) checkbox.checked = true;
            console.log("🍃 MEC Lite mode enabled (glassmorphism disabled, basic graphics applied)");
        } else {
            document.body.classList.remove('mec-lite');
            localStorage.setItem('mec_lite_mode', 'false');
            if (checkbox) checkbox.checked = false;
            console.log("✨ Premium MEC mode enabled (glassmorphism and animations active)");
        }
    };

    window.toggleLowEndMode = function(checked) {
        window.enableMecLiteMode(checked);
    };

    // Auto-apply stored preference or fallback to system performance cues
    const initLiteMode = () => {
        const storedLite = localStorage.getItem('mec_lite_mode');
        if (storedLite === 'true') {
            window.enableMecLiteMode(true);
        } else if (storedLite === 'false') {
            window.enableMecLiteMode(false);
        } else {
            // Auto-detect based on hardware: if RAM is low (navigator.deviceMemory < 8)
            if (navigator.deviceMemory && navigator.deviceMemory < 8) {
                window.enableMecLiteMode(true);
            }
        }
        
        // Sync setting checkbox state once DOM is ready
        setTimeout(() => {
            const checkbox = document.getElementById('set-low-end-mode');
            const storedVal = localStorage.getItem('mec_lite_mode');
            if (checkbox) {
                checkbox.checked = storedVal === 'true' || (storedVal === null && navigator.deviceMemory && navigator.deviceMemory < 8);
            }
        }, 1500);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLiteMode);
    } else {
        initLiteMode();
    }
})();

