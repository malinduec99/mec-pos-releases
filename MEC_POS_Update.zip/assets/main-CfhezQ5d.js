/* empty css              */import{G as xt}from"./index-D2360V5-.js";import{a as ce,c as E,d as k,s as X,o as $e,q as T,w as S,g as A,b as j,e as me,i as Pe,f as gt,h as kt,u as ft,j as St,l as It,k as Ct,m as Pt,n as rt}from"./firebase-CVcZ1MF3.js";window.uploadLogToCloud=async(e,t="error")=>{try{const a=window.currentStoreId||"unknown",i=window.HostPCName||navigator.userAgent||"WebBrowser";await ce(E(k,"systemLogs"),{message:e,level:t,storeId:a,pcName:i,timestamp:X()})}catch(a){console.error("Failed to upload log:",a)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function Bt(){try{const e=localStorage.getItem("mecThemeColors");if(e){const t=JSON.parse(e),a=document.documentElement;a.style.setProperty("--primary-blue",t.primary),a.style.setProperty("--accent-blue",t.accent),a.style.setProperty("--admin-bg",t.bg),a.style.setProperty("--glass-bg",t.glass),a.style.setProperty("--primary-color",t.primary),a.style.setProperty("--secondary-color",t.accent),a.style.setProperty("--deep-bg",t.bg),t.bg==="#0f172a"||t.bg==="#11011c"||t.bg==="#022c22"?(a.style.setProperty("--text-dark","#f8fafc"),a.style.setProperty("--text-muted","#94a3b8")):(a.style.setProperty("--text-dark","#0f172a"),a.style.setProperty("--text-muted","#64748b"))}}catch{}}Bt();function he(){const e=document.querySelector("header");if(e){const a=e.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(a)}px`)}const t=document.getElementById("product-grid-header");if(t&&e){const a=e.getBoundingClientRect().height,o=t.getBoundingClientRect().top<=Math.round(a)+2;t.classList.toggle("is-stuck",o)}}window.addEventListener("resize",he);window.addEventListener("scroll",he,{passive:!0});document.addEventListener("DOMContentLoaded",he);setTimeout(he,200);setTimeout(he,800);const bt=new URLSearchParams(window.location.search),se=window.location.pathname.split("/").filter(e=>e!=="");let qe=null;se[0]==="store"&&se[1]?qe=se[1]:se[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(se[0])&&(qe=se[0]);const Et=bt.get("store")||qe;window.currentStoreId=Et||null;window.currentStoreData=null;try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const Ce=E(k,"stores"),pe=window.location.hostname;async function $t(){let e=null;try{if(window.currentStoreId){const t=T(Ce,S("slug","==",window.currentStoreId)),a=await A(t);if(!a.empty)e={...a.docs[0].data(),docId:a.docs[0].id};else try{const i=j(k,"stores",window.currentStoreId),o=await gt(i);o.exists()&&(e={...o.data(),docId:o.id})}catch{}}else if(["mecbookshop.web.lk","mecbookshop.com.lk","mec-book-shop.web.app","localhost","127.0.0.1"].includes(pe)){window.currentStoreId="mec-book-shop";const a=T(Ce,S("slug","==","mec-book-shop")),i=await A(a);i.empty||(e={...i.docs[0].data(),docId:i.docs[0].id})}else if(pe==="mecpos.web.lk"||pe==="mec-pos-shop.web.app"||pe==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const a=pe.replace(/^www\./,""),i=T(Ce,S("domain","==",a)),o=await A(i);o.empty||(e={...o.docs[0].data(),docId:o.docs[0].id})}}catch(t){console.error("Store resolution query failed:",t)}if(e)window.currentStoreData=e,window.currentStoreId=e.slug||e.storeSlug||e.docId||"mec-book-shop",console.log("Resolved Store ID:",window.currentStoreId),it(),lt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{window.currentStoreId||(window.currentStoreId="mec-book-shop");try{const a=T(Ce,S("slug","==","mec-book-shop")),i=await A(a);i.empty||window.currentStoreId==="mec-book-shop"&&(window.currentStoreData=i.docs[0].data())}catch(a){console.error("Error loading fallback store data:",a)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),it(),lt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}$t();function it(){var b,u,f,g,w,h,B,v,P,I,$,L,z,M,O;let e=(b=window.currentStoreData)==null?void 0:b.name;e||(window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?e=window.currentStoreId.split("-").map(C=>C.charAt(0).toUpperCase()+C.slice(1)).join(" "):e="MEC Book Shop"),e==="MEC POS"&&(e="MEC Book Shop"),document.title=`${e} | Official Store`;const t=(f=(u=window.currentStoreData)==null?void 0:u.webDesign)==null?void 0:f.primary,a=(w=(g=window.currentStoreData)==null?void 0:g.webDesign)==null?void 0:w.accent;t&&document.documentElement.style.setProperty("--primary-color",t),a&&document.documentElement.style.setProperty("--secondary-color",a),document.querySelectorAll(".logo-text").forEach(C=>{C.innerText=e});const i=window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master";i?(document.querySelectorAll(".bookshop-brand-banner").forEach(C=>C.style.display="none"),document.querySelectorAll(".merchant-only").forEach(C=>C.style.display="")):(document.querySelectorAll(".bookshop-brand-banner").forEach(C=>C.style.display="block"),document.querySelectorAll(".merchant-only").forEach(C=>C.style.display="none"));const o=(h=window.currentStoreData)==null?void 0:h.logoUrl,s=o&&o.trim()!==""&&!o.includes("zenith_logo")&&!o.includes("/logo.png")?o:"/mec-logo.png";document.querySelectorAll(".logo-img, #pwa-install-banner img").forEach(C=>{C.src=s,C.style.display=i?"":C.classList.contains("merchant-only")?"none":""});const r=document.getElementById("hero");if(r){const C=(v=(B=window.currentStoreData)==null?void 0:B.webDesign)==null?void 0:v.bannerUrl,D=C&&C.length>10?C:window.currentStoreId==="mec-book-shop"?"/banner.png":null;if(D)r.innerHTML=`

        <div class="banner-container" id="banner-container" style="width: 100%;">

          <img id="main-banner" src="${D}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">

        </div>

      `;else{const G=((I=(P=window.currentStoreData)==null?void 0:P.webContent)==null?void 0:I.welcome)||`Welcome to ${e}`,ze=((L=($=window.currentStoreData)==null?void 0:$.webContent)==null?void 0:L.announce)||"Your premium destination for high-quality products and services.";r.innerHTML=`

        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">

          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${G}</h1>

          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${ze}</p>

          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>

        </div>

      `}}const c=document.getElementById("page-title");c&&(c.innerText=`${e} | Official Store`);const n=document.getElementById("footer-copy");n&&(n.innerText=`© 2026 ${e}. All rights reserved.`);const l=((z=window.currentStoreData)==null?void 0:z.webEpinics)||{},d=!!l.multiVendor,p=!!l.affiliate;(M=document.getElementById("nav-sell-with-us"))==null||M.remove(),(O=document.getElementById("nav-affiliate-program"))==null||O.remove();const m=document.getElementById("nav-menu");if(m){const C=document.getElementById("nav-auth-item");if(d){const D=document.createElement("li");D.id="nav-sell-with-us",D.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',C?m.insertBefore(D,C):m.appendChild(D)}if(p){const D=document.createElement("li");D.id="nav-affiliate-program",D.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',C?m.insertBefore(D,C):m.appendChild(D)}}document.documentElement.classList.remove("loading-merchant")}let ue;const oe=document.createElement("div");oe.id="pwa-install-banner";oe.innerHTML=`

    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">

        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">

        <div>

            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>

            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>

        </div>

        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>

    </div>

    <style>

        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }

    </style>

`;oe.style.display="none";document.body.appendChild(oe);window.addEventListener("beforeinstallprompt",e=>{e.preventDefault(),ue=e,oe.style.display="block"});oe.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){oe.style.display="none";return}if(ue){ue.prompt();const{outcome:t}=await ue.userChoice;t==="accepted"&&(oe.style.display="none"),ue=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const Q=document.getElementById("menu-toggle"),Z=document.getElementById("nav-menu"),H=document.getElementById("mobile-menu-overlay"),Le=()=>{Z==null||Z.classList.remove("active"),Q==null||Q.classList.remove("active"),H==null||H.classList.remove("active")};Q==null||Q.addEventListener("click",()=>{const e=Z==null?void 0:Z.classList.toggle("active");Q==null||Q.classList.toggle("active"),e?H==null||H.classList.add("active"):H==null||H.classList.remove("active")});const Re=document.getElementById("close-menu");Re==null||Re.addEventListener("click",Le);H==null||H.addEventListener("click",Le);Z==null||Z.querySelectorAll("a").forEach(e=>{e.addEventListener("click",Le)});function ve(e,t){var i;if(typeof e=="string"&&e.trim()!==""){const o=e.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const a=(i=window.currentStoreData)==null?void 0:i.logoUrl;return a&&a.trim()!==""&&!a.includes("zenith_logo.png")&&!a.includes("/logo.png")?a:"/mec-logo.png"}const Lt=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}],We=E(k,"products"),Tt=E(k,"orders"),At=E(k,"promotions"),Nt=E(k,"branches"),Dt=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let st=[];$e(Nt,e=>{st=e.docs.map(t=>({...t.data(),docId:t.id})),window.allStoreBranches=st,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function ge(){var i,o,s,r;const e=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master";let t=(window.allStoreBranches||[]).filter(c=>e||c.storeId===window.currentStoreId||!c.storeId);const a={docId:"main",name:(((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop")+" - Main Branch",location:((o=window.currentStoreData)==null?void 0:o.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",address:((s=window.currentStoreData)==null?void 0:s.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",city:"Horana",district:"Kalutara",phone:((r=window.currentStoreData)==null?void 0:r.phone)||"071 923 3388"};return t.length===0&&(t=[a]),t}window.getAllAvailableShops=ge;function yt(){const t=ge().map(i=>(i.location||i.city||"").trim()).filter(i=>i.length>0);return Array.from(new Set([...t,...Dt])).filter(Boolean).sort((i,o)=>i.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=yt;let _=[],xe=0,x=[],re="All",R=1,_e=12,le="recommended",Y="",Oe=null;document.getElementById("cart-count");window.webStoreBankAccounts={slot1:{docId:"ndb_default",bankName:"National Development Bank (NDB)",badge:"NDB",accountName:"MEC BOOK SHOP & COMMUNICATION",accountType:"Regular Current",bankCode:"7214",swiftCode:"NDBSLKLX",accountNo:"111000391437"},slot2:{docId:"boc_default",bankName:"Bank of Ceylon (BOC)",badge:"BOC",accountName:"WPM Shamesh",branch:"Horana Branch",bankCode:"",swiftCode:"",accountType:"Savings",accountNo:"0084334885"}};window.selectedWebStoreBankSlot="slot1";window.selectWebStoreBankSlot=e=>{window.selectedWebStoreBankSlot=e;const t=document.getElementById("web-bank-card-1"),a=document.getElementById("web-bank-card-2"),i=document.getElementById("web-slot-1-radio"),o=document.getElementById("web-slot-2-radio"),s=document.getElementById("web-bank-1-badge"),r=document.getElementById("web-bank-2-badge");e==="slot1"?(i&&(i.checked=!0),o&&(o.checked=!1),t&&(t.style.background="#f0fdf4",t.style.borderColor="#16a34a",t.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),a&&(a.style.background="#ffffff",a.style.borderColor="#cbd5e1",a.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),s&&(s.style.background="#16a34a",s.style.color="#ffffff",s.innerText="✓ Selected"),r&&(r.style.background="#f1f5f9",r.style.color="#64748b",r.innerText="Click to select")):(i&&(i.checked=!1),o&&(o.checked=!0),a&&(a.style.background="#f0fdf4",a.style.borderColor="#16a34a",a.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),t&&(t.style.background="#ffffff",t.style.borderColor="#cbd5e1",t.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),r&&(r.style.background="#16a34a",r.style.color="#ffffff",r.innerText="✓ Selected"),s&&(s.style.background="#f1f5f9",s.style.color="#64748b",s.innerText="Click to select"))};window.copyBankDetails=(e,t)=>{const a=document.getElementById(e);if(!a)return;const i=a.innerText.trim();navigator.clipboard.writeText(i),alert(`${t} Copied: ${i}`)};window.updateWebStoreBankCardsUI=()=>{var a,i;const e=(a=window.webStoreBankAccounts)==null?void 0:a.slot1,t=(i=window.webStoreBankAccounts)==null?void 0:i.slot2;if(e){const o=document.getElementById("web-bank-1-title"),s=document.getElementById("web-bank-1-accname"),r=document.getElementById("web-bank-1-accno"),c=document.getElementById("web-bank-1-acctype"),n=document.getElementById("web-bank-1-code"),l=document.getElementById("web-bank-1-swift");o&&e.bankName&&(o.innerText=`🏦 ${e.bankName}`),s&&e.accountName&&(s.innerText=e.accountName),r&&e.accountNo&&(r.innerText=e.accountNo),c&&e.accountType&&(c.innerText=e.accountType),n&&e.bankCode&&(n.innerText=e.bankCode),l&&e.swiftCode&&(l.innerText=e.swiftCode)}if(t){const o=document.getElementById("web-bank-2-title"),s=document.getElementById("web-bank-2-accname"),r=document.getElementById("web-bank-2-accno"),c=document.getElementById("web-bank-2-branch");o&&t.bankName&&(o.innerText=`🏦 ${t.bankName}`),s&&t.accountName&&(s.innerText=t.accountName),r&&t.accountNo&&(r.innerText=t.accountNo),c&&t.branch&&(c.innerText=t.branch)}};function zt(){try{const e=localStorage.getItem("mec_webstore_bank_config");if(e){const t=JSON.parse(e);t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data})}}catch{}try{$e(j(k,"config","webstore_bank_accounts"),e=>{if(e.exists()){const t=e.data();t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data}),window.updateWebStoreBankCardsUI()}},e=>console.warn("Web store banks config snapshot warning:",e))}catch(e){console.warn("Could not setup webstore banks listener:",e)}}zt();function lt(){let e=window.currentStoreId||"mec-book-shop";e==="master"&&(e="mec-book-shop");const t=E(k,"stores",e,"products");let a=T(t);$e(a,i=>{const o=i.docs.map(r=>({...r.data(),id:r.id,docId:r.id,sku:r.data().sku||r.id}));if((window.currentStoreId==="mec-book-shop"||window.currentStoreId==="O8ywuZTKSwdL4z77RQ9M"||window.currentStoreId==="master")&&!o.some(c=>c.name&&c.name.trim().toLowerCase()==="other")&&i.docs.length>0){console.log("Auto-creating 'Other' product for MEC Book Shop...");const c={name:"Other",sku:"SKU-OTHER-0000-GEN-P1C0",category:"Uncategorized",mode:"Shop",supplierId:"General",supplierName:"General",cost:0,price:1,wholesalePrice:1,loyaltyPrice:1,discount:0,stock:999999,wStock:0,totalStock:999999,timestamp:X(),salesToday:0,image:"",variants:[],payMethods:{cod:!0,bank:!0,shop:!0},storeId:window.currentStoreId};c.docId=c.sku,me(j(k,"products",c.sku),c).catch(n=>console.error("Error creating 'Other' product:",n))}_=o.filter(r=>{const n=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?r.storeId==="mec-book-shop"||r.storeId==="master"||!r.storeId:r.storeId===window.currentStoreId,l=r.mode==="Shop"||r.mode==="Warehouse"||r.mode===void 0,d=r.status!=="pending";return n&&l&&d}),_.sort((r,c)=>{var n,l;return(((n=c.timestamp)==null?void 0:n.seconds)||0)-(((l=r.timestamp)==null?void 0:l.seconds)||0)}),_.length===0&&window.currentStoreId==="master"&&Lt.forEach(async r=>{await ce(We,r)}),U(),Te()})}var ut;(ut=document.getElementById("product-sort"))==null||ut.addEventListener("change",e=>{le=e.target.value,R=1,U()});const Mt=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.addEventListener("input",t=>{Y=t.target.value.toLowerCase(),window.searchQuery=Y,document.querySelectorAll("#store-search, .store-search-input").forEach(a=>{a!==t.target&&(a.value=t.target.value)}),R=1,U()})})};Mt();window.renderProducts=U;window.clearSearch=()=>{Y="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.value=""}),R=1,U()};function je(){localStorage.setItem("mec_cart",JSON.stringify(x))}function Rt(){const e=localStorage.getItem("mec_cart");e&&(x=JSON.parse(e),xe=x.reduce((t,a)=>t+(a.quantity||1),0),Ne())}const fe=document.createElement("div");fe.id="cart-modal";document.body.appendChild(fe);const be=document.createElement("div");be.id="cart-overlay";document.body.appendChild(be);window.toggleCart=e=>{e?(fe.classList.add("active"),be.classList.add("active"),De(),document.body.style.overflow="hidden"):(fe.classList.remove("active"),be.classList.remove("active"),document.body.style.overflow="")};const ke=window.toggleCart;be.onclick=()=>ke(!1);const _t=document.querySelectorAll('a[href="#cart"]');_t.forEach(e=>{e.onclick=t=>{t.preventDefault(),Le(),ke(!0)}});const ct=document.getElementById("shop-now-btn");ct&&ct.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const wt={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function Ot(){return["All",...new Set(_.map(t=>t.category))]}function Te(){const e=Ot(),t=document.getElementById("sidebar-category-list"),a=document.getElementById("mobile-category-bar");t&&(t.innerHTML=e.map(r=>`

      <li class="sidebar-cat-item ${r===re?"active":""}" data-category="${r}">

        <div class="cat-icon-text">

          <span class="cat-icon">${wt[r]||"📁"}</span>

          <span>${r}</span>

        </div>

        <span class="arrow">›</span>

      </li>

    `).join("")),a&&(a.innerHTML=e.map(r=>`

      <button class="mobile-cat-btn ${r===re?"active":""}" data-category="${r}">

        ${r}

      </button>

    `).join(""));const i=r=>{var n;re=r;const c=document.getElementById("featured-title");c&&(c.innerText=r==="All"?"Featured Collection":`${r} Collection`),U(),Te(),ee(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(r=>{r.addEventListener("click",c=>{c.stopPropagation(),i(c.currentTarget.dataset.category)}),r.addEventListener("mouseenter",c=>{const n=c.currentTarget.dataset.category;n!=="All"?qt(n,c.currentTarget):ee()})}),document.querySelectorAll(".mobile-cat-btn").forEach(r=>{r.addEventListener("click",c=>i(c.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),s=document.getElementById("nav-category-btn");s&&o&&(s.onclick=r=>{r.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),ee()})}document.addEventListener("click",e=>{const t=document.querySelector(".category-menu-wrapper");t&&!t.contains(e.target)&&(t.classList.remove("active"),typeof ee=="function"&&ee())});const W=document.getElementById("mega-menu");let Ae;function qt(e,t){if(!W)return;clearTimeout(Ae),document.querySelectorAll(".sidebar-cat-item").forEach(n=>n.classList.remove("active")),t==null||t.classList.add("active");const a=(_||[]).filter(n=>n.category===e),i={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`

      <div style="margin-bottom: 1.1rem;">

        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>

        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">

          <span>${wt[e]||"📁"}</span>

          <span>${e}</span>

        </div>

        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${a.length} Items Available</div>

      </div>

      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">

        <span>View All</span>

        <span>→</span>

      </button>

      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>

      <div style="display: flex; flex-direction: column; gap: 4px;">

        ${i.map(n=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${n}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${n}</a>`).join("")}

      </div>

    `);const s=document.getElementById("mega-products-heading");s&&(s.innerText=`${e} Products (${a.length})`);const r=document.getElementById("mega-products-list");r&&(r.innerHTML=a.length>0?a.map(n=>`

          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${n.docId}')">

            <img src="${ve(n.image,n.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">

            <div class="mega-prod-info">

              <h5 title="${n.name}">${n.name}</h5>

              <div class="price">LKR ${Number(n.price||0).toFixed(2)}</div>

            </div>

          </a>

        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),W.style.top="calc(100% + 8px)",W.style.left="248px",W.classList.add("active");const c=W.getBoundingClientRect();if(c.right>window.innerWidth-16){const n=c.right-(window.innerWidth-16);W.style.left=`${Math.max(0,248-n)}px`}}function ee(){Ae=setTimeout(()=>{W==null||W.classList.remove("active")},400)}W==null||W.addEventListener("mouseenter",()=>clearTimeout(Ae));var mt;(mt=document.getElementById("sidebar-category-list"))==null||mt.addEventListener("mouseenter",()=>clearTimeout(Ae));window.filterByCategoryAndScroll=e=>{var a;re=e;const t=document.getElementById("featured-title");t&&(t.innerText=e==="All"?"Featured Collection":`${e} Collection`),U(),Te(),ee(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,t)=>{var i;re=t,U(),Te();const a=document.getElementById("featured-title");a&&(a.innerText=`${e} in ${t}`),(i=document.getElementById("shop-section"))==null||i.scrollIntoView({behavior:"smooth"}),ee()};window.scrollToProduct=e=>{const t=document.getElementById(`product-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"center"}),t.classList.add("highlight-pulse"),setTimeout(()=>t.classList.remove("highlight-pulse"),3e3),ee())};function de(e,t=null,a=null){var p;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const i=(a||((p=window.currentUserProfile)==null?void 0:p.customerType)||"retail").toLowerCase();let o=0,s=0,r=0;t?(o=Number(t.price),(isNaN(o)||o<=0)&&(o=Number(e.price)||0),s=Number(t.wholesalePrice),(isNaN(s)||s<=0)&&(s=Number(e.wholesalePrice)||0),r=Number(t.loyaltyPrice),(isNaN(r)||r<=0)&&(r=Number(e.loyaltyPrice)||0)):(o=Number(e.price)||0,s=Number(e.wholesalePrice)||0,r=Number(e.loyaltyPrice)||0),isNaN(o)&&(o=0);let c=o,n=!1;i==="wholesale"&&s>0?(c=s,n=s!==o):i==="loyalty"&&r>0&&(c=r,n=r!==o);const l=Number(e.discount)||0,d=c*(1-(l>0?l/100:0));return{retailPrice:isNaN(o)?0:o,effectivePrice:isNaN(c)?0:c,discountedPrice:isNaN(d)?0:d,isSpecial:n,userType:i}}window.getCustomerEffectivePrice=de;function ye(e,t=null){return Ve(e,t,"web")}function Ve(e,t=null,a="web"){if(!e)return 0;if(a==="ShopPay"||a==="shop"||a==="Shop"){if(t){const s=parseFloat(t.stock)||0;if(s>0)return s}const o=parseFloat(e.stock||0);return o>0?o:0}else{if(t){const n=parseFloat(t.stock)||0,l=parseFloat(t.wStock)||0,d=n+l;if(d>0)return d}if(e.variants&&e.variants.length>0){const n=e.variants.reduce((l,d)=>l+(parseFloat(d.stock)||0)+(parseFloat(d.wStock)||0),0);if(n>0)return n}const o=parseFloat(e.stock||0),s=parseFloat(e.wStock||0),r=parseFloat(e.totalStock||0),c=o+s;return c>0?c:r>0?r:0}}function Ge(e,t="",a=0){if(!e||!Array.isArray(e)||e.length===0)return[];const i=new Map;return e.forEach((o,s)=>{const r=Number(o.price||o.sellingPrice||a||0),c=(o.size||"").trim(),n=(o.color||"").trim();let l=(o.name||o.variantLabel||"").trim();const p=!l||l.toLowerCase()==="default"||l.toLowerCase()==="existing stock"||l.toLowerCase()==="option"||l.toLowerCase()===(t||"").trim().toLowerCase()?"":l,m=`${r}_${c.toLowerCase()}_${n.toLowerCase()}_${p.toLowerCase()}`,b=parseFloat(o.stock)||0,u=parseFloat(o.wStock)||0;if(!i.has(m))i.set(m,{...o,price:r,sellingPrice:r,size:c,color:n,variantLabel:p,name:p||(c||n?`${c} ${n}`.trim():`MRP LKR ${r.toLocaleString()}`),stock:b,wStock:u,totalStock:b+u,batchSources:[{sourceDocId:o.sourceDocId,origIndex:s,stock:b,wStock:u}]});else{const f=i.get(m);f.stock+=b,f.wStock+=u,f.totalStock+=b+u,f.batchSources.push({sourceDocId:o.sourceDocId,origIndex:s,stock:b,wStock:u})}}),Array.from(i.values())}window.consolidateVariants=Ge;const we=document.getElementById("product-detail-modal"),Je=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const t=(window.groupedProducts||[]).find(u=>u.docId===e)||_.find(u=>u.docId===e);if(!t)return;t.variants=Ge(t.variants,t.name,t.price);const a=Number(t.discount)||0,i=t.variants&&t.variants.length>1,o=t.variants&&t.variants.length>0?t.variants[0]:null;let s=t.image;o&&(o.image?s=o.image:o.images&&o.images.length>0&&(s=o.images[0]));const r=de(t,o),c=r.userType,n=r.isSpecial,l=r.retailPrice,d=r.discountedPrice,p=ye(t,o),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let b="";if(i){const u=[...new Set(t.variants.map(g=>g.size).filter(Boolean))],f=[...new Set(t.variants.map(g=>g.color).filter(Boolean))];if(u.length>0||f.length>0){let g="";f.length>0&&(g=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Color</span>

              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||f[0]}</span>

            </div>

            <div class="variant-pill-container" id="color-pill-group">

              ${f.map(h=>{const B=m[h.toLowerCase()]||"#64748b";return`

                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||f[0])===h?"active":""}" 

                    style="background-color: ${B};" 

                    title="${h}" data-color="${h}"

                    onclick="window.selectVariantByAttribute('${t.docId}', 'color', '${h}')">

                  </button>

                `}).join("")}

            </div>

          </div>

        `);let w="";u.length>0&&(w=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Style / Size</span>

              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>

            </div>

            <div class="variant-pill-container" id="size-pill-group">

              ${u.map(h=>`

                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===h?"active":""}" 

                    data-size="${h}"

                    onclick="window.selectVariantByAttribute('${t.docId}', 'size', '${h}')">

                    ${h}

                  </button>

                `).join("")}

            </div>

          </div>

        `),b=`${g}${w}`}else b=`

        <div class="variant-selector-group">

          <div class="variant-selector-label">

            <span>Choose Option / MRP</span>

          </div>

          <div class="variant-pill-container">

            ${t.variants.map((g,w)=>{const h=ye(t,g);return`

              <div class="variant-mrp-card ${w===0?"active":""}" id="v-card-${w}"

                   onclick="window.updateDetailDisplay('${t.docId}', ${w})">

                <div style="flex:1;">

                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${g.variantLabel&&g.variantLabel.toLowerCase()!==t.name.toLowerCase()&&g.variantLabel.toLowerCase()!=="default"?g.variantLabel:g.size||g.color?`${g.size||""} ${g.color||""}`.trim():`MRP LKR ${(g.price||t.price||0).toLocaleString()}`}</div>

                  <div style="font-size: 0.75rem; color: #64748b;">${h>0?`In Stock (${h})`:"Out of stock"}</div>

                </div>

                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">

                  LKR ${(g.price||t.price||0).toLocaleString()}

                </div>

              </div>

            `}).join("")}

          </div>

        </div>

      `}we.innerHTML=`

        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>

        <div class="detail-content">

            <div class="detail-image-sec">

                <img src="${ve(s,t.name)}" id="detail-main-img" 

                    alt="${t.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">

            </div>



            <div class="detail-info-sec">

                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${t.category}</div>

                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${t.name}</h2>

                ${n?`<div style="font-size: 0.8rem; color: ${c==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${c.toUpperCase()} APPLIED</div>`:""}

                

                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">

                    ${a>0||n?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}

                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${d.toFixed(2)}</span>

                </div>

                

                ${b}



                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">

                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}

                </div>

                

                <div class="detail-actions-sec">

                    <button class="add-to-cart-btn detail-add-btn" 

                            onclick="window.handleDetailAddToCart('${t.docId}')">

                        🛒 Add to Cart

                    </button>

                </div>

            </div>

        </div>

    `,window.activeDetailVariantIndex=0,we.classList.add("active"),Je.classList.add("active"),document.body.style.overflow="hidden",ee(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,t,a)=>{const i=(window.groupedProducts||[]).find(r=>r.docId===e)||_.find(r=>r.docId===e);if(!i||!i.variants)return;const o=window.activeDetailVariantIndex||0;i.variants[o]||i.variants[0];let s=i.variants.findIndex(r=>t==="color"?r.color===a:t==="size"?r.size===a:!1);if(s===-1&&(s=0),t==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(c=>{c.classList.toggle("active",c.dataset.color===a)});const r=document.getElementById("detail-selected-color");r&&(r.innerText=a)}if(t==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(c=>{c.classList.toggle("active",c.dataset.size===a)});const r=document.getElementById("detail-selected-size");r&&(r.innerText=a)}window.updateDetailDisplay(e,s)};window.closeProductDetail=()=>{we.classList.remove("active"),Je.classList.remove("active"),document.body.style.overflow=""};Je.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,t)=>{window.activeDetailVariantIndex=Number(t);const a=(window.groupedProducts||[]).find(d=>d.docId===e)||_.find(d=>d.docId===e);if(!a)return;const i=a.variants&&a.variants.length>0?a.variants[t]:null,o=document.getElementById("detail-main-img"),s=document.getElementById("detail-stock"),r=we.querySelector(".detail-original-price"),c=we.querySelector(".detail-final-price");if(o){let d=a.image;i&&(i.image?d=i.image:i.images&&i.images.length>0&&(d=i.images[0])),o.src=ve(d,a.name)}document.querySelectorAll(".variant-mrp-card").forEach((d,p)=>{d.classList.toggle("active",p===Number(t))}),Number(a.discount);const n=de(a,i);r&&(r.innerText=`LKR ${n.retailPrice.toFixed(2)}`),c&&(c.innerText=`LKR ${n.discountedPrice.toFixed(2)}`);const l=ye(a,i);if(s){const d=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";s.innerHTML=d,s.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const t=(window.groupedProducts||[]).find(p=>p.docId===e)||_.find(p=>p.docId===e);if(!t)return;const a=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let i="Default",o=null;t.variants&&t.variants.length>0&&(o=t.variants[a]||t.variants[0],i=o.name||o.variantLabel||o.color||o.size||"Default");const r=de(t,o).effectivePrice,c=o&&o.cost!==void 0?Number(o.cost):Number(t.cost)||0,n=ye(t,o),l=x.findIndex(p=>p.docId===t.docId&&p.selectedVariant===i),d=l!==-1?(x[l].quantity||1)+1:1;if(t.mode!=="Service"&&t.mode!=="Technical"&&d>n){alert(`Sorry, out of stock! Only ${n} available.`);return}Ut(t,i,r,c),window.closeProductDetail(),ke(!0)};function Ut(e,t,a,i){const o=x.findIndex(s=>s.docId===e.docId&&s.selectedVariant===t);o!==-1?x[o].quantity=(x[o].quantity||1)+1:x.push({...e,selectedVariant:t,price:a,cost:i,quantity:1}),xe=x.reduce((s,r)=>s+(r.quantity||1),0),je(),Ne()}window.changeCartQty=(e,t,a)=>{var o;const i=x.findIndex(s=>s.docId===e&&s.selectedVariant===t);if(i!==-1){if(a>0){const s=_.find(r=>r.docId===e);if(s&&s.mode!=="Service"&&s.mode!=="Technical"){let r=null;t!=="Default"&&s.variants&&(r=s.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===t));const c=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",n=Ve(s,r,c);if((x[i].quantity||1)+a>n){alert(c==="ShopPay"?`Sorry! Only ${n} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${n} available.`);return}}}x[i].quantity=(x[i].quantity||1)+a,x[i].quantity<=0&&x.splice(i,1),xe=x.reduce((s,r)=>s+(r.quantity||1),0),je(),Ne(),De()}};function Ne(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(t=>{t&&(t.innerText=xe,t.classList.add("bump"),setTimeout(()=>t.classList.remove("bump"),300))})}function Qe(e,t,a){if(!e||!t||t.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let i=t;if(e.targetType==="specific_products"){const r=(e.selectedProducts||[]).map(c=>(c||"").trim().toLowerCase());if(i=t.filter(c=>{const n=(c.name||"").trim().toLowerCase(),l=(c.docId||"").trim().toLowerCase();return r.includes(n)||r.includes(l)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const r=(e.selectedCategories||[]).map(c=>(c||"").trim().toLowerCase());if(i=t.filter(c=>{const n=(c.category||"").trim().toLowerCase();return r.includes(n)}),i.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const o=i.reduce((r,c)=>{const n=c.discount||0,l=c.price*(1-n/100),d=c.quantity||1;return r+l*d},0);let s=0;return e.type==="Percentage"?s=o*(Number(e.value)/100):s=Math.min(o,Number(e.value)||0),{discountAmount:s,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function De(){var i;const e=x.reduce((o,s)=>{const r=s.discount||0,c=s.price*(1-r/100),n=s.quantity||1;return o+c*n},0);let t=0;if(window.appliedCoupon){const o=Qe(window.appliedCoupon,x);o.isValidForCart?t=o.discountAmount:window.appliedCoupon=null}const a=Math.max(0,e-t);fe.innerHTML=`

        <div class="cart-header">

            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>

            <button class="close-cart" id="close-cart-btn">&times;</button>

        </div>

        

        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">

            <div class="cart-body">

                ${x.length===0?`

                    <div class="cart-empty-state">

                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>

                        <p>Your cart is empty</p>

                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>

                    </div>

                `:x.map(o=>{const s=o.discount||0,r=o.price*(1-s/100),c=o.quantity||1,n=r*c;return`

                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">

                            <div class="cart-item-info" style="flex: 1;">

                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>

                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>

                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">

                                    ${s>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}

                                    LKR ${r.toFixed(2)} ${c>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${c} = LKR ${n.toFixed(2)}</span>`:""}

                                </div>

                            </div>

                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 

                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">

                                    -

                                </button>

                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${c}</span>

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 

                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">

                                    +

                                </button>

                            </div>

                        </div>

                    `}).join("")}

            </div>



            ${x.length>0?`

                <div class="cart-footer">

                    <div class="delivery-info-banner">

                        <span>🚚</span>

                        <span>COD LKR 400 | Bank Transfer LKR 250</span>

                    </div>



                    <!-- Promo / Coupon Code Section -->

                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">

                        <div style="display: flex; gap: 0.5rem;">

                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>

                            ${window.appliedCoupon?`

                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>

                            `:`

                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>

                            `}

                        </div>

                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">

                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}

                        </div>

                    </div>

                    

                    ${window.appliedCoupon?`

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">

                            <span>Subtotal</span>

                            <span>LKR ${e.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">

                            <span>Coupon Discount (${window.appliedCoupon.code})</span>

                            <span>- LKR ${t.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">

                            <span>Total Payable</span>

                            <span>LKR ${a.toFixed(2)}</span>

                        </div>

                    `:`

                        <div class="cart-subtotal">

                            <span>Total Payable</span>

                            <span>LKR ${e.toFixed(2)}</span>

                        </div>

                    `}



                    <div class="checkout-form-section">

                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>

                        <div class="input-group">

                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">

                        </div>

                        <div class="input-group">

                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">

                        </div>

                        <div class="input-group" id="delivery-address-group">

                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">

                        </div>

                        <div class="input-group" id="delivery-city-group">

                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">

                        </div>



                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>

                        <div class="payment-method-selector">

                            ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">

                                <span class="method-label">COD</span>

                            </label>

                            `:""}

                            ${x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="Bank" ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">

                                <span class="method-label">Transfer</span>

                            </label>

                            `:""}

                            ${x.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="ShopPay" ${!x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">

                                <span class="method-label">Shop Cash</span>

                            </label>

                            `:""}

                        </div>

                        

                        <!-- Bank Transfer Info Box -->

                        <div id="bank-details-box" style="display: none;">

                            <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.75rem;">

                                <p style="color: #065f46; font-weight: 800; margin: 0; font-size: 0.82rem; display: flex; align-items: center; gap: 6px;">

                                    <span>✨</span> Lower delivery charge (LKR 250)

                                </p>

                                <p style="color: #047857; margin: 3px 0 0; font-size: 0.75rem; font-weight: 600;">

                                    👇 Select the Bank Account you transferred to (ඔබ මුදල් තැන්පත් කළ ගිණුම තෝරන්න):

                                </p>

                            </div>



                            <!-- Account 1: Slot 1 (e.g. NDB) -->

                            <div id="web-bank-card-1" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot1')" style="background: #f0fdf4 !important; color: #0f172a !important; border: 2px solid #16a34a !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.15); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-1-radio" value="slot1" checked style="accent-color: #16a34a; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-1-title" style="font-weight: 900; color: #b91c1c; font-size: 0.95rem;">🏦 National Development Bank (NDB)</span>

                                    </div>

                                    <span id="web-bank-1-badge" style="font-size: 0.72rem; background: #16a34a; color: #ffffff; padding: 3px 8px; border-radius: 6px; font-weight: 800;">✓ Selected</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-1-accname" style="color: #0f172a; font-weight: 700;">MEC BOOK SHOP & COMMUNICATION</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div id="web-bank-1-type-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    Account Type: <span id="web-bank-1-acctype" style="color: #0f172a; font-weight: 700;">Regular Current</span>

                                </div>

                                <div id="web-bank-1-codes-row" style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Bank Code: <strong id="web-bank-1-code" style="color: #334155;">7214</strong></span>

                                    <span>Swift Code: <strong id="web-bank-1-swift" style="color: #334155;">NDBSLKLX</strong></span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; border: 1.5px dashed #16a34a; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-1-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accno', 'Account Number');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <!-- Account 2: Slot 2 (e.g. BOC) -->

                            <div id="web-bank-card-2" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot2')" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1 !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-2-radio" value="slot2" style="accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-2-title" style="font-weight: 900; color: #0284c7; font-size: 0.95rem;">🏦 Bank of Ceylon (BOC)</span>

                                    </div>

                                    <span id="web-bank-2-badge" style="font-size: 0.72rem; background: #f1f5f9; color: #64748b; padding: 3px 8px; border-radius: 6px; font-weight: 700;">Click to select</span>

                                </div>

                                <div id="web-bank-2-branch-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600; padding-left: 26px;">

                                    Branch: <span id="web-bank-2-branch" style="color: #0f172a; font-weight: 700;">Horana Branch</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-2-accname" style="color: #0f172a; font-weight: 700;">WPM Shamesh</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-2-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accno', 'Account Number');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <div style="margin-top: 1rem;">

                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>

                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">

                            </div>

                        </div>



                        <!-- Shop Pickup / Branch Selection Box -->

                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">

                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">

                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch

                            </p>



                            <!-- City / Town Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>

                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>

                                  ${yt().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}

                                </select>

                            </div>



                            <!-- Shop / Branch List Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>

                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <!-- Injected by populatePickupShops -->

                                </select>

                            </div>



                            <!-- Selected Shop Info Card -->

                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">

                            </div>

                        </div>

                    </div>



                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">

                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">

                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">

                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 

                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 

                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.

                        </label>

                    </div>



                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">

                        Confirm Order

                    </button>

                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->

                </div>

            `:""}

        </div>

    `,document.getElementById("close-cart-btn").onclick=()=>ke(!1),(i=document.getElementById("checkout-btn"))==null||i.addEventListener("click",Ft),setTimeout(()=>{typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI()},50),window.toggleBankDetails=o=>{const s=document.getElementById("bank-details-box");s&&(s.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const s=document.getElementById("bank-details-box"),r=document.getElementById("shop-pickup-box"),c=document.getElementById("delivery-address-group"),n=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(s&&(s.style.display="block"),typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI(),r&&(r.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(s&&(s.style.display="none"),r&&(r.style.display="block",window.populatePickupShops()),c&&(c.style.display="none"),n&&(n.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(s&&(s.style.display="none"),r&&(r.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var d,p,m,b;const o=document.getElementById("pickup-town-select"),s=document.getElementById("pickup-shop-select"),r=document.getElementById("selected-shop-info-card");if(!s)return;const c=o?o.value:"All",n=ge();let l=n;c&&c!=="All"&&(l=n.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(c.toLowerCase()))),l.length===0?(s.innerHTML=n.map((u,f)=>`

        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),r&&(r.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${c}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((d=n[0])==null?void 0:d.docId)||((p=n[0])==null?void 0:p.id)||0)):(s.innerHTML=l.map((u,f)=>`

        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((b=l[0])==null?void 0:b.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const s=document.getElementById("selected-shop-info-card");if(!s)return;const r=ge(),c=r.find(n=>n.docId===o||n.id===o)||r[0];c&&(s.innerHTML=`

        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${c.name||c.shopName||"Main Branch"}</div>

        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${c.location||c.address||"In-store Pickup Counter"}</div>

        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${c.phone?`Contact: <b>${c.phone}</b>`:"Store Pickup Active"}</div>

        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">

          <span>✓</span> Collect & Pay Cash at this shop counter

        </div>

      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),t=document.getElementById("promo-message");if(!e)return;const a=e.value.trim().toUpperCase();if(!a){t&&(t.innerText="❌ Please enter a promo code.",t.style.color="#ef4444");return}t&&(t.innerText="⏳ Validating coupon...",t.style.color="var(--primary-color)");try{const i=T(At,S("code","==",a),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty){t&&(t.innerText="❌ Invalid or expired coupon code.",t.style.color="#ef4444");return}const s=o.docs[0],r={...s.data(),id:s.id},c=new Date().toISOString().split("T")[0];if(r.expiryDate<c){t&&(t.innerText="❌ This coupon has expired.",t.style.color="#ef4444");return}if(r.status!=="Active"){t&&(t.innerText="❌ This coupon is inactive.",t.style.color="#ef4444");return}const n=x.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=Qe(r,x,n);if(!l.isValidForCart){t&&(t.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,t.style.color="#ef4444");return}window.appliedCoupon=r,De();const d=document.getElementById("promo-message");if(d){const p=r.targetType==="specific_products"?" (Selected Items)":r.targetType==="specific_categories"?" (Selected Categories)":"";d.innerText=`✅ Coupon applied: ${r.type==="Percentage"?`${r.value}% OFF`:`LKR ${r.value} OFF`}${p}`,d.style.color="#10b981"}}catch(i){console.error("Error validating coupon:",i),t&&(t.innerText="❌ Error validating coupon code.",t.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,De()};async function Ft(){var m,b,u,f,g,w,h,B;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!"),window.location.href="/login.html";return}if(x.length===0)return;const t=document.getElementById("terms-agree");if(t&&!t.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const a=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),i=(b=document.getElementById("delivery-phone-2"))==null?void 0:b.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),s=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),r=((g=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:g.value)||"COD",c=(w=document.getElementById("deposit-slip"))==null?void 0:w.files[0],n=r==="ShopPay";let l=null,d="All";if(n){d=((h=document.getElementById("pickup-town-select"))==null?void 0:h.value)||"All";const v=(B=document.getElementById("pickup-shop-select"))==null?void 0:B.value,P=ge();if(l=P.find(I=>I.docId===v||I.id===v)||P[0],!v&&(!P||P.length===0)){alert("Please select a pickup shop / branch!");return}}if(!a||!n&&(!o||!s)){alert(n?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",a),localStorage.setItem("mec_saved_phone2",i),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",s),r==="Bank"&&!c){alert("Please upload your bank deposit slip!");return}for(const v of x){const P=_.find(I=>I.docId===v.docId)||(window.groupedProducts||[]).find(I=>I.docId===v.docId);if(P&&P.mode!=="Service"&&P.mode!=="Technical"){let I=null;v.selectedVariant&&v.selectedVariant!=="Default"&&P.variants&&(I=P.variants.find(L=>(L.name||L.variantLabel||L.color||L.size||"Variant")===v.selectedVariant));const $=Ve(P,I,r);if((v.quantity||1)>$){alert(r==="ShopPay"?`Sorry! "${v.name}" only has ${$} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${v.name}" only has ${$} available in stock.`);return}}}const p=async(v=null)=>{var P,I;try{const $=x.reduce((y,q)=>y+q.price*(1-(q.discount||0)/100)*(q.quantity||1),0);let L=0,z="";if(window.appliedCoupon){z=window.appliedCoupon.code;const y=Qe(window.appliedCoupon,x,$);y.isValidForCart&&(L=y.discountAmount)}const M=Math.max(0,$-L),O=sessionStorage.getItem("mec_ref_code");let C="",D=0;if(O)try{const y=T(E(k,"affiliates"),S("code","==",O),S("storeId","==",window.currentStoreId));(await A(y)).empty||(C=O,D=Number((M*.05).toFixed(2)))}catch(y){console.error("Error verifying affiliate referral code at checkout:",y)}const G=window.currentStoreId||"mec-book-shop",ze=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),Ye=e&&(e.name||e.email)?e.name||e.email:a||"Guest Customer",Xe=window.selectedWebStoreBankSlot||"slot1",N=window.webStoreBankAccounts&&window.webStoreBankAccounts[Xe]||((P=window.webStoreBankAccounts)==null?void 0:P.slot1),ne={orderId:"ORD-"+Date.now(),userId:ze,userName:Ye,userEmail:e&&e.email?e.email:"",phone:a||"",phone2:i||"",branchId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:n?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:n?d:"",pickupShopPhone:n&&(l==null?void 0:l.phone)||"",pickupShopAddress:n&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:n?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:n?d!=="All"?d:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":s||"",items:x.map(y=>({id:y.id||y.docId||"",docId:y.docId||y.id||"",name:y.name||"",price:Number(y.price)||0,cost:Number(y.cost)||0,quantity:Number(y.quantity)||1,discount:Number(y.discount)||0,finalPrice:Number(y.price)*(1-(Number(y.discount)||0)/100)})),subtotal:Number($)||0,discount:Number(L)||0,couponCode:z||"",total:Number(M)||0,status:"Pending",customerType:(((I=window.currentUserProfile)==null?void 0:I.customerType)||"retail").toLowerCase(),paymentMethod:r||"COD",targetBankSlot:r==="Bank"?Xe:null,targetBankAccountId:r==="Bank"&&(N==null?void 0:N.docId)||null,targetBankName:r==="Bank"?(N==null?void 0:N.bankName)||"Bank":null,targetAccountNo:r==="Bank"?(N==null?void 0:N.accountNo)||"":null,targetAccountTitle:r==="Bank"?(N==null?void 0:N.accountName)||"":null,bankCredited:r==="Bank",slipImage:v||"",codCharge:r==="COD"?400:r==="Bank"?250:0,isShopPending:r==="ShopPay",storeId:G,numericStoreId:"1001",timestamp:X(),date:new Date().toLocaleString(),referredBy:C||"",referredCommission:Number(D)||0},Ze=j(E(k,"stores",G,"orders")),et=Ze.id;ne.docId=et,await Promise.all([me(Ze,ne),me(j(Tt,et),ne)]);try{const y=kt(k);let q=!1;for(const F of x){const Se=F.docId||F.id;if(Se&&Se!=="N/A"){const tt=j(k,"stores",G,"products",Se),ot=await gt(tt);if(ot.exists()){const ie=ot.data(),nt=Number(F.quantity)||1;let te={};if(ie.variants&&Array.isArray(ie.variants)&&ie.variants.length>0){const J=[...ie.variants];let ae=nt;for(let V=0;V<J.length&&!(ae<=0);V++){const K=J[V],Ie=Number(K.price||K.sellingPrice||ie.price||0),vt=Number(F.price||0);if(!F.selectedVariant||F.selectedVariant==="Default"||K.name===F.selectedVariant||K.variantLabel===F.selectedVariant||Math.abs(Ie-vt)<.01){const Me=parseFloat(K.stock)||0;if(Me>0){const at=Math.min(Me,ae);K.stock=Me-at,ae-=at}}}if(ae>0)for(let V=0;V<J.length&&!(ae<=0);V++){const K=parseFloat(J[V].stock)||0;if(K>0){const Ie=Math.min(K,ae);J[V].stock=K-Ie,ae-=Ie}}te.variants=J,te.stock=J.reduce((V,K)=>V+(parseFloat(K.stock)||0),0)}else{const J=parseFloat(ie.stock)||0;te.stock=Math.max(0,J-nt)}te.totalStock=te.stock,te.updatedAt=X(),y.update(tt,te),(G==="mec-book-shop"||G==="master")&&y.update(j(k,"products",Se),te),q=!0}}}q&&(await y.commit(),console.log("[Web Store Checkout] Stock deducted successfully for Order #"+ne.orderId))}catch(y){console.warn("[Web Store Checkout] Stock deduction error (order recorded):",y)}if(r==="Bank"&&N)try{let y=N.docId;if(!y||y==="ndb_default"||y==="boc_default"){const q=T(E(k,"bank_accounts"),S("accountNo","==",N.accountNo)),F=await A(q);F.empty||(y=F.docs[0].id)}if(y&&y!=="ndb_default"&&y!=="boc_default"){const q=j(k,"bank_accounts",y);await ft(q,{balance:Pe(M),updatedAt:X()}),await ce(E(k,"bank_transactions"),{accountId:y,bankName:N.bankName||"Bank Transfer",accountNo:N.accountNo||"",amount:M,type:"Credit",description:`Web Store Bank Transfer: Order #${ne.orderId} (${Ye})`,referenceNo:ne.orderId,orderId:ne.orderId,source:"Web Store",date:new Date().toLocaleDateString("sv-SE"),timestamp:X(),isReconciled:!1,storeId:G}),console.log(`[Web Store Checkout] Credited LKR ${M} to ${N.bankName} (${N.accountNo})`)}}catch(y){console.warn("Error crediting web store bank account:",y)}if(C)try{const y=T(E(k,"affiliates"),S("code","==",C),S("storeId","==",G)),q=await A(y);if(!q.empty){const F=q.docs[0].id;await me(j(k,"affiliates",F),{salesCount:Pe(1),totalCommission:Pe(D)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(y){console.error("Error updating affiliate statistics post-order:",y)}x=[],xe=0,window.appliedCoupon=null,je(),Ne(),ke(!1),alert(r==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":n?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch($){console.error("Order error:",$),alert("Error placing order: "+($.message||"Please try again."))}};if(c){const v=new FileReader;v.onload=P=>{const I=new Image;I.onload=()=>{const $=document.createElement("canvas"),L=1e3,z=1e3;let M=I.width,O=I.height;M>O?M>L&&(O*=L/M,M=L):O>z&&(M*=z/O,O=z),$.width=M,$.height=O,$.getContext("2d").drawImage(I,0,0,M,O);const D=$.toDataURL("image/jpeg",.6);p(D)},I.onerror=()=>{p(P.target.result)},I.src=P.target.result},v.onerror=P=>{console.error("FileReader Error:",P),alert("Error reading slip file. Please try selecting the image again.")},v.readAsDataURL(c)}else p()}function U(){const e=document.querySelector("#product-grid"),t=document.getElementById("pagination-controls");if(!e)return;let a=_.filter(n=>{if(n.mode==="Service"||n.mode==="Technical"||n.mode==="POS")return!1;const l=(n.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const d=re==="All"||n.category===re,p=window.matchProductSearch?window.matchProductSearch(n,Y):n.name.toLowerCase().includes(Y)||n.category.toLowerCase().includes(Y)||n.sku&&n.sku.toLowerCase().includes(Y);return d&&p});le==="recommended"?((!Oe||Oe.length!==a.length)&&(Oe=a.map((n,l)=>({id:l,sort:Math.random()})).sort((n,l)=>n.sort-l.sort).map(n=>n.id)),a.sort(()=>Math.random()-.5)):a.sort((n,l)=>{if(le==="az")return n.name.localeCompare(l.name);if(le==="za")return l.name.localeCompare(n.name);if(le==="low"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return d-p}if(le==="high"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-d}return 0});const i=new Map;a.forEach(n=>{const l=n.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),d=l?l[1].trim():n.name.trim(),p=l?l[2].trim():(n.size||n.color)&&`${n.size?n.size:""} ${n.color?n.color:""}`.trim()||"Default",m=d.toLowerCase();if(i.has(m)){const b=i.get(m);b.totalStock+=n.totalStock!==void 0?n.totalStock:n.stock||0;const u=(n.variants||[]).map(f=>({...f,sourceDocId:n.docId}));u.length===0&&u.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),b.variants=[...b.variants,...u]}else{const b=(n.variants||[]).map(u=>({...u,sourceDocId:n.docId}));b.length===0&&b.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),i.set(m,{...n,name:d,totalStock:n.totalStock!==void 0?n.totalStock:n.stock||0,variants:b})}}),i.forEach(n=>{n.variants=Ge(n.variants,n.name,n.price);const l=n.variants.reduce((d,p)=>d+(parseFloat(p.stock)||0)+(parseFloat(p.wStock)||0),0);l>0&&(n.stock=l,n.totalStock=l)}),window.groupedProducts=Array.from(i.values());const o=window.groupedProducts.length,s=Math.ceil(o/_e);R>s&&s>0&&(R=s),R<1&&(R=1);const r=(R-1)*_e,c=window.groupedProducts.slice(r,r+_e);if(window.groupedProducts.length===0){e.innerHTML=`

      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">

        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>

        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>

        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${Y}</strong>".<br>Try a different keyword or browse all categories.</p>

        <button onclick="window.clearSearch()" 

          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"

          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">

          Clear Search

        </button>

      </div>`,t&&(t.innerHTML="");return}if(e.innerHTML=c.map(n=>{const l=n.variants&&n.variants.length>1,d=n.variants&&n.variants.length>0?n.variants[0]:null,p=de(n,d),m=p.retailPrice,b=p.discountedPrice,u=p.isSpecial,f=p.userType,g=Number(n.discount)||0;let w=ye(n,d);isNaN(w)&&(w=0);let h=n.image;(!h||h.trim()===""||h.includes("/logo.png"))&&d&&(d.images&&d.images.length>0?h=d.images[0]:d.image&&(h=d.image)),h=ve(h,n.name);const B=n.timestamp?typeof n.timestamp.toMillis=="function"?n.timestamp.toMillis():typeof n.timestamp=="number"?n.timestamp:0:0,v=B>0&&Date.now()-B<10080*60*1e3;return`

    <div class="product-card" id="product-${n.docId}">

      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${n.docId}')">

        <div class="image-slider-container" style="height: 100%; width: 100%;">

            <img src="${h}" class="main-product-img" alt="${n.name}" 

                loading="lazy" decoding="async"

                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 

                style="width:100%; height:100%; object-fit:cover;">

        </div>

        ${w<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}

        ${g>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${g}% OFF</div>`:v?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}

        

        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">

            ${((d==null?void 0:d.images)||[n.image]).map((P,I)=>`<div class="dot ${I===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${I===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}

        </div>



        ${l?`

          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')">

            Select Options

          </button>

        `:`

          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')" ${w<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>

            ${w<=0?"Out of Stock":"Add to Cart"}

          </button>

        `}

      </div>

      <div class="product-info">

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">

          <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px;">${n.category||"General"}</div>

          <div class="stock-display" style="font-size: 0.72rem; font-weight:700;">

            ${w<=0?'<span style="color:#ef4444; background:rgba(239,68,68,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Out of Stock</span>':w<5?`<span style="color:#f59e0b; background:rgba(245,158,11,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Only ${w} left</span>`:`<span style="color:#10b981; font-weight:700;">Stock: ${w}</span>`}

          </div>

        </div>

        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${n.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">

          ${n.name}

        </div>

        





        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">

            ${g>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${m.toFixed(2)}</span>`:""}

            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${b.toFixed(2)}</span>

            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}

        </div>

      </div>

    </div>`}).join(""),t)if(s>1){let n=`<button class="pag-nav-btn" ${R===1?"disabled":""} onclick="window.changePage(${R-1})">‹ Previous</button>`;const l=5;let d=Math.max(1,R-2),p=Math.min(s,d+l-1);p===s&&(d=Math.max(1,p-l+1)),d>1&&(n+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',d>2&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=d;m<=p;m++)n+=`<button class="pag-page-btn ${m===R?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<s&&(p<s-1&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),n+=`<button class="pag-page-btn" onclick="window.changePage(${s})">${s}</button>`),n+=`<button class="pag-nav-btn" ${R===s?"disabled":""} onclick="window.changePage(${R+1})">Next ›</button>`,t.innerHTML=n}else t.innerHTML=""}window.changePage=e=>{var t;R=e,U(),(t=document.getElementById("shop-section"))==null||t.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,t)=>{const a=window.groupedProducts?window.groupedProducts.find(B=>B.docId===e):null,i=document.getElementById(`product-${e}`);if(!a||!i)return;const o=a.variants&&a.variants[t]?a.variants[t]:null,s=de(a,o),r=s.retailPrice,c=s.discountedPrice,n=s.isSpecial,l=Number(a.discount)||0,d=o&&o.stock!==void 0?o.stock:a.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:a.images&&a.images.length>0?p=a.images:p=[a.image];const m=p.map(B=>ve(B,a.name)),b=i.querySelector(".original-price"),u=i.querySelector(".final-price");b&&(b.innerText=`LKR ${r.toFixed(2)}`,b.style.display=l>0||n?"inline":"none"),u&&(u.innerText=`LKR ${c.toFixed(2)}`);const f=i.querySelector(".stock-display");f.innerText=`Stock: ${d}`,f.style.color=d<5?"#ef4444":"#10b981";const g=i.querySelector(".add-to-cart-btn");d<=0?(g.disabled=!0,g.innerText="Out of Stock",g.style.background="#cbd5e1",g.style.cursor="not-allowed"):(g.disabled=!1,g.innerText="Add to Cart",g.style.background="",g.style.cursor="pointer");const w=i.querySelector(".main-product-img");w.src=m[0];const h=i.querySelector(".image-dots");if(h.innerHTML=m.map((B,v)=>`<div class="dot ${v===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${v===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let B=0;i.imageInterval&&clearInterval(i.imageInterval),i.imageInterval=setInterval(()=>{B=(B+1)%m.length,w.style.opacity="0.5",setTimeout(()=>{w.src=m[B],w.style.opacity="1",h.querySelectorAll(".dot").forEach((P,I)=>{P.style.background=I===B?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else i.imageInterval&&clearInterval(i.imageInterval)};function Kt(){const e=document.getElementById("nav-auth-item"),t=document.getElementById("user-profile");document.getElementById("user-display-name"),St(rt,a=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),a){const i={name:a.displayName||a.email.split("@")[0],email:a.email,id:a.uid};sessionStorage.setItem("mec_user",JSON.stringify(i));const o=()=>{var B,v,P,I,$;if(!e)return;const l=(((B=window.currentUserProfile)==null?void 0:B.customerType)||"retail").toLowerCase(),d=((v=window.currentUserProfile)==null?void 0:v.phone)||((P=window.currentUserProfile)==null?void 0:P.contact)||"",p=a.photoURL||((I=window.currentUserProfile)==null?void 0:I.photoURL)||(($=window.currentUserProfile)==null?void 0:$.avatar)||"",b=(L=>{if(!L)return"U";const z=L.trim().split(" ");return z.length>=2?(z[0][0]+z[1][0]).toUpperCase():L.slice(0,2).toUpperCase()})(i.name),u=l==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':l==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=l==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">

               <span>👑</span> Wholesale Customer (Wholesale Price Active)

             </div>`:l==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>💎</span> Loyalty Card Member Active

                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>🛍️</span> Standard Retail Customer

                 </div>`;e.innerHTML=`

          <div style="position: relative; display: inline-block;">

            <!-- Circular Avatar Only Trigger Button -->

            <button id="user-profile-trigger" style="

              background: transparent;

              border: none;

              padding: 2px;

              cursor: pointer;

              outline: none;

              display: flex;

              align-items: center;

              justify-content: center;

              position: relative;

            " title="${i.name}">

              

              <!-- Circular Avatar Photo / Initials -->

              <div style="

                width: 38px;

                height: 38px;

                border-radius: 50%;

                background: linear-gradient(135deg, #0284c7, #6366f1);

                display: flex;

                align-items: center;

                justify-content: center;

                font-weight: 800;

                font-size: 0.88rem;

                color: white;

                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);

                border: 2px solid ${l==="wholesale"?"#eab308":l==="loyalty"?"#10b981":"#38bdf8"};

                overflow: hidden;

                flex-shrink: 0;

                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;

              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 

                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">

                ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:b}

              </div>



              <!-- Status Badge Dot -->

              ${l==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':l==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}

            </button>



            <!-- Modern Floating Profile Card Dropdown -->

            <div id="user-profile-dropdown" style="

              display: none;

              position: absolute;

              right: 0;

              top: calc(100% + 12px);

              width: 290px;

              background: #0f172a;

              border: 1px solid rgba(255, 255, 255, 0.15);

              border-radius: 16px;

              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);

              padding: 1.25rem;

              z-index: 10000;

              text-align: left;

            ">

              <!-- Profile Card Header -->

              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">

                <div style="

                  width: 46px;

                  height: 46px;

                  border-radius: 50%;

                  background: linear-gradient(135deg, #0284c7, #8b5cf6);

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  font-weight: 900;

                  font-size: 1.1rem;

                  color: white;

                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);

                  border: 2px solid rgba(255,255,255,0.6);

                  overflow: hidden;

                  flex-shrink: 0;

                ">

                  ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:b}

                </div>

                <div style="overflow: hidden; flex: 1;">

                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">

                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">

                      ${i.name}

                    </span>

                    ${u}

                  </div>

                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">

                    ${i.email||"Registered Customer"}

                  </div>

                </div>

              </div>



              <!-- Account Details & Benefits -->

              <div style="margin: 12px 0;">

                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">

                  Account Membership

                </div>

                ${f}

                

                ${d?`

                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">

                    <span style="color:#38bdf8;">📞</span> <span>${d}</span>

                  </div>

                `:""}

              </div>



              <!-- Quick Actions -->

              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">

                <a href="/track.html" style="

                  display: flex;

                  align-items: center;

                  justify-content: space-between;

                  padding: 8px 12px;

                  background: rgba(255, 255, 255, 0.05);

                  border: 1px solid rgba(255, 255, 255, 0.08);

                  border-radius: 8px;

                  color: #f1f5f9;

                  text-decoration: none;

                  font-size: 0.82rem;

                  font-weight: 600;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"

                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">

                  <span style="display:flex; align-items:center; gap:8px;">

                    <span>📦</span> Track My Orders

                  </span>

                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>

                </a>

              </div>



              <!-- Divider & Logout Button -->

              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">

                <button id="nav-logout-btn" style="

                  width: 100%;

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  gap: 8px;

                  background: rgba(239, 68, 68, 0.12);

                  border: 1px solid rgba(239, 68, 68, 0.3);

                  color: #f87171;

                  padding: 8px 12px;

                  border-radius: 8px;

                  font-size: 0.85rem;

                  font-weight: 700;

                  cursor: pointer;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"

                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">

                  <span>🚪</span> Log Out

                </button>

              </div>

            </div>

          </div>

        `;const g=document.getElementById("user-profile-trigger"),w=document.getElementById("user-profile-dropdown");g&&w&&(g.onclick=L=>{L.stopPropagation();const z=w.style.display==="block";w.style.display=z?"none":"block"});const h=document.getElementById("nav-logout-btn");h&&(h.onclick=async L=>{if(L.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await Pt(rt),window.location.href="/"}catch(z){console.error("Logout Error:",z),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",l=>{const d=document.getElementById("user-profile-trigger"),p=document.getElementById("user-profile-dropdown");p&&d&&!d.contains(l.target)&&!p.contains(l.target)&&(p.style.display="none")}),o();const s=(a.email||"").trim(),r=s.toLowerCase(),c=T(E(k,"customers"),S("email","==",s)),n=T(E(k,"customers"),S("email","==",r));Promise.all([A(c),A(n)]).then(([l,d])=>{let p=null;if(l.empty?d.empty||(p=d.docs[0].data()):p=l.docs[0].data(),p){const m=(p.customerType||p.type||(p.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...p,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()}else{const m=window.currentStoreId||"mec-book-shop";A(T(E(k,"customers"),S("storeId","==",m))).then(b=>{const u=(a.displayName||a.email.split("@")[0]||"").trim().toLowerCase(),f=b.docs.find(g=>{const w=g.data(),h=(w.email||"").trim().toLowerCase(),B=(w.phone||"").trim(),v=(w.name||"").trim().toLowerCase(),P=h&&h===r,I=a.phoneNumber&&B&&(B===a.phoneNumber||a.phoneNumber.includes(B)),$=v&&u&&(v===u||u.includes(v)||v.includes(u)||u.split(" ")[0]===v);return P||I||$});if(f){const g=f.data(),w=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:w,docId:f.id},!g.email&&a.email&&ft(j(k,"customers",f.id),{email:a.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),U()})}}).catch(l=>{console.error("Error fetching user profile:",l),window.currentUserProfile={customerType:"retail"},o(),U()})}else sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},U(),e&&(e.innerHTML='<a href="/login">Login</a>'),t&&(t.style.display="none")})}function Ht(){const e=document.getElementById("reviews-container");if(!e)return;const t=E(k,"reviews"),a=T(t,Ct("timestamp","desc"),It(15));$e(a,i=>{const o=i.docs.map(s=>s.data());if(o.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=o.map(s=>`

      <div class="review-card">

        <div class="review-stars">

          ${"★".repeat(s.rating)}${"☆".repeat(5-s.rating)}

        </div>

        <p class="review-comment">"${s.comment||"No comment provided."}"</p>

        <div class="review-footer">

          <span class="review-author">${s.userName}</span>

          <span class="review-date">${s.date}</span>

        </div>

      </div>

    `).join("")})}Rt();Kt();Ht();const Ue="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let Fe=null;try{Ue&&(Fe=new xt(Ue))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function dt(e,t){if(!_||_.length===0)return t?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const i=(e||"").toLowerCase().split(/\s+/).filter(s=>s.length>2),o=_.map(s=>{let r=0;const c=(s.name||"").toLowerCase(),n=(s.category||"").toLowerCase(),l=(s.description||"").toLowerCase();return i.forEach(d=>{c.includes(d)&&(r+=3),n.includes(d)&&(r+=2),l.includes(d)&&(r+=1)}),{product:s,score:r}}).filter(s=>s.score>0).sort((s,r)=>r.score-s.score);if(o.length>0){const s=o.slice(0,3).map(r=>r.product);return t?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${s.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=c.wholesalePrice?` | තොග මිල: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${s.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"In Stock":"Out of Stock",l=c.wholesalePrice?` | Wholesale: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return t?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function Wt(e,t){var i,o,s,r,c,n;const a=/[\u0D80-\u0DFF]/.test(e)||t==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((i=window.currentStoreData)==null?void 0:i.name)||"MEC Book Shop, Horana",d=(_||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(g=>`${g.name||g.variantLabel||"Var"}-Stock:${g.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.

Available Inventory & Prices:

${d}



CRITICAL RULES:

1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).

2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.

3. Keep answers concise, clear, and direct (max 2-3 short sentences).

4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(Fe)try{const w=(await(await Fe.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(w)return w}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Ue)}`,b=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(b.ok){const u=await b.json(),f=(n=(c=(r=(s=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:s.content)==null?void 0:r.parts)==null?void 0:c[0])==null?void 0:n.text;if(f&&f.trim())return f.trim()}return dt(e,a)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),dt(e,a)}}window.toggleGeminiChat=e=>{var o;const t=document.getElementById("gemini-chat-window"),a=document.getElementById("gemini-bubble");if(!t)return;(e!=null?!!e:!t.classList.contains("active"))?(t.classList.add("active"),a&&a.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):t.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),t=document.getElementById("gemini-chat-messages");if(!e||!t||!e.value.trim())return;const a=e.value.trim();e.value="";const i=document.createElement("div");i.className="user-msg",i.textContent=a,t.appendChild(i),t.scrollTop=t.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",t.appendChild(o),t.scrollTop=t.scrollHeight;const s=a.toLowerCase(),r=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let c=a,n=!1;if(r.forEach(m=>{s.includes(m)&&(n=!0)}),n&&(r.forEach(m=>{c=c.replace(new RegExp(m,"gi"),"")}),c=c.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),c.length>1)){window.searchQuery=c,Y=c;const m=document.getElementById("store-search");m&&(m.value=c),R=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(a)||["mata","thiyenawada","tiyenawada","poth"].some(m=>s.includes(m)),d=await Wt(a,l?"si":"en");o.textContent=d,t.scrollTop=t.scrollHeight};window.talkToAgentWhatsApp=()=>{var s,r,c;const e=document.getElementById("gemini-chat-messages");let t="";e&&(t=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let a=((s=window.currentStoreData)==null?void 0:s.phone)||((r=window.systemConfig)==null?void 0:r.invPhone)||"94770658356";a=a.replace(/[^0-9]/g,""),a.startsWith("0")&&(a="94"+a.substring(1));const i=`Hi ${((c=window.currentStoreData)==null?void 0:c.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(i+t);window.open(`https://wa.me/${a}?text=${o}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const pt=document.getElementById("gemini-orb-btn");pt&&pt.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=bt.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const t=T(E(k,"affiliates"),S("code","==",e),S("storeId","==",window.currentStoreId)),a=await A(t);if(!a.empty){const i=j(k,"affiliates",a.docs[0].id);await me(i,{clicks:Pe(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(t){console.error("Error incrementing referral click:",t)}}};function jt(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="aff-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>

        

        <!-- Tab navigation inside modal -->

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>

        </div>



        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>

        </form>

      </div>



      <div id="aff-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>

        

        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">

          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>

          <div style="display:flex; gap:10px; align-items:center;">

            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">

            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>

          </div>

        </div>



        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(e)}function Vt(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="seller-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>

        

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>

        </div>



        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>

        </form>

      </div>



      <div id="seller-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">

          <div>

            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>

            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>

          </div>

          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">

            Pending

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">

          

          <!-- Add Product Form -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>

            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">

              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>

              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>

            </form>

          </div>



          <!-- Product List -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>

            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">

              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>

            </div>

          </div>

        </div>



        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{jt();const t=document.getElementById("affiliate-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const a=localStorage.getItem("mec_affiliate_user");if(a){const i=JSON.parse(a);try{const o=T(E(k,"affiliates"),S("email","==",i.email),S("storeId","==",window.currentStoreId)),s=await A(o);if(s.empty)localStorage.removeItem("mec_affiliate_user"),Ke();else{const r={...s.docs[0].data(),docId:s.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(r)),Be(r)}}catch(o){console.error(o),Be(i)}}else Ke()}};function Ke(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const t=document.getElementById("aff-login-form"),a=document.getElementById("aff-register-form"),i=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");e==="login"?(t&&(t.style.display="flex"),a&&(a.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),a&&(a.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const t=document.getElementById("aff-login-email").value.trim(),a=document.getElementById("aff-login-pass").value;try{const i=T(E(k,"affiliates"),S("email","==",t),S("password","==",a),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const s={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),Be(s)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const t=document.getElementById("aff-reg-name").value.trim(),a=document.getElementById("aff-reg-email").value.trim(),i=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const s=T(E(k,"affiliates"),S("email","==",a),S("storeId","==",window.currentStoreId));if(!(await A(s)).empty){alert("An account with this email is already registered as a partner.");return}const c=t.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),n={name:t,email:a,phone:i,password:o,code:c,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:X()},l=await ce(E(k,"affiliates"),n);n.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(n)),Be(n)}catch(s){console.error(s),alert("Registration failed. Please try again.")}};function Be(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const t=window.location.protocol,a=window.location.host,i=window.location.pathname;let o=`${t}//${a}${i}`;window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?o+=`?store=${window.currentStoreId}&ref=${e.code}`:o+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),Ke()};window.toggleSellerPortal=async e=>{Vt();const t=document.getElementById("seller-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const a=localStorage.getItem("mec_seller_user");if(a){const i=JSON.parse(a);try{const o=T(E(k,"vendor_shops"),S("email","==",i.email),S("storeId","==",window.currentStoreId)),s=await A(o);if(s.empty)localStorage.removeItem("mec_seller_user"),He();else{const r={...s.docs[0].data(),docId:s.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(r)),Ee(r)}}catch(o){console.error(o),Ee(i)}}else He()}};function He(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const t=document.getElementById("seller-login-form"),a=document.getElementById("seller-register-form"),i=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");e==="login"?(t&&(t.style.display="flex"),a&&(a.style.display="none"),i&&(i.style.color="#38bdf8",i.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),a&&(a.style.display="flex"),i&&(i.style.color="#94a3b8",i.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const t=document.getElementById("seller-login-email").value.trim(),a=document.getElementById("seller-login-pass").value;try{const i=T(E(k,"vendor_shops"),S("email","==",t),S("password","==",a),S("storeId","==",window.currentStoreId)),o=await A(i);if(o.empty)alert("Invalid email address or password.");else{const s={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),Ee(s)}}catch(i){console.error(i),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{e.preventDefault();const t=document.getElementById("seller-reg-shopname").value.trim(),a=document.getElementById("seller-reg-owner").value.trim(),i=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),s=document.getElementById("seller-reg-pass").value;try{const r=T(E(k,"vendor_shops"),S("shopName","==",t),S("storeId","==",window.currentStoreId));if(!(await A(r)).empty){alert("This shop name is already registered.");return}const n=T(E(k,"vendor_shops"),S("email","==",i),S("storeId","==",window.currentStoreId));if(!(await A(n)).empty){alert("This email is already registered to a shop.");return}const d={shopName:t,ownerName:a,email:i,phone:o,password:s,status:"pending",storeId:window.currentStoreId,timestamp:X()},p=await ce(E(k,"vendor_shops"),d);d.docId=p.id,localStorage.setItem("mec_seller_user",JSON.stringify(d)),Ee(d);try{const m="+94770658356",b=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${t}
Owner: ${a}
Phone: ${o}
Email: ${i}`,u=`https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(m)}&message=${encodeURIComponent(b)}`;fetch(u,{method:"GET",mode:"no-cors"}).catch(()=>{})}catch(m){console.error("Vendor SMS alert error:",m)}}catch(r){console.error(r),alert("Shop registration failed. Please try again.")}};async function Ee(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const t=document.getElementById("seller-dash-status-badge");t&&(t.innerText=e.status||"pending",e.status==="active"?(t.style.background="rgba(16, 185, 129, 0.2)",t.style.color="#10b981"):(t.style.background="rgba(251, 191, 36, 0.2)",t.style.color="#fbbf24")),await ht(e.email)}async function ht(e){const t=document.getElementById("seller-products-list");if(t){t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const a=T(We,S("vendorId","==",e),S("storeId","==",window.currentStoreId)),i=await A(a);if(i.empty)t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";i.forEach(s=>{const r=s.data(),c=r.status==="active"?"#10b981":"#fbbf24";o+=`

          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">

            <div>

              <span style="font-weight:bold; font-size:0.85rem; display:block;">${r.name||""}</span>

              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${r.price||0}</span>

            </div>

            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${c};">${r.status||"pending"}</span>

          </div>

        `}),t.innerHTML=o}}catch(a){console.error(a),t.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const t=localStorage.getItem("mec_seller_user");if(!t)return;const a=JSON.parse(t),i=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),s=document.getElementById("seller-prod-category").value.trim(),r=document.getElementById("seller-prod-image").value.trim(),c=document.getElementById("seller-prod-desc").value.trim();try{const n={name:i,price:Number(o),category:s,image:r||"",description:c||"",status:"pending",vendorId:a.email,storeId:window.currentStoreId,timestamp:X(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await ce(We,n),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await ht(a.email)}catch(n){console.error(n),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),He()};window.addEventListener("beforeunload",function(e){var t;(t=window.chrome)!=null&&t.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
