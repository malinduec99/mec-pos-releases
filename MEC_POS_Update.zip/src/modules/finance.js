import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot,
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc, 
    serverTimestamp,
    query,
    where,
    getDocs,
    Timestamp
} from "firebase/firestore";

const expensesCol = collection(db, 'expenses');
const incomeCol = collection(db, 'income');

const sinvoicesCol = collection(db, 'supplier_invoices');
const suppliersCol = collection(db, 'suppliers');

window.initFinance = initFinance;
export function initFinance() {
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    threeMonthsAgo.setHours(0,0,0,0);
    const threeMonthsAgoTimestamp = Timestamp.fromDate(threeMonthsAgo);

    const expQ = isMaster ?
        query(expensesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(expensesCol, where('storeId', '==', storeId));
    onSnapshot(expQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const expenses = isMaster ? raw : raw.filter(ex => ex.timestamp && ex.timestamp.seconds >= threeMonthsAgoTimestamp.seconds);
        window.allExpenses = expenses;
        if (typeof window.renderExpensesUI === 'function') window.renderExpensesUI(expenses);
    });

    const incQ = isMaster ?
        query(incomeCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(incomeCol, where('storeId', '==', storeId));
    onSnapshot(incQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const income = isMaster ? raw : raw.filter(inc => inc.timestamp && inc.timestamp.seconds >= threeMonthsAgoTimestamp.seconds);
        window.allIncome = income;
        if (typeof window.renderIncomeUI === 'function') window.renderIncomeUI(income);
    });

    const supQ = isMaster ? suppliersCol : query(suppliersCol, where('storeId', '==', storeId));
    onSnapshot(supQ, (snapshot) => {
        const suppliers = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id, id: doc.id }));
        window.allSuppliers = suppliers;
        if (typeof window.renderSuppliersUI === 'function') window.renderSuppliersUI(suppliers);
    });

    const sinvQ = isMaster ?
        query(sinvoicesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(sinvoicesCol, where('storeId', '==', storeId));
    onSnapshot(sinvQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const sinvoices = isMaster ? raw : raw.filter(sinv => sinv.timestamp && sinv.timestamp.seconds >= threeMonthsAgoTimestamp.seconds);
        window.allSInvoices = sinvoices;
        if (typeof window.renderSupplierInvoicesUI === 'function') window.renderSupplierInvoicesUI();
    });
}

window.addExpense = async (e) => {
    e.preventDefault();
    const title = document.getElementById('exp-title').value;
    const category = document.getElementById('exp-category').value;
    const amount = parseFloat(document.getElementById('exp-amount').value);
    const date = document.getElementById('exp-date').value;

    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    try {
        window.showToast("🚀 Recording expense...", "info");
        await addDoc(expensesCol, { title, category, amount, date, branchId, storeId, timestamp: serverTimestamp() });
        e.target.reset();
        window.showToast("✅ Expense recorded.", "success");
    } catch (err) { 
        console.error(err);
        window.showToast("❌ Error saving expense", "error");
    }
};

window.filterExpensesByDate = () => {
    if (window.allExpenses && typeof window.renderExpensesUI === 'function') {
        window.renderExpensesUI(window.allExpenses);
    }
};

window.renderExpensesUI = (expenses) => {
    const div = document.getElementById('admin-expense-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();
    const activeBranchFilter = window.activeBranchFilter || 'All';

    const startDateVal = document.getElementById('exp-filter-start-date')?.value;
    const endDateVal = document.getElementById('exp-filter-end-date')?.value;

    const filtered = expenses.filter(ex => {
        if (ex.storeId && ex.storeId !== storeId) return false;
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            if (ex.branchId !== userBranch && (!ex.branchId && userBranch !== 'Global')) return false;
        } else if (activeBranchFilter !== 'All') {
            if (ex.branchId !== activeBranchFilter) return false;
        }

        // Date range filtering
        if (startDateVal && ex.date < startDateVal) return false;
        if (endDateVal && ex.date > endDateVal) return false;

        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    const totalAmount = sorted.reduce((sum, ex) => sum + (Number(ex.amount) || 0), 0);

    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8;">
            <span>Showing <strong>${sorted.length}</strong> record(s)</span>
            <span>Total Expense: <strong style="color: #ef4444; font-size: 1.05rem;">LKR ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
        </div>
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.length === 0 ? `<tr><td colspan="5" style="text-align:center; padding: 20px; color:#64748b;">No expenses found for selected range.</td></tr>` : ''}
                ${sorted.map(ex => `
                    <tr>
                        <td>${ex.date}</td>
                        <td>${ex.title}</td>
                        <td><span class="status-badge" style="background:#f1f5f9; color:#475569;">${ex.category}</span></td>
                        <td style="font-weight:700;">LKR ${(Number(ex.amount) || 0).toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteExpense('${ex.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
};

window.deleteExpense = async (id) => {
    const docRef = doc(db, 'expenses', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
};

window.addIncome = async (e) => {
    e.preventDefault();
    const title = document.getElementById('inc-title').value;
    const amount = parseFloat(document.getElementById('inc-amount').value);
    const date = document.getElementById('inc-date').value;

    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    try {
        window.showToast("🚀 Recording income...", "info");
        await addDoc(incomeCol, { title, amount, date, branchId, storeId, timestamp: serverTimestamp() });
        e.target.reset();
        window.showToast("✅ Income recorded.", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving income", "error");
    }
};

window.renderIncomeUI = (income) => {
    const div = document.getElementById('admin-income-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();
    const activeBranchFilter = window.activeBranchFilter || 'All';

    const filtered = income.filter(inc => {
        if (inc.storeId && inc.storeId !== storeId) return false;
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            return inc.branchId === userBranch || (!inc.branchId && userBranch === 'Global');
        } else if (activeBranchFilter !== 'All') {
            return inc.branchId === activeBranchFilter;
        }
        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Source</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.map(inc => `
                    <tr>
                        <td>${inc.date}</td>
                        <td>${inc.title}</td>
                        <td style="font-weight:700; color:#10b981;">+ LKR ${inc.amount.toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteIncome('${inc.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
};

window.deleteIncome = async (id) => {
    const docRef = doc(db, 'income', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
};

window.generateReports = (orders) => {
    try {
        const userRole = sessionStorage.getItem('userRole');
        const userBranch = sessionStorage.getItem('userBranchId');
        const activeBranchFilter = window.activeBranchFilter || 'All';

        const filterByBranch = (items) => {
            if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
                return items.filter(i => i.branchId === userBranch || (!i.branchId && userBranch === 'Global'));
            } else if (activeBranchFilter !== 'All') {
                return items.filter(i => i.branchId === activeBranchFilter);
            }
            return items;
        };

        if (!Array.isArray(orders)) {
            console.warn("⚠️ generateReports: orders is not an array", orders);
            return;
        }
        const delivered = filterByBranch(orders.filter(o => o.status === 'Delivered'));
        const expenses = filterByBranch(window.allExpenses || []);
        const income = filterByBranch(window.allIncome || []);
        const now = new Date();

        const start = window.currentReportFilters?.start || new Date(now.getFullYear(), now.getMonth(), 1);
        const end = window.currentReportFilters?.end || new Date(now.getFullYear(), now.getMonth() + 1, 0);

        const calcNet = (items) => {
            let sales = 0, costs = 0, exps = 0, incs = 0;
            let serviceCharges = 0, serviceCosts = 0;

            (items.sales || []).forEach(o => {
                const isCard = o.paymentMethod === 'Card';
                // If a surcharge field exists, use it; otherwise assume 2.5% was added to total
                const surchargeAmt = o.surcharge || (isCard ? (o.total - (o.total / 1.025)) : 0);
                const surchargeFactor = isCard && !o.surcharge ? (1 / 1.025) : 1;

                (o.items || []).forEach(i => {
                    const p = (window.allProducts || []).find(product => product.docId === i.docId) || i;
                    const qty = i.quantity || 1;
                    
                    let itemRevenue = (i.price - (i.discount || 0)) * qty;
                    
                    // If surcharge was added manually as a percentage of total, scale it back
                    // If surcharge is explicitly stored, we assume it's NOT part of the item price sum
                    if (isCard && !o.surcharge) {
                        itemRevenue *= surchargeFactor;
                    }

                    if (p.mode === 'Service' || i.mode === 'Service') {
                        serviceCharges += itemRevenue;
                        serviceCosts += (p.cost || 0) * qty;
                    } else {
                        sales += itemRevenue;
                        costs += (p.cost || 0) * qty;
                    }
                });
            });

            items.exps.forEach(e => exps += e.amount);
            items.incs.forEach(n => incs += n.amount);
            
            // Add Reload Commissions
            let reloadComm = 0;
            (items.reloads || []).filter(r => r.status !== 'Void').forEach(r => reloadComm += (r.commission || 0));

            const netProfit = (sales + serviceCharges + incs + reloadComm) - (costs + serviceCosts + exps);
            return { sales, costs, serviceCharges, serviceCosts, exps, incs, reloadComm, net: netProfit };
        };

        const getFilteredData = (s, e) => {
            return {
                sales: delivered.filter(o => {
                    const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
                    return d >= s && d <= e;
                }),
                exps: expenses.filter(o => {
                    const d = o.date ? new Date(o.date + 'T12:00:00') : new Date(0);
                    return d >= s && d <= e;
                }),
                incs: income.filter(o => {
                    const d = o.date ? new Date(o.date + 'T12:00:00') : new Date(0);
                    return d >= s && d <= e;
                }),
                reloads: (window.allReloads || []).filter(o => {
                    const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
                    return d >= s && d <= e;
                })
            };
        };

        const today = new Date();
        today.setHours(0,0,0,0);
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1);

        const yearStart = new Date(now.getFullYear(), 0, 1);
        const yearEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59);

        const dData = calcNet(getFilteredData(today, tomorrow));
        const mData = calcNet(getFilteredData(start, end));
        const yData = calcNet(getFilteredData(yearStart, yearEnd));
        const allData = calcNet({ sales: delivered, exps: expenses, incs: income });

        const updateVal = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.innerText = val;
        };

        updateVal('report-daily-profit', `LKR ${dData.net.toFixed(2)}`);
        updateVal('report-daily-sales', (dData.sales + dData.serviceCharges).toFixed(0));
        updateVal('report-daily-cost', (dData.costs + dData.serviceCosts + dData.exps).toFixed(0));
        updateVal('report-monthly-profit', `LKR ${mData.net.toFixed(2)}`);
        updateVal('report-monthly-sales', (mData.sales + mData.serviceCharges).toFixed(0));
        updateVal('report-monthly-cost', (mData.costs + mData.serviceCosts + mData.exps).toFixed(0));
        updateVal('report-yearly-profit', `LKR ${yData.net.toFixed(2)}`);
        updateVal('report-yearly-sales', (yData.sales + yData.serviceCharges).toFixed(0));
        updateVal('report-yearly-cost', (yData.costs + yData.serviceCosts + yData.exps).toFixed(0));

        const breakdown = document.getElementById('report-breakdown-list');
        if (breakdown) {
            const total = mData.sales + mData.serviceCharges + mData.incs;
            const margin = total > 0 ? (mData.net / total) * 100 : 0;
            breakdown.innerHTML = `
                <div style="background: rgba(255,255,255,0.05); padding: 25px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.1);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h4 style="margin: 0; color: #38bdf8; font-weight: 800;">Performance Breakdown</h4>
                        <span style="background: rgba(16, 185, 129, 0.1); color: #10b981; padding: 5px 12px; border-radius: 20px; font-weight: 900; font-size: 0.8rem;">
                            MARGIN: ${margin.toFixed(1)}%
                        </span>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div style="padding: 15px; background: rgba(14, 165, 233, 0.1); border-radius: 12px;">
                            <div style="font-size: 0.7rem; opacity: 0.6;">SALES REVENUE</div>
                            <div style="font-size: 1.1rem; font-weight: 800;">LKR ${mData.sales.toFixed(2)}</div>
                        </div>
                        <div style="padding: 15px; background: rgba(16, 185, 129, 0.1); border-radius: 12px;">
                            <div style="font-size: 0.7rem; opacity: 0.6;">SERVICE INCOME</div>
                            <div style="font-size: 1.1rem; font-weight: 800;">LKR ${mData.serviceCharges.toFixed(2)}</div>
                        </div>
                        <div style="padding: 15px; background: rgba(245, 158, 11, 0.1); border-radius: 12px;">
                            <div style="font-size: 0.7rem; opacity: 0.6;">RELOAD COMMISSIONS</div>
                            <div style="font-size: 1.1rem; font-weight: 800; color: #f59e0b;">LKR ${mData.reloadComm.toFixed(2)}</div>
                        </div>
                        <div style="padding: 15px; background: rgba(239, 68, 68, 0.1); border-radius: 12px;">
                            <div style="font-size: 0.7rem; opacity: 0.6;">OPERATIONAL EXPENSES</div>
                            <div style="font-size: 1.1rem; font-weight: 800; color: #ef4444;">LKR ${mData.exps.toFixed(2)}</div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (typeof Chart !== 'undefined') {
            const monthsNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            const year = now.getFullYear();
            let mRev = new Array(12).fill(0);
            let mProf = new Array(12).fill(0);

            delivered.filter(o => (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0))).getFullYear() === year).forEach(o => {
                const mo = (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0))).getMonth();
                mRev[mo] += o.total;
                let c = 0;
                o.items.forEach(i => {
                    const p = window.allProducts?.find(pr => pr.docId === i.docId) || i;
                    c += (p.cost || 0) * (i.quantity || 1);
                });
                mProf[mo] += (o.total - c);
            });

            const lineCtx = document.getElementById('salesLineChart');
            if (lineCtx) {
                if (window.myLineChart) window.myLineChart.destroy();
                window.myLineChart = new Chart(lineCtx, {
                    type: 'line',
                    data: {
                        labels: monthsNames,
                        datasets: [
                            { label: 'Revenue', data: mRev, borderColor: '#0ea5e9', fill: true, tension: 0.4 },
                            { label: 'Profit', data: mProf, borderColor: '#10b981', fill: true, tension: 0.4 }
                        ]
                    },
                    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
                });
            }

            const pieCtx = document.getElementById('revenuePieChart');
            if (pieCtx) {
                if (window.myPieChart) window.myPieChart.destroy();
                window.myPieChart = new Chart(pieCtx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Sales', 'Services', 'Extra'],
                        datasets: [{
                            data: [mData.sales, mData.serviceCharges, mData.incs],
                            backgroundColor: ['#00aeef', '#10b981', '#fbbf24'],
                            borderWidth: 0
                        }]
                    },
                    options: { responsive: true, cutout: '65%', plugins: { legend: { position: 'bottom' } } }
                });
            }
        }
    } catch (e) { console.error("Reports Error:", e); }
};

window.openQuickExpenseModal = () => {
    const modal = document.getElementById('pos-quick-expense-modal');
    if (modal) {
        document.getElementById('qexp-title').value = '';
        document.getElementById('qexp-amount').value = '';
        document.getElementById('qexp-category').value = 'General';
        modal.style.display = 'flex';
        setTimeout(() => document.getElementById('qexp-title').focus(), 300);
    }
};

window.saveQuickExpense = async () => {
    const titleInput = document.getElementById('qexp-title');
    const amountInput = document.getElementById('qexp-amount');
    const title = titleInput.value.trim();
    const amount = parseFloat(amountInput.value);
    const category = document.getElementById('qexp-category').value;
    const modal = document.getElementById('pos-quick-expense-modal');
    
    if (!title || isNaN(amount) || amount <= 0) {
        window.showToast("Please enter a valid description and amount!", "error");
        return;
    }
    
    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();
    const date = new Date().toISOString().split('T')[0];
    
    // Close modal immediately for smooth UI experience
    if (modal) modal.style.display = 'none';
    window.showToast("🚀 Recording quick expense...", "info");

    try {
        await addDoc(collection(db, 'expenses'), { 
            title, 
            category, 
            amount, 
            date, 
            branchId, 
            storeId, 
            timestamp: serverTimestamp(),
            isQuickPOS: true
        });
        
        window.showToast("✅ Expense recorded.", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving expense", "error");
    }
};
