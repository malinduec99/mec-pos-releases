window.toSinhala=t=>{if(!t)return"";let e=t.toLowerCase();const n={th:"ත",dh:"ද",sh:"ශ",ch:"ච",kh:"ඛ",gh:"ඝ",ph:"ඵ",bh:"භ",jh:"ඣ",ng:"ඟ",kn:"ඥ"};Object.keys(n).forEach(a=>{e=e.replace(new RegExp(a,"g"),n[a])});const s={aa:"ා",ae:"ැ",ii:"ී",uu:"ූ",ee:"ේ",oo:"ෝ",au:"ෞ",a:"",e:"ෙ",i:"ි",o:"ො",u:"ු"},o={k:"ක",g:"ග",c:"ච",j:"ජ",T:"ඨ",D:"ඪ",t:"ට",d:"ඩ",n:"න",p:"ප",b:"බ",m:"ම",y:"ය",r:"ර",l:"ල",v:"ව",w:"ව",s:"ස",h:"හ",f:"ෆ"};let i="",r=0;for(;r<e.length;){let a=!1;if(r+1<e.length){let d=e.substr(r,2);s[d]&&(i+=s[d],r+=2,a=!0)}if(a)continue;let l=e[r];s[l]!==void 0?i+=s[l]:o[l]?i+=o[l]:i+=l,r++}return i};window.matchProductSku=(t,e)=>{if(!t||!e)return!1;const n=e.toLowerCase().trim(),s=t.toLowerCase();if(s===n)return!0;let o=s;if(o.startsWith("sku-")){const i=o.split("-");i.length>1&&(i.pop(),o=i.join("-"))}return o.includes(n)};window.COMMON_SEARCH_ALIASES={stepler:["stapler","staplar","steplar","staple","steple"],stapler:["stepler","staplar","steplar","staple","steple"],steple:["staple","stapler","stepler"],staple:["steple","stapler","stepler"],steples:["staples","stapler","stepler"],staples:["steples","stapler","stepler"],pin:["pins","steple pin","staple pin"],pins:["pin"],pensil:["pencil"],pencil:["pensil"],colour:["color"],color:["colour"],eraser:["iraser","rubber"],iraser:["eraser","rubber"],rubber:["eraser","iraser"],ruler:["rooler","rule"],rooler:["ruler"],scissors:["scissor","sissor","sissors"],scissor:["scissors","sissor","sissors"],sissor:["scissors","scissor"],glue:["glu","gum"],glu:["glue","gum"],gum:["glue","glu","gam"],tape:["tep","selotep","sellotape"],tep:["tape"],selotep:["sellotape","cellotape","tape"],sellotape:["selotep","cellotape","tape"],box:["boks"],boks:["box"],book:["buk","books"],buk:["book"],books:["book"],file:["fayil","fail","files"],fail:["file","fayil"],paper:["pepar","peper","papers"],pepar:["paper"],peper:["paper"],marker:["maka","maker","markers"],highlighter:["hilighter","hiliter"],tippex:["tipex","correct","correction"],battery:["betry","betari","batteries"],calculator:["calculater","kelculator"],cover:["kawar","kover","covers"],bag:["beg","bags"],bottle:["botle","botal","bottles"],paste:["pest"],board:["bod","boards"],whiteboard:["waitbod","whitebord"],crayons:["creyons","crayan","crayon"],clay:["kley"],bristol:["bristal"],envelope:["envelop","envalop","envelopes"]};window.splitSearchTokens=t=>t?String(t).toLowerCase().trim().split(/[\s,_\/\\+]+/).filter(e=>e.length>0):[];window.getSearchWordVariants=t=>{if(!t)return[];const e=new Set([t]),n=window.COMMON_SEARCH_ALIASES[t];if(n&&n.forEach(s=>e.add(s)),t.length>3&&t.endsWith("s")){const s=t.slice(0,-1);e.add(s),window.COMMON_SEARCH_ALIASES[s]&&window.COMMON_SEARCH_ALIASES[s].forEach(o=>e.add(o))}else t.length>2&&e.add(t+"s");if(window.toSinhala&&/[a-z]/i.test(t)&&t.length>=2){const s=window.toSinhala(t);s&&e.add(s)}return Array.from(e)};window.matchProductSearch=(t,e)=>{if(!t)return!1;if(!e||!String(e).trim())return!0;const n=window.splitSearchTokens(e);if(n.length===0)return!0;const s=(t.name||t.searchKeyName||"").toLowerCase(),o=(t.category||"").toLowerCase(),i=(t.description||"").toLowerCase(),r=(t.brand||t.supplierName||"").toLowerCase(),a=(t.sku||t.code||t.barcode||"").toLowerCase(),l=[],d=t.variants||t.allVariants||[];for(let h=0;h<d.length;h++){const c=d[h];c&&(c.name&&l.push(String(c.name).toLowerCase()),c.variantLabel&&l.push(String(c.variantLabel).toLowerCase()),c.sku&&l.push(String(c.sku).toLowerCase()),c.barcode&&l.push(String(c.barcode).toLowerCase()),c.size&&l.push(String(c.size).toLowerCase()),c.color&&l.push(String(c.color).toLowerCase()))}const E=[s,o,i,r,a,...l].join(" ");for(let h=0;h<n.length;h++){const c=n[h],u=window.getSearchWordVariants(c);let f=!1;for(let p=0;p<u.length;p++){const A=u[p];if(E.includes(A)){f=!0;break}if(window.matchProductSku(t.sku,A)){f=!0;break}if(d.some(b=>b&&b.sku&&window.matchProductSku(b.sku,A))){f=!0;break}}if(!f)return!1}return!0};window.getProductSearchScore=(t,e)=>{if(!t||!e)return 0;const n=String(e).toLowerCase().trim(),s=(t.name||t.searchKeyName||"").toLowerCase(),o=(t.sku||"").toLowerCase();let i=0;s===n&&(i+=500),o===n&&(i+=400),s.startsWith(n)&&(i+=200),s.includes(n)&&(i+=100);const r=window.splitSearchTokens(e);return r.length>0&&(s.startsWith(r[0])&&(i+=50),r.forEach(a=>{s.includes(a)&&(i+=20),o.includes(a)&&(i+=15)})),i};window.filterProductsSmart=(t,e)=>!t||!Array.isArray(t)?[]:!e||!String(e).trim()?t:t.filter(n=>window.matchProductSearch(n,e)).sort((n,s)=>{const o=window.getProductSearchScore(s,e),i=window.getProductSearchScore(n,e);return o!==i?o-i:(n.name||"").localeCompare(s.name||"")});window.matchOrderSearch=(t,e)=>{if(!t)return!1;if(!e||!String(e).trim())return!0;const n=window.splitSearchTokens(e);if(n.length===0)return!0;const s=(t.userName||t.customerName||"").toLowerCase(),o=(t.orderId||t.id||"").toLowerCase(),i=(t.phone||t.customerPhone||"").toLowerCase(),r=(t.invoiceNo||t.receiptNo||"").toLowerCase(),a=[];Array.isArray(t.items)&&t.items.forEach(d=>{d.name&&a.push(String(d.name).toLowerCase()),d.sku&&a.push(String(d.sku).toLowerCase())});const l=[s,o,i,r,...a].join(" ");for(let d=0;d<n.length;d++){const E=n[d],h=window.getSearchWordVariants(E);let c=!1;for(let u=0;u<h.length;u++)if(l.includes(h[u])){c=!0;break}if(!c)return!1}return!0};window.isChequeCleared=(t,e)=>{const n=t||e;if(!n)return!1;let s=null;const o=String(n).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(o)){const i=o.split("-"),r=parseInt(i[0],10),a=parseInt(i[1],10)-1,l=parseInt(i[2],10);s=new Date(r,a,l+1,17,0,0,0)}else{const i=new Date(o);isNaN(i.getTime())||(i.setDate(i.getDate()+1),i.setHours(17,0,0,0),s=i)}return s?new Date>=s:!1};window.getChequeClearanceTime=(t,e)=>{const n=t||e;if(!n)return null;const s=String(n).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(s)){const i=s.split("-");return new Date(parseInt(i[0],10),parseInt(i[1],10)-1,parseInt(i[2],10)+1,17,0,0,0)}const o=new Date(s);return isNaN(o.getTime())?null:(o.setDate(o.getDate()+1),o.setHours(17,0,0,0),o)};var N;(function(t){t.STRING="string",t.NUMBER="number",t.INTEGER="integer",t.BOOLEAN="boolean",t.ARRAY="array",t.OBJECT="object"})(N||(N={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var T;(function(t){t.LANGUAGE_UNSPECIFIED="language_unspecified",t.PYTHON="python"})(T||(T={}));var L;(function(t){t.OUTCOME_UNSPECIFIED="outcome_unspecified",t.OUTCOME_OK="outcome_ok",t.OUTCOME_FAILED="outcome_failed",t.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"})(L||(L={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const M=["user","model","function","system"];var D;(function(t){t.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",t.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",t.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",t.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",t.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",t.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"})(D||(D={}));var k;(function(t){t.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",t.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",t.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",t.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",t.BLOCK_NONE="BLOCK_NONE"})(k||(k={}));var G;(function(t){t.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",t.NEGLIGIBLE="NEGLIGIBLE",t.LOW="LOW",t.MEDIUM="MEDIUM",t.HIGH="HIGH"})(G||(G={}));var x;(function(t){t.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",t.SAFETY="SAFETY",t.OTHER="OTHER"})(x||(x={}));var v;(function(t){t.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",t.STOP="STOP",t.MAX_TOKENS="MAX_TOKENS",t.SAFETY="SAFETY",t.RECITATION="RECITATION",t.LANGUAGE="LANGUAGE",t.BLOCKLIST="BLOCKLIST",t.PROHIBITED_CONTENT="PROHIBITED_CONTENT",t.SPII="SPII",t.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",t.OTHER="OTHER"})(v||(v={}));var H;(function(t){t.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",t.RETRIEVAL_QUERY="RETRIEVAL_QUERY",t.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",t.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",t.CLASSIFICATION="CLASSIFICATION",t.CLUSTERING="CLUSTERING"})(H||(H={}));var U;(function(t){t.MODE_UNSPECIFIED="MODE_UNSPECIFIED",t.AUTO="AUTO",t.ANY="ANY",t.NONE="NONE"})(U||(U={}));var j;(function(t){t.MODE_UNSPECIFIED="MODE_UNSPECIFIED",t.MODE_DYNAMIC="MODE_DYNAMIC"})(j||(j={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class g extends Error{constructor(e){super(`[GoogleGenerativeAI Error]: ${e}`)}}class S extends g{constructor(e,n){super(e),this.response=n}}class q extends g{constructor(e,n,s,o){super(e),this.status=n,this.statusText=s,this.errorDetails=o}}class _ extends g{}class W extends g{}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Q="https://generativelanguage.googleapis.com",Z="v1beta",tt="0.24.1",et="genai-js";var w;(function(t){t.GENERATE_CONTENT="generateContent",t.STREAM_GENERATE_CONTENT="streamGenerateContent",t.COUNT_TOKENS="countTokens",t.EMBED_CONTENT="embedContent",t.BATCH_EMBED_CONTENTS="batchEmbedContents"})(w||(w={}));class nt{constructor(e,n,s,o,i){this.model=e,this.task=n,this.apiKey=s,this.stream=o,this.requestOptions=i}toString(){var e,n;const s=((e=this.requestOptions)===null||e===void 0?void 0:e.apiVersion)||Z;let i=`${((n=this.requestOptions)===null||n===void 0?void 0:n.baseUrl)||Q}/${s}/${this.model}:${this.task}`;return this.stream&&(i+="?alt=sse"),i}}function st(t){const e=[];return t!=null&&t.apiClient&&e.push(t.apiClient),e.push(`${et}/${tt}`),e.join(" ")}async function ot(t){var e;const n=new Headers;n.append("Content-Type","application/json"),n.append("x-goog-api-client",st(t.requestOptions)),n.append("x-goog-api-key",t.apiKey);let s=(e=t.requestOptions)===null||e===void 0?void 0:e.customHeaders;if(s){if(!(s instanceof Headers))try{s=new Headers(s)}catch(o){throw new _(`unable to convert customHeaders value ${JSON.stringify(s)} to Headers: ${o.message}`)}for(const[o,i]of s.entries()){if(o==="x-goog-api-key")throw new _(`Cannot set reserved header name ${o}`);if(o==="x-goog-api-client")throw new _(`Header name ${o} can only be set using the apiClient field`);n.append(o,i)}}return n}async function it(t,e,n,s,o,i){const r=new nt(t,e,n,s,i);return{url:r.toString(),fetchOptions:Object.assign(Object.assign({},lt(i)),{method:"POST",headers:await ot(r),body:o})}}async function I(t,e,n,s,o,i={},r=fetch){const{url:a,fetchOptions:l}=await it(t,e,n,s,o,i);return rt(a,l,r)}async function rt(t,e,n=fetch){let s;try{s=await n(t,e)}catch(o){at(o,t)}return s.ok||await ct(s,t),s}function at(t,e){let n=t;throw n.name==="AbortError"?(n=new W(`Request aborted when fetching ${e.toString()}: ${t.message}`),n.stack=t.stack):t instanceof q||t instanceof _||(n=new g(`Error fetching from ${e.toString()}: ${t.message}`),n.stack=t.stack),n}async function ct(t,e){let n="",s;try{const o=await t.json();n=o.error.message,o.error.details&&(n+=` ${JSON.stringify(o.error.details)}`,s=o.error.details)}catch{}throw new q(`Error fetching from ${e.toString()}: [${t.status} ${t.statusText}] ${n}`,t.status,t.statusText,s)}function lt(t){const e={};if((t==null?void 0:t.signal)!==void 0||(t==null?void 0:t.timeout)>=0){const n=new AbortController;(t==null?void 0:t.timeout)>=0&&setTimeout(()=>n.abort(),t.timeout),t!=null&&t.signal&&t.signal.addEventListener("abort",()=>{n.abort()}),e.signal=n.signal}return e}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function y(t){return t.text=()=>{if(t.candidates&&t.candidates.length>0){if(t.candidates.length>1&&console.warn(`This response had ${t.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),R(t.candidates[0]))throw new S(`${C(t)}`,t);return ut(t)}else if(t.promptFeedback)throw new S(`Text not available. ${C(t)}`,t);return""},t.functionCall=()=>{if(t.candidates&&t.candidates.length>0){if(t.candidates.length>1&&console.warn(`This response had ${t.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),R(t.candidates[0]))throw new S(`${C(t)}`,t);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),F(t)[0]}else if(t.promptFeedback)throw new S(`Function call not available. ${C(t)}`,t)},t.functionCalls=()=>{if(t.candidates&&t.candidates.length>0){if(t.candidates.length>1&&console.warn(`This response had ${t.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),R(t.candidates[0]))throw new S(`${C(t)}`,t);return F(t)}else if(t.promptFeedback)throw new S(`Function call not available. ${C(t)}`,t)},t}function ut(t){var e,n,s,o;const i=[];if(!((n=(e=t.candidates)===null||e===void 0?void 0:e[0].content)===null||n===void 0)&&n.parts)for(const r of(o=(s=t.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)r.text&&i.push(r.text),r.executableCode&&i.push("\n```"+r.executableCode.language+`
`+r.executableCode.code+"\n```\n"),r.codeExecutionResult&&i.push("\n```\n"+r.codeExecutionResult.output+"\n```\n");return i.length>0?i.join(""):""}function F(t){var e,n,s,o;const i=[];if(!((n=(e=t.candidates)===null||e===void 0?void 0:e[0].content)===null||n===void 0)&&n.parts)for(const r of(o=(s=t.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)r.functionCall&&i.push(r.functionCall);if(i.length>0)return i}const dt=[v.RECITATION,v.SAFETY,v.LANGUAGE];function R(t){return!!t.finishReason&&dt.includes(t.finishReason)}function C(t){var e,n,s;let o="";if((!t.candidates||t.candidates.length===0)&&t.promptFeedback)o+="Response was blocked",!((e=t.promptFeedback)===null||e===void 0)&&e.blockReason&&(o+=` due to ${t.promptFeedback.blockReason}`),!((n=t.promptFeedback)===null||n===void 0)&&n.blockReasonMessage&&(o+=`: ${t.promptFeedback.blockReasonMessage}`);else if(!((s=t.candidates)===null||s===void 0)&&s[0]){const i=t.candidates[0];R(i)&&(o+=`Candidate was blocked due to ${i.finishReason}`,i.finishMessage&&(o+=`: ${i.finishMessage}`))}return o}function O(t){return this instanceof O?(this.v=t,this):new O(t)}function ft(t,e,n){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var s=n.apply(t,e||[]),o,i=[];return o={},r("next"),r("throw"),r("return"),o[Symbol.asyncIterator]=function(){return this},o;function r(c){s[c]&&(o[c]=function(u){return new Promise(function(f,p){i.push([c,u,f,p])>1||a(c,u)})})}function a(c,u){try{l(s[c](u))}catch(f){h(i[0][3],f)}}function l(c){c.value instanceof O?Promise.resolve(c.value.v).then(d,E):h(i[0][2],c)}function d(c){a("next",c)}function E(c){a("throw",c)}function h(c,u){c(u),i.shift(),i.length&&a(i[0][0],i[0][1])}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;function ht(t){const e=t.body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0})),n=pt(e),[s,o]=n.tee();return{stream:Et(s),response:gt(o)}}async function gt(t){const e=[],n=t.getReader();for(;;){const{done:s,value:o}=await n.read();if(s)return y(Ct(e));e.push(o)}}function Et(t){return ft(this,arguments,function*(){const n=t.getReader();for(;;){const{value:s,done:o}=yield O(n.read());if(o)break;yield yield O(y(s))}})}function pt(t){const e=t.getReader();return new ReadableStream({start(s){let o="";return i();function i(){return e.read().then(({value:r,done:a})=>{if(a){if(o.trim()){s.error(new g("Failed to parse stream"));return}s.close();return}o+=r;let l=o.match($),d;for(;l;){try{d=JSON.parse(l[1])}catch{s.error(new g(`Error parsing JSON response: "${l[1]}"`));return}s.enqueue(d),o=o.substring(l[0].length),l=o.match($)}return i()}).catch(r=>{let a=r;throw a.stack=r.stack,a.name==="AbortError"?a=new W("Request aborted when reading from the stream"):a=new g("Error reading from the stream"),a})}}})}function Ct(t){const e=t[t.length-1],n={promptFeedback:e==null?void 0:e.promptFeedback};for(const s of t){if(s.candidates){let o=0;for(const i of s.candidates)if(n.candidates||(n.candidates=[]),n.candidates[o]||(n.candidates[o]={index:o}),n.candidates[o].citationMetadata=i.citationMetadata,n.candidates[o].groundingMetadata=i.groundingMetadata,n.candidates[o].finishReason=i.finishReason,n.candidates[o].finishMessage=i.finishMessage,n.candidates[o].safetyRatings=i.safetyRatings,i.content&&i.content.parts){n.candidates[o].content||(n.candidates[o].content={role:i.content.role||"user",parts:[]});const r={};for(const a of i.content.parts)a.text&&(r.text=a.text),a.functionCall&&(r.functionCall=a.functionCall),a.executableCode&&(r.executableCode=a.executableCode),a.codeExecutionResult&&(r.codeExecutionResult=a.codeExecutionResult),Object.keys(r).length===0&&(r.text=""),n.candidates[o].content.parts.push(r)}o++}s.usageMetadata&&(n.usageMetadata=s.usageMetadata)}return n}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function J(t,e,n,s){const o=await I(e,w.STREAM_GENERATE_CONTENT,t,!0,JSON.stringify(n),s);return ht(o)}async function X(t,e,n,s){const i=await(await I(e,w.GENERATE_CONTENT,t,!1,JSON.stringify(n),s)).json();return{response:y(i)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function z(t){if(t!=null){if(typeof t=="string")return{role:"system",parts:[{text:t}]};if(t.text)return{role:"system",parts:[t]};if(t.parts)return t.role?t:{role:"system",parts:t.parts}}}function m(t){let e=[];if(typeof t=="string")e=[{text:t}];else for(const n of t)typeof n=="string"?e.push({text:n}):e.push(n);return _t(e)}function _t(t){const e={role:"user",parts:[]},n={role:"function",parts:[]};let s=!1,o=!1;for(const i of t)"functionResponse"in i?(n.parts.push(i),o=!0):(e.parts.push(i),s=!0);if(s&&o)throw new g("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!s&&!o)throw new g("No content is provided for sending chat message.");return s?e:n}function wt(t,e){var n;let s={model:e==null?void 0:e.model,generationConfig:e==null?void 0:e.generationConfig,safetySettings:e==null?void 0:e.safetySettings,tools:e==null?void 0:e.tools,toolConfig:e==null?void 0:e.toolConfig,systemInstruction:e==null?void 0:e.systemInstruction,cachedContent:(n=e==null?void 0:e.cachedContent)===null||n===void 0?void 0:n.name,contents:[]};const o=t.generateContentRequest!=null;if(t.contents){if(o)throw new _("CountTokensRequest must have one of contents or generateContentRequest, not both.");s.contents=t.contents}else if(o)s=Object.assign(Object.assign({},s),t.generateContentRequest);else{const i=m(t);s.contents=[i]}return{generateContentRequest:s}}function K(t){let e;return t.contents?e=t:e={contents:[m(t)]},t.systemInstruction&&(e.systemInstruction=z(t.systemInstruction)),e}function St(t){return typeof t=="string"||Array.isArray(t)?{content:m(t)}:t}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],vt={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function Ot(t){let e=!1;for(const n of t){const{role:s,parts:o}=n;if(!e&&s!=="user")throw new g(`First content should be with role 'user', got ${s}`);if(!M.includes(s))throw new g(`Each item should include role field. Got ${s} but valid roles are: ${JSON.stringify(M)}`);if(!Array.isArray(o))throw new g("Content should have 'parts' property with an array of Parts");if(o.length===0)throw new g("Each Content should have at least one part");const i={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(const a of o)for(const l of P)l in a&&(i[l]+=1);const r=vt[s];for(const a of P)if(!r.includes(a)&&i[a]>0)throw new g(`Content with role '${s}' can't contain '${a}' part`);e=!0}}function Y(t){var e;if(t.candidates===void 0||t.candidates.length===0)return!1;const n=(e=t.candidates[0])===null||e===void 0?void 0:e.content;if(n===void 0||n.parts===void 0||n.parts.length===0)return!1;for(const s of n.parts)if(s===void 0||Object.keys(s).length===0||s.text!==void 0&&s.text==="")return!1;return!0}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B="SILENT_ERROR";class mt{constructor(e,n,s,o={}){this.model=n,this.params=s,this._requestOptions=o,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=e,s!=null&&s.history&&(Ot(s.history),this._history=s.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(e,n={}){var s,o,i,r,a,l;await this._sendPromise;const d=m(e),E={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(r=this.params)===null||r===void 0?void 0:r.toolConfig,systemInstruction:(a=this.params)===null||a===void 0?void 0:a.systemInstruction,cachedContent:(l=this.params)===null||l===void 0?void 0:l.cachedContent,contents:[...this._history,d]},h=Object.assign(Object.assign({},this._requestOptions),n);let c;return this._sendPromise=this._sendPromise.then(()=>X(this._apiKey,this.model,E,h)).then(u=>{var f;if(Y(u.response)){this._history.push(d);const p=Object.assign({parts:[],role:"model"},(f=u.response.candidates)===null||f===void 0?void 0:f[0].content);this._history.push(p)}else{const p=C(u.response);p&&console.warn(`sendMessage() was unsuccessful. ${p}. Inspect response object for details.`)}c=u}).catch(u=>{throw this._sendPromise=Promise.resolve(),u}),await this._sendPromise,c}async sendMessageStream(e,n={}){var s,o,i,r,a,l;await this._sendPromise;const d=m(e),E={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(r=this.params)===null||r===void 0?void 0:r.toolConfig,systemInstruction:(a=this.params)===null||a===void 0?void 0:a.systemInstruction,cachedContent:(l=this.params)===null||l===void 0?void 0:l.cachedContent,contents:[...this._history,d]},h=Object.assign(Object.assign({},this._requestOptions),n),c=J(this._apiKey,this.model,E,h);return this._sendPromise=this._sendPromise.then(()=>c).catch(u=>{throw new Error(B)}).then(u=>u.response).then(u=>{if(Y(u)){this._history.push(d);const f=Object.assign({},u.candidates[0].content);f.role||(f.role="model"),this._history.push(f)}else{const f=C(u);f&&console.warn(`sendMessageStream() was unsuccessful. ${f}. Inspect response object for details.`)}}).catch(u=>{u.message!==B&&console.error(u)}),c}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function It(t,e,n,s){return(await I(e,w.COUNT_TOKENS,t,!1,JSON.stringify(n),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rt(t,e,n,s){return(await I(e,w.EMBED_CONTENT,t,!1,JSON.stringify(n),s)).json()}async function At(t,e,n,s){const o=n.requests.map(r=>Object.assign(Object.assign({},r),{model:e}));return(await I(e,w.BATCH_EMBED_CONTENTS,t,!1,JSON.stringify({requests:o}),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V{constructor(e,n,s={}){this.apiKey=e,this._requestOptions=s,n.model.includes("/")?this.model=n.model:this.model=`models/${n.model}`,this.generationConfig=n.generationConfig||{},this.safetySettings=n.safetySettings||[],this.tools=n.tools,this.toolConfig=n.toolConfig,this.systemInstruction=z(n.systemInstruction),this.cachedContent=n.cachedContent}async generateContent(e,n={}){var s;const o=K(e),i=Object.assign(Object.assign({},this._requestOptions),n);return X(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}async generateContentStream(e,n={}){var s;const o=K(e),i=Object.assign(Object.assign({},this._requestOptions),n);return J(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}startChat(e){var n;return new mt(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(n=this.cachedContent)===null||n===void 0?void 0:n.name},e),this._requestOptions)}async countTokens(e,n={}){const s=wt(e,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),o=Object.assign(Object.assign({},this._requestOptions),n);return It(this.apiKey,this.model,s,o)}async embedContent(e,n={}){const s=St(e),o=Object.assign(Object.assign({},this._requestOptions),n);return Rt(this.apiKey,this.model,s,o)}async batchEmbedContents(e,n={}){const s=Object.assign(Object.assign({},this._requestOptions),n);return At(this.apiKey,this.model,e,s)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bt{constructor(e){this.apiKey=e}getGenerativeModel(e,n){if(!e.model)throw new g("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new V(this.apiKey,e,n)}getGenerativeModelFromCachedContent(e,n,s){if(!e.name)throw new _("Cached content must contain a `name` field.");if(!e.model)throw new _("Cached content must contain a `model` field.");const o=["model","systemInstruction"];for(const r of o)if(n!=null&&n[r]&&e[r]&&(n==null?void 0:n[r])!==e[r]){if(r==="model"){const a=n.model.startsWith("models/")?n.model.replace("models/",""):n.model,l=e.model.startsWith("models/")?e.model.replace("models/",""):e.model;if(a===l)continue}throw new _(`Different value for "${r}" specified in modelParams (${n[r]}) and cachedContent (${e[r]})`)}const i=Object.assign(Object.assign({},n),{model:e.model,tools:e.tools,toolConfig:e.toolConfig,systemInstruction:e.systemInstruction,cachedContent:e});return new V(this.apiKey,i,s)}}export{bt as G};
