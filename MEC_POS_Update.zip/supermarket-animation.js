// ═══════════════════════════════════════════════════════════════════════════
// HIGH-PERFORMANCE 3D ANIMATED SUPERMARKET BACKGROUND ENGINE
// ═══════════════════════════════════════════════════════════════════════════

(function() {
    let canvas, ctx;
    let width, height;
    let animFrameId;
    let currentMode = 'login';
    let doorOpenProgress = 0;
    let isDoorOpening = false;

    function initVideoEngine() {
        let container = document.getElementById('supermarket-canvas-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'supermarket-canvas-container';
            container.className = 'supermarket-video-bg';
            document.body.prepend(container);
        }

        container.innerHTML = `
            <canvas id="supermarket-canvas"></canvas>
            <div class="bg-video-overlay-shade"></div>
            <div class="store-door-layer" id="store-door-layer">
                <div class="glass-door door-left" id="door-left">
                    <div class="door-handle"></div>
                    <div class="door-logo">MEC STORE</div>
                </div>
                <div class="glass-door door-right" id="door-right">
                    <div class="door-handle"></div>
                    <div class="door-logo">AUTOMATIC ENTRANCE</div>
                </div>
                <div class="door-light-beam" id="door-light-beam"></div>
            </div>
        `;

        canvas = document.getElementById('supermarket-canvas');
        if (!canvas) return;
        ctx = canvas.getContext('2d');
        resize();
        window.addEventListener('resize', resize);

        observeModeChanges();
        startLoop();
    }

    function resize() {
        if (!canvas) return;
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }

    function observeModeChanges() {
        const targetContainer = document.getElementById('main-auth-container') || document.getElementById('storefront-auth-container');
        if (!targetContainer) return;

        const checkMode = () => {
            const isReg = targetContainer.classList.contains('is-register');
            const newMode = isReg ? 'register' : 'login';
            if (newMode !== currentMode) {
                currentMode = newMode;
                document.getElementById('supermarket-canvas-container')?.classList.toggle('mode-register', isReg);
            }
        };

        const observer = new MutationObserver(checkMode);
        observer.observe(targetContainer, { attributes: true, attributeFilter: ['class'] });
        checkMode();
    }

    // Global trigger for registration door opening animation
    window.triggerDoorOpenAnimation = function(callback) {
        isDoorOpening = true;
        const doorLeft = document.getElementById('door-left');
        const doorRight = document.getElementById('door-right');
        const lightBeam = document.getElementById('door-light-beam');

        if (doorLeft) doorLeft.style.transform = 'translateX(-95%)';
        if (doorRight) doorRight.style.transform = 'translateX(95%)';
        if (lightBeam) lightBeam.style.opacity = '1';

        setTimeout(() => {
            if (typeof callback === 'function') callback();
        }, 1800);
    };

    // ─── 3D VIDEO RENDER LOOP ──────────────────────────────────
    function startLoop() {
        let time = 0;
        function render() {
            time += 0.02;
            ctx.clearRect(0, 0, width, height);

            if (currentMode === 'login') {
                drawSupermarketTrolleyFlow(time);
            } else {
                drawSupermarketEntranceFlow(time);
            }

            animFrameId = requestAnimationFrame(render);
        }
        render();
    }

    // ─── LOGIN: Customer Pushing Shopping Trolley Through Aisle ───
    function drawSupermarketTrolleyFlow(time) {
        // Deep Gradient Supermarket Aisle Backdrop
        const bgGrad = ctx.createLinearGradient(0, 0, width, height);
        bgGrad.addColorStop(0, '#0d0b1a');
        bgGrad.addColorStop(0.4, '#2e1065');
        bgGrad.addColorStop(0.8, '#4c1d95');
        bgGrad.addColorStop(1, '#090a15');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Neon Ceiling Lights
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 20;
        for (let i = 0.15; i <= 0.85; i += 0.25) {
            ctx.fillRect(width * i, height * 0.05, width * 0.18, 8);
        }
        ctx.shadowBlur = 0;

        // Perspective Flooring Grid
        const horizon = height * 0.42;
        const vanishingX = width * 0.5 + Math.sin(time * 0.4) * 35;

        ctx.strokeStyle = 'rgba(192, 38, 211, 0.3)';
        ctx.lineWidth = 2;

        for (let x = -width * 0.5; x <= width * 1.5; x += 100) {
            ctx.beginPath();
            ctx.moveTo(x, height);
            ctx.lineTo(vanishingX, horizon);
            ctx.stroke();
        }

        // Horizontal Motion Flooring Lines (Simulates Moving Trolley Forward)
        const moveOffset = (time * 140) % 60;
        for (let y = horizon; y <= height; y += 35) {
            const curY = y + moveOffset;
            if (curY <= height) {
                ctx.beginPath();
                ctx.moveTo(0, curY);
                ctx.lineTo(width, curY);
                ctx.stroke();
            }
        }

        // Aisle Shelves Left & Right
        drawShelves(horizon, vanishingX, time);

        // Customer Pushing Trolley Animation
        const trolleyX = width * 0.22 + Math.sin(time * 0.7) * 25;
        const trolleyY = height * 0.65 + Math.cos(time * 1.1) * 8;
        drawTrolleyCharacter(trolleyX, trolleyY, time);
    }

    function drawShelves(horizon, vanishingX, time) {
        // Left Shelving Units
        ctx.fillStyle = 'rgba(126, 34, 206, 0.45)';
        ctx.beginPath();
        ctx.moveTo(0, horizon - 60);
        ctx.lineTo(vanishingX - 220, horizon);
        ctx.lineTo(vanishingX - 220, horizon + 120);
        ctx.lineTo(0, height);
        ctx.fill();

        // Right Shelving Units
        ctx.fillStyle = 'rgba(192, 38, 211, 0.4)';
        ctx.beginPath();
        ctx.moveTo(width, horizon - 60);
        ctx.lineTo(vanishingX + 220, horizon);
        ctx.lineTo(vanishingX + 220, horizon + 120);
        ctx.lineTo(width, height);
        ctx.fill();

        // Animated Grocery Items on Shelves
        const glowingItems = [
            { x: width * 0.12, y: horizon + 50, r: 16, color: '#00f5ff' },
            { x: width * 0.85, y: horizon + 80, r: 20, color: '#f59e0b' },
            { x: width * 0.89, y: horizon + 160, r: 14, color: '#ec4899' }
        ];

        glowingItems.forEach(it => {
            ctx.fillStyle = it.color;
            ctx.shadowColor = it.color;
            ctx.shadowBlur = 18;
            ctx.beginPath();
            ctx.arc(it.x, it.y + Math.sin(time * 2.5 + it.x) * 10, it.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
        });
    }

    function drawTrolleyCharacter(x, y, time) {
        ctx.save();
        ctx.translate(x, y);

        // Shopping Cart Base & Basket
        ctx.strokeStyle = '#00f5ff';
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 15;
        ctx.lineWidth = 3.5;

        // Basket Frame
        ctx.beginPath();
        ctx.roundRect(0, 0, 85, 55, 6);
        ctx.stroke();

        // Metal Grid lines
        ctx.lineWidth = 1.5;
        for (let i = 18; i < 85; i += 18) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, 55);
            ctx.stroke();
        }

        // Cart Wheels
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#ffffff';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(12, 64, 8, 0, Math.PI * 2);
        ctx.arc(73, 64, 8, 0, Math.PI * 2);
        ctx.fill();

        // Cart Handle Bar
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#00f5ff';
        ctx.beginPath();
        ctx.moveTo(-20, -12);
        ctx.lineTo(0, 15);
        ctx.stroke();

        // Customer Silhouette Pushing Trolley
        ctx.fillStyle = '#ec4899';
        ctx.shadowColor = '#ec4899';
        ctx.shadowBlur = 20;

        // Head
        ctx.beginPath();
        ctx.arc(-35, -55, 16, 0, Math.PI * 2);
        ctx.fill();

        // Body
        ctx.beginPath();
        ctx.ellipse(-35, -15, 16, 30, 0, 0, Math.PI * 2);
        ctx.fill();

        // Arms Pushing Cart
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#ec4899';
        ctx.beginPath();
        ctx.moveTo(-30, -25);
        ctx.lineTo(-15, -10);
        ctx.stroke();

        ctx.restore();
    }

    // ─── REGISTER: Customer Car Arrival & Waiting at Entrance Doors ───
    function drawSupermarketEntranceFlow(time) {
        // Night Exterior Backdrop
        const bgGrad = ctx.createLinearGradient(0, 0, width, height);
        bgGrad.addColorStop(0, '#060710');
        bgGrad.addColorStop(0.5, '#1e1b4b');
        bgGrad.addColorStop(1, '#7e22ce');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Store Header Sign
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#c026d3';
        ctx.shadowBlur = 30;
        ctx.font = '900 38px Outfit, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('🏬 MEC SUPERMARKET ENTRANCE', width * 0.5, height * 0.16);
        ctx.shadowBlur = 0;

        // Ground Pavement Line
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, height * 0.72);
        ctx.lineTo(width, height * 0.72);
        ctx.stroke();

        // Car Parked
        drawCar(width * 0.10, height * 0.73, time);

        // Customer Walking / Waiting at Glass Door
        let custX = width * 0.44;
        let custY = height * 0.76;
        if (isDoorOpening) {
            custX += 70;
            custY -= 40;
        }
        drawEntranceCustomer(custX, custY, time);
    }

    function drawCar(x, y, time) {
        ctx.save();
        ctx.translate(x, y);

        // Car Body
        ctx.fillStyle = '#3b82f6';
        ctx.shadowColor = '#3b82f6';
        ctx.shadowBlur = 22;
        ctx.beginPath();
        ctx.roundRect(0, 0, 160, 45, 12);
        ctx.fill();

        // Car Roof
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.roundRect(30, -26, 90, 28, 8);
        ctx.fill();

        // Headlight Beams
        const lightGrad = ctx.createRadialGradient(165, 22, 0, 230, 22, 120);
        lightGrad.addColorStop(0, 'rgba(255, 255, 255, 0.85)');
        lightGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = lightGrad;
        ctx.beginPath();
        ctx.arc(165, 22, 100, -Math.PI * 0.25, Math.PI * 0.25);
        ctx.fill();

        // Wheels
        ctx.fillStyle = '#020617';
        ctx.beginPath();
        ctx.arc(30, 45, 14, 0, Math.PI * 2);
        ctx.arc(130, 45, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
    }

    function drawEntranceCustomer(x, y, time) {
        ctx.save();
        ctx.translate(x, y);

        ctx.fillStyle = '#f59e0b';
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 20;

        // Head
        ctx.beginPath();
        ctx.arc(0, -60, 16, 0, Math.PI * 2);
        ctx.fill();

        // Body
        ctx.beginPath();
        ctx.ellipse(0, -20, 16, 28, 0, 0, Math.PI * 2);
        ctx.fill();

        // Legs
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 4.5;
        const swing = isDoorOpening ? Math.sin(time * 8) * 14 : Math.sin(time * 3) * 4;

        ctx.beginPath();
        ctx.moveTo(-5, 0);
        ctx.lineTo(-5 + swing, 28);
        ctx.moveTo(5, 0);
        ctx.lineTo(5 - swing, 28);
        ctx.stroke();

        ctx.restore();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initVideoEngine);
    } else {
        initVideoEngine();
    }
})();
