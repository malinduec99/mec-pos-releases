/**
 * MEC POS ZENITH ERP — SRI LANKA PAYROLL & STATUTORY COMPLIANCE ENGINE
 * 
 * Implements:
 * 1. Sri Lanka Shop & Office Employees Act No. 19 of 1954 Compliance
 * 2. EPF Act No. 15 of 1958 (8% Employee / 12% Employer on Total Statutory Earnings)
 * 3. ETF Act No. 46 of 1980 (3% Employer Contribution)
 * 4. Inland Revenue Department (IRD) APIT (Advance Personal Income Tax) Progressive Slabs
 * 5. Attendance Allowance Protection Rule under Statutory Medical Certificates
 * 6. Central Bank EPF e-Services C-Form 6-Field Text Generation
 * 7. ETF Board Monthly Schedule Export
 * 8. Corporate Banking Bulk Salary Upload Format (Commercial Bank, Sampath, BOC, HNB - SLIPS / CEFT)
 * 9. Automated General Ledger Double-Entry Journal Posting to MEC Accounting
 */

// ─── APIT Tax Slabs (Effective Sri Lanka Inland Revenue Tables) ────────────────
export const APIT_MONTHLY_TAX_SLABS = [
    { threshold: 100000, rate: 0.00 }, // First 100,000 tax-free allowance
    { threshold: 41667,  rate: 0.06 }, // Next 41,667 @ 6%
    { threshold: 41667,  rate: 0.12 }, // Next 41,667 @ 12%
    { threshold: 41667,  rate: 0.18 }, // Next 41,667 @ 18%
    { threshold: 41667,  rate: 0.24 }, // Next 41,667 @ 24%
    { threshold: 41667,  rate: 0.30 }, // Next 41,667 @ 30%
    { threshold: Infinity, rate: 0.36 } // Excess @ 36%
];

/**
 * Calculates APIT (Advance Personal Income Tax) for a given monthly gross taxable income.
 */
export function calculateAPIT(monthlyTaxableIncome) {
    if (monthlyTaxableIncome <= 100000) return 0;
    
    let remaining = monthlyTaxableIncome - 100000;
    let totalTax = 0;

    const slabRates = [
        { limit: 41667, rate: 0.06 },
        { limit: 41667, rate: 0.12 },
        { limit: 41667, rate: 0.18 },
        { limit: 41667, rate: 0.24 },
        { limit: 41667, rate: 0.30 },
        { limit: Infinity, rate: 0.36 }
    ];

    for (const slab of slabRates) {
        if (remaining <= 0) break;
        const taxableInSlab = Math.min(remaining, slab.limit);
        totalTax += taxableInSlab * slab.rate;
        remaining -= taxableInSlab;
    }

    return Math.round(totalTax * 100) / 100;
}

/**
 * Calculates complete payroll details for a single employee under Sri Lanka compliance.
 */
export function calculateSriLankaPayrollForEmployee({
    emp,
    monthStr, // 'YYYY-MM'
    allOrders = [],
    allLeaveRequests = [],
    advanceDeductions = 0
}) {
    const [year, month] = monthStr.split('-');
    const yearInt = parseInt(year);
    const monthInt = parseInt(month);

    // 1. Basic & Budgetary Relief Allowances (Total Statutory Base)
    const basicSalary = parseFloat(emp.basicSalary || emp.salary || 0);
    const braAllowance = parseFloat(emp.braAllowance || emp.budgetaryAllowance || 0);
    const colaAllowance = parseFloat(emp.colaAllowance || emp.livingAllowance || 0);
    const fixedAllowance = parseFloat(emp.fixedAllowance || 0);

    // Statutory Earnings Base for EPF / ETF
    const epfBase = basicSalary + braAllowance + colaAllowance + fixedAllowance;

    // 2. Sales Commission Attribution from POS
    let totalSales = 0;
    for (let i = 0; i < allOrders.length; i++) {
        const o = allOrders[i];
        if (!o.isPOS) continue;
        const matchesStaff = (o.staffId === emp.docId || o.staffId === emp.regno || o.staffId === emp.id);
        if (!matchesStaff) continue;
        
        const d = (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : new Date(o.date));
        if (d.getFullYear() === yearInt && (d.getMonth() + 1) === monthInt) {
            totalSales += (o.total || 0);
        }
    }
    const commissionPct = parseFloat(emp.commission || emp.salesCommission || 0);
    const commissionEarned = totalSales * (commissionPct / 100);

    // 3. Attendance Allowance & Sri Lanka Labour Law Protection Engine
    const monthlyAttendanceAllowance = parseFloat(emp.attendanceAllowance || emp.allowance || 0);
    let payableAttendanceAllowance = 0;
    let allowanceProtected = false;
    let allowanceRemarks = 'Not configured';

    if (monthlyAttendanceAllowance > 0) {
        // Query leaves in this month
        const leavesInMonth = allLeaveRequests.filter(l => {
            const matchesStaff = (l.empId === emp.docId || l.empId === emp.regno || l.empId === emp.id);
            if (!matchesStaff) return false;
            const lDate = String(l.date || '').trim();
            return lDate.startsWith(monthStr);
        });

        // Any rejected leave or unapproved casual leave forfeits attendance bonus
        const hasRejected = leavesInMonth.some(l => (l.status || '').toLowerCase() === 'rejected');
        const hasUnprotectedCasual = leavesInMonth.some(l => {
            if ((l.status || '').toLowerCase() === 'approved') {
                const isProtected = l.allowanceProtected === true || (l.medicalBill && (l.type || '').toLowerCase().includes('medical'));
                return !isProtected;
            }
            return false;
        });

        const hasProtectedMedical = leavesInMonth.some(l => {
            return (l.status || '').toLowerCase() === 'approved' && (l.allowanceProtected === true || !!l.medicalBill);
        });

        if (hasRejected || hasUnprotectedCasual) {
            payableAttendanceAllowance = 0;
            allowanceProtected = false;
            allowanceRemarks = hasRejected ? 'Forfeited due to rejected leave' : 'Forfeited due to uncertified casual absence';
        } else {
            payableAttendanceAllowance = monthlyAttendanceAllowance;
            allowanceProtected = hasProtectedMedical;
            allowanceRemarks = hasProtectedMedical
                ? 'Protected under Shop & Office Act (Medical Certificate Verified)'
                : 'Granted in full (100% Attendance)';
        }
    }

    // 4. Gross Earnings
    const grossEarnings = epfBase + commissionEarned + payableAttendanceAllowance;

    // 5. Statutory EPF & ETF Computations (Sri Lanka Statutory Rates)
    const isEpfEligible = emp.epfEnabled !== false && emp.status !== 'Contractor';
    const employeeEpf8 = isEpfEligible ? Math.round(epfBase * 0.08 * 100) / 100 : 0;
    const employerEpf12 = isEpfEligible ? Math.round(epfBase * 0.12 * 100) / 100 : 0;
    const employerEtf3 = isEpfEligible ? Math.round(epfBase * 0.03 * 100) / 100 : 0;
    const totalEpfRemittance = employeeEpf8 + employerEpf12; // 20%
    const totalStatutoryContribution = totalEpfRemittance + employerEtf3; // 23%

    // 6. APIT (Advance Personal Income Tax)
    const apitTax = calculateAPIT(grossEarnings);

    // 7. Total Deductions & Net Salary
    const totalEmployeeDeductions = employeeEpf8 + apitTax + advanceDeductions;
    const netSalary = Math.max(0, grossEarnings - totalEmployeeDeductions);

    // 8. Total Employment Cost to Employer (Company Cost)
    const totalCompanyCost = grossEarnings + employerEpf12 + employerEtf3;

    return {
        empId: emp.docId || emp.regno,
        empRegNo: emp.regno || emp.empId || 'EMP-000',
        empName: emp.name || emp.fullName || 'Employee',
        empRole: emp.role || emp.designation || 'Staff',
        empPhone: emp.phone || '',
        bankName: emp.bankName || 'Commercial Bank',
        bankBranch: emp.bankBranch || 'Colombo',
        bankAccount: emp.bankAccount || emp.accountNo || '',
        epfNumber: emp.epfNumber || emp.epfNo || emp.regno || '',
        nic: emp.nic || emp.nationalId || '',
        month: monthStr,
        
        // Earnings
        basicSalary,
        braAllowance,
        colaAllowance,
        fixedAllowance,
        epfBase,
        totalSales,
        commissionPct,
        commissionEarned,
        monthlyAttendanceAllowance,
        payableAttendanceAllowance,
        allowanceProtected,
        allowanceRemarks,
        grossEarnings,
        
        // Deductions
        employeeEpf8,
        apitTax,
        advanceDeductions,
        totalEmployeeDeductions,
        netSalary,

        // Employer Statutory Liabilities
        employerEpf12,
        employerEtf3,
        totalEpfRemittance,
        totalStatutoryContribution,
        totalCompanyCost
    };
}

/**
 * Generates official Central Bank of Sri Lanka (CBSL) EPF e-Services C-Form text export.
 * Standard 6-field ASCII format:
 * [Emp EPF No] [Emp NIC] [Employee Name] [Total Earnings] [Member EPF 8%] [Employer EPF 12%]
 */
export function generateCentralBankEPFCFormText(payrollRecords, employerEpfRegNo = 'EPF/MEC/99812', monthStr = '') {
    const lines = [];
    lines.push(`H|${employerEpfRegNo}|${monthStr.replace('-', '')}|${payrollRecords.length}`);
    
    payrollRecords.forEach((r, idx) => {
        const epfNo = (r.epfNumber || (idx + 1).toString()).padEnd(6, ' ');
        const nic = (r.nic || '000000000V').padEnd(12, ' ');
        const name = (r.empName || 'Staff').substring(0, 30).padEnd(30, ' ');
        const earnings = r.epfBase.toFixed(2).padStart(12, ' ');
        const emp8 = r.employeeEpf8.toFixed(2).padStart(10, ' ');
        const empl12 = r.employerEpf12.toFixed(2).padStart(10, ' ');
        lines.push(`D|${epfNo}|${nic}|${name}|${earnings}|${emp8}|${empl12}`);
    });

    const totalBase = payrollRecords.reduce((acc, r) => acc + r.epfBase, 0).toFixed(2);
    const total8 = payrollRecords.reduce((acc, r) => acc + r.employeeEpf8, 0).toFixed(2);
    const total12 = payrollRecords.reduce((acc, r) => acc + r.employerEpf12, 0).toFixed(2);
    lines.push(`T|${payrollRecords.length}|${totalBase}|${total8}|${total12}`);

    return lines.join('\r\n');
}

/**
 * Generates ETF Board Monthly Schedule (Form II) CSV format.
 */
export function generateETFScheduleCSV(payrollRecords, employerEtfRegNo = 'ETF/MEC/7721', monthStr = '') {
    const headers = ['Employer ETF No', 'Month', 'Member No', 'NIC', 'Employee Name', 'Statutory Earnings (LKR)', 'ETF Contribution 3% (LKR)'];
    const rows = payrollRecords.map(r => [
        `"${employerEtfRegNo}"`,
        `"${monthStr}"`,
        `"${r.epfNumber}"`,
        `"${r.nic}"`,
        `"${r.empName}"`,
        r.epfBase.toFixed(2),
        r.employerEtf3.toFixed(2)
    ]);

    const totalBase = payrollRecords.reduce((acc, r) => acc + r.epfBase, 0).toFixed(2);
    const totalEtf = payrollRecords.reduce((acc, r) => acc + r.employerEtf3, 0).toFixed(2);
    rows.push(['"TOTAL"', `"${monthStr}"`, '""', '""', `"${payrollRecords.length} Employees"`, totalBase, totalEtf]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
}

/**
 * Generates Corporate Bank Bulk Salary Direct-Debit file (SLIPS / CEFT format).
 * Compatible with Commercial Bank, Sampath Bank, BOC, HNB corporate internet banking.
 */
export function generateBankBulkTransferCSV(payrollRecords, corporateAccount = '10002938471', paymentDate = '') {
    const headers = [
        'Beneficiary Name',
        'Beneficiary Bank',
        'Branch Code',
        'Account Number',
        'Net Amount (LKR)',
        'Payment Reference',
        'Originating Account'
    ];

    const rows = payrollRecords.map(r => [
        `"${r.empName.replace(/"/g, '""')}"`,
        `"${r.bankName || 'Commercial Bank'}"`,
        `"${r.bankBranch || '001'}"`,
        `"${r.bankAccount || '0000000000'}"`,
        r.netSalary.toFixed(2),
        `"SALARY ${r.month}"`,
        `"${corporateAccount}"`
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
}

/**
 * Generates an official, printable HTML / PDF Payslip with Sri Lanka compliance breakdown.
 */
export function generatePayslipHTML(record, companyInfo = {}) {
    const companyName = companyInfo.name || companyInfo.storeName || 'MEC BOOK SHOP';
    const companyAddress = companyInfo.address || 'Colombo, Sri Lanka';
    const companyPhone = companyInfo.phone || '+94 11 234 5678';

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Payslip - ${record.empName} - ${record.month}</title>
    <style>
        * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        body { margin: 0; padding: 24px; background: #fff; color: #1e293b; font-size: 13px; line-height: 1.4; }
        .payslip-container { max-width: 780px; margin: 0 auto; border: 1.5px solid #0f172a; border-radius: 12px; padding: 24px; }
        .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 16px; margin-bottom: 16px; }
        .company-title { font-size: 20px; font-weight: 900; color: #0f172a; letter-spacing: 0.5px; }
        .company-sub { font-size: 11px; color: #64748b; margin-top: 2px; }
        .slip-title { text-align: right; }
        .slip-badge { background: #0f172a; color: #fff; padding: 4px 12px; border-radius: 6px; font-size: 12px; font-weight: 800; display: inline-block; }
        .emp-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-bottom: 20px; font-size: 12px; }
        .emp-grid div { display: flex; justify-content: space-between; padding: 2px 0; }
        .emp-grid strong { color: #475569; }
        .table-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; }
        th { background: #f1f5f9; padding: 8px 10px; text-align: left; font-weight: 800; border-bottom: 1.5px solid #cbd5e1; }
        td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; }
        .amount { text-align: right; font-variant-numeric: tabular-nums; font-weight: 600; }
        .total-row { font-weight: 800; background: #f8fafc; border-top: 1.5px solid #cbd5e1; }
        .net-pay-banner { background: #0f172a; color: #fff; border-radius: 8px; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .net-label { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
        .net-amount { font-size: 24px; font-weight: 900; color: #38bdf8; }
        .employer-stat-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; font-size: 11.5px; }
        .footer { display: flex; justify-content: space-between; margin-top: 36px; padding-top: 16px; border-top: 1px dashed #cbd5e1; font-size: 11px; color: #64748b; }
        .sig-line { width: 180px; border-top: 1px solid #0f172a; text-align: center; padding-top: 6px; margin-top: 30px; font-weight: 600; color: #0f172a; }
        .law-note { font-size: 10px; color: #64748b; margin-top: 12px; font-style: italic; }
        @media print { body { padding: 0; } .payslip-container { border: none; } }
    </style>
</head>
<body>
    <div class="payslip-container">
        <div class="header">
            <div>
                <div class="company-title">${companyName}</div>
                <div class="company-sub">${companyAddress} • Tel: ${companyPhone}</div>
                <div class="company-sub">Sri Lanka Shop & Office Employees Act Compliant Payroll</div>
            </div>
            <div class="slip-title">
                <div class="slip-badge">OFFICIAL PAYSLIP</div>
                <div style="font-size: 12px; font-weight: 800; color: #0f172a; margin-top: 6px;">Month: ${record.month}</div>
            </div>
        </div>

        <div class="emp-grid">
            <div><strong>Employee Name:</strong> <span>${record.empName}</span></div>
            <div><strong>Employee ID:</strong> <span>${record.empRegNo}</span></div>
            <div><strong>Designation / Role:</strong> <span>${record.empRole}</span></div>
            <div><strong>EPF Membership No:</strong> <span>${record.epfNumber || 'EPF-' + record.empRegNo}</span></div>
            <div><strong>Bank & Branch:</strong> <span>${record.bankName || 'Commercial Bank'}</span></div>
            <div><strong>Account Number:</strong> <span>${record.bankAccount || '••••••••'}</span></div>
        </div>

        <div class="table-grid">
            <!-- Earnings Table -->
            <div>
                <table>
                    <thead>
                        <tr><th>EARNINGS (LKR)</th><th style="text-align:right;">AMOUNT</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>Basic Salary</td><td class="amount">${record.basicSalary.toFixed(2)}</td></tr>
                        ${record.braAllowance > 0 ? `<tr><td>Budgetary Relief Allowance</td><td class="amount">${record.braAllowance.toFixed(2)}</td></tr>` : ''}
                        ${record.colaAllowance > 0 ? `<tr><td>Cost of Living Allowance</td><td class="amount">${record.colaAllowance.toFixed(2)}</td></tr>` : ''}
                        ${record.fixedAllowance > 0 ? `<tr><td>Fixed Job Allowances</td><td class="amount">${record.fixedAllowance.toFixed(2)}</td></tr>` : ''}
                        <tr><td style="font-size: 11px; color:#0284c7; font-weight:700;">Subtotal Statutory EPF Base</td><td class="amount" style="color:#0284c7;">${record.epfBase.toFixed(2)}</td></tr>
                        ${record.commissionEarned > 0 ? `<tr><td>POS Sales Commission (${record.commissionPct}%)</td><td class="amount">${record.commissionEarned.toFixed(2)}</td></tr>` : ''}
                        ${record.payableAttendanceAllowance > 0 ? `<tr><td>Attendance Allowance ${record.allowanceProtected ? '(🛡️ Protected)' : ''}</td><td class="amount">${record.payableAttendanceAllowance.toFixed(2)}</td></tr>` : ''}
                        <tr class="total-row"><td>GROSS EARNINGS</td><td class="amount">${record.grossEarnings.toFixed(2)}</td></tr>
                    </tbody>
                </table>
            </div>

            <!-- Deductions Table -->
            <div>
                <table>
                    <thead>
                        <tr><th>DEDUCTIONS (LKR)</th><th style="text-align:right;">AMOUNT</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>EPF Employee Contribution (8%)</td><td class="amount" style="color:#dc2626;">-${record.employeeEpf8.toFixed(2)}</td></tr>
                        ${record.apitTax > 0 ? `<tr><td>APIT Income Tax (Inland Revenue)</td><td class="amount" style="color:#dc2626;">-${record.apitTax.toFixed(2)}</td></tr>` : '<tr><td style="color:#64748b;">APIT Tax (Below Taxable Slab)</td><td class="amount">0.00</td></tr>'}
                        ${record.advanceDeductions > 0 ? `<tr><td>Salary Advance / Loan Recovery</td><td class="amount" style="color:#dc2626;">-${record.advanceDeductions.toFixed(2)}</td></tr>` : ''}
                        <tr class="total-row"><td>TOTAL DEDUCTIONS</td><td class="amount" style="color:#dc2626;">-${record.totalEmployeeDeductions.toFixed(2)}</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Net Payable Banner -->
        <div class="net-pay-banner">
            <div>
                <div class="net-label">NET TAKE-HOME PAYABLE</div>
                <div style="font-size: 11px; opacity: 0.8; margin-top: 3px;">Credited via Electronic Bank Transfer</div>
            </div>
            <div class="net-amount">LKR ${record.netSalary.toFixed(2)}</div>
        </div>

        <!-- Employer Statutory Contribution Information Box -->
        <div class="employer-stat-box">
            <div style="font-weight: 800; color: #166534; margin-bottom: 4px; display:flex; justify-content:space-between;">
                <span>🛡️ EMPLOYER STATUTORY CONTRIBUTIONS (NOT DEDUCTED FROM EMPLOYEE)</span>
                <span>TOTAL REMITTED: LKR ${record.totalStatutoryContribution.toFixed(2)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; color: #15803d; font-size: 11px;">
                <span>EPF Employer 12%: <strong>LKR ${record.employerEpf12.toFixed(2)}</strong></span>
                <span>ETF Employer 3%: <strong>LKR ${record.employerEtf3.toFixed(2)}</strong></span>
                <span>Total Statutory EPF/ETF (23%): <strong>LKR ${record.totalStatutoryContribution.toFixed(2)}</strong></span>
                <span>Total Company Employment Cost: <strong>LKR ${record.totalCompanyCost.toFixed(2)}</strong></span>
            </div>
        </div>

        <div class="law-note">
            * Note on Attendance Allowance: Certified medical leave under Sri Lanka Shop & Office Employees Act protects the monthly attendance allowance from deduction.
        </div>

        <div class="footer">
            <div class="sig-line">Prepared By (HR / Accounts)</div>
            <div style="text-align: center; align-self: flex-end;">
                <div style="font-weight: 700; color: #0f172a;">MEC POS ZENITH ERP</div>
                <div style="font-size: 9.5px;">System Generated Certified Slip</div>
            </div>
            <div class="sig-line">Employee Signature</div>
        </div>
    </div>
</body>
</html>
    `;
}
