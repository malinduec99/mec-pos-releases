import { db } from '../firebase.js';
import { GoogleGenerativeAI } from "@google/generative-ai";
import { 
    collection, 
    onSnapshot, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    writeBatch, 
    doc, 
    setDoc,
    serverTimestamp,
    query,
    orderBy,
    limit,
    where
} from "firebase/firestore";
import { saveOfflineCache, loadOfflineCache } from './cacheManager.js';

const productsCol = collection(db, 'products');
const categoriesCol = collection(db, 'categories');

/**
 * Merchant Isolated Structured SKU Generator:
 * Example requested format: MECbookshop-[SUPPLIER]-[CATEGORY]-[PRODUCT_SHORTCODE_OR_NAME]
 * e.g., MECbookshop-SUPATLAS-STAT-00040 or MECbookshop-ATLA-ATLA-80P
 */
window.generateStructuredSKU = (data) => {
    // 1. Store Identifier (Default: MECbookshop or current store slug)
    const storeSlug = (data.storeSlug || window.currentStoreSlug || 'MECbookshop').toString().trim().replace(/[^A-Za-z0-9]/g, '') || 'MECbookshop';

    // 2. Supplier Code (First 4-6 uppercase chars)
    let supRaw = (data.supplierName || data.supplierId || 'SUPGEN').toString().trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (supRaw.startsWith('SUP')) supRaw = supRaw.substring(3);
    const supCode = (supRaw || 'GEN').substring(0, 5).padEnd(4, 'X');

    // 3. Category Code (First 4 uppercase chars)
    const catCode = (data.category || 'GEN').toString().trim().toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 4).padEnd(4, 'X');

    // 4. Product Short Code or Clean Name Slug
    let prodCode = '';
    if (data.shortCode || data.itemCode || data.code) {
        prodCode = (data.shortCode || data.itemCode || data.code).toString().trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    }
    if (!prodCode) {
        // Fallback: extract last number or product initials/name slug
        const matchNum = (data.name || '').match(/\d+[a-zA-Z]*/g);
        if (matchNum && matchNum.length > 0) {
            prodCode = matchNum.join('');
        } else {
            prodCode = (data.name || 'ITEM').toString().trim().toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 6);
        }
    }

    return `${storeSlug}-${supCode}-${catCode}-${prodCode}`;
};

window.initInventory = async () => {
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';
    
    // Instant Load from Local Disk Cache before Firestore network resolves
    try {
        const cachedProds = await loadOfflineCache('products');
        if (cachedProds && Array.isArray(cachedProds) && cachedProds.length > 0 && (!window.allProducts || window.allProducts.length === 0)) {
            console.log(`⚡ [LocalDiskCache] Instantly pre-loaded ${cachedProds.length} products from local disk.`);
            window.allProducts = cachedProds;
            if (typeof window.renderAdminProductsUI === 'function') window.renderAdminProductsUI(cachedProds);
            if (typeof window.renderPOSBill === 'function') window.renderPOSBill();
        }
    } catch (cacheErr) {
        console.warn("[LocalDiskCache] Pre-load error:", cacheErr);
    }

    const prodQ = isMaster ? productsCol : query(productsCol, where('storeId', '==', storeId));
    onSnapshot(prodQ, (snapshot) => {
        const prods = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id, docId: doc.id, sku: doc.data().sku || doc.id }));
        
        // Auto-create "Other" product if it doesn't exist for mec-book-shop
        const isMECBookShop = storeId === 'mec-book-shop' || storeId === 'O8ywuZTKSwdL4z77RQ9M' || isMaster;
        if (isMECBookShop && snapshot.docs.length > 0) {
            const hasOther = prods.some(p => p.name && p.name.trim().toLowerCase() === 'other');
            if (!hasOther) {
                console.log("Auto-creating 'Other' product for MEC Book Shop...");
                const otherProduct = {
                    name: "Other",
                    sku: "SKU-OTHER-0000-GEN-P1C0",
                    category: "Uncategorized",
                    mode: "Shop",
                    supplierId: "General",
                    supplierName: "General",
                    cost: 0,
                    price: 1,
                    wholesalePrice: 1,
                    loyaltyPrice: 1,
                    discount: 0,
                    stock: 999999,
                    wStock: 0,
                    totalStock: 999999,
                    timestamp: serverTimestamp(),
                    salesToday: 0,
                    image: "",
                    variants: [],
                    payMethods: {
                        cod: true,
                        bank: true,
                        shop: true
                    },
                    storeId: storeId
                };
                otherProduct.docId = otherProduct.sku;
                setDoc(doc(db, 'products', otherProduct.sku), otherProduct)
                    .then(() => console.log("Other product created successfully"))
                    .catch(err => console.error("Error creating 'Other' product:", err));
            }
        }

        window.allProducts = prods;
        const currentTab = window.currentActiveTab || '';
        const isPosActive = currentTab === 'pos' || document.body.classList.contains('pos-fullscreen-mode');

        // Only render heavy admin inventory table if user is actually on products/stock tab
        if (!isPosActive && (currentTab === 'products' || currentTab === 'stock' || currentTab === '')) {
            if (typeof window.renderAdminProductsUI === 'function') window.renderAdminProductsUI(prods);
        }
        
        // ⚡ REALTIME LOCAL DISK & DESKTOP CACHE SYNC ⚡
        // Saves instantly to C# Desktop 'mecpos bacup/MEC_PRODUCTS_CACHE.json' and local disk
        saveOfflineCache('products', prods);
        try {
            localStorage.setItem('mecpos_local_products_count', prods.length);
            localStorage.setItem('mecpos_local_products_synced_at', new Date().toISOString());
        } catch (e) {}
        
        // Ensure POS Terminal updates catalog without interrupting user's typing or billing
        if (isPosActive) {
            const posSearchInput = document.getElementById('pos-search');
            const isUserTyping = posSearchInput && document.activeElement === posSearchInput && posSearchInput.value.trim().length > 0;
            const activeBill = typeof window.getActiveBill === 'function' ? window.getActiveBill() : null;
            const hasActiveItems = activeBill && activeBill.items && activeBill.items.length > 0;

            if (!isUserTyping && typeof window.handlePOSSearch === 'function') {
                window.handlePOSSearch(posSearchInput ? posSearchInput.value || '' : '');
            }
            // Only re-render bill if bill items are empty, preventing mid-transaction UI stutter or input blur
            if (!hasActiveItems && typeof window.renderPOSBill === 'function') {
                window.renderPOSBill();
            }
        }
    }, (error) => {
        console.error("🔥 Firestore Inventory Error:", error);
        window.showToast("Cloud Sync Error: " + error.message, "error");
    });

    const catQ = isMaster ? categoriesCol : query(categoriesCol, where('storeId', '==', storeId));
    onSnapshot(catQ, (snapshot) => {
        const cats = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allCategories = cats;
        if (typeof window.renderAdminCategoriesUI === 'function') window.renderAdminCategoriesUI(cats);
        if (typeof window.renderCategoryWholesaleRules === 'function') window.renderCategoryWholesaleRules();
    });
    window.initAlphabetSidebar();

    // Bind form submission
    const prodForm = document.getElementById('product-form');
    if (prodForm) {
        prodForm.onsubmit = window.saveProduct;
    }
}window.getMerchantDefaultLogo = () => {
    // 1. If merchant uploaded custom logo in settings or storeInfo
    const customLogo = window.systemConfig?.storeLogoUrl || window.systemConfig?.logoUrl || window.storeInfo?.logoUrl || window.currentStoreData?.logoUrl;
    if (customLogo && customLogo.trim() !== '' && !customLogo.includes('zenith_logo.png') && !customLogo.includes('/logo.png')) {
        return customLogo;
    }
    return '/mec-logo.png';
};

window.renderAdminProductsUI = (products) => {
    const productsDiv = document.getElementById('admin-product-list');
    if (!productsDiv) return;
    
    // Always ensure alphabet sidebar is ready
    if (typeof window.initAlphabetSidebar === 'function') window.initAlphabetSidebar();

    const searchInput = document.getElementById('admin-product-search');
    const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const canEdit = true;
    const canDelete = true;

    // Globalization for alphabet filter
    window._adminProductLetterFilter = window._adminProductLetterFilter || '';

    let filtered = (products || []).filter(p => p.status !== 'Void' && p.isVoid !== true);

    // 1. Filter by letter (Sidebar)
    if (window._adminProductLetterFilter) {
        filtered = filtered.filter(p => (p.name || '').toUpperCase().startsWith(window._adminProductLetterFilter));
    }

    // 2. Filter by search term (Text Box)
    if (searchTerm) {
        filtered = filtered.filter(p => 
            (p.name || '').toLowerCase().includes(searchTerm) ||
            (p.category || '').toLowerCase().includes(searchTerm) ||
            (p.description || '').toLowerCase().includes(searchTerm) ||
            window.matchProductSku(p.sku, searchTerm) ||
            (p.variants || []).some(v => window.matchProductSku(v.sku, searchTerm))
        );
    }

    // --- [MOD] Grouping Logic for Product Master ---
    const groupedMap = new Map();
    filtered.forEach(p => {
        const key = (p.name || 'Unnamed').trim();
        if (!groupedMap.has(key)) {
            groupedMap.set(key, {
                name: key,
                category: p.category,
                image: p.image,
                mode: p.mode,
                variants: [p]
            });
        } else {
            groupedMap.get(key).variants.push(p);
        }
    });    const displayGroups = Array.from(groupedMap.values())
        .sort((a, b) => a.name.localeCompare(b.name));

    const totalGroups = displayGroups.length;

    // Global pagination state for inventory
    window._adminInventoryPage = window._adminInventoryPage || 1;
    window._adminInventoryPageSize = window._adminInventoryPageSize || 50;

    const rawPageSize = window._adminInventoryPageSize;
    const isShowAll = rawPageSize === 'all' || rawPageSize === 'All' || rawPageSize === 0;
    const pageSize = isShowAll ? Math.max(1, totalGroups) : (parseInt(rawPageSize, 10) || 50);
    const totalPages = Math.max(1, Math.ceil(totalGroups / pageSize));

    // Adjust page number if filters reduce results below current page
    if (window._adminInventoryPage > totalPages) {
        window._adminInventoryPage = totalPages;
    }
    if (window._adminInventoryPage < 1) {
        window._adminInventoryPage = 1;
    }

    const currentPage = window._adminInventoryPage;
    const startIndex = isShowAll ? 0 : (currentPage - 1) * pageSize;
    const endIndex = isShowAll ? totalGroups : Math.min(startIndex + pageSize, totalGroups);
    const itemsToDisplay = isShowAll ? displayGroups : displayGroups.slice(startIndex, endIndex);

    if (totalGroups === 0) {
        productsDiv.innerHTML = `<div style="grid-column: 1/-1; padding: 4rem; text-align: center; color: var(--text-muted);">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
            <p>No products found matching your criteria</p>
            <button onclick="window.setProductLetterFilter(''); if(document.getElementById('admin-product-search')) document.getElementById('admin-product-search').value='';" style="background:none; border:none; color:var(--primary-blue); cursor:pointer; text-decoration:underline; font-weight:bold; margin-top:10px;">Clear all filters</button>
        </div>`;
        return;
    }

    const defaultMerchantLogo = window.getMerchantDefaultLogo();

    // Helper to generate page buttons
    const generatePageButtons = () => {
        let pages = [];
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, currentPage + 2);

        if (startPage > 1) {
            pages.push(`<button onclick="window.changeInventoryPage(1)" style="padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;cursor:pointer;font-weight:700;">1</button>`);
            if (startPage > 2) {
                pages.push(`<span style="color:#64748b;padding:0 4px;">...</span>`);
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            const isActive = i === currentPage;
            pages.push(`<button onclick="window.changeInventoryPage(${i})" style="padding:6px 12px;background:${isActive ? '#38bdf8' : 'rgba(255,255,255,0.05)'};border:1px solid ${isActive ? '#38bdf8' : 'rgba(255,255,255,0.1)'};color:${isActive ? '#0f172a' : '#fff'};border-radius:8px;cursor:pointer;font-weight:800;">${i}</button>`);
        }

        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                pages.push(`<span style="color:#64748b;padding:0 4px;">...</span>`);
            }
            pages.push(`<button onclick="window.changeInventoryPage(${totalPages})" style="padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;cursor:pointer;font-weight:700;">${totalPages}</button>`);
        }

        return pages.join('');
    };

    const paginationBarHTML = `
        <tr style="background: rgba(15, 23, 42, 0.95); border-top: 1px solid rgba(56, 189, 248, 0.2);">
            <td colspan="1" style="padding: 12px 16px;">
                <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:12px;">
                    <!-- Status summary -->
                    <div style="font-size:0.85rem; color:#94a3b8; font-weight:600;">
                        Showing <span style="color:#38bdf8; font-weight:800;">${totalGroups === 0 ? 0 : startIndex + 1} - ${endIndex}</span> of <span style="color:#38bdf8; font-weight:800;">${totalGroups}</span> products
                    </div>

                    <!-- Pagination Controls -->
                    <div style="display:flex; align-items:center; gap:6px;">
                        <button onclick="window.changeInventoryPage(${currentPage - 1})" ${currentPage <= 1 || isShowAll ? 'disabled style="opacity:0.4;cursor:not-allowed;padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;"' : 'style="padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;cursor:pointer;font-weight:700;"'}>
                            ◀ Previous
                        </button>
                        
                        ${isShowAll ? `<span style="color:#38bdf8;font-weight:800;font-size:0.85rem;padding:0 8px;">All Items</span>` : generatePageButtons()}

                        <button onclick="window.changeInventoryPage(${currentPage + 1})" ${currentPage >= totalPages || isShowAll ? 'disabled style="opacity:0.4;cursor:not-allowed;padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;"' : 'style="padding:6px 12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;border-radius:8px;cursor:pointer;font-weight:700;"'}>
                            Next ▶
                        </button>
                    </div>

                    <!-- Items per page selector -->
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:0.8rem; color:#94a3b8; font-weight:600;">Per page:</span>
                        <select onchange="window.changeInventoryPageSize(this.value)" style="background:#0f172a; border:1px solid rgba(56, 189, 248, 0.3); color:#fff; padding:5px 8px; border-radius:8px; font-weight:700; font-size:0.8rem; cursor:pointer; outline:none;">
                            <option value="25" ${pageSize === 25 && !isShowAll ? 'selected' : ''}>25</option>
                            <option value="50" ${pageSize === 50 && !isShowAll ? 'selected' : ''}>50</option>
                            <option value="100" ${pageSize === 100 && !isShowAll ? 'selected' : ''}>100</option>
                            <option value="200" ${pageSize === 200 && !isShowAll ? 'selected' : ''}>200</option>
                            <option value="all" ${isShowAll ? 'selected' : ''}>All (${totalGroups})</option>
                        </select>
                    </div>
                </div>
            </td>
        </tr>
    `;

    productsDiv.innerHTML = `
        <table class="admin-table" style="width: 100%; table-layout: fixed;">
            <colgroup>
                <col style="width: 100%;">
            </colgroup>
            <tbody>
                ${itemsToDisplay.map(group => {
                    const variants = group.variants;
                    const totalStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    const totalWStock = variants.reduce((sum, v) => sum + (parseFloat(v.wStock) || 0), 0);
                    
                    const prices = variants.map(v => parseFloat(v.price) || 0);
                    const minPrice = Math.min(...prices);
                    const maxPrice = Math.max(...prices);
                    const priceDisplay = minPrice === maxPrice 
                        ? `LKR ${minPrice.toLocaleString()}` 
                        : `LKR ${minPrice.toLocaleString()} – ${maxPrice.toLocaleString()}`;

                    const firstVariant = variants[0];
                    const hasMultiple = variants.length > 1;
                    const groupMode = firstVariant.mode || 'Shop';
                    const skuDisplay = hasMultiple ? 'Multiple Variants' : ((firstVariant.sku && firstVariant.sku.startsWith('SKU-')) ? firstVariant.sku : window.generateStructuredSKU(firstVariant));

                    const stockColor  = totalStock < 5  ? '#ef4444' : '#10b981';
                    const wStockColor = totalWStock < 5 ? '#f59e0b' : '#38bdf8';

                    const itemImg = (firstVariant.image && firstVariant.image.trim() !== '' && !firstVariant.image.includes('placehold.co') && !firstVariant.image.includes('zenith_logo.png') && !firstVariant.image.includes('/logo.png'))
                        ? firstVariant.image
                        : defaultMerchantLogo;

                    return `
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.06);">
                        <td style="padding: 10px 8px; width: 100%;">
                            <div style="display:flex; align-items:flex-start; gap:12px; width:100%;">

                                <!-- Thumbnail -->
                                <div style="position:relative; flex-shrink:0; cursor:pointer;" onclick="window.openQuickImageModal('${encodeURIComponent(group.name)}', '${firstVariant.docId}')" title="Click to view large photo & change image">
                                    <img src="${itemImg}"
                                         style="width:64px; height:64px; border-radius:12px; object-fit:cover; background:#111; border:2px solid rgba(56, 189, 248, 0.3); transition: transform 0.2s, border-color 0.2s;"
                                         onmouseover="this.style.transform='scale(1.06)'; this.style.borderColor='#38bdf8';"
                                         onmouseout="this.style.transform='scale(1)'; this.style.borderColor='rgba(56, 189, 248, 0.3)';"
                                         onerror="this.src='${defaultMerchantLogo}'">
                                    ${hasMultiple ? `<span style="position:absolute;top:-7px;right:-7px;background:#3b82f6;color:#fff;font-size:0.55rem;padding:2px 5px;border-radius:8px;font-weight:900;border:2px solid #0f172a;">${variants.length} VAR</span>` : ''}
                                </div>

                                <!-- Main content: 2-zone layout (info left, controls right) -->
                                <div style="flex:1; min-width:0; display:flex; align-items:center; gap:12px; justify-content:space-between;">

                                    <!-- LEFT: name + SKU + info chips -->
                                    <div style="flex:1; min-width:0;">
                                        <div style="font-weight:900;color:#fff;font-size:1rem;line-height:1.35;word-break:break-word;margin-bottom:3px;">${group.name}</div>
                                        <div style="font-size:0.68rem;color:#38bdf8;font-family:monospace;font-weight:700;margin-bottom:6px;word-break:break-all;">${skuDisplay}</div>
                                        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:5px;">
                                            <span style="background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.25);color:#38bdf8;padding:2px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;">${groupMode === 'Service' ? '📄 Service' : groupMode === 'Warehouse' ? '📦 Warehouse' : groupMode === 'Technical' ? '🔧 Repair' : '🛒 Shop'}</span>
                                            <span style="background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.25);color:#a5b4fc;padding:2px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;">${firstVariant.category || 'Uncategorized'}</span>
                                            <span style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.25);color:#34d399;padding:2px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;">${priceDisplay}</span>
                                            <span style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:2px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;color:${stockColor};">S: ${totalStock}</span>
                                            <span style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:2px 8px;border-radius:6px;font-size:0.7rem;font-weight:700;color:${wStockColor};">W: ${totalWStock}</span>
                                        </div>
                                    </div>

                                    <!-- RIGHT: quick-edit controls panel -->
                                    <div style="display:flex;flex-direction:column;gap:7px;align-items:flex-end;flex-shrink:0;min-width:220px;">
                                        <!-- Type & Category selects -->
                                        <div style="display:flex;gap:6px;width:100%;justify-content:flex-end;">
                                            <select class="quick-edit-select" onchange="window.quickUpdateGroupMode('${encodeURIComponent(group.name)}', this.value)"
                                                style="background:rgba(15,23,42,0.8);border:1px solid rgba(56,189,248,0.2);color:white;padding:5px 8px;border-radius:8px;outline:none;cursor:pointer;font-weight:700;font-size:0.75rem;flex:1;max-width:100px;">
                                                <option value="Shop" ${groupMode==='Shop'?'selected':''}>🛒 Shop</option>
                                                <option value="Warehouse" ${groupMode==='Warehouse'?'selected':''}>📦 Warehouse</option>
                                                <option value="Service" ${groupMode==='Service'?'selected':''}>📄 Service</option>
                                                <option value="Technical" ${groupMode==='Technical'?'selected':''}>🔧 Repair</option>
                                            </select>
                                            <select class="quick-edit-select" onchange="window.quickUpdateGroupCategory('${encodeURIComponent(group.name)}', this.value)"
                                                style="background:rgba(15,23,42,0.8);border:1px solid rgba(99,102,241,0.2);color:white;padding:5px 8px;border-radius:8px;outline:none;cursor:pointer;font-weight:700;font-size:0.75rem;flex:1;max-width:115px;">
                                                <option value="">Uncategorized</option>
                                                ${(window.allCategories || []).map(c => `<option value="${c.name}" ${firstVariant.category===c.name?'selected':''}>${c.name}</option>`).join('')}
                                            </select>
                                        </div>
                                        <!-- Action buttons -->
                                        <div style="display:flex;gap:6px;width:100%;justify-content:flex-end;">
                                            <button class="icon-btn edit" onclick="window.openEditModalByName('${encodeURIComponent(group.name)}')" title="Manage Variants"
                                                style="padding:5px 14px;flex:1;display:flex;align-items:center;justify-content:center;gap:5px;font-size:0.78rem;font-weight:700;border-radius:8px;">
                                                ✏️ Edit
                                            </button>
                                            <button class="icon-btn delete" onclick="window.confirmDeleteProduct('${firstVariant.docId}')" title="Delete Product"
                                                style="padding:5px 12px;display:flex;align-items:center;justify-content:center;border-radius:8px;font-size:0.9rem;">
                                                🗑️
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </td>
                    </tr>
                `}).join('')}
                ${paginationBarHTML}
            </tbody>
        </table>
    `;
};

// Global handlers for inventory pagination
window.changeInventoryPage = (page) => {
    window._adminInventoryPage = page;
    if (typeof window.renderAdminProductsUI === 'function') {
        window.renderAdminProductsUI(window.allProducts || []);
    }
    const container = document.getElementById('admin-product-list');
    if (container) {
        container.scrollTop = 0;
    }
};

window.changeInventoryPageSize = (size) => {
    window._adminInventoryPageSize = size === 'all' ? 'all' : (parseInt(size, 10) || 50);
    window._adminInventoryPage = 1;
    if (typeof window.renderAdminProductsUI === 'function') {
        window.renderAdminProductsUI(window.allProducts || []);
    }
};

window.quickUpdateGroupMode = async (encodedName, newMode) => {
    const groupName = decodeURIComponent(encodedName);
    try {
        window.showToast(`Updating type/mode to ${newMode}...`, "info");
        const groupProducts = (window.allProducts || []).filter(p => (p.name || '').trim() === groupName);
        if (groupProducts.length === 0) return;
        
        const batch = writeBatch(db);
        groupProducts.forEach(p => {
            batch.update(doc(db, 'products', p.docId), { 
                mode: newMode
            });
        });
        await batch.commit();
        window.showToast("✅ Type/Mode updated successfully!", "success");
    } catch (err) {
        console.error("Quick Mode Update Error:", err);
        window.showToast("❌ Failed to update Type/Mode", "error");
    }
};

window.quickUpdateGroupCategory = async (encodedName, newCategory) => {
    const groupName = decodeURIComponent(encodedName);
    try {
        window.showToast(`Updating category to ${newCategory}...`, "info");
        const groupProducts = (window.allProducts || []).filter(p => (p.name || '').trim() === groupName);
        if (groupProducts.length === 0) return;
        
        const batch = writeBatch(db);
        groupProducts.forEach(p => {
            batch.update(doc(db, 'products', p.docId), { category: newCategory });
        });
        await batch.commit();
        window.showToast("✅ Category updated successfully!", "success");
    } catch (err) {
        console.error("Quick Category Update Error:", err);
        window.showToast("❌ Failed to update Category", "error");
    }
};

window.setProductLetterFilter = (letter) => {
    window._adminProductLetterFilter = letter;
    window._adminInventoryPage = 1;
    window.initAlphabetSidebar?.();
    window.renderAdminProductsUI(window.allProducts || []);
};

window.initAlphabetSidebar = () => {
    const sidebar = document.getElementById('alphabet-sidebar');
    if (!sidebar) return;
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    sidebar.innerHTML = `
        <button class="alphabet-letter ${!window._adminProductLetterFilter ? 'active' : ''}" onclick="window.setProductLetterFilter('')">ALL</button>
        ${letters.map(l => `
            <button class="alphabet-letter ${window._adminProductLetterFilter === l ? 'active' : ''}" onclick="window.setProductLetterFilter('${l}')">${l}</button>
        `).join('')}
    `;
};

let searchTimeout;
window.filterAdminProducts = (val) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        window.renderAdminProductsUI(window.allProducts || []);
    }, 250);
};

window.confirmDeleteProduct = async (docId) => {
    const product = (window.allProducts || []).find(p => p.docId === docId);
    if (!product) return;

    const docRef = doc(db, 'products', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;

    try {
        await deleteDoc(docRef);
        window.showToast("Product deleted successfully.", "info");
    } catch (e) {
        window.showToast("Error deleting product", "error");
    }
};

window.confirmDeleteVariant = async (productId, variantId) => {
    const product = (window.allProducts || []).find(p => p.docId === productId);
    if (!product) return window.showToast('Product not found', 'error');

    if (!await window.verifyDeletePermission()) return;

    const pRef = doc(db, 'products', productId);
    const variants = product.variants || [];
    const variantIndex = variants.findIndex(v => v.variantId === variantId);
    
    if (variantIndex > -1) {
        const deletedVariant = variants[variantIndex];
        const newVariants = variants.filter(v => v.variantId !== variantId);
        const newTotalStock = Math.max(0, (parseFloat(product.totalStock || product.stock || 0)) - (parseFloat(deletedVariant.stock) || 0));

        try {
            await updateDoc(pRef, {
                variants: newVariants,
                stock: newTotalStock,
                totalStock: newTotalStock,
                lastUpdated: Date.now()
            });
            window.showToast("Variant deleted successfully.", "success");
            
            // Re-render UI if modal is open
            if (document.getElementById('product-form-modal')?.style.display === 'flex') {
                window.openEditModal(productId, false);
            }
        } catch (e) {
            console.error(e);
            window.showToast("Error deleting variant", "error");
        }
    } else {
        window.showToast("Variant not found", "error");
    }
};

window.openAddProductModal = () => {
    const modal = document.getElementById('product-form-modal');
    if (!modal) return;
    document.getElementById('product-form').reset();
    document.getElementById('variant-list').innerHTML = '';
    document.getElementById('edit-variant-list').innerHTML = '';
    
    // Clear image previews and AI image cache
    window.lastGeneratedAIImage = "";
    window.lastEditGeneratedAIImage = "";
    const pPreview = document.getElementById('p-image-preview');
    if(pPreview) pPreview.innerHTML = '';
    const epPreview = document.getElementById('edit-p-image-preview');
    if(epPreview) epPreview.innerHTML = '';
    
    // Populate categories in modal
    const catSelect = document.getElementById('p-category');
    if (catSelect && window.allCategories) {
        catSelect.innerHTML = window.allCategories.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
    }

    // Populate suppliers in modal
    const supSelect = document.getElementById('p-supplier');
    if (supSelect) {
        const optionsHtml = (window.allSuppliers || []).map(s => `<option value="${s.docId || s.id}">${s.name}</option>`).join('');
        supSelect.innerHTML = '<option value="">None / General</option>' + optionsHtml;
    }
    
    const modeSelect = document.getElementById('p-mode');
    if (modeSelect) {
        modeSelect.value = 'Shop';
        if (typeof window.toggleStockVisibility === 'function') {
            window.toggleStockVisibility('Shop', 'p-stock');
        }
    }
    
    modal.style.display = 'flex';
    document.getElementById('p-name').focus();
};

window.resizeImageToBase64 = (file, maxSize = 1000) => {
    return new Promise((resolve) => {
        if (!file) {
            resolve('');
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                if (width > height) {
                    if (width > maxSize) { height = Math.round(height * (maxSize / width)); width = maxSize; }
                } else {
                    if (height > maxSize) { width = Math.round(width * (maxSize / height)); height = maxSize; }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.imageSmoothingEnabled = true;
                ctx.imageSmoothingQuality = 'high';
                ctx.drawImage(img, 0, 0, width, height);
                // Convert to crisp, high-quality compressed WebP with 0.88 quality
                let webpUrl = canvas.toDataURL('image/webp', 0.88);
                // Fallback to JPEG 0.88 if browser doesn't support canvas WebP export
                if (!webpUrl.startsWith('data:image/webp')) {
                    webpUrl = canvas.toDataURL('image/jpeg', 0.88);
                }
                resolve(webpUrl);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
};

window.extractVariantsFromDOM = async (listId) => {
    const list = document.getElementById(listId);
    if (!list) return [];
    const rows = list.querySelectorAll('.variant-row');
    const variants = [];
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const vIdInput = row.querySelector('.v-id');
        const vId = vIdInput ? vIdInput.value : `VAR-${Math.floor(Math.random()*10000)}`;
        const vSupplierSelect = row.querySelector('.v-supplier');
        const vSupplier = vSupplierSelect ? vSupplierSelect.value : 'General';
        const vNameInput = row.querySelector('.v-name');
        const vName = vNameInput ? vNameInput.value : (document.getElementById('p-name')?.value || document.getElementById('edit-p-name')?.value || 'Default');
        const vSizeRaw = row.querySelector('.v-size').value;
        const vSize = vSizeRaw === '__other__' ? (row.querySelector('.v-size-custom')?.value?.trim() || '') : vSizeRaw;
        const vColorRaw = row.querySelector('.v-color').value;
        const vColor = vColorRaw === '__other__' ? (row.querySelector('.v-color-custom')?.value?.trim() || '') : vColorRaw;
        const vCost = Math.round((parseFloat(row.querySelector('.v-cost').value) || 0) * 1000) / 1000;
        const vPrice = Math.round((parseFloat(row.querySelector('.v-price').value) || 0) * 1000) / 1000;
        const vWholesale = Math.round((parseFloat(row.querySelector('.v-wholesale').value) || 0) * 1000) / 1000;
        const vLoyalty = Math.round((parseFloat(row.querySelector('.v-loyalty').value) || 0) * 1000) / 1000;
        const vStock = parseInt(row.querySelector('.v-stock').value) || 0;
        
        let imageBase64 = '';
        const fileInput = row.querySelector('.v-image-upload');
        if (fileInput && fileInput.files && fileInput.files.length > 0) {
            // High-resolution variant image (1000px HD)
            imageBase64 = await window.resizeImageToBase64(fileInput.files[0], 1000);
        } else if (row.dataset.existingImage) {
            imageBase64 = row.dataset.existingImage;
        } else if (window._variantImageCache && window._variantImageCache.get(row)) {
            imageBase64 = window._variantImageCache.get(row);
        }

        // Construct a clear variant label for POS
        let variantLabel = "";
        if (vSize && vColor) variantLabel = `${vSize} / ${vColor}`;
        else if (vSize) variantLabel = vSize;
        else if (vColor) variantLabel = vColor;
        else if (vPrice > 0) variantLabel = `Batch @ LKR ${vPrice}`;
        else variantLabel = vName;

        variants.push({
            variantId: vId,
            supplierName: vSupplier,
            name: vName, // used by frontend
            variantLabel: variantLabel, // used by POS selection
            size: vSize,
            color: vColor,
            cost: vCost, // used by frontend
            buyingPrice: vCost, // used by POS
            price: vPrice, // used by frontend
            sellingPrice: vPrice, // used by POS
            wholesalePrice: vWholesale,
            loyaltyPrice: vLoyalty,
            stock: vStock,
            image: imageBase64,
            addedDate: Date.now()
        });
    }
    return variants;
};

window.saveProduct = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    
    try {
        const name = document.getElementById('p-name').value;
        const sku = document.getElementById('p-sku').value || `MEC-${Date.now()}`;
        const category = document.getElementById('p-category').value;
        const mode = document.getElementById('p-mode').value;
        const supSelect = document.getElementById('p-supplier');
        const supplierId = supSelect.value;
        const supplierName = supplierId ? supSelect.options[supSelect.selectedIndex].text : 'General';

        let baseImage = '';
        const baseFileInput = document.getElementById('p-image');
        if (baseFileInput && baseFileInput.files && baseFileInput.files.length > 0) {
            baseImage = await window.resizeImageToBase64(baseFileInput.files[0], 400);
        } else if (window.lastGeneratedAIImage) {
            baseImage = window.lastGeneratedAIImage;
        }

        const extractedVariants = await window.extractVariantsFromDOM('variant-list');
        
        let productData = {
            name,
            sku: sku,
            category,
            mode,
            size: document.getElementById('p-size')?.value || '',
            color: document.getElementById('p-color')?.value || '',
            supplierId,
            supplierName,
            cost: Math.round((parseFloat(document.getElementById('p-cost').value) || 0) * 1000) / 1000,
            price: Math.round((parseFloat(document.getElementById('p-price').value) || 0) * 1000) / 1000,
            wholesalePrice: Math.round((parseFloat(document.getElementById('p-wholesale-price').value) || 0) * 1000) / 1000,
            loyaltyPrice: Math.round((parseFloat(document.getElementById('p-loyalty-price').value) || 0) * 1000) / 1000,
            discount: Math.round((parseFloat(document.getElementById('p-discount').value) || 0) * 1000) / 1000,
            stock: parseFloat(document.getElementById('p-stock').value) || 0,
            wStock: parseFloat(document.getElementById('p-wstock').value) || 0,
            timestamp: serverTimestamp(),
            salesToday: 0,
            image: baseImage,
            variants: extractedVariants,
            payMethods: {
                cod: document.getElementById('p-pay-cod')?.checked ?? true,
                bank: document.getElementById('p-pay-bank')?.checked ?? true,
                shop: document.getElementById('p-pay-shop')?.checked ?? true
            }
        };

        // Auto-generate structured SKU if it's the default format
        if (productData.sku.startsWith('MEC-')) {
            productData.sku = window.generateStructuredSKU(productData);
        }
        productData.totalStock = productData.stock + productData.wStock;

        // If variants exist, recalculate total stock from variants
        if (extractedVariants.length > 0) {
            productData.totalStock = extractedVariants.reduce((sum, v) => sum + v.stock, 0);
            productData.stock = productData.totalStock; // Align base stock with total variant stock
        }

        window.showToast("🚀 Creating product...", "info");
        productData.storeId = window.getStoreId();
        
        // Use the structured SKU prefixed with storeId as the actual Firestore document ID to prevent multi-merchant collisions
        const cleanSku = productData.sku.trim().replace(/\//g, '_');
        const docId = `${productData.storeId}_${cleanSku}`;
        const docRef = doc(productsCol, docId);
        productData.docId = docId; // Ensure docId field is set to unique ID
        productData.sku = productData.sku.trim(); // Keep original in SKU property
        await setDoc(docRef, productData);
        
        window.showToast("✅ Product published successfully!", "success");
        document.getElementById('product-form-modal').style.display = 'none';
        
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving product", "error");
    }
};

window.updateProduct = async function(e) {
    if (e && e.preventDefault) e.preventDefault();
    
    const docId = window.currentEditingId;
    const groupName = window.currentEditingGroupName;

    if (!docId && !groupName) {
        console.error("No product or group selected for update");
        return;
    }

    try {
        const category = document.getElementById('edit-p-category')?.value || '';
        const mode = document.getElementById('edit-p-mode')?.value || 'Shop';
        const supSelect = document.getElementById('edit-p-supplier');
        const supplierId = supSelect ? supSelect.value : '';
        const supplierName = (supSelect && supSelect.selectedIndex >= 0) ? supSelect.options[supSelect.selectedIndex].text : '';
        const name = document.getElementById('edit-p-name')?.value.trim() || groupName || '';

        let baseImage = '';
        const baseFileInput = document.getElementById('edit-p-image');
        if (baseFileInput && baseFileInput.files && baseFileInput.files.length > 0) {
            baseImage = await window.resizeImageToBase64(baseFileInput.files[0], 400);
        } else if (window.lastEditGeneratedAIImage) {
            baseImage = window.lastEditGeneratedAIImage;
        }

        const extractedVariants = await window.extractVariantsFromDOM('edit-variant-list');

        // Sanitization helper
        const sanitize = (obj) => {
            const clean = { ...obj };
            Object.keys(clean).forEach(key => {
                if (clean[key] === undefined) delete clean[key];
            });
            return clean;
        };

        if (docId) {
            // INDIVIDUAL PRODUCT UPDATE
            let updates = {
                name,
                category,
                mode,
                supplierId,
                supplierName,
                size: document.getElementById('edit-p-size')?.value || '',
                color: document.getElementById('edit-p-color')?.value || '',
                sku: document.getElementById('edit-p-sku')?.value.trim() || '',
                expiryDate: document.getElementById('edit-p-expiry')?.value || '',
                cost: Math.round((parseFloat(document.getElementById('edit-p-cost')?.value) || 0) * 1000) / 1000,
                price: Math.round((parseFloat(document.getElementById('edit-p-price')?.value) || 0) * 1000) / 1000,
                wholesalePrice: (parseFloat(document.getElementById('edit-p-wholesale-price')?.value) || 0) > 0
                    ? Math.round((parseFloat(document.getElementById('edit-p-wholesale-price')?.value) || 0) * 1000) / 1000
                    : Math.round((Math.round((parseFloat(document.getElementById('edit-p-price')?.value) || 0) * 1000) / 1000 * (1 - (parseFloat(window.systemConfig?.wholesaleDiscount) || 0) / 100)) * 1000) / 1000,
                loyaltyPrice: (parseFloat(document.getElementById('edit-p-loyalty-price')?.value) || 0) > 0
                    ? Math.round((parseFloat(document.getElementById('edit-p-loyalty-price')?.value) || 0) * 1000) / 1000
                    : Math.round((Math.round((parseFloat(document.getElementById('edit-p-price')?.value) || 0) * 1000) / 1000 * (1 - (parseFloat(window.systemConfig?.loyaltyDiscount) || 0) / 100)) * 1000) / 1000,
                discount: Math.round((parseFloat(document.getElementById('edit-p-discount')?.value) || 0) * 1000) / 1000,
                stock: parseInt(document.getElementById('edit-p-stock')?.value) || 0,
                wStock: parseInt(document.getElementById('edit-p-wstock')?.value) || 0,
                payMethods: {
                    cod: document.getElementById('edit-p-pay-cod')?.checked ?? true,
                    bank: document.getElementById('edit-p-pay-bank')?.checked ?? true,
                    shop: document.getElementById('edit-p-pay-shop')?.checked ?? true
                }
            };
            updates.totalStock = (updates.stock || 0) + (updates.wStock || 0);

            if (baseImage) updates.image = baseImage;

            const existingProduct = (window.allProducts || []).find(p => p.docId === docId);
            const existingVariants = existingProduct ? (existingProduct.variants || []) : [];
            
            // If there's an existing variants array OR extracted variants, we update the array to whatever is in the DOM
            if (existingVariants.length > 0 || extractedVariants.length > 0) {
                updates.variants = extractedVariants.map(v => sanitize(v));
                const variantStockSum = updates.variants.reduce((sum, v) => sum + (v.stock || 0), 0);
                // If variants have their own explicit positive stocks, use that sum. Otherwise, retain the main entered Shop Stock!
                if (variantStockSum > 0) {
                    updates.totalStock = variantStockSum;
                    updates.stock = variantStockSum;
                } else {
                    // Variants share the main entered Shop Stock
                    updates.totalStock = (updates.stock || 0) + (updates.wStock || 0);
                }
            }

            window.showToast("🚀 Updating product...", "info");
            updates.storeId = window.getStoreId();

            // Guard: check approximate document size before saving
            // Firestore limit is 1MB per document. If variant images push it over, strip them.
            const sanitizedUpdates = sanitize(updates);
            const approxSize = JSON.stringify(sanitizedUpdates).length;
            if (approxSize > 900000) {
                // Strip variant images to bring size under limit
                if (sanitizedUpdates.variants) {
                    sanitizedUpdates.variants = sanitizedUpdates.variants.map(v => ({ ...v, image: '' }));
                }
                window.showToast("⚠️ Variants saved without images (too large). Use smaller photos.", "warning");
            }

            updateDoc(doc(db, 'products', docId), sanitizedUpdates).then(() => {
                window.showToast("✅ Product & variant images saved!", "success");
            }).catch(err => {
                console.error("Firestore update product error:", err);
                window.showToast("❌ Save failed: " + err.message + " (try smaller photos)", "error");
            });
            window.closeEditModal?.();

        } else if (groupName) {
            // GROUP UPDATE (Common fields for all variants + add new variants)
            window.showToast("🚀 Updating product group...", "info");
            
            const groupProducts = (window.allProducts || []).filter(p => (p.name || '').trim() === groupName);
            const batch = writeBatch(db);
            const storeId = window.getStoreId();
            
            const commonUpdates = sanitize({
                name,
                category,
                mode,
                supplierId,
                supplierName,
                cost: Math.round((parseFloat(document.getElementById('edit-p-cost')?.value) || 0) * 1000) / 1000,
                price: Math.round((parseFloat(document.getElementById('edit-p-price')?.value) || 0) * 1000) / 1000,
                wholesalePrice: Math.round((parseFloat(document.getElementById('edit-p-wholesale-price')?.value) || 0) * 1000) / 1000,
                loyaltyPrice: Math.round((parseFloat(document.getElementById('edit-p-loyalty-price')?.value) || 0) * 1000) / 1000,
                discount: Math.round((parseFloat(document.getElementById('edit-p-discount')?.value) || 0) * 1000) / 1000,
                stock: parseInt(document.getElementById('edit-p-stock')?.value) || 0,
                wStock: parseInt(document.getElementById('edit-p-wstock')?.value) || 0,
                expiryDate: document.getElementById('edit-p-expiry')?.value || '',
                payMethods: {
                    cod: document.getElementById('edit-p-pay-cod')?.checked ?? true,
                    bank: document.getElementById('edit-p-pay-bank')?.checked ?? true,
                    shop: document.getElementById('edit-p-pay-shop')?.checked ?? true
                }
            });
            commonUpdates.totalStock = (commonUpdates.stock || 0) + (commonUpdates.wStock || 0);
            if (baseImage) commonUpdates.image = baseImage;

            groupProducts.forEach(p => {
                batch.update(doc(db, 'products', p.docId), commonUpdates);
            });

            // Add NEW variants as separate product documents with storeId prefixed document IDs
            extractedVariants.forEach(v => {
                const rawSku = v.sku || `MEC-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
                const cleanSku = rawSku.trim().replace(/\//g, '_');
                const newDocId = `${storeId}_${cleanSku}`;
                const pData = sanitize({
                    ...v,
                    ...commonUpdates,
                    docId: newDocId,
                    sku: rawSku,
                    storeId: storeId,
                    timestamp: serverTimestamp(),
                    salesToday: 0
                });
                batch.set(doc(db, 'products', newDocId), pData);
            });

            batch.commit().catch(err => {
                console.error("Firestore batch commit product error:", err);
                window.showToast("❌ Sync failed: " + err.message, "error");
            });
            window.showToast("✅ Product group updated!", "success");
            window.closeEditModal?.();
        }
    } catch (err) {
        console.error("Update Error:", err);
        window.showToast("❌ Error updating product", "error");
    }
};

// --- Bulk Upload & CSV Logic ---
// --- Bulk Upload & CSV Logic with Gemini AI ---
let genAI = null;
try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (apiKey) {
        genAI = new GoogleGenerativeAI(apiKey);
    } else {
        console.warn("VITE_GEMINI_API_KEY is missing. AI mapper will fall back to local heuristics.");
    }
} catch (e) {
    console.error("Error initializing GoogleGenerativeAI client:", e);
}

// Helper to parse CSV lines taking care of quotes
function parseCSVLine(line) {
    const result = [];
    let insideQuote = false;
    let entry = '';
    
    // Determine delimiter (comma or semicolon)
    const delimiter = line.includes(';') && !line.includes(',') ? ';' : ',';
    
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
            insideQuote = !insideQuote;
        } else if (char === delimiter && !insideQuote) {
            result.push(entry.trim());
            entry = '';
        } else {
            entry += char;
        }
    }
    result.push(entry.trim());
    return result;
}

// Heuristic fallback mapper if Gemini AI is unavailable
function getHeuristicMapping(headers) {
    const findIndex = (keywords) => {
        return headers.findIndex(h => {
            const lower = h.toLowerCase().trim();
            return keywords.some(k => lower.includes(k) || k.includes(lower));
        });
    };

    return {
        nameIndex: findIndex(['name', 'title', 'item', 'product', 'නම', 'විස්තරය']),
        skuIndex: findIndex(['sku', 'code', 'barcode', 'id', 'පච්චය', 'අංකය']),
        categoryIndex: findIndex(['category', 'type', 'group', 'කාණ්ඩය', 'වර්ගය']),
        costIndex: findIndex(['cost', 'buying', 'purchase', 'ගැනුම් මිල', 'ගැනුම්']),
        priceIndex: findIndex(['price', 'retail', 'selling', 'sellingprice', 'විකුණුම් මිල', 'මිල']),
        stockIndex: findIndex(['stock', 'qty', 'quantity', 'count', 'තොගය', 'ප්‍රමාණය'])
    };
}

// Core function to map columns using Gemini AI
async function getAIColumnMapping(headers, samples) {
    // 1. Confident check for exact/well-known column headers (case-insensitive)
    const findConfidentIndex = (exactKeywords) => {
        return headers.findIndex(h => {
            const clean = h.toLowerCase().trim();
            return exactKeywords.includes(clean);
        });
    };

    const confident = {
        nameIndex: findConfidentIndex(['name', 'product name', 'item name', 'title', 'product', 'නම']),
        skuIndex: findConfidentIndex(['sku', 'item code', 'product code', 'code', 'barcode']),
        categoryIndex: findConfidentIndex(['category', 'product group', 'productgroup', 'group', 'type']),
        costIndex: findConfidentIndex(['cost', 'cost price', 'buying price', 'purchase price']),
        priceIndex: findConfidentIndex(['price', 'retail price', 'selling price', 'retail', 'selling']),
        stockIndex: findConfidentIndex(['quantity', 'qty', 'stock', 'stock quantity', 'stock qty', 'qnty', 'on hand'])
    };

    let mapping = {
        nameIndex: -1,
        skuIndex: -1,
        categoryIndex: -1,
        costIndex: -1,
        priceIndex: -1,
        stockIndex: -1
    };

    try {
        if (genAI) {
            const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
            const systemPrompt = `You are a data processing assistant for MEC POS.
Analyze the following CSV headers and sample data from a CSV file.
Determine the 0-based index (integer) for each target field:
- nameIndex: column corresponding to Product Name/Title. (Required, must map to something, default to 0 if unsure).
- skuIndex: column corresponding to SKU, Item Code, or Barcode (default to -1 if missing).
- categoryIndex: column corresponding to Category, Department, or Type (default to -1 if missing).
- costIndex: column corresponding to Cost Price, Buying Price, or Purchase Price (default to -1 if missing).
- priceIndex: column corresponding to Retail Price, Selling Price, or Price (default to -1 if missing).
- stockIndex: column corresponding to Stock Quantity, Qty, Count, or Inventory (default to -1 if missing). IMPORTANT: Do NOT map this to settings or boolean flags like "IsUsingDefaultQuantity", "UseDefaultQuantity", "DefaultQuantity", "IsActive", "HasStock", etc. If the column represents a boolean setting rather than a numeric physical inventory stock count, return -1.

CSV Column Headers (0-based indices):
${headers.map((h, i) => `[${i}] "${h}"`).join('\n')}

First few rows of sample data:
${samples.map(row => JSON.stringify(row)).join('\n')}

Return ONLY a raw JSON object matching the structure below. Do NOT wrap it in markdown code blocks.
{
  "nameIndex": number,
  "skuIndex": number,
  "categoryIndex": number,
  "costIndex": number,
  "priceIndex": number,
  "stockIndex": number
}`;

            const result = await model.generateContent(systemPrompt);
            const response = await result.response;
            const responseText = response.text().trim();
            
            // Sanitize response to isolate JSON if AI returns markdown wrapper
            const cleanJSON = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
            mapping = JSON.parse(cleanJSON);
            console.log("Gemini AI Mapped Indices successfully:", mapping);
        } else {
            console.warn("GoogleGenerativeAI client is not initialized. Falling back to heuristic mapping.");
            mapping = getHeuristicMapping(headers);
        }
    } catch (err) {
        console.error("Gemini AI Mapping error, falling back to heuristic:", err);
        mapping = getHeuristicMapping(headers);
    }

    // Merge: If local confidence check found a confident exact match, override Gemini's selection!
    if (confident.nameIndex !== -1) mapping.nameIndex = confident.nameIndex;
    if (confident.skuIndex !== -1) mapping.skuIndex = confident.skuIndex;
    if (confident.categoryIndex !== -1) mapping.categoryIndex = confident.categoryIndex;
    if (confident.costIndex !== -1) mapping.costIndex = confident.costIndex;
    if (confident.priceIndex !== -1) mapping.priceIndex = confident.priceIndex;
    if (confident.stockIndex !== -1) mapping.stockIndex = confident.stockIndex;

    return mapping;
}

// Globally hold parsed product data to synchronize on confirm
let pendingUploadProducts = [];

window.handleCSVSelect = async (input) => {
    const file = input.files[0];
    if (!file) return;

    document.getElementById('progress-label').innerText = `📂 Selected: ${file.name}`;
    window.showToast(`Selected: ${file.name}`, "info");

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const text = e.target.result;
            const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
            if (lines.length < 2) {
                return window.showToast("CSV file must have headers and at least one row.", "warning");
            }

            const rawHeaders = parseCSVLine(lines[0]);
            const rows = lines.slice(1).map(l => parseCSVLine(l));
            const samples = rows.slice(0, 3);

            // Update status indicator
            const statusLabel = document.getElementById('ai-mapper-status');
            if (statusLabel) {
                statusLabel.innerText = "Gemini AI Mapping columns...";
                statusLabel.style.background = "#fef3c7";
                statusLabel.style.color = "#d97706";
            }

            // Get AI mapping indices
            const mapping = await getAIColumnMapping(rawHeaders, samples);
            
            // Programmatic safeguard against mapping boolean/default settings to Stock Qty
            const forbiddenStockKeywords = ['isusing', 'usedefault', 'defaultquantity', 'status', 'active', 'enable', 'disabled', 'boolean', 'flag'];
            if (mapping.stockIndex !== -1 && rawHeaders[mapping.stockIndex]) {
                const stockHeader = rawHeaders[mapping.stockIndex].toLowerCase();
                if (forbiddenStockKeywords.some(kw => stockHeader.includes(kw))) {
                    console.log(`Programmatic safeguard triggered: overriding stockIndex from ${mapping.stockIndex} to -1 because header "${rawHeaders[mapping.stockIndex]}" is a setting/flag.`);
                    mapping.stockIndex = -1;
                }
            }
            
            if (statusLabel) {
                statusLabel.innerText = "Gemini AI Mapped ✅";
                statusLabel.style.background = "#dcfce7";
                statusLabel.style.color = "#15803d";
            }

            // Build human-friendly badges
            const mappingDetailsEl = document.getElementById('ai-mapping-details');
            if (mappingDetailsEl) {
                const getLabel = (idx) => idx !== -1 ? rawHeaders[idx] : "❌ (Not Found / Defaulted)";
                
                mappingDetailsEl.innerHTML = `
                    <div style="background: rgba(14, 165, 233, 0.1); border: 1px solid rgba(14, 165, 233, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        Name ➡️ <span style="color: #0284c7;">${getLabel(mapping.nameIndex)}</span>
                    </div>
                    <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        SKU ➡️ <span style="color: #059669;">${getLabel(mapping.skuIndex)}</span>
                    </div>
                    <div style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        Category ➡️ <span style="color: #d97706;">${getLabel(mapping.categoryIndex)}</span>
                    </div>
                    <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        Cost Price ➡️ <span style="color: #dc2626;">${getLabel(mapping.costIndex)}</span>
                    </div>
                    <div style="background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        Retail Price ➡️ <span style="color: #7c3aed;">${getLabel(mapping.priceIndex)}</span>
                    </div>
                    <div style="background: rgba(100, 116, 139, 0.1); border: 1px solid rgba(100, 116, 139, 0.3); padding: 6px 12px; border-radius: 8px; font-weight: 600;">
                        Stock Qty ➡️ <span style="color: #475569;">${getLabel(mapping.stockIndex)}</span>
                    </div>
                `;
            }

            // Map and parse all products using the mapped indices
            const storeId = window.getStoreId();
            pendingUploadProducts = rows.map(cols => {
                if (cols.length === 0 || !cols[mapping.nameIndex]) return null;

                const name = cols[mapping.nameIndex];
                const sku = (mapping.skuIndex !== -1 && cols[mapping.skuIndex]) 
                            ? cols[mapping.skuIndex] 
                            : `MEC-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
                const category = (mapping.categoryIndex !== -1 && cols[mapping.categoryIndex]) 
                                 ? cols[mapping.categoryIndex] 
                                 : 'Uncategorized';
                const cost = (mapping.costIndex !== -1) ? (parseFloat(cols[mapping.costIndex]) || 0) : 0;
                const price = (mapping.priceIndex !== -1) ? (parseFloat(cols[mapping.priceIndex]) || 0) : 0;
                const stock = (mapping.stockIndex !== -1) ? (parseFloat(cols[mapping.stockIndex]) || 0) : 0;

                const pData = {
                    name,
                    sku,
                    category,
                    cost,
                    price,
                    stock,
                    totalStock: stock,
                    mode: 'Shop',
                    storeId: storeId,
                    timestamp: serverTimestamp(),
                    salesToday: 0
                };

                if (pData.sku.startsWith('MEC-')) {
                    pData.sku = window.generateStructuredSKU(pData);
                }
                pData.docId = pData.sku;
                return pData;
            }).filter(p => p !== null);

            // Populate the Preview Table
            const previewBody = document.getElementById('bulk-preview-body');
            if (previewBody) {
                previewBody.innerHTML = pendingUploadProducts.map(p => `
                    <tr>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-weight: 600; color: #1e293b;">${p.name}</td>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-family: monospace; color: #64748b;">${p.sku}</td>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; color: #475569;"><span style="background:#f1f5f9; padding: 2px 8px; border-radius: 4px; font-size:0.8rem;">${p.category}</span></td>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; text-align: right; font-weight: 700; color: #dc2626;">LKR ${p.cost.toFixed(2)}</td>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; text-align: right; font-weight: 700; color: #059669;">LKR ${p.price.toFixed(2)}</td>
                        <td style="padding: 12px 15px; border-bottom: 1px solid #f1f5f9; text-align: center; font-weight: 800; color: #1e293b;">${p.stock}</td>
                    </tr>
                `).join('');
            }

            // Set unique product count display
            const countEl = document.getElementById('bulk-preview-count');
            if (countEl) countEl.innerText = pendingUploadProducts.length;

            // Bind the Synchronize button
            const confirmBtn = document.getElementById('bulk-confirm-btn');
            if (confirmBtn) {
                confirmBtn.onclick = async () => {
                    try {
                        alert(`Starting sync for ${pendingUploadProducts.length} products...`);
                        confirmBtn.disabled = true;
                        confirmBtn.innerText = "Syncing with Database...";
                        
                        // Execute batch upload in chunks of 500 (Firestore batch limits)
                        const chunkSize = 500;
                        for (let i = 0; i < pendingUploadProducts.length; i += chunkSize) {
                            const chunk = pendingUploadProducts.slice(i, i + chunkSize);
                            const batch = writeBatch(db);
                            chunk.forEach(p => {
                                // Keep original SKU but sanitize the Firestore document path ID with storeId prefix to prevent merchant overwriting
                                const originalSku = String(p.sku).trim();
                                const cleanSku = originalSku.replace(/\//g, '_');
                                const docId = `${storeId}_${cleanSku}`;
                                if (!cleanSku) {
                                    throw new Error(`Product "${p.name}" has an empty or invalid SKU.`);
                                }
                                p.sku = originalSku; // Keep original with slash (e.g. 1/2) for screen display/barcode
                                p.docId = docId;  // Sanitized unique document ID for database path
                                const docRef = doc(productsCol, docId);
                                batch.set(docRef, p);
                            });
                            await batch.commit();
                        }
                        
                        alert("✅ Synchronize complete!");
                        window.showToast(`✅ Successfully uploaded ${pendingUploadProducts.length} products!`, "success");
                        document.getElementById('bulk-upload-preview-modal').style.display = 'none';
                        document.body.style.overflow = 'auto';
                        
                        // Reset file input
                        input.value = "";
                    } catch (err) {
                        console.error("Firebase sync error:", err);
                        alert("❌ Sync failed: " + err.message);
                        window.showToast("❌ Sync failed: " + err.message, "error");
                    } finally {
                        confirmBtn.disabled = false;
                        confirmBtn.innerText = "Confirm & Synchronize All Items";
                    }
                };
            }

            // Show the modal
            document.getElementById('bulk-upload-preview-modal').style.display = 'flex';
            document.body.style.overflow = 'hidden';

        } catch (err) {
            console.error("CSV loading error:", err);
            window.showToast("❌ Failed to parse CSV: " + err.message, "error");
        }
    };
    reader.readAsText(file);
};

window.handleBulkUpload = async () => {
    // Re-trigger file upload prompt
    const fileInput = document.getElementById('bulk-file-input');
    if (fileInput) {
        fileInput.click();
    } else {
        window.showToast("CSV Selector element not found.", "error");
    }
};


window.downloadProductsCSV = () => {
    const products = window.allProducts || [];
    let csv = "Name,SKU,Category,Cost,Retail,Stock\n";
    products.forEach(p => {
        const name = window.escapeCSV(p.name);
        const sku = window.escapeCSV(p.sku);
        const cat = window.escapeCSV(p.category);
        csv += `"${name}","${sku}","${cat}",${p.cost || 0},${p.price || 0},${p.stock || 0}\n`;
    });
    window.downloadFile?.(csv, "Products_Export.csv");
};

window.lastGeneratedAIImage = "";
window.lastEditGeneratedAIImage = "";

window.triggerAIImageSearch = async (nameInputId, previewId, fileInputId) => {
    const productNameInput = document.getElementById(nameInputId);
    const productName = productNameInput ? productNameInput.value.trim() : "";
    
    if (!productName) {
        window.showToast("⚠️ Please enter a product name first!", "warning");
        return;
    }
    
    const modal = document.getElementById('ai-image-finder-modal');
    if (!modal) return;
    
    modal.style.display = 'flex';
    document.getElementById('ai-image-search-term').innerText = productName;
    
    const loadingEl = document.getElementById('ai-image-loading');
    const resultsEl = document.getElementById('ai-image-results');
    
    loadingEl.style.display = 'flex';
    resultsEl.style.display = 'none';
    resultsEl.innerHTML = '';
    
    try {
        const unsplashSearchUrl = `https://unsplash.com/napi/search/photos?query=${encodeURIComponent(productName)}&per_page=9`;
        const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(unsplashSearchUrl)}`;
        
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("CORS Proxy request failed");
        
        const json = await response.json();
        const data = JSON.parse(json.contents);
        
        loadingEl.style.display = 'none';
        resultsEl.style.display = 'grid';
        
        if (!data || !data.results || data.results.length === 0) {
            resultsEl.innerHTML = `<div style="grid-column: span 3; text-align: center; color: #94a3b8; padding: 20px;">No images found for "${productName}". Try a different name.</div>`;
            return;
        }
        
        data.results.forEach(photo => {
            const thumbUrl = photo.urls.small || photo.urls.thumb;
            const fullUrl = photo.urls.regular;
            
            const imgContainer = document.createElement('div');
            imgContainer.style.cssText = `
                position: relative;
                border-radius: 12px;
                overflow: hidden;
                aspect-ratio: 1;
                cursor: pointer;
                border: 2px solid rgba(255,255,255,0.08);
                transition: all 0.2s ease;
            `;
            imgContainer.innerHTML = `<img src="${thumbUrl}" style="width:100%; height:100%; object-fit:cover;">`;
            
            imgContainer.onmouseover = () => {
                imgContainer.style.borderColor = '#a855f7';
                imgContainer.style.transform = 'scale(1.05)';
            };
            imgContainer.onmouseout = () => {
                imgContainer.style.borderColor = 'rgba(255,255,255,0.08)';
                imgContainer.style.transform = 'scale(1)';
            };
            
            imgContainer.onclick = async () => {
                modal.style.display = 'none';
                window.showToast("⚡ Processing AI photo selection...", "info");
                
                try {
                    const rawProxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(fullUrl)}`;
                    const imgResponse = await fetch(rawProxyUrl);
                    const blob = await imgResponse.blob();
                    
                    const reader = new FileReader();
                    reader.onloadend = () => {
                        const base64data = reader.result;
                        
                        if (nameInputId.includes('edit')) {
                            window.lastEditGeneratedAIImage = base64data;
                        } else {
                            window.lastGeneratedAIImage = base64data;
                        }
                        
                        const previewEl = document.getElementById(previewId);
                        if (previewEl) {
                            previewEl.innerHTML = `<img src="${base64data}" style="width:100px; height:100px; border-radius:12px; object-fit:cover; margin-top:10px; border:2px solid #a855f7;">`;
                        }
                        window.showToast("✅ AI Image Applied Successfully!", "success");
                    };
                    reader.readAsDataURL(blob);
                    
                } catch (err) {
                    console.error("Failed to process image:", err);
                    window.showToast("❌ Failed to download selected image.", "error");
                }
            };
            
            resultsEl.appendChild(imgContainer);
        });
        
    } catch (err) {
        console.error("AI Image search error:", err);
        loadingEl.style.display = 'none';
        resultsEl.style.display = 'block';
        resultsEl.innerHTML = `<div style="color: #ef4444; text-align: center; padding: 20px;">AI search failed. Please try again.</div>`;
    }
};

window.currentQuickImgProductGroup = null;
window.currentQuickImgDocId = null;
window.pendingQuickCompressedImage = null;

window.openQuickImageModal = (encodedGroupName, docId) => {
    try {
        const groupName = decodeURIComponent(encodedGroupName);
        window.currentQuickImgProductGroup = groupName;
        window.currentQuickImgDocId = docId;
        window.pendingQuickCompressedImage = null;

        const p = (window.allProducts || []).find(item => (docId && item.docId === docId) || item.name === groupName);
        const defaultImg = (typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png';
        const currentImg = (p && p.image && !p.image.includes('zenith_logo') && !p.image.includes('/logo.png')) ? p.image : defaultImg;
        const category   = (p && p.category) ? p.category : 'Uncategorized';
        const price      = (p && p.price)    ? `LKR ${parseFloat(p.price).toLocaleString()}` : 'LKR 0.00';

        // Remove existing overlay if any
        const existing = document.getElementById('qim-overlay');
        if (existing) existing.remove();

        // Build overlay directly on body — bypasses ALL stacking/overflow issues
        const overlay = document.createElement('div');
        overlay.id = 'qim-overlay';
        overlay.style.cssText = `
            position: fixed; inset: 0;
            width: 100vw; height: 100vh;
            background: rgba(2,6,23,0.88);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            display: flex; align-items: center; justify-content: center;
            z-index: 999999;
            padding: 16px;
            box-sizing: border-box;
            animation: qim-fadein 0.2s ease;
        `;

        overlay.innerHTML = `
            <style>
                @keyframes qim-fadein { from { opacity:0; transform: scale(0.97); } to { opacity:1; transform: scale(1); } }
                @keyframes qim-card-in { from { opacity:0; transform: translateY(24px); } to { opacity:1; transform: translateY(0); } }
                #qim-card { animation: qim-card-in 0.22s ease; }
                #qim-change-btn:hover { transform: translateY(-2px) !important; }
                #qim-save-btn:hover { transform: translateY(-2px) !important; }
            </style>
            <div id="qim-card" style="
                background: #ffffff;
                border-radius: 28px;
                overflow: hidden;
                box-shadow: 0 40px 120px rgba(0,0,0,0.7);
                width: 100%;
                max-width: 1200px;
                max-height: 90vh;
                display: flex;
                flex-wrap: wrap;
                position: relative;
                color: #0f172a;
            ">
                <!-- Close Button -->
                <button id="qim-close-btn" style="
                    position:absolute; top:16px; right:16px; z-index:10;
                    background:rgba(241,245,249,0.95); border:none; color:#475569;
                    font-size:1.5rem; width:40px; height:40px; border-radius:50%;
                    cursor:pointer; display:flex; align-items:center; justify-content:center;
                    font-weight:700; transition: all 0.2s; box-shadow:0 2px 10px rgba(0,0,0,0.12);
                " onmouseover="this.style.background='#e2e8f0'; this.style.color='#0f172a';"
                   onmouseout="this.style.background='rgba(241,245,249,0.95)'; this.style.color='#475569';">×</button>

                <!-- Left: Large Image fills entire left panel -->
                <div style="
                    flex:1.8; min-width:380px;
                    background:linear-gradient(145deg,#f0f4ff,#dde8ff);
                    display:flex; align-items:center; justify-content:center;
                    min-height:520px; position:relative; overflow:hidden;
                    cursor:pointer;
                " onclick="document.getElementById('qim-file-input').click()" title="Click to change photo">
                    <img id="qim-preview-img" src="${currentImg}" alt="Product Image"
                         style="width:100%; height:520px; object-fit:contain; padding:24px; box-sizing:border-box; transition: transform 0.3s;"
                         onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform='scale(1)'"
                         onerror="this.src='${defaultImg}'">
                    <input type="file" id="qim-file-input" accept="image/*" style="display:none;">
                </div>

                <!-- Right: Info & Controls -->
                <div style="
                    flex:1; min-width:300px; padding:40px 36px;
                    display:flex; flex-direction:column; justify-content:center; background:white;
                    border-left:1px solid #e8edf5;
                ">
                    <div style="font-size:0.72rem; font-weight:900; color:#0284c7; text-transform:uppercase; letter-spacing:1.2px; margin-bottom:10px;">
                        <span style="background:#eff6ff;padding:4px 12px;border-radius:20px;border:1px solid #bfdbfe;">${category}</span>
                    </div>
                    <h2 style="margin:0 0 14px 0; font-size:1.75rem; font-weight:900; color:#0f172a !important; -webkit-text-fill-color:#0f172a !important; line-height:1.2;">${groupName}</h2>
                    <div style="font-size:1.6rem; font-weight:900; color:#e11d48 !important; margin-bottom:24px; letter-spacing:-0.5px;">${price}</div>

                    <div style="font-size:0.83rem; color:#64748b; margin-bottom:28px; line-height:1.6; background:#f8fafc; padding:14px 16px; border-radius:14px; border:1px solid #f1f5f9;">
                        💡 Select a high-quality photo from your device. Auto-compresses to ~50KB WebP for fast cloud loading.
                    </div>

                    <div style="display:flex; flex-direction:column; gap:12px;">
                        <button id="qim-change-btn" style="
                            width:100%; padding:17px; border-radius:16px;
                            background:linear-gradient(135deg,#0ea5e9,#0284c7); color:white;
                            border:none; font-weight:800; font-size:1.05rem; cursor:pointer;
                            display:flex; align-items:center; justify-content:center; gap:8px;
                            box-shadow:0 8px 28px rgba(14,165,233,0.45); transition:transform 0.2s;
                        ">📸 Change Image</button>

                        <button id="qim-save-btn" style="
                            width:100%; padding:17px; border-radius:16px;
                            background:linear-gradient(135deg,#10b981,#059669); color:white;
                            border:none; font-weight:800; font-size:1.05rem; cursor:pointer;
                            display:none; align-items:center; justify-content:center; gap:8px;
                            box-shadow:0 8px 28px rgba(16,185,129,0.45); transition:transform 0.2s;
                        ">💾 Save New Image</button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        // Wire up events
        document.getElementById('qim-close-btn').addEventListener('click', () => overlay.remove());
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

        document.getElementById('qim-change-btn').addEventListener('click', () => {
            document.getElementById('qim-file-input').click();
        });

        document.getElementById('qim-file-input').addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            window.showToast('⚡ Auto-compressing photo...', 'info');
            const compressed = await window.resizeImageToBase64(file, 800);
            window.pendingQuickCompressedImage = compressed;
            document.getElementById('qim-preview-img').src = compressed;
            const saveBtn = document.getElementById('qim-save-btn');
            if (saveBtn) { saveBtn.style.display = 'flex'; }
            window.showToast('📸 Compressed & ready to save!', 'success');
        });

        document.getElementById('qim-save-btn').addEventListener('click', async () => {
            if (!window.pendingQuickCompressedImage) {
                window.showToast('Please select a new photo first', 'warning');
                return;
            }
            const saveBtn = document.getElementById('qim-save-btn');
            if (saveBtn) saveBtn.textContent = '⏳ Saving...';
            try {
                const matchingProducts = (window.allProducts || []).filter(pr => pr.name === groupName || pr.docId === window.currentQuickImgDocId);
                if (matchingProducts.length === 0 && window.currentQuickImgDocId) {
                    matchingProducts.push({ docId: window.currentQuickImgDocId });
                }
                const updates = matchingProducts.map(pr => {
                    pr.image = window.pendingQuickCompressedImage;
                    const productRef = doc(db, 'products', pr.docId);
                    return updateDoc(productRef, { image: window.pendingQuickCompressedImage });
                });
                await Promise.all(updates);
                window.showToast('✅ Photo updated & saved!', 'success');
                overlay.remove();
                if (typeof window.renderAdminProductsUI === 'function') {
                    window.renderAdminProductsUI(window.allProducts);
                }
            } catch (err) {
                console.error('Error saving quick image:', err);
                window.showToast('❌ Failed to save image', 'error');
                if (saveBtn) saveBtn.textContent = '💾 Save New Image';
            }
        });

    } catch (e) {
        console.error('Error opening quick image modal:', e);
    }
};

window.handleQuickImageFileSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    window.showToast("⚡ Auto-compressing photo...", "info");
    const compressedWebP = await window.resizeImageToBase64(file, 800);
    window.pendingQuickCompressedImage = compressedWebP;

    const previewImg = document.getElementById('quick-img-preview');
    const saveBtn = document.getElementById('quick-img-save-btn');

    if (previewImg) previewImg.src = compressedWebP;
    if (saveBtn) saveBtn.style.display = 'inline-flex';

    window.showToast("📸 Compressed & ready to save!", "success");
};

window.saveQuickImageChange = async () => {
    if (!window.pendingQuickCompressedImage) {
        window.showToast("Please select a new photo first", "warning");
        return;
    }

    const groupName = window.currentQuickImgProductGroup;
    const saveBtn = document.getElementById('quick-img-save-btn');
    if (saveBtn) saveBtn.innerText = '⏳ Saving...';

    try {
        const matchingProducts = (window.allProducts || []).filter(p => p.name === groupName || p.docId === window.currentQuickImgDocId);
        
        if (matchingProducts.length === 0 && window.currentQuickImgDocId) {
            matchingProducts.push({ docId: window.currentQuickImgDocId });
        }

        const updates = matchingProducts.map(p => {
            p.image = window.pendingQuickCompressedImage;
            const productRef = doc(db, 'products', p.docId);
            return updateDoc(productRef, { image: window.pendingQuickCompressedImage });
        });

        await Promise.all(updates);

        window.showToast("✅ Photo updated & saved successfully!", "success");
        document.getElementById('quick-image-modal').style.display = 'none';

        if (typeof window.renderAdminProductsUI === 'function') {
            window.renderAdminProductsUI(window.allProducts);
        }
    } catch (err) {
        console.error("Error updating quick product image:", err);
        window.showToast("❌ Failed to save image", "error");
    } finally {
        if (saveBtn) saveBtn.innerText = '💾 Save New Photo';
    }
};


