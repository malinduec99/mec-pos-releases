import './style.css'
import { GoogleGenerativeAI } from "@google/generative-ai";
import { db, auth } from './firebase.js';
import {
  collection,
  onSnapshot,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  doc,
  setDoc,
  getDocs,
  getDoc,
  serverTimestamp,
  updateDoc,
  increment,
  deleteDoc
} from "firebase/firestore";
import { onAuthStateChanged, signOut } from "firebase/auth";

// --- Global Error Logging System ---
window.uploadLogToCloud = async (message, level = 'error') => {
    try {
        const storeId = window.currentStoreId || 'unknown';
        const pcName = window.HostPCName || navigator.userAgent || 'WebBrowser';
        await addDoc(collection(db, 'systemLogs'), {
            message: message,
            level: level,
            storeId: storeId,
            pcName: pcName,
            timestamp: serverTimestamp()
        });
    } catch(e) {
        console.error("Failed to upload log:", e);
    }
};

window.addEventListener('error', (event) => {
    window.uploadLogToCloud(`Web Error: ${event.message} at ${event.filename}:${event.lineno}`, 'error');
});

window.addEventListener('unhandledrejection', (event) => {
    window.uploadLogToCloud(`Promise Rejection: ${event.reason}`, 'error');
});

// --- Theme Sync System ---
function applyStoredTheme() {
    try {
        const stored = localStorage.getItem('mecThemeColors');
        if (stored) {
            const c = JSON.parse(stored);
            const root = document.documentElement;
            
            // Admin Panel Overrides
            root.style.setProperty('--primary-blue', c.primary);
            root.style.setProperty('--accent-blue', c.accent);
            root.style.setProperty('--admin-bg', c.bg);
            root.style.setProperty('--glass-bg', c.glass);
            
            // Store Front Overrides
            root.style.setProperty('--primary-color', c.primary);
            root.style.setProperty('--secondary-color', c.accent);
            root.style.setProperty('--deep-bg', c.bg);

            if(c.bg === '#0f172a' || c.bg === '#11011c' || c.bg === '#022c22') {
                 root.style.setProperty('--text-dark', '#f8fafc');
                 root.style.setProperty('--text-muted', '#94a3b8');
            } else {
                 root.style.setProperty('--text-dark', '#0f172a');
                 root.style.setProperty('--text-muted', '#64748b');
            }
        }
    } catch(e) {}
}
applyStoredTheme();

// --- Sticky Toolbar Header Sync ---
function syncHeaderHeight() {
    const header = document.querySelector('header');
    if (header) {
        const h = header.getBoundingClientRect().height;
        document.documentElement.style.setProperty('--header-height', `${Math.round(h)}px`);
    }
    const gridHeader = document.getElementById('product-grid-header');
    if (gridHeader && header) {
        const h = header.getBoundingClientRect().height;
        const rect = gridHeader.getBoundingClientRect();
        const isStuck = rect.top <= Math.round(h) + 2;
        gridHeader.classList.toggle('is-stuck', isStuck);
    }
}
window.addEventListener('resize', syncHeaderHeight);
window.addEventListener('scroll', syncHeaderHeight, { passive: true });
document.addEventListener('DOMContentLoaded', syncHeaderHeight);
setTimeout(syncHeaderHeight, 200);
setTimeout(syncHeaderHeight, 800);

// --- SaaS Store Detection ---
const urlParams = new URLSearchParams(window.location.search);
const pathParts = window.location.pathname.split('/').filter(p => p !== '');

// Support both /store/slug and /slug formats
let slugFromPath = null;
if (pathParts[0] === 'store' && pathParts[1]) {
    slugFromPath = pathParts[1];
} else if (pathParts[0] && !['index.html', 'store.html', 'track', 'admin', 'login.html', 'merchant-login.html', 'platform.html'].includes(pathParts[0])) {
    slugFromPath = pathParts[0];
}

const paramOrPathSlug = urlParams.get('store') || slugFromPath;
window.currentStoreId = paramOrPathSlug || null;
window.currentStoreData = null;

try {
  const cachedProf = sessionStorage.getItem('mec_customer_profile');
  if (cachedProf) {
    window.currentUserProfile = JSON.parse(cachedProf);
  } else {
    window.currentUserProfile = { customerType: 'retail' };
  }
} catch(e) {
  window.currentUserProfile = { customerType: 'retail' };
}

const storesRef = collection(db, 'stores');
const hostname = window.location.hostname;

async function resolveStoreAndInit() {
  let matchedStore = null;
  try {
    if (window.currentStoreId) {
      // Query specifically by slug
      const qSlug = query(storesRef, where('slug', '==', window.currentStoreId));
      const snapSlug = await getDocs(qSlug);
      if (!snapSlug.empty) {
        matchedStore = { ...snapSlug.docs[0].data(), docId: snapSlug.docs[0].id };
      } else {
        // Try fallback query by docId directly
        try {
          const docRef = doc(db, 'stores', window.currentStoreId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            matchedStore = { ...docSnap.data(), docId: docSnap.id };
          }
        } catch(e) {}
      }
    } else {
      // Domain-based store resolution
      // mecbookshop domains default to mec-book-shop
      const isBookShopDomain = ['mecbookshop.web.lk', 'mecbookshop.com.lk', 'mec-book-shop.web.app', 'localhost', '127.0.0.1'].includes(hostname);
      if (isBookShopDomain) {
        window.currentStoreId = 'mec-book-shop';
        const qMain = query(storesRef, where('slug', '==', 'mec-book-shop'));
        const snapMain = await getDocs(qMain);
        if (!snapMain.empty) {
          matchedStore = { ...snapMain.docs[0].data(), docId: snapMain.docs[0].id };
        }
      } else if (hostname === 'mecpos.web.lk' || hostname === 'mec-pos-shop.web.app' || hostname === 'mecpos-web-lk.web.app') {
        // MEC POS Zenith Portal domain - never force mec-book-shop
        // If a specific merchant slug wasn't provided, window.currentStoreId remains null
        window.currentStoreId = null;
      } else {
        const cleanHostname = hostname.replace(/^www\./, '');
        const qDom = query(storesRef, where('domain', '==', cleanHostname));
        const snapDom = await getDocs(qDom);
        if (!snapDom.empty) {
          matchedStore = { ...snapDom.docs[0].data(), docId: snapDom.docs[0].id };
        }
      }
    }
  } catch(err) {
    console.error("Store resolution query failed:", err);
  }

  if (matchedStore) {
    window.currentStoreData = matchedStore;
    window.currentStoreId = matchedStore.slug || matchedStore.storeSlug || matchedStore.docId || 'mec-book-shop';
    console.log("Resolved Store ID:", window.currentStoreId);
    updateStoreBranding();
    initProductsListener();
    if (typeof window.checkAffReferral === 'function') window.checkAffReferral();
  } else {
    const requestedStore = window.currentStoreId;
    if (!requestedStore) {
      window.currentStoreId = 'mec-book-shop';
    }
    try {
      const fallbackQuery = query(storesRef, where('slug', '==', 'mec-book-shop'));
      const fallbackSnap = await getDocs(fallbackQuery);
      if (!fallbackSnap.empty) {
        if (window.currentStoreId === 'mec-book-shop') {
          window.currentStoreData = fallbackSnap.docs[0].data();
        }
      }
    } catch(err) {
      console.error("Error loading fallback store data:", err);
    }
    console.log("Resolved Store ID (Fallback):", window.currentStoreId);
    updateStoreBranding();
    initProductsListener();
    if (typeof window.checkAffReferral === 'function') window.checkAffReferral();
  }
}

resolveStoreAndInit();

function updateStoreBranding() {
  let name = window.currentStoreData?.name;
  if (!name) {
      if (window.currentStoreId && window.currentStoreId !== 'mec-book-shop' && window.currentStoreId !== 'master') {
          // Format slug into a readable name (e.g. d-and-j -> D And J)
          name = window.currentStoreId.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
      } else {
          name = "MEC Book Shop";
      }
  }
  if (name === "MEC POS") name = "MEC Book Shop"; // Force correct name
  document.title = `${name} | Official Store`;

  // Apply custom theme colors if they exist for this store
  const customPrimary = window.currentStoreData?.webDesign?.primary;
  const customAccent = window.currentStoreData?.webDesign?.accent;
  if (customPrimary) {
      document.documentElement.style.setProperty('--primary-color', customPrimary);
  }
  if (customAccent) {
      document.documentElement.style.setProperty('--secondary-color', customAccent);
  }
  // Update all logo text instances
  document.querySelectorAll('.logo-text').forEach(el => {
    el.innerText = name;
  });

  const isMerchantStore = window.currentStoreId && window.currentStoreId !== 'mec-book-shop' && window.currentStoreId !== 'master';
  if (isMerchantStore) {
    document.querySelectorAll('.bookshop-brand-banner').forEach(b => b.style.display = 'none');
    document.querySelectorAll('.merchant-only').forEach(m => m.style.display = '');
  } else {
    document.querySelectorAll('.bookshop-brand-banner').forEach(b => b.style.display = 'block');
    document.querySelectorAll('.merchant-only').forEach(m => m.style.display = 'none');
  }

  // Update dynamic logo images
  const logoUrl = window.currentStoreData?.logoUrl;
  const fallbackLogo = (logoUrl && logoUrl.trim() !== '' && !logoUrl.includes('zenith_logo') && !logoUrl.includes('/logo.png')) 
    ? logoUrl 
    : '/mec-logo.png';

  document.querySelectorAll('.logo-img, #pwa-install-banner img').forEach(img => {
    img.src = fallbackLogo;
    img.style.display = isMerchantStore ? '' : (img.classList.contains('merchant-only') ? 'none' : '');
  });

  // Update Hero Section (Dynamic Banner or Text-based Hero)
  const heroSection = document.getElementById('hero');
  if (heroSection) {
    // [v3.17.25] Always prefer Firestore bannerUrl — hardcoded fallback only if truly unset
    const firestoreBanner = window.currentStoreData?.webDesign?.bannerUrl;
    const bannerUrl = (firestoreBanner && firestoreBanner.length > 10)
      ? firestoreBanner
      : (window.currentStoreId === 'mec-book-shop' ? '/banner.png' : null);
    
    if (bannerUrl) {
      heroSection.innerHTML = `
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${bannerUrl}" alt="${name} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `;
    } else {
      const welcomeText = window.currentStoreData?.webContent?.welcome || `Welcome to ${name}`;
      const announceText = window.currentStoreData?.webContent?.announce || "Your premium destination for high-quality products and services.";
      heroSection.innerHTML = `
        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">
          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${welcomeText}</h1>
          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${announceText}</p>
          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>
        </div>
      `;
    }
  }

  // Update Page Title and Footer
  const pageTitle = document.getElementById('page-title');
  if (pageTitle) pageTitle.innerText = `${name} | Official Store`;

  const footerCopy = document.getElementById('footer-copy');
  if (footerCopy) footerCopy.innerText = `© 2026 ${name}. All rights reserved.`;

  // Dynamic Navigation Links (Epinics Multi-Vendor & Affiliate)
  const webEpinics = window.currentStoreData?.webEpinics || {};
  const isMultiVendor = !!webEpinics.multiVendor;
  const isAffiliate = !!webEpinics.affiliate;

  document.getElementById('nav-sell-with-us')?.remove();
  document.getElementById('nav-affiliate-program')?.remove();

  const navMenu = document.getElementById('nav-menu');
  if (navMenu) {
    const authItem = document.getElementById('nav-auth-item');

    if (isMultiVendor) {
      const li = document.createElement('li');
      li.id = 'nav-sell-with-us';
      li.innerHTML = `<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>`;
      if (authItem) {
        navMenu.insertBefore(li, authItem);
      } else {
        navMenu.appendChild(li);
      }
    }

    if (isAffiliate) {
      const li = document.createElement('li');
      li.id = 'nav-affiliate-program';
      li.innerHTML = `<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>`;
      if (authItem) {
        navMenu.insertBefore(li, authItem);
      } else {
        navMenu.appendChild(li);
      }
    }
  }

  // Reveal UI now that branding is applied
  document.documentElement.classList.remove('loading-merchant');
}

// --- PWA Installation Logic ---
let deferredPrompt;
const installBtn = document.createElement('div');
installBtn.id = 'pwa-install-banner';
installBtn.innerHTML = `
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>
            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>
        </div>
        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;
installBtn.style.display = 'none';
document.body.appendChild(installBtn);

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.style.display = 'block';
});

installBtn.addEventListener('click', async (e) => {
  if (e.target.id === 'pwa-close') {
    installBtn.style.display = 'none';
    return;
  }
  if (deferredPrompt) {
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      installBtn.style.display = 'none';
    }
    deferredPrompt = null;
  }
});

// Register Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(reg => {
      console.log('SW Registered', reg.scope);
    }).catch(err => {
      console.log('SW Registration Failed', err);
    });
  });
}

// --- Mobile Menu Toggle ---
const menuToggle = document.getElementById('menu-toggle');
const navMenu = document.getElementById('nav-menu');

const mobileOverlay = document.getElementById('mobile-menu-overlay');

const closeMobileMenu = () => {
  navMenu?.classList.remove('active');
  menuToggle?.classList.remove('active');
  mobileOverlay?.classList.remove('active');
};

menuToggle?.addEventListener('click', () => {
  const isActive = navMenu?.classList.toggle('active');
  menuToggle?.classList.toggle('active');
  if (isActive) mobileOverlay?.classList.add('active');
  else mobileOverlay?.classList.remove('active');
});

const closeMenuBtn = document.getElementById('close-menu');
closeMenuBtn?.addEventListener('click', closeMobileMenu);
mobileOverlay?.addEventListener('click', closeMobileMenu);

// Close menu when link is clicked
navMenu?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', closeMobileMenu);
});
// -----------------------------

// updateGreeting — stub kept to avoid ReferenceError (logic moved to static banner)
function updateGreeting() {
    // No-op: greeting is now handled by the static hero banner section
}

// --- Robust Image Resolution System ---
function resolveProductImage(img, name) {
    if (typeof img === 'string' && img.trim() !== '') {
        const trimmed = img.trim();
        if ((trimmed.startsWith('data:') || trimmed.startsWith('blob:') || trimmed.startsWith('http') || trimmed.startsWith('/')) &&
            !trimmed.includes('placehold.co') && !trimmed.includes('zenith_logo.png') && !trimmed.includes('/logo.png')) {
            return trimmed;
        }
    }
    
    // Fallback must ALWAYS be the merchant's store logo, NEVER POS Zenith!
    const storeLogo = window.currentStoreData?.logoUrl;
    if (storeLogo && storeLogo.trim() !== '' && !storeLogo.includes('zenith_logo.png') && !storeLogo.includes('/logo.png')) {
        return storeLogo;
    }
    
    return '/mec-logo.png';
}


const defaultProducts = [
  {
    id: 1,
    name: 'Atlas CR Book (80 Pages)',
    price: 350.00,
    category: 'Notebooks',
    image: 'https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80'
  },
  {
    id: 2,
    name: 'Promate Exercise Book (120 Pg)',
    price: 280.00,
    category: 'Notebooks',
    image: 'https://placehold.co/400x300/EC008C/FFF?text=Promate+120'
  }
];

// Firebase Collection References
const productsCol = collection(db, 'products');
const ordersCol = collection(db, 'orders');
const promotionsCol = collection(db, 'promotions');
const branchesCol = collection(db, 'branches');

// Comprehensive Sri Lanka Cities & Towns A to Z for Branch Pickup Filtering
const SRI_LANKA_TOWNS_A_Z = [
  "Ahangama", "Ahungalla", "Akuressa", "Alawwa", "Aluthgama", "Ambalangoda", "Ambalantota", "Ampara", "Angoda", "Anuradhapura", "Aranayaka", "Athurugiriya", "Avissawella",
  "Baddegama", "Badulla", "Balangoda", "Bandaragama", "Bandarawela", "Battaramulla", "Batticaloa", "Beliatta", "Bentota", "Beruwala", "Biyagama", "Boralasgamuwa", "Boralesgamuwa", "Bulathsinhala",
  "Chavakachcheri", "Chilaw", "Chunnakam", "Colombo 01 - Fort", "Colombo 02 - Slave Island", "Colombo 03 - Kollupitiya", "Colombo 04 - Bambalapitiya", "Colombo 05 - Havelock Town", "Colombo 06 - Wellawatte", "Colombo 07 - Cinnamon Gardens", "Colombo 08 - Borella", "Colombo 09 - Dematagoda", "Colombo 10 - Maradana", "Colombo 11 - Pettah", "Colombo 12 - Hultsdorf", "Colombo 13 - Kotahena", "Colombo 14 - Grandpass", "Colombo 15 - Mutwal",
  "Dambulla", "Dankotuwa", "Dehiowita", "Dehiwala", "Delgoda", "Deniyaya", "Deraniyagala", "Digana", "Divulapitiya", "Dodangoda", "Dompe",
  "Eheliyagoda", "Elpitiya", "Embilipitiya", "Eppawala",
  "Galagedara", "Galgamuwa", "Galewela", "Galle", "Gampaha", "Gampola", "Gelioya", "Giriulla", "Godakawela", "Gonapinuwala",
  "Habarana", "Hakmana", "Hambantota", "Hanwella", "Haputale", "Hatton", "Hettipola", "Hikkaduwa", "Hingurakgoda", "Hokandara", "Homagama", "Horana",
  "Ibbagamuwa", "Imaduwa", "Ingiriya",
  "Ja-Ela", "Jaffna",
  "Kadawatha", "Kaduwela", "Kahawatta", "Kalawana", "Kalmunai", "Kalutara", "Kamburupitiya", "Kandana", "Kandy", "Karapitiya", "Katubedda", "Katugastota", "Katunayake", "Kegalle", "Kekirawa", "Kelaniya", "Kesbewa", "Kilinochchi", "Kiribathgoda", "Kirinda", "Kochchikade", "Kohuwala", "Kolonnawa", "Koralawella", "Kosgoda", "Kotikawatta", "Kottawa", "Kuliyapitiya", "Kundasale", "Kurunegala",
  "Mabima", "Madampe", "Madapatha", "Maharagama", "Mahiyanganaya", "Malabe", "Mannar", "Marawila", "Maskeliya", "Matale", "Matara", "Mathugama", "Matugama", "Mawathagama", "Medawachchiya", "Meegoda", "Melsiripura", "Menikhinna", "Minuwangoda", "Mirigama", "Mirissa", "Monaragala", "Moratuwa", "Mount Lavinia", "Mullaitivu",
  "Narahenpita", "Narammala", "Naththandiya", "Nawala", "Nawalapitiya", "Negombo", "Nelundeniya", "Nittambuwa", "Nochchiyagama", "Nugegoda", "Nuwara Eliya",
  "Padukka", "Paiyagala", "Palavi", "Pallekele", "Panadura", "Pannala", "Pannipitiya", "Pasikuda", "Passara", "Peliyagoda", "Pelmadulla", "Peradeniya", "Pilimathalawa", "Piliyandala", "Pitakotte", "Polgahawela", "Polonnaruwa", "Pugoda", "Pundaluoya", "Puttalam",
  "Radawana", "Ragama", "Rajagiriya", "Rambukkana", "Ranala", "Ranna", "Rathgama", "Ratmalana", "Ratnapura", "Rikillagaskada", "Ruwanwella",
  "Seeduwa", "Sigiriya",
  "Talawakele", "Tangalle", "Thalawathugoda", "Thambuttegama", "Thihariya", "Tissamaharama", "Trincomalee",
  "Udugama", "Udumulla", "Ukuwela", "Unawatuna", "Urubokka", "Uswetakeiyawa",
  "Valvettithurai", "Vavuniya", "Veyangoda",
  "Wadduwa", "Walasmulla", "Warakapola", "Wariyapola", "Waskaduwa", "Wattala", "Weligama", "Welikanda", "Welimada", "Welipenna", "Welisara", "Weliweriya", "Wellampitiya", "Wellawaya", "Wennappuwa", "Wijerama",
  "Yakkala", "Yatiyanthota"
];

let allStoreBranches = [];
onSnapshot(branchesCol, (snapshot) => {
  allStoreBranches = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
  window.allStoreBranches = allStoreBranches;
  if (typeof window.populatePickupShops === 'function') {
    window.populatePickupShops();
  }
});

function getAllAvailableShops() {
  const isMaster = window.currentStoreId === 'mec-book-shop' || window.currentStoreId === 'master';
  let list = (window.allStoreBranches || []).filter(b => isMaster || b.storeId === window.currentStoreId || !b.storeId);
  
  // Default main branch fallback if no branches in database
  const defaultMain = {
    docId: 'main',
    name: (window.currentStoreData?.name || 'MEC Book Shop') + ' - Main Branch',
    location: window.currentStoreData?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
    address: window.currentStoreData?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
    city: 'Horana',
    district: 'Kalutara',
    phone: window.currentStoreData?.phone || '071 923 3388'
  };

  if (list.length === 0) {
    list = [defaultMain];
  }
  return list;
}
window.getAllAvailableShops = getAllAvailableShops;

function getAvailableTowns() {
  const allShops = getAllAvailableShops();
  const registeredTowns = allShops
    .map(s => (s.location || s.city || '').trim())
    .filter(t => t.length > 0);

  const merged = Array.from(new Set([...registeredTowns, ...SRI_LANKA_TOWNS_A_Z]))
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
  return merged;
}
window.getAvailableTowns = getAvailableTowns;

let products = [];
let cartCount = 0;
let cart = [];
let currentCategory = 'All';
let currentPage = 1;
let itemsPerPage = 12; // Adjusted for better grid layout
let currentSort = 'recommended';
let searchQuery = '';
let seededRandomOrder = null;

const cartCountElement = document.getElementById('cart-count');

// Listen for Products Live (Scoped for speed)
function initProductsListener() {
  let q;
  if (window.currentStoreId === 'mec-book-shop' || window.currentStoreId === 'master') {
    q = query(productsCol);
  } else {
    q = query(productsCol, where('storeId', '==', window.currentStoreId));
  }

  onSnapshot(q, (snapshot) => {
    const allProducts = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id, docId: doc.id, sku: doc.data().sku || doc.id }));
    
    // Auto-create "Other" product if it doesn't exist for mec-book-shop
    const isMECBookShop = window.currentStoreId === 'mec-book-shop' || window.currentStoreId === 'O8ywuZTKSwdL4z77RQ9M' || window.currentStoreId === 'master';
    if (isMECBookShop) {
        const hasOther = allProducts.some(p => p.name && p.name.trim().toLowerCase() === 'other');
        if (!hasOther && snapshot.docs.length > 0) {
            console.log("Auto-creating 'Other' product for MEC Book Shop...");
            const otherProduct = {
                name: "Other",
                sku: "SKU-OTHER-0000-GEN-P1C0",
                category: "Uncategorized",
                mode: "Shop",
                supplierId: "General",
                supplierName: "General",
                cost: 0,
                price: 1,
                wholesalePrice: 1,
                loyaltyPrice: 1,
                discount: 0,
                stock: 999999,
                wStock: 0,
                totalStock: 999999,
                timestamp: serverTimestamp(),
                salesToday: 0,
                image: "",
                variants: [],
                payMethods: {
                    cod: true,
                    bank: true,
                    shop: true
                },
                storeId: window.currentStoreId
            };
            otherProduct.docId = otherProduct.sku;
            setDoc(doc(db, 'products', otherProduct.sku), otherProduct).catch(err => console.error("Error creating 'Other' product:", err));
        }
    }

    products = allProducts.filter(p => {
      const isMECStore = window.currentStoreId === 'mec-book-shop' || window.currentStoreId === 'master';
      const isOurStore = isMECStore
        ? (p.storeId === 'mec-book-shop' || p.storeId === 'master' || !p.storeId)
        : (p.storeId === window.currentStoreId);
      
      // Hide Service and Technical products from web storefront
      const isVisibleMode = (p.mode === 'Shop' || p.mode === 'Warehouse' || p.mode === undefined);
      
      // Hide pending seller products from catalog
      const isActive = p.status !== 'pending';
      
      return isOurStore && isVisibleMode && isActive;
    });

    // Sort products for consistent display
    products.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));

    if (products.length === 0 && window.currentStoreId === 'master') {
      // Seed initial data if empty
      defaultProducts.forEach(async (p) => {
        await addDoc(productsCol, p);
      });
    }
    renderProducts();
    renderCategories();
  });
}

// Sorting listener
document.getElementById('product-sort')?.addEventListener('change', (e) => {
  currentSort = e.target.value;
  currentPage = 1;
  renderProducts();
});

// Search listener
const setupSearchListeners = () => {
  document.querySelectorAll('#store-search, .store-search-input').forEach(input => {
    input.addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase();
      window.searchQuery = searchQuery; // keep window in sync for AI chat
      document.querySelectorAll('#store-search, .store-search-input').forEach(other => {
        if (other !== e.target) other.value = e.target.value;
      });
      currentPage = 1;
      renderProducts();
    });
  });
};
setupSearchListeners();

// Expose renderProducts globally (used by AI assistant chat search)
window.renderProducts = renderProducts;

// Global clear-search helper (used by empty-state button)
window.clearSearch = () => {
  searchQuery = '';
  window.searchQuery = '';
  document.querySelectorAll('#store-search, .store-search-input').forEach(inp => {
    inp.value = '';
  });
  currentPage = 1;
  renderProducts();
};

// --- Cart Persistence ---
function saveCart() {
  localStorage.setItem('mec_cart', JSON.stringify(cart));
}

function loadCart() {
  const saved = localStorage.getItem('mec_cart');
  if (saved) {
    cart = JSON.parse(saved);
    cartCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    updateCartUI();
  }
}

// Create Cart Modal UI dynamically
const cartModal = document.createElement('div');
cartModal.id = 'cart-modal';
document.body.appendChild(cartModal);

const overlay = document.createElement('div');
overlay.id = 'cart-overlay';
document.body.appendChild(overlay);

window.toggleCart = (show) => {
  if (show) {
    cartModal.classList.add('active');
    overlay.classList.add('active');
    renderCartItems();
    document.body.style.overflow = 'hidden';
  } else {
    cartModal.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
};
const toggleCart = window.toggleCart;

overlay.onclick = () => toggleCart(false);

const cartTriggers = document.querySelectorAll('a[href="#cart"]');
cartTriggers.forEach(trigger => {
  trigger.onclick = (e) => {
    e.preventDefault();
    closeMobileMenu(); // Close sidebar if it's open
    toggleCart(true);
  };
});

const shopNowBtn = document.getElementById('shop-now-btn');
if (shopNowBtn) {
  shopNowBtn.addEventListener('click', () => {
    const productsSection = document.getElementById('shop-section');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  });
}

const categoryIcons = {
  'All': '🏠',
  'Notebooks': '📓',
  'Stationery': '📎',
  'Writing': '✏️',
  'Art': '🎨',
  'Books': '📖',
  'Pens': '🖋️',
  'School': '🎒',
  'Office': '🏢'
};

function getCategories() {
  const categories = ['All', ...new Set(products.map(p => p.category))];
  return categories;
}

function renderCategories() {
  const categories = getCategories();
  const sidebarList = document.getElementById('sidebar-category-list');
  const mobileBar = document.getElementById('mobile-category-bar');

  if (sidebarList) {
    sidebarList.innerHTML = categories.map(cat => `
      <li class="sidebar-cat-item ${cat === currentCategory ? 'active' : ''}" data-category="${cat}">
        <div class="cat-icon-text">
          <span class="cat-icon">${categoryIcons[cat] || '📁'}</span>
          <span>${cat}</span>
        </div>
        <span class="arrow">›</span>
      </li>
    `).join('');
  }

  if (mobileBar) {
    mobileBar.innerHTML = categories.map(cat => `
      <button class="mobile-cat-btn ${cat === currentCategory ? 'active' : ''}" data-category="${cat}">
        ${cat}
      </button>
    `).join('');
  }

  // Common selection handler
  const handleCategorySelect = (cat) => {
    currentCategory = cat;
    const titleEl = document.getElementById('featured-title');
    if (titleEl) titleEl.innerText = cat === 'All' ? 'Featured Collection' : `${cat} Collection`;
    renderProducts();
    renderCategories();
    hideMegaMenu();
    // Scroll to products on sidebar selection too
    document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Add click and hover listeners to sidebar
  document.querySelectorAll('.sidebar-cat-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      handleCategorySelect(e.currentTarget.dataset.category);
    });
    item.addEventListener('mouseenter', (e) => {
      const cat = e.currentTarget.dataset.category;
      if (cat !== 'All') {
        showMegaMenu(cat, e.currentTarget);
      } else {
        hideMegaMenu();
      }
    });
  });

  // Add click listeners to mobile bar
  document.querySelectorAll('.mobile-cat-btn').forEach(btn => {
    btn.addEventListener('click', (e) => handleCategorySelect(e.target.dataset.category));
  });

  const menuWrapper = document.querySelector('.category-menu-wrapper');
  const navCatBtn = document.getElementById('nav-category-btn');

  if (navCatBtn && menuWrapper) {
    navCatBtn.onclick = (e) => {
      e.stopPropagation();
      menuWrapper.classList.toggle('active');
    };
  }

  menuWrapper?.addEventListener('mouseleave', () => {
    menuWrapper.classList.remove('active');
    hideMegaMenu();
  });
}

// Global outside click to dismiss navbar categories
document.addEventListener('click', (e) => {
  const menuWrapper = document.querySelector('.category-menu-wrapper');
  if (menuWrapper && !menuWrapper.contains(e.target)) {
    menuWrapper.classList.remove('active');
    if (typeof hideMegaMenu === 'function') hideMegaMenu();
  }
});

const megaMenu = document.getElementById('mega-menu');

let megaMenuTimer;

function showMegaMenu(category, targetElement) {
  if (!megaMenu) return;
  clearTimeout(megaMenuTimer); // Cancel any pending hide

  // Highlight active hovered item in sidebar
  document.querySelectorAll('.sidebar-cat-item').forEach(el => el.classList.remove('active'));
  targetElement?.classList.add('active');

  // Get ALL products for this category
  const categoryProducts = (products || []).filter(p => p.category === category);

  // Sub-categories / type filters
  const subCategories = {
    'Writing': ['Ball Point Pens', 'Gel Pens', 'Markers', 'Pencils'],
    'Pens': ['Ball Point', 'Gel Pens', 'Highlighters', 'Ink Pens'],
    'Notebooks': ['Hardcover', 'Softcover', 'Spiral', 'CR Books'],
    'Art': ['Watercolors', 'Acrylics', 'Brushes', 'Sketchbooks'],
    'STATIONERIES': ['Pens & Pencils', 'Glue & Tape', 'Erasers & Rulers', 'Paper & Files'],
    'ATLAS': ['CR Books', 'Exercise Books', 'Pastels & Color', 'Geometry Boxes']
  }[category] || ['Standard Items', 'Premium Items', 'New Arrivals'];

  // Update Mega Sidebar Column
  const sideCol = document.getElementById('mega-sidebar-col');
  if (sideCol) {
    sideCol.innerHTML = `
      <div style="margin-bottom: 1.1rem;">
        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>
        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">
          <span>${categoryIcons[category] || '📁'}</span>
          <span>${category}</span>
        </div>
        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${categoryProducts.length} Items Available</div>
      </div>
      <button type="button" onclick="window.filterByCategoryAndScroll('${category}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">
        <span>View All</span>
        <span>→</span>
      </button>
      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        ${subCategories.map(sub => `<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${sub}', '${category}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${sub}</a>`).join('')}
      </div>
    `;
  }

  // Update Products List Heading
  const prodHeading = document.getElementById('mega-products-heading');
  if (prodHeading) {
    prodHeading.innerText = `${category} Products (${categoryProducts.length})`;
  }

  const prodList = document.getElementById('mega-products-list');
  if (prodList) {
    prodList.innerHTML = categoryProducts.length > 0
      ? categoryProducts.map(p => `
          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${p.docId}')">
            <img src="${resolveProductImage(p.image, p.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">
            <div class="mega-prod-info">
              <h5 title="${p.name}">${p.name}</h5>
              <div class="price">LKR ${Number(p.price || 0).toFixed(2)}</div>
            </div>
          </a>
        `).join('')
      : '<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>';
  }

  // Position megaMenu next to the dropdown cleanly
  megaMenu.style.top = 'calc(100% + 8px)';
  megaMenu.style.left = '248px';
  megaMenu.classList.add('active');

  // Prevent megaMenu from overflowing off the right viewport edge
  const rect = megaMenu.getBoundingClientRect();
  if (rect.right > window.innerWidth - 16) {
    const overflow = rect.right - (window.innerWidth - 16);
    megaMenu.style.left = `${Math.max(0, 248 - overflow)}px`;
  }
}

function hideMegaMenu() {
  // Add a generous 400ms delay so user can smoothly move diagonally across items to the products panel
  megaMenuTimer = setTimeout(() => {
    megaMenu?.classList.remove('active');
  }, 400);
}

// Ensure mega menu stays open when mouse is inside it or inside sidebar list
megaMenu?.addEventListener('mouseenter', () => clearTimeout(megaMenuTimer));
document.getElementById('sidebar-category-list')?.addEventListener('mouseenter', () => clearTimeout(megaMenuTimer));

// Global function for filtering by category and scrolling directly
window.filterByCategoryAndScroll = (category) => {
  currentCategory = category;
  const titleEl = document.getElementById('featured-title');
  if (titleEl) titleEl.innerText = category === 'All' ? 'Featured Collection' : `${category} Collection`;
  renderProducts();
  renderCategories();
  hideMegaMenu();
  document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' });
};

// Global function for sub-category filtering
window.filterBySubCategory = (sub, mainCat) => {
  currentCategory = mainCat;
  renderProducts();
  renderCategories();
  const titleEl = document.getElementById('featured-title');
  if (titleEl) titleEl.innerText = `${sub} in ${mainCat}`;
  document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' });
  hideMegaMenu();
};

window.scrollToProduct = (docId) => {
  const el = document.getElementById(`product-${docId}`);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('highlight-pulse');
    setTimeout(() => el.classList.remove('highlight-pulse'), 3000);
    hideMegaMenu();
  }
};

// --- Customer Pricing Engine ---
export function getCustomerEffectivePrice(product, variant = null, userType = null) {
  if (!product) return { retailPrice: 0, effectivePrice: 0, discountedPrice: 0, isSpecial: false, userType: 'retail' };
  
  const currentType = (userType || window.currentUserProfile?.customerType || 'retail').toLowerCase();
  
  let retail = 0;
  let wholesale = 0;
  let loyalty = 0;
  
  if (variant) {
    retail = Number(variant.price);
    if (isNaN(retail) || retail <= 0) retail = Number(product.price) || 0;
    
    wholesale = Number(variant.wholesalePrice);
    if (isNaN(wholesale) || wholesale <= 0) wholesale = Number(product.wholesalePrice) || 0;
    
    loyalty = Number(variant.loyaltyPrice);
    if (isNaN(loyalty) || loyalty <= 0) loyalty = Number(product.loyaltyPrice) || 0;
  } else {
    retail = Number(product.price) || 0;
    wholesale = Number(product.wholesalePrice) || 0;
    loyalty = Number(product.loyaltyPrice) || 0;
  }
  
  if (isNaN(retail)) retail = 0;
  let effective = retail;
  let isSpecial = false;
  
  if (currentType === 'wholesale' && wholesale > 0) {
    effective = wholesale;
    isSpecial = (wholesale !== retail);
  } else if (currentType === 'loyalty' && loyalty > 0) {
    effective = loyalty;
    isSpecial = (loyalty !== retail);
  }
  
  const discount = Number(product.discount) || 0;
  const discounted = effective * (1 - (discount > 0 ? discount / 100 : 0));
  
  return {
    retailPrice: isNaN(retail) ? 0 : retail,
    effectivePrice: isNaN(effective) ? 0 : effective,
    discountedPrice: isNaN(discounted) ? 0 : discounted,
    isSpecial: isSpecial,
    userType: currentType
  };
}
window.getCustomerEffectivePrice = getCustomerEffectivePrice;

// Unified Stock Helper: Combines Web Stock and Shop Stock together
function getProductTotalStock(product, variant = null) {
  return getProductAvailableStock(product, variant, 'web');
}

// Order-type aware stock helper:
// - COD / Bank Transfer: Web Stock + Shop Stock (All stock)
// - ShopPay (Shop Order/Pickup): Shop Stock ONLY
function getProductAvailableStock(product, variant = null, orderType = 'web') {
  if (!product) return 0;
  
  const isShopOnly = (orderType === 'ShopPay' || orderType === 'shop' || orderType === 'Shop');
  
  if (isShopOnly) {
    // Shop Order: ONLY Shop Stock (product.stock / variant.stock)
    if (variant) {
      const vStock = parseFloat(variant.stock) || 0;
      if (vStock > 0) return vStock;
    }
    const shopStock = parseFloat(product.stock || 0);
    return shopStock > 0 ? shopStock : 0;
  } else {
    // COD / Bank Transfer Web Order: Web Stock + Shop Stock (ALL stock)
    if (variant) {
      const vStock = parseFloat(variant.stock) || 0;
      const vWStock = parseFloat(variant.wStock) || 0;
      const vTotal = vStock + vWStock;
      if (vTotal > 0) return vTotal;
    }
    if (product.variants && product.variants.length > 0) {
      const sumVariants = product.variants.reduce((sum, v) => {
        return sum + (parseFloat(v.stock) || 0) + (parseFloat(v.wStock) || 0);
      }, 0);
      if (sumVariants > 0) return sumVariants;
    }
    const shopStock = parseFloat(product.stock || 0);
    const webStock = parseFloat(product.wStock || 0);
    const totalStockField = parseFloat(product.totalStock || 0);
    const combined = shopStock + webStock;
    if (combined > 0) return combined;
    if (totalStockField > 0) return totalStockField;
    return 0;
  }
}

const detailModal = document.getElementById('product-detail-modal');
const detailOverlay = document.getElementById('product-detail-overlay');

window.openProductDetail = (docId) => {
  const product = (window.groupedProducts || []).find(p => p.docId === docId) || products.find(p => p.docId === docId);
  if (!product) return;

  const discount = Number(product.discount) || 0;
  const hasVariants = product.variants && product.variants.length > 0;
  const firstVariant = hasVariants ? product.variants[0] : null;
  
  let initialImg = product.image;
  if (firstVariant) {
    if (firstVariant.image) initialImg = firstVariant.image;
    else if (firstVariant.images && firstVariant.images.length > 0) initialImg = firstVariant.images[0];
  }

  const priceInfo = getCustomerEffectivePrice(product, firstVariant);
  const userType = priceInfo.userType;
  const isSpecial = priceInfo.isSpecial;
  const retailPrice = priceInfo.retailPrice;
  const discountedPrice = priceInfo.discountedPrice;
  const initialStock = getProductTotalStock(product, firstVariant);

  // Build dynamic color and size pills or MRP cards
  const colorMap = {
    'red':'#ef4444','blue':'#2563eb','black':'#1e293b','green':'#16a34a',
    'yellow':'#eab308','orange':'#ea580c','purple':'#9333ea','pink':'#db2777',
    'white':'#f8fafc','grey':'#64748b','gray':'#64748b','brown':'#78350f',
    'navy':'#1e3a8a','cyan':'#0891b2','gold':'#d97706','silver':'#94a3b8'
  };

  let variantSelectorsHTML = '';
  if (hasVariants) {
    // Collect distinct colors and sizes if applicable
    const distinctSizes = [...new Set(product.variants.map(v => v.size).filter(Boolean))];
    const distinctColors = [...new Set(product.variants.map(v => v.color).filter(Boolean))];

    if (distinctSizes.length > 0 || distinctColors.length > 0) {
      // 1. Color Selector if available
      let colorSelectorHTML = '';
      if (distinctColors.length > 0) {
        colorSelectorHTML = `
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Color</span>
              <span class="selected-val" id="detail-selected-color">${firstVariant?.color || distinctColors[0]}</span>
            </div>
            <div class="variant-pill-container" id="color-pill-group">
              ${distinctColors.map(c => {
                const hex = colorMap[c.toLowerCase()] || '#64748b';
                const isSelected = (firstVariant?.color || distinctColors[0]) === c;
                return `
                  <button type="button" class="variant-color-btn ${isSelected ? 'active' : ''}" 
                    style="background-color: ${hex};" 
                    title="${c}" data-color="${c}"
                    onclick="window.selectVariantByAttribute('${product.docId}', 'color', '${c}')">
                  </button>
                `;
              }).join('')}
            </div>
          </div>
        `;
      }

      // 2. Size Selector if available
      let sizeSelectorHTML = '';
      if (distinctSizes.length > 0) {
        sizeSelectorHTML = `
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Style / Size</span>
              <span class="selected-val" id="detail-selected-size">${firstVariant?.size || distinctSizes[0]}</span>
            </div>
            <div class="variant-pill-container" id="size-pill-group">
              ${distinctSizes.map(s => {
                const isSelected = (firstVariant?.size || distinctSizes[0]) === s;
                return `
                  <button type="button" class="variant-size-btn ${isSelected ? 'active' : ''}" 
                    data-size="${s}"
                    onclick="window.selectVariantByAttribute('${product.docId}', 'size', '${s}')">
                    ${s}
                  </button>
                `;
              }).join('')}
            </div>
          </div>
        `;
      }

      variantSelectorsHTML = `${colorSelectorHTML}${sizeSelectorHTML}`;
    } else {
      // Fallback: visual card pills with MRP
      variantSelectorsHTML = `
        <div class="variant-selector-group">
          <div class="variant-selector-label">
            <span>Choose Option / MRP</span>
          </div>
          <div class="variant-pill-container">
            ${product.variants.map((v, i) => {
              const vStock = getProductTotalStock(product, v);
              return `
              <div class="variant-mrp-card ${i === 0 ? 'active' : ''}" id="v-card-${i}"
                   onclick="window.updateDetailDisplay('${product.docId}', ${i})">
                <div style="flex:1;">
                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${v.name || v.variantLabel || v.color || v.size || `Option ${i+1}`}</div>
                  <div style="font-size: 0.75rem; color: #64748b;">${vStock > 0 ? `In Stock (${vStock})` : 'Out of stock'}</div>
                </div>
                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">
                  LKR ${(v.price || product.price || 0).toLocaleString()}
                </div>
              </div>
            `}).join('')}
          </div>
        </div>
      `;
    }
  }

  detailModal.innerHTML = `
        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>
        <div class="detail-content">
            <div class="detail-image-sec">
                <img src="${resolveProductImage(initialImg, product.name)}" id="detail-main-img" 
                    alt="${product.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">
            </div>

            <div class="detail-info-sec">
                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${product.category}</div>
                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${product.name}</h2>
                ${isSpecial ? `<div style="font-size: 0.8rem; color: ${userType === 'wholesale' ? '#facc15' : '#10b981'}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${userType.toUpperCase()} APPLIED</div>` : ''}
                
                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">
                    ${(discount > 0 || isSpecial) ? `<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${retailPrice.toFixed(2)}</span>` : ''}
                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${discountedPrice.toFixed(2)}</span>
                </div>
                
                ${variantSelectorsHTML}

                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${initialStock > 0 ? '#10b981' : '#ef4444'}; margin: 0.5rem 0;">
                  ${initialStock > 0 ? `✓ In Stock (${initialStock} available)` : '✕ Out of Stock'}
                </div>
                
                <div class="detail-actions-sec">
                    <button class="add-to-cart-btn detail-add-btn" 
                            onclick="window.handleDetailAddToCart('${product.docId}')">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `;

  window.activeDetailVariantIndex = 0;
  detailModal.classList.add('active');
  detailOverlay.classList.add('active');
  document.body.style.overflow = 'hidden';
  hideMegaMenu();

  // Immediately synchronize first variant's display (image, stock, pricing)
  window.updateDetailDisplay(docId, 0);
};

window.selectVariantByAttribute = (docId, attrType, attrVal) => {
  const product = (window.groupedProducts || []).find(p => p.docId === docId) || products.find(p => p.docId === docId);
  if (!product || !product.variants) return;

  const curIdx = window.activeDetailVariantIndex || 0;
  const currentVariant = product.variants[curIdx] || product.variants[0];

  // Try matching combined attributes or closest variant
  let targetIdx = product.variants.findIndex(v => {
    if (attrType === 'color') return v.color === attrVal;
    if (attrType === 'size') return v.size === attrVal;
    return false;
  });

  if (targetIdx === -1) targetIdx = 0;

  // Update button active states
  if (attrType === 'color') {
    document.querySelectorAll('#color-pill-group .variant-color-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.color === attrVal);
    });
    const label = document.getElementById('detail-selected-color');
    if (label) label.innerText = attrVal;
  }
  if (attrType === 'size') {
    document.querySelectorAll('#size-pill-group .variant-size-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.size === attrVal);
    });
    const label = document.getElementById('detail-selected-size');
    if (label) label.innerText = attrVal;
  }

  window.updateDetailDisplay(docId, targetIdx);
};

window.closeProductDetail = () => {
  detailModal.classList.remove('active');
  detailOverlay.classList.remove('active');
  document.body.style.overflow = '';
};

detailOverlay.onclick = window.closeProductDetail;

window.updateDetailDisplay = (docId, variantIndex) => {
  window.activeDetailVariantIndex = Number(variantIndex);
  const product = (window.groupedProducts || []).find(p => p.docId === docId) || products.find(p => p.docId === docId);
  if (!product) return;
  const variant = (product.variants && product.variants.length > 0) ? product.variants[variantIndex] : null;
  const imgEl = document.getElementById('detail-main-img');
  const stockEl = document.getElementById('detail-stock');
  const origPriceEl = detailModal.querySelector('.detail-original-price');
  const finalPriceEl = detailModal.querySelector('.detail-final-price');

  if (imgEl) {
    let targetImage = product.image;
    if (variant) {
      if (variant.image) targetImage = variant.image;
      else if (variant.images && variant.images.length > 0) targetImage = variant.images[0];
    }
    imgEl.src = resolveProductImage(targetImage, product.name);
  }

  // Update card highlights if card picker was used
  document.querySelectorAll('.variant-mrp-card').forEach((card, idx) => {
    card.classList.toggle('active', idx === Number(variantIndex));
  });

  const discount = Number(product.discount) || 0;
  const priceInfo = getCustomerEffectivePrice(product, variant);

  if (origPriceEl) origPriceEl.innerText = `LKR ${priceInfo.retailPrice.toFixed(2)}`;
  if (finalPriceEl) finalPriceEl.innerText = `LKR ${priceInfo.discountedPrice.toFixed(2)}`;

  // Unified combined stock (Web Stock + Shop Stock together)
  const stockVal = getProductTotalStock(product, variant);

  if (stockEl) {
    const stockLabel = stockVal > 0 ? `✓ In Stock (${stockVal} available)` : '✕ Out of Stock';
    stockEl.innerHTML = stockLabel;
    stockEl.style.color = stockVal > 0 ? '#10b981' : '#ef4444';
  }
};

window.handleDetailAddToCart = (docId) => {
  const product = (window.groupedProducts || []).find(p => p.docId === docId) || products.find(p => p.docId === docId);
  if (!product) return;

  const variantIndex = window.activeDetailVariantIndex !== undefined ? window.activeDetailVariantIndex : 0;

  let selectedVariant = 'Default';
  let variantObj = null;
  if (product.variants && product.variants.length > 0) {
      variantObj = product.variants[variantIndex] || product.variants[0];
      selectedVariant = variantObj.name || variantObj.variantLabel || variantObj.color || variantObj.size || 'Default';
  }

  const priceInfo = getCustomerEffectivePrice(product, variantObj);
  const price = priceInfo.effectivePrice;
  const costValue = (variantObj && variantObj.cost !== undefined) ? Number(variantObj.cost) : (Number(product.cost) || 0);
  
  const currentStock = getProductTotalStock(product, variantObj);

  const existingIndex = cart.findIndex(item => item.docId === product.docId && item.selectedVariant === selectedVariant);
  const requestedQty = existingIndex !== -1 ? (cart[existingIndex].quantity || 1) + 1 : 1;

  if (product.mode !== 'Service' && product.mode !== 'Technical') {
      if (requestedQty > currentStock) {
          alert(`Sorry, out of stock! Only ${currentStock} available.`);
          return;
      }
  }

  addToCartWithLogic(product, selectedVariant, price, costValue);
  window.closeProductDetail();
  toggleCart(true);
};

function addToCartWithLogic(product, variantName, price, costValue) {
  const existingIndex = cart.findIndex(item => item.docId === product.docId && item.selectedVariant === variantName);

  if (existingIndex !== -1) {
    cart[existingIndex].quantity = (cart[existingIndex].quantity || 1) + 1;
  } else {
    cart.push({
      ...product,
      selectedVariant: variantName,
      price: price,
      cost: costValue,
      quantity: 1
    });
  }

  cartCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  saveCart();
  updateCartUI();
}

window.changeCartQty = (docId, variantName, delta) => {
  const index = cart.findIndex(item => item.docId === docId && item.selectedVariant === variantName);
  if (index !== -1) {
    if (delta > 0) {
      const product = products.find(p => p.docId === docId);
      if (product && product.mode !== 'Service' && product.mode !== 'Technical') {
        let variantObj = null;
        if (variantName !== 'Default' && product.variants) {
          variantObj = product.variants.find(v => (v.name || v.variantLabel || v.color || v.size || "Variant") === variantName);
        }
        const paymentMethod = document.querySelector('input[name="payment-method"]:checked')?.value || 'COD';
        const currentStock = getProductAvailableStock(product, variantObj, paymentMethod);
        if ((cart[index].quantity || 1) + delta > currentStock) {
          if (paymentMethod === 'ShopPay') {
            alert(`Sorry! Only ${currentStock} available in Shop stock for shop pickup.`);
          } else {
            alert(`Sorry, out of stock! Only ${currentStock} available.`);
          }
          return;
        }
      }
    }
    cart[index].quantity = (cart[index].quantity || 1) + delta;
    if (cart[index].quantity <= 0) {
      cart.splice(index, 1);
    }
    cartCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    saveCart();
    updateCartUI();
    renderCartItems();
  }
};

function updateCartUI() {
  const counts = [
    document.getElementById('cart-count'),
    document.getElementById('cart-count-mobile'),
    document.getElementById('cart-count-dock')
  ];

  counts.forEach(el => {
    if (el) {
      el.innerText = cartCount;
      el.classList.add('bump');
      setTimeout(() => el.classList.remove('bump'), 300);
    }
  });
}

// Coupon discount calculation supporting whole cart, specific products, or specific categories
function calculateCouponDiscount(coupon, currentCart, cartSubtotal) {
  if (!coupon || !currentCart || currentCart.length === 0) {
    return { discountAmount: 0, eligibleSubtotal: 0, isValidForCart: false, reason: '' };
  }

  let eligibleItems = currentCart;
  
  if (coupon.targetType === 'specific_products') {
    const targetList = (coupon.selectedProducts || []).map(p => (p || '').trim().toLowerCase());
    eligibleItems = currentCart.filter(item => {
      const name = (item.name || '').trim().toLowerCase();
      const docId = (item.docId || '').trim().toLowerCase();
      return targetList.includes(name) || targetList.includes(docId);
    });
    if (eligibleItems.length === 0) {
      return { 
        discountAmount: 0, 
        eligibleSubtotal: 0, 
        isValidForCart: false, 
        reason: 'Coupon is only valid for selected products.' 
      };
    }
  } else if (coupon.targetType === 'specific_categories') {
    const targetCats = (coupon.selectedCategories || []).map(c => (c || '').trim().toLowerCase());
    eligibleItems = currentCart.filter(item => {
      const cat = (item.category || '').trim().toLowerCase();
      return targetCats.includes(cat);
    });
    if (eligibleItems.length === 0) {
      return { 
        discountAmount: 0, 
        eligibleSubtotal: 0, 
        isValidForCart: false, 
        reason: `Coupon is only valid for: ${(coupon.selectedCategories || []).join(', ')}` 
      };
    }
  }

  const eligibleSubtotal = eligibleItems.reduce((sum, item) => {
    const discount = item.discount || 0;
    const finalPrice = item.price * (1 - discount / 100);
    const qty = item.quantity || 1;
    return sum + (finalPrice * qty);
  }, 0);

  let discountAmount = 0;
  if (coupon.type === 'Percentage') {
    discountAmount = eligibleSubtotal * (Number(coupon.value) / 100);
  } else {
    discountAmount = Math.min(eligibleSubtotal, Number(coupon.value) || 0);
  }

  return { discountAmount, eligibleSubtotal, isValidForCart: true, reason: '' };
}

function renderCartItems() {
  const subtotal = cart.reduce((sum, item) => {
    const discount = item.discount || 0;
    const finalPrice = item.price * (1 - discount / 100);
    const qty = item.quantity || 1;
    return sum + (finalPrice * qty);
  }, 0);

  let discountAmount = 0;
  if (window.appliedCoupon) {
    const couponCalc = calculateCouponDiscount(window.appliedCoupon, cart, subtotal);
    if (couponCalc.isValidForCart) {
      discountAmount = couponCalc.discountAmount;
    } else {
      window.appliedCoupon = null;
    }
  }
  const finalTotal = Math.max(0, subtotal - discountAmount);

  cartModal.innerHTML = `
        <div class="cart-header">
            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>
            <button class="close-cart" id="close-cart-btn">&times;</button>
        </div>
        
        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">
            <div class="cart-body">
                ${cart.length === 0 ? `
                    <div class="cart-empty-state">
                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>
                        <p>Your cart is empty</p>
                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>
                    </div>
                ` : cart.map((item) => {
    const discount = item.discount || 0;
    const singleFinalPrice = item.price * (1 - discount / 100);
    const qty = item.quantity || 1;
    const itemTotal = singleFinalPrice * qty;

    return `
                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">
                            <div class="cart-item-info" style="flex: 1;">
                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${item.name}</h4>
                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${item.selectedVariant || 'Default'}</div>
                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">
                                    ${discount > 0 ? `<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${item.price.toFixed(2)}</span>` : ''}
                                    LKR ${singleFinalPrice.toFixed(2)} ${qty > 1 ? `<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${qty} = LKR ${itemTotal.toFixed(2)}</span>` : ''}
                                </div>
                            </div>
                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                                <button onclick="window.changeCartQty('${item.docId}', '${item.selectedVariant}', -1)" 
                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">
                                    -
                                </button>
                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${qty}</span>
                                <button onclick="window.changeCartQty('${item.docId}', '${item.selectedVariant}', 1)" 
                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">
                                    +
                                </button>
                            </div>
                        </div>
                    `;
  }).join('')}
            </div>

            ${cart.length > 0 ? `
                <div class="cart-footer">
                    <div class="delivery-info-banner">
                        <span>🚚</span>
                        <span>COD LKR 400 | Bank Transfer LKR 250</span>
                    </div>

                    <!-- Promo / Coupon Code Section -->
                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; gap: 0.5rem;">
                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon ? window.appliedCoupon.code : ''}" ${window.appliedCoupon ? 'disabled' : ''}>
                            ${window.appliedCoupon ? `
                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>
                            ` : `
                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>
                            `}
                        </div>
                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">
                            ${window.appliedCoupon ? `✅ Coupon applied: ${window.appliedCoupon.type === 'Percentage' ? `${window.appliedCoupon.value}% OFF` : `LKR ${window.appliedCoupon.value} OFF`}` : ''}
                        </div>
                    </div>
                    
                    ${window.appliedCoupon ? `
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">
                            <span>Subtotal</span>
                            <span>LKR ${subtotal.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">
                            <span>Coupon Discount (${window.appliedCoupon.code})</span>
                            <span>- LKR ${discountAmount.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">
                            <span>Total Payable</span>
                            <span>LKR ${finalTotal.toFixed(2)}</span>
                        </div>
                    ` : `
                        <div class="cart-subtotal">
                            <span>Total Payable</span>
                            <span>LKR ${subtotal.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="checkout-form-section">
                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>
                        <div class="input-group">
                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem('mec_saved_phone') || ''}">
                        </div>
                        <div class="input-group">
                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem('mec_saved_phone2') || ''}">
                        </div>
                        <div class="input-group" id="delivery-address-group">
                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem('mec_saved_address') || ''}">
                        </div>
                        <div class="input-group" id="delivery-city-group">
                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem('mec_saved_city') || ''}">
                        </div>

                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>
                        <div class="payment-method-selector">
                            ${cart.every(item => {
                                if (item.payMethods) return item.payMethods.cod !== false;
                                return item.payCOD !== false;
                            }) ? `
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">
                                <span class="method-label">COD</span>
                            </label>
                            ` : ''}
                            ${cart.every(item => {
                                if (item.payMethods) return item.payMethods.bank !== false;
                                return item.payBank !== false;
                            }) ? `
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="Bank" ${!cart.every(item => (item.payMethods ? item.payMethods.cod !== false : item.payCOD !== false)) ? 'checked' : ''} onchange="window.onPaymentMethodChange('Bank')">
                                <span class="method-label">Transfer</span>
                            </label>
                            ` : ''}
                            ${cart.every(item => {
                                if (item.payMethods) return item.payMethods.shop !== false;
                                return item.payShop !== false;
                            }) ? `
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="ShopPay" ${(!cart.every(item => (item.payMethods ? item.payMethods.cod !== false : item.payCOD !== false)) && !cart.every(item => (item.payMethods ? item.payMethods.bank !== false : item.payBank !== false))) ? 'checked' : ''} onchange="window.onPaymentMethodChange('ShopPay')">
                                <span class="method-label">Shop Cash</span>
                            </label>
                            ` : ''}
                        </div>
                        
                        <!-- Bank Transfer Info Box -->
                        <!-- Bank Transfer Info Box -->
                        <div id="bank-details-box" style="display: none;">
                            <p style="color: #166534; font-weight: 800; margin-bottom: 0.5rem; font-size: 0.8rem; display: flex; align-items: center; gap: 6px;">
                                <span>✨</span> Lower delivery charge (LKR 250) - Transfer to any account below:
                            </p>

                            <!-- Account 1: National Development Bank (NDB) -->
                            <div class="bank-info-card" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 0.85rem; margin: 0.5rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                                <div style="font-weight: 900; color: #b91c1c; font-size: 0.95rem; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center;">
                                    <span>🏦 National Development Bank (NDB)</span>
                                    <span style="font-size: 0.72rem; background: #fee2e2; color: #991b1b; padding: 2px 8px; border-radius: 6px; font-weight: 700;">NDB</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600;">
                                    <span>Account Name: <span style="color: #0f172a; font-weight: 700;">MEC BOOK SHOP & COMMUNICATION</span></span>
                                    <button type="button" onclick="navigator.clipboard.writeText('MEC BOOK SHOP & COMMUNICATION'); alert('Account Name Copied: MEC BOOK SHOP & COMMUNICATION');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600;">
                                    Account Type: <span style="color: #0f172a; font-weight: 700;">Regular Current</span>
                                </div>
                                <div style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600;">
                                    <span>Bank Code: <strong style="color: #334155;">7214</strong></span>
                                    <span>Swift Code: <strong style="color: #334155;">NDBSLKLX</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>
                                    </div>
                                    <button type="button" onclick="navigator.clipboard.writeText('111000391437'); alert('NDB Account Number Copied: 111000391437');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <!-- Account 2: Bank of Ceylon (BOC) -->
                            <div class="bank-info-card" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                                <div style="font-weight: 900; color: #0284c7; font-size: 0.95rem; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center;">
                                    <span>🏦 Bank of Ceylon (BOC)</span>
                                    <span style="font-size: 0.72rem; background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 6px; font-weight: 700;">BOC</span>
                                </div>
                                <div style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600;">
                                    Branch: <span style="color: #0f172a; font-weight: 700;">Horana Branch</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600;">
                                    <span>Account Name: <span style="color: #0f172a; font-weight: 700;">WPM Shamesh</span></span>
                                    <button type="button" onclick="navigator.clipboard.writeText('WPM Shamesh'); alert('Account Name Copied: WPM Shamesh');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>
                                    </div>
                                    <button type="button" onclick="navigator.clipboard.writeText('0084334885'); alert('BOC Account Number Copied: 0084334885');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <div style="margin-top: 1rem;">
                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>
                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">
                            </div>
                        </div>

                        <!-- Shop Pickup / Branch Selection Box -->
                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch
                            </p>

                            <!-- City / Town Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>
                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>
                                  ${getAvailableTowns().map(t => `<option value="${t}" style="color:#0f172a; background:#ffffff;">${t}</option>`).join('')}
                                </select>
                            </div>

                            <!-- Shop / Branch List Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>
                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <!-- Injected by populatePickupShops -->
                                </select>
                            </div>

                            <!-- Selected Shop Info Card -->
                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">
                            </div>
                        </div>
                    </div>

                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">
                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">
                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">
                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 
                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 
                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.
                        </label>
                    </div>

                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">
                        Confirm Order
                    </button>
                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->
                </div>
            ` : ''}
        </div>
    `;

  document.getElementById('close-cart-btn').onclick = () => toggleCart(false);
  document.getElementById('checkout-btn')?.addEventListener('click', handleCheckout);

  window.toggleBankDetails = (show) => {
    const box = document.getElementById('bank-details-box');
    if (box) box.style.display = show ? 'block' : 'none';
  };

  window.onPaymentMethodChange = (method) => {
    const bankBox = document.getElementById('bank-details-box');
    const shopBox = document.getElementById('shop-pickup-box');
    const addressGroup = document.getElementById('delivery-address-group');
    const cityGroup = document.getElementById('delivery-city-group');
    const titleEl = document.getElementById('contact-details-title');

    if (method === 'Bank') {
      if (bankBox) bankBox.style.display = 'block';
      if (shopBox) shopBox.style.display = 'none';
      if (addressGroup) addressGroup.style.display = 'block';
      if (cityGroup) cityGroup.style.display = 'block';
      if (titleEl) titleEl.innerText = '📦 Delivery Details';
    } else if (method === 'ShopPay') {
      if (bankBox) bankBox.style.display = 'none';
      if (shopBox) {
        shopBox.style.display = 'block';
        window.populatePickupShops();
      }
      if (addressGroup) addressGroup.style.display = 'none';
      if (cityGroup) cityGroup.style.display = 'none';
      if (titleEl) titleEl.innerText = '👤 Customer Contact Details (Shop Pickup)';
    } else {
      // COD
      if (bankBox) bankBox.style.display = 'none';
      if (shopBox) shopBox.style.display = 'none';
      if (addressGroup) addressGroup.style.display = 'block';
      if (cityGroup) cityGroup.style.display = 'block';
      if (titleEl) titleEl.innerText = '📦 Delivery Details';
    }
  };

  window.populatePickupShops = () => {
    const townSelect = document.getElementById('pickup-town-select');
    const shopSelect = document.getElementById('pickup-shop-select');
    const infoCard = document.getElementById('selected-shop-info-card');
    if (!shopSelect) return;

    const selectedTown = townSelect ? townSelect.value : 'All';
    const allShops = getAllAvailableShops();

    let filtered = allShops;
    if (selectedTown && selectedTown !== 'All') {
      filtered = allShops.filter(s => {
        const d = ((s.location || '') + ' ' + (s.city || '') + ' ' + (s.address || '') + ' ' + (s.name || '')).toLowerCase();
        return d.includes(selectedTown.toLowerCase());
      });
    }

    if (filtered.length === 0) {
      // Fallback: show all available shops so customer is never blocked
      shopSelect.innerHTML = allShops.map((s, idx) => `
        <option value="${s.docId || s.id || idx}" ${idx === 0 ? 'selected' : ''} style="color:#0f172a; background:#ffffff;">
          ${s.name || s.shopName || 'Branch'} ${s.location ? `(${s.location})` : ''}
        </option>
      `).join('');
      if (infoCard) {
        infoCard.innerHTML = `<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${selectedTown}</b>. Showing our available pickup branches above:</div>`;
      }
      window.onPickupShopSelected(allShops[0]?.docId || allShops[0]?.id || 0);
    } else {
      shopSelect.innerHTML = filtered.map((s, idx) => `
        <option value="${s.docId || s.id || idx}" ${idx === 0 ? 'selected' : ''} style="color:#0f172a; background:#ffffff;">
          ${s.name || s.shopName || 'Branch'} ${s.location ? `(${s.location})` : ''}
        </option>
      `).join('');

      window.onPickupShopSelected(filtered[0]?.docId || filtered[0]?.id || 0);
    }
  };

  window.filterShopsByTown = (town) => {
    window.populatePickupShops();
  };

  window.onPickupShopSelected = (shopId) => {
    const infoCard = document.getElementById('selected-shop-info-card');
    if (!infoCard) return;

    const allShops = getAllAvailableShops();
    const shop = allShops.find(s => (s.docId === shopId || s.id === shopId)) || allShops[0];
    if (shop) {
      infoCard.innerHTML = `
        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${shop.name || shop.shopName || 'Main Branch'}</div>
        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${shop.location || shop.address || 'In-store Pickup Counter'}</div>
        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${shop.phone ? `Contact: <b>${shop.phone}</b>` : 'Store Pickup Active'}</div>
        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">
          <span>✓</span> Collect & Pay Cash at this shop counter
        </div>
      `;
    }
  };
}

window.applyCouponCode = async () => {
  const inputEl = document.getElementById('cart-promo-input');
  const msgEl = document.getElementById('promo-message');
  if (!inputEl) return;
  const promoCode = inputEl.value.trim().toUpperCase();
  if (!promoCode) {
    if (msgEl) {
      msgEl.innerText = "❌ Please enter a promo code.";
      msgEl.style.color = "#ef4444";
    }
    return;
  }

  if (msgEl) {
    msgEl.innerText = "⏳ Validating coupon...";
    msgEl.style.color = "var(--primary-color)";
  }

  try {
    const q = query(
      promotionsCol, 
      where('code', '==', promoCode), 
      where('storeId', '==', window.currentStoreId)
    );
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      if (msgEl) {
        msgEl.innerText = "❌ Invalid or expired coupon code.";
        msgEl.style.color = "#ef4444";
      }
      return;
    }

    const couponDoc = querySnapshot.docs[0];
    const coupon = { ...couponDoc.data(), id: couponDoc.id };
    
    const today = new Date().toISOString().split('T')[0];
    if (coupon.expiryDate < today) {
      if (msgEl) {
        msgEl.innerText = "❌ This coupon has expired.";
        msgEl.style.color = "#ef4444";
      }
      return;
    }

    if (coupon.status !== 'Active') {
      if (msgEl) {
        msgEl.innerText = "❌ This coupon is inactive.";
        msgEl.style.color = "#ef4444";
      }
      return;
    }

    // Verify if coupon is valid for items in cart
    const currentSubtotal = cart.reduce((sum, item) => sum + (item.price * (1 - (item.discount || 0) / 100) * (item.quantity || 1)), 0);
    const validation = calculateCouponDiscount(coupon, cart, currentSubtotal);
    if (!validation.isValidForCart) {
      if (msgEl) {
        msgEl.innerText = `❌ ${validation.reason || 'Coupon is not applicable to items in your cart.'}`;
        msgEl.style.color = "#ef4444";
      }
      return;
    }

    // Success! Apply it.
    window.appliedCoupon = coupon;
    renderCartItems();
    
    const newMsgEl = document.getElementById('promo-message');
    if (newMsgEl) {
      const appliesNote = coupon.targetType === 'specific_products' ? ' (Selected Items)' : (coupon.targetType === 'specific_categories' ? ' (Selected Categories)' : '');
      newMsgEl.innerText = `✅ Coupon applied: ${coupon.type === 'Percentage' ? `${coupon.value}% OFF` : `LKR ${coupon.value} OFF`}${appliesNote}`;
      newMsgEl.style.color = "#10b981";
    }
  } catch (err) {
    console.error("Error validating coupon:", err);
    if (msgEl) {
      msgEl.innerText = "❌ Error validating coupon code.";
      msgEl.style.color = "#ef4444";
    }
  }
};

window.removeCouponCode = () => {
  window.appliedCoupon = null;
  renderCartItems();
};

async function handleCheckout() {
  const user = JSON.parse(sessionStorage.getItem('mec_user'));
  if (!user) {
    alert('Please login to place an order!');
    window.location.href = '/login.html';
    return;
  }

  if (cart.length === 0) return;

  const termsAgree = document.getElementById('terms-agree');
  if (termsAgree && !termsAgree.checked) {
    alert('Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!');
    return;
  }

  const phone = document.getElementById('delivery-phone')?.value.trim();
  const phone2 = document.getElementById('delivery-phone-2')?.value.trim();
  const address = document.getElementById('delivery-address')?.value.trim();
  const city = document.getElementById('delivery-city')?.value.trim();
  const paymentMethod = document.querySelector('input[name="payment-method"]:checked')?.value || 'COD';
  const slipFile = document.getElementById('deposit-slip')?.files[0];

  const isShopPickup = paymentMethod === 'ShopPay';
  let selectedShop = null;
  let selectedTown = 'All';

  if (isShopPickup) {
    selectedTown = document.getElementById('pickup-town-select')?.value || 'All';
    const selectedShopId = document.getElementById('pickup-shop-select')?.value;
    const allShopsList = getAllAvailableShops();
    selectedShop = allShopsList.find(s => (s.docId === selectedShopId || s.id === selectedShopId)) || allShopsList[0];
    
    if (!selectedShopId && (!allShopsList || allShopsList.length === 0)) {
      alert('Please select a pickup shop / branch!');
      return;
    }
  }

  if (!phone || (!isShopPickup && (!address || !city))) {
    alert(isShopPickup ? 'Please enter your Phone Number for Shop Pickup!' : 'Please fill in all delivery details (Phone, Address, City)!');
    return;
  }

  // SAVE Delivery Details for next time
  localStorage.setItem('mec_saved_phone', phone);
  localStorage.setItem('mec_saved_phone2', phone2);
  localStorage.setItem('mec_saved_address', address);
  localStorage.setItem('mec_saved_city', city);

  if (paymentMethod === 'Bank' && !slipFile) {
    alert('Please upload your bank deposit slip!');
    return;
  }

  // Validate stock based on payment method:
  // - COD / Bank: Web Stock + Shop Stock (Combined total stock)
  // - ShopPay (Shop Pickup): Shop Stock ONLY
  for (const item of cart) {
    const p = products.find(prod => prod.docId === item.docId) || (window.groupedProducts || []).find(prod => prod.docId === item.docId);
    if (p && p.mode !== 'Service' && p.mode !== 'Technical') {
      let vObj = null;
      if (item.selectedVariant && item.selectedVariant !== 'Default' && p.variants) {
        vObj = p.variants.find(v => (v.name || v.variantLabel || v.color || v.size || 'Variant') === item.selectedVariant);
      }
      const availableStock = getProductAvailableStock(p, vObj, paymentMethod);
      if ((item.quantity || 1) > availableStock) {
        if (paymentMethod === 'ShopPay') {
          alert(`Sorry! "${item.name}" only has ${availableStock} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`);
        } else {
          alert(`Sorry! "${item.name}" only has ${availableStock} available in stock.`);
        }
        return;
      }
    }
  }

  const processOrder = async (slipBase64 = null) => {
    try {
      const subtotal = cart.reduce((sum, item) => sum + (item.price * (1 - (item.discount || 0) / 100) * (item.quantity || 1)), 0);
      let couponDiscount = 0;
      let couponCode = '';
      if (window.appliedCoupon) {
        couponCode = window.appliedCoupon.code;
        const calc = calculateCouponDiscount(window.appliedCoupon, cart, subtotal);
        if (calc.isValidForCart) {
          couponDiscount = calc.discountAmount;
        }
      }
      const finalTotal = Math.max(0, subtotal - couponDiscount);

      const refCode = sessionStorage.getItem('mec_ref_code');
      let referredBy = '';
      let referredCommission = 0;
      if (refCode) {
        try {
          const qRef = query(collection(db, 'affiliates'), where('code', '==', refCode), where('storeId', '==', window.currentStoreId));
          const snapRef = await getDocs(qRef);
          if (!snapRef.empty) {
            referredBy = refCode;
            referredCommission = Number((finalTotal * 0.05).toFixed(2));
          }
        } catch (e) {
          console.error("Error verifying affiliate referral code at checkout:", e);
        }
      }

      const storeIdToUse = window.currentStoreId || 'mec-book-shop';
      const userIdToUse = (user && (user.id || user.uid)) ? (user.id || user.uid) : 'guest-' + Date.now();
      const userNameToUse = (user && (user.name || user.email)) ? (user.name || user.email) : (phone || 'Guest Customer');

      const newOrder = {
        orderId: 'ORD-' + Date.now(),
        userId: userIdToUse,
        userName: userNameToUse,
        userEmail: (user && user.email) ? user.email : '',
        phone: phone || '',
        phone2: phone2 || '',
        branchId: isShopPickup ? (selectedShop?.docId || selectedShop?.id || 'main') : 'web-order',
        pickupShopId: isShopPickup ? (selectedShop?.docId || selectedShop?.id || 'main') : '',
        pickupShopName: isShopPickup ? (selectedShop?.name || selectedShop?.shopName || 'Main Branch') : '',
        pickupTown: isShopPickup ? selectedTown : '',
        pickupShopPhone: isShopPickup ? (selectedShop?.phone || '') : '',
        pickupShopAddress: isShopPickup ? (selectedShop?.location || selectedShop?.address || '') : '',
        address: isShopPickup ? `Shop Pickup: ${selectedShop?.name || selectedShop?.shopName || 'Main Branch'} (${selectedShop?.location || selectedShop?.address || 'Store'})` : (address || ''),
        city: isShopPickup ? (selectedTown !== 'All' ? selectedTown : (selectedShop?.location || selectedShop?.city || 'Shop Pickup')) : (city || ''),
        items: cart.map(item => ({
          id: item.id || item.docId || '',
          docId: item.docId || item.id || '',
          name: item.name || '',
          price: Number(item.price) || 0,
          cost: Number(item.cost) || 0,
          quantity: Number(item.quantity) || 1,
          discount: Number(item.discount) || 0,
          finalPrice: Number(item.price) * (1 - (Number(item.discount) || 0) / 100)
        })),
        subtotal: Number(subtotal) || 0,
        discount: Number(couponDiscount) || 0,
        couponCode: couponCode || '',
        total: Number(finalTotal) || 0,
        status: 'Pending',
        customerType: (window.currentUserProfile?.customerType || 'retail').toLowerCase(),
        paymentMethod: paymentMethod || 'COD',
        slipImage: slipBase64 || '',
        codCharge: paymentMethod === 'COD' ? 400 : (paymentMethod === 'Bank' ? 250 : 0),
        isShopPending: paymentMethod === 'ShopPay',
        storeId: storeIdToUse,
        numericStoreId: '1001',
        timestamp: serverTimestamp(),
        date: new Date().toLocaleString(),
        referredBy: referredBy || '',
        referredCommission: Number(referredCommission) || 0
      };

      await addDoc(ordersCol, newOrder);

      if (referredBy) {
        try {
          const qRef = query(collection(db, 'affiliates'), where('code', '==', referredBy), where('storeId', '==', storeIdToUse));
          const snapRef = await getDocs(qRef);
          if (!snapRef.empty) {
            const affDocId = snapRef.docs[0].id;
            await setDoc(doc(db, 'affiliates', affDocId), {
              salesCount: increment(1),
              totalCommission: increment(referredCommission)
            }, { merge: true });
            sessionStorage.removeItem('mec_ref_code');
            sessionStorage.removeItem('mec_ref_clicked');
          }
        } catch (e) {
          console.error("Error updating affiliate statistics post-order:", e);
        }
      }

      cart = [];
      cartCount = 0;
      window.appliedCoupon = null;
      saveCart();
      updateCartUI();
      toggleCart(false);
      if (paymentMethod === 'Bank') {
        alert('Order placed successfully! We will verify your slip soon. Delivery: LKR 250');
      } else if (isShopPickup) {
        alert('Order placed successfully! No delivery charge. Please pay at the shop.');
      } else {
        alert('Order placed successfully! Delivery charge will be LKR 400/-');
      }
    } catch (e) {
      console.error("Order error:", e);
      alert("Error placing order: " + (e.message || "Please try again."));
    }
  };

  if (slipFile) {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1000;
        const MAX_HEIGHT = 1000;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Compress to JPEG with 0.6 quality for fast upload
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.6);
        processOrder(compressedBase64);
      };
      img.onerror = () => {
        // Fallback to original data URL if non-image PDF or load error
        processOrder(event.target.result);
      };
      img.src = event.target.result;
    };
    reader.onerror = (err) => {
      console.error("FileReader Error:", err);
      alert("Error reading slip file. Please try selecting the image again.");
    };
    reader.readAsDataURL(slipFile);
  } else {
    processOrder();
  }
}

function renderProducts() {
  const grid = document.querySelector('#product-grid');
  const pagControls = document.getElementById('pagination-controls');
  if (!grid) return;

  // 1. Filter
  let displayProducts = products.filter(p => {
    // Hide Service, Technical and POS-only items from the website store
    if (p.mode === 'Service' || p.mode === 'Technical' || p.mode === 'POS') return false;
    
    // Fallback for legacy items added as 'Other' without a mode
    const n = (p.name || '').toLowerCase();
    if (n === 'call' || n.includes('repair') || n.includes('repire') || n.includes('rapair') || n.includes('print out') || n.includes('photo print')) {
        return false;
    }

    const matchesCategory = currentCategory === 'All' || p.category === currentCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery) || 
                         p.category.toLowerCase().includes(searchQuery) ||
                         (p.sku && p.sku.toLowerCase().includes(searchQuery));
    return matchesCategory && matchesSearch;
  });

  // 2. Sort
  if (currentSort === 'recommended') {
    // Generate a stable random order for the session if not exists
    if (!seededRandomOrder || seededRandomOrder.length !== displayProducts.length) {
      seededRandomOrder = displayProducts.map((_, i) => ({ id: i, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(item => item.id);
    }
    // Simple shuffle for demonstration - users like seeing different things
    displayProducts.sort(() => Math.random() - 0.5);
  } else {
    displayProducts.sort((a, b) => {
      if (currentSort === 'az') return a.name.localeCompare(b.name);
      if (currentSort === 'za') return b.name.localeCompare(a.name);
      if (currentSort === 'low') {
        const p1 = a.variants && a.variants.length > 0 ? a.variants[0].price : a.price;
        const p2 = b.variants && b.variants.length > 0 ? b.variants[0].price : b.price;
        return p1 - p2;
      }
      if (currentSort === 'high') {
        const p1 = a.variants && a.variants.length > 0 ? a.variants[0].price : a.price;
        const p2 = b.variants && b.variants.length > 0 ? b.variants[0].price : b.price;
        return p2 - p1;
      }
      return 0;
    });
  }

  // 1.5 Group virtual variants
  const groupedMap = new Map();
  displayProducts.forEach(p => {
      // Regex to extract base name and variant label from names like "Product (Size: small)"
      const nameMatch = p.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i);
      const baseName = nameMatch ? nameMatch[1].trim() : p.name.trim();
      const variantLabel = nameMatch ? nameMatch[2].trim() : (p.size || p.color ? `${p.size ? p.size : ''} ${p.color ? p.color : ''}`.trim() || 'Default' : 'Default');
      
      const key = baseName.toLowerCase();
      if (!groupedMap.has(key)) {
          const initialVariants = (p.variants || []).map(v => ({ ...v, sourceDocId: p.docId }));
          if (initialVariants.length === 0) {
              initialVariants.push({
                  name: variantLabel,
                  price: p.price,
                  wholesalePrice: p.wholesalePrice,
                  loyaltyPrice: p.loyaltyPrice,
                  cost: p.cost,
                  stock: p.stock || 0,
                  images: [p.image],
                  sourceDocId: p.docId
              });
          }
          groupedMap.set(key, {
              ...p,
              name: baseName, // Use the cleaned base name
              totalStock: p.totalStock !== undefined ? p.totalStock : (p.stock || 0),
              variants: initialVariants
          });
      } else {
          const existing = groupedMap.get(key);
          existing.totalStock += (p.totalStock !== undefined ? p.totalStock : (p.stock || 0));
          const newVariants = (p.variants || []).map(v => ({ ...v, sourceDocId: p.docId }));
          if (newVariants.length === 0) {
              newVariants.push({
                  name: variantLabel,
                  price: p.price,
                  wholesalePrice: p.wholesalePrice,
                  loyaltyPrice: p.loyaltyPrice,
                  cost: p.cost,
                  stock: p.stock || 0,
                  images: [p.image],
                  sourceDocId: p.docId
              });
          }
          existing.variants = [...existing.variants, ...newVariants];
      }
  });

  window.groupedProducts = Array.from(groupedMap.values());

  // 3. Pagination Data
  const totalItems = window.groupedProducts.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  if (currentPage > totalPages && totalPages > 0) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;

  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedProducts = window.groupedProducts.slice(startIndex, startIndex + itemsPerPage);

  // 4. Render Grid — show empty state if no results
  if (window.groupedProducts.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>
        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${searchQuery}</strong>".<br>Try a different keyword or browse all categories.</p>
        <button onclick="window.clearSearch()" 
          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"
          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
          Clear Search
        </button>
      </div>`;
    if (pagControls) pagControls.innerHTML = '';
    return;
  }

  grid.innerHTML = paginatedProducts.map(product => {
    const hasVariants = product.variants && product.variants.length > 0;
    const defaultVariant = hasVariants ? product.variants[0] : null;

    // DETERMINE PRICE BASED ON USER TYPE VIA ENGINE
    const priceInfo = getCustomerEffectivePrice(product, defaultVariant);
    const retailPrice = priceInfo.retailPrice;
    const discountedPrice = priceInfo.discountedPrice;
    const isSpecial = priceInfo.isSpecial;
    const userType = priceInfo.userType;
    const discount = Number(product.discount) || 0;

    // STOCK RESOLUTION: Combined Web Stock + Shop Stock together
    let stock = getProductTotalStock(product, defaultVariant);
    if (isNaN(stock)) stock = 0;
    
    // MAIN IMAGE RESOLUTION: Prefer the product's primary cover image so the multi-item/cover image is shown on the card
    let displayImage = product.image;
    if (!displayImage || displayImage.trim() === '' || displayImage.includes('/logo.png')) {
        if (defaultVariant) {
            if (defaultVariant.images && defaultVariant.images.length > 0) displayImage = defaultVariant.images[0];
            else if (defaultVariant.image) displayImage = defaultVariant.image;
        }
    }
    displayImage = resolveProductImage(displayImage, product.name);

    // Check for NEW (within 7 days) or HOT (Random best seller simulation)
    // Safe timestamp conversion: Firestore Timestamp has .toMillis(), plain numbers are already ms
    const tsMs = product.timestamp
        ? (typeof product.timestamp.toMillis === 'function'
            ? product.timestamp.toMillis()
            : (typeof product.timestamp === 'number' ? product.timestamp : 0))
        : 0;
    const isNew = tsMs > 0 && (Date.now() - tsMs < 7 * 24 * 60 * 60 * 1000);

    return `
    <div class="product-card" id="product-${product.docId}">
      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${product.docId}')">
        <div class="image-slider-container" style="height: 100%; width: 100%;">
            <img src="${displayImage}" class="main-product-img" alt="${product.name}" 
                loading="lazy" decoding="async"
                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 
                style="width:100%; height:100%; object-fit:cover;">
        </div>
        ${stock <= 0 ? '<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>' : ''}
        ${discount > 0 ? `<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${discount}% OFF</div>` : (isNew ? `<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>` : '')}
        
        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">
            ${(defaultVariant?.images || [product.image]).map((img, i) => `<div class="dot ${i === 0 ? 'active' : ''}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${i === 0 ? 'background: #00aeef; width: 12px; border-radius: 4px;' : ''}"></div>`).join('')}
        </div>

        ${hasVariants ? `
          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${product.docId}')">
            Select Options
          </button>
        ` : `
          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${product.docId}')" ${stock <= 0 ? 'disabled style="background:#cbd5e1; cursor:not-allowed;"' : ''}>
            ${stock <= 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        `}
      </div>
      <div class="product-info">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">
          <div style="font-size: 0.8rem; color: var(--text-light);">${product.category}</div>
          <div class="stock-display" style="font-size: 0.75rem; color: ${stock < 5 ? '#ef4444' : '#10b981'}; font-weight:700;">Stock: ${stock}</div>
        </div>
        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${product.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">
          ${product.name}
        </div>
        


        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">
            ${(discount > 0 || isSpecial) ? `<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${retailPrice.toFixed(2)}</span>` : ''}
            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${discountedPrice.toFixed(2)}</span>
            ${isSpecial ? `<span style="background:${userType === 'wholesale' ? 'rgba(234,179,8,0.18)' : 'rgba(16,185,129,0.18)'}; color:${userType === 'wholesale' ? '#facc15' : '#10b981'}; border:1px solid ${userType === 'wholesale' ? 'rgba(234,179,8,0.4)' : 'rgba(16,185,129,0.4)'}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${userType}</span>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');

  // 5. Pagination UI
  if (pagControls) {
    if (totalPages > 1) {
      let pagHTML = `<button class="pag-nav-btn" ${currentPage === 1 ? 'disabled' : ''} onclick="window.changePage(${currentPage - 1})">‹ Previous</button>`;

      const maxVisible = 5;
      let startPage = Math.max(1, currentPage - 2);
      let endPage = Math.min(totalPages, startPage + maxVisible - 1);

      if (endPage === totalPages) {
        startPage = Math.max(1, endPage - maxVisible + 1);
      }

      // First Page + Dots
      if (startPage > 1) {
        pagHTML += `<button class="pag-page-btn" onclick="window.changePage(1)">1</button>`;
        if (startPage > 2) pagHTML += `<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>`;
      }

      // Middle Pages
      for (let i = startPage; i <= endPage; i++) {
        pagHTML += `<button class="pag-page-btn ${i === currentPage ? 'active' : ''}" onclick="window.changePage(${i})">${i}</button>`;
      }

      // Last Page + Dots
      if (endPage < totalPages) {
        if (endPage < totalPages - 1) pagHTML += `<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>`;
        pagHTML += `<button class="pag-page-btn" onclick="window.changePage(${totalPages})">${totalPages}</button>`;
      }

      pagHTML += `<button class="pag-nav-btn" ${currentPage === totalPages ? 'disabled' : ''} onclick="window.changePage(${currentPage + 1})">Next ›</button>`;
      pagControls.innerHTML = pagHTML;
    } else {
      pagControls.innerHTML = '';
    }
  }


}

window.changePage = (page) => {
  currentPage = page;
  renderProducts();
  document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' });
};

// Global function to update product card when variant changes
window.updateProductDisplay = (docId, variantIndex) => {
  const product = window.groupedProducts ? window.groupedProducts.find(p => p.docId === docId) : null;
  const card = document.getElementById(`product-${docId}`);
  if (!product || !card) return;

  const variant = product.variants && product.variants[variantIndex] ? product.variants[variantIndex] : null;
  const priceInfo = getCustomerEffectivePrice(product, variant);
  const retailPrice = priceInfo.retailPrice;
  const discountedPrice = priceInfo.discountedPrice;
  const isSpecial = priceInfo.isSpecial;
  const discount = Number(product.discount) || 0;
  const stock = variant ? (variant.stock !== undefined ? variant.stock : (product.stock || 0)) : (product.stock || 0);

  let variantImgList = [];
  if (variant && variant.images && variant.images.length > 0) variantImgList = variant.images;
  else if (variant && variant.image) variantImgList = [variant.image];
  else if (product.images && product.images.length > 0) variantImgList = product.images;
  else variantImgList = [product.image];

  const images = variantImgList.map(img => resolveProductImage(img, product.name));


  // Update Price
  const originalPriceEl = card.querySelector('.original-price');
  const finalPriceEl = card.querySelector('.final-price');
  if (originalPriceEl) {
    originalPriceEl.innerText = `LKR ${retailPrice.toFixed(2)}`;
    originalPriceEl.style.display = (discount > 0 || isSpecial) ? 'inline' : 'none';
  }
  if (finalPriceEl) finalPriceEl.innerText = `LKR ${discountedPrice.toFixed(2)}`;

  // Update Stock
  const stockEl = card.querySelector('.stock-display');
  stockEl.innerText = `Stock: ${stock}`;
  stockEl.style.color = stock < 5 ? '#ef4444' : '#10b981';

  // Update Add to Cart Button
  const btn = card.querySelector('.add-to-cart-btn');
  if (stock <= 0) {
    btn.disabled = true;
    btn.innerText = 'Out of Stock';
    btn.style.background = '#cbd5e1';
    btn.style.cursor = 'not-allowed';
  } else {
    btn.disabled = false;
    btn.innerText = 'Add to Cart';
    btn.style.background = '';
    btn.style.cursor = 'pointer';
  }

  // Update Image and Dots
  const imgEl = card.querySelector('.main-product-img');
  imgEl.src = images[0];

  const dotsContainer = card.querySelector('.image-dots');
  dotsContainer.innerHTML = images.map((_, i) => `<div class="dot ${i === 0 ? 'active' : ''}" style="width: 6px; height: 6px; border-radius: 50%; background: ${i === 0 ? 'white' : 'rgba(255,255,255,0.5)'};"></div>`).join('');

  // Handle image cycling if multiple images
  if (images.length > 1) {
    let currentImgIdx = 0;
    if (card.imageInterval) clearInterval(card.imageInterval);
    card.imageInterval = setInterval(() => {
      currentImgIdx = (currentImgIdx + 1) % images.length;
      imgEl.style.opacity = '0.5';
      setTimeout(() => {
        imgEl.src = images[currentImgIdx];
        imgEl.style.opacity = '1';
        // Update active dot
        const dots = dotsContainer.querySelectorAll('.dot');
        dots.forEach((dot, idx) => {
          dot.style.background = idx === currentImgIdx ? 'white' : 'rgba(255,255,255,0.5)';
        });
      }, 300);
    }, 3000);
  } else {
    if (card.imageInterval) clearInterval(card.imageInterval);
  }
};

// Auth State Management
function checkUserAuth() {
  const navAuthItem = document.getElementById('nav-auth-item');
  const userProfileSection = document.getElementById('user-profile');
  const userDisplayName = document.getElementById('user-display-name');

  onAuthStateChanged(auth, (user) => {
    const heroTitle = document.getElementById('hero-title');
    const heroSubtitle = document.getElementById('hero-subtitle');

    if (user) {
      // User is signed in
      const userData = {
        name: user.displayName || user.email.split('@')[0],
        email: user.email,
        id: user.uid
      };
      sessionStorage.setItem('mec_user', JSON.stringify(userData));

      const updateNavHeaderUI = () => {
        if (!navAuthItem) return;
        const currentCustType = (window.currentUserProfile?.customerType || 'retail').toLowerCase();
        const customerPhone = window.currentUserProfile?.phone || window.currentUserProfile?.contact || '';
        const userPhoto = user.photoURL || window.currentUserProfile?.photoURL || window.currentUserProfile?.avatar || '';

        const getInitials = (name) => {
          if (!name) return 'U';
          const parts = name.trim().split(' ');
          if (parts.length >= 2) {
            return (parts[0][0] + parts[1][0]).toUpperCase();
          }
          return name.slice(0, 2).toUpperCase();
        };
        const initials = getInitials(userData.name);

        const badgePill = currentCustType === 'wholesale' 
          ? `<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>` 
          : (currentCustType === 'loyalty' ? `<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>` : '');

        const tierBannerHTML = currentCustType === 'wholesale' 
          ? `<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">
               <span>👑</span> Wholesale Customer (Wholesale Price Active)
             </div>`
          : (currentCustType === 'loyalty' 
              ? `<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>💎</span> Loyalty Card Member Active
                 </div>`
              : `<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>🛍️</span> Standard Retail Customer
                 </div>`);

        navAuthItem.innerHTML = `
          <div style="position: relative; display: inline-block;">
            <!-- Circular Avatar Only Trigger Button -->
            <button id="user-profile-trigger" style="
              background: transparent;
              border: none;
              padding: 2px;
              cursor: pointer;
              outline: none;
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
            " title="${userData.name}">
              
              <!-- Circular Avatar Photo / Initials -->
              <div style="
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0284c7, #6366f1);
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 800;
                font-size: 0.88rem;
                color: white;
                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);
                border: 2px solid ${currentCustType === 'wholesale' ? '#eab308' : (currentCustType === 'loyalty' ? '#10b981' : '#38bdf8')};
                overflow: hidden;
                flex-shrink: 0;
                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 
                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">
                ${userPhoto ? `<img src="${userPhoto}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">` : initials}
              </div>

              <!-- Status Badge Dot -->
              ${currentCustType === 'wholesale' 
                ? `<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>` 
                : (currentCustType === 'loyalty' 
                    ? `<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>` 
                    : '')}
            </button>

            <!-- Modern Floating Profile Card Dropdown -->
            <div id="user-profile-dropdown" style="
              display: none;
              position: absolute;
              right: 0;
              top: calc(100% + 12px);
              width: 290px;
              background: #0f172a;
              border: 1px solid rgba(255, 255, 255, 0.15);
              border-radius: 16px;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);
              padding: 1.25rem;
              z-index: 10000;
              text-align: left;
            ">
              <!-- Profile Card Header -->
              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div style="
                  width: 46px;
                  height: 46px;
                  border-radius: 50%;
                  background: linear-gradient(135deg, #0284c7, #8b5cf6);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 1.1rem;
                  color: white;
                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
                  border: 2px solid rgba(255,255,255,0.6);
                  overflow: hidden;
                  flex-shrink: 0;
                ">
                  ${userPhoto ? `<img src="${userPhoto}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">` : initials}
                </div>
                <div style="overflow: hidden; flex: 1;">
                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">
                      ${userData.name}
                    </span>
                    ${badgePill}
                  </div>
                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                    ${userData.email || 'Registered Customer'}
                  </div>
                </div>
              </div>

              <!-- Account Details & Benefits -->
              <div style="margin: 12px 0;">
                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">
                  Account Membership
                </div>
                ${tierBannerHTML}
                
                ${customerPhone ? `
                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">
                    <span style="color:#38bdf8;">📞</span> <span>${customerPhone}</span>
                  </div>
                ` : ''}
              </div>

              <!-- Quick Actions -->
              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">
                <a href="/track.html" style="
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  padding: 8px 12px;
                  background: rgba(255, 255, 255, 0.05);
                  border: 1px solid rgba(255, 255, 255, 0.08);
                  border-radius: 8px;
                  color: #f1f5f9;
                  text-decoration: none;
                  font-size: 0.82rem;
                  font-weight: 600;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">
                  <span style="display:flex; align-items:center; gap:8px;">
                    <span>📦</span> Track My Orders
                  </span>
                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>
                </a>
              </div>

              <!-- Divider & Logout Button -->
              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">
                <button id="nav-logout-btn" style="
                  width: 100%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 8px;
                  background: rgba(239, 68, 68, 0.12);
                  border: 1px solid rgba(239, 68, 68, 0.3);
                  color: #f87171;
                  padding: 8px 12px;
                  border-radius: 8px;
                  font-size: 0.85rem;
                  font-weight: 700;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"
                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">
                  <span>🚪</span> Log Out
                </button>
              </div>
            </div>
          </div>
        `;

        const trigger = document.getElementById('user-profile-trigger');
        const dropdown = document.getElementById('user-profile-dropdown');
        if (trigger && dropdown) {
          trigger.onclick = (e) => {
            e.stopPropagation();
            const isOpen = dropdown.style.display === 'block';
            dropdown.style.display = isOpen ? 'none' : 'block';
          };
        }

        const logoutBtn = document.getElementById('nav-logout-btn');
        if (logoutBtn) {
          logoutBtn.onclick = async (e) => {
            e.stopPropagation();
            if (!navigator.onLine) {
              alert("You are currently offline. Unsaved data will be lost if you logout now.");
              return;
            }
            try {
              sessionStorage.removeItem('mec_user');
              sessionStorage.removeItem('mec_customer_profile');
              window.currentUserProfile = { customerType: 'retail' };
              await signOut(auth);
              window.location.href = '/';
            } catch (error) {
              console.error("Logout Error:", error);
              sessionStorage.removeItem('mec_user');
              sessionStorage.removeItem('mec_customer_profile');
              window.currentUserProfile = { customerType: 'retail' };
              window.location.reload();
            }
          };
        }
      };

      // Close profile dropdown on outside click
      document.addEventListener('click', (e) => {
        const trigger = document.getElementById('user-profile-trigger');
        const dropdown = document.getElementById('user-profile-dropdown');
        if (dropdown && trigger && !trigger.contains(e.target) && !dropdown.contains(e.target)) {
          dropdown.style.display = 'none';
        }
      });

      updateNavHeaderUI();

      // Fetch customer data from Firestore with robust matching
      const userEmail = (user.email || '').trim();
      const userEmailLower = userEmail.toLowerCase();
      
      const q1 = query(collection(db, 'customers'), where('email', '==', userEmail));
      const q2 = query(collection(db, 'customers'), where('email', '==', userEmailLower));

      Promise.all([getDocs(q1), getDocs(q2)]).then(([snap1, snap2]) => {
          let foundDoc = null;
          if (!snap1.empty) {
              foundDoc = snap1.docs[0].data();
          } else if (!snap2.empty) {
              foundDoc = snap2.docs[0].data();
          }

          if (foundDoc) {
              const custType = (foundDoc.customerType || foundDoc.type || (foundDoc.loyaltyCardNo ? 'loyalty' : 'retail')).toLowerCase();
              window.currentUserProfile = { ...foundDoc, customerType: custType };
              sessionStorage.setItem('mec_customer_profile', JSON.stringify(window.currentUserProfile));
              updateNavHeaderUI();
              renderProducts();
          } else {
              // Broader search by store if exact email match didn't find it
              const currentStore = window.currentStoreId || 'mec-book-shop';
              getDocs(query(collection(db, 'customers'), where('storeId', '==', currentStore))).then(snapStore => {
                  const userDisplayNameClean = (user.displayName || user.email.split('@')[0] || '').trim().toLowerCase();
                  const matched = snapStore.docs.find(d => {
                      const cData = d.data();
                      const cEmail = (cData.email || '').trim().toLowerCase();
                      const cPhone = (cData.phone || '').trim();
                      const cName = (cData.name || '').trim().toLowerCase();
                      
                      const emailMatches = cEmail && cEmail === userEmailLower;
                      const phoneMatches = user.phoneNumber && cPhone && (cPhone === user.phoneNumber || user.phoneNumber.includes(cPhone));
                      const nameMatches = cName && userDisplayNameClean && (
                          cName === userDisplayNameClean ||
                          userDisplayNameClean.includes(cName) ||
                          cName.includes(userDisplayNameClean) ||
                          userDisplayNameClean.split(' ')[0] === cName
                      );
                      return emailMatches || phoneMatches || nameMatches;
                  });
                  if (matched) {
                      const cData = matched.data();
                      const custType = (cData.customerType || cData.type || (cData.loyaltyCardNo ? 'loyalty' : 'retail')).toLowerCase();
                      window.currentUserProfile = { ...cData, customerType: custType, docId: matched.id };
                      // Auto-link email if missing
                      if (!cData.email && user.email) {
                          updateDoc(doc(db, 'customers', matched.id), { email: user.email }).catch(() => {});
                      }
                  } else {
                      window.currentUserProfile = { customerType: 'retail' };
                  }
                  sessionStorage.setItem('mec_customer_profile', JSON.stringify(window.currentUserProfile));
                  updateNavHeaderUI();
                  renderProducts();
              }).catch(() => {
                  window.currentUserProfile = { customerType: 'retail' };
                  sessionStorage.setItem('mec_customer_profile', JSON.stringify(window.currentUserProfile));
                  updateNavHeaderUI();
                  renderProducts();
              });
          }
      }).catch(err => {
          console.error("Error fetching user profile:", err);
          window.currentUserProfile = { customerType: 'retail' };
          updateNavHeaderUI();
          renderProducts();
      });

    } else {
      // User is signed out
      sessionStorage.removeItem('mec_user');
      sessionStorage.removeItem('mec_customer_profile');
      window.currentUserProfile = { customerType: 'retail' };
      renderProducts();

      if (navAuthItem) {
        navAuthItem.innerHTML = `<a href="/login">Login</a>`;
      }
      if (userProfileSection) {
        userProfileSection.style.display = 'none';
      }
    }
  });
}

function renderUserOrdersUI(userOrders) {
  const list = document.getElementById('user-orders-list');
  if (!list) return;

  list.innerHTML = userOrders.length === 0 ? `
    <div class="empty-orders">
      <p>You haven't placed any orders yet.</p>
      <button class="category-btn active" onclick="document.getElementById('products').scrollIntoView({behavior:'smooth'})">Start Shopping</button>
    </div>
  ` : userOrders.map(order => `
        <div class="order-card">
            <div class="order-info">
                <div class="order-id">${order.orderId}</div>
                <div class="order-meta">${order.date} • ${order.items.length} items</div>
                <div class="order-total">LKR ${order.total.toFixed(2)}</div>
            </div>
            <div class="order-status-col">
                <span class="status-badge" data-status="${order.status}">
                    ${order.status}
                </span>
            </div>
        </div>
  `).join('');
}

function getStatusBg(status) {
  if (status === 'Pending') return '#fee2e2';
  if (status === 'Processing') return '#fef3c7';
  if (status === 'Shipped') return '#dcfce7';
  if (status === 'Delivered') return '#dbeafe';
  return '#eee';
}

function getStatusColor(status) {
  if (status === 'Pending') return '#991b1b';
  if (status === 'Processing') return '#92400e';
  if (status === 'Shipped') return '#166534';
  if (status === 'Delivered') return '#1e40af';
  return '#333';
}

// Logout logic is now handled in the nav bar

// Real-time Reviews for Homepage
function loadReviews() {
  const reviewsContainer = document.getElementById('reviews-container');
  if (!reviewsContainer) return;

  const reviewsCol = collection(db, 'reviews');
  const q = query(reviewsCol, orderBy('timestamp', 'desc'), limit(15));

  onSnapshot(q, (snapshot) => {
    const reviews = snapshot.docs.map(doc => doc.data());

    if (reviews.length === 0) {
      reviewsContainer.innerHTML = '<p class="loading-text">No reviews yet. Be the first to review us!</p>';
      return;
    }

    reviewsContainer.innerHTML = reviews.map(rev => `
      <div class="review-card">
        <div class="review-stars">
          ${'★'.repeat(rev.rating)}${'☆'.repeat(5 - rev.rating)}
        </div>
        <p class="review-comment">"${rev.comment || 'No comment provided.'}"</p>
        <div class="review-footer">
          <span class="review-author">${rev.userName}</span>
          <span class="review-date">${rev.date}</span>
        </div>
      </div>
    `).join('');
  });
}

// Initialize
updateGreeting();
loadCart();
checkUserAuth();
loadReviews();

/* --- Real Gemini AI Interaction --- */
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || "AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";
let genAI = null;
try {
  if (GEMINI_API_KEY) {
    genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
  }
} catch (err) {
  console.warn("Could not instantiate GoogleGenerativeAI client:", err);
}

// Local smart search fallback when offline or API limit reached
function getLocalCatalogAnswer(userText, isSinhala) {
  if (!products || products.length === 0) {
    return isSinhala
      ? "සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න."
      : "Sorry, unable to load product information right now. Please try again.";
  }

  const queryLower = (userText || "").toLowerCase();
  const words = queryLower.split(/\s+/).filter(w => w.length > 2);
  
  // Rank products by keyword matches
  const scored = products.map(p => {
    let score = 0;
    const nameLower = (p.name || "").toLowerCase();
    const catLower = (p.category || "").toLowerCase();
    const descLower = (p.description || "").toLowerCase();
    
    words.forEach(w => {
      if (nameLower.includes(w)) score += 3;
      if (catLower.includes(w)) score += 2;
      if (descLower.includes(w)) score += 1;
    });
    return { product: p, score };
  }).filter(item => item.score > 0).sort((a, b) => b.score - a.score);

  if (scored.length > 0) {
    const top = scored.slice(0, 3).map(s => s.product);
    if (isSinhala) {
      const itemsText = top.map(p => {
        const stockStatus = (p.stock > 0 || (p.variants && p.variants.some(v => v.stock > 0))) ? "තොග ඇත (In Stock)" : "තොග අවසන් (Out of Stock)";
        const wholesaleTxt = p.wholesalePrice ? ` | තොග මිල: LKR ${p.wholesalePrice}` : '';
        return `• ${p.name} - LKR ${p.price}${wholesaleTxt} [${stockStatus}]`;
      }).join('\n');
      return `ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:\n${itemsText}\n\nවැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`;
    } else {
      const itemsText = top.map(p => {
        const stockStatus = (p.stock > 0 || (p.variants && p.variants.some(v => v.stock > 0))) ? "In Stock" : "Out of Stock";
        const wholesaleTxt = p.wholesalePrice ? ` | Wholesale: LKR ${p.wholesalePrice}` : '';
        return `• ${p.name} - LKR ${p.price}${wholesaleTxt} [${stockStatus}]`;
      }).join('\n');
      return `Yes, we found the following matching items in stock:\n${itemsText}\n\nFor bulk or wholesale inquiries, please click the Support button!`;
    }
  }

  return isSinhala
    ? "ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න."
    : "Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team.";
}

async function getGeminiResponse(userText, lang) {
  const isSinhala = /[\u0D80-\u0DFF]/.test(userText) || lang === 'si' || 
    ['ow', 'ne', 'hoyala', 'mata', 'thiyenawada', 'tiyenawada', 'kiyada', 'poth', 'atlas'].some(w => (userText || '').toLowerCase().includes(w));

  try {
    // 1. Direct REST or SDK call
    const storeName = window.currentStoreData?.name || 'MEC Book Shop, Horana';
    
    // Format compact product catalog (up to 50 active products)
    const productInfo = (products || []).slice(0, 50).map(p => {
      let info = `${p.name} (Retail: LKR ${p.price}${p.wholesalePrice ? `, Wholesale: LKR ${p.wholesalePrice}` : ''})`;
      if (p.variants && p.variants.length > 0) {
        info += ` [Variants: ${p.variants.map(v => `${v.name || v.variantLabel || "Var"}-Stock:${v.stock || 0}`).join(', ')}]`;
      } else {
        info += ` [Stock: ${p.stock || 0}]`;
      }
      return info;
    }).join(' | ');

    const systemInstruction = `You are the polite, helpful AI Store Assistant for ${storeName}.
Available Inventory & Prices:
${productInfo}

CRITICAL RULES:
1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).
2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.
3. Keep answers concise, clear, and direct (max 2-3 short sentences).
4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;

    // Try using GoogleGenerativeAI SDK first
    if (genAI) {
      try {
        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
        const result = await model.generateContent(`${systemInstruction}\n\nCustomer Query: "${userText}"`);
        const response = await result.response;
        const text = response.text().trim();
        if (text) return text;
      } catch (sdkErr) {
        console.warn("SDK gemini-2.5-flash failed, trying direct REST call:", sdkErr);
      }
    }

    // Direct REST API Fallback
    const restUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
    const restResp = await fetch(restUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: `${systemInstruction}\n\nCustomer Query: "${userText}"` }]
        }]
      })
    });

    if (restResp.ok) {
      const data = await restResp.json();
      const ans = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (ans && ans.trim()) return ans.trim();
    }

    // If both failed, use smart local search fallback
    return getLocalCatalogAnswer(userText, isSinhala);
  } catch (error) {
    console.error("Gemini Assistant Error, using local catalog fallback:", error);
    return getLocalCatalogAnswer(userText, isSinhala);
  }
}

/* --- [v3.12.42] Robust Gemini Chat Logic --- */
window.toggleGeminiChat = (show) => {
    const chatWin = document.getElementById('gemini-chat-window');
    const bubble = document.getElementById('gemini-bubble');
    if (!chatWin) return;

    const shouldShow = (show !== undefined && show !== null) ? !!show : !chatWin.classList.contains('active');

    if (shouldShow) {
        chatWin.classList.add('active');
        if (bubble) bubble.classList.remove('active');
        document.getElementById('gemini-chat-input')?.focus();
    } else {
        chatWin.classList.remove('active');
    }
};

window.sendGeminiChatMessage = async () => {
    const input = document.getElementById('gemini-chat-input');
    const msgArea = document.getElementById('gemini-chat-messages');
    if (!input || !msgArea || !input.value.trim()) return;

    const userText = input.value.trim();
    input.value = '';

    // Append User Message
    const userDiv = document.createElement('div');
    userDiv.className = 'user-msg';
    userDiv.textContent = userText;
    msgArea.appendChild(userDiv);
    msgArea.scrollTop = msgArea.scrollHeight;

    // Thinking Indicator
    const aiDiv = document.createElement('div');
    aiDiv.className = 'ai-msg';
    aiDiv.textContent = 'Thinking...';
    msgArea.appendChild(aiDiv);
    msgArea.scrollTop = msgArea.scrollHeight;

    // 1. Check for hard Search Intent
    const inputLower = userText.toLowerCase();
    const searchKeywords = ['search', 'find', 'hoyala', 'hoyanna', 'balanna', 'thiyenawada', 'tiyenawada', 'look for', 'get me'];
    let queryTerm = userText;
    let isSearch = false;
    searchKeywords.forEach(kw => { if (inputLower.includes(kw)) isSearch = true; });

    if (isSearch) {
      searchKeywords.forEach(kw => { queryTerm = queryTerm.replace(new RegExp(kw, 'gi'), ''); });
      queryTerm = queryTerm.replace(/for/gi, '').replace(/mata/gi, '').replace(/whalsale/gi, '').replace(/wholesale/gi, '').replace(/poth/gi, '').trim();

      if (queryTerm.length > 1) {
        window.searchQuery = queryTerm;
        searchQuery = queryTerm; // sync local variable too
        const searchInput = document.getElementById('store-search');
        if (searchInput) searchInput.value = queryTerm;
        currentPage = 1;
        window.currentPage = 1;
        if (window.renderProducts) window.renderProducts();
        document.getElementById('shop-section')?.scrollIntoView({ behavior: 'smooth' });
      }
    }

    // 2. Get AI Response (auto-detects Sinhala/Singlish/English)
    const isSi = /[\u0D80-\u0DFF]/.test(userText) || ['mata', 'thiyenawada', 'tiyenawada', 'poth'].some(k => inputLower.includes(k));
    const aiText = await getGeminiResponse(userText, isSi ? 'si' : 'en');
    aiDiv.textContent = aiText;
    msgArea.scrollTop = msgArea.scrollHeight;
};

window.talkToAgentWhatsApp = () => {
    const msgArea = document.getElementById('gemini-chat-messages');
    let history = "";
    if (msgArea) {
        const msgs = Array.from(msgArea.querySelectorAll('div'));
        history = msgs.map(m => `${m.classList.contains('user-msg') ? 'Customer' : 'AI'}: ${m.textContent}`).join('\n');
    }

    // Dynamically retrieve store phone or systemConfig phone
    let phone = window.currentStoreData?.phone || window.systemConfig?.invPhone || "94770658356";
    phone = phone.replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) phone = '94' + phone.substring(1);
    const intro = `Hi ${window.currentStoreData?.name || 'MEC Support'}! I was chatting with your AI assistant. Here is my query:\n\n`;
    const finalMsg = encodeURIComponent(intro + history);
    window.open(`https://wa.me/${phone}?text=${finalMsg}`, '_blank');
};

// Auto-greet after delay
setTimeout(() => {
    const bubble = document.getElementById('gemini-bubble');
    if (bubble && !document.getElementById('gemini-chat-window').classList.contains('active')) {
        bubble.classList.add('active');
        setTimeout(() => bubble.classList.remove('active'), 8000);
    }
}, 5000);

// [v3.12.43] Initialize Listeners
const orbBtn = document.getElementById('gemini-orb-btn');
if (orbBtn) {
    orbBtn.addEventListener('click', () => window.toggleGeminiChat());
}


// --- Epinics Enterprise Modules (SaaS: Multi-Vendor & Affiliate Program) ---

window.checkAffReferral = async () => {
  const refCode = urlParams.get('ref');
  if (refCode) {
    sessionStorage.setItem('mec_ref_code', refCode);
    if (!sessionStorage.getItem('mec_ref_clicked')) {
      sessionStorage.setItem('mec_ref_clicked', '1');
      try {
        const q = query(collection(db, 'affiliates'), where('code', '==', refCode), where('storeId', '==', window.currentStoreId));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const docRef = doc(db, 'affiliates', snap.docs[0].id);
          await setDoc(docRef, { clicks: increment(1) }, { merge: true });
          console.log(`Registered click for affiliate promoter: ${refCode}`);
        }
      } catch (err) {
        console.error("Error incrementing referral click:", err);
      }
    }
  }
};

// --- Affiliate Portal Logic ---

function ensureAffiliateModalExists() {
  if (document.getElementById('affiliate-portal-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'affiliate-portal-modal';
  modal.className = 'modal-overlay';
  modal.style.cssText = 'display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;';
  modal.innerHTML = `
    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="aff-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>
        
        <!-- Tab navigation inside modal -->
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>
        </div>

        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>
        </form>
      </div>

      <div id="aff-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>
        
        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">
          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>
          <div style="display:flex; gap:10px; align-items:center;">
            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">
            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>
          </div>
        </div>

        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
}

function ensureSellerModalExists() {
  if (document.getElementById('seller-portal-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'seller-portal-modal';
  modal.className = 'modal-overlay';
  modal.style.cssText = 'display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;';
  modal.innerHTML = `
    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="seller-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>
        
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>
        </div>

        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>
        </form>
      </div>

      <div id="seller-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>
            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>
          </div>
          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">
            Pending
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">
          
          <!-- Add Product Form -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>
            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">
              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>
              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>
            </form>
          </div>

          <!-- Product List -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>
            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">
              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>
            </div>
          </div>
        </div>

        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
}

window.toggleAffiliatePortal = async (show) => {
  ensureAffiliateModalExists();
  const modal = document.getElementById('affiliate-portal-modal');
  if (!modal) return;
  modal.style.display = show ? 'flex' : 'none';
  modal.classList.toggle('active', show);
  if (show) {
    const storedUser = localStorage.getItem('mec_affiliate_user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      try {
        const q = query(collection(db, 'affiliates'), where('email', '==', user.email), where('storeId', '==', window.currentStoreId));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const freshData = { ...snap.docs[0].data(), docId: snap.docs[0].id };
          localStorage.setItem('mec_affiliate_user', JSON.stringify(freshData));
          renderAffiliateDashboard(freshData);
        } else {
          localStorage.removeItem('mec_affiliate_user');
          showAffiliateAuth();
        }
      } catch (err) {
        console.error(err);
        renderAffiliateDashboard(user);
      }
    } else {
      showAffiliateAuth();
    }
  }
};

function showAffiliateAuth() {
  document.getElementById('aff-auth-section').style.display = 'block';
  document.getElementById('aff-dashboard-section').style.display = 'none';
  window.switchAffTab('login');
}

window.switchAffTab = (tab) => {
  const loginForm = document.getElementById('aff-login-form');
  const regForm = document.getElementById('aff-register-form');
  const tabLogin = document.getElementById('aff-tab-login');
  const tabReg = document.getElementById('aff-tab-register');
  if (tab === 'login') {
    if (loginForm) loginForm.style.display = 'flex';
    if (regForm) regForm.style.display = 'none';
    if (tabLogin) { tabLogin.style.color = '#38bdf8'; tabLogin.style.borderBottom = '2px solid #38bdf8'; }
    if (tabReg) { tabReg.style.color = '#94a3b8'; tabReg.style.borderBottom = 'none'; }
  } else {
    if (loginForm) loginForm.style.display = 'none';
    if (regForm) regForm.style.display = 'flex';
    if (tabLogin) { tabLogin.style.color = '#94a3b8'; tabLogin.style.borderBottom = 'none'; }
    if (tabReg) { tabReg.style.color = '#10b981'; tabReg.style.borderBottom = '2px solid #10b981'; }
  }
};

window.handleAffiliateLogin = async (e) => {
  e.preventDefault();
  const email = document.getElementById('aff-login-email').value.trim();
  const pass = document.getElementById('aff-login-pass').value;
  try {
    const q = query(collection(db, 'affiliates'), where('email', '==', email), where('password', '==', pass), where('storeId', '==', window.currentStoreId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const user = { ...snap.docs[0].data(), docId: snap.docs[0].id };
      localStorage.setItem('mec_affiliate_user', JSON.stringify(user));
      renderAffiliateDashboard(user);
    } else {
      alert("Invalid email address or password.");
    }
  } catch (err) {
    console.error(err);
    alert("Login failed. Please try again.");
  }
};

window.handleAffiliateRegister = async (e) => {
  e.preventDefault();
  const name = document.getElementById('aff-reg-name').value.trim();
  const email = document.getElementById('aff-reg-email').value.trim();
  const phone = document.getElementById('aff-reg-phone').value.trim();
  const password = document.getElementById('aff-reg-pass').value;

  try {
    const q = query(collection(db, 'affiliates'), where('email', '==', email), where('storeId', '==', window.currentStoreId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      alert("An account with this email is already registered as a partner.");
      return;
    }

    const code = name.toLowerCase().replace(/[^a-z0-9]/g, '') + Math.floor(100 + Math.random() * 900);
    const newAff = {
      name,
      email,
      phone,
      password,
      code,
      clicks: 0,
      salesCount: 0,
      totalCommission: 0,
      storeId: window.currentStoreId,
      timestamp: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, 'affiliates'), newAff);
    newAff.docId = docRef.id;
    localStorage.setItem('mec_affiliate_user', JSON.stringify(newAff));
    renderAffiliateDashboard(newAff);
  } catch (err) {
    console.error(err);
    alert("Registration failed. Please try again.");
  }
};

function renderAffiliateDashboard(user) {
  document.getElementById('aff-auth-section').style.display = 'none';
  document.getElementById('aff-dashboard-section').style.display = 'block';
  document.getElementById('aff-dash-name').innerText = user.name || 'Promoter';
  
  const protocol = window.location.protocol;
  const host = window.location.host;
  const path = window.location.pathname;
  
  let refLink = `${protocol}//${host}${path}`;
  if (window.currentStoreId !== 'mec-book-shop' && window.currentStoreId !== 'master') {
    refLink += `?store=${window.currentStoreId}&ref=${user.code}`;
  } else {
    refLink += `?ref=${user.code}`;
  }
  
  document.getElementById('aff-referral-url').value = refLink;
  document.getElementById('aff-clicks').innerText = user.clicks || 0;
  document.getElementById('aff-sales').innerText = user.salesCount || 0;
  document.getElementById('aff-commission').innerText = `LKR ${(user.totalCommission || 0).toFixed(2)}`;
}

window.copyAffReferralLink = () => {
  const copyText = document.getElementById('aff-referral-url');
  if (!copyText) return;
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(copyText.value);
  alert("Referral link copied to clipboard!");
};

window.handleAffiliateLogout = () => {
  localStorage.removeItem('mec_affiliate_user');
  showAffiliateAuth();
};

// --- Seller / Multi-Vendor Portal Logic ---

window.toggleSellerPortal = async (show) => {
  ensureSellerModalExists();
  const modal = document.getElementById('seller-portal-modal');
  if (!modal) return;
  modal.style.display = show ? 'flex' : 'none';
  modal.classList.toggle('active', show);
  if (show) {
    const storedUser = localStorage.getItem('mec_seller_user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      try {
        const q = query(collection(db, 'vendor_shops'), where('email', '==', user.email), where('storeId', '==', window.currentStoreId));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const freshData = { ...snap.docs[0].data(), docId: snap.docs[0].id };
          localStorage.setItem('mec_seller_user', JSON.stringify(freshData));
          renderSellerDashboard(freshData);
        } else {
          localStorage.removeItem('mec_seller_user');
          showSellerAuth();
        }
      } catch (err) {
        console.error(err);
        renderSellerDashboard(user);
      }
    } else {
      showSellerAuth();
    }
  }
};

function showSellerAuth() {
  document.getElementById('seller-auth-section').style.display = 'block';
  document.getElementById('seller-dashboard-section').style.display = 'none';
  window.switchSellerTab('login');
}

window.switchSellerTab = (tab) => {
  const loginForm = document.getElementById('seller-login-form');
  const regForm = document.getElementById('seller-register-form');
  const tabLogin = document.getElementById('seller-tab-login');
  const tabReg = document.getElementById('seller-tab-register');
  if (tab === 'login') {
    if (loginForm) loginForm.style.display = 'flex';
    if (regForm) regForm.style.display = 'none';
    if (tabLogin) { tabLogin.style.color = '#38bdf8'; tabLogin.style.borderBottom = '2px solid #38bdf8'; }
    if (tabReg) { tabReg.style.color = '#94a3b8'; tabReg.style.borderBottom = 'none'; }
  } else {
    if (loginForm) loginForm.style.display = 'none';
    if (regForm) regForm.style.display = 'flex';
    if (tabLogin) { tabLogin.style.color = '#94a3b8'; tabLogin.style.borderBottom = 'none'; }
    if (tabReg) { tabReg.style.color = '#10b981'; tabReg.style.borderBottom = '2px solid #10b981'; }
  }
};

window.handleSellerLogin = async (e) => {
  e.preventDefault();
  const email = document.getElementById('seller-login-email').value.trim();
  const pass = document.getElementById('seller-login-pass').value;
  try {
    const q = query(collection(db, 'vendor_shops'), where('email', '==', email), where('password', '==', pass), where('storeId', '==', window.currentStoreId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const user = { ...snap.docs[0].data(), docId: snap.docs[0].id };
      localStorage.setItem('mec_seller_user', JSON.stringify(user));
      renderSellerDashboard(user);
    } else {
      alert("Invalid email address or password.");
    }
  } catch (err) {
    console.error(err);
    alert("Login failed. Please try again.");
  }
};

window.handleSellerRegister = async (e) => {
  e.preventDefault();
  const shopName = document.getElementById('seller-reg-shopname').value.trim();
  const ownerName = document.getElementById('seller-reg-owner').value.trim();
  const email = document.getElementById('seller-reg-email').value.trim();
  const phone = document.getElementById('seller-reg-phone').value.trim();
  const password = document.getElementById('seller-reg-pass').value;

  try {
    const qShop = query(collection(db, 'vendor_shops'), where('shopName', '==', shopName), where('storeId', '==', window.currentStoreId));
    const snapShop = await getDocs(qShop);
    if (!snapShop.empty) {
      alert("This shop name is already registered.");
      return;
    }
    const qEmail = query(collection(db, 'vendor_shops'), where('email', '==', email), where('storeId', '==', window.currentStoreId));
    const snapEmail = await getDocs(qEmail);
    if (!snapEmail.empty) {
      alert("This email is already registered to a shop.");
      return;
    }

    const newShop = {
      shopName,
      ownerName,
      email,
      phone,
      password,
      status: 'pending',
      storeId: window.currentStoreId,
      timestamp: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, 'vendor_shops'), newShop);
    newShop.docId = docRef.id;
    localStorage.setItem('mec_seller_user', JSON.stringify(newShop));
    renderSellerDashboard(newShop);

    // Send instant SMS alert to Super Admin private mobile number (0770658356)
    try {
      const adminPhone = "+94770658356";
      const smsText = `🚨 NEW STOREFRONT VENDOR REGISTRATION!\nShop: ${shopName}\nOwner: ${ownerName}\nPhone: ${phone}\nEmail: ${email}`;
      const smsUrl = `https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(adminPhone)}&message=${encodeURIComponent(smsText)}`;
      fetch(smsUrl, { method: 'GET', mode: 'no-cors' }).catch(() => {});
    } catch (smsErr) {
      console.error('Vendor SMS alert error:', smsErr);
    }
  } catch (err) {
    console.error(err);
    alert("Shop registration failed. Please try again.");
  }
};

async function renderSellerDashboard(user) {
  document.getElementById('seller-auth-section').style.display = 'none';
  document.getElementById('seller-dashboard-section').style.display = 'block';
  document.getElementById('seller-dash-shopname').innerText = user.shopName || 'My Brand Shop';
  
  const statusBadge = document.getElementById('seller-dash-status-badge');
  if (statusBadge) {
    statusBadge.innerText = user.status || 'pending';
    if (user.status === 'active') {
      statusBadge.style.background = 'rgba(16, 185, 129, 0.2)';
      statusBadge.style.color = '#10b981';
    } else {
      statusBadge.style.background = 'rgba(251, 191, 36, 0.2)';
      statusBadge.style.color = '#fbbf24';
    }
  }

  await loadSellerProducts(user.email);
}

async function loadSellerProducts(email) {
  const listContainer = document.getElementById('seller-products-list');
  if (!listContainer) return;
  listContainer.innerHTML = '<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';

  try {
    const q = query(productsCol, where('vendorId', '==', email), where('storeId', '==', window.currentStoreId));
    const snap = await getDocs(q);
    if (snap.empty) {
      listContainer.innerHTML = '<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';
    } else {
      let html = '';
      snap.forEach(docSnap => {
        const prod = docSnap.data();
        const statusColor = prod.status === 'active' ? '#10b981' : '#fbbf24';
        html += `
          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-weight:bold; font-size:0.85rem; display:block;">${prod.name || ''}</span>
              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${prod.price || 0}</span>
            </div>
            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${statusColor};">${prod.status || 'pending'}</span>
          </div>
        `;
      });
      listContainer.innerHTML = html;
    }
  } catch (err) {
    console.error(err);
    listContainer.innerHTML = '<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>';
  }
}

window.handleSellerAddProduct = async (e) => {
  e.preventDefault();
  const storedUser = localStorage.getItem('mec_seller_user');
  if (!storedUser) return;
  const user = JSON.parse(storedUser);

  const name = document.getElementById('seller-prod-name').value.trim();
  const price = document.getElementById('seller-prod-price').value.trim();
  const category = document.getElementById('seller-prod-category').value.trim();
  const image = document.getElementById('seller-prod-image').value.trim();
  const description = document.getElementById('seller-prod-desc').value.trim();

  try {
    const newProd = {
      name,
      price: Number(price),
      category,
      image: image || '',
      description: description || '',
      status: 'pending',
      vendorId: user.email,
      storeId: window.currentStoreId,
      timestamp: serverTimestamp(),
      sku: 'SKU-VEND-' + Date.now(),
      cost: 0,
      discount: 0,
      stock: 999,
      mode: 'Shop'
    };

    await addDoc(productsCol, newProd);
    alert("Product submitted successfully for approval!");
    document.getElementById('seller-add-product-form').reset();
    await loadSellerProducts(user.email);
  } catch (err) {
    console.error(err);
    alert("Error submitting product. Please try again.");
  }
};

window.handleSellerLogout = () => {
  localStorage.removeItem('mec_seller_user');
  showSellerAuth();
};

window.addEventListener('beforeunload', function (e) {
  // Do not prompt inside desktop apps (WebView2 / Electron)
  if (window.chrome?.webview || window.electron || window.electronAPI) return;
  if (!navigator.onLine) {
    e.preventDefault();
    e.returnValue = 'You are currently offline. Unsaved data will be lost if you close the app.';
  }
});
