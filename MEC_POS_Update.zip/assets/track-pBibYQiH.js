import{g as N,q as O,w as C,c as W,d as X,j as Z,n as T,C as S,o as _,x as R,u as k,a as ee,s as te}from"./firebase-CVcZ1MF3.js";/* empty css              */const U=new URLSearchParams(window.location.search),L=window.location.pathname.split("/").filter(t=>t!==""),ne=L[0]&&!["index.html","track","admin","login.html"].includes(L[0])?L[0]:null,y=U.get("store")||ne||"mec-book-shop";window.storeInfo=null;N(O(W(X,"stores"),C("slug","==",y))).then(t=>{t.empty||(window.storeInfo=t.docs[0].data())});const A=document.getElementById("tracking-result"),V=document.getElementById("list-view"),c=document.getElementById("history-list"),Y=document.getElementById("res-order-id"),M=document.getElementById("res-status-badge"),oe=document.getElementById("res-date"),q=document.getElementById("res-total"),K=document.getElementById("res-items-count");document.getElementById("res-items-list");document.getElementById("res-cod-row");document.getElementById("res-cod");const ie=document.getElementById("confirm-section"),G=document.getElementById("review-section");let Q=5,m=null;const x={Pending:document.getElementById("step-pending"),Processing:document.getElementById("step-processing"),Shipped:document.getElementById("step-shipped"),Delivered:document.getElementById("step-delivered")};let u=[];async function se(t){c&&(c.innerHTML='<p class="loading-text">Loading invoice details...</p>');try{const e=S("orders",y),o=O(e,C("orderId","==",t)),s=await N(o);if(s.empty)c&&(c.innerHTML=`
                    <div style="padding: 2.5rem; text-align: center; color: #ef4444; border: 1px dashed rgba(239, 68, 68, 0.4); border-radius: 16px; background: rgba(239, 68, 68, 0.05);">
                        <p style="font-size: 1.5rem; margin-bottom: 0.5rem;">⚠️</p>
                        <p style="font-weight: 800; font-size: 1.1rem; margin: 0;">Invoice Not Found</p>
                        <p style="font-size: 0.85rem; opacity: 0.8; margin-top: 5px;">No record found for Invoice ID: <strong>${t}</strong></p>
                    </div>
                `);else{const i={...s.docs[0].data(),docId:s.docs[0].id};u=[i],viewOrderDetails(i.orderId);const l=document.getElementById("back-btn");l&&(l.style.display="none")}}catch(e){console.error(e),c&&(c.innerHTML="Error loading invoice: "+e.message)}}const j=U.get("id");j?se(j):Z(T,t=>{t?re(t.uid):c.innerHTML=`
                <div style="padding: 2rem; border: 2px dashed #eee; border-radius: 12px;">
                    <p>Please log in to your account to view your orders.</p>
                    <a href="/login.html" class="add-to-cart-btn" style="display: inline-block; text-decoration: none; margin-top: 1rem;">Login Now</a>
                </div>
            `});async function re(t){const e=S("orders",y),o=O(e,C("userId","==",t));_(o,s=>{if(u=s.docs.map(i=>({...i.data(),docId:i.id})).sort((i,l)=>{var p,g;return(((p=l.timestamp)==null?void 0:p.seconds)||0)-(((g=i.timestamp)==null?void 0:g.seconds)||0)}),de(),m){const i=u.find(l=>l.orderId===m.orderId);i&&viewOrderDetails(i.orderId)}},s=>{console.error(s),c.innerHTML="Error: "+s.message})}function de(){if(u.length===0){c.innerHTML=`
            <div class="empty-orders">
                <div style="font-size: 4rem; opacity: 0.2; margin-bottom: 1rem;">📦</div>
                <p>You haven't placed any orders yet.</p>
                <button class="category-btn active" onclick="window.location.href='/#products'" style="margin-top: 1rem;">Start Shopping</button>
            </div>
        `;return}c.innerHTML=u.map(t=>{var o;const e=t.status==="Shipped"?"Handed Over":t.status;return`
            <div class="order-card" onclick="viewOrderDetails('${t.orderId}')" style="cursor: pointer; position: relative;">
                <div class="order-info">
                    <div class="order-id">${t.orderId}</div>
                    <div class="order-meta">${t.date} • ${((o=t.items)==null?void 0:o.length)||0} Items</div>
                    <div class="order-total">LKR ${(t.total+(t.codCharge||0)).toFixed(2)}</div>
                </div>
                <div class="order-status-col" style="display: flex; flex-direction: column; align-items: flex-end; gap: 10px;">
                    <span class="status-badge" data-status="${t.status}">
                        ${e}
                    </span>
                    ${t.status==="Shipped"?`
                        <button onclick="event.stopPropagation(); window.confirmOrderReceivedOnCard('${t.docId}')" 
                            style="background: #22c55e; color: white; border: none; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; cursor: pointer;">
                            Confirm Received ✅
                        </button>
                    `:""}
                </div>
            </div>
        `}).join("")}window.confirmOrderReceivedOnCard=async t=>{if(confirm("Have you received this package?"))try{const e=R("orders",t,y);await k(e,{status:"Delivered"}),alert("📦 Thank you for confirming! You can now leave a review.")}catch(e){alert("Error: "+e.message)}};window.viewOrderDetails=t=>{const e=u.find(n=>n.orderId===t);if(!e)return;m=e,Y.innerText=e.orderId,oe.innerText=e.date;const o=e.status==="Shipped"?"Handed Over":e.status;M.innerText=o,M.setAttribute("data-status",e.status);const s=e.items?e.items.length:0;K&&(K.innerText=`${s} Items`);const i=document.getElementById("res-name");i&&(i.innerText=e.userName||"Customer");const l=e.total||0,p=e.codCharge||0,g=l+p;q&&(q.innerText=g.toFixed(2));const h=e.items||[],D=h.reduce((n,a)=>n+(a.price||0)*(a.quantity||1),0),w=h.reduce((n,a)=>n+(a.discount||0)*(a.quantity||1),0),E=e.discount||0,v=w+E,b=document.getElementById("res-invoice-subtotal"),r=document.getElementById("res-invoice-discount"),d=document.getElementById("res-invoice-discount-row"),I=document.getElementById("res-invoice-delivery"),f=document.getElementById("res-invoice-delivery-row"),$=document.getElementById("res-invoice-paymethod"),F=document.getElementById("res-invoice-items-body");b&&(b.innerText=D.toFixed(2)),r&&(r.innerText=v.toFixed(2)),d&&(d.style.display=v>0?"flex":"none"),I&&(I.innerText=p.toFixed(2)),f&&(f.style.display=p>0?"flex":"none"),$&&($.innerText=e.paymentMethod||e.method||"Cash"),F&&(F.innerHTML=h.map(n=>{const a=n.quantity||1,H=n.price||0,B=n.discount||0,J=(H-B)*a;return`
                <tr style="border-bottom: 1px solid #f1f5f9; font-weight: 500;">
                    <td style="padding: 12px 8px; font-weight: 700; color: #0f172a;">${n.name}</td>
                    <td style="padding: 12px 8px; text-align: center;">${a}</td>
                    <td style="padding: 12px 8px; text-align: right;">LKR ${H.toFixed(2)}</td>
                    <td style="padding: 12px 8px; text-align: right; color: #ef4444;">${B>0?`-LKR ${B.toFixed(2)}`:"-"}</td>
                    <td style="padding: 12px 8px; text-align: right; font-weight: 700; color: #1e293b;">LKR ${J.toFixed(2)}</td>
                </tr>
            `}).join("")),Object.keys(x).forEach(n=>{x[n]&&x[n].classList.remove("active","completed")});const z=["Pending","Processing","Shipped","Delivered"],P=z.indexOf(e.status);z.forEach((n,a)=>{x[n]&&(a<P?x[n].classList.add("completed"):a===P&&x[n].classList.add("active"))}),ie.style.display=e.status==="Shipped"?"block":"none",G.style.display=e.status==="Delivered"&&!e.reviewed?"block":"none",V.style.display="none",A.style.display="block"};window.hideOrderDetails=()=>{A.style.display="none",V.style.display="block",m=null};window.confirmOrderReceived=async()=>{if(m)try{const t=R("orders",m.docId,y);await k(t,{status:"Delivered"}),alert("📦 Thank you for confirming! You can now leave a review.")}catch(t){alert("Error: "+t.message)}};window.setRating=t=>{Q=t,document.querySelectorAll(".star-rating span").forEach((o,s)=>{o.style.color=s<t?"#fbbf24":"#ddd"})};window.submitReview=async()=>{if(!m)return;const t=document.getElementById("review-comment").value.trim();try{const e=S("reviews",y);await ee(e,{orderId:m.orderId,userId:T.currentUser.uid,userName:T.currentUser.displayName||"Customer",rating:Q,comment:t,timestamp:te(),date:new Date().toLocaleDateString()});const o=R("orders",m.docId,y);await k(o,{reviewed:!0}),document.getElementById("review-status").style.display="block",setTimeout(()=>G.style.display="none",3e3)}catch(e){alert("Error: "+e.message)}};window.printFromTrack=()=>{var E,v,b;const t=Y.innerText.replace("Order ID: ",""),e=u.find(r=>r.orderId===t);if(!e)return;const o=e.items||[],s=o.reduce((r,d)=>r+(d.price||0)*(d.quantity||1),0),i=o.reduce((r,d)=>r+(d.discount||0)*(d.quantity||1),0),l=e.discount||0,p=i+l,g=e.codCharge||0,h=e.total+g,D=document.getElementById("printable-area");D.innerHTML=`
        <div style="padding: 40px; font-family: 'Segoe UI', sans-serif; color: #1e293b;">
            <div style="text-align: center; border-bottom: 2px solid #002060; padding-bottom: 20px;">
                ${(E=window.storeInfo)!=null&&E.logoUrl?`<img src="${window.storeInfo.logoUrl}" style="width: 100px; height: 100px; object-fit: contain; margin-bottom: 10px;">`:""}
                <h1 style="margin: 5px 0; color: #002060; font-size: 1.8rem;">${((v=window.storeInfo)==null?void 0:v.name)||"MEC BOOK SHOP"}</h1>
                <p style="margin: 2px 0; font-size: 0.85rem; color: #64748b;">${((b=window.storeInfo)==null?void 0:b.location)||"No 97, Victoria Estate, Panadura Road, Munagama, Horana."}</p>
                <h2 style="margin: 15px 0 5px; color: #002060; font-weight: 800; letter-spacing: 1px;">OFFICIAL INVOICE</h2>
            </div>
            <div style="margin: 30px 0; display: flex; justify-content: space-between; font-size: 0.9rem;">
                <div>
                    <h4 style="margin: 0 0 8px; color: #64748b; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">BILL TO:</h4>
                    <p style="margin: 2px 0;"><strong>${e.userName||"Customer"}</strong></p>
                    <p style="margin: 2px 0; color: #475569;">${e.address||""}, ${e.city||""}</p>
                    <p style="margin: 2px 0; color: #475569;">Tel: ${e.phone||""}${e.phone2?" / "+e.phone2:""}</p>
                </div>
                <div style="text-align: right;">
                    <p style="margin: 4px 0;"><strong>Order ID:</strong> ${e.orderId}</p>
                    <p style="margin: 4px 0;"><strong>Date:</strong> ${e.date}</p>
                    <p style="margin: 4px 0;"><strong>Method:</strong> <span style="text-transform: uppercase;">${e.paymentMethod||e.method||"Cash"}</span></p>
                </div>
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-top: 20px; border: 1px solid #e2e8f0;">
                <thead>
                    <tr style="background: #002060; color: white;">
                        <th style="padding: 10px; text-align: left; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Item Description</th>
                        <th style="padding: 10px; text-align: center; width: 60px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Qty</th>
                        <th style="padding: 10px; text-align: right; width: 100px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Price</th>
                        <th style="padding: 10px; text-align: right; width: 80px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Disc</th>
                        <th style="padding: 10px; text-align: right; width: 110px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${o.map(r=>{const d=r.quantity||1,I=r.price||0,f=r.discount||0,$=(I-f)*d;return`
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 10px; font-weight: bold; color: #1e293b;">${r.name}</td>
                                <td style="padding: 10px; text-align: center; color: #475569;">${d}</td>
                                <td style="padding: 10px; text-align: right; color: #475569;">LKR ${I.toFixed(2)}</td>
                                <td style="padding: 10px; text-align: right; color: #ef4444;">${f>0?`-LKR ${f.toFixed(2)}`:"-"}</td>
                                <td style="padding: 10px; text-align: right; font-weight: 700; color: #1e293b;">LKR ${$.toFixed(2)}</td>
                            </tr>
                        `}).join("")}
                </tbody>
            </table>
            
            <div style="margin-top: 20px; border-top: 2px dashed #002060; padding-top: 15px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; font-size: 0.85rem; color: #475569;">
                <div style="display: flex; justify-content: space-between; width: 240px;">
                    <span style="font-weight: 600;">Subtotal:</span>
                    <span style="font-weight: 700; color: #1e293b;">LKR ${s.toFixed(2)}</span>
                </div>
                ${p>0?`
                <div style="display: flex; justify-content: space-between; width: 240px; color: #ef4444;">
                    <span style="font-weight: 600;">Discount Given:</span>
                    <span style="font-weight: 700;">- LKR ${p.toFixed(2)}</span>
                </div>
                `:""}
                ${g>0?`
                <div style="display: flex; justify-content: space-between; width: 240px;">
                    <span style="font-weight: 600;">Delivery/COD:</span>
                    <span style="font-weight: 700; color: #1e293b;">LKR ${g.toFixed(2)}</span>
                </div>
                `:""}
                <div style="display: flex; justify-content: space-between; width: 240px; font-weight: bold; font-size: 1.1rem; color: #002060; border-top: 2px solid #002060; padding-top: 8px; margin-top: 4px;">
                    <span>Grand Total:</span>
                    <span>LKR ${h.toFixed(2)}</span>
                </div>
            </div>
        </div>
    `;const w=document.createElement("style");w.innerHTML=`
        @media print {
            body * { visibility: hidden; }
            #printable-area, #printable-area * { visibility: visible; }
            #printable-area { display: block !important; position: absolute; left: 0; top: 0; width: 100%; }
        }
    `,document.head.appendChild(w),window.print(),document.head.removeChild(w)};document.getElementById("back-btn").addEventListener("click",()=>{window.hideOrderDetails()});
