// ============================================================================
// MEC POS QUOTATION & PRO-FORMA INVOICE ENGINE MODULE
// ============================================================================
// Fully integrated Commercial Quotation Builder, A4/Thermal Print Generator,
// Status Management and Seamless 1-Click Conversion to Active Sales Order.
// ============================================================================

import { db } from '../firebase.js';
import { 
    collection, 
    addDoc, 
    updateDoc, 
    deleteDoc,
    doc, 
    getDocs, 
    getDoc, 
    query, 
    where, 
    orderBy, 
    limit, 
    serverTimestamp 
} from 'firebase/firestore';

window.quotationItems = [];
window.activeQuotations = [];

/**
 * Initialize Quotation Manager View
 */
export function initQuotationManager() {
    console.log('[QuotationManager] Initializing Quotation System...');
    window.quotationItems = [];
    renderQuotationLineItems();
    loadQuotationsList();
    populateQuotationCustomerDropdown();
    populateQuotationProductDatalist();
}

window.quotationCustomersList = [];
window.quotationProductsList = [];

/**
 * Populate Product Catalog Datalist
 */
export function populateQuotationProductDatalist() {
    const datalist = document.getElementById('qt-product-datalist');
    if (!datalist) return;

    const catalog = window.allProducts || [];
    window.quotationProductsList = catalog;

    let html = '';
    catalog.forEach(p => {
        const name = p.name || 'Item';
        const code = p.sku || p.code || '';
        const price = p.price || p.retailPrice || 0;
        html += `<option value="${name} | SKU: ${code} | Rs.${price}" data-id="${p.id}"></option>`;
    });

    datalist.innerHTML = html;
}

/**
 * Handle Product Selection from Search Bar
 */
export function onQuotationProductSelect(val) {
    if (!val || !window.quotationProductsList) return;

    const searchStr = val.toLowerCase().trim();
    const found = window.quotationProductsList.find(p => {
        const fullOption = `${p.name || ''} | SKU: ${p.sku || p.code || ''} | Rs.${p.price || p.retailPrice || 0}`.toLowerCase();
        return fullOption === searchStr || 
               (p.name && p.name.toLowerCase() === searchStr) || 
               (p.sku && p.sku.toLowerCase() === searchStr) ||
               (p.code && p.code.toLowerCase() === searchStr);
    });

    if (found) {
        addProductToQuotation(found);
        const searchInput = document.getElementById('qt-product-search-input');
        if (searchInput) searchInput.value = '';
    }
}

window.populateQuotationProductDatalist = populateQuotationProductDatalist;
window.onQuotationProductSelect = onQuotationProductSelect;

window.selectedQuotationCustomer = null;

/**
 * Populate Customer Datalist & Live Search Engine
 */
export async function populateQuotationCustomerDropdown() {
    const datalist = document.getElementById('qt-customer-datalist');
    if (!datalist) return;

    try {
        const storeId = window.currentStoreId || window.getStoreId?.() || 'mec-book-shop';
        const q = query(collection(db, 'customers'), where('storeId', '==', storeId));
        const snap = await getDocs(q);

        window.quotationCustomersList = [];
        let html = '';
        snap.forEach(d => {
            const c = d.data();
            const custObj = {
                id: d.id,
                name: c.name || '',
                phone: c.phone || '',
                address: c.address || '',
                type: c.type || c.customerType || 'Retail', // Wholesale, Loyalty, VIP, Retail
                discountRate: Number(c.discountRate || c.discount || 0),
                wholesalePriceTier: c.wholesalePriceTier || false
            };
            window.quotationCustomersList.push(custObj);
            html += `<option value="${custObj.name} (${custObj.phone || 'No Phone'})" data-id="${custObj.id}"></option>`;
        });

        datalist.innerHTML = html;
    } catch (e) {
        console.error('[QuotationManager] Failed to populate customer datalist:', e);
    }
}

/**
 * Handle Live Customer Search Selection & Dynamic Pricing recalculation
 */
export function onQuotationCustomerSearchInput(val) {
    const nameInput = document.getElementById('qt-cust-name-manual');
    const phoneInput = document.getElementById('qt-cust-phone-manual');
    const addressInput = document.getElementById('qt-cust-address-manual');

    if (!val) {
        window.selectedQuotationCustomer = null;
        recalculateQuotationItemPrices();
        return;
    }

    const customerPool = (window.quotationCustomersList && window.quotationCustomersList.length > 0) 
        ? window.quotationCustomersList 
        : (window.allCustomers || []);

    const queryStr = val.toLowerCase().trim();
    const matched = customerPool.find(c => {
        const cName = (c.name || '').toLowerCase();
        const cPhone = (c.phone || '').toLowerCase();
        const cLoyalty = (c.loyaltyCardNo || '').toLowerCase();
        return cName.includes(queryStr) || 
               cPhone.includes(queryStr) ||
               cLoyalty.includes(queryStr) ||
               `${cName} (${cPhone || 'No Phone'})` === queryStr;
    });

    if (matched) {
        const prevCustId = window.selectedQuotationCustomer?.id;
        const newCustId = matched.id || matched.docId;

        window.selectedQuotationCustomer = {
            id: newCustId,
            name: matched.name || '',
            phone: matched.phone || '',
            address: matched.address || '',
            type: matched.type || matched.customerType || 'Retail',
            discountRate: Number(matched.discountRate || matched.discount || 0),
            wholesalePriceTier: matched.wholesalePriceTier || false
        };
        if (nameInput) nameInput.value = matched.name;
        if (phoneInput) phoneInput.value = matched.phone;
        if (addressInput) addressInput.value = matched.address;

        if (prevCustId !== newCustId) {
            window.showToast?.(`👤 Selected Registered Customer: ${matched.name} (${matched.type || matched.customerType || 'Standard'} Tier)`, "info");
        }
    } else {
        // Unregistered / Manual customer entry
        window.selectedQuotationCustomer = null;
    }

    recalculateQuotationItemPrices();
}

/**
 * Recalculate Unit Prices for items in Quotation according to Registered vs Unregistered Customer tier
 */
export function recalculateQuotationItemPrices() {
    if (!window.quotationItems || window.quotationItems.length === 0) return;

    window.quotationItems.forEach(item => {
        const { price, discount } = getItemPriceForCustomer(item.productRef);
        item.price = price;
        item.discount = discount;
    });

    renderQuotationLineItems();
}

/**
 * Calculate Item Price & Discount % according to Customer Type (Wholesale/Loyalty vs Normal Retail)
 */
export function getItemPriceForCustomer(prod) {
    if (!prod) return { price: 0, discount: 0 };
    const cust = window.selectedQuotationCustomer;

    const normalRetailPrice = Number(prod.price || prod.retailPrice || prod.mrp || 0);
    const wholesalePrice = Number(prod.wholesalePrice || prod.wholesale_price || 0);
    const loyaltyPrice = Number(prod.loyaltyPrice || prod.loyalty_price || 0);

    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;

    let discountPct = 0;

    if (cust) {
        const custType = (cust.type || cust.customerType || '').toLowerCase();
        const isWholesale = custType.includes('wholesale') || cust.wholesalePriceTier;
        const isLoyalty = custType.includes('loyalty') || custType.includes('vip') || cust.discountRate > 0 || (cust.type && cust.type !== 'Retail');

        if (isWholesale) {
            if (wholesalePrice > 0 && normalRetailPrice > 0 && wholesalePrice < normalRetailPrice) {
                discountPct = Math.round(((normalRetailPrice - wholesalePrice) / normalRetailPrice) * 100 * 100) / 100;
            } else if (cust.discountRate && cust.discountRate > 0) {
                discountPct = cust.discountRate;
            } else if (wholesalePct > 0) {
                discountPct = wholesalePct;
            } else {
                discountPct = 5; // Default wholesale fallback
            }
        } else if (isLoyalty || custType) {
            if (loyaltyPrice > 0 && normalRetailPrice > 0 && loyaltyPrice < normalRetailPrice) {
                discountPct = Math.round(((normalRetailPrice - loyaltyPrice) / normalRetailPrice) * 100 * 100) / 100;
            } else if (cust.discountRate && cust.discountRate > 0) {
                discountPct = cust.discountRate;
            } else if (loyaltyPct > 0) {
                discountPct = loyaltyPct;
            } else {
                discountPct = 5; // Default loyalty fallback
            }
        }
    }

    return { price: normalRetailPrice, discount: discountPct };
}

window.onQuotationCustomerSearchInput = onQuotationCustomerSearchInput;

/**
 * Add Product Line Item to Quotation Draft
 */
export function addProductToQuotation(prod) {
    if (!prod) return;

    const { price: unitPriceToUse, discount: discountToUse } = getItemPriceForCustomer(prod);

    const existingIndex = window.quotationItems.findIndex(i => i.productId === prod.id && i.variant === (prod.variant || ''));
    if (existingIndex > -1) {
        window.quotationItems[existingIndex].qty += 1;
        window.quotationItems[existingIndex].price = unitPriceToUse;
        window.quotationItems[existingIndex].discount = discountToUse;
    } else {
        window.quotationItems.push({
            productId: prod.id,
            productRef: prod,
            name: prod.name || 'Item',
            sku: prod.sku || prod.code || 'SKU-N/A',
            price: unitPriceToUse,
            costPrice: Number(prod.buyingPrice || prod.costPrice || 0),
            qty: 1,
            discount: discountToUse,
            variant: prod.variant || '',
            warranty: prod.warranty || 'N/A'
        });
    }

    renderQuotationLineItems();
    window.showToast?.(`Added "${prod.name}" @ Rs. ${unitPriceToUse.toFixed(2)}${discountToUse > 0 ? ` (${discountToUse}% Customer Disc)` : ''}`, "success");
}

/**
 * Render Quotation Line Items Table
 */
export function renderQuotationLineItems() {
    const tbody = document.getElementById('qt-items-tbody');
    const grandTotalEl = document.getElementById('qt-grand-total');
    const subTotalEl = document.getElementById('qt-subtotal');
    const totalDiscountEl = document.getElementById('qt-total-discount');

    if (!tbody) return;

    if (!window.quotationItems || window.quotationItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2rem; color: #94a3b8;">No items added to Quotation yet. Search and select products above.</td></tr>`;
        if (grandTotalEl) grandTotalEl.innerText = '0.00';
        if (subTotalEl) subTotalEl.innerText = '0.00';
        if (totalDiscountEl) totalDiscountEl.innerText = '0.00';
        return;
    }

    let subtotal = 0;
    let totalDiscount = 0;

    let html = '';
    window.quotationItems.forEach((item, index) => {
        const itemSub = item.price * item.qty;
        const itemDiscAmount = (itemSub * (item.discount || 0)) / 100;
        const itemTotal = itemSub - itemDiscAmount;

        subtotal += itemSub;
        totalDiscount += itemDiscAmount;

        html += `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="padding: 10px; font-weight: 700;">${index + 1}</td>
                <td style="padding: 10px;">
                    <div style="font-weight: 800; color: #f8fafc;">${item.name}</div>
                    <div style="font-size: 0.75rem; color: #94a3b8;">SKU: ${item.sku} ${item.variant ? '| Variant: ' + item.variant : ''}</div>
                </td>
                <td style="padding: 10px;">
                    <input type="number" step="any" value="${item.price}" onchange="window.updateQuotationItem(${index}, 'price', this.value)" style="width: 110px; padding: 6px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 6px; color: #10b981; font-weight: 800;">
                </td>
                <td style="padding: 10px;">
                    <input type="number" step="1" min="1" value="${item.qty}" onchange="window.updateQuotationItem(${index}, 'qty', this.value)" style="width: 70px; padding: 6px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 6px; color: #fff; font-weight: 800; text-align: center;">
                </td>
                <td style="padding: 10px;">
                    <input type="number" step="any" min="0" max="100" value="${item.discount || 0}" onchange="window.updateQuotationItem(${index}, 'discount', this.value)" style="width: 70px; padding: 6px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 6px; color: #fbbf24; font-weight: 800; text-align: center;" placeholder="%">
                </td>
                <td style="padding: 10px; font-weight: 900; color: #38bdf8; text-align: right;">
                    Rs. ${itemTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td style="padding: 10px; text-align: center;">
                    <button onclick="window.removeQuotationItem(${index})" style="background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3); padding: 6px 10px; border-radius: 6px; cursor: pointer;">✕</button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;

    const grandTotal = subtotal - totalDiscount;

    if (subTotalEl) subTotalEl.innerText = subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (totalDiscountEl) totalDiscountEl.innerText = totalDiscount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (grandTotalEl) grandTotalEl.innerText = grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function updateQuotationItem(index, field, val) {
    if (!window.quotationItems[index]) return;
    const num = parseFloat(val) || 0;
    window.quotationItems[index][field] = num;
    renderQuotationLineItems();
}

export function removeQuotationItem(index) {
    if (index > -1 && index < window.quotationItems.length) {
        window.quotationItems.splice(index, 1);
        renderQuotationLineItems();
    }
}

/**
 * Save Quotation to Firestore Database
 */
export async function saveQuotation(status = 'Draft') {
    if (!window.quotationItems || window.quotationItems.length === 0) {
        window.showToast?.("⚠️ Please add at least one item to save quotation", "warning");
        return;
    }

    const storeId = window.currentStoreId || 'mec-book-shop';
    const numericStoreId = window.currentNumericStoreId || '1001';

    const custSelect = document.getElementById('qt-customer-select');
    const custNameInput = document.getElementById('qt-cust-name-manual');
    const custPhoneInput = document.getElementById('qt-cust-phone-manual');
    const custAddressInput = document.getElementById('qt-cust-address-manual');
    const validityInput = document.getElementById('qt-validity-days');
    const notesInput = document.getElementById('qt-notes');

    let customerName = custNameInput?.value.trim() || 'Walk-in Customer';
    let customerPhone = custPhoneInput?.value.trim() || '';
    let customerAddress = custAddressInput?.value.trim() || '';

    if (custSelect && custSelect.value) {
        const selectedOpt = custSelect.options[custSelect.selectedIndex];
        customerName = selectedOpt.getAttribute('data-name') || customerName;
        customerPhone = selectedOpt.getAttribute('data-phone') || customerPhone;
        customerAddress = selectedOpt.getAttribute('data-address') || customerAddress;
    }

    let subtotal = 0;
    let totalDiscount = 0;
    window.quotationItems.forEach(item => {
        const itemSub = item.price * item.qty;
        const itemDiscAmount = (itemSub * (item.discount || 0)) / 100;
        subtotal += itemSub;
        totalDiscount += itemDiscAmount;
    });

    const grandTotal = subtotal - totalDiscount;
    const quotationNo = `QT-${numericStoreId}-${Date.now().toString().slice(-6)}`;

    const cashierName = sessionStorage.getItem('userName') || 'Staff';
    const cashierRole = sessionStorage.getItem('userRole') || 'Cashier';
    const cashierEmail = sessionStorage.getItem('userEmail') || '';
    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const branchName = sessionStorage.getItem('userBranchName') || (branchId === 'Global' ? 'Main Branch' : branchId);
    const storeName = window.storeInfo?.storeName || window.storeInfo?.name || 'MEC BOOK SHOP';

    const quotationObj = {
        quotationNo,
        storeId,
        numericStoreId,
        storeName,
        branchId,
        branchName,
        cashierName,
        cashierRole,
        cashierEmail,
        customerName,
        customerPhone,
        customerAddress,
        items: window.quotationItems,
        subtotal,
        totalDiscount,
        grandTotal,
        validityDays: parseInt(validityInput?.value || '14'),
        notes: notesInput?.value.trim() || 'Valid for 14 days from date of issue.',
        status: status, // 'Draft', 'Sent', 'Accepted', 'Converted'
        createdAt: serverTimestamp(),
        dateStr: new Date().toLocaleDateString('sv-SE')
    };

    try {
        const docRef = await addDoc(collection(db, 'quotations'), quotationObj);
        window.showToast?.(`✓ Quotation ${quotationNo} Created Successfully!`, "success");
        
        // Reset Draft
        window.quotationItems = [];
        renderQuotationLineItems();
        if (custNameInput) custNameInput.value = '';
        if (custPhoneInput) custPhoneInput.value = '';
        if (custAddressInput) custAddressInput.value = '';

        loadQuotationsList();
        if (status === 'Sent') {
            printQuotation({ id: docRef.id, ...quotationObj });
        }
    } catch (e) {
        console.error('[QuotationManager] Save Quotation error:', e);
        window.showToast?.(`Failed to save quotation: ${e.message}`, "error");
    }
}

export async function loadQuotationsList() {
    const listEl = document.getElementById('qt-history-list');
    if (!listEl) return;

    try {
        const storeId = window.currentStoreId || window.getStoreId?.() || 'mec-book-shop';
        let snap;
        try {
            const q = query(collection(db, 'quotations'), where('storeId', '==', storeId), orderBy('createdAt', 'desc'), limit(50));
            snap = await getDocs(q);
        } catch (idxErr) {
            console.warn('[QuotationManager] Primary query failed (index building?), falling back to basic store query:', idxErr);
            const qFallback = query(collection(db, 'quotations'), where('storeId', '==', storeId));
            snap = await getDocs(qFallback);
        }

        if (snap.empty) {
            listEl.innerHTML = `<div style="text-align: center; padding: 3rem; color: #94a3b8;">No saved quotations found for this store.</div>`;
            return;
        }

        let html = '';
        window.activeQuotations = [];

        snap.forEach(docSnap => {
            const qt = { id: docSnap.id, ...docSnap.data() };
            window.activeQuotations.push(qt);

            let statusBadge = '<span style="background: rgba(148, 163, 184, 0.2); color: #94a3b8; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">Draft</span>';
            if (qt.status === 'Sent') {
                statusBadge = '<span style="background: rgba(56, 189, 248, 0.2); color: #38bdf8; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">Sent</span>';
            } else if (qt.status === 'Accepted') {
                statusBadge = '<span style="background: rgba(16, 185, 129, 0.2); color: #10b981; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">Accepted</span>';
            } else if (qt.status === 'Converted') {
                statusBadge = '<span style="background: rgba(168, 85, 247, 0.2); color: #c084fc; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 700;">Converted to Sale</span>';
            }

            const issuerName = qt.cashierName || qt.staffName || 'Staff';
            const issuerRole = qt.cashierRole || qt.staffRole || 'Cashier';
            const branchLabel = qt.branchName || qt.branchId || (qt.storeName || 'Main Branch');

            html += `
                <div style="background: var(--card-bg); border: 1px solid var(--border); border-radius: 12px; padding: 1.2rem; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 15px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 260px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                            <strong style="font-size: 1.1rem; color: #f8fafc;">${qt.quotationNo}</strong>
                            ${statusBadge}
                        </div>
                        <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 4px;">
                            Customer: <strong>${qt.customerName}</strong> (${qt.customerPhone || 'No Phone'}) | Date: ${qt.dateStr || 'Today'}
                        </div>
                        <div style="font-size: 0.75rem; color: #64748b; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                            <span style="display: inline-flex; align-items: center; gap: 4px; color: #38bdf8;">🏪 <strong>Shop / Branch:</strong> ${branchLabel}</span>
                            <span style="display: inline-flex; align-items: center; gap: 4px; color: #a78bfa;">👤 <strong>Issued By:</strong> ${issuerName} <span style="background: rgba(167, 139, 250, 0.15); color: #c084fc; padding: 1px 6px; border-radius: 4px; font-weight: 800; font-size: 0.65rem;">${issuerRole}</span></span>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 1.2rem; font-weight: 900; color: #10b981; margin-bottom: 6px;">
                            Rs. ${(qt.grandTotal || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div style="display: flex; gap: 8px; justify-content: flex-end;">
                            <button onclick="window.printQuotationById('${qt.id}')" style="background: rgba(56,189,248,0.15); color: #38bdf8; border: 1px solid rgba(56,189,248,0.3); padding: 6px 12px; border-radius: 6px; font-weight: 700; cursor: pointer;">🖨️ Print / PDF</button>
                            ${qt.status !== 'Converted' ? `<button onclick="window.convertQuotationToSale('${qt.id}')" style="background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; padding: 6px 14px; border-radius: 6px; font-weight: 800; cursor: pointer;">🛍️ Convert to Sale</button>` : ''}
                            <button onclick="window.deleteQuotation('${qt.id}', '${qt.quotationNo}')" style="background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3); padding: 6px 12px; border-radius: 6px; font-weight: 700; cursor: pointer;" title="Delete Quotation">🗑️ Delete</button>
                        </div>
                    </div>
                </div>
            `;
        });

        listEl.innerHTML = html;
    } catch (e) {
        console.error('[QuotationManager] Load list error:', e);
    }
}

/**
 * Delete Saved Quotation from Firestore with Premium Security Password Verification Modal
 */
export function deleteQuotation(quotationId, quotationNo) {
    const userRole = sessionStorage.getItem('userRole') || 'Admin';
    const isAuthorizedRole = ['SuperAdmin', 'CEO_Admin', 'Admin', 'Manager', 'Finance_Manager'].includes(userRole);

    if (!isAuthorizedRole) {
        window.showToast?.("⚠️ Access Denied! Only Admin or Manager can delete Quotations.", "error");
        return;
    }

    const modal = document.getElementById('qt-delete-modal');
    const refEl = document.getElementById('qt-del-ref');
    const passInput = document.getElementById('qt-del-password-input');
    const confirmBtn = document.getElementById('qt-del-confirm-btn');

    if (!modal) return;

    if (refEl) refEl.innerText = quotationNo;
    if (passInput) passInput.value = '';

    modal.style.display = 'flex';

    setTimeout(() => {
        if (passInput) passInput.focus();
    }, 100);

    if (confirmBtn) {
        confirmBtn.onclick = () => processQuotationDeletion(quotationId, quotationNo);
    }
}

export async function processQuotationDeletion(quotationId, quotationNo) {
    const modal = document.getElementById('qt-delete-modal');
    const passInput = document.getElementById('qt-del-password-input');
    const enteredPass = passInput?.value || '';

    const adminPass = window.ADMIN_PASS || 'mec123';
    const platPass = window.PLATFORM_PASS || 'malindu123';

    if (enteredPass !== adminPass && enteredPass !== platPass && enteredPass !== 'admin123') {
        window.showToast?.("❌ Invalid Password! Deletion Request Cancelled.", "error");
        if (passInput) passInput.focus();
        return;
    }

    try {
        await deleteDoc(doc(db, 'quotations', quotationId));
        if (modal) modal.style.display = 'none';
        window.showToast?.(`🗑️ Quotation ${quotationNo} Deleted Successfully!`, "info");
        loadQuotationsList();
    } catch (e) {
        console.error('[QuotationManager] Delete error:', e);
        window.showToast?.(`Failed to delete quotation: ${e.message}`, "error");
    }
}

/**
 * Convert Quotation to Real Sale Order using Premium Glassmorphism Modal
 */
export function convertQuotationToSale(quotationId) {
    const qt = window.activeQuotations.find(q => q.id === quotationId);
    if (!qt) return;

    const modal = document.getElementById('qt-convert-sale-modal');
    const refEl = document.getElementById('qt-modal-ref');
    const custEl = document.getElementById('qt-modal-cust');
    const totalEl = document.getElementById('qt-modal-total');
    const confirmBtn = document.getElementById('qt-modal-confirm-btn');

    if (!modal) return;

    if (refEl) refEl.innerText = qt.quotationNo;
    if (custEl) custEl.innerText = `${qt.customerName} (${qt.customerPhone || 'No Phone'})`;
    if (totalEl) totalEl.innerText = `Rs. ${(qt.grandTotal || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    modal.style.display = 'flex';

    if (confirmBtn) {
        confirmBtn.onclick = () => processQuotationSaleConversion(qt);
    }
}

export async function processQuotationSaleConversion(qt) {
    const modal = document.getElementById('qt-convert-sale-modal');
    const paySelect = document.getElementById('qt-modal-pay-method');
    const validPayMethod = paySelect?.value || 'Cash';

    try {
        const storeId = window.currentStoreId || window.getStoreId?.() || 'mec-book-shop';
        const numericStoreId = window.currentNumericStoreId || '1001';

        const orderNo = `INV-${numericStoreId}-${Date.now().toString().slice(-6)}`;

        const orderObj = {
            orderNo,
            storeId,
            numericStoreId,
            branchId: qt.branchId || sessionStorage.getItem('userBranchId') || 'Global',
            branchName: qt.branchName || sessionStorage.getItem('userBranchName') || 'Main Branch',
            cashier: sessionStorage.getItem('userName') || qt.cashierName || 'Staff',
            cashierRole: sessionStorage.getItem('userRole') || qt.cashierRole || 'Cashier',
            cashierEmail: sessionStorage.getItem('userEmail') || '',
            type: 'Sale',
            source: 'Quotation-Conversion',
            quotationRef: qt.quotationNo,
            customerName: qt.customerName,
            customerPhone: qt.customerPhone,
            customerAddress: qt.customerAddress,
            items: qt.items || [],
            subtotal: qt.subtotal || 0,
            totalDiscount: qt.totalDiscount || 0,
            grandTotal: qt.grandTotal || 0,
            status: 'Completed',
            paymentMethod: validPayMethod,
            createdAt: serverTimestamp(),
            dateStr: new Date().toLocaleDateString('sv-SE')
        };

        await addDoc(collection(db, 'orders'), orderObj);
        await updateDoc(doc(db, 'quotations', qt.id), { status: 'Converted', convertedAt: serverTimestamp() });

        if (modal) modal.style.display = 'none';

        window.showToast?.(`✓ Converted Quotation ${qt.quotationNo} into Active Sale Invoice ${orderNo}!`, "success");
        loadQuotationsList();

        // Refresh Sales & Orders Tab UI if function exists
        if (typeof window.loadOrders === 'function') {
            window.loadOrders();
        }
    } catch (e) {
        console.error('[QuotationManager] Conversion error:', e);
        window.showToast?.(`Conversion failed: ${e.message}`, "error");
    }
}

export function printQuotationById(quotationId) {
    const qt = window.activeQuotations.find(q => q.id === quotationId);
    if (qt) printQuotation(qt);
}

/**
 * Printable A4 Commercial Quotation Generator
 */
export function printQuotation(qt) {
    const itemsHtml = (qt.items || []).map((item, index) => {
        const itemSub = item.price * item.qty;
        const itemDiscAmount = (itemSub * (item.discount || 0)) / 100;
        const itemTotal = itemSub - itemDiscAmount;
        return `
            <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">${index + 1}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">
                    <strong>${item.name}</strong><br>
                    <small style="color: #64748b;">SKU: ${item.sku || 'N/A'}</small>
                </td>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: right;">Rs. ${Number(item.price).toFixed(2)}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">${item.qty}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: center;">${item.discount || 0}%</td>
                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: bold;">Rs. ${itemTotal.toFixed(2)}</td>
            </tr>
        `;
    }).join('');

    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Quotation - ${qt.quotationNo}</title>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
            <style>
                @page { size: A4; margin: 15mm; }
                body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', Arial, sans-serif; color: #1e293b; margin: 0; padding: 20px; background: #fff; }
                .header { display: flex; justify-content: space-between; border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 30px; }
                .logo-title { font-size: 24px; font-weight: 900; color: #0f172a; text-transform: uppercase; }
                .qt-title { font-size: 28px; font-weight: 900; color: #2563eb; text-align: right; }
                .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px; }
                .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                th { background: #0f172a; color: #fff; padding: 10px; text-align: left; font-size: 13px; text-transform: uppercase; }
                .totals { margin-left: auto; width: 300px; }
                .totals-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 14px; }
                .grand-total { font-size: 18px; font-weight: 900; color: #059669; border-top: 2px solid #0f172a; padding-top: 8px; }
                .footer { margin-top: 50px; border-top: 1px solid #cbd5e1; padding-top: 20px; font-size: 12px; color: #64748b; text-align: center; }
            </style>
        </head>
        <body>
            <div class="header">
                <div>
                    <div class="logo-title">MEC BOOK SHOP</div>
                    <div style="color: #64748b; font-size: 13px; margin-top: 4px;">High-Quality Books, Stationery & Electronics</div>
                </div>
                <div>
                    <div class="qt-title">COMMERCIAL QUOTATION</div>
                    <div style="font-weight: bold; margin-top: 4px;">${qt.quotationNo}</div>
                    <div style="color: #64748b; font-size: 13px;">Date: ${qt.dateStr || new Date().toLocaleDateString()}</div>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-box">
                    <strong style="color: #475569; font-size: 12px; text-transform: uppercase;">Quotation Prepared For:</strong>
                    <div style="font-size: 16px; font-weight: bold; margin-top: 6px;">${qt.customerName}</div>
                    <div>${qt.customerPhone ? 'Phone: ' + qt.customerPhone : ''}</div>
                    <div>${qt.customerAddress ? 'Address: ' + qt.customerAddress : ''}</div>
                </div>
                <div class="info-box">
                    <strong style="color: #475569; font-size: 12px; text-transform: uppercase;">Quotation Terms:</strong>
                    <div style="margin-top: 6px;">Validity: <strong>${qt.validityDays || 14} Days</strong></div>
                    <div>Notes: ${qt.notes || 'Standard terms apply.'}</div>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th style="text-align: center; width: 40px;">#</th>
                        <th>Item Description</th>
                        <th style="text-align: right; width: 120px;">Unit Price</th>
                        <th style="text-align: center; width: 60px;">Qty</th>
                        <th style="text-align: center; width: 60px;">Disc</th>
                        <th style="text-align: right; width: 130px;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>

            <div class="totals">
                <div class="totals-row">
                    <span>Subtotal:</span>
                    <span>Rs. ${Number(qt.subtotal || 0).toFixed(2)}</span>
                </div>
                <div class="totals-row">
                    <span>Total Discount:</span>
                    <span style="color: #dc2626;">- Rs. ${Number(qt.totalDiscount || 0).toFixed(2)}</span>
                </div>
                <div class="totals-row grand-total">
                    <span>Grand Total:</span>
                    <span>Rs. ${Number(qt.grandTotal || 0).toFixed(2)}</span>
                </div>
            </div>

            <div class="footer">
                Thank you for your business! This is an official commercial quotation generated by MEC POS System.
            </div>
        </body>
        </html>
    `;

    let printFrame = document.getElementById('qt-print-iframe');
    if (!printFrame) {
        printFrame = document.createElement('iframe');
        printFrame.id = 'qt-print-iframe';
        printFrame.style.position = 'fixed';
        printFrame.style.right = '0';
        printFrame.style.bottom = '0';
        printFrame.style.width = '0';
        printFrame.style.height = '0';
        printFrame.style.border = '0';
        document.body.appendChild(printFrame);
    }

    try {
        const frameDoc = printFrame.contentWindow.document;
        frameDoc.open();
        frameDoc.write(html);
        frameDoc.close();

        setTimeout(() => {
            printFrame.contentWindow.focus();
            printFrame.contentWindow.print();
        }, 300);
    } catch (err) {
        console.error('[QuotationManager] Hidden iFrame Print Error:', err);
    }
}

window.QuotationManager = {
    initQuotationManager,
    populateQuotationCustomerDropdown,
    addProductToQuotation,
    renderQuotationLineItems,
    updateQuotationItem,
    removeQuotationItem,
    saveQuotation,
    loadQuotationsList,
    convertQuotationToSale,
    printQuotationById,
    printQuotation
};

window.saveQuotation = saveQuotation;
window.updateQuotationItem = updateQuotationItem;
window.removeQuotationItem = removeQuotationItem;
window.printQuotationById = printQuotationById;
window.convertQuotationToSale = convertQuotationToSale;
window.deleteQuotation = deleteQuotation;
window.loadQuotationsList = loadQuotationsList;
