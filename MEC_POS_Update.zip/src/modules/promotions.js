import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot, 
    addDoc, 
    deleteDoc, 
    doc, 
    updateDoc, 
    query, 
    where, 
    getDocs, 
    serverTimestamp 
} from "firebase/firestore";

const promotionsCol = collection(db, 'promotions');
const storesCol = collection(db, 'stores');

// Local cache
let currentStoreData = null;
let allCoupons = [];

window.initPromotions = initPromotions;
window.renderPromotionsUI = renderPromotionsUI;

export function initPromotions() {
    console.log("🎁 Initializing Promotions Module...");

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    // 1. Listen for Coupon Codes in promotions collection
    const promoQ = isMaster ? promotionsCol : query(promotionsCol, where('storeId', '==', storeId));
    onSnapshot(promoQ, (snapshot) => {
        allCoupons = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        if (window.currentActiveTab === 'promotions') {
            renderCouponsTable();
        }
    });

    // 2. Listen for store info (to sync webDesign/webContent settings)
    const storeQ = query(storesCol, where('slug', '==', storeId));
    onSnapshot(storeQ, (snapshot) => {
        if (!snapshot.empty) {
            currentStoreData = { ...snapshot.docs[0].data(), docId: snapshot.docs[0].id };
            if (window.currentActiveTab === 'promotions') {
                populateCampaignSettings();
            }
        }
    });

    // 3. Set default date to today for expiry date
    const expiryInput = document.getElementById('coupon-expiry');
    if (expiryInput && !expiryInput.value) {
        expiryInput.value = new Date().toISOString().split('T')[0];
    }
}

function renderPromotionsUI() {
    console.log("🎨 Rendering Promotions Dashboard...");
    renderCouponsTable();
    populateCampaignSettings();
    populateCouponItemSelectors();
}

// Populate product and category checklists
function populateCouponItemSelectors() {
    const productsList = document.getElementById('coupon-products-list');
    const categoriesList = document.getElementById('coupon-categories-list');
    
    const allProds = window.allProducts || [];
    
    // 1. Populate Products
    if (productsList) {
        if (allProds.length === 0) {
            productsList.innerHTML = `<span style="color:var(--text-muted); font-size:0.75rem;">No products found.</span>`;
        } else {
            // Deduplicate by name
            const uniqueProds = [];
            const seenNames = new Set();
            for (const p of allProds) {
                const name = (p.name || '').trim();
                if (name && !seenNames.has(name.toLowerCase())) {
                    seenNames.add(name.toLowerCase());
                    uniqueProds.push(p);
                }
            }
            uniqueProds.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

            productsList.innerHTML = uniqueProds.map(p => `
                <label class="coupon-prod-item" style="display:flex; align-items:center; gap:8px; font-size:0.8rem; color:#e2e8f0; cursor:pointer; padding:3px 6px; border-radius:6px; background:rgba(255,255,255,0.03);">
                    <input type="checkbox" name="coupon-product" value="${p.name}" onchange="window.updateCouponSelectionCounts()" style="cursor:pointer; accent-color:#38bdf8;">
                    <span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${p.name}</span>
                    <span style="color:#94a3b8; font-size:0.7rem;">LKR ${(p.price || 0).toLocaleString()}</span>
                </label>
            `).join('');
        }
    }

    // 2. Populate Categories
    if (categoriesList) {
        const categories = [...new Set(allProds.map(p => (p.category || '').trim()).filter(Boolean))].sort();
        if (categories.length === 0) {
            categoriesList.innerHTML = `<span style="color:var(--text-muted); font-size:0.75rem;">No categories found.</span>`;
        } else {
            categoriesList.innerHTML = categories.map(cat => `
                <label class="coupon-cat-item" style="display:flex; align-items:center; gap:8px; font-size:0.8rem; color:#e2e8f0; cursor:pointer; padding:3px 6px; border-radius:6px; background:rgba(255,255,255,0.03);">
                    <input type="checkbox" name="coupon-category" value="${cat}" onchange="window.updateCouponSelectionCounts()" style="cursor:pointer; accent-color:#38bdf8;">
                    <span style="flex:1;">📁 ${cat}</span>
                </label>
            `).join('');
        }
    }
}

window.toggleCouponTargetSelection = (type) => {
    const prodBox = document.getElementById('coupon-products-select-box');
    const catBox = document.getElementById('coupon-categories-select-box');
    
    if (prodBox) prodBox.style.display = type === 'specific_products' ? 'block' : 'none';
    if (catBox) catBox.style.display = type === 'specific_categories' ? 'block' : 'none';
    
    if (type === 'specific_products' || type === 'specific_categories') {
        populateCouponItemSelectors();
    }
};

window.filterCouponProducts = (query) => {
    const q = (query || '').toLowerCase().trim();
    const items = document.querySelectorAll('.coupon-prod-item');
    items.forEach(el => {
        const text = el.innerText.toLowerCase();
        el.style.display = text.includes(q) ? 'flex' : 'none';
    });
};

window.updateCouponSelectionCounts = () => {
    const selectedProds = document.querySelectorAll('input[name="coupon-product"]:checked');
    const selectedCats = document.querySelectorAll('input[name="coupon-category"]:checked');
    
    const prodCountEl = document.getElementById('coupon-selected-prod-count');
    const catCountEl = document.getElementById('coupon-selected-cat-count');
    
    if (prodCountEl) prodCountEl.innerText = `${selectedProds.length} selected`;
    if (catCountEl) catCountEl.innerText = `${selectedCats.length} selected`;
};

// Render coupons list
function renderCouponsTable() {
    const tbody = document.getElementById('coupons-table-body');
    if (!tbody) return;

    if (allCoupons.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 3rem; color: var(--text-muted);">
                    🎟️ No coupons registered yet. Create one on the right panel!
                </td>
            </tr>
        `;
        return;
    }

    const today = new Date().toISOString().split('T')[0];

    tbody.innerHTML = allCoupons.map(c => {
        const isExpired = c.expiryDate < today;
        const statusText = isExpired ? 'Expired' : (c.status || 'Active');
        const statusClass = isExpired ? 'suspended' : 'active';
        
        let targetText = '🌐 All Products';
        if (c.targetType === 'specific_products') {
            const count = (c.selectedProducts || []).length;
            const tooltip = (c.selectedProducts || []).join(', ');
            targetText = `<span title="${tooltip}" style="color:#38bdf8; cursor:help; font-weight:600;">📦 ${count} Selected Item${count === 1 ? '' : 's'}</span>`;
        } else if (c.targetType === 'specific_categories') {
            targetText = `<span style="color:#a855f7; font-weight:600;">📁 ${(c.selectedCategories || []).join(', ')}</span>`;
        }
        
        return `
            <tr>
                <td style="font-weight: 700; color: #fff; text-transform: uppercase; font-family: monospace; font-size: 1.1rem;">
                    ${c.code}
                </td>
                <td style="font-weight: 700; color: var(--accent-blue);">
                    ${c.type === 'Percentage' ? `${c.value}% OFF` : `LKR ${parseFloat(c.value).toFixed(2)} OFF`}
                </td>
                <td>
                    ${targetText}
                </td>
                <td>${c.expiryDate}</td>
                <td>
                    <span class="pill ${statusClass}">${statusText}</span>
                </td>
                <td>
                    <button class="btn-action" onclick="window.deletePromoCoupon('${c.docId}', '${c.code}')" style="background: rgba(239, 68, 68, 0.1); border-color: rgba(239, 68, 68, 0.2); color: #ef4444;">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Populate welcome messages, banner and updates live previews
function populateCampaignSettings() {
    if (!currentStoreData) return;

    const welcomeTitleInput = document.getElementById('promo-welcome-title');
    const announceTextInput = document.getElementById('promo-announce-text');
    const previewWelcome = document.getElementById('preview-welcome-title');
    const previewAnnounce = document.getElementById('preview-announce-text');
    const previewImg = document.getElementById('preview-banner-img');
    const textPreviewContainer = document.getElementById('promo-text-preview');
    const btnClearBanner = document.getElementById('btn-clear-promo-banner');

    const welcome = currentStoreData.webContent?.welcome || '';
    const announce = currentStoreData.webContent?.announce || '';
    const bannerUrl = currentStoreData.webDesign?.bannerUrl || '';

    if (welcomeTitleInput) welcomeTitleInput.value = welcome;
    if (announceTextInput) announceTextInput.value = announce;

    // Update Preview Welcome Text
    if (previewWelcome) previewWelcome.innerText = welcome || 'Welcome to Our Store';
    if (previewAnnounce) previewAnnounce.innerText = announce || 'Your premium destination for high-quality products.';

    // Setup live preview sync
    if (welcomeTitleInput) {
        welcomeTitleInput.oninput = (e) => {
            if (previewWelcome) previewWelcome.innerText = e.target.value || 'Welcome to Our Store';
        };
    }
    if (announceTextInput) {
        announceTextInput.oninput = (e) => {
            if (previewAnnounce) previewAnnounce.innerText = e.target.value || 'Your premium destination for high-quality products.';
        };
    }

    // Update banner preview image
    if (bannerUrl && bannerUrl.length > 10) {
        if (previewImg) {
            previewImg.src = bannerUrl;
            previewImg.style.display = 'block';
        }
        if (textPreviewContainer) textPreviewContainer.style.display = 'none';
        if (btnClearBanner) btnClearBanner.style.display = 'inline-block';
        window.currentPromoBannerBase64 = bannerUrl;
    } else {
        if (previewImg) {
            previewImg.src = '';
            previewImg.style.display = 'none';
        }
        if (textPreviewContainer) textPreviewContainer.style.display = 'block';
        if (btnClearBanner) btnClearBanner.style.display = 'none';
        window.currentPromoBannerBase64 = null;
    }
}

// ─── Actions ───

// Add Coupon
window.savePromoCoupon = async (e) => {
    e.preventDefault();

    const code = document.getElementById('coupon-code').value.trim().toUpperCase();
    const type = document.getElementById('coupon-type').value;
    const value = parseFloat(document.getElementById('coupon-value').value);
    const expiryDate = document.getElementById('coupon-expiry').value;
    const targetType = document.getElementById('coupon-target-type')?.value || 'all';

    if (!code || isNaN(value) || value <= 0 || !expiryDate) {
        window.showToast("❌ Please fill in all coupon details correctly.", "error");
        return;
    }

    // Collect targeted products or categories if selected
    const selectedProducts = [];
    const selectedCategories = [];

    if (targetType === 'specific_products') {
        document.querySelectorAll('input[name="coupon-product"]:checked').forEach(cb => {
            selectedProducts.push(cb.value);
        });
        if (selectedProducts.length === 0) {
            window.showToast("❌ Please select at least one product for this coupon.", "error");
            return;
        }
    } else if (targetType === 'specific_categories') {
        document.querySelectorAll('input[name="coupon-category"]:checked').forEach(cb => {
            selectedCategories.push(cb.value);
        });
        if (selectedCategories.length === 0) {
            window.showToast("❌ Please select at least one category for this coupon.", "error");
            return;
        }
    }

    // Ensure coupon code unique (locally)
    const exists = allCoupons.some(c => c.code === code);
    if (exists) {
        window.showToast("❌ This coupon code already exists.", "error");
        return;
    }

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';

    try {
        window.showToast("Saving coupon...", "info");
        await addDoc(promotionsCol, {
            code,
            type,
            value,
            expiryDate,
            storeId,
            targetType,
            selectedProducts,
            selectedCategories,
            status: 'Active',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
        });
        window.showToast("✅ Coupon saved successfully!", "success");
        
        // Reset form
        document.getElementById('add-coupon-form').reset();
        window.toggleCouponTargetSelection('all');
        const expiryInput = document.getElementById('coupon-expiry');
        if (expiryInput) expiryInput.value = new Date().toISOString().split('T')[0];

    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to save coupon.", "error");
    }
};

// Delete Coupon
window.deletePromoCoupon = async (docId, code) => {
    if (!confirm(`Are you sure you want to delete coupon code "${code}"?`)) return;

    try {
        window.showToast("Deleting coupon...", "info");
        await deleteDoc(doc(db, 'promotions', docId));
        window.showToast(`✅ Coupon "${code}" deleted successfully.`, "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to delete coupon.", "error");
    }
};

// Handle banner image upload and optimize it (Base64 conversion)
window.handlePromoBannerUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    window.showToast("⏳ Optimizing banner image...", "info");
    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const maxDimension = 1200;

            if (width > height) {
                if (width > maxDimension) {
                    height *= maxDimension / width;
                    width = maxDimension;
                }
            } else {
                if (height > maxDimension) {
                    width *= maxDimension / height;
                    height = maxDimension;
                }
            }

            canvas.width = width;
            canvas.height = height;
            canvas.getContext('2d').drawImage(img, 0, 0, width, height);

            const optimizedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            
            // Show preview
            const previewImg = document.getElementById('preview-banner-img');
            const textPreviewContainer = document.getElementById('promo-text-preview');
            const btnClearBanner = document.getElementById('btn-clear-promo-banner');

            if (previewImg) {
                previewImg.src = optimizedBase64;
                previewImg.style.display = 'block';
            }
            if (textPreviewContainer) textPreviewContainer.style.display = 'none';
            if (btnClearBanner) btnClearBanner.style.display = 'inline-block';

            window.currentPromoBannerBase64 = optimizedBase64;
            window.showToast("🖼️ Banner optimized successfully! Save to apply.", "success");
        };
        img.onerror = () => {
            window.showToast("❌ Error loading image file.", "error");
        };
        img.src = event.target.result;
    };
    reader.onerror = () => {
        window.showToast("❌ Error reading file.", "error");
    };
    reader.readAsDataURL(file);
};

// Clear promotion banner
window.clearPromoBanner = () => {
    const previewImg = document.getElementById('preview-banner-img');
    const textPreviewContainer = document.getElementById('promo-text-preview');
    const btnClearBanner = document.getElementById('btn-clear-promo-banner');
    const fileInput = document.getElementById('promo-banner-file');

    if (previewImg) {
        previewImg.src = '';
        previewImg.style.display = 'none';
    }
    if (textPreviewContainer) textPreviewContainer.style.display = 'block';
    if (btnClearBanner) btnClearBanner.style.display = 'none';
    if (fileInput) fileInput.value = '';

    window.currentPromoBannerBase64 = null;
    window.showToast("🧹 Banner image cleared. Save to apply changes.", "info");
};

// Save Campaign (Banner / Welcome Title / Announce text)
window.savePromoCampaign = async () => {
    const welcome = document.getElementById('promo-welcome-title').value.trim();
    const announce = document.getElementById('promo-announce-text').value.trim();
    const bannerUrl = window.currentPromoBannerBase64 || null;

    if (!currentStoreData) {
        window.showToast("❌ Store profile not loaded yet. Cannot save.", "error");
        return;
    }

    try {
        window.showToast("Saving campaign changes...", "info");

        // Clone current design config or start fresh
        const webDesign = { ...(currentStoreData.webDesign || {}) };
        webDesign.bannerUrl = bannerUrl;

        // Clone current content config or start fresh
        const webContent = { ...(currentStoreData.webContent || {}) };
        webContent.welcome = welcome;
        webContent.announce = announce;

        await updateDoc(doc(db, 'stores', currentStoreData.docId), {
            webDesign,
            webContent,
            updatedAt: serverTimestamp()
        });

        window.showToast("🚀 Promotions & Banners saved to live site!", "success");

    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to save campaign.", "error");
    }
};
