import { db } from '../firebase.js';
import { 
    collection, 
    addDoc, 
    serverTimestamp, 
    onSnapshot, 
    query, 
    where, 
    limit, 
    doc, 
    updateDoc,
    orderBy
} from "firebase/firestore";

export function initReloadModule() {
    console.log("Reload module initialized.");
    
    // Initialize Terminal Keyboard Workflow
    const termPhoneInput = document.getElementById('rel-phone');
    const termAmountInput = document.getElementById('rel-amount');

    if (termPhoneInput) {
        termPhoneInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                if (termAmountInput) termAmountInput.focus();
            }
        });
    }

    if (termAmountInput) {
        termAmountInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const btns = document.querySelectorAll('.term-pay-btn');
                if(btns.length > 0) {
                    window.selectTerminalPaymentMethod(0);
                    btns[0].focus();
                }
            }
        });
    }
}

window.selectedNetwork = null;
window.isReloadProcessing = false;

window.selectReloadNetwork = (network, btn) => {
    window.selectedNetwork = network;
    document.getElementById('rel-network').value = network;
    
    // UI Update
    document.querySelectorAll('.net-btn').forEach(b => {
        b.style.background = 'white';
        b.style.color = '#333';
        b.style.borderColor = '#ddd';
    });
    
    // Brand specific colors
    const brandColors = {
        'Dialog': '#ed1c24',
        'Mobitel': '#1e40af',
        'Hutch': '#ff6600',
        'Airtel': '#dc2626',
        'Dialog TV': '#ed1c24',
        'Router': '#4338ca',
        'SLT': '#0284c7',
        'Other': '#64748b'
    };
    
    btn.style.background = brandColors[network] || '#002060';
    btn.style.color = 'white';
    btn.style.borderColor = brandColors[network] || '#002060';
};

window.autoDetectNetwork = (number) => {
    if (!number || number.length < 3) return;
    
    // Clean number (remove spaces/dashes)
    const cleanNum = number.replace(/[\s-]/g, '');
    const prefix = cleanNum.substring(0, 3);
    
    let network = null;
    if (['077', '076', '074'].includes(prefix)) network = 'Dialog';
    else if (['071', '070'].includes(prefix)) network = 'Mobitel';
    else if (['078', '072'].includes(prefix)) network = 'Hutch';
    else if (['075'].includes(prefix)) network = 'Airtel';
    
    if (network) {
        // Find the button and trigger click
        const btns = document.querySelectorAll('.net-btn');
        btns.forEach(btn => {
            if (btn.innerText.trim() === network) {
                window.selectReloadNetwork(network, btn);
            }
        });
    }
};

window.setReloadPayMode = (mode) => {
    document.getElementById('rel-pay-mode').value = mode;
};

window.openCardSurcharge = () => {
    const amount = parseFloat(document.getElementById('rel-amount').value);
    if (!amount || amount <= 0) {
        window.showToast("Please enter a valid amount first", "error");
        return;
    }
    
    const surcharge = amount * 0.025;
    const total = amount + surcharge;
    
    document.getElementById('surcharge-base-amt').innerText = `LKR ${amount.toLocaleString()}`;
    document.getElementById('surcharge-fee-amt').innerText = `LKR ${surcharge.toLocaleString()}`;
    document.getElementById('surcharge-total-amt').innerText = `LKR ${total.toLocaleString()}`;
    
    const surchargeModal = document.getElementById('modal-card-surcharge');
    if (surchargeModal) {
        const confirmBtn = surchargeModal.querySelector('.action-btn.primary');
        if (confirmBtn) {
            confirmBtn.onclick = () => window.quickProcessReload('Card');
        }
        surchargeModal.style.display = 'flex';
    }
};

// --- Popup Specific Helpers ---
window.selectReloadNetworkPopup = (network, btn) => {
    document.getElementById('pos-rel-network').value = network;
    
    document.querySelectorAll('.net-btn-popup').forEach(b => {
        b.style.background = 'rgba(255,255,255,0.03)';
        b.style.color = 'white';
        b.style.borderColor = 'rgba(255,255,255,0.1)';
        b.style.transform = 'scale(1)';
    });
    
    const brandColors = {
        'Dialog': '#ed1c24',
        'Mobitel': '#1e40af',
        'Hutch': '#ff6600',
        'Airtel': '#dc2626'
    };
    
    btn.style.background = brandColors[network] || '#002060';
    btn.style.borderColor = 'white';
    btn.style.transform = 'scale(1.05)';
    btn.style.boxShadow = `0 0 15px ${brandColors[network]}88`;

};

window.autoDetectNetworkPopup = (number) => {
    if (!number || number.length < 3) return;
    const cleanNum = number.replace(/[\s-]/g, '');
    const prefix = cleanNum.substring(0, 3);
    
    let network = null;
    if (['077', '076', '074'].includes(prefix)) network = 'Dialog';
    else if (['071', '070'].includes(prefix)) network = 'Mobitel';
    else if (['078', '072'].includes(prefix)) network = 'Hutch';
    else if (['075'].includes(prefix)) network = 'Airtel';
    
    if (network) {
        const btns = document.querySelectorAll('.net-btn-popup');
        btns.forEach(btn => {
            if (btn.innerText.trim() === network) {
                window.selectReloadNetworkPopup(network, btn);
            }
        });
    }
};

window.quickProcessReload = async (method) => {
    const network = document.getElementById('rel-network').value;
    const phone = document.getElementById('rel-phone').value;
    const amountStr = document.getElementById('rel-amount').value;
    const amount = parseFloat(amountStr);
    const payMode = method || document.getElementById('rel-pay-mode').value;
    const storeId = window.getStoreId();

    if (!network || !phone || isNaN(amount) || amount <= 0) {
        window.showToast("Please fill all reload details!", "error");
        return;
    }

    if (window.isReloadProcessing) return;
    window.isReloadProcessing = true;

    // Handle Credit (Naya) Customer Selection
    let customerId = null;
    if (payMode === 'Credit') {
        const selectedId = document.getElementById('rel-cust-id').value;
        if (!selectedId) {
            // [v3.9.69] Pre-populate quick registration phone with the reload phone
            const regPhone = document.getElementById('reg-rel-cust-phone');
            if (regPhone) regPhone.value = phone;
            
            document.getElementById('modal-reload-customer').style.display = 'flex';
            window.isReloadProcessing = false; // RELEASE LOCK!
            return;
        }
        customerId = selectedId;
    }

    try {
        window.showToast("Processing reload...", "info");
        
        let surcharge = 0;
        let finalAmount = amount;
        
        if (payMode === 'Card') {
            surcharge = amount * 0.025;
            finalAmount = amount + surcharge;
        }

        const calculateCommission = (net, amt) => {
            if (net === 'Dialog') return amt * 0.04;
            if (net === 'Mobitel') return amt * 0.06;
            if (net === 'Hutch') return amt * 0.04;
            if (net === 'Airtel') return amt * 0.04;
            if (net === 'Dialog TV' || net === 'Router') return amt * 0.04;
            return amt * 0.01; // Default 1%
        };
        const commission = calculateCommission(network, amount);

        // 2. Parallel Dispatch
        const reloadData = {
            network, phone, amount: finalAmount, baseAmount: amount,
            surcharge, commission, payMode, storeId, status: 'Completed',
            timestamp: serverTimestamp(), date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
            staffId: sessionStorage.getItem('userId') || 'Master',
            staffName: sessionStorage.getItem('userName') || 'Master Admin',
            customerId: customerId || null, customerName: window.selectedReloadCustomerName || null
        };

        const tasks = [addDoc(collection(db, 'reloads'), reloadData)];

        if (payMode === 'Credit' && customerId) {
            tasks.push(addDoc(collection(db, 'credit_ledger'), {
                customerId, 
                customerName: window.selectedReloadCustomerName,
                type: 'Debit', 
                amount: finalAmount, 
                reason: `Reload: ${network} to ${phone}`,
                storeId, 
                timestamp: serverTimestamp(), 
                date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE')
            }));

            // [v3.9.59] Update Customer Outstanding Balance
            const customer = window.allCustomers?.find(c => c.docId === customerId);
            if (customer) {
                tasks.push(updateDoc(doc(db, 'customers', customerId), {
                    outstanding: (customer.outstanding || 0) + finalAmount
                }));
            }
        }

        await Promise.all(tasks);

        window.showToast("✅ Reload Successful!", "success");
        document.getElementById('modal-card-surcharge').style.display = 'none';
        
        // 3. Reset UI
        const form = document.getElementById('reload-form');
        if (form) form.reset();
        
        // Reset state & Visuals
        document.querySelectorAll('.net-btn').forEach(b => {
            b.style.background = 'white';
            b.style.color = '#333';
            b.style.borderColor = '#ddd';
        });
        window.selectedNetwork = null;
        window.selectedReloadCustomerName = null;
        document.getElementById('rel-cust-id').value = '';
        document.getElementById('rel-cust-search').value = '';
        
    } catch (err) {
        console.error(err);
        window.showToast("Error processing reload!", "error");
    } finally {
        window.isReloadProcessing = false;
    }
};

// --- SYNC & RENDERING ---

window.initReloadSync = () => {
    try {
        // Clean up existing listener to prevent duplicate triggers
        if (typeof window._unsubscribeReloadSync === 'function') {
            try {
                window._unsubscribeReloadSync();
            } catch (e) {}
        }

        const storeId = window.getStoreId();
        if (!storeId) {
            console.warn("Reload sync delayed: storeId is not available yet.");
            window._reloadSyncActive = false;
            return;
        }
        
        let q;
        if (storeId === 'master') {
            q = query(
                collection(db, 'reloads'),
                limit(300)
            );
        } else {
            q = query(
                collection(db, 'reloads'),
                where('storeId', '==', storeId),
                limit(150)
            );
        }

        const listContainer = document.getElementById('reload-history-list');
        if (listContainer) {
            listContainer.innerHTML = `<div style="text-align:center; padding:2rem; opacity:0.5;">📡 Connecting to reload sync...</div>`;
        }

        window._unsubscribeReloadSync = onSnapshot(q, (snapshot) => {
            try {
                const reloads = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                reloads.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
                
                window.allReloads = reloads;
                window._reloadSyncActive = true;
                window.renderReloadHistory();

                if (window.currentActiveTab === 'credit' && window.currentCreditTab === 'reload' && typeof window.renderCreditLedgerUI === 'function') {
                    window.renderCreditLedgerUI();
                }
            } catch (snapErr) {
                console.error("Snapshot process error:", snapErr);
                window.showToast("Snapshot process error: " + snapErr.message, "error");
            }
        }, (err) => {
            console.error("Reload sync error:", err);
            window.showToast("Firestore query error: " + err.message, "error");
            window._reloadSyncActive = false;
        });
    } catch (e) {
        console.error("initReloadSync failed:", e);
        window.showToast("initReloadSync failed: " + e.message, "error");
    }
};

window.loadReloadHistory = () => {
    try {
        if (!window._reloadSyncActive) {
            window.initReloadSync();
        } else {
            window.renderReloadHistory();
        }
    } catch (e) {
        console.error("loadReloadHistory failed:", e);
        window.showToast("loadReloadHistory failed: " + e.message, "error");
    }
};

window.renderReloadHistory = () => {
    try {
        const listContainer = document.getElementById('reload-history-list');
        if (!listContainer) return;

        const startDate = document.getElementById('rel-filter-start')?.value;
        const endDate = document.getElementById('rel-filter-end')?.value;

        let filtered = [...(window.allReloads || [])];
        
        if (startDate || endDate) {
            filtered = filtered.filter(r => {
                const d = r.date || (r.timestamp && r.timestamp.seconds ? new Date(r.timestamp.seconds * 1000).toLocaleDateString('sv-SE') : '');
                if (!d) return false;
                if (startDate && d < startDate) return false;
                if (endDate && d > endDate) return false;
                return true;
            });
        }

        if (filtered.length === 0) {
            listContainer.innerHTML = `<div style="text-align:center; padding:3rem; color:var(--text-muted); opacity:0.6;">
                <div style="font-size:2.5rem; margin-bottom:1rem;">📱</div>
                No transactions found for this period.<br>Try adjusting filters.
            </div>`;
            return;
        }

        listContainer.innerHTML = filtered.map(data => {
            const dateStr = data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'}) : 'Pending...';
            const comm = data.commission || 0;
            const isVoid = data.status === 'Void';
            const netName = data.network || 'Other';
            const phoneNo = data.phone || 'N/A';
            const amt = data.amount || 0;
            const payMode = data.payMode || 'Cash';
            
            // Network specific colors
            const netColors = {
                'Dialog': '#ed1c24',
                'Mobitel': '#1e40af',
                'Hutch': '#ff6600',
                'Airtel': '#dc2626',
                'Dialog TV': '#ed1c24',
                'Router': '#4338ca',
                'SLT': '#0284c7'
            };
            const themeColor = isVoid ? '#94a3b8' : (netColors[netName] || '#6366f1');

            return `
                <div class="glass-card" style="padding: 12px 15px; border-left: 5px solid ${themeColor}; background: ${isVoid ? 'rgba(255,255,255,0.02)' : 'rgba(255,255,255,0.05)'}; display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; border-radius: 12px; opacity: ${isVoid ? '0.6' : '1'}; position: relative;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <div style="width: 35px; height: 35px; border-radius: 8px; background: ${themeColor}22; display: flex; align-items: center; justify-content: center; font-weight: 900; color: ${themeColor}; font-size: 0.65rem;">
                            ${netName.substring(0,3).toUpperCase()}
                        </div>
                        <div>
                            <div style="font-weight: 800; font-size: 0.95rem; ${isVoid ? 'text-decoration: line-through;' : ''}">${phoneNo}</div>
                            <div style="font-size: 0.65rem; color: #94a3b8; font-weight: 700;">
                                ${dateStr} • <span style="color: ${payMode === 'Credit' ? '#f59e0b' : '#10b981'};">${payMode}</span>
                                ${isVoid ? ' • <span style="color:#ef4444;">VOIDED</span>' : ''}
                            </div>
                        </div>
                    </div>
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="text-align: right;">
                            <div style="font-weight: 900; color: white; font-size: 1rem; ${isVoid ? 'text-decoration: line-through;' : ''}">LKR ${amt.toLocaleString()}</div>
                            <div style="font-size: 0.7rem; font-weight: 800; color: #10b981; ${isVoid ? 'opacity:0.3;' : ''}">+LKR ${comm.toFixed(2)}</div>
                        </div>
                        ${!isVoid ? `
                        <button onclick="window.voidReload('${data.docId}')" 
                            style="background: rgba(239, 68, 68, 0.1); border: none; width: 30px; height: 30px; border-radius: 8px; cursor: pointer; color: #ef4444; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; transition: all 0.2s;"
                            title="Void Transaction">
                            🗑️
                        </button>
                        ` : `
                        <div style="width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; opacity: 0.3;">🚫</div>
                        `}
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) {
        console.error("renderReloadHistory failed:", e);
        window.showToast("renderReloadHistory failed: " + e.message, "error");
    }
};
window.voidReload = async (docId) => {
    // Premium Authorization Overlay Logic...
    // For brevity, I'll assume the user wants the secure voiding logic restored from previous sessions.
    // I will include it here to ensure it's "locked" and correct.
    const overlay = document.createElement('div');
    overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999;`;
    overlay.innerHTML = `
        <div style="background:#0f172a; padding:40px; border-radius:24px; border:1px solid rgba(255,255,255,0.1); text-align:center; max-width:400px; width:90%;">
            <div style="font-size:3rem; margin-bottom:20px;">🛡️</div>
            <h2 style="color:white; margin:0 0 10px;">Manager Authorization</h2>
            <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:25px;">Enter credentials to void this reload.</p>
            <input type="password" id="void-pass" placeholder="Manager Password" style="width:100%; padding:15px; border-radius:12px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; font-size:1.1rem; text-align:center; margin-bottom:15px; outline:none;">
            <div style="display:flex; gap:10px;">
                <button id="void-cancel" style="flex:1; padding:15px; border-radius:12px; background:rgba(255,255,255,0.05); color:#94a3b8; border:none; cursor:pointer; font-weight:700;">Cancel</button>
                <button id="void-confirm" style="flex:2; padding:15px; border-radius:12px; background:#ef4444; color:white; border:none; cursor:pointer; font-weight:800;">Authorize Void</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    
    document.getElementById('void-cancel').onclick = () => overlay.remove();
    document.getElementById('void-confirm').onclick = async () => {
        const pass = document.getElementById('void-pass').value;
        if (pass === 'mec123') {
            try {
                await updateDoc(doc(db, 'reloads', docId), { status: 'Void' });
                window.showToast("Transaction Voided Successfully", "info");
                overlay.remove();
            } catch (e) {
                console.error(e);
                window.showToast("Error voiding transaction", "error");
            }
        } else {
            window.showToast("Invalid Credentials!", "error");
        }
    };
};


// --- POPUP VERSION FOR POS ---

window.openQuickReloadModal = () => {
    document.getElementById('pos-quick-reload-modal').style.display = 'flex';
    document.getElementById('pos-rel-phone').value = '';
    document.getElementById('pos-rel-amount').value = '';
    document.getElementById('pos-rel-network').value = '';
    
    // Reset visuals
    document.querySelectorAll('.net-btn-popup').forEach(b => {
        b.style.background = 'rgba(255,255,255,0.03)';
        b.style.color = 'white';
        b.style.borderColor = 'rgba(255,255,255,0.1)';
    });

    window.activeReloadPayMethodIndex = 0;
    window.selectPaymentMethodPopup(0);
    
    const phoneInput = document.getElementById('pos-rel-phone');
    const amountInput = document.getElementById('pos-rel-amount');
    
    // Attach keyboard listener if not already
    if (!phoneInput.dataset.listener) {
        phoneInput.onkeydown = (e) => window.handleReloadPopupKeydown(e, 'phone');
        phoneInput.dataset.listener = "true";
    }
    if (!amountInput.dataset.listener) {
        amountInput.onkeydown = (e) => window.handleReloadPopupKeydown(e, 'amount');
        amountInput.dataset.listener = "true";
    }

    setTimeout(() => {
        const nets = document.querySelectorAll('.net-btn-popup');
        if (nets.length > 0) {
            nets[0].focus();
            nets[0].click(); // Auto-select the first one (Dialog) for convenience
        } else {
            amountInput.focus();
        }
    }, 300);
};

window.handleReloadPopupKeydown = (e, context) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        if (context === 'phone') {
            document.getElementById('pos-rel-amount').focus();
        } else if (context === 'amount') {
            // Focus the active payment button
            const activeBtn = document.querySelectorAll('.rel-pay-btn')[window.activeReloadPayMethodIndex];
            if (activeBtn) activeBtn.focus();
        }
    }
};

// Global listener for the modal itself to handle arrows when buttons are focused
window.addEventListener('keydown', (e) => {
    // 1. POS Quick Reload Modal Workflow
    const modal = document.getElementById('pos-quick-reload-modal');
    if (modal && modal.style.display !== 'none') {
        const nets = Array.from(document.querySelectorAll('.net-btn-popup'));
        const dialogBtn = document.getElementById('btn-dialog-recharge');
        const amount = document.getElementById('pos-rel-amount');
        const pays = Array.from(document.querySelectorAll('.rel-pay-btn')); // [0:Cash, 1:Card, 2:Naya, 3:Add to Bill]
        const addToBillBtn = document.querySelector('#pos-quick-reload-modal .action-btn.primary') || pays[3];
        const active = document.activeElement;

        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            modal.style.display = 'none';
            const searchEl = document.getElementById('pos-search');
            if (searchEl) {
                searchEl.focus();
                searchEl.select();
            }
            return;
        }



        // Handle Navigation keys (Arrow keys + Enter + Tab)
        if (['ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowLeft'].includes(e.key)) {
            e.preventDefault();
            e.stopPropagation();

            // If focus is currently outside modal controls, pull it to active network button or amount input
            const validElements = [...nets, dialogBtn, amount, ...pays, addToBillBtn].filter(Boolean);
            if (!validElements.includes(active)) {
                if (nets.length > 0) nets[0].focus();
                else if (amount) amount.focus();
                return;
            }
        }

        // ─── ARROW DOWN Navigation ───
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            e.stopPropagation();
            if (nets.includes(active)) {
                if (dialogBtn && dialogBtn.style.display !== 'none') dialogBtn.focus();
                else if (amount) { amount.focus(); amount.select(); }
            } else if (active === dialogBtn) {
                if (amount) { amount.focus(); amount.select(); }
            } else if (active === amount) {
                if (pays.length > 0) {
                    pays[0].focus();
                    window.activeReloadPayMethodIndex = 0;
                    if (typeof window.selectPaymentMethodPopup === 'function') window.selectPaymentMethodPopup(0);
                }
            } else if (pays.slice(0, 3).includes(active)) {
                if (addToBillBtn) addToBillBtn.focus();
            }
        }
        // ─── ARROW UP Navigation ───
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            e.stopPropagation();
            if (active === addToBillBtn || pays[3] === active) {
                const idx = window.activeReloadPayMethodIndex || 0;
                if (pays[idx]) pays[idx].focus();
            } else if (pays.slice(0, 3).includes(active)) {
                if (amount) { amount.focus(); amount.select(); }
            } else if (active === amount) {
                if (dialogBtn && dialogBtn.style.display !== 'none') dialogBtn.focus();
                else if (nets.length > 0) {
                    const activeNet = nets.find(b => b.classList.contains('active')) || nets[0];
                    activeNet.focus();
                }
            } else if (active === dialogBtn) {
                if (nets.length > 0) {
                    const activeNet = nets.find(b => b.classList.contains('active')) || nets[0];
                    activeNet.focus();
                }
            }
        }
        // ─── ARROW RIGHT Navigation ───
        else if (e.key === 'ArrowRight') {
            if (nets.includes(active)) {
                e.preventDefault();
                e.stopPropagation();
                const idx = (nets.indexOf(active) + 1) % nets.length;
                nets[idx].focus();
                nets[idx].click();
            } else if (pays.slice(0, 3).includes(active)) {
                e.preventDefault();
                e.stopPropagation();
                const idx = (pays.indexOf(active) + 1) % 3;
                window.activeReloadPayMethodIndex = idx;
                if (typeof window.selectPaymentMethodPopup === 'function') window.selectPaymentMethodPopup(idx);
                pays[idx].focus();
            }
        }
        // ─── ARROW LEFT Navigation ───
        else if (e.key === 'ArrowLeft') {
            if (nets.includes(active)) {
                e.preventDefault();
                e.stopPropagation();
                const idx = (nets.indexOf(active) - 1 + nets.length) % nets.length;
                nets[idx].focus();
                nets[idx].click();
            } else if (pays.slice(0, 3).includes(active)) {
                e.preventDefault();
                e.stopPropagation();
                const idx = (pays.indexOf(active) - 1 + 3) % 3;
                window.activeReloadPayMethodIndex = idx;
                if (typeof window.selectPaymentMethodPopup === 'function') window.selectPaymentMethodPopup(idx);
                pays[idx].focus();
            }
        }
        return; // Don't process terminal keys if POS modal is open
    }

    // 2. Main Terminal Reload Workflow
    const reloadView = document.getElementById('reload-quick-view');
    // Only if the terminal reload view is visible and active
    if (reloadView && reloadView.offsetParent !== null) {
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
            // Ignore if typing inside an input field
            if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
            
            const buttons = document.querySelectorAll('.term-pay-btn');
            if (buttons.length === 0) return;

            if (window.activeTermPayMethodIndex === undefined) window.activeTermPayMethodIndex = 0;

            if (e.key === 'ArrowRight') {
                window.activeTermPayMethodIndex = (window.activeTermPayMethodIndex + 1) % buttons.length;
            } else {
                window.activeTermPayMethodIndex = (window.activeTermPayMethodIndex - 1 + buttons.length) % buttons.length;
            }
            
            window.selectTerminalPaymentMethod(window.activeTermPayMethodIndex);
            buttons[window.activeTermPayMethodIndex].focus();
            e.preventDefault();
        }
    }
});

window.selectTerminalPaymentMethod = (index) => {
    const buttons = document.querySelectorAll('.term-pay-btn');
    if (buttons.length === 0) return;
    
    buttons.forEach((btn, i) => {
        if (i === index) {
            btn.style.transform = 'scale(1.05)';
            btn.style.border = '2px solid white';
        } else {
            btn.style.transform = 'scale(1)';
            btn.style.border = 'none';
        }
    });
    window.activeTermPayMethodIndex = index;
};

window.selectPaymentMethodPopup = (index) => {
    const buttons = document.querySelectorAll('.rel-pay-btn');
    buttons.forEach((btn, i) => {
        if (i === index) btn.classList.add('active');
        else btn.classList.remove('active');
    });
    window.activeReloadPayMethodIndex = index;
};


window.selectReloadNetworkPopup = (network, btn) => {
    document.getElementById('pos-rel-network').value = network;
    
    document.querySelectorAll('.net-btn-popup').forEach(b => {
        b.style.background = 'rgba(255,255,255,0.03)';
        b.style.color = 'white';
        b.style.borderColor = 'rgba(255,255,255,0.1)';
    });
    
    const brandColors = {
        'Dialog': '#ed1c24',
        'Mobitel': '#1e40af',
        'Hutch': '#ff6600',
        'Airtel': '#dc2626'
    };
    
    btn.style.background = brandColors[network] || '#0ea5e9';
    btn.style.borderColor = brandColors[network] || '#0ea5e9';
};

window.autoDetectNetworkPopup = (number) => {
    if (!number || number.length < 3) return;
    const prefix = number.substring(0, 3);
    let network = null;
    if (['077', '076', '074'].includes(prefix)) network = 'Dialog';
    else if (['071', '070'].includes(prefix)) network = 'Mobitel';
    else if (['078', '072'].includes(prefix)) network = 'Hutch';
    else if (['075'].includes(prefix)) network = 'Airtel';
    
    if (network) {
        const btns = document.querySelectorAll('.net-btn-popup');
        btns.forEach(btn => {
            if (btn.innerText.trim() === network) {
                window.selectReloadNetworkPopup(network, btn);
            }
        });
    }
};

window.quickProcessReloadPopup = async (payMode) => {
    try {
        const network = document.getElementById('pos-rel-network').value;
        const phoneVal = document.getElementById('pos-rel-phone').value.trim();
        const phone = phoneVal || "No Number";
        const amountStr = document.getElementById('pos-rel-amount').value;
        const amount = parseFloat(amountStr);
        const storeId = window.getStoreId();

        if (!network || isNaN(amount) || amount <= 0) {
            window.showToast("Please fill all details correctly!", "error");
            return;
        }

        if (window.isReloadProcessing) return;

        // [v3.9.61] Handle Credit (Naya) for Popup
        if (payMode === 'Credit') {
            const customerPhoneInput = document.getElementById('pos-cust-phone');
            let customerPhone = customerPhoneInput ? customerPhoneInput.value.trim() : "";
            
            // Fallback: If no customer selected in POS, use the reload phone number
            if (!customerPhone) customerPhone = phone.trim();

            const cleanInputPhone = customerPhone.replace(/[\s-]/g, "");
            const customer = (window.allCustomers || []).find(c => {
                const cleanCustPhone = (c.phone || "").replace(/[\s-]/g, "");
                return (cleanCustPhone !== "" && cleanCustPhone === cleanInputPhone) || 
                       (c.loyaltyCardNo && c.loyaltyCardNo === customerPhone);
            });

            if (!customer) {
                // [v3.9.62] Show Quick Registration Modal
                document.getElementById('reg-rel-cust-phone').value = customerPhone;
                document.getElementById('reg-rel-cust-name').value = "";
                document.getElementById('pos-reload-cust-modal').style.display = 'flex';
                setTimeout(() => document.getElementById('reg-rel-cust-name').focus(), 300);
                return;
            }
        }


        // Handle Card Surcharge
        if (payMode === 'Card') {
            const surcharge = amount * 0.025;
            const total = amount + surcharge;
            
            const surchargeModal = document.getElementById('pos-modal-card-surcharge');
            if (surchargeModal) {
                document.getElementById('pos-surcharge-base-amt').innerText = `LKR ${amount.toLocaleString()}`;
                document.getElementById('pos-surcharge-fee-amt').innerText = `LKR ${surcharge.toLocaleString()}`;
                document.getElementById('pos-surcharge-total-amt').innerText = `LKR ${total.toLocaleString()}`;
                surchargeModal.style.display = 'flex';
                
                const confirmBtn = surchargeModal.querySelector('.action-btn.primary');
                if (confirmBtn) {
                    confirmBtn.onclick = () => window.executeReloadPopupSave(payMode, amount, surcharge, network, phone);
                    setTimeout(() => confirmBtn.focus(), 300);
                } else {
                    window.showToast("Debug: Confirm button not found in modal", "error");
                }
                return;
            } else {
                window.showToast("Debug: pos-modal-card-surcharge not found in DOM!", "error");
                // Fallback to save without modal if it's somehow missing
                return await window.executeReloadPopupSave(payMode, amount, surcharge, network, phone);
            }
        }

        await window.executeReloadPopupSave(payMode, amount, 0, network, phone);
    } catch (e) {
        console.error("CRITICAL ERROR in quickProcessReloadPopup:", e);
        window.showToast("Critical Error: " + e.message, "error");
    }
};

window.executeReloadPopupSave = async (payMode, baseAmount, surcharge, network, phone, explicitCustomer = null) => {
    const storeId = window.getStoreId();
    const finalAmount = baseAmount + surcharge;
    
    if (window.isReloadProcessing) return;
    window.isReloadProcessing = true;

    // Safe & immediate closing of modals for instant UI response
    const reloadModal = document.getElementById('pos-quick-reload-modal');
    const surchargeModal = document.getElementById('pos-modal-card-surcharge');
    if (reloadModal) reloadModal.style.display = 'none';
    if (surchargeModal) surchargeModal.style.display = 'none';

    try {
        window.showToast("Saving transaction...", "info");
        
        // Disable buttons in popup
        const btns = document.querySelectorAll('.rel-pay-btn');
        btns.forEach(b => b.disabled = true);
        
        const calculateCommission = (net, amt) => {
            if (net === 'Dialog') return amt * 0.04;
            if (net === 'Mobitel') return amt * 0.06;
            if (net === 'Hutch') return amt * 0.04;
            if (net === 'Airtel') return amt * 0.04;
            if (net === 'Dialog TV' || net === 'Router') return amt * 0.04;
            return amt * 0.01; // Default 1%
        };
        const commission = calculateCommission(network, baseAmount);

        // Detect POS Customer for Credit linking
        // Detect Customer by Reload Phone Number or POS Customer
        let customer = explicitCustomer;
        
        if (!customer) {
            const cleanReloadPhone = phone.replace(/[\s-]/g, "").replace(/\D/g, '');
            customer = (window.allCustomers || []).find(c => {
                const cleanCustPhone = (c.phone || "").replace(/[\s-]/g, "").replace(/\D/g, '');
                return cleanCustPhone !== "" && cleanCustPhone === cleanReloadPhone && c.storeId === storeId;
            });

            if (!customer) {
                const customerPhoneInput = document.getElementById('pos-cust-phone');
                let customerPhone = customerPhoneInput ? customerPhoneInput.value.trim() : "";
                if (customerPhone) {
                    const cleanInputPhone = customerPhone.replace(/[\s-]/g, "");
                    customer = (window.allCustomers || []).find(c => {
                        const cleanCustPhone = (c.phone || "").replace(/[\s-]/g, "");
                        return ((cleanCustPhone !== "" && cleanCustPhone === cleanInputPhone) || 
                               (c.loyaltyCardNo && c.loyaltyCardNo === customerPhone)) && c.storeId === storeId;
                    });
                }
            }
        }

        const reloadData = {
            network,
            phone,
            amount: finalAmount,
            baseAmount,
            surcharge,
            commission,
            payMode,
            storeId,
            status: 'Completed',
            timestamp: serverTimestamp(),
            date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
            staffId: sessionStorage.getItem('userId') || 'Master',
            staffName: sessionStorage.getItem('userName') || 'Master Admin',
            customerId: customer ? (customer.docId || customer.id) : null,
            customerName: customer ? customer.name : "Walk-in Customer"
        };

        const tasks = [addDoc(collection(db, 'reloads'), reloadData)];

        // Handle Credit Ledger Sync
        const finalCustId = customer ? (customer.docId || customer.id) : null;
        if (payMode === 'Credit' && finalCustId) {
            tasks.push(addDoc(collection(db, 'credit_ledger'), {
                customerId: finalCustId,
                customerName: customer.name,
                type: 'Debit',
                amount: finalAmount,
                reason: `Reload (Quick POS): ${network} to ${phone}`,
                storeId,
                timestamp: serverTimestamp(),
                date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE')
            }));

            // Update Customer Outstanding Balance
            tasks.push(updateDoc(doc(db, 'customers', finalCustId), {
                outstanding: (customer.outstanding || 0) + finalAmount
            }));
        }

        await Promise.all(tasks);

        window.showToast("✅ Reload Successful!", "success");
        
        // Reset form
        const phoneInput = document.getElementById('pos-rel-phone');
        const amountInput = document.getElementById('pos-rel-amount');
        if (phoneInput) phoneInput.value = '';
        if (amountInput) amountInput.value = '';
        
        // Clear/Reset POS Terminal state
        if (typeof window.resetPOS === 'function') {
            window.resetPOS();
        }
        
    } catch (err) {
        console.error(err);
        window.showToast("Error processing reload: " + err.message, "error");
    } finally {
        window.isReloadProcessing = false;
        const btns = document.querySelectorAll('.rel-pay-btn');
        btns.forEach(b => {
            b.disabled = false;
            b.style.opacity = '1';
        });
    }
};

window.registerCustomerAndSaveReload = async () => {
    const name = document.getElementById('reg-rel-cust-name').value.trim();
    const phone = document.getElementById('reg-rel-cust-phone').value.trim();
    const type = document.getElementById('reg-rel-cust-type').value;

    if (!name) {
        window.showToast("Please enter customer name!", "error");
        return;
    }

    try {
        window.showToast("Registering customer...", "info");
        
        // Auto-generate Loyalty ID (Logic mirrored from pos.js)
        const custs = window.allCustomers || [];
        let generatedId = '';
        if (type === 'wholesale') {
            const cCount = custs.filter(c => c.customerType === 'wholesale').length;
            generatedId = 'WHO-' + String(cCount + 1).padStart(3, '0');
        } else {
            const cCount = custs.filter(c => c.customerType !== 'wholesale').length;
            generatedId = 'LO-' + String(cCount + 1).padStart(3, '0');
        }

        const newCust = {
            name, 
            phone, 
            loyaltyCardNo: generatedId,
            customerType: type,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp(),
            outstanding: 0
        };

        const docRef = await addDoc(collection(db, 'customers'), newCust);
        const finalCustomer = { ...newCust, docId: docRef.id, id: docRef.id };

        document.getElementById('pos-reload-cust-modal').style.display = 'none';
        document.getElementById('modal-reload-customer').style.display = 'none';
        
        // Now proceed with saving the reload
        const payMode = 'Credit';
        // Check context using modal visibility
        const posModal = document.getElementById('pos-quick-reload-modal');
        const isFromPOS = posModal && posModal.style.display === 'flex';

        const network = isFromPOS ? document.getElementById('pos-rel-network').value : document.getElementById('rel-network').value;
        const amountStr = isFromPOS ? document.getElementById('pos-rel-amount').value : document.getElementById('rel-amount').value;
        const amount = parseFloat(amountStr);
        const reloadPhone = isFromPOS ? document.getElementById('pos-rel-phone').value : document.getElementById('rel-phone').value;
        
        if (isFromPOS) {
            // It's from POS Popup
            await window.executeReloadPopupSave(payMode, amount, 0, network, reloadPhone, finalCustomer);
        } else {
            // It's from Terminal View (Quick Reload)
            // Mirroring quickProcessReload task dispatch
            window.isReloadProcessing = true; // Set to true as we are bypassing the main func
            try {
                const commission = (net, amt) => (net === 'Dialog' || net === 'Mobitel') ? amt * 0.015 : amt * 0.02;
                const reloadData = {
                    network, phone: reloadPhone, amount, baseAmount: amount,
                    surcharge: 0, commission: commission(network, amount), payMode, storeId: window.getStoreId(), status: 'Completed',
                    timestamp: serverTimestamp(), date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
                    staffId: sessionStorage.getItem('userId') || 'Master',
                    staffName: sessionStorage.getItem('userName') || 'Master Admin',
                    customerId: finalCustomer.docId, customerName: finalCustomer.name
                };

                const tasks = [
                    addDoc(collection(db, 'reloads'), reloadData),
                    addDoc(collection(db, 'credit_ledger'), {
                        customerId: finalCustomer.docId, customerName: finalCustomer.name,
                        type: 'Debit', amount, reason: `Reload: ${network} to ${reloadPhone}`,
                        storeId: window.getStoreId(), timestamp: serverTimestamp(), date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE')
                    }),
                    updateDoc(doc(db, 'customers', finalCustomer.docId), { outstanding: amount })
                ];

                await Promise.all(tasks);
                window.showToast("✅ Reload & Registration Successful!", "success");
                
                // Reset form
                const form = document.getElementById('reload-form');
                if (form) form.reset();
                window.selectedNetwork = null;
            } catch (err) {
                console.error(err);
                window.showToast("Error saving reload after registration!", "error");
            } finally {
                window.isReloadProcessing = false;
            }
        }
        
    } catch (err) {
        console.error(err);
        window.showToast("Error registering customer: " + err.message, "error");
    }
};


window.addReloadToActiveBill = () => {
    const network = document.getElementById('pos-rel-network').value;
    const phoneVal = document.getElementById('pos-rel-phone').value.trim();
    const phone = phoneVal || "No Number";
    const amountStr = document.getElementById('pos-rel-amount').value;
    const amount = parseFloat(amountStr);

    if (!network || isNaN(amount) || amount <= 0) {
        window.showToast("Please fill all details correctly!", "error");
        return;
    }

    const calculateCommission = (net, amt) => {
        if (net === 'Dialog') return amt * 0.04;
        if (net === 'Mobitel') return amt * 0.06;
        if (net === 'Hutch') return amt * 0.04;
        if (net === 'Airtel') return amt * 0.04;
        if (net === 'Dialog TV' || net === 'Router') return amt * 0.04;
        return amt * 0.01; // Default 1%
    };
    const commission = calculateCommission(network, amount);

    const activeBill = window.getActiveBill();
    activeBill.items.push({
        docId: 'reload-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        name: phoneVal ? `Reload - ${network} (${phoneVal})` : `Reload - ${network}`,
        price: amount,
        quantity: 1,
        discount: 0,
        variantIndex: undefined,
        costPrice: amount - commission,
        mode: 'Service',
        category: 'Reload',
        sku: 'RELOAD-' + network.toUpperCase(),
        isReload: true,
        reloadDetails: {
            network,
            phone,
            amount,
            commission
        }
    });

    window.showToast("🛒 Reload added to POS Bill!", "success");
    document.getElementById('pos-quick-reload-modal').style.display = 'none';
    
    // Reset modal inputs
    document.getElementById('pos-rel-phone').value = '';
    document.getElementById('pos-rel-amount').value = '';
    document.getElementById('pos-rel-network').value = '';
    
    // Re-render POS Bill items
    if (window.renderPOSBill) window.renderPOSBill();
};

window.searchReloadCustomer = (val) => {
    const list = document.getElementById('rel-cust-list');
    if (!list) return;

    if (!val || val.trim() === "") {
        list.innerHTML = "";
        return;
    }

    const q = val.toLowerCase().trim();
    const matches = (window.allCustomers || []).filter(c => {
        const name = (c.name || '').toLowerCase();
        const phone = (c.phone || '').toLowerCase();
        const card = (c.loyaltyCardNo || '').toLowerCase();
        return name.includes(q) || phone.includes(q) || card.includes(q);
    });

    list.innerHTML = matches.map(c => `
        <div onclick="window.selectReloadCustomer('${c.docId}', '${c.name.replace(/'/g, "\\'")}')" 
             style="background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 12px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: 0.2s; margin-bottom: 8px;"
             onmouseover="this.style.background='rgba(56, 189, 248, 0.1)'; this.style.borderColor='rgba(56, 189, 248, 0.3)';"
             onmouseout="this.style.background='rgba(255, 255, 255, 0.03)'; this.style.borderColor='rgba(255, 255, 255, 0.1)';"
        >
            <div>
                <div style="font-weight: 700; color: white;">${c.name}</div>
                <div style="font-size: 0.75rem; color: #94a3b8;">${c.phone || 'No Phone'}</div>
            </div>
            <div style="font-size: 0.75rem; background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 2px 8px; border-radius: 6px; font-weight: 800; text-transform: uppercase;">
                ${c.customerType || 'retail'}
            </div>
        </div>
    `).join('');
};

window.lookupReloadCustomer = (phone) => {
    const previewEl = document.getElementById('rel-cust-preview');
    const nameValEl = document.getElementById('rel-cust-name-val');
    if (!previewEl || !nameValEl) return;

    if (!phone || phone.trim().length < 9) {
        previewEl.style.display = 'none';
        return;
    }

    const cleanedPhone = phone.trim().replace(/\D/g, '');
    const customer = (window.allCustomers || []).find(c => {
        const cPhone = (c.phone || '').trim().replace(/\D/g, '');
        return cPhone === cleanedPhone && c.storeId === window.getStoreId();
    });

    if (customer) {
        nameValEl.innerText = customer.name;
        previewEl.style.display = 'block';
    } else {
        previewEl.style.display = 'none';
    }
};

window.selectReloadCustomer = (docId, name) => {
    document.getElementById('rel-cust-id').value = docId;
    window.selectedReloadCustomerName = name;
    
    // Close modal
    const modal = document.getElementById('modal-reload-customer');
    if (modal) modal.style.display = 'none';
    
    // Resume processing reload as credit
    window.quickProcessReload('Credit');
};

// --- Dialog Scan & Recharge Decoder Implementation ---

window.handleDialogUrlInput = (url) => {
    const cardEl = document.getElementById('dialog-decoded-card');
    const pinEl = document.getElementById('dialog-decoded-pin');
    const portalIframe = document.getElementById('dialog-portal-iframe');
    if (!cardEl || !pinEl) return;

    if (!url || url.trim() === '') {
        cardEl.style.display = 'none';
        return;
    }

    // Instantly launch C# native WebView2 popup to bypass X-Frame block when a Dialog link is pasted!
    if (url.toLowerCase().startsWith('http')) {
        window.openDialogPortalPopup(url);
    }

    try {
        const hashIndex = url.indexOf('#code=');
        if (hashIndex === -1) {
            // Check if it's already a raw code/PIN
            if (/^[A-Za-z0-9+/=]+$/.test(url.trim()) && url.trim().length > 20) {
                const decoded = atob(url.trim());
                pinEl.innerText = decoded;
                cardEl.style.display = 'block';
            } else {
                cardEl.style.display = 'none';
            }
            return;
        }

        const encoded = url.substring(hashIndex + 6);
        const decoded = atob(encoded); // Native Base64 Decode
        
        if (decoded) {
            pinEl.innerText = decoded;
            cardEl.style.display = 'block';
            window.showToast("🔓 Voucher code successfully decoded!", "success");
        } else {
            cardEl.style.display = 'none';
        }
    } catch (e) {
        console.error("Base64 decode error:", e);
        cardEl.style.display = 'none';
    }
};

window.copyDecodedPin = () => {
    const pinEl = document.getElementById('dialog-decoded-pin');
    if (pinEl && pinEl.innerText !== '-') {
        navigator.clipboard.writeText(pinEl.innerText);
        window.showToast("📋 PIN copied to clipboard!", "success");
    }
};

window.addDialogVoucherToPOS = () => {
    const url = document.getElementById('dialog-recharge-url').value;
    const pinEl = document.getElementById('dialog-decoded-pin');
    const valueSelect = document.getElementById('dialog-card-value');
    
    if (!pinEl || pinEl.innerText === '-' || pinEl.innerText === '') {
        window.showToast("Please paste a valid Dialog Recharge URL first!", "error");
        return;
    }

    const value = parseFloat(valueSelect.value || "100");
    const pin = pinEl.innerText;
    
    // Add to POS Cart
    const activeBill = window.getActiveBill();
    if (!activeBill) {
        window.showToast("No active POS bill found! Open the POS tab.", "error");
        return;
    }

    activeBill.items.push({
        docId: 'dialog-recharge-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        name: `Dialog Recharge (PIN: ${pin.substring(0,4)}...${pin.substring(pin.length - 4)})`,
        price: value,
        quantity: 1,
        discount: 0,
        variantIndex: undefined,
        costPrice: value * 0.96, // 4% commission assumed
        mode: 'Service',
        category: 'Reload',
        sku: 'DIALOG-VOUCHER-' + value,
        isReload: true,
        reloadDetails: {
            network: 'Dialog',
            phone: 'Voucher',
            amount: value,
            commission: value * 0.04,
            voucherPin: pin,
            voucherUrl: url
        }
    });

    window.showToast(`🛒 LKR ${value} Dialog Voucher added to Bill!`, "success");
    
    // Reset form
    document.getElementById('dialog-recharge-url').value = '';
    document.getElementById('dialog-decoded-card').style.display = 'none';
    document.getElementById('dialog-decoded-pin').innerText = '-';
    
    // Hide last URL display
    const lastUrlDisplay = document.getElementById('dialog-last-url-display');
    if (lastUrlDisplay) lastUrlDisplay.style.display = 'none';
    
    if (window.renderPOSBill) window.renderPOSBill();
};

window.openDialogPortalPopup = (url) => {
    const defaultUrl = "https://dialog.lk/scan-and-recharge?language=en#code=WlZrdEhud2ZWNGw1UFRQZlpKSFFrdVJRRURpbDlObWJhdkxWTFN1Nk14NGt2dnZXV3lTbm9LR3pmZWFiSlp3VitqaERnNExvZDkvblZKdzhNcjFweTdrVitmN3MxTDVvTTRxbU80ZEZ2L0JEQU9mYTNTcHRRYlJnNVpjendSN0s=";
    const configuredUrl = window._configuredDialogQrUrl || "";
    const targetUrl = url || (configuredUrl.trim() !== "" ? configuredUrl : defaultUrl);
    window._lastActiveDialogUrl = targetUrl;

    // 1. Close quick reload modal if open
    const quickReloadModal = document.getElementById('pos-quick-reload-modal');
    if (quickReloadModal) quickReloadModal.style.display = 'none';

    // 2. Open directly in external browser (Google Chrome in foreground)
    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(targetUrl);
        window.showToast("⚡ Opening Dialog Portal in Chrome...", "info");
        return;
    }

    if (window.chrome && window.chrome.webview && typeof window.chrome.webview.postMessage === 'function') {
        try {
            window.chrome.webview.postMessage({
                type: 'openExternalUrl',
                action: 'openExternalUrl',
                url: targetUrl
            });
            window.chrome.webview.postMessage(JSON.stringify({
                type: 'openExternalUrl',
                action: 'openExternalUrl',
                url: targetUrl
            }));
            window.showToast("⚡ Opening Dialog Portal in Chrome...", "info");
            return;
        } catch(e) {
            console.warn("Failed to trigger Chrome launch:", e);
        }
    }

    // 3. Web Browser mode fallback
    try {
        window.open(targetUrl, '_blank');
        window.showToast("⚡ Dialog Scan & Recharge Opened!", "success");
    } catch(e) {
        window.showToast("⚠️ Popup blocked! Please allow popups for this site.", "error");
    }
};

window.openDialogExternalPageDirect = () => {
    const defaultUrl = "https://dialog.lk/scan-and-recharge?language=en#code=WlZrdEhud2ZWNGw1UFRQZlpKSFFrdVJRRURpbDlObWJhdkxWTFN1Nk14NGt2dnZXV3lTbm9LR3pmZWFiSlp3VitqaERnNExvZDkvblZKdzhNcjFweTdrVitmN3MxTDVvTTRxbU80ZEZ2L0JEQU9mYTNTcHRRYlJnNVpjendSN0s=";
    const targetUrl = window._lastActiveDialogUrl || defaultUrl;
    // Close the terminal modal
    const modal = document.getElementById('dialog-portal-iframe-modal');
    if (modal) modal.style.display = 'none';
    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(targetUrl);
    } else {
        window.open(targetUrl, '_blank', 'width=1200,height=800,scrollbars=yes,resizable=yes');
    }
};

window.openDialogExternalPage = () => {
    window.openDialogPortalPopup();
};

// Handle notifications back from C# popup window URL changes
window.onDialogPopupNavigated = (url) => {
    console.log("Dialog Popup navigated to:", url);
    const lastUrlDisplay = document.getElementById('dialog-last-url-display');
    if (lastUrlDisplay) {
        lastUrlDisplay.innerText = "Current URL: " + url;
        lastUrlDisplay.style.display = 'block';
    }
};

window.addAutoDialogReloadToPOS = (amount, phone) => {
    if (isNaN(amount) || amount <= 0) {
        window.showToast("Invalid auto reload amount!", "error");
        return;
    }
    
    const activeBill = window.getActiveBill();
    if (!activeBill) {
        window.showToast("No active POS bill found!", "error");
        return;
    }
    
    // Dialog Scan & Recharge commission is 4%
    const commission = amount * 0.04;
    const phoneVal = phone ? phone.trim() : "";
    
    activeBill.items.push({
        docId: 'dialog-scan-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        name: phoneVal ? `Dialog Scan & Recharge (${phoneVal})` : `Dialog Scan & Recharge`,
        price: amount,
        quantity: 1,
        discount: 0,
        variantIndex: undefined,
        costPrice: amount - commission,
        mode: 'Service',
        category: 'Reload',
        sku: 'DIALOG-SCAN-RECHARGE',
        isReload: true,
        reloadDetails: {
            network: 'Dialog',
            phone: phoneVal || 'Voucher',
            amount: amount,
            commission: commission
        }
    });
    
    window.showToast(`🛒 LKR ${amount} Dialog Recharge added to Bill!`, "success");
    if (window.renderPOSBill) window.renderPOSBill();
};

window.initReloadModule = initReloadModule;

