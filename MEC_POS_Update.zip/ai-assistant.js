/**
 * ARIA — AI Revenue Intelligence Assistant
 * MEC POS ZENITH — Powered by Firebase Vertex AI (Gemini 2.0 Flash)
 * Shared widget injected into all MEC POS panels.
 */

(function () {
    'use strict';

    // ── Firebase Vertex AI config (same project as MEC POS) ──────────────────
    const FIREBASE_CONFIG = {
        apiKey: "AIzaSyCFGweYcgmcfP5zS6M1ytOfKYKUbHfsols",
        authDomain: "mec-book-shop.firebaseapp.com",
        databaseURL: "https://mec-book-shop-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "mec-book-shop",
        storageBucket: "mec-book-shop.firebasestorage.app",
        messagingSenderId: "721921338336",
        appId: "1:721921338336:web:bcd6215a75b163145cd985",
        measurementId: "G-M0GZ9BXGBV"
    };

    // ── Detect which panel we're in ──────────────────────────────────────────
    const PAGE = (() => {
        const p = location.pathname;
        if (p.includes('super-admin')) return 'super-admin';
        if (p.includes('admin'))       return 'admin';
        if (p.includes('store') || p === '/' || p.includes('index')) return 'pos';
        return 'unknown';
    })();

    // ── System Prompt ────────────────────────────────────────────────────────
    const SYSTEM_PROMPT = `You are ARIA, the AI Revenue Intelligence Assistant built into MEC POS ZENITH — a cloud-based ERP and Point-of-Sale platform for Sri Lankan merchants.

You assist ${PAGE === 'super-admin' ? 'Super Admins managing all merchant stores and subscriptions' : PAGE === 'admin' ? 'Store Admins managing their shop operations, inventory, sales, and employees' : 'POS cashiers handling transactions, products, and orders'}.

Your personality:
- Professional, friendly, and efficient
- Respond in the same language the user uses (Sinhala, English, or Singlish)
- Keep answers concise and actionable
- Use emojis sparingly for clarity

Your capabilities:
- Answer questions about store management, subscriptions, revenue, inventory
- Analyze data that is shared with you in the conversation
- Help with system navigation and feature explanations
- Provide business insights and recommendations
- Help troubleshoot MEC POS features

MEC POS Plans: Trial (Free), Starter (LKR 4,900/mo), Professional (LKR 9,900/mo), Enterprise (LKR 19,900/mo)
Features: Multi-branch POS, inventory management, employee management, cloud sync, analytics, invoicing, Android app

Always be helpful. If you cannot do something, suggest the correct feature in MEC POS.`;

    // ── Chat History ─────────────────────────────────────────────────────────
    let chatHistory = [];
    let isOpen = false;
    let isThinking = false;
    let modelInstance = null;
    let chatSession = null;

    // ── Inject Styles ────────────────────────────────────────────────────────
    function injectStyles() {
        if (document.getElementById('aria-styles')) return;
        const style = document.createElement('style');
        style.id = 'aria-styles';
        style.textContent = `
            /* ═══════════════════════════════ ARIA WIDGET ═══════════════════════════════ */
            #aria-fab {
                position: fixed;
                bottom: 24px;
                right: 24px;
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background: linear-gradient(135deg, #7c3aed 0%, #00d4ff 100%);
                border: none;
                cursor: pointer;
                z-index: 99999;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 0 0 0 rgba(124,58,237,0.4), 0 8px 32px rgba(0,0,0,0.4);
                animation: aria-pulse 2.5s ease-in-out infinite;
                transition: transform 0.2s ease, box-shadow 0.2s ease;
            }
            #aria-fab:hover {
                transform: scale(1.08);
                box-shadow: 0 0 0 8px rgba(124,58,237,0.15), 0 12px 40px rgba(0,0,0,0.5);
            }
            #aria-fab:active { transform: scale(0.95); }
            #aria-fab svg { width: 28px; height: 28px; transition: opacity 0.2s; }
            #aria-fab .aria-close-icon { display: none; }
            #aria-fab.open .aria-ai-icon { display: none; }
            #aria-fab.open .aria-close-icon { display: block; }
            #aria-fab.open { animation: none; }

            @keyframes aria-pulse {
                0%, 100% { box-shadow: 0 0 0 0 rgba(124,58,237,0.4), 0 8px 32px rgba(0,0,0,0.4); }
                50%       { box-shadow: 0 0 0 12px rgba(124,58,237,0), 0 8px 32px rgba(0,0,0,0.4); }
            }

            /* Badge */
            #aria-badge {
                position: fixed;
                bottom: 72px;
                right: 20px;
                background: linear-gradient(135deg, #7c3aed, #00d4ff);
                color: #fff;
                font-size: 11px;
                font-weight: 700;
                padding: 3px 9px;
                border-radius: 20px;
                z-index: 99998;
                opacity: 1;
                transition: opacity 0.5s;
                font-family: 'Outfit', 'Inter', sans-serif;
                letter-spacing: 0.5px;
                pointer-events: none;
            }
            #aria-badge.hidden { opacity: 0; pointer-events: none; }

            /* Chat Panel */
            #aria-panel {
                position: fixed;
                bottom: 96px;
                right: 24px;
                width: 380px;
                height: 560px;
                background: rgba(10, 14, 26, 0.97);
                backdrop-filter: blur(24px);
                border: 1px solid rgba(124,58,237,0.3);
                border-radius: 20px;
                z-index: 99998;
                display: flex;
                flex-direction: column;
                overflow: hidden;
                box-shadow: 0 32px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(0,212,255,0.08);
                transform: translateY(20px) scale(0.95);
                opacity: 0;
                pointer-events: none;
                transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1), opacity 0.25s ease;
                font-family: 'Outfit', 'Inter', sans-serif;
            }
            #aria-panel.open {
                transform: translateY(0) scale(1);
                opacity: 1;
                pointer-events: all;
            }

            /* Header */
            .aria-header {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 16px 20px;
                background: linear-gradient(135deg, rgba(124,58,237,0.2) 0%, rgba(0,212,255,0.1) 100%);
                border-bottom: 1px solid rgba(255,255,255,0.06);
                flex-shrink: 0;
            }
            .aria-avatar {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: linear-gradient(135deg, #7c3aed, #00d4ff);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                flex-shrink: 0;
                box-shadow: 0 0 16px rgba(124,58,237,0.4);
            }
            .aria-header-info { flex: 1; }
            .aria-header-info h3 {
                color: #fff;
                font-size: 15px;
                font-weight: 700;
                margin: 0;
                letter-spacing: 0.3px;
            }
            .aria-status {
                display: flex;
                align-items: center;
                gap: 5px;
                font-size: 11px;
                color: #10b981;
                margin-top: 2px;
                font-weight: 500;
            }
            .aria-status-dot {
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #10b981;
                animation: aria-blink 2s ease-in-out infinite;
            }
            @keyframes aria-blink {
                0%, 100% { opacity: 1; }
                50%       { opacity: 0.3; }
            }
            .aria-clear-btn {
                background: rgba(255,255,255,0.06);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px;
                color: #94a3b8;
                cursor: pointer;
                padding: 5px 8px;
                font-size: 12px;
                transition: all 0.2s;
                display: flex;
                align-items: center;
                gap: 4px;
            }
            .aria-clear-btn:hover { background: rgba(255,255,255,0.1); color: #e2e8f0; }

            /* Messages */
            .aria-messages {
                flex: 1;
                overflow-y: auto;
                padding: 16px;
                display: flex;
                flex-direction: column;
                gap: 12px;
                scroll-behavior: smooth;
            }
            .aria-messages::-webkit-scrollbar { width: 4px; }
            .aria-messages::-webkit-scrollbar-track { background: transparent; }
            .aria-messages::-webkit-scrollbar-thumb { background: rgba(124,58,237,0.4); border-radius: 2px; }

            /* Welcome */
            .aria-welcome {
                text-align: center;
                padding: 20px 12px;
                color: #64748b;
            }
            .aria-welcome .aria-welcome-emoji {
                font-size: 40px;
                margin-bottom: 12px;
                display: block;
                animation: aria-float 3s ease-in-out infinite;
            }
            @keyframes aria-float {
                0%, 100% { transform: translateY(0); }
                50%       { transform: translateY(-6px); }
            }
            .aria-welcome h4 { color: #e2e8f0; font-size: 16px; margin-bottom: 6px; }
            .aria-welcome p { font-size: 13px; line-height: 1.5; }

            /* Suggestions */
            .aria-suggestions {
                display: flex;
                flex-direction: column;
                gap: 6px;
                margin-top: 16px;
            }
            .aria-suggestion {
                background: rgba(124,58,237,0.08);
                border: 1px solid rgba(124,58,237,0.2);
                border-radius: 10px;
                padding: 8px 12px;
                cursor: pointer;
                color: #a78bfa;
                font-size: 12px;
                text-align: left;
                transition: all 0.2s;
                font-family: inherit;
            }
            .aria-suggestion:hover {
                background: rgba(124,58,237,0.18);
                border-color: rgba(124,58,237,0.5);
                color: #c4b5fd;
                transform: translateX(3px);
            }

            /* Message bubbles */
            .aria-msg {
                max-width: 88%;
                animation: aria-msg-in 0.3s cubic-bezier(0.34,1.56,0.64,1);
            }
            @keyframes aria-msg-in {
                from { opacity: 0; transform: translateY(8px) scale(0.96); }
                to   { opacity: 1; transform: translateY(0) scale(1); }
            }
            .aria-msg.user { align-self: flex-end; }
            .aria-msg.ai   { align-self: flex-start; }

            .aria-msg-bubble {
                padding: 10px 14px;
                border-radius: 14px;
                font-size: 13.5px;
                line-height: 1.55;
                word-break: break-word;
            }
            .aria-msg.user .aria-msg-bubble {
                background: linear-gradient(135deg, #7c3aed, #5b21b6);
                color: #fff;
                border-bottom-right-radius: 4px;
            }
            .aria-msg.ai .aria-msg-bubble {
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.08);
                color: #e2e8f0;
                border-bottom-left-radius: 4px;
            }
            .aria-msg.ai .aria-msg-bubble strong { color: #a78bfa; }
            .aria-msg.ai .aria-msg-bubble code {
                background: rgba(124,58,237,0.2);
                padding: 1px 5px;
                border-radius: 4px;
                font-size: 12px;
                color: #00d4ff;
                font-family: monospace;
            }
            .aria-msg-time {
                font-size: 10px;
                color: #475569;
                margin-top: 4px;
                padding: 0 2px;
            }
            .aria-msg.user .aria-msg-time { text-align: right; }

            /* Thinking */
            .aria-thinking .aria-msg-bubble {
                display: flex;
                gap: 5px;
                align-items: center;
                padding: 12px 16px;
            }
            .aria-dot {
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #7c3aed;
                animation: aria-bounce 1.2s ease-in-out infinite;
            }
            .aria-dot:nth-child(2) { animation-delay: 0.2s; background: #5b8def; }
            .aria-dot:nth-child(3) { animation-delay: 0.4s; background: #00d4ff; }
            @keyframes aria-bounce {
                0%, 100% { transform: translateY(0); opacity: 0.4; }
                50%       { transform: translateY(-6px); opacity: 1; }
            }

            /* Input area */
            .aria-input-area {
                padding: 12px 16px;
                border-top: 1px solid rgba(255,255,255,0.06);
                display: flex;
                gap: 8px;
                align-items: flex-end;
                background: rgba(0,0,0,0.2);
                flex-shrink: 0;
            }
            #aria-input {
                flex: 1;
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                color: #e2e8f0;
                padding: 10px 14px;
                font-size: 13.5px;
                font-family: inherit;
                resize: none;
                max-height: 100px;
                min-height: 40px;
                line-height: 1.5;
                outline: none;
                transition: border-color 0.2s;
                overflow-y: auto;
            }
            #aria-input:focus { border-color: rgba(124,58,237,0.5); }
            #aria-input::placeholder { color: #475569; }
            #aria-send {
                width: 40px;
                height: 40px;
                border-radius: 10px;
                background: linear-gradient(135deg, #7c3aed, #00d4ff);
                border: none;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                transition: transform 0.15s, opacity 0.15s;
            }
            #aria-send:hover { transform: scale(1.05); }
            #aria-send:active { transform: scale(0.95); }
            #aria-send:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
            #aria-send svg { width: 18px; height: 18px; fill: #fff; }

            /* Context bar */
            .aria-context-bar {
                padding: 6px 16px;
                background: rgba(0,212,255,0.04);
                border-bottom: 1px solid rgba(0,212,255,0.08);
                display: flex;
                align-items: center;
                gap: 6px;
                font-size: 11px;
                color: #38bdf8;
                flex-shrink: 0;
            }

            /* Responsive */
            @media (max-width: 440px) {
                #aria-panel { width: calc(100vw - 24px); right: 12px; bottom: 84px; }
                #aria-fab   { right: 16px; bottom: 16px; }
            }
        `;
        document.head.appendChild(style);
    }

    // ── Build HTML ───────────────────────────────────────────────────────────
    function buildWidget() {
        // FAB button
        const fab = document.createElement('button');
        fab.id = 'aria-fab';
        fab.setAttribute('aria-label', 'Open ARIA AI Assistant');
        fab.innerHTML = `
            <svg class="aria-ai-icon" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round">
                <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
                <circle cx="9" cy="13" r="1.5" fill="white" stroke="none"/>
                <circle cx="15" cy="13" r="1.5" fill="white" stroke="none"/>
            </svg>
            <svg class="aria-close-icon" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>`;

        // Badge
        const badge = document.createElement('div');
        badge.id = 'aria-badge';
        badge.textContent = 'Ask ARIA ✨';
        setTimeout(() => badge.classList.add('hidden'), 4000);

        // Panel
        const panel = document.createElement('div');
        panel.id = 'aria-panel';
        panel.setAttribute('role', 'dialog');
        panel.setAttribute('aria-label', 'ARIA AI Assistant');

        const contextLabel = PAGE === 'super-admin'
            ? '🏢 Super Admin Context · All Stores'
            : PAGE === 'admin' ? '🏪 Store Admin Context' : '🧾 POS Context';

        const suggestions = PAGE === 'super-admin' ? [
            '📊 Show total active merchants',
            '💰 What is the MRR breakdown by plan?',
            '🔧 How do I suspend a merchant store?'
        ] : PAGE === 'admin' ? [
            '📦 How do I add a new product?',
            '👥 How do I manage employees?',
            '📊 How do I view sales reports?'
        ] : [
            '💳 How do I process a return?',
            '🔍 How do I search for a product?',
            '🧾 How do I print a receipt?'
        ];

        panel.innerHTML = `
            <div class="aria-header">
                <div class="aria-avatar">✨</div>
                <div class="aria-header-info">
                    <h3>ARIA</h3>
                    <div class="aria-status">
                        <div class="aria-status-dot"></div>
                        AI Ready · Gemini 2.0 Flash
                    </div>
                </div>
                <button class="aria-clear-btn" id="aria-clear-btn" title="Clear chat">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>
                    Clear
                </button>
            </div>
            <div class="aria-context-bar">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                ${contextLabel}
            </div>
            <div class="aria-messages" id="aria-messages">
                <div class="aria-welcome">
                    <span class="aria-welcome-emoji">✨</span>
                    <h4>Hi, I'm ARIA!</h4>
                    <p>Your AI Revenue Intelligence Assistant. Ask me anything about MEC POS.</p>
                    <div class="aria-suggestions">
                        ${suggestions.map(s => `<button class="aria-suggestion">${s}</button>`).join('')}
                    </div>
                </div>
            </div>
            <div class="aria-input-area">
                <textarea id="aria-input" placeholder="Ask ARIA anything..." rows="1" maxlength="2000"></textarea>
                <button id="aria-send" title="Send">
                    <svg viewBox="0 0 24 24"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg>
                </button>
            </div>
        `;

        document.body.appendChild(fab);
        document.body.appendChild(badge);
        document.body.appendChild(panel);

        // Event listeners
        fab.addEventListener('click', togglePanel);
        document.getElementById('aria-send').addEventListener('click', sendMessage);
        document.getElementById('aria-clear-btn').addEventListener('click', clearChat);
        const input = document.getElementById('aria-input');
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
        });
        input.addEventListener('input', () => {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 100) + 'px';
        });

        // Suggestion buttons
        panel.querySelectorAll('.aria-suggestion').forEach(btn => {
            btn.addEventListener('click', () => {
                input.value = btn.textContent.replace(/^[^\w]+ /, '');
                sendMessage();
            });
        });
    }

    // ── Toggle Panel ─────────────────────────────────────────────────────────
    function togglePanel() {
        isOpen = !isOpen;
        document.getElementById('aria-fab').classList.toggle('open', isOpen);
        document.getElementById('aria-panel').classList.toggle('open', isOpen);
        if (isOpen) {
            document.getElementById('aria-badge').classList.add('hidden');
            setTimeout(() => document.getElementById('aria-input').focus(), 350);
            initAI();
        }
    }

    // ── Initialize Firebase Vertex AI ────────────────────────────────────────
    async function initAI() {
        if (modelInstance) return;
        try {
            const { initializeApp, getApps } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
            const { getVertexAI, getGenerativeModel } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-vertexai.js');

            const apps = getApps();
            const app = apps.find(a => a.name === 'aria') ||
                        initializeApp(FIREBASE_CONFIG, 'aria');

            const vertexAI = getVertexAI(app);
            modelInstance = getGenerativeModel(vertexAI, {
                model: 'gemini-2.0-flash',
                systemInstruction: SYSTEM_PROMPT
            });

            chatSession = modelInstance.startChat({ history: [] });
            updateStatus('AI Ready · Gemini 2.0 Flash', '#10b981');
        } catch (err) {
            console.warn('[ARIA] Vertex AI init failed, falling back to Gemini REST:', err.message);
            updateStatus('AI Ready (Direct)', '#10b981');
            modelInstance = 'rest';
        }
    }

    // ── Gemini REST fallback ─────────────────────────────────────────────────
    async function callGeminiRest(userMessage) {
        const contents = [
            ...chatHistory.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
            { role: 'user', parts: [{ text: userMessage }] }
        ];

        const resp = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${FIREBASE_CONFIG.apiKey}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents,
                    systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
                    generationConfig: { maxOutputTokens: 800, temperature: 0.7 }
                })
            }
        );
        if (!resp.ok) throw new Error(`API error ${resp.status}`);
        const data = await resp.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || 'I could not generate a response.';
    }

    // ── Inject live context from page ────────────────────────────────────────
    function getLiveContext() {
        const parts = [];
        try {
            if (window.cachedStores && window.cachedStores.length) {
                const total = window.cachedStores.length;
                const active = window.cachedStores.filter(s => s.status === 'Active').length;
                parts.push(`[Live data: ${total} merchant stores, ${active} active]`);
            }
            if (window.currentStoreData) {
                parts.push(`[Current store: ${window.currentStoreData.name || 'Unknown'}]`);
            }
        } catch (_) {}
        return parts.length ? '\n\n' + parts.join(' ') : '';
    }

    // ── Send Message ─────────────────────────────────────────────────────────
    async function sendMessage() {
        if (isThinking) return;
        const input = document.getElementById('aria-input');
        const text = input.value.trim();
        if (!text) return;

        input.value = '';
        input.style.height = 'auto';

        // Remove welcome screen
        const welcome = document.querySelector('.aria-welcome');
        if (welcome) welcome.remove();

        // Add user message
        appendMessage('user', text);
        chatHistory.push({ role: 'user', text });

        // Show thinking
        isThinking = true;
        document.getElementById('aria-send').disabled = true;
        const thinkingEl = appendThinking();

        try {
            await initAI();
            const fullMessage = text + getLiveContext();
            let response;

            if (modelInstance && modelInstance !== 'rest' && chatSession) {
                const result = await chatSession.sendMessage(fullMessage);
                response = result.response.text();
            } else {
                response = await callGeminiRest(fullMessage);
            }

            thinkingEl.remove();
            const formatted = formatResponse(response);
            appendMessage('ai', formatted, true);
            chatHistory.push({ role: 'model', text: response });

        } catch (err) {
            thinkingEl.remove();
            appendMessage('ai', `⚠️ Sorry, I encountered an error: ${err.message}. Please try again.`);
            console.error('[ARIA]', err);
        }

        isThinking = false;
        document.getElementById('aria-send').disabled = false;
    }

    // ── Format AI response (basic markdown) ─────────────────────────────────
    function formatResponse(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br>');
    }

    // ── Append Message ───────────────────────────────────────────────────────
    function appendMessage(role, content, isHTML = false) {
        const messages = document.getElementById('aria-messages');
        const msg = document.createElement('div');
        msg.className = `aria-msg ${role}`;

        const now = new Date();
        const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

        msg.innerHTML = `
            <div class="aria-msg-bubble">${isHTML ? content : escapeHTML(content)}</div>
            <div class="aria-msg-time">${time}</div>
        `;
        messages.appendChild(msg);
        messages.scrollTop = messages.scrollHeight;
        return msg;
    }

    // ── Append Thinking ──────────────────────────────────────────────────────
    function appendThinking() {
        const messages = document.getElementById('aria-messages');
        const msg = document.createElement('div');
        msg.className = 'aria-msg ai aria-thinking';
        msg.innerHTML = `
            <div class="aria-msg-bubble">
                <div class="aria-dot"></div>
                <div class="aria-dot"></div>
                <div class="aria-dot"></div>
            </div>`;
        messages.appendChild(msg);
        messages.scrollTop = messages.scrollHeight;
        return msg;
    }

    // ── Clear Chat ───────────────────────────────────────────────────────────
    function clearChat() {
        chatHistory = [];
        chatSession = null;
        if (modelInstance && modelInstance !== 'rest') {
            chatSession = modelInstance.startChat({ history: [] });
        }
        const messages = document.getElementById('aria-messages');
        messages.innerHTML = `
            <div class="aria-welcome">
                <span class="aria-welcome-emoji">✨</span>
                <h4>Chat cleared!</h4>
                <p>Starting a fresh conversation.</p>
            </div>`;
    }

    // ── Update status text ───────────────────────────────────────────────────
    function updateStatus(text, color) {
        const status = document.querySelector('.aria-status');
        if (status) {
            status.lastChild.textContent = ' ' + text;
            const dot = status.querySelector('.aria-status-dot');
            if (dot) dot.style.background = color;
        }
    }

    // ── Escape HTML ──────────────────────────────────────────────────────────
    function escapeHTML(str) {
        return str.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }

    // ── Init ─────────────────────────────────────────────────────────────────
    function init() {
        // Disabled widget injection as requested
        const existingFab = document.getElementById('aria-fab');
        if (existingFab) existingFab.remove();
        const existingPanel = document.getElementById('aria-panel');
        if (existingPanel) existingPanel.remove();
        const existingBadge = document.getElementById('aria-badge');
        if (existingBadge) existingBadge.remove();
        return;
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
