import { db, storage } from '../firebase.js';
import { collection, getDocs } from "firebase/firestore";
import { ref, uploadString, listAll, deleteObject } from "firebase/storage";

export async function runFullSystemBackup(isAuto = false) {
    try {
        if (!isAuto) window.showToast?.("📡 Gathering system data...", "info");
        
        const collectionsToBackup = [
            'products', 'customers', 'pos-orders', 'web-orders', 
            'repairs', 'employees', 'branches', 'stores', 
            'expenses', 'income', 'purchases', 'suppliers',
            'categories'
        ];

        const backupData = {
            version: "2.8.58",
            timestamp: new Date().toISOString(),
            storeId: window.getStoreId() || 'mec-book-shop',
            data: {}
        };

        for (const colName of collectionsToBackup) {
            const snapshot = await getDocs(collection(db, colName));
            backupData.data[colName] = snapshot.docs.map(doc => ({
                ...doc.data(),
                _id: doc.id
            }));
        }

        // Always trigger direct JSON file download for web browser and C# wrapper
        const cleanDate = new Date().toISOString().slice(0, 10);
        const cleanTime = new Date().toTimeString().slice(0, 5).replace(/:/g, '-');
        const fileName = `MEC_BACKUP_${backupData.storeId}_${cleanDate}_${cleanTime}.json`;
        
        const jsonStr = JSON.stringify(backupData, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        if (!isAuto) window.showToast?.(`📥 Backup Downloaded: ${fileName}`, "success");

        // Send to Electron if running inside Electron wrapper
        if (window.electron && window.electron.saveSystemBackup) {
            window.electron.saveSystemBackup(backupData);
        }

        // Upload to Firebase Cloud Storage for remote recovery
        try {
            console.log("☁️ Uploading backup to Firebase Cloud Storage...");
            const backupFileName = `backups/${backupData.storeId}/${fileName}`;
            const storageRef = ref(storage, backupFileName);
            
            await uploadString(storageRef, jsonStr, 'raw', {
                contentType: 'application/json'
            });
            console.log("☁️ Cloud Backup Successful:", backupFileName);

            // Programmatic rotation - Keep only the 3 latest backups in Firebase Storage for this merchant
            try {
                const listRef = ref(storage, `backups/${backupData.storeId}`);
                const res = await listAll(listRef);
                
                const sortedItems = res.items.sort((a, b) => a.name.localeCompare(b.name));
                
                if (sortedItems.length > 3) {
                    const toDeleteCount = sortedItems.length - 3;
                    console.log(`🧹 Rotating backups: deleting ${toDeleteCount} oldest backups...`);
                    for (let i = 0; i < toDeleteCount; i++) {
                        await deleteObject(sortedItems[i]);
                        console.log("🧹 Deleted old cloud backup:", sortedItems[i].name);
                    }
                }
            } catch (rotateErr) {
                console.error("Cloud Backup Rotation Failed:", rotateErr);
            }
        } catch (storageErr) {
            console.error("Cloud Backup Upload Failed:", storageErr);
        }

    } catch (err) {
        console.error("Backup Process Error:", err);
        if (!isAuto) window.showToast("❌ Backup process failed: " + err.message, "error");
    }
}

/**
 * Restore System Database from local JSON Backup file
 */
export async function restoreSystemBackup(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const backupObj = JSON.parse(e.target.result);
            if (!backupObj || !backupObj.data) {
                window.showToast?.("❌ Invalid Backup File Format!", "error");
                return;
            }

            const collectionsToRestore = Object.keys(backupObj.data);
            window.showToast?.(`📥 Restoring database (${collectionsToRestore.length} collections)...`, "info");

            let totalRestored = 0;
            for (const colName of collectionsToRestore) {
                const items = backupObj.data[colName] || [];
                for (const item of items) {
                    try {
                        const docId = item._id || item.id;
                        delete item._id;
                        if (docId) {
                            const { doc, setDoc } = await import('firebase/firestore');
                            await setDoc(doc(db, colName, docId), item, { merge: true });
                            totalRestored++;
                        }
                    } catch (itemErr) {
                        console.error(`Error restoring item in ${colName}:`, itemErr);
                    }
                }
            }

            window.showToast?.(`🎉 Restore Complete! ${totalRestored} records restored. Reloading UI...`, "success");
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } catch (err) {
            console.error("[Restore] Error:", err);
            window.showToast?.("❌ Failed to parse backup file: " + err.message, "error");
        }
    };
    reader.readAsText(file);
}

// Auto-trigger logic
export function initAutoBackup() {
    // Listen for status ONCE during app lifecycle
    if (window.electron && window.electron.onBackupStatus) {
        window.electron.onBackupStatus((result) => {
            if (result.success) {
                console.log("✅ Backup Saved:", result.path);
                window.showToast(`✅ Backup Saved: ${result.path.split('\\').pop()}`, "success");
                localStorage.setItem('last_backup_date', new Date().toDateString());
            } else {
                console.error("❌ Backup Failed:", result.error);
                window.showToast("❌ Backup Failed: " + result.error, "error");
            }
        });
    }

    const lastBackup = localStorage.getItem('last_backup_date');
    const today = new Date().toDateString();

    if (lastBackup !== today) {
        console.log("📅 Daily Backup Triggered...");
        setTimeout(() => {
            runFullSystemBackup(true);
        }, 30000); // Wait 30s after login
    }
}

window.runFullSystemBackup = runFullSystemBackup;
window.restoreSystemBackup = restoreSystemBackup;
