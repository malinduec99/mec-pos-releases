import { db } from '../firebase.js';
import { collection, query, onSnapshot, doc, setDoc, updateDoc, deleteDoc, addDoc, serverTimestamp, where } from "firebase/firestore";

window.mrpState = {
    activeSubTab: 'bom',
    boms: [],
    workOrders: [],
    rawMaterials: []
};

// Initialize MRP Module
window.initMRP = () => {
    console.log("🏭 MRP Module Initializing...");
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';
    
    // Listen to BOMs
    const bomsQ = isMaster ? collection(db, "boms") : query(collection(db, "boms"), where('storeId', '==', storeId));
    onSnapshot(bomsQ, (snapshot) => {
        window.mrpState.boms = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        if (window.mrpState.activeSubTab === 'bom') window.renderMRP();
    });

    // Listen to Work Orders
    const woQ = isMaster ? collection(db, "workOrders") : query(collection(db, "workOrders"), where('storeId', '==', storeId));
    onSnapshot(woQ, (snapshot) => {
        window.mrpState.workOrders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        if (window.mrpState.activeSubTab === 'workorders') window.renderMRP();
    });
};

window.switchMRPSubTab = (tab) => {
    window.mrpState.activeSubTab = tab;
    
    // Update UI active state
    document.querySelectorAll('#section-mrp .sub-tab').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`mrp-sub-tab-${tab}`).classList.add('active');
    
    window.renderMRP();
};

window.renderMRP = () => {
    const displayArea = document.getElementById('mrp-display-area');
    const actionBtn = document.getElementById('mrp-action-btn');
    if (!displayArea) return;

    switch (window.mrpState.activeSubTab) {
        case 'bom':
            actionBtn.innerHTML = "➕ Create BOM";
            actionBtn.onclick = () => window.openBOMModal();
            renderBOMList(displayArea);
            break;
        case 'workorders':
            actionBtn.innerHTML = "➕ New Work Order";
            actionBtn.onclick = () => window.openWorkOrderModal();
            renderWorkOrdersList(displayArea);
            break;
        case 'rawmaterials':
            actionBtn.innerHTML = "🧱 Add Raw Material";
            actionBtn.onclick = () => showTab('products'); // Suggest adding as product with category 'Raw Material'
            renderRawMaterialsList(displayArea);
            break;
        case 'scheduling':
            actionBtn.innerHTML = "📅 Plan Production";
            actionBtn.onclick = () => alert("Production Scheduling feature coming soon in v3.7.0");
            displayArea.innerHTML = `<div style="padding: 4rem; text-align: center; color: var(--text-muted);">
                <h3>Production Scheduling</h3>
                <p>Track factory capacity and machine availability. (Coming Soon)</p>
            </div>`;
            break;
    }
};

function renderBOMList(container) {
    if (window.mrpState.boms.length === 0) {
        container.innerHTML = `<div style="padding: 4rem; text-align: center; color: var(--text-muted);">No Bill of Materials defined yet.</div>`;
        return;
    }

    container.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Finished Product</th>
                    <th>Components</th>
                    <th>Est. Production Cost</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${window.mrpState.boms.map(bom => {
                    const product = (window.allProducts || []).find(p => p.docId === bom.productId);
                    return `
                        <tr>
                            <td>
                                <div style="font-weight: 800;">${product ? product.name : 'Unknown Product'}</div>
                                <div style="font-size: 0.75rem; color: var(--primary-blue);">${bom.productId}</div>
                            </td>
                            <td>
                                <div style="display: flex; flex-direction: column; gap: 4px;">
                                    ${bom.components.map(c => `
                                        <span style="font-size: 0.85rem;">• ${c.qty}x ${c.name}</span>
                                    `).join('')}
                                </div>
                            </td>
                            <td style="font-weight: 700; color: #10b981;">LKR ${bom.totalCost || 0}</td>
                            <td>
                                <button class="icon-btn edit" onclick="window.openBOMModal('${bom.id}')">📝</button>
                                <button class="icon-btn delete" onclick="window.deleteBOM('${bom.id}')">🗑️</button>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
}

function renderWorkOrdersList(container) {
    if (window.mrpState.workOrders.length === 0) {
        container.innerHTML = `<div style="padding: 4rem; text-align: center; color: var(--text-muted);">No active Work Orders.</div>`;
        return;
    }

    container.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
            ${window.mrpState.workOrders.map(wo => {
                const product = (window.allProducts || []).find(p => p.docId === wo.productId);
                const statusColor = wo.status === 'Completed' ? '#10b981' : (wo.status === 'In Progress' ? '#38bdf8' : '#f59e0b');
                return `
                    <div class="order-card" style="border-left: 5px solid ${statusColor};">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                            <span style="font-weight: 900; color: white;">WO-${wo.id.substring(0, 6).toUpperCase()}</span>
                            <span class="glass-tag" style="background: ${statusColor}22; color: ${statusColor};">${wo.status}</span>
                        </div>
                        <div style="font-size: 1.1rem; font-weight: 800; margin-bottom: 5px;">${product ? product.name : 'Unknown'}</div>
                        <div style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 15px;">Target Qty: <b style="color: white;">${wo.quantity}</b></div>
                        
                        <div style="display: flex; gap: 10px;">
                            ${wo.status !== 'Completed' ? `<button class="action-btn" style="flex: 1; font-size: 0.8rem; background: #10b981;" onclick="window.completeWorkOrder('${wo.id}')">Finish</button>` : ''}
                            <button class="action-btn" style="flex: 1; font-size: 0.8rem; background: rgba(255,255,255,0.05);" onclick="window.deleteWorkOrder('${wo.id}')">Cancel</button>
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
    `;
}

function renderRawMaterialsList(container) {
    const rawMaterials = (window.allProducts || []).filter(p => p.category === 'Raw Material' || p.category === 'Components');
    
    if (rawMaterials.length === 0) {
        container.innerHTML = `<div style="padding: 4rem; text-align: center; color: var(--text-muted);">
            <h3>No Raw Materials Found</h3>
            <p>Add products with the category "Raw Material" to track them here.</p>
        </div>`;
        return;
    }

    container.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Material Name</th>
                    <th>Current Stock</th>
                    <th>Unit Cost</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ${rawMaterials.map(rm => `
                    <tr>
                        <td style="font-weight: 800; color: white;">${rm.name}</td>
                        <td style="font-weight: 700; color: ${rm.stock < 10 ? '#ef4444' : '#10b981'};">${rm.stock} units</td>
                        <td style="color: var(--text-muted);">LKR ${rm.cost || 0}</td>
                        <td>
                            <button class="icon-btn edit" onclick="window.openEditModal('${rm.docId}')">📦 Restock</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Global Modals (Coming in Phase 2)
window.openBOMModal = (id) => alert("BOM Editor coming in v3.7.0. Current BOMs are read-only.");
window.openWorkOrderModal = (id) => alert("Work Order Creation coming in v3.7.0.");
