// --- Theme Sync System ---

window.applyTheme = (themeName) => {
    const root = document.documentElement;
    let colors = {};
    if (themeName === 'win11-light') {
        colors = { primary: '#002060', accent: '#00aeef', bg: '#f1f5f9', glass: 'rgba(255,255,255,0.85)' };
        root.style.colorScheme = "light";
    } else if (themeName === 'win11-dark') {
        colors = { primary: '#38bdf8', accent: '#7dd3fc', bg: '#0f172a', glass: 'rgba(30,41,59,0.85)' };
        root.style.colorScheme = "dark";
    } else if (themeName === 'cyberpunk') {
        colors = { primary: '#f000ff', accent: '#00f0ff', bg: '#11011c', glass: 'rgba(20,5,30,0.85)' };
        root.style.colorScheme = "dark";
    } else if (themeName === 'emerald') {
        colors = { primary: '#064e3b', accent: '#10b981', bg: '#022c22', glass: 'rgba(2,44,34,0.85)' };
        root.style.colorScheme = "dark";
    }

    localStorage.setItem('mecThemeMode', themeName);
    localStorage.setItem('mecThemeColors', JSON.stringify(colors));
    window.showToast("✨ Display Theme Updated!", "success");
    applyStoredTheme();
};

window.updateCustomColor = (type, value) => {
    const root = document.documentElement;
    if (type === 'primary') root.style.setProperty('--primary-blue', value);
    if (type === 'accent') root.style.setProperty('--accent-blue', value);
    if (type === 'bg') root.style.setProperty('--admin-bg', value);
};

window.saveCustomTheme = () => {
    const p = document.getElementById('theme-color-primary').value;
    const a = document.getElementById('theme-color-accent').value;
    const b = document.getElementById('theme-color-bg').value;
    const colors = { primary: p, accent: a, bg: b, glass: b + 'd9' }; // approx 85% opacity
    
    localStorage.setItem('mecThemeMode', 'custom');
    localStorage.setItem('mecThemeColors', JSON.stringify(colors));
    window.showToast("💾 Custom Theme Saved & Applied to Store!", "success");
    applyStoredTheme();
};

export function applyStoredTheme() {
    try {
        const stored = localStorage.getItem('mecThemeColors');
        if (stored) {
            const c = JSON.parse(stored);
            const root = document.documentElement;
            root.style.setProperty('--primary-blue', c.primary);
            root.style.setProperty('--accent-blue', c.accent);
            root.style.setProperty('--admin-bg', c.bg);
            root.style.setProperty('--glass-bg', c.glass);
            if(c.bg === '#0f172a' || c.bg === '#11011c' || c.bg === '#022c22') {
                 root.style.setProperty('--text-dark', '#f8fafc');
                 root.style.setProperty('--text-muted', '#94a3b8');
            } else {
                 root.style.setProperty('--text-dark', '#0f172a');
                 root.style.setProperty('--text-muted', '#64748b');
            }
        }
    } catch(e) {}
}

const THEMES = {
    original: { primary: '#38bdf8', accent: '#0ea5e9', bg: '#020617' },
    emerald: { primary: '#10b981', accent: '#34d399', bg: '#022c22' },
    crimson: { primary: '#ef4444', accent: '#f87171', bg: '#450a0a' },
    cyber: { primary: '#8b5cf6', accent: '#a78bfa', bg: '#0f172a' },
    'mec-light': { primary: '#002060', accent: '#00aeef', bg: '#ffffff' }
};

export function initTheme() {
    applyStoredTheme();
    // Use active theme if already set or saved in localStorage
    const savedTheme = localStorage.getItem('mec_active_theme') || 'classic-zenith';
    if (typeof window.setAdminTheme === 'function') {
        window.setAdminTheme(savedTheme, true);
    }
}

window.initTheme = initTheme;
