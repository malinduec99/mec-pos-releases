import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot,
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc, 
    serverTimestamp,
    query,
    where,
    getDocs,
    Timestamp
} from "firebase/firestore";
import { GoogleGenerativeAI } from "@google/generative-ai";

const accountsCol = collection(db, 'bank_accounts');
const transactionsCol = collection(db, 'bank_transactions');

let genAI = null;
try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY || "AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";
    if (apiKey) {
        genAI = new GoogleGenerativeAI(apiKey);
    }
} catch (e) {
    console.error("Error initializing GoogleGenerativeAI client in bankManager:", e);
}

window.initBankManager = initBankManager;

export function initBankManager() {
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    // Realtime listener for Bank Accounts
    const accQ = isMaster ? accountsCol : query(accountsCol, where('storeId', '==', storeId));
    onSnapshot(accQ, (snapshot) => {
        const accounts = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allBankAccounts = accounts;
        renderAccountsUI(accounts);
        populateAccountSelects(accounts);
    });

    // Realtime listener for Bank Transactions (limit to last 3 months for performance)
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    const txQ = query(transactionsCol, where('timestamp', '>=', Timestamp.fromDate(threeMonthsAgo)));
    onSnapshot(txQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const txs = isMaster ? raw : raw.filter(t => t.storeId === storeId);
        window.allBankTransactions = txs;
        renderTransactionsUI(txs);
    });
}

function renderAccountsUI(accounts) {
    const container = document.getElementById('bank-accounts-list');
    if (!container) return;

    if (accounts.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                🏦 No bank accounts registered yet. Add your first account above!
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
            ${accounts.map(acc => `
                <div class="stat-box primary" style="padding: 1.5rem; border-radius: 20px; border-left: 6px solid #a855f7;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <h4 style="margin: 0; font-size: 1.1rem; color: white;">${acc.bankName}</h4>
                            <p style="margin: 4px 0 0; font-size: 0.85rem; color: #94a3b8;">A/C: ${acc.accountNo}</p>
                            <p style="margin: 2px 0 0; font-size: 0.8rem; color: #64748b;">Holder: ${acc.holderName}</p>
                        </div>
                        <div style="display: flex; gap: 6px;">
                            <button class="icon-btn" onclick="window.openBankSettings('${acc.docId}')" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; border: none; font-size: 1rem;">⚙️</button>
                            <button class="icon-btn delete" onclick="window.deleteBankAccount('${acc.docId}')" style="background: rgba(239, 68, 68, 0.1); color: #ef4444; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; border: none; font-size: 1rem;">🗑️</button>
                        </div>
                    </div>
                    <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.8rem; color: #94a3b8; font-weight: 700; text-transform: uppercase;">Current Balance</span>
                        <span style="font-size: 1.3rem; font-weight: 900; color: #10b981;">LKR ${(acc.balance || 0).toFixed(2)}</span>
                    </div>
                    <div style="margin-top: 1rem; display: flex; gap: 8px;">
                        <button class="action-btn" onclick="window.openUploadStatementModal('${acc.docId}')" style="padding: 6px 12px; font-size: 0.75rem; background: #8b5cf6; border-color: #a855f7; width: 100%; justify-content: center; font-weight: 800;">📄 Upload Statement</button>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function populateAccountSelects(accounts) {
    const selects = ['stmt-account-select', 'slip-account-select'];
    selects.forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            select.innerHTML = `<option value="">-- Select Bank Account --</option>` +
                accounts.map(acc => `<option value="${acc.docId}">${acc.bankName} - ${acc.accountNo}</option>`).join('');
        }
    });
}

function renderTransactionsUI(txs) {
    const tbody = document.getElementById('bank-transactions-tbody');
    if (!tbody) return;

    const sorted = txs.sort((a, b) => new Date(b.date) - new Date(a.date));

    if (sorted.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 20px;">No recent transactions found.</td></tr>`;
        return;
    }

    tbody.innerHTML = sorted.map(t => {
        const typeBadge = t.type === 'Credit' 
            ? `<span class="status-badge" style="background: rgba(16, 185, 129, 0.15); color: #10b981; font-weight:800;">DEPOSIT</span>`
            : `<span class="status-badge" style="background: rgba(239, 68, 68, 0.15); color: #ef4444; font-weight:800;">WITHDRAWAL</span>`;
        
        const reconBadge = t.isReconciled 
            ? `<span class="status-badge" style="background: rgba(16, 185, 129, 0.2); color: #10b981; font-weight:800;">✅ MATCHED</span>`
            : `<span class="status-badge" style="background: rgba(245, 158, 11, 0.2); color: #f59e0b; font-weight:800;">⚠️ UNMATCHED</span>`;

        const amountColor = t.type === 'Credit' ? '#10b981' : '#ef4444';
        const amountPrefix = t.type === 'Credit' ? '+' : '-';

        return `
            <tr>
                <td>${t.date}</td>
                <td>${t.description}</td>
                <td>${typeBadge}</td>
                <td style="font-weight: 800; color: ${amountColor};">${amountPrefix} LKR ${t.amount.toFixed(2)}</td>
                <td><span style="font-family: monospace; font-size: 0.85rem; color: #38bdf8;">${t.referenceNo || 'N/A'}</span></td>
                <td>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        ${reconBadge}
                        ${!t.isReconciled ? `<button class="action-btn primary" onclick="window.autoMatchTransaction('${t.docId}')" style="padding: 4px 8px; font-size: 0.7rem; font-weight:800;">Auto Match</button>` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

window.addBankAccount = async (e) => {
    e.preventDefault();
    const bankName = document.getElementById('bank-name').value;
    const accountNo = document.getElementById('account-no').value;
    const holderName = document.getElementById('holder-name').value;
    const openingBalance = parseFloat(document.getElementById('opening-balance').value) || 0;

    const storeId = window.getStoreId();
    const branchId = sessionStorage.getItem('userBranchId') || 'Global';

    try {
        window.showToast("🚀 Registering bank account...", "info");
        await addDoc(accountsCol, {
            bankName,
            accountNo,
            holderName,
            balance: openingBalance,
            openingBalance,
            storeId,
            branchId,
            timestamp: serverTimestamp()
        });
        e.target.reset();
        window.showToast("✅ Bank account registered successfully!", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to register bank account.", "error");
    }
};

window.deleteBankAccount = async (id) => {
    if (!confirm("Are you sure you want to delete this bank account?")) return;
    const docRef = doc(db, 'bank_accounts', id);
    try {
        await deleteDoc(docRef);
        window.showToast("🗑️ Bank account deleted.", "info");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to delete account.", "error");
    }
};

// Modal trigger
window.openUploadStatementModal = (accountId) => {
    const modal = document.getElementById('bank-statement-modal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('stmt-account-select').value = accountId;
    }
};

// Simple client-side XOR obfuscation for database privacy (keyed by storeId)
function encryptPassword(text, key) {
    if (!text) return '';
    let result = '';
    for (let i = 0; i < text.length; i++) {
        result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    }
    return btoa(result);
}

function decryptPassword(encoded, key) {
    if (!encoded) return '';
    try {
        const text = atob(encoded);
        let result = '';
        for (let i = 0; i < text.length; i++) {
            result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        }
        return result;
    } catch (e) {
        return '';
    }
}

// PDF parser using PDF.js decryption and Gemini AI text analysis
async function parsePDFWithGemini(file, accountId) {
    if (!genAI) {
        try {
            genAI = new GoogleGenerativeAI("AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA");
        } catch (err) {
            console.error("Failed to initialize GoogleGenerativeAI with fallback key:", err);
        }
    }

    if (!genAI) {
        window.showToast("❌ Gemini AI is not configured.", "error");
        return [];
    }

    const acc = window.allBankAccounts?.find(a => a.docId === accountId);
    const storeId = window.getStoreId();
    const encryptedPassword = acc?.pdfPassword || '';
    const pdfPassword = decryptPassword(encryptedPassword, storeId);

    window.showToast("✨ Parsing PDF statement...", "info");

    let fullText = '';
    try {
        const arrayBuffer = await file.arrayBuffer();
        
        const loadingParams = {
            data: new Uint8Array(arrayBuffer)
        };
        if (pdfPassword && pdfPassword.trim() !== '') {
            loadingParams.password = pdfPassword;
        }

        if (typeof window.pdfjsLib === 'undefined') {
            throw new Error("PDF.js library failed to load in browser head.");
        }

        const loadingTask = window.pdfjsLib.getDocument(loadingParams);
        const pdf = await loadingTask.promise;
        window.showToast(`✨ Decrypted statement. Reading ${pdf.numPages} pages...`, "info");
        
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const textContent = await page.getTextContent();
            const pageText = textContent.items.map(item => item.str).join(' ');
            fullText += pageText + '\n';
        }

        if (!fullText.trim()) {
            window.showToast("⚠️ This PDF has no selectable text (scanned image). Please copy-paste the text into Option B.", "warning");
            return { transactions: [], closingBalance: null };
        }
    } catch (pdfErr) {
        console.error("PDF parsing/decryption failed:", pdfErr);
        window.showToast("❌ Decryption failed! Please check your PDF password in Bank Settings (⚙️).", "error");
        return { transactions: [], closingBalance: null };
    }

    window.showToast("✨ Gemini AI is analyzing the statement text...", "info");

    try {
        const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
        const prompt = `You are an expert financial assistant. Analyze this bank statement text.
Identify the final closing balance of the statement (the balance at the end of the statement period).
Extract all transactions.

Respond ONLY with a valid JSON object containing:
1. "closingBalance": number or null (the final statement balance if explicitly found in the text, e.g. 15450.00)
2. "transactions": JSON array of transaction objects, where each object has:
   - "date": string (format: YYYY-MM-DD)
   - "description": string (the transaction description, payee, or details)
   - "referenceNo": string (transaction ID or reference code if available, otherwise empty string "")
   - "amount": number (positive transaction amount)
   - "type": string (either "Credit" for deposits/inflow or "Debit" for withdrawals/outflow)

Respond ONLY with this JSON block, no markdown format tags or other text.
Statement text:
${fullText}`;

        const result = await model.generateContent(prompt);
        const responseText = result.response.text();
        const jsonStart = responseText.indexOf('{');
        const jsonEnd = responseText.lastIndexOf('}') + 1;
        
        if (jsonStart === -1 || jsonEnd === -1) {
            console.error("Gemini Response is not a JSON object:", responseText);
            throw new Error("Invalid response format from Gemini AI");
        }

        const jsonText = responseText.substring(jsonStart, jsonEnd);
        const parsed = JSON.parse(jsonText);
        
        return {
            transactions: parsed.transactions || [],
            closingBalance: typeof parsed.closingBalance === 'number' ? parsed.closingBalance : null
        };
    } catch (err) {
        console.error("Gemini PDF text parsing failed:", err);
        window.showToast("❌ Gemini AI failed to parse the statement text.", "error");
        return { transactions: [], closingBalance: null };
    }
}

// Bank Settings Modal Handlers
window.openBankSettings = (accountId) => {
    const modal = document.getElementById('bank-settings-modal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('settings-bank-id').value = accountId;
        const acc = window.allBankAccounts?.find(a => a.docId === accountId);
        const storeId = window.getStoreId();
        const encryptedPassword = acc?.pdfPassword || '';
        document.getElementById('settings-pdf-password').value = decryptPassword(encryptedPassword, storeId);
    }
};

window.saveBankSettings = async () => {
    const accountId = document.getElementById('settings-bank-id').value;
    const plainPassword = document.getElementById('settings-pdf-password').value;
    const storeId = window.getStoreId();
    const encryptedPassword = encryptPassword(plainPassword, storeId);
    
    try {
        window.showToast("Saving settings...", "info");
        const docRef = doc(db, 'bank_accounts', accountId);
        await updateDoc(docRef, { pdfPassword: encryptedPassword });

        document.getElementById('bank-settings-modal').style.display = 'none';
        window.showToast("✅ Settings saved successfully!", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Failed to save settings.", "error");
    }
};

// Parse bank statements (Support CSV/PDF files and manual text parsing)
window.processBankStatement = async () => {
    try {
        const accountId = document.getElementById('stmt-account-select').value;
        if (!accountId) {
            window.showToast("⚠️ Please select a bank account.", "warning");
            return;
        }

        const fileInput = document.getElementById('stmt-file');
        const textInput = document.getElementById('stmt-text-paste').value.trim();

        let transactions = [];
        let statementClosingBalance = null;

        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            if (file.name.toLowerCase().endsWith('.pdf')) {
                const res = await parsePDFWithGemini(file, accountId);
                transactions = res.transactions || [];
                statementClosingBalance = res.closingBalance;
            } else {
                const text = await file.text();
                transactions = parseCSVText(text);
            }
        } else if (textInput) {
            transactions = parseManualText(textInput);
        } else {
            window.showToast("⚠️ Please choose a file or paste statement text.", "warning");
            return;
        }

        if (transactions.length === 0) {
            window.showToast("❌ No valid transactions could be parsed.", "error");
            return;
        }

        // Save parsed transactions to Firestore
        window.showToast(`🚀 Processing ${transactions.length} transactions...`, "info");
        const storeId = window.getStoreId();
        const branchId = sessionStorage.getItem('userBranchId') || 'Global';

        let addedCount = 0;
        for (const tx of transactions) {
            try {
                await addDoc(transactionsCol, {
                    accountId,
                    date: tx.date,
                    description: tx.description,
                    amount: tx.amount,
                    type: tx.type, // 'Credit' (Deposit) or 'Debit' (Withdrawal)
                    referenceNo: tx.referenceNo,
                    isReconciled: false,
                    matchedDocId: null,
                    docType: null,
                    storeId,
                    branchId,
                    timestamp: serverTimestamp()
                });
                addedCount++;
            } catch (err) {
                console.error(err);
            }
        }

        // Update the bank account balance
        const accountRef = doc(db, 'bank_accounts', accountId);
        const currentAcc = window.allBankAccounts?.find(a => a.docId === accountId);
        if (currentAcc) {
            let newBalance = parseFloat(currentAcc.balance) || 0;
            if (statementClosingBalance !== null && !isNaN(statementClosingBalance)) {
                newBalance = statementClosingBalance;
                console.log(`Setting balance directly to closing balance from PDF statement: LKR ${newBalance}`);
            } else {
                // Calculate net change
                let netChange = 0;
                transactions.forEach(tx => {
                    const amt = parseFloat(tx.amount) || 0;
                    if (tx.type === 'Credit') netChange += amt;
                    else if (tx.type === 'Debit') netChange -= amt;
                });
                newBalance += netChange;
                console.log(`Updating balance by net change of LKR ${netChange}: new balance is LKR ${newBalance}`);
            }
            await updateDoc(accountRef, { balance: newBalance });
        }

        // Close modal and reset fields
        document.getElementById('bank-statement-modal').style.display = 'none';
        document.getElementById('stmt-file').value = '';
        document.getElementById('stmt-text-paste').value = '';
        window.showToast(`✅ Successfully imported ${addedCount} bank transactions and updated ledger balance!`, "success");
    } catch (e) {
        console.error("Uncaught error in processBankStatement:", e);
        window.showToast(`❌ Error: ${e.message}`, "error");
    }
};

// Simple CSV parser
function parseCSVText(text) {
    const rows = text.split('\n').map(row => row.split(','));
    const parsed = [];
    
    // Look for lines containing numbers/dates
    // Standard local statement layout: Date, Description, Reference, Withdrawal (Debit), Deposit (Credit)
    for (const row of rows) {
        if (row.length < 3) continue;
        const dateStr = row[0].trim();
        // Regex to detect common date formats (YYYY-MM-DD or DD/MM/YYYY)
        if (!/^\d{2,4}[-/\.]\d{2}[-/\.]\d{2,4}$/.test(dateStr)) continue;

        const description = row[1]?.trim() || "Online Transfer";
        const reference = row[2]?.trim() || "";

        // Parse amount columns
        const debit = parseFloat(row[3]?.replace(/[^\d\.]/g, '')) || 0;
        const credit = parseFloat(row[4]?.replace(/[^\d\.]/g, '')) || 0;

        if (debit > 0) {
            parsed.push({ date: dateStr, description, referenceNo: reference, amount: debit, type: 'Debit' });
        } else if (credit > 0) {
            parsed.push({ date: dateStr, description, referenceNo: reference, amount: credit, type: 'Credit' });
        }
    }
    return parsed;
}

// Manual Text Copy-Paste Parser (Regex matcher)
function parseManualText(text) {
    const lines = text.split('\n');
    const parsed = [];
    
    for (const line of lines) {
        // Matches common line formats containing a date and transaction amount
        // Example: 2026-07-04 CASH DEPOSIT 45000.00
        const dateMatch = line.match(/(\d{4}[-/\.]\d{2}[-/\.]\d{2})|(\d{2}[-/\.]\d{2}[-/\.]\d{4})/);
        if (!dateMatch) continue;

        const date = dateMatch[0];
        const cleanLine = line.replace(date, '').trim();

        // Extract amount (usually the last numeric string in the line)
        const numMatches = cleanLine.match(/\b\d+[\.,]\d{2}\b/g);
        if (!numMatches) continue;

        const amount = parseFloat(numMatches[numMatches.length - 1].replace(',', ''));
        const description = cleanLine.replace(numMatches[numMatches.length - 1], '').trim() || "Online Transfer";

        // Determine if it is a deposit (Credit) or withdrawal (Debit) by keywords
        const isCredit = /deposit|deposit|credit|cr\b|inflow|recv|received|\+/i.test(line);
        const type = isCredit ? 'Credit' : 'Debit';

        parsed.push({
            date,
            description,
            referenceNo: description.match(/\b[A-Z0-9]{8,12}\b/i)?.[0] || '',
            amount,
            type
        });
    }
    return parsed;
}

// Auto matching engine (links transaction to sales bills or expenses)
window.autoMatchTransaction = async (txId) => {
    window.showToast("🔍 Finding matches...", "info");
    const tx = window.allBankTransactions.find(t => t.docId === txId);
    if (!tx) return;

    const amount = tx.amount;
    const date = tx.date;

    if (tx.type === 'Credit') {
        // Find matching unpaid web orders or POS sales
        const orders = window.allOrders || [];
        const match = orders.find(o => Math.abs(parseFloat(o.total) - amount) < 1.0 && o.status !== 'Void');
        
        if (match) {
            // Found a match! Update transaction and order/invoice
            const txRef = doc(db, 'bank_transactions', txId);
            await updateDoc(txRef, {
                isReconciled: true,
                matchedDocId: match.docId,
                docType: 'Order'
            });

            // Adjust bank balance
            const accRef = doc(db, 'bank_accounts', tx.accountId);
            const acc = window.allBankAccounts.find(a => a.docId === tx.accountId);
            if (acc) {
                await updateDoc(accRef, { balance: (acc.balance || 0) + amount });
            }

            window.showToast(`✅ Matched successfully with Order #${match.docId.slice(-6).toUpperCase()}!`, "success");
        } else {
            window.showToast("❌ No matches found in current sales list.", "warning");
        }
    } else {
        // Find matching expenses
        const expenses = window.allExpenses || [];
        const match = expenses.find(ex => Math.abs(parseFloat(ex.amount) - amount) < 1.0);

        if (match) {
            const txRef = doc(db, 'bank_transactions', txId);
            await updateDoc(txRef, {
                isReconciled: true,
                matchedDocId: match.docId,
                docType: 'Expense'
            });

            // Deduct bank balance
            const accRef = doc(db, 'bank_accounts', tx.accountId);
            const acc = window.allBankAccounts.find(a => a.docId === tx.accountId);
            if (acc) {
                await updateDoc(accRef, { balance: (acc.balance || 0) - amount });
            }

            window.showToast(`✅ Matched successfully with Expense: ${match.title}!`, "success");
        } else {
            window.showToast("❌ No matching expenses found.", "warning");
        }
    }
};

// Client-Side OCR Deposit Slip Parser using Tesseract.js (Lazy-loaded)
let isTesseractLoading = false;

window.scanDepositSlip = async () => {
    const fileInput = document.getElementById('slip-image');
    if (fileInput.files.length === 0) {
        window.showToast("⚠️ Please select a deposit slip image.", "warning");
        return;
    }

    const file = fileInput.files[0];
    const outputDiv = document.getElementById('slip-ocr-results');
    outputDiv.innerHTML = `<div class="loader-report"></div><p style="text-align:center; font-size:0.9rem; color:#38bdf8;">Loading Tesseract OCR Engine...</p>`;

    // Dynamically load Tesseract.js if not already present
    if (typeof window.Tesseract === 'undefined' && !isTesseractLoading) {
        isTesseractLoading = true;
        await new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = "https://unpkg.com/tesseract.js@5.0.3/dist/tesseract.min.js";
            script.onload = () => {
                isTesseractLoading = false;
                resolve();
            };
            document.head.appendChild(script);
        });
    }

    outputDiv.innerHTML = `<div class="loader-report"></div><p style="text-align:center; font-size:0.9rem; color:#38bdf8;">Extracting text from image...</p>`;

    try {
        const result = await window.Tesseract.recognize(file, 'eng');
        const text = result.data.text;
        
        // Find reference number (typically a series of uppercase alphanumeric characters)
        const refNoMatch = text.match(/\b[A-Z0-9]{8,12}\b/i);
        const refNo = refNoMatch ? refNoMatch[0].toUpperCase() : 'Not Found';

        // Find numbers that resemble amounts (e.g. LKR 1,500.00 or 1500.00)
        const amountMatches = text.match(/\b\d+[\.,]\d{2}\b/g) || [];
        let parsedAmount = 0;
        if (amountMatches.length > 0) {
            // Find the largest amount which is likely the transaction amount
            const amounts = amountMatches.map(a => parseFloat(a.replace(',', '')));
            parsedAmount = Math.max(...amounts);
        }

        outputDiv.innerHTML = `
            <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); margin-top: 15px;">
                <div style="font-weight: 800; font-size: 1rem; color: #10b981; margin-bottom: 10px;">📋 OCR Slip Extracted Details:</div>
                <div style="margin-bottom: 8px;">
                    <span style="color:#94a3b8; font-size:0.8rem; font-weight:700;">TRANSACTION REFERENCE:</span>
                    <div id="ocr-extracted-ref" style="font-size:1.2rem; font-weight:900; color:#38bdf8; font-family:monospace;">${refNo}</div>
                </div>
                <div style="margin-bottom: 12px;">
                    <span style="color:#94a3b8; font-size:0.8rem; font-weight:700;">TOTAL AMOUNT INFERRED:</span>
                    <div id="ocr-extracted-amount" style="font-size:1.4rem; font-weight:900; color:#10b981;">LKR ${parsedAmount.toFixed(2)}</div>
                </div>
                <button onclick="window.matchSlipWithStatement('${refNo}', ${parsedAmount})" class="action-btn primary" style="width:100%; font-weight:900;">Link Slip to Bank Ledger</button>
            </div>
        `;
    } catch (err) {
        console.error("OCR Error:", err);
        outputDiv.innerHTML = `<p style="color:#ef4444; text-align:center;">❌ Failed to parse image. Try upload a clearer image.</p>`;
    }
};

window.matchSlipWithStatement = async (refNo, amount) => {
    if (refNo === 'Not Found' || !amount) {
        window.showToast("⚠️ Invalid slip details to match.", "warning");
        return;
    }

    const txs = window.allBankTransactions || [];
    // Match based on either reference number or exact amount
    const match = txs.find(t => t.referenceNo === refNo || (Math.abs(t.amount - amount) < 1.0 && !t.isReconciled));

    if (match) {
        const txRef = doc(db, 'bank_transactions', match.docId);
        await updateDoc(txRef, {
            isReconciled: true,
            referenceNo: refNo
        });

        // Add to bank balance
        const accRef = doc(db, 'bank_accounts', match.accountId);
        const acc = window.allBankAccounts.find(a => a.docId === match.accountId);
        if (acc) {
            await updateDoc(accRef, { balance: (acc.balance || 0) + match.amount });
        }

        window.showToast("✅ Slip matched and bank transaction verified!", "success");
        document.getElementById('deposit-slip-modal').style.display = 'none';
        document.getElementById('slip-image').value = '';
        document.getElementById('slip-ocr-results').innerHTML = '';
    } else {
        window.showToast("⚠️ Slip details recorded, but no matching bank statement record found yet.", "warning");
    }
};
