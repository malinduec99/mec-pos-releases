import { db } from '../firebase.js';
import { 
    doc, 
    updateDoc, 
    deleteDoc, 
    addDoc, 
    collection, 
    writeBatch,
    serverTimestamp,
    onSnapshot,
    query,
    where,
    getDocs,
    Timestamp
} from "firebase/firestore";

const repairJobsCol = collection(db, 'repairJobs');
const ordersCol = collection(db, 'orders');

export function initRepairs() {
    window.currentRepairFilter = 'New';
    
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    threeMonthsAgo.setHours(0,0,0,0);
    const threeMonthsAgoTimestamp = Timestamp.fromDate(threeMonthsAgo);
    
    const qRepairs = isMaster ?
        query(repairJobsCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(repairJobsCol, where('storeId', '==', storeId));
    onSnapshot(qRepairs, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const jobs = isMaster ? raw : raw.filter(j => j.timestamp && j.timestamp.seconds >= threeMonthsAgoTimestamp.seconds);
        window.allRepairJobs = jobs;
        if (window.currentActiveTab === 'repairs') {
            requestAnimationFrame(() => window.renderRepairJobsUI(jobs));
        }
    });

    // Add search listener for Repair Intake customer autocomplete
    setTimeout(() => {
        const nameInput = document.getElementById('rep-cust-name');
        const phoneInput = document.getElementById('rep-cust-phone');
        if (nameInput && phoneInput) {
            nameInput.addEventListener('input', () => {
                const val = nameInput.value.trim().toLowerCase();
                if (!val) return;
                const match = (window.allCustomers || []).find(c => (c.name || '').trim().toLowerCase() === val);
                if (match && match.phone) {
                    phoneInput.value = match.phone;
                }
            });
            phoneInput.addEventListener('input', () => {
                const val = phoneInput.value.trim().toLowerCase();
                if (!val) return;
                const match = (window.allCustomers || []).find(c => (c.phone || '').trim().toLowerCase() === val);
                if (match && match.name) {
                    nameInput.value = match.name;
                }
            });
        }
    }, 1000);
}

window.filterRepairsByStatus = (status) => {
    window.currentRepairFilter = status;
    
    // UI Update for buttons
    const buttons = document.querySelectorAll('#section-repairs .sub-tab');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    const activeBtnId = `btn-rep-${status.toLowerCase()}`;
    const activeBtn = document.getElementById(activeBtnId);
    if (activeBtn) activeBtn.classList.add('active');
    
    window.renderRepairJobsUI(window.allRepairJobs);
};

window.filterRepairOrdersSearch = (val) => {
    window.repairSearchQuery = (val || '').toLowerCase().trim();
    window.renderRepairJobsUI(window.allRepairJobs);
};

window.renderRepairJobsUI = (jobs) => {
    window.allRepairJobs = jobs; // Store globally for billing search
    const tableBody = document.getElementById('admin-repairs-list');
    if (!tableBody) return;
    const storeId = window.getStoreId();
    const filter = window.currentRepairFilter || 'All';
    const search = window.repairSearchQuery || '';

    const userBranch = sessionStorage.getItem('userBranchId');
    const activeBranch = window.activeBranchFilter || (userBranch && userBranch !== 'Global' ? userBranch : 'All');

    tableBody.innerHTML = jobs
        .filter(j => !j.storeId || j.storeId === storeId || storeId === 'master')
        .filter(j => {
            // Branch Isolation Filter
            if (activeBranch && activeBranch !== 'All') {
                const isTargetHorana = activeBranch === 'main' || activeBranch === 'Global' || activeBranch.toLowerCase().includes('horana');
                const jobBranchId = (j.branchId || 'main').toLowerCase();
                const isJobPanadura = jobBranchId.includes('panadura') || jobBranchId === 'j8lsw5vrjwmssc630dh0';

                if (isTargetHorana) {
                    if (isJobPanadura) return false;
                } else if (activeBranch.toLowerCase().includes('panadura') || activeBranch === 'j8lSW5VrJWmSsc630dH0') {
                    if (!isJobPanadura) return false;
                } else {
                    if (jobBranchId !== activeBranch.toLowerCase()) return false;
                }
            }
            return true;
        })
        .filter(j => {
            // If there's an active search query, bypass status filter so they can find it globally
            if (search) return true;
            return filter === 'All' || j.status === filter;
        })
        .filter(j => {
            if (!search) return true;
            const name = (j.customerName || '').toLowerCase();
            const phone = (j.customerPhone || '').toLowerCase();
            const jobId = (j.jobId || '').toLowerCase();
            return name.includes(search) || phone.includes(search) || jobId.includes(search);
        })
        .sort((a,b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0))
        .map(job => {
            const status = job.status || 'New';
            const statusColor = status === 'New' ? '#10b981' : (status === 'Processing' ? '#3b82f6' : (status === 'Completed' ? '#8b5cf6' : (status === 'Cancelled' ? '#ef4444' : '#64748b')));
            const isDelivered = status === 'Delivered';

            const billedItems = job.billedItems || [];
            const billValue = billedItems.length > 0 
                ? billedItems.reduce((sum, i) => sum + (Number(i.price || 0) * Number(i.quantity || 1)), 0)
                : Number(job.estimatedCost || job.estimated || 0);

            return `
            <tr>
                <td onclick="window.viewRepairDetails('${job.docId}')" style="font-weight:bold; color:var(--primary-blue); cursor:pointer; text-decoration: underline;">${job.jobId}</td>
                <td>${job.timestamp ? (typeof job.timestamp.toDate === 'function' ? job.timestamp.toDate() : new Date(job.timestamp.seconds * 1000)).toLocaleDateString() : ''}</td>
                <td>${job.customerName || 'N/A'}</td>
                <td>${job.customerPhone || 'N/A'}</td>
                <td>${job.itemDescription || 'N/A'}</td>
                <td>
                    <div style="display:flex; flex-direction:column; gap:2px;">
                        <span style="display:inline-block; max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${job.issue || 'N/A'}</span>
                        <span style="font-size:0.7rem; font-weight:700; color:${statusColor};">${status}</span>
                    </div>
                </td>
                <td style="font-weight:bold; color:#38bdf8;">LKR ${billValue.toFixed(2)}</td>
                <td style="text-align: right; display: flex; gap: 8px; justify-content: flex-end; align-items: center;">
                    ${isDelivered ? 
                        `<button class="action-btn" onclick="window.openModernInvoice('${job.associatedOrderId || job.orderId || job.jobId}')" style="padding: 4px 10px; font-size: 0.7rem; background: #10b981; color: white; border-radius: 6px;">📄 View Bill</button>
                         <button class="action-btn" onclick="window.voidAndReverseRepair('${job.docId}')" style="padding: 4px 10px; font-size: 0.7rem; background: #ef4444; color: white; border-radius: 6px;">🔄 Void & Reverse</button>` : 
                        (status === 'New' || status === 'Cancelled' ? '' : `
                            <button class="action-btn" onclick="window.openRepairBilling('${job.docId}')" style="padding: 4px 10px; font-size: 0.7rem; background: #002060; color: white; border-radius: 6px;">💳 Bill</button>
                            ${status === 'Completed' ? `<button class="action-btn" onclick="window.payAndDeliverRepair('${job.docId}')" style="padding: 4px 10px; font-size: 0.7rem; background: #10b981; color: white; border-radius: 6px;">🚚 Deliver</button>` : ''}
                        `)
                    }
                    <button class="action-btn" onclick="window.printRepairJobCard('${job.docId}')" style="padding: 4px 10px; font-size: 0.7rem; background: #7c3aed; color: white; border-radius: 6px;">🖨️ Print</button>
                    ${(status === 'New' || status === 'Processing') ? `
                        <select onchange="window.updateRepairStatus('${job.docId}', this.value)" style="padding: 4px; font-size: 0.7rem; border-radius: 6px; border: 1px solid #e2e8f0; background: #f8fafc; font-weight: 600; cursor: pointer;">
                            ${status === 'New' ? `
                                <option value="New" selected>New</option>
                                <option value="Processing">Processing</option>
                                <option value="Cancelled">Cancelled</option>
                            ` : `
                                <option value="Processing" selected>Processing</option>
                                <option value="Cancelled">Cancelled</option>
                            `}
                        </select>
                    ` : `
                        <span style="font-size: 0.7rem; font-weight: 700; color: ${statusColor}; background: rgba(255,255,255,0.05); padding: 4px 10px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.1);">${status}</span>
                    `}
                    ${!isDelivered ? `<button class="icon-btn delete" onclick="window.confirmDeleteRepair('${job.docId}')" style="width: 28px; height: 28px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 10px;">🗑️</button>` : ''}
                </td>
            </tr>
        `}).join('');
};

// ─── Print Repair Job Card / Invoice ───────────────────────────────────────────
window.printRepairJobCard = (docId) => {
    const job = (window.allRepairJobs || []).find(j => j.docId === docId);
    if (!job) { window.showToast('Repair job not found.', 'warning'); return; }

    const biz = window.systemConfig?.bizName || window.storeInfo?.name || 'MEC Book Shop';
    const bizAddress = window.systemConfig?.address || window.storeInfo?.address || '';
    const bizPhone = window.systemConfig?.phone || window.storeInfo?.phone || '';

    const status = job.status || 'New';
    const statusColor = status === 'New' ? '#10b981' : (status === 'Processing' ? '#3b82f6' : (status === 'Completed' ? '#8b5cf6' : (status === 'Delivered' ? '#0ea5e9' : (status === 'Cancelled' ? '#ef4444' : '#64748b'))));

    const billedItems = job.billedItems || [];
    const billValue = billedItems.length > 0
        ? billedItems.reduce((sum, i) => sum + (Number(i.price || 0) * Number(i.quantity || 1)), 0)
        : Number(job.estimatedCost || job.estimated || 0);

    const dateStr = job.timestamp
        ? (typeof job.timestamp.toDate === 'function' ? job.timestamp.toDate() : new Date(job.timestamp.seconds * 1000)).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' })
        : new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });

    const itemsHtml = billedItems.length > 0 ? billedItems.map((item, idx) => `
        <tr style="border-bottom: 1px solid #f1f5f9;">
            <td style="padding: 8px 10px; font-size: 0.85rem;">${idx + 1}</td>
            <td style="padding: 8px 10px; font-size: 0.85rem;">${item.name || item.description || 'Service'}</td>
            <td style="padding: 8px 10px; font-size: 0.85rem; text-align: center;">${item.quantity || 1}</td>
            <td style="padding: 8px 10px; font-size: 0.85rem; text-align: right;">LKR ${Number(item.price || 0).toFixed(2)}</td>
            <td style="padding: 8px 10px; font-size: 0.85rem; text-align: right; font-weight: 700;">LKR ${(Number(item.price || 0) * Number(item.quantity || 1)).toFixed(2)}</td>
        </tr>`).join('') : `
        <tr><td colspan="5" style="padding: 12px 10px; font-size: 0.85rem; color: #64748b; text-align: center;">No items billed yet — Estimated: LKR ${billValue.toFixed(2)}</td></tr>`;

    const printHTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Repair Invoice — ${job.jobId}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', Arial, sans-serif; background: #fff; color: #1e293b; padding: 24px; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; border-bottom: 3px solid #002060; padding-bottom: 16px; }
  .biz-name { font-size: 1.5rem; font-weight: 900; color: #002060; }
  .biz-sub { font-size: 0.75rem; color: #64748b; margin-top: 3px; }
  .invoice-title { text-align: right; }
  .invoice-title h2 { font-size: 1.3rem; font-weight: 900; color: #7c3aed; }
  .invoice-title .job-id { font-size: 1rem; font-weight: 700; color: #002060; }
  .status-badge { display: inline-block; padding: 3px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; color: white; background: ${statusColor}; margin-top: 6px; }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
  .info-box { background: #f8fafc; border-radius: 8px; padding: 12px 14px; border: 1px solid #e2e8f0; }
  .info-box label { font-size: 0.65rem; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; display: block; margin-bottom: 4px; }
  .info-box span { font-size: 0.9rem; font-weight: 700; color: #1e293b; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
  thead tr { background: #002060; color: white; }
  thead th { padding: 10px; font-size: 0.78rem; text-align: left; }
  thead th:last-child, thead th:nth-child(4) { text-align: right; }
  thead th:nth-child(3) { text-align: center; }
  .total-row { background: #f0f4ff; }
  .total-row td { padding: 10px; font-weight: 900; font-size: 0.95rem; }
  .footer { margin-top: 24px; text-align: center; font-size: 0.75rem; color: #94a3b8; border-top: 1px dashed #e2e8f0; padding-top: 12px; }
  .notes-box { background: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; font-size: 0.83rem; }
  .notes-box strong { color: #92400e; }
  @media print { body { padding: 10px; } button { display: none !important; } }
</style>
</head>
<body>
<div class="header">
    <div>
        <div class="biz-name">${biz}</div>
        <div class="biz-sub">${bizAddress}${bizAddress && bizPhone ? ' &nbsp;|&nbsp; ' : ''}${bizPhone}</div>
    </div>
    <div class="invoice-title">
        <h2>🔧 Repair Invoice</h2>
        <div class="job-id">${job.jobId}</div>
        <div class="status-badge">${status}</div>
    </div>
</div>

<div class="info-grid">
    <div class="info-box">
        <label>Customer Name</label>
        <span>${job.customerName || 'N/A'}</span>
    </div>
    <div class="info-box">
        <label>Phone</label>
        <span>${job.customerPhone || 'N/A'}</span>
    </div>
    <div class="info-box">
        <label>Item / Device</label>
        <span>${job.itemDescription || 'N/A'}</span>
    </div>
    <div class="info-box">
        <label>Date Received</label>
        <span>${dateStr}</span>
    </div>
    <div class="info-box" style="grid-column: 1 / -1;">
        <label>Issue Reported</label>
        <span>${job.issue || 'N/A'}</span>
    </div>
    ${job.technicianNotes ? `
    <div class="info-box" style="grid-column: 1 / -1;">
        <label>Technician Notes</label>
        <span>${job.technicianNotes}</span>
    </div>` : ''}
</div>

${job.notes ? `<div class="notes-box"><strong>📝 Notes:</strong> ${job.notes}</div>` : ''}

<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Description</th>
            <th style="text-align:center;">Qty</th>
            <th style="text-align:right;">Unit Price</th>
            <th style="text-align:right;">Total</th>
        </tr>
    </thead>
    <tbody>
        ${itemsHtml}
    </tbody>
    <tfoot>
        <tr class="total-row">
            <td colspan="4" style="text-align:right; color:#002060;">TOTAL AMOUNT</td>
            <td style="text-align:right; color:#002060;">LKR ${billValue.toFixed(2)}</td>
        </tr>
    </tfoot>
</table>

<div class="footer">
    <p>Thank you for trusting us with your repair! &nbsp;|&nbsp; ${biz}</p>
    <p style="margin-top:4px;">Printed on ${new Date().toLocaleString('en-GB')}</p>
</div>

<script>window.onload = () => { window.print(); };<\/script>
</body>
</html>`;

    // Use a hidden iframe instead of window.open to prevent WebView2 popups
    let iframe = document.getElementById('repair-print-iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'repair-print-iframe';
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);
    }

    const doc = iframe.contentWindow.document || iframe.contentDocument;
    doc.open();
    doc.write(printHTML);
    doc.close();

    // Trigger print from the iframe after load
    setTimeout(() => {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
    }, 500);
};

window.sendRepairCompletionSMSPrompt = async (job, balance) => {
    if (!job || !job.customerPhone) return;
    const balanceNum = Number(balance || 0);
    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const defaultMsg = `Dear ${job.customerName || 'Customer'}, your repair job ${job.jobId} (${job.itemDescription || 'item'}) is completed & ready for pickup. Bal: LKR ${balanceNum.toFixed(2)}. Thank you! - ${bizName}`;
    
    if (await window.showCustomConfirm(`Send Completion SMS to customer?\n\n"${defaultMsg}"`, "Send SMS", "✉️", "Send SMS", "Cancel")) {
        if (typeof window.dispatchSMS === 'function') {
            await window.dispatchSMS(job.customerPhone, defaultMsg);
        } else {
            window.showToast("SMS engine not initialized.", "error");
        }
    }
};

window.updateRepairStatus = async (docId, newStatus) => {
    try {
        const job = (window.allRepairJobs || []).find(j => j.docId === docId);
        if (!job) return;

        // Block changing to Completed or Delivered if there is no associated bill
        if ((newStatus === 'Completed' || newStatus === 'Delivered') && !job.associatedOrderId) {
            window.showToast("⚠️ Cannot mark as Completed/Delivered without creating a bill first!", "error");
            if (window.renderRepairJobsUI) window.renderRepairJobsUI(window.allRepairJobs);
            return;
        }

        // Block manual status change to Delivered if it is Completed
        if (newStatus === 'Delivered' && job.status === 'Completed') {
            window.showToast("⚠️ Please use the 'Pay & Deliver' button to finalize payment and deliver this repair!", "warning");
            if (window.renderRepairJobsUI) window.renderRepairJobsUI(window.allRepairJobs);
            return;
        }

        // Supervisor authorization required to cancel
        if (newStatus === 'Cancelled') {
            const auth = await window.asyncAuthPrompt("Supervisor authorization required to cancel this repair job.", "Security Verification");
            if (!auth) {
                window.showToast("❌ Cancellation aborted.", "info");
                if (window.renderRepairJobsUI) window.renderRepairJobsUI(window.allRepairJobs);
                return;
            }

            const isSuperAdmin = (auth.user.toLowerCase() === 'malinduec@gmail.com' && auth.pass === 'malindu123') ||
                                 (auth.user.toLowerCase() === 'mecposadmin@gmail.com' && auth.pass === 'mecpos123');
            const isMecCeo = (auth.user.toLowerCase() === 'mecbookshop@gmail.com' && auth.pass === 'mec123');
            const isDJCeo = (auth.user.toLowerCase() === 'ireshadinali@gmail.com' && auth.pass === 'ireshadinali123');
            const isManager = (auth.pass === 'mec123');

            if (!isSuperAdmin && !isMecCeo && !isDJCeo && !isManager) {
                window.showToast("❌ Unauthorized Credentials!", "error");
                if (window.renderRepairJobsUI) window.renderRepairJobsUI(window.allRepairJobs);
                return;
            }
        }

        await updateDoc(doc(db, 'repairJobs', docId), { status: newStatus });
        window.showToast(`Repair status updated to ${newStatus}`, "success");

        if (newStatus === 'Completed') {
            const job = (window.allRepairJobs || []).find(j => j.docId === docId);
            if (job && job.customerPhone) {
                const balance = Number(job.balanceDue || 0);
                await window.sendRepairCompletionSMSPrompt(job, balance);
            }
        }
    } catch (e) {
        console.error(e);
        window.showToast("Error updating status", "error");
    }
};

window.confirmDeleteRepair = async (docId) => {
    const docRef = doc(db, 'repairJobs', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'Cancelled', isVoid: true })) return;
    
    try {
        await deleteDoc(docRef);
        window.showToast("Repair record deleted.", "info");
    } catch (e) { 
        console.error(e);
        window.showToast("Error deleting record", "error");
    }
};

window.searchPartsForRepair = (val) => {
    const resultsDiv = document.getElementById('bill-rep-part-results');
    const gridDiv = document.getElementById('repair-pos-products-grid');
    
    if (!val || val.length < 1) { 
        if (resultsDiv) resultsDiv.style.display = 'none';
        window.renderRepairPartsGrid();
        return; 
    }

    const q = val.toLowerCase();
    const products = window.allProducts || [];
    const filtered = products.filter(p => {
        // Only show parts that are either Shop/Store or Technical (Repair) mode
        if (p.mode === 'Service' || p.mode === 'Warehouse') return false;
        
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return (p.name && p.name.toLowerCase().includes(q)) || 
               window.matchProductSku(p.sku, q) || 
               matchesVariantSku ||
               (p.barcode && p.barcode.includes(q));
    }).slice(0, 20);

    if (gridDiv) {
        gridDiv.innerHTML = filtered.map(p => `
            <div onclick="window.addPartToRepairBill('${p.docId}')" 
                 style="background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 12px; padding: 10px; cursor: pointer; display: flex; flex-direction: column; justify-content: space-between; min-height: 80px; transition: 0.15s; position: relative; overflow: hidden;"
                 onmouseover="this.style.background='rgba(56, 189, 248, 0.1)'; this.style.borderColor='rgba(56, 189, 248, 0.4)';"
                 onmouseout="this.style.background='rgba(15, 23, 42, 0.8)'; this.style.borderColor='rgba(56, 189, 248, 0.2)';"
            >
                <div style="font-weight: 700; color: white; font-size: 0.8rem; margin-bottom: 5px; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${p.name}</div>
                <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: auto;">
                    <div style="color: #38bdf8; font-weight: 900; font-size: 0.9rem;">Rs.${p.price.toLocaleString()}</div>
                    <div style="background: ${(p.stock || 0) > 0 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)'}; color: ${(p.stock || 0) > 0 ? '#10b981' : '#ef4444'}; padding: 2px 6px; border-radius: 4px; font-size: 0.65rem; font-weight: 800;">${p.stock || 0}</div>
                </div>
            </div>
        `).join('');
    }
    if (resultsDiv) resultsDiv.style.display = 'none';
};

window.renderRepairPartsGrid = () => {
    const grid = document.getElementById('repair-pos-products-grid');
    if (!grid) return;
    
    const products = window.allProducts || [];
    const availableParts = products
        .filter(p => {
            // Hide Service and Warehouse items from repair grid
            if (p.mode === 'Service' || p.mode === 'Warehouse') return false;
            return parseFloat(p.price) > 0;
        })
        .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
        
    grid.innerHTML = availableParts.map(p => `
        <div onclick="window.addPartToRepairBill('${p.docId}')" 
             style="background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 12px; padding: 10px; cursor: pointer; display: flex; flex-direction: column; justify-content: space-between; min-height: 80px; transition: 0.15s; position: relative; overflow: hidden;">
            <div style="font-weight: 700; color: white; font-size: 0.8rem; margin-bottom: 5px; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${p.name}</div>
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: auto;">
                <div style="color: #38bdf8; font-weight: 900; font-size: 0.9rem;">Rs.${p.price.toLocaleString()}</div>
                <div style="background: ${(p.stock || 0) > 0 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)'}; color: ${(p.stock || 0) > 0 ? '#10b981' : '#ef4444'}; padding: 2px 6px; border-radius: 4px; font-size: 0.65rem; font-weight: 800;">${p.stock || 0}</div>
            </div>
        </div>
    `).join('');
};

window.addPartToRepairBill = (docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;

    // Open Quick Add Modal
    const modal = document.getElementById('repair-quick-add-modal');
    const nameEl = document.getElementById('quick-add-item-name');
    const qtyInput = document.getElementById('quick-add-qty');
    const discountInput = document.getElementById('quick-add-discount');
    const confirmBtn = document.getElementById('quick-add-confirm-btn');

    if (!modal || !nameEl || !qtyInput || !discountInput) return;

    nameEl.innerText = p.name.toUpperCase();
    qtyInput.value = 1;
    discountInput.value = 0;
    
    window._currentQuickAddPart = p;
    window.updateQuickAddPreview();

    confirmBtn.onclick = () => {
        const qty = parseInt(qtyInput.value) || 1;
        const discount = parseFloat(discountInput.value) || 0;
        
        window.executeAddPartToRepairBill(p, qty, discount);
        modal.style.display = 'none';
    };

    modal.style.display = 'flex';
};

window.updateQuickAddPreview = () => {
    const p = window._currentQuickAddPart;
    if (!p) return;
    const discount = parseFloat(document.getElementById('quick-add-discount').value) || 0;
    const finalPrice = Math.max(0, p.price - discount);
    document.getElementById('quick-add-final-price').innerText = "Rs. " + finalPrice.toLocaleString();
};

window.executeAddPartToRepairBill = (p, qty, discount) => {
    const list = document.getElementById('bill-rep-parts-list');
    const emptyNotif = document.getElementById('repair-empty-list-notif');
    if (!list) return;

    if (emptyNotif) emptyNotif.style.display = 'none';

    // Check if already exists (with same discount)
    const existingRow = Array.from(list.querySelectorAll('tr')).find(r => 
        r.dataset.docId === p.docId && parseFloat(r.dataset.discount || 0) === discount
    );

    if (existingRow) {
        const qtyEl = existingRow.querySelector('.qty-val');
        const totalEl = existingRow.querySelector('.total-val');
        let currentQty = parseInt(existingRow.dataset.quantity) || 1;
        currentQty += qty;
        qtyEl.innerText = currentQty;
        existingRow.dataset.quantity = currentQty;
        
        const price = parseFloat(existingRow.dataset.price);
        const disc = parseFloat(existingRow.dataset.discount || 0);
        totalEl.innerText = "Rs. " + ((price - disc) * currentQty).toLocaleString();
        
        window.updateRepairTotal();
        window.showToast(`Updated ${p.name} quantity to ${currentQty}`, "info");
    } else {
        const tr = document.createElement('tr');
        tr.style = "border-bottom: 1px solid rgba(255, 255, 255, 0.05); animation: slideIn 0.3s ease-out; cursor: pointer; transition: 0.2s;";
        tr.dataset.docId = p.docId;
        tr.dataset.price = p.price;
        tr.dataset.name = p.name;
        tr.dataset.quantity = qty;
        tr.dataset.discount = discount;

        const finalUnitPrice = p.price - discount;
        
        tr.innerHTML = `
            <td style="padding: 15px 10px;">
                <div style="font-weight: 700; color: white;">${p.name}</div>
                <div style="font-size: 0.7rem; color: #64748b;">${p.sku || 'No SKU'} ${discount > 0 ? `<span style="color: #ef4444; font-weight: 800;">(DISC: Rs. ${discount})</span>` : ''}</div>
            </td>
            <td style="padding: 15px 10px; text-align: center; color: #38bdf8; font-weight: 900;" class="qty-val">${qty}</td>
            <td style="padding: 15px 10px; text-align: right; font-weight: 600; color: #94a3b8;">${finalUnitPrice.toLocaleString()}</td>
            <td style="padding: 15px 10px; text-align: right; font-weight: 800; color: #10b981;" class="total-val">Rs. ${(finalUnitPrice * qty).toLocaleString()}</td>
            <td style="padding: 15px 10px; text-align: center;">
                <button onclick="event.stopPropagation(); this.closest('tr').remove(); window.updateRepairTotal(); if(document.querySelectorAll('#bill-rep-parts-list tr').length === 0) document.getElementById('repair-empty-list-notif').style.display='block';" 
                        style="background: rgba(239, 68, 68, 0.1); border: none; color: #ef4444; width: 28px; height: 28px; border-radius: 6px; cursor: pointer; transition: 0.2s;">✕</button>
            </td>
        `;
        list.appendChild(tr);
        window.showToast("🛠️ Part added to bill", "info");
    }

    const searchInput = document.getElementById('bill-rep-part-search');
    if (searchInput) searchInput.value = '';
    const searchResults = document.getElementById('bill-rep-part-results');
    if (searchResults) searchResults.style.display = 'none';
    window.updateRepairTotal();
};

window.updateRepairTotal = () => {
    const serviceCharge = parseFloat(document.getElementById('bill-rep-service-charge').value) || 0;
    const advance = parseFloat(document.getElementById('bill-rep-advance').value) || 0;
    const tendered = parseFloat(document.getElementById('bill-rep-tendered').value) || 0;
    
    let partsTotal = 0;
    const parts = document.querySelectorAll('#bill-rep-parts-list tr');
    parts.forEach(tr => {
        const qty = parseInt(tr.dataset.quantity) || 1;
        const price = parseFloat(tr.dataset.price) || 0;
        const disc = parseFloat(tr.dataset.discount) || 0;
        partsTotal += (price - disc) * qty;
    });

    const subtotal = serviceCharge + partsTotal;
    const total = subtotal - advance;
    const change = Math.max(0, tendered - total);

    const estimated = window.currentBillingRepairEstimatedCost || 0;
    const estEl = document.getElementById('bill-rep-estimated-display');
    if (estEl) {
        estEl.innerText = "Rs. " + estimated.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }

    if (document.getElementById('bill-rep-subtotal')) {
        document.getElementById('bill-rep-subtotal').innerText = "Rs. " + subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }
    if (document.getElementById('bill-rep-advance-display')) {
        document.getElementById('bill-rep-advance-display').innerText = "Rs. " + advance.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }
    
    const totalEl = document.getElementById('bill-rep-total');
    if (totalEl) {
        totalEl.innerText = total.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }
    
    if (document.getElementById('bill-rep-change')) {
        document.getElementById('bill-rep-change').innerText = change.toLocaleString(undefined, { minimumFractionDigits: 2 });
    }
};

window.clearRepairBill = async () => {
    if (await window.showCustomConfirm("⚠️ Clear all parts and reset charges for this repair bill?", "Clear Repair Bill", "⚠️", "Clear Bill", "Cancel")) {
        const list = document.getElementById('bill-rep-parts-list');
        if (list) list.innerHTML = '';
        
        const serviceInput = document.getElementById('bill-rep-service-charge');
        if (serviceInput) serviceInput.value = 0;
        
        const tenderedInput = document.getElementById('bill-rep-tendered');
        if (tenderedInput) tenderedInput.value = '';
        
        const emptyNotif = document.getElementById('repair-empty-list-notif');
        if (emptyNotif) emptyNotif.style.display = 'block';
        
        window.updateRepairTotal();
        window.showToast("🔄 Bill Cleared", "info");
    }
};

window.registerRepairCustomer = async () => {
    const name = document.getElementById('reg-rel-cust-name').value.trim();
    const phone = document.getElementById('reg-rel-cust-phone').value.trim();
    const type = document.getElementById('reg-rel-cust-type').value;

    if (!name) {
        window.showToast("Please enter customer name!", "error");
        return;
    }

    try {
        window.showToast("🚀 Registering Master Customer...", "info");
        
        const custs = window.allCustomers || [];
        let generatedId = '';
        if (type === 'wholesale') {
            const cCount = custs.filter(c => c.customerType === 'wholesale').length;
            generatedId = 'WHO-' + String(cCount + 1).padStart(3, '0');
        } else {
            const cCount = custs.filter(c => c.customerType !== 'wholesale').length;
            generatedId = 'LO-' + String(cCount + 1).padStart(3, '0');
        }

        const newCust = {
            name, 
            phone, 
            loyaltyCardNo: generatedId,
            customerType: type,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp(),
            outstanding: 0
        };

        const docRef = await addDoc(collection(db, 'customers'), newCust);
        window.showToast("✅ Customer Registered!", "success");
        
        document.getElementById('pos-reload-cust-modal').style.display = 'none';
        
        // Update allCustomers cache
        if (window.allCustomers) {
            window.allCustomers.push({ ...newCust, docId: docRef.id });
        }
        
        // Finalize the sale now
        window.finalizeRepairPOSSale();
        
    } catch (err) {
        console.error("Reg Error:", err);
        window.showToast("❌ Registration Failed", "error");
    }
};

window.openRepairBilling = async (docId) => {
    console.log("🚀 TRIGGER: opening billing for", docId);
    const jobs = window.allRepairJobs || [];
    const job = jobs.find(j => j.docId === docId);
    
    if (!job) {
        window.showToast("❌ Data Error: Job details lost. Try refreshing.", "error");
        return;
    }

    if (job.status === 'Completed' || job.associatedOrderId || (job.billedItems && job.billedItems.length > 0)) {
        window.openRepairQuickDeliveryModal(docId);
        return;
    }

    // Reset Terminal Clock
    if(window.repairClockInterval) clearInterval(window.repairClockInterval);
    window.repairClockInterval = setInterval(() => {
        const clockEl = document.getElementById('bill-rep-terminal-clock');
        if(clockEl) clockEl.innerText = new Date().toLocaleTimeString();
    }, 1000);
    const clockEl = document.getElementById('bill-rep-terminal-clock');
    if(clockEl) clockEl.innerText = new Date().toLocaleTimeString();

    // Populate Header Info Bar
    const jobIdEl = document.getElementById('repair-pos-job-id');
    const custNameEl = document.getElementById('repair-pos-cust-name');
    const custPhoneEl = document.getElementById('repair-pos-cust-phone');
    const itemDescEl = document.getElementById('repair-pos-item-desc');

    if (jobIdEl) jobIdEl.innerText = `#${job.jobId || 'UNKNOWN'}`;
    const customer = (window.allCustomers || []).find(c => c.phone === job.customerPhone);
    if (custNameEl) {
        const badge = customer 
            ? `<span style="font-size: 0.6rem; background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); padding: 2px 8px; border-radius: 6px; font-weight: 800; text-transform: uppercase;">MASTER</span>`
            : `<span style="font-size: 0.6rem; background: rgba(245, 158, 11, 0.1); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3); padding: 2px 8px; border-radius: 6px; font-weight: 800; text-transform: uppercase;">WALK-IN</span>`;
        custNameEl.innerHTML = `<span>${(job.customerName || 'N/A').toUpperCase()}</span> ${badge}`;
    }
    if (custPhoneEl) custPhoneEl.innerText = job.customerPhone || 'N/A';
    if (itemDescEl) {
        const item = job.itemDescription || job.deviceName || 'DEVICE';
        const problem = job.issue || job.description || 'NO DESCRIPTION';
        itemDescEl.innerText = `${item.toUpperCase()} - ${problem.toUpperCase()}`;
    }

    window.currentBillingRepairId = docId;
    
    // Clear cart
    const list = document.getElementById('bill-rep-parts-list');
    if (list) list.innerHTML = '';
    const emptyNotif = document.getElementById('repair-empty-list-notif');
    if (emptyNotif) emptyNotif.style.display = 'block';

    window.currentBillingRepairEstimatedCost = parseFloat(job.estimatedCost) || 0;
    let order = null;
    let serviceCharge = 0; // Default to 0, do not add estimatedCost to service charge
    let advance = parseFloat(job.advance || job.advancePayment) || 0;

    if (job.billedItems && job.billedItems.length > 0) {
        const scItem = job.billedItems.find(i => i.docId === 'service_charge');
        if (scItem) serviceCharge = scItem.price;

        const parts = job.billedItems.filter(i => i.docId !== 'service_charge');
        parts.forEach(item => {
            const prod = (window.allProducts || []).find(p => p.docId === item.docId) || {
                docId: item.docId,
                name: item.name,
                price: item.price,
                sku: item.sku || ''
            };
            window.executeAddPartToRepairBill(prod, item.quantity, 0);
        });
    } else {
        order = (window.allOrders || []).find(o => 
            (job.associatedOrderId && o.orderId === job.associatedOrderId) || 
            (job.jobId && o.repairJobId === job.jobId)
        );
        if (!order && job.associatedOrderId) {
            try {
                const q = query(ordersCol, where('orderId', '==', job.associatedOrderId));
                const snap = await getDocs(q);
                if (!snap.empty) {
                    order = { ...snap.docs[0].data(), docId: snap.docs[0].id };
                }
            } catch (e) {
                console.error("Error fetching order by associatedOrderId:", e);
            }
        }
        if (!order && job.jobId) {
            try {
                const q = query(ordersCol, where('repairJobId', '==', job.jobId));
                const snap = await getDocs(q);
                if (!snap.empty) {
                    order = { ...snap.docs[0].data(), docId: snap.docs[0].id };
                }
            } catch (e) {
                console.error("Error fetching order by jobId:", e);
            }
        }

        if (order) {
            // Load items from order
            const scItem = order.items.find(i => i.docId === 'service_charge');
            if (scItem) serviceCharge = scItem.price;

            const parts = order.items.filter(i => i.docId !== 'service_charge');
            parts.forEach(item => {
                const prod = (window.allProducts || []).find(p => p.docId === item.docId) || {
                    docId: item.docId,
                    name: item.name,
                    price: item.price,
                    sku: item.sku || ''
                };
                window.executeAddPartToRepairBill(prod, item.quantity, 0);
            });
        }
    }

    document.getElementById('bill-rep-service-charge').value = serviceCharge;
    document.getElementById('bill-rep-advance').value = advance;
    const advDisp = document.getElementById('bill-rep-advance-display');
    if (advDisp) advDisp.innerText = `Rs. ${advance.toLocaleString()}`;
    const estDisp = document.getElementById('bill-rep-estimated-display');
    if (estDisp) {
        const estimated = parseFloat(job.estimatedCost) || 0;
        estDisp.innerText = `Rs. ${estimated.toLocaleString()}`;
    }
    
    // Render the parts grid
    if (typeof window.renderRepairPartsGrid === 'function') {
        window.renderRepairPartsGrid();
    }
    
    window.updateRepairTotal();

    // Update complete button text and handler (always COMPLETE (F8) for this screen)
    const completeBtn = document.querySelector('button[onclick*="handleRepairCompleteClick"]');
    if (completeBtn) {
        completeBtn.innerHTML = '<span>COMPLETE (F8)</span>';
        completeBtn.setAttribute('onclick', 'window.handleRepairCompleteClick()');
    }
    
    const modal = document.getElementById('repair-billing-modal');
    if (modal) {
        modal.classList.add('active');
        document.body.classList.add('repair-terminal-open');
        modal.style.cssText = 'display: flex !important; visibility: visible !important; position: fixed !important; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 99999999 !important; background: rgba(2, 6, 23, 0.98); align-items: center; justify-content: center;';
        window.showToast("⚡ Opening Billing Dashboard...", "info");
    }

    // Auto-Focus Service Charge
    setTimeout(() => {
        const scInput = document.getElementById('bill-rep-service-charge');
        if (scInput) {
            scInput.focus();
            scInput.select();
        }
    }, 500);

    // KEYBOARD SHORTCUTS FOR BILLING
    const shortcutHandler = (e) => {
        const currentModal = document.getElementById('repair-billing-modal');
        if (currentModal.style.display === 'none' || !currentModal.classList.contains('active')) {
            window.removeEventListener('keydown', shortcutHandler);
            return;
        }

        if (e.key === 'F8') {
            e.preventDefault();
            const currentJob = (window.allRepairJobs || []).find(j => j.docId === window.currentBillingRepairId);
            if (currentJob && (currentJob.status === 'Completed' || currentJob.associatedOrderId)) {
                window.payAndDeliverRepair(window.currentBillingRepairId);
            } else {
                window.handleRepairCompleteClick();
            }
        }
        if (e.key === 'Escape') {
            window.closeRepairBillingModal();
            window.removeEventListener('keydown', shortcutHandler);
        }
    };
    window.addEventListener('keydown', shortcutHandler);
};

window.closeRepairBillingModal = () => {
    const currentModal = document.getElementById('repair-billing-modal');
    if (currentModal) {
        currentModal.style.cssText = 'display: none !important;';
        currentModal.classList.remove('active');
    }
    document.body.classList.remove('repair-terminal-open');
};

window.currentRepPayIndex = 0;

window.updateRepPayHighlight = () => {
    for (let i = 0; i < 4; i++) {
        const btn = document.getElementById(`rep-btn-${i}`);
        if (btn) {
            if (i === window.currentRepPayIndex) {
                btn.style.boxShadow = '0 0 20px rgba(255,255,255,0.5)';
                btn.style.transform = 'scale(1.05)';
                btn.style.filter = 'brightness(1.2)';
            } else {
                btn.style.boxShadow = 'none';
                btn.style.transform = 'scale(1)';
                btn.style.filter = 'none';
            }
        }
    }
};

const repPayModalHandler = (e) => {
    const modal = document.getElementById('repair-payment-popup-modal');
    if (modal && modal.style.display === 'flex') {
        if (e.key === 'ArrowRight') {
            e.preventDefault();
            window.currentRepPayIndex = (window.currentRepPayIndex + 1) % 4;
            window.updateRepPayHighlight();
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.currentRepPayIndex = (window.currentRepPayIndex - 1 + 4) % 4;
            window.updateRepPayHighlight();
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            window.currentRepPayIndex = (window.currentRepPayIndex + 2) % 4;
            window.updateRepPayHighlight();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            window.currentRepPayIndex = (window.currentRepPayIndex - 2 + 4) % 4;
            window.updateRepPayHighlight();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            const btn = document.getElementById(`rep-btn-${window.currentRepPayIndex}`);
            if (btn) btn.click();
        } else if (e.key === 'Escape') {
            modal.style.display = 'none';
        }
    }
};

window.openRepairPaymentModal = () => {
    const docId = window.currentBillingRepairId;
    if (!docId) {
        window.showToast("No active repair job to bill.", "warning");
        return;
    }
    
    // Update the payable amount in the modal
    const totalPayableElement = document.getElementById('bill-rep-total');
    const payableAmount = totalPayableElement ? totalPayableElement.innerText : "0.00";
    
    const popupPayable = document.getElementById('rep-pop-payable');
    if (popupPayable) {
        popupPayable.innerText = "Rs. " + payableAmount;
    }
    
    // Show the modal
    const modal = document.getElementById('repair-payment-popup-modal');
    if (modal) {
        modal.style.display = 'flex';
        window.currentRepPayIndex = 0;
        window.updateRepPayHighlight();
        window.removeEventListener('keydown', repPayModalHandler);
        window.addEventListener('keydown', repPayModalHandler);
    }
};

window.finalizeRepairPOSSale = async () => {
    try {
        const docId = window.currentBillingRepairId;
        const jobs = window.allRepairJobs || [];
        const job = jobs.find(j => j.docId === docId);
        if (!job) {
            window.showToast("Error: Repair Job not found in memory.", "error");
            return;
        }

    let payMethod = document.getElementById('bill-rep-pay-method').value;
    if (window.forceRepairPOSPayMethod) {
        payMethod = window.forceRepairPOSPayMethod;
        window.forceRepairPOSPayMethod = null;
    }
    const tendered = parseFloat(document.getElementById('bill-rep-tendered').value) || 0;
    
    // Check if customer is registered
    const customer = (window.allCustomers || []).find(c => c.phone === job.customerPhone);

    if (payMethod === 'Credit' && !customer) {
        window.showToast("⚠️ Master customer registration required for Credit Sale!", "warning");
        const regModal = document.getElementById('pos-reload-cust-modal');
        if (regModal) {
            document.getElementById('reg-rel-cust-phone').value = job.customerPhone || '';
            document.getElementById('reg-rel-cust-name').value = job.customerName || '';
            const regBtn = regModal.querySelector('button[onclick*="registerCustomerAndSaveReload"]');
            if (regBtn) regBtn.setAttribute('onclick', 'window.registerRepairCustomer()');
            regModal.style.display = 'flex';
        }
        return;
    }

    const serviceCharge = parseFloat(document.getElementById('bill-rep-service-charge').value) || 0;
    const advance = parseFloat(document.getElementById('bill-rep-advance').value) || 0;
    
    const items = [];
    items.push({
        docId: 'service_charge',
        name: `Repair Service: ${job.jobId}`,
        price: serviceCharge,
        quantity: 1,
        category: 'Service'
    });

    const rows = document.querySelectorAll('#bill-rep-parts-list tr');
    const batch = writeBatch(db);

    rows.forEach(tr => {
        const pId = tr.dataset.docId;
        const pName = tr.dataset.name;
        const pPrice = parseFloat(tr.dataset.price);
        const pQty = parseInt(tr.dataset.quantity) || 1;

        const prod = (window.allProducts || []).find(p => p.docId === pId);
        const costPrice = prod ? (parseFloat(prod.cost || prod.buyingPrice) || 0) : 0;

        items.push({
            docId: pId,
            name: pName,
            price: pPrice,
            quantity: pQty,
            costPrice: costPrice
        });

        const prodRef = doc(db, 'products', pId);
        const product = (window.allProducts || []).find(p => p.docId === pId);
        if (product) {
            batch.update(prodRef, { stock: Math.max(0, (product.stock || 0) - pQty) });
        }
    });

    const totalPayable = items.reduce((sum, i) => sum + (i.price * i.quantity), 0) - advance;
    
    let surcharge = 0;
    if (payMethod === 'Card') {
        const addSurcharge = await window.showCustomConfirm(
            "Add 2.5% Bank Card Surcharge to this repair bill?",
            "Card Surcharge",
            "💳",
            "Add Surcharge",
            "Skip Surcharge"
        );
        if (addSurcharge) {
            surcharge = totalPayable * 0.025;
        }
    }
    const finalTotal = totalPayable + surcharge;

    window.showToast("🚀 Finalizing Repair Bill...", "info");
    const billingModal = document.getElementById('repair-billing-modal');
    if (billingModal) {
        billingModal.classList.remove('active');
        document.body.classList.remove('repair-terminal-open');
        billingModal.style.cssText = 'display: none !important;';
    }

    if (payMethod === 'Pending') {
        batch.update(doc(db, 'repairJobs', docId), { 
            status: 'Completed', 
            balanceDue: finalTotal,
            serviceCharge: serviceCharge,
            billedItems: items,
            advancePaid: advance
        });

        await batch.commit();

        window.showToast("✅ Repair Billed Successfully!", "success");

        if (job && job.customerPhone) {
            setTimeout(() => {
                window.sendRepairCompletionSMSPrompt(job, finalTotal);
            }, 100);
        }
        
        // Reset the terminal UI
        document.getElementById('bill-rep-tendered').value = '';
        document.getElementById('bill-rep-service-charge').value = '';
        document.getElementById('bill-rep-parts-list').innerHTML = '';
        window.updateRepairTotal();
        return;
    }

    // Generate Order ID
    let nextRepairNum = 1;
    const existingRepOrders = (window.allOrders || []).filter(o => String(o.orderId || "").startsWith("#REP-"));
    if (existingRepOrders.length > 0) {
        const nums = existingRepOrders.map(o => {
            const m = String(o.orderId || "").match(/\d+$/);
            return m ? parseInt(m[0]) : 0;
        });
        nextRepairNum = Math.max(...nums) + 1;
    }
    const orderId = '#REP-' + nextRepairNum.toString().padStart(6, '0');

    const orderData = {
        orderId,
        items,
        total: finalTotal,
        baseAmount: totalPayable,
        surcharge: surcharge,
        deductedPoints: 0,
        paymentMethod: payMethod,
        status: 'Completed',
        isPOS: true,
        userName: customer ? customer.name : (job.customerName || 'Walk-in'),
        phone: job.customerPhone || '',
        customerId: customer ? customer.docId : null,
        staffName: sessionStorage.getItem('userName') || 'Technician',
        staffId: sessionStorage.getItem('userId') || '',
        branchId: sessionStorage.getItem('userBranchId') || 'Global',
        storeId: window.getStoreId(),
        timestamp: serverTimestamp(),
        date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        repairJobId: job.jobId,
        repairDocId: docId,
        itemDescription: job.itemDescription || job.deviceName || 'Electronic Item',
        problem: job.issue || job.reportedIssue || 'Technical Issue',
        serviceCharge: serviceCharge,
        advancePaid: advance,
        type: 'RepairBill'
    };
    
    window.lastSavedPOSOrder = orderData; 

    const orderDocRef = doc(collection(db, 'orders'));
    window.lastSavedPOSOrder.docId = orderDocRef.id;

    batch.set(orderDocRef, orderData);
    batch.update(doc(db, 'repairJobs', docId), { 
        status: 'Completed', 
        balanceDue: finalTotal,
        associatedOrderId: orderId
    });

    await batch.commit();

    window.showToast("✅ Repair Billed Successfully!", "success");

    if (job && job.customerPhone) {
        setTimeout(() => {
            window.sendRepairCompletionSMSPrompt(job, finalTotal);
        }, 100);
    }
    
    // Populate invoice modal data
    window.currentPendingRepairOrder = orderData;
    window.currentPendingRepairOrder.docId = orderDocRef.id;
    
    // Show a custom invoice modal or just open Graphic directly
    if (typeof window.openModernInvoice === 'function') {
        window.openModernInvoice(orderDocRef.id);
    }
        
        // Reset the terminal UI
        document.getElementById('bill-rep-tendered').value = '';
        document.getElementById('bill-rep-service-charge').value = '';
        document.getElementById('bill-rep-parts-list').innerHTML = '';
        window.updateRepairTotal();
        
    } catch (err) {
        console.error("Repair Finalize Error:", err);
        window.showToast("❌ Error: " + err.message, "error");
    }
};

window.viewRepairDetails = (docId) => {
    console.log("🔍 TRIGGER: viewing details for", docId);
    const jobs = window.allRepairJobs || [];
    const job = jobs.find(j => j.docId === docId);
    
    if (!job) {
        window.showToast("❌ Error: Job data not found.", "error");
        return;
    }

    const modalContainer = document.getElementById('repair-details-modal');
    if (!modalContainer) {
        window.alert("CRITICAL UI ERROR: 'repair-details-modal' not found in page!");
        return;
    }

    try {
        const jobId = job.jobId || 'N/A';
        const rawDate = job.timestamp || job.date || new Date();
        const date = (rawDate && typeof rawDate.toDate === 'function') ? rawDate.toDate().toLocaleString() : new Date(rawDate).toLocaleString();
        
        const name = job.customerName || 'N/A';
        const phone = job.customerPhone || 'N/A';
        const desc = job.itemDescription || 'Electronic Item';
        const issue = job.issue || job.reportedIssue || 'Not Working';
        const cost = parseFloat(job.estimatedCost) || 0;
        const advance = parseFloat(job.advance || job.advancePayment) || 0;
        const balance = parseFloat(job.balanceDue) || (cost - advance);

        let contentHTML = "";
        
        if (window.getA5InvoiceHTML) {
            console.log("DEBUG: Found getA5InvoiceHTML, rendering premium preview.");
            const invoiceHTML = window.getA5InvoiceHTML(jobId, date, name, phone, desc, issue, cost, advance, balance, 'single');
            contentHTML = `
                <div class="modal-content" style="max-width: 850px; width: 95%; background: transparent; padding: 0; box-shadow: none; border: none; position: relative; margin-top: 50px; margin-bottom: 50px;">

                    <!-- INVOICE CONTAINER -->
                    <div style="display: flex; justify-content: center; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 30px 70px rgba(0,0,0,0.7); position: relative; padding: 10px;">
                        <!-- INTERNAL X BUTTON -->
                        <button onclick="document.getElementById('repair-details-modal').style.display='none'; document.getElementById('repair-details-modal').classList.remove('active');" 
                                style="position: absolute; top: 25px; right: 25px; width: 45px; height: 45px; border-radius: 50%; background: #ef4444; color: white; border: 3px solid white; font-size: 1.5rem; font-weight: 900; cursor: pointer; display: flex; align-items: center; justify-content: center; z-index: 1000; box-shadow: 0 5px 15px rgba(0,0,0,0.2); transition: transform 0.2s;">&times;</button>
                        ${invoiceHTML}
                    </div>
                    
                    <div style="text-align: center; margin-top: 30px; color: rgba(255,255,255,0.5); font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">
                        MEC POS v2.2.9 - Enhanced Repair Systems
                    </div>
                </div>
            `;
        } else {
            console.warn("DEBUG: getA5InvoiceHTML missing, using plain fallback.");
            contentHTML = `
                <div class="modal-content" style="max-width: 450px; background: #0f172a; color: white; border-radius: 20px; padding: 30px; border: 1px solid #38bdf8;">
                   <h2 style="margin-top:0;">${jobId}</h2>
                   <p>Customer: ${name}</p>
                   <p>Item: ${desc}</p>
                   <p>Issue: ${issue}</p>
                   <hr style="opacity: 0.1;">
                   <h3>Balance: LKR ${balance.toLocaleString()}</h3>
                   <button onclick="document.getElementById('repair-details-modal').style.display='none'" style="width: 100%; padding: 15px; background: #ef4444; color: white; border-radius: 10px; font-weight: 900; margin-top: 20px; border:none; cursor: pointer;">CLOSE</button>
                </div>
            `;
        }

        modalContainer.innerHTML = contentHTML || "<h1>Error: Content Loading Failed</h1>";
        modalContainer.style.cssText = 'display: flex !important; visibility: visible !important; position: fixed !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100vh !important; z-index: 999999999 !important; background: rgba(2, 6, 23, 0.95) !important; align-items: flex-start !important; justify-content: center !important; padding-top: 40px !important; padding-bottom: 40px !important; overflow-y: auto !important;';
        modalContainer.classList.add('active');
        window.showToast("📄 Loading Preview...", "info");

    } catch (err) {
        console.error("VIEW DETAILS ERROR:", err);
        window.showToast("❌ Crash: " + err.message, "error");
    }
};

window.printRepairThermalReceipt = (order) => {
    if (!order) return;
    const orderBranchKey = order.branchId || order.branch || localStorage.getItem('mec_terminal_branch') || sessionStorage.getItem('userBranchId') || 'main';
    const branchInfo = typeof window.getBranchInfo === 'function' 
        ? window.getBranchInfo(orderBranchKey) 
        : {
            name: window.storeInfo?.name || 'MEC BOOK SHOP',
            branchName: 'Main Branch - Horana',
            address: 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
            phone: '071 923 3388'
        };

    const branchDisplayName = branchInfo.branchName || branchInfo.name || 'MEC BOOK SHOP';
    const branchAddress = branchInfo.address || branchInfo.location || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana';
    const branchPhone = branchInfo.phone || '071 923 3388';
    const items = order.items || [];
    
    let itemsHtml = items.map(item => `
        <div style="display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 12px;">
            <div style="flex: 1;">
                <div style="font-weight: 700; text-transform: uppercase;">${item.name}</div>
                <div style="font-size: 10px; color: #666;">${item.quantity} x LKR ${(item.price || 0).toLocaleString()}</div>
            </div>
            <div style="font-weight: 700;">LKR ${((item.price || 0) * (item.quantity || 1)).toLocaleString()}</div>
        </div>
    `).join('');

    const printWindow = window.open('', 'RepairReceipt', 'width=400,height=600');
    if (!printWindow) return;

    printWindow.document.write(`
        <html>
        <head>
            <title>Repair Receipt ${order.orderId}</title>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', sans-serif; padding: 10px; width: 300px; margin: 0 auto; color: #000; }
                .center { text-align: center; }
                .divider { border-bottom: 1px dashed #000; margin: 10px 0; }
                .bold { font-weight: bold; }
                .header { margin-bottom: 15px; }
            </style>
        </head>
        <body>
            <div class="header center">
                <div style="font-size: 18px; font-weight: 900;">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                <div style="font-size: 12px; font-weight: 800; color: #0284c7; margin-top: 2px;">🏢 ${branchDisplayName}</div>
                <div style="font-size: 11px; margin-top: 2px;">📍 ${branchAddress}</div>
                <div style="font-size: 11px;">📞 Tel: ${branchPhone}</div>
                <div class="divider"></div>
                <div style="font-size: 14px; font-weight: 900; background: #000; color: #fff; padding: 2px 0;">REPAIR BILL</div>
            </div>

            <div style="font-size: 11px;">
                <div style="display: flex; justify-content: space-between;">
                    <span>DATE: ${order.date || new Date().toLocaleDateString()}</span>
                    <span>INV: ${order.orderId}</span>
                </div>
                <div>JOB ID: ${order.repairJobId || 'N/A'}</div>
                <div>CUST: ${(order.userName || 'WALK-IN').toUpperCase()}</div>
                <div>PHONE: ${order.phone || 'N/A'}</div>
            </div>

            <div class="divider"></div>
            
            <div style="font-size: 11px; margin-bottom: 10px;">
                <div class="bold">DEVICE:</div>
                <div>${(order.itemDescription || 'N/A').toUpperCase()}</div>
                <div class="bold" style="margin-top: 5px;">PROBLEM:</div>
                <div>${(order.problem || 'N/A').toUpperCase()}</div>
            </div>

            <div class="divider"></div>
            ${itemsHtml}
            <div class="divider"></div>

            <div style="font-size: 13px;">
                <div style="display: flex; justify-content: space-between;">
                    <span>TOTAL BILL:</span>
                    <span class="bold">LKR ${(order.total + (order.advancePaid || 0)).toLocaleString()}</span>
                </div>
                ${order.advancePaid > 0 ? `
                <div style="display: flex; justify-content: space-between; color: #555;">
                    <span>ADVANCE PAID:</span>
                    <span>- LKR ${(order.advancePaid).toLocaleString()}</span>
                </div>
                ` : ''}
                <div style="display: flex; justify-content: space-between; font-size: 16px; margin-top: 5px;">
                    <span class="bold">NET PAYABLE:</span>
                    <span class="bold">LKR ${(order.total || 0).toLocaleString()}</span>
                </div>
            </div>

            <div class="divider"></div>
            <div class="center" style="font-size: 10px; margin-top: 20px;">
                THANK YOU FOR YOUR BUSINESS!<br>
                Items once sold cannot be returned.<br>
                *** REPAIR RECEIPT ***
            </div>
            <script>
                setTimeout(() => {
                    window.focus();
                    window.print();
                    window.close();
                }, 300);
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
};

window.showRepairIntake = () => {
    window.currentRepairJobId = 'JOB-' + Math.floor(Math.random() * 90000 + 10000);
    document.getElementById('repair-intake-modal').style.display = 'flex';
    document.getElementById('rep-job-id-display').innerText = window.currentRepairJobId;
    document.getElementById('rep-cust-name').value = '';
    document.getElementById('rep-cust-phone').value = '';
    document.getElementById('rep-item-desc').value = '';
    document.getElementById('rep-issue').value = '';
    document.getElementById('rep-est-cost').value = '0';
    document.getElementById('rep-advance').value = '0';

    const datalist = document.getElementById('rep-customers-list');
    if (datalist) {
        datalist.innerHTML = (window.allCustomers || [])
            .map(c => `<option value="${c.name}">${c.phone || ''}</option>`)
            .join('');
    }
    const phoneDatalist = document.getElementById('rep-customers-phone-list');
    if (phoneDatalist) {
        phoneDatalist.innerHTML = (window.allCustomers || [])
            .filter(c => c.phone)
            .map(c => `<option value="${c.phone}">${c.name || ''}</option>`)
            .join('');
    }
};

window.getA5InvoiceHTML = (jobId, date, name, phone, desc, issue, cost, advance, balance, layoutType = 'duo') => {
    const templateId = window.systemConfig?.invTemplate || 'classic';
    const themes = {
        classic: { 
            primary: '#002060', 
            secondary: '#64748b', 
            accent: '#e30030', 
            bg: '#f8fafc', 
            radius: '4px',
            font: "'Inter', sans-serif" 
        },
        modern: { 
            primary: '#0ea5e9', 
            secondary: '#94a3b8', 
            accent: '#10b981', 
            bg: '#f1f5f9', 
            radius: '16px',
            font: "'Outfit', 'Inter', sans-serif" 
        },
        minimal: { 
            primary: '#1a1a1a', 
            secondary: '#666666', 
            accent: '#000000', 
            bg: '#ffffff', 
            radius: '0px',
            font: "'Inter', sans-serif" 
        }
    };
    const theme = themes[templateId] || themes.classic;
    const storeName = (window.storeInfo?.name || 'MEC BOOK SHOP').toUpperCase();

    const singleReceipt = (type) => `
    <div class="repair-receipt-copy" style="width: 100%; border: 1px solid #e2e8f0; border-radius: ${theme.radius}; padding: 13px 18px; box-sizing: border-box; background: white; color: #0f172a; font-family: ${theme.font}; position: relative; overflow: hidden;">
        <div style="position: absolute; top: 7px; right: 10px; font-size: 9px; color: #94a3b8; font-weight: 800; text-transform: uppercase; opacity: 0.5;">${type}</div>

        <div style="display: flex; justify-content: space-between; align-items: flex-start; ${templateId === 'modern' ? `background: ${theme.primary}; color: white; padding: 12px 15px; margin: -13px -18px 14px -18px;` : `border-bottom: 3px solid ${theme.primary}; padding-bottom: 10px; margin-bottom: 12px;`}">
            <div>
                <h1 style="margin: 0; color: ${templateId === 'modern' ? 'white' : theme.primary}; font-size: 18px; font-weight: 900;">${storeName}</h1>
                <p style="margin: 2px 0 0 0; color: ${templateId === 'modern' ? 'rgba(255,255,255,0.8)' : theme.secondary}; font-size: 10px; font-weight: 700;">Premium Tech Repair & Support</p>
                <p style="margin: 3px 0 0 0; color: #475569; font-size: 9px; font-weight: 700;">📍 ${window.storeInfo?.address || 'Head Office'}</p>
                <p style="margin: 1px 0 0 0; color: #475569; font-size: 9px; font-weight: 700;">📞 ${window.storeInfo?.phone || 'Contact Branch'}</p>
            </div>
            <div style="text-align: right;">
                <h2 style="margin: 0; color: ${templateId === 'modern' ? 'white' : '#ef4444'}; font-size: 15px; font-weight: 900; text-transform: uppercase;">Repair Intake</h2>
                <p style="margin: 2px 0 0 0; color: ${templateId === 'modern' ? 'white' : '#0f172a'}; font-weight: 800; font-size: 12px;">#${jobId}</p>
                <p style="margin: 1px 0 0 0; color: #64748b; font-size: 9px; font-weight: 600;">Date: ${date}</p>
            </div>
        </div>

        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
            <div style="flex: 1; background: #f1f5f9; padding: 10px 12px; border-radius: ${theme.radius}; border-left: 4px solid ${theme.primary};">
                <h3 style="margin: 0 0 5px 0; color: #0f172a; font-size: 9px; text-transform: uppercase; font-weight: 800; letter-spacing: 1px;">Customer Detail</h3>
                <p style="margin: 2px 0; font-size: 12px; color: #0f172a !important;"><b style="color: #0f172a !important;">Name:</b> <span style="color: #0f172a !important; font-weight: 700;">${name || 'N/A'}</span></p>
                <p style="margin: 2px 0; font-size: 12px; color: #0f172a !important;"><b style="color: #0f172a !important;">Phone:</b> <span style="color: #0f172a !important; font-weight: 700;">${phone || 'N/A'}</span></p>
            </div>
            <div style="flex: 1; background: #f1f5f9; padding: 10px 12px; border-radius: ${theme.radius}; border-left: 4px solid ${theme.accent};">
                <h3 style="margin: 0 0 5px 0; color: #0f172a; font-size: 9px; text-transform: uppercase; font-weight: 800; letter-spacing: 1px;">Item Details</h3>
                <p style="margin: 2px 0; font-size: 12px; color: #0f172a !important;"><b style="color: #0f172a !important;">Item:</b> <span style="color: #0f172a !important; font-weight: 700;">${desc || 'N/A'}</span></p>
                <p style="margin: 2px 0; font-size: 11px; color: #1e293b !important;"><b style="color: #1e293b !important;">Issue:</b> <span style="color: #1e293b !important; font-weight: 700;">${issue}</span></p>
            </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; color: #0f172a !important;">
            <thead>
                <tr style="background: ${theme.primary}; color: white;">
                    <th style="padding: 8px 10px; text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 1px;">DESCRIPTION</th>
                    <th style="padding: 8px 10px; text-align: right; font-size: 10px; text-transform: uppercase; letter-spacing: 1px;">AMOUNT (LKR)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px 10px; border-bottom: 1px solid #e2e8f0; font-size: 13px; color: #0f172a !important; font-weight: 700;">Estimated Repair Charge</td>
                    <td style="padding: 10px 10px; border-bottom: 1px solid #e2e8f0; text-align: right; font-size: 13px; font-weight: 900; color: #0f172a !important;">${cost.toFixed(2)}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 10px; font-size: 13px; font-weight: 800; color: #16a34a !important;">Advance Payment (-)</td>
                    <td style="padding: 8px 10px; text-align: right; font-size: 13px; font-weight: 900; color: #16a34a !important;">${advance.toFixed(2)}</td>
                </tr>
            </tbody>
        </table>

        <div style="display: flex; justify-content: flex-end; align-items: center; gap: 15px; padding: 12px 15px; background: #f8fafc; border-radius: ${theme.radius}; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 10px;">
            <span style="font-size: 12px; font-weight: 800; color: #64748b;">BALANCE DUE:</span>
            <span style="font-size: 22px; font-weight: 900; color: ${theme.primary};">Rs. ${balance.toFixed(2)}</span>
        </div>

        <div style="font-size: 8.5px; color: #334155; text-align: left; background: #f1f5f9; padding: 8px 12px; border-radius: 6px; border-left: 3px solid #94a3b8; line-height: 1.5;">
            <strong style="color: #0f172a;">REPAIR POLICY & WARRANTY:</strong><br>
            1. No warranty for physical damages, water damages, display lines, or dead pixels after repair.<br>
            2. Warranty covers only the repaired/replaced components for the specified period.<br>
            3. Devices left over 30 days after repair completion will be disposed of. The shop is not responsible thereafter.<br>
            4. <b>Please bring this original receipt when collecting the device.</b>
        </div>

        <div style="margin-top: 8px; font-size: 9px; color: #64748b; text-align: center; border-top: 1px dashed #cbd5e1; padding-top: 7px; font-style: italic; font-weight: 600;">
            Thank you for choosing ${storeName}!
        </div>
    </div>
    `;

    if (layoutType === 'single') return singleReceipt("PREVIEW COPY");

    return `
    <div class="duo-invoice-wrapper" style="width: 210mm; height: 297mm; padding: 8mm 10mm; background: #f1f5f9; box-sizing: border-box; display: flex; flex-direction: column; gap: 4mm; overflow: hidden;">
        ${singleReceipt("CUSTOMER COPY")}
        <div style="border-top: 2px dashed #94a3b8; position: relative; flex-shrink: 0;">
            <div style="position: absolute; top: -10px; left: 50%; transform: translateX(-50%); background: #f1f5f9; padding: 0 12px; color: #94a3b8; font-size: 11px; font-weight: 800;">✂️ CUT HERE</div>
        </div>
        ${singleReceipt("OFFICE COPY")}
    </div>
    `;
};

const saveRepairJob = async (jobId, name, phone, desc, issue, cost, advance, balance) => {
    if (window._isSavingRepair) return;
    window._isSavingRepair = true;
    try {
        const existingJob = (window.allRepairJobs || []).find(j => j.jobId === jobId);
        if (existingJob) {
            await updateDoc(doc(db, 'repairJobs', existingJob.docId), {
                customerName: name,
                customerPhone: phone,
                itemDescription: desc,
                issue: issue,
                estimatedCost: cost,
                advancePayment: advance,
                balanceDue: balance
            });
            window.showToast("✅ Repair job updated!", "success");
        } else {
            window.showToast(navigator.onLine ? "🚀 Uploading repair job..." : "💾 Saving repair locally...", "info");
            let branchId = sessionStorage.getItem('userBranchId') || window.activeBranchFilter || 'main';
            if (branchId === 'Global' || branchId === 'All') branchId = 'main';

            const newDocRef = await addDoc(repairJobsCol, {
                jobId,
                customerName: name,
                customerPhone: phone,
                itemDescription: desc,
                issue: issue,
                estimatedCost: cost,
                advancePayment: advance,
                balanceDue: balance,
                status: 'New',
                branchId,
                storeId: window.getStoreId(),
                timestamp: serverTimestamp()
            });
            if (!window.allRepairJobs) window.allRepairJobs = [];
            window.allRepairJobs.push({
                docId: newDocRef.id,
                jobId,
                customerName: name,
                customerPhone: phone,
                itemDescription: desc,
                issue: issue,
                estimatedCost: cost,
                advancePayment: advance,
                balanceDue: balance,
                status: 'New',
                branchId,
                storeId: window.getStoreId()
            });
            window.showToast("✅ Repair job recorded!", "success");
        }
    } catch (e) {
        console.error("Error saving repair job: ", e);
        window.showToast("❌ Failed to save repair job", "error");
    } finally {
        setTimeout(() => { window._isSavingRepair = false; }, 1000);
    }
};

window.saveRepairIntakeOnly = async () => {
    try {
        const name = document.getElementById('rep-cust-name').value;
        const phone = document.getElementById('rep-cust-phone').value;
        const desc = document.getElementById('rep-item-desc').value;
        const issue = document.getElementById('rep-issue').value;
        const cost = parseFloat(document.getElementById('rep-est-cost').value) || 0;
        const advance = parseFloat(document.getElementById('rep-advance').value) || 0;
        const balance = cost - advance;
        const jobId = window.currentRepairJobId || ('JOB-' + Math.floor(Math.random() * 90000 + 10000));

        if (!name) {
            window.showToast("Please enter customer name", "error");
            return;
        }

        window.showToast("💾 Saving repair job...", "info");
        await saveRepairJob(jobId, name, phone, desc, issue, cost, advance, balance);
        
        // Close modal
        document.getElementById('repair-intake-modal').style.display = 'none';
    } catch (e) {
        console.error(e);
        window.showToast("❌ Failed to save repair job", "error");
    }
};

window.generateRepairReceipt = async () => {
    try {
        const name = document.getElementById('rep-cust-name').value;
        const phone = document.getElementById('rep-cust-phone').value;
        const desc = document.getElementById('rep-item-desc').value;
        const issue = document.getElementById('rep-issue').value;
        const cost = parseFloat(document.getElementById('rep-est-cost').value) || 0;
        const advance = parseFloat(document.getElementById('rep-advance').value) || 0;
        const balance = cost - advance;
        const date = new Date().toLocaleString();
        const jobId = window.currentRepairJobId || ('JOB-' + Math.floor(Math.random() * 90000 + 10000));

        window.showToast("🖼️ Generating JPG receipt...", "info");
        await saveRepairJob(jobId, name, phone, desc, issue, cost, advance, balance);

        // Get duo template (A4 with 2 copies)
        const invoiceHTML = window.getA5InvoiceHTML(jobId, date, name, phone, desc, issue, cost, advance, balance, 'duo');

        // Create an off-screen container to render the JPG
        const printFrame = document.createElement('div');
        printFrame.id = 'repair-print-container';
        printFrame.style.cssText = 'position:fixed; left:-10000px; top:-10000px; width:210mm; height:297mm; background:white; z-index:-1;';
        printFrame.innerHTML = invoiceHTML;
        document.body.appendChild(printFrame);

        // Load html2canvas if not present
        if (typeof html2canvas === 'undefined') {
            await new Promise((resolve) => {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
                script.onload = resolve;
                document.head.appendChild(script);
            });
        }

        setTimeout(async () => {
            try {
                // Generate Canvas
                const canvas = await html2canvas(printFrame, { scale: 2, useCORS: true, backgroundColor: '#ffffff', logging: false });
                const imgData = canvas.toDataURL("image/jpeg", 0.95);
                
                // Print the JPG directly via Iframe
                let jpgPrintFrame = document.getElementById('jpg-print-iframe');
                if (!jpgPrintFrame) {
                    jpgPrintFrame = document.createElement('iframe');
                    jpgPrintFrame.id = 'jpg-print-iframe';
                    jpgPrintFrame.setAttribute('style', 'position:fixed; left:-10000px; top:-10000px; width:210mm; height:297mm; visibility:visible; display:block; z-index:-1;');
                    document.body.appendChild(jpgPrintFrame);
                }

                const doc = jpgPrintFrame.contentWindow.document;
                doc.open();
                doc.write(`
                    <html>
                    <head>
                        <title>Repair Intake ${jobId}</title>
                        <style>
                            @page { size: A4 portrait; margin: 0; }
                            body { margin: 0; padding: 0; display: flex; justify-content: center; align-items: flex-start; background: white; }
                            img { width: 100%; max-width: 210mm; display: block; }
                        </style>
                    </head>
                    <body>
                        <img src="${imgData}" />
                        <script>
                            setTimeout(() => {
                               window.focus();
                               window.print();
                            }, 500);
                        </script>
                    </body>
                    </html>
                `);
                doc.close();

                document.body.removeChild(printFrame);
                window.showToast("🖨️ Opening Printer...", "success");

                // Close modal after a short delay
                setTimeout(() => {
                    document.getElementById('repair-intake-modal').style.display = 'none';
                }, 2000);
            } catch (err) {
                console.error("Canvas Error:", err);
                window.showToast("❌ Failed to generate JPG.", "error");
                document.body.removeChild(printFrame);
            }
        }, 500); // give time for DOM to render before snapshot

    } catch (e) {
        console.error("JPG Error:", e);
        window.showToast("❌ Generation Failed: Check console", "error");
    }
};

window.downloadRepairPDF = async () => {
    const name = document.getElementById('rep-cust-name').value;
    const phone = document.getElementById('rep-cust-phone').value;
    const desc = document.getElementById('rep-item-desc').value;
    const issue = document.getElementById('rep-issue').value;
    const cost = parseFloat(document.getElementById('rep-est-cost').value) || 0;
    const advance = parseFloat(document.getElementById('rep-advance').value) || 0;
    const balance = cost - advance;
    const date = new Date().toLocaleString();
    const jobId = window.currentRepairJobId || ('JOB-' + Math.floor(Math.random() * 90000 + 10000));

    await saveRepairJob(jobId, name, phone, desc, issue, cost, advance, balance);

    const tempDiv = document.createElement('div');
    // Using DUO layout for PDF as well
    tempDiv.innerHTML = window.getA5InvoiceHTML(jobId, date, name, phone, desc, issue, cost, advance, balance, 'duo');

    const opt = {
        margin:       0,
        filename:     `${jobId}_Repair_Invoice.pdf`,
        image:        { type: 'jpeg', quality: 1.0 },
        html2canvas:  { scale: 4, useCORS: true, logging: false },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    if (window.html2pdf) {
        window.html2pdf().set(opt).from(tempDiv).save().then(() => {
             document.getElementById('repair-intake-modal').style.display = 'none';
             window.showToast("✅ A4 Duo-Copy PDF Downloaded Successfully", "success");
        });
    } else {
        alert("PDF generator not loaded. Refreshing or checking connection may help.");
    }
};

window.shareRepairSMS = async () => {
    const name = document.getElementById('rep-cust-name')?.value || 'Valued Customer';
    let phone = document.getElementById('rep-cust-phone')?.value;
    const desc = document.getElementById('rep-item-desc')?.value || 'Device';
    const issue = document.getElementById('rep-issue')?.value || 'Repair';
    const cost = parseFloat(document.getElementById('rep-est-cost')?.value) || 0;
    const advance = parseFloat(document.getElementById('rep-advance')?.value) || 0;
    const balance = cost - advance;
    const jobId = window.currentRepairJobId || ('JOB-' + Math.floor(Math.random() * 90000 + 10000));

    if (!phone) {
        if (window.showToast) window.showToast("Please enter customer phone number first.", "warning");
        else alert("Please enter a customer phone number first.");
        return;
    }

    if (typeof saveRepairJob === 'function') {
        await saveRepairJob(jobId, name, phone, desc, issue, cost, advance, balance);
    }
    const modal = document.getElementById('repair-intake-modal');
    if (modal) modal.style.display = 'none';

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const message = `MEC Services Repair Intake: Job #${jobId}\nCustomer: ${name}\nItem: ${desc}\nIssue: ${issue}\nEst: LKR ${cost.toFixed(2)} | Adv: LKR ${advance.toFixed(2)} | Bal: LKR ${balance.toFixed(2)}\nThank you! We will notify you when ready. - ${bizName}`;

    if (typeof window.dispatchSMS === 'function') {
        await window.dispatchSMS(phone, message);
    } else {
        alert("SMS engine not initialized.");
    }
};

window.shareRepairWhatsApp = async () => {
    const name = document.getElementById('rep-cust-name')?.value || 'Valued Customer';
    let phone = document.getElementById('rep-cust-phone')?.value;
    const desc = document.getElementById('rep-item-desc')?.value || 'Device';
    const issue = document.getElementById('rep-issue')?.value || 'Repair';
    const cost = parseFloat(document.getElementById('rep-est-cost')?.value) || 0;
    const advance = parseFloat(document.getElementById('rep-advance')?.value) || 0;
    const balance = cost - advance;
    const jobId = window.currentRepairJobId || ('JOB-' + Math.floor(Math.random() * 90000 + 10000));

    if (!phone) {
        if (window.showToast) window.showToast("Please enter customer phone number first.", "warning");
        else alert("Please enter a customer phone number first.");
        return;
    }

    if (typeof saveRepairJob === 'function') {
        await saveRepairJob(jobId, name, phone, desc, issue, cost, advance, balance);
    }
    const modal = document.getElementById('repair-intake-modal');
    if (modal) modal.style.display = 'none';

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const message = `*${bizName.toUpperCase()} SERVICES - REPAIR INTAKE BILL* 🔧\n\n*Job ID:* ${jobId}\n*Customer:* ${name}\n*Item:* ${desc}\n*Reported Issue:* ${issue}\n\n*Estimated Service Charge:* LKR ${cost.toFixed(2)}\n*Advance Paid:* LKR ${advance.toFixed(2)}\n*Balance Due:* LKR ${balance.toFixed(2)}\n\nThank you for choosing ${bizName} Services! We will notify you when your item is ready.`;

    if (typeof window.dispatchWhatsApp === 'function') {
        await window.dispatchWhatsApp(phone, message);
    } else {
        const encoded = encodeURIComponent(message);
        window.open(`https://wa.me/${phone.replace(/\D/g, '')}?text=${encoded}`, '_blank');
    }
};

window.voidAndReverseRepair = async (docId) => {
    const jobs = window.allRepairJobs || [];
    const job = jobs.find(j => j.docId === docId);
    if (!job) return;

    const auth = await window.asyncAuthPrompt("Supervisor authorization required to Void & Reverse this repair bill.", "Security Verification");
    if (!auth) return;

    const isSuperAdmin = (auth.user.toLowerCase() === 'malinduec@gmail.com' && auth.pass === 'malindu123') ||
                         (auth.user.toLowerCase() === 'mecposadmin@gmail.com' && auth.pass === 'mecpos123');
    const isMecCeo = (auth.user.toLowerCase() === 'mecbookshop@gmail.com' && auth.pass === 'mec123');
    const isDJCeo = (auth.user.toLowerCase() === 'ireshadinali@gmail.com' && auth.pass === 'ireshadinali123');
    const isManager = (auth.pass === 'mec123');

    if (!isSuperAdmin && !isMecCeo && !isDJCeo && !isManager) {
        window.showToast("❌ Unauthorized Credentials!", "error");
        return;
    }

    if (await window.showCustomConfirm("Are you sure you want to VOID the associated bill/order and put this repair back into 'Processing' status?", "Void Repair Bill", "🚨", "Void Bill", "Cancel")) {
        try {
            window.showToast("🔄 Reversing repair billing...", "info");
            const batch = writeBatch(db);

            // 1. Update the repair status back to "Processing"
            const repairRef = doc(db, 'repairJobs', docId);
            batch.update(repairRef, {
                status: 'Processing',
                balanceDue: parseFloat(job.estimatedCost || 0) - parseFloat(job.advancePayment || job.advance || 0),
                associatedOrderId: null
            });

            // 2. Void the order (if it exists)
            if (job.associatedOrderId) {
                const orders = window.allOrders || [];
                const matchedOrder = orders.find(o => o.orderId === job.associatedOrderId);
                if (matchedOrder) {
                    const orderRef = doc(db, 'orders', matchedOrder.docId);
                    batch.update(orderRef, {
                        status: 'Void',
                        voidReason: `Reversed Repair Job ${job.jobId}`,
                        voidDate: serverTimestamp(),
                        voidedBy: auth.user || 'Supervisor'
                    });

                    // 3. Return stock of items in the order
                    const items = matchedOrder.items || [];
                    for (const item of items) {
                        if (item.docId && item.docId !== 'service_charge') {
                            const prodRef = doc(db, 'products', item.docId);
                            const prod = (window.allProducts || []).find(p => p.docId === item.docId);
                            if (prod) {
                                batch.update(prodRef, {
                                    stock: (prod.stock || 0) + (item.quantity || 1)
                                });
                            }
                        }
                    }
                }
            }

            await batch.commit();
            window.showToast("✅ Repair billing reversed & set back to Processing!", "success");
        } catch (error) {
            console.error("Void & Reverse Error:", error);
            window.showToast("❌ Failed to reverse repair billing", "error");
        }
    }
};

window.currentPayAndDeliverRepairDocId = null;

window.payAndDeliverRepair = async (docId) => {
    const jobs = window.allRepairJobs || [];
    const job = jobs.find(j => j.docId === docId);
    if (!job) return;

    window.currentPayAndDeliverRepairDocId = docId;

    const balance = Number(job.balanceDue || 0);

    const popupPayable = document.getElementById('rep-pop-payable');
    if (popupPayable) {
        popupPayable.innerText = "Rs. " + balance.toFixed(2);
    }

    const modal = document.getElementById('repair-payment-popup-modal');
    if (modal) {
        modal.style.display = 'flex';
        window.currentRepPayIndex = 0;
        window.updateRepPayHighlight();
    }
};

window.executePayAndDeliverRepair = async (paymentMethod) => {
    const docId = window.currentPayAndDeliverRepairDocId;
    if (!docId) return;

    try {
        const jobs = window.allRepairJobs || [];
        const job = jobs.find(j => j.docId === docId);
        if (!job) return;

        window.showToast("🚀 Finalizing payment & delivering...", "info");
        const batch = writeBatch(db);

        let orderId = job.associatedOrderId;
        let createdOrderDocId = null;
        let orderData = null;

        // 1. Update order status to Delivered & paymentMethod
        if (orderId) {
            const orders = window.allOrders || [];
            let matchedOrder = orders.find(o => o.orderId === orderId);
            if (!matchedOrder) {
                try {
                    const q = query(ordersCol, where('orderId', '==', orderId));
                    const snap = await getDocs(q);
                    if (!snap.empty) {
                        matchedOrder = { ...snap.docs[0].data(), docId: snap.docs[0].id };
                    }
                } catch (e) {
                    console.error("Error fetching order directly on delivery:", e);
                }
            }
            if (matchedOrder) {
                const orderRef = doc(db, 'orders', matchedOrder.docId);
                batch.update(orderRef, {
                    status: 'Delivered',
                    paymentMethod: paymentMethod,
                    timestamp: serverTimestamp(),
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                });
                createdOrderDocId = matchedOrder.docId;
                orderData = { ...matchedOrder, status: 'Delivered', paymentMethod: paymentMethod };
            }
        } else {
            // Create a brand new order since it was only saved as 'Completed' inside the repairJob
            let nextRepairNum = 1;
            const existingRepOrders = (window.allOrders || []).filter(o => String(o.orderId || "").startsWith("#REP-"));
            if (existingRepOrders.length > 0) {
                const nums = existingRepOrders.map(o => {
                    const m = String(o.orderId || "").match(/\d+$/);
                    return m ? parseInt(m[0]) : 0;
                });
                nextRepairNum = Math.max(...nums) + 1;
            }
            orderId = '#REP-' + nextRepairNum.toString().padStart(6, '0');

            const customer = (window.allCustomers || []).find(c => c.phone === job.customerPhone);
            const billedItems = job.billedItems || [];
            const serviceCharge = job.serviceCharge || 0;
            const advance = job.advancePaid || job.advance || job.advancePayment || 0;
            const baseAmount = Number(job.balanceDue || 0);
            
            let surcharge = 0;
            if (paymentMethod === 'Card') {
                const addSurcharge = await window.showCustomConfirm(
                    "Add 2.5% Bank Card Surcharge to this repair bill?",
                    "Card Surcharge",
                    "💳",
                    "Add Surcharge",
                    "Skip Surcharge"
                );
                if (addSurcharge) {
                    surcharge = baseAmount * 0.025;
                }
            }
            const finalTotal = baseAmount + surcharge;

            orderData = {
                orderId,
                items: billedItems,
                total: finalTotal,
                baseAmount: baseAmount,
                surcharge: surcharge,
                deductedPoints: 0,
                paymentMethod: paymentMethod,
                status: 'Delivered',
                isPOS: true,
                userName: customer ? customer.name : (job.customerName || 'Walk-in'),
                phone: job.customerPhone || '',
                customerId: customer ? customer.docId : null,
                staffName: sessionStorage.getItem('userName') || 'Technician',
                staffId: sessionStorage.getItem('userId') || '',
                branchId: sessionStorage.getItem('userBranchId') || 'Global',
                storeId: window.getStoreId(),
                timestamp: serverTimestamp(),
                date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                repairJobId: job.jobId,
                repairDocId: docId,
                itemDescription: job.itemDescription || job.deviceName || 'Electronic Item',
                problem: job.issue || job.reportedIssue || 'Technical Issue',
                serviceCharge: serviceCharge,
                advancePaid: advance,
                type: 'RepairBill'
            };

            const orderDocRef = doc(collection(db, 'orders'));
            orderData.docId = orderDocRef.id;
            createdOrderDocId = orderDocRef.id;

            batch.set(orderDocRef, orderData);
        }

        // 2. Update repair job status to Delivered & balanceDue to 0 & associate the orderId
        const repairRef = doc(db, 'repairJobs', docId);
        batch.update(repairRef, {
            status: 'Delivered',
            balanceDue: 0,
            associatedOrderId: orderId
        });

        await batch.commit();
        window.showToast("✅ Repair job fully Delivered & Paid!", "success");

        // Populate invoice modal data and show
        if (orderData && createdOrderDocId) {
            window.currentPendingRepairOrder = orderData;
            window.currentPendingRepairOrder.docId = createdOrderDocId;
            if (typeof window.openModernInvoice === 'function') {
                window.openModernInvoice(createdOrderDocId);
            }
        }
    } catch (err) {
        console.error("Execute Pay & Deliver Error:", err);
        window.showToast("❌ Failed to finalize payment", "error");
    } finally {
        window.currentPayAndDeliverRepairDocId = null;
    }
};

window.handleRepairPaymentSelect = (method) => {
    if (window.currentPayAndDeliverRepairDocId) {
        window.executePayAndDeliverRepair(method);
    } else {
        document.getElementById('bill-rep-pay-method').value = method;
        window.finalizeRepairPOSSale();
    }
    document.getElementById('repair-payment-popup-modal').style.display = 'none';
};

window.handleRepairCompleteClick = () => {
    window.forceRepairPOSPayMethod = 'Pending';
    const payMethodSelect = document.getElementById('bill-rep-pay-method');
    if (payMethodSelect) payMethodSelect.value = 'Pending';
    window.finalizeRepairPOSSale();
};

window.currentQuickDepDocId = null;
window.currentQuickDepPaymentMethod = 'Cash';

window.openRepairQuickDeliveryModal = async (docId) => {
    const jobs = window.allRepairJobs || [];
    const job = jobs.find(j => j.docId === docId);
    if (!job) return;

    window.currentQuickDepDocId = docId;
    window.currentQuickDepPaymentMethod = 'Cash';

    // Get order data
    let billedItems = job.billedItems || [];
    let serviceCharge = job.serviceCharge || 0;
    let advance = job.advancePaid || job.advance || job.advancePayment || 0;
    
    // Check if job already has associatedOrderId
    if (job.associatedOrderId && billedItems.length === 0) {
        try {
            const q = query(ordersCol, where('orderId', '==', job.associatedOrderId));
            const snap = await getDocs(q);
            if (!snap.empty) {
                const order = { ...snap.docs[0].data(), docId: snap.docs[0].id };
                billedItems = order.items || [];
                serviceCharge = order.serviceCharge || 0;
                advance = order.advancePaid || 0;
            }
        } catch (e) {
            console.error("Error fetching order in quick checkout:", e);
        }
    }

    // Populate Job details
    document.getElementById('quick-dep-job-id').innerText = job.jobId || 'N/A';
    document.getElementById('quick-dep-cust-name').innerText = job.customerName || 'N/A';
    document.getElementById('quick-dep-cust-phone').innerText = job.customerPhone || 'N/A';
    document.getElementById('quick-dep-item').innerText = job.itemDescription || job.deviceName || 'N/A';

    // Populate Items list
    const tbody = document.getElementById('quick-dep-items-list');
    tbody.innerHTML = '';
    
    const hasServiceCharge = billedItems.some(i => i.docId === 'service_charge');
    let displayItems = [...billedItems];
    if (!hasServiceCharge && serviceCharge > 0) {
        displayItems.unshift({
            docId: 'service_charge',
            name: `Repair Service: ${job.jobId}`,
            price: serviceCharge,
            quantity: 1
        });
    }

    let subtotal = 0;
    displayItems.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="padding: 8px 0;">
                <div style="font-weight: 700;">${item.name}</div>
            </td>
            <td style="padding: 8px 0; text-align: center;">${item.quantity}</td>
            <td style="padding: 8px 0; text-align: right;">Rs. ${itemTotal.toLocaleString()}</td>
        `;
        tbody.appendChild(tr);
    });

    const total = subtotal - advance;

    document.getElementById('quick-dep-subtotal').innerText = `Rs. ${subtotal.toLocaleString()}`;
    document.getElementById('quick-dep-advance').innerText = `Rs. ${advance.toLocaleString()}`;
    document.getElementById('quick-dep-total').innerText = `Rs. ${total.toLocaleString()}`;

    // Reset input/payment
    document.getElementById('quick-dep-tendered').value = '';
    document.getElementById('quick-dep-change').innerText = 'Rs. 0.00';
    
    window.selectQuickDepPayment('Cash');

    const modal = document.getElementById('repair-quick-delivery-modal');
    if (modal) {
        modal.style.display = 'flex';
    }
};

window.selectQuickDepPayment = (method) => {
    window.currentQuickDepPaymentMethod = method;
    
    const btns = document.querySelectorAll('.qd-pay-btn');
    btns.forEach(btn => {
        btn.style.background = 'rgba(255, 255, 255, 0.02)';
        btn.style.color = '#cbd5e1';
        btn.style.border = '2px solid rgba(255, 255, 255, 0.1)';
    });

    let selectedBtnId = 'qd-pay-Cash';
    if (method === 'Card') selectedBtnId = 'qd-pay-Card';
    else if (method === 'Bank Transfer') selectedBtnId = 'qd-pay-Bank';
    else if (method === 'Credit') selectedBtnId = 'qd-pay-Credit';

    const selBtn = document.getElementById(selectedBtnId);
    if (selBtn) {
        if (method === 'Cash') {
            selBtn.style.background = 'rgba(16, 185, 129, 0.1)';
            selBtn.style.color = '#10b981';
            selBtn.style.border = '2px solid #10b981';
        } else if (method === 'Card') {
            selBtn.style.background = 'rgba(139, 92, 246, 0.1)';
            selBtn.style.color = '#8b5cf6';
            selBtn.style.border = '2px solid #8b5cf6';
        } else if (method === 'Bank Transfer') {
            selBtn.style.background = 'rgba(245, 158, 11, 0.1)';
            selBtn.style.color = '#f59e0b';
            selBtn.style.border = '2px solid #f59e0b';
        } else if (method === 'Credit') {
            selBtn.style.background = 'rgba(239, 68, 68, 0.1)';
            selBtn.style.color = '#ef4444';
            selBtn.style.border = '2px solid #ef4444';
        }
    }

    const cashArea = document.getElementById('quick-dep-cash-area');
    if (cashArea) {
        cashArea.style.display = (method === 'Cash') ? 'block' : 'none';
    }
};

window.updateQuickDepChange = () => {
    let totalText = document.getElementById('quick-dep-total').innerText;
    totalText = totalText.replace(/Rs\.?/gi, '').replace(/,/g, '').trim();
    const total = parseFloat(totalText) || 0;
    const tendered = parseFloat(document.getElementById('quick-dep-tendered').value) || 0;
    const change = Math.max(0, tendered - total);
    document.getElementById('quick-dep-change').innerText = `Rs. ${change.toFixed(2)}`;
};

window.submitQuickDepPayment = async () => {
    const docId = window.currentQuickDepDocId;
    if (!docId) return;

    window.currentPayAndDeliverRepairDocId = docId;
    document.getElementById('repair-quick-delivery-modal').style.display = 'none';
    await window.executePayAndDeliverRepair(window.currentQuickDepPaymentMethod);
};

window.initRepairs = initRepairs;
