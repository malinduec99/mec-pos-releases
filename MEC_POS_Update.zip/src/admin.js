// [MANDATORY] Run .\MASTER_SYNC.bat after any changes to this file!
import './admin-style.css';
import './singlish.js';
import './modules/auth.js';
import './modules/inventory.js';
import './modules/orders.js';
import './modules/finance.js';
import './modules/bankManager.js';
import './modules/pos.js';
import './modules/theme.js';
import './modules/repairs.js';
import './modules/reports.js';
import './modules/mrp.js';
import './modules/hrm.js';
import './modules/promotions.js';
import './modules/lite-mode.js';
import './modules/aiCopilot.js';
import { initQuotationManager } from './modules/quotationManager.js';
import { initSupplyChain } from './modules/supply_chain.js';
import { initSystem, CLIENT_VERSION } from './modules/system.js';
import { initAutoBackup } from './modules/backup.js';
import { initReloadModule } from './modules/reload.js';
import { db, auth } from './firebase.js';
import { saveOfflineCache, loadOfflineCache } from './modules/cacheManager.js';
import {
    calculateAPIT,
    calculateSriLankaPayrollForEmployee,
    generateCentralBankEPFCFormText,
    generateETFScheduleCSV,
    generateBankBulkTransferCSV,
    generatePayslipHTML
} from './modules/sriLankaPayrollEngine.js';

// Cloud logging bridge for remote diagnostics
window.uploadLogToCloud = async function(message, type = 'csharp') {
    try {
        const storeId = localStorage.getItem('mecpos_last_store_id') || 'unknown';
        await addDoc(collection(db, 'system_logs'), {
            storeId,
            type,
            message,
            timestamp: serverTimestamp(),
            userAgent: navigator.userAgent
        });
    } catch(e) {
        console.error("Cloud logging failed:", e);
    }
};

// --- Store Detection & Global Helpers ---
const urlParams = new URLSearchParams(window.location.search);
const pathParts = window.location.pathname.split('/').filter(p => p !== '');
const urlStore = urlParams.get('store') || (pathParts[0] === 'admin' ? pathParts[1] : null);
if (urlStore) sessionStorage.setItem('tempStoreSlug', urlStore);

window.getStoreId = () => sessionStorage.getItem('userStoreId') || sessionStorage.getItem('tempStoreSlug') || 'mec-book-shop';

window.getLocalYYYYMMDD = (d = new Date()) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// --- Scanner Global Logic ---
let html5QrCode;
let currentFacingMode = "environment";
let scannerCallback = null;

window.openScanner = (callback = null) => {
    scannerCallback = callback;
    const modal = document.getElementById('scanner-modal');
    if (modal) modal.style.display = 'flex';
    if (!html5QrCode) {
        html5QrCode = new Html5Qrcode("scanner-reader");
    }
    startScanning();
};

const startScanning = () => {
    const config = { 
        fps: 24, 
        qrbox: (width, height) => {
            return { width: Math.floor(width * 0.8), height: Math.floor(height * 0.5) };
        }
    };
    html5QrCode.start(
        { facingMode: currentFacingMode },
        config,
        onScanSuccess
    ).catch(err => {
        console.error("Camera Error:", err);
        window.showToast("Cannot access camera. Check permissions.", "error");
    });
};

window.toggleCamera = () => {
    currentFacingMode = currentFacingMode === "environment" ? "user" : "environment";
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => startScanning());
    }
};

window.closeScanner = () => {
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
            document.getElementById('scanner-modal').style.display = 'none';
        });
    } else {
        const modal = document.getElementById('scanner-modal');
        if (modal) modal.style.display = 'none';
    }
};

const onScanSuccess = (decodedText) => {
    const q = decodedText.trim();
    if (typeof scannerCallback === 'function') {
        scannerCallback(q);
        window.closeScanner();
        scannerCallback = null;
        return;
    }

    // [v3.12.15] Respect active tab for scanner logic
    const activeTab = document.querySelector('.nav-tab.active')?.id;

    if (activeTab === 'tab-supplier-invoices' || activeTab === 'tab-stock') {
        const searchQ = q.toLowerCase();
        const product = (window.allProducts || []).find(p => 
            (p.sku && p.sku.toLowerCase() === searchQ) ||
            (p.name && p.name.toLowerCase() === searchQ)
        );

        if (product) {
            window.addToSupplierInvoice(product.docId);
            window.showToast(`✅ Added to Batch: ${product.name}`, "success");
            const sound = document.getElementById('sound-pos-save');
            if (sound) sound.play().catch(() => {});
        } else {
            window.showToast("❌ Product not found in catalog", "warning");
        }
        return;
    }

    // Default POS logic
    if (window.addToPOSBill) {
        const searchQ = q.toLowerCase();
        const product = (window.allProducts || []).find(p => 
            (p.sku && p.sku.toLowerCase() === searchQ) ||
            (p.name && p.name.toLowerCase() === searchQ)
        );

        if (product) {
            if (window.directAddToPOSBill) {
                window.directAddToPOSBill(product.docId);
            } else {
                window.addToPOSBill(product.docId); // Fallback
            }
            window.showToast(`✅ Added to POS: ${product.name}`, "success");
            const sound = document.getElementById('sound-pos-save');
            if (sound) sound.play().catch(() => {});
        } else {
            window.showToast("❌ Product code not recognized", "warning");
        }
     }
};

// --- Inline POS Auto-Scanner Logic ---
let inlineHtml5QrCode = null;
let isInlineScannerRunning = false;

window.startInlineAutoScan = async () => {
    const wrap = document.getElementById('pos-inline-scanner-preview-wrap');
    if (!wrap) return;

    if (isInlineScannerRunning) return;

    wrap.style.display = 'block';
    if (!inlineHtml5QrCode) {
        inlineHtml5QrCode = new Html5Qrcode("pos-inline-scanner-reader");
    }

    const config = {
        fps: 24,
        aspectRatio: 1.0
    };

    try {
        await inlineHtml5QrCode.start(
            { facingMode: "environment" },
            config,
            (decodedText) => {
                const q = decodedText.trim();
                const sound = document.getElementById('sound-pos-save');
                if (sound) sound.play().catch(() => {});
                window.handleInlineScanResult(q);
            }
        );
        isInlineScannerRunning = true;
        console.log("Inline Auto-Scan active.");
    } catch (err) {
        console.error("Inline Auto-Scan Error:", err);
        wrap.style.display = 'none';
    }
};

window.stopInlineAutoScan = async () => {
    if (!isInlineScannerRunning) return;

    const wrap = document.getElementById('pos-inline-scanner-preview-wrap');
    if (inlineHtml5QrCode && inlineHtml5QrCode.isScanning) {
        try {
            await inlineHtml5QrCode.stop();
        } catch (err) {
            console.error("Error stopping inline scanner:", err);
        }
    }
    if (wrap) wrap.style.display = 'none';
    isInlineScannerRunning = false;
    console.log("Inline Auto-Scan stopped.");
};

window.togglePOSAutoScanSetting = (enabled) => {
    localStorage.setItem('mec_pos_auto_scan', enabled ? 'true' : 'false');
    if (enabled) {
        window.showToast("📷 Auto-Scanner enabled! It will start automatically when opening POS terminal.", "success");
        // Start immediately if we are currently on the POS tab
        if (window.currentActiveTab === 'pos') {
            window.startInlineAutoScan();
        }
    } else {
        window.showToast("✅ Auto-Scanner disabled.", "info");
        window.stopInlineAutoScan();
    }
};

window.handleInlineScanResult = (q) => {
    const cleanQ = q.trim();
    if (!cleanQ) return;

    const lowerQ = cleanQ.toLowerCase();
    
    // 1. Try to match a product SKU/barcode
    const product = (window.allProducts || []).find(p => 
        (p.sku && p.sku.toLowerCase() === lowerQ) ||
        (p.name && p.name.toLowerCase() === lowerQ)
    );

    if (product) {
        if (window.addToPOSBill) {
            if (window.directAddToPOSBill) {
                window.directAddToPOSBill(product.docId);
            } else {
                window.addToPOSBill(product.docId);
            }
            window.showToast(`✅ Added to POS: ${product.name}`, "success");
        }
        return;
    }

    // 2. Try to match a customer (phone / loyalty card)
    const customer = (window.allCustomers || []).find(c => {
        const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
        const qClean = lowerQ.replace(/\s/g, '');
        const cPhoneNormalized = cPhone.replace(/^0/, '');
        const qCleanNormalized = qClean.replace(/^0/, '');

        const phoneMatch = (cPhone === qClean) || 
                           (cPhoneNormalized === qCleanNormalized) ||
                           (cPhone.endsWith(qClean) && qClean.length >= 9) || 
                           (cPhoneNormalized.startsWith(qCleanNormalized) && qCleanNormalized.length >= 7);
                           
        const cardMatch = (c.loyaltyCardNo && c.loyaltyCardNo.toLowerCase() === lowerQ);
        
        return phoneMatch || cardMatch;
    });

    if (customer) {
        const phoneInput = document.getElementById('pos-cust-phone');
        if (phoneInput) {
            phoneInput.value = customer.loyaltyCardNo || customer.phone || cleanQ;
        }
        window.lookupPOSCustomer(customer.loyaltyCardNo || customer.phone || cleanQ);
        return;
    }

    window.showToast(`❌ Scanned code not recognized: ${cleanQ}`, "warning");
};

// --- UI Helper Logic ---
window.openModal = (id) => {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent background scroll
    }
};

window.closeModal = (id) => {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto'; // Restore scroll
    }
};

// Close modals when clicking outside
window.onclick = (event) => {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
};
// Maintain compatibility between modules and old global-based receipt logic
Object.defineProperty(window, 'currentPOSBill', {
    get: function() {
        if (typeof window.getActiveBill === 'function') {
            const bill = window.getActiveBill();
            return (bill && bill.items) ? bill.items : [];
        }
        return [];
    },
    configurable: true
});
import { signInWithEmailAndPassword } from "firebase/auth";
import {
    collection,
    onSnapshot,
    doc,
    updateDoc,
    deleteDoc,
    addDoc,
    query,
    orderBy,
    where,
    limit,
    serverTimestamp,
    getDocs,
    getDoc,
    setDoc,
    writeBatch,
    Timestamp
} from "firebase/firestore";

window.applyLowEndOptimizations = () => {
    const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
    if (isLowEnd) {
        document.body.classList.add('low-end-mode');
        console.log("⚡ Low-End Performance Optimizations Applied (Blurs, Shadows & Animations disabled)");
    } else {
        document.body.classList.remove('low-end-mode');
    }
};

// --- Requirement: Sync Updates & Clean Session ---
window.addEventListener('DOMContentLoaded', () => {
    window.applyLowEndOptimizations();
    // 1. Instantly ensure splash screen doesn't block interactions after a short grace period
    const splash = document.getElementById('splash-screen');
    if (splash) {
        // [v3.12.50] Safety: Force hide splash faster to prevent non-responsive UI
        setTimeout(() => {
            splash.style.transition = 'opacity 0.4s ease-out';
            splash.style.opacity = '0';
            splash.style.pointerEvents = 'none';
            setTimeout(() => {
                splash.style.display = 'none';
                
                // [BACKUP] Trigger Daily Automated Backup
                if (typeof initAutoBackup === 'function') initAutoBackup();

                // [NEW] Auto-focus the login input after splash hides
                const loginSection = document.getElementById('login-section');
                const adminEmailField = document.getElementById('login-email');
                if (loginSection && loginSection.style.display !== 'none' && adminEmailField) {
                    adminEmailField.focus();
                }
            }, 400);
        }, 300); // 300ms is enough for initial paint
    }

    window.manualSyncFirestore = async () => {
        if (!navigator.onLine) {
            window.showToast("❌ Offline Mode: Cannot manual sync right now!", "error");
            return;
        }
        window.showToast("📡 Starting manual synchronization...", "info");
        try {
            const { waitForPendingWrites } = await import("firebase/firestore");
            await waitForPendingWrites(db);
            window.showToast("✅ Manual Sync Successful! All local data uploaded.", "success");
        } catch (err) {
            console.error(err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        }
    };

    // --- Connectivity Management ---
    let firestoreIsReachable = true;
    
    // Connectivity health check throttled to avoid noise
    const checkFirestoreHealth = async () => {
        if (!navigator.onLine) {
            firestoreIsReachable = false;
            updateConnectivityStatus();
            return;
        }
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2500); // 2.5 seconds timeout
        
        try {
            // Ping own domain to verify active internet connectivity
            await fetch('/csharp_version.json', { 
                mode: 'no-cors', 
                signal: controller.signal,
                cache: 'no-store'
            });
            firestoreIsReachable = true;
        } catch (e) {
            firestoreIsReachable = false;
        } finally {
            clearTimeout(timeoutId);
        }
        updateConnectivityStatus();
    };

    const updateConnectivityStatus = () => {
        const statusDiv = document.getElementById('conn-status');
        const statusText = document.getElementById('conn-text');
        if (!statusDiv || !statusText) return;

        if (!statusDiv.onclick) {
            statusDiv.onclick = window.manualSyncFirestore;
            statusDiv.title = "Click to manually upload local data to cloud";
            statusDiv.style.cursor = "pointer";
        }

        // True "Online" means navigator says yes AND Firestore is reachable
        if (navigator.onLine && firestoreIsReachable) {
            statusDiv.classList.remove('offline');
            statusDiv.classList.add('online');
            statusText.innerText = 'Cloud Online';
            if (window._wasOffline) {
                window.showToast("☁️ Back Online: Syncing changes...", "success");
                window._wasOffline = false;
            }
        } else {
            statusDiv.classList.remove('online');
            statusDiv.classList.add('offline');
            statusText.innerText = navigator.onLine ? 'Backend Lagging' : 'Offline Mode';
            
            if (!window._wasOffline) {
                if (!navigator.onLine) {
                    window.showToast("🔌 Offline: Working on Local Buffer", "warning");
                } else {
                    window.showToast("⏳ Sync Delay: Cloud unreachable", "info");
                }
                window._wasOffline = true;
            }
        }
    };

    window.addEventListener('online', () => { 
        updateConnectivityStatus(); 
        checkFirestoreHealth(); 
    });
    window.addEventListener('offline', () => {
        firestoreIsReachable = false;
        updateConnectivityStatus();
    });
    
    // Run initial and periodic health checks (lightweight interval)
    updateConnectivityStatus();
    checkFirestoreHealth();
    setInterval(checkFirestoreHealth, 45000); // Check every 45 seconds to keep CPU cool

    // --- Initialize Domain Modules (Safe Execution) ---
    try {
        initSystemBroadcastListener();
        if (typeof window.initSystem === 'function') window.initSystem();
        if (typeof window.initTheme === 'function') window.initTheme();
        if (typeof window.initAuth === 'function') window.initAuth();
        if (typeof window.initPromotions === 'function') window.initPromotions();
        if (typeof window.initInventory === 'function') window.initInventory();
        if (typeof window.initOrders === 'function') window.initOrders();
        if (typeof window.initFinance === 'function') window.initFinance();
        if (typeof window.initBankManager === 'function') window.initBankManager();
        if (typeof window.initPOS === 'function') window.initPOS();
        if (typeof window.initRepairs === 'function') window.initRepairs();
        if (typeof window.initReports === 'function') window.initReports();
        if (typeof window.initMRP === 'function') window.initMRP();
        if (typeof window.initHRM === 'function') window.initHRM();
        if (typeof window.initSupplyChain === 'function') window.initSupplyChain();
        initReloadModule(); // [FIXED] Initialize Reload Terminal listeners
        if (typeof window.loadSystemSettings === 'function') window.loadSystemSettings();

        // [NEW] Default all date inputs to today if empty
        const today = window.getLocalYYYYMMDD();
        document.querySelectorAll('input[type="date"]').forEach(input => {
            if (!input.value) input.value = today;
        });

        // [NEW] Initialize Desktop Window Controls for Admin Header
        const isDesktopApp = !!window.electron || !!window.electronAPI || !!window.chrome?.webview;
        document.getElementById('btn-close')?.addEventListener('click', () => {
            if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'close' });
            else if (window.electronAPI) window.electronAPI.close?.();
            else if (window.electron) window.electron.close?.();
        });
        document.getElementById('btn-minimize')?.addEventListener('click', () => {
            if (window.chrome?.webview) window.chrome.webview.postMessage({ type: 'minimize' });
            else if (window.electronAPI) window.electronAPI.minimize?.();
            else if (window.electron) window.electron.minimize?.();
        });

        // Diagnostics (Lightweight)
        setTimeout(() => {
            const prodSize = window.allProducts ? window.allProducts.length : 0;
            const orderSize = window.allOrders ? window.allOrders.length : 0;
            const branchSize = window.allBranches ? window.allBranches.length : 0;
            console.log("📊 SYNC REPORT:", { products: prodSize, orders: orderSize, branches: branchSize });
        }, 5000);
    } catch (e) {
        console.error("🏁 Startup Initialization Error:", e);
        // Force hide splash on critical fail so user can at least see the page
        const s = document.getElementById('splash-screen');
        if (s) s.style.display = 'none';
    }
});

// --- Global Error Capture for Debugging ---
window.addEventListener('error', (e) => {
    console.error("CRITICAL RUNTIME ERROR:", e.error);
    if (window.showToast) {
        window.showToast("⚠️ System Error: " + (e.error?.message || "Internal Crash"), "error");
    }
});

// --- Admin PWA & Session Protection ---
let deferredPrompt;
const installBtn = document.createElement('div');
installBtn.id = 'admin-install-banner';
installBtn.innerHTML = `
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:#002060; color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: adminSlideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC Admin</div>
            <div style="font-size:0.75rem; opacity:0.9;">Separate app for orders & stock</div>
        </div>
        <button id="pwa-close-admin" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes adminSlideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;
installBtn.style.display = 'none';
document.body.appendChild(installBtn);

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.style.display = 'block';
});

installBtn.addEventListener('click', async (e) => {
    if (e.target.id === 'pwa-close-admin') {
        installBtn.style.display = 'none';
        return;
    }
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') installBtn.style.display = 'none';
        deferredPrompt = null;
    }
});

// --- Notification Toast Utility ---
let lastToastTime = 0;
let lastToastMessage = "";

window.showToast = (message, type = 'info') => {
    const now = Date.now();
    if (now - lastToastTime < 1000 && lastToastMessage === message) return;
    lastToastTime = now;
    lastToastMessage = message;

    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast admin-notif ${type}`;
    let icon = '🔔';
    let text = message;
    const emojiMatch = message.match(/^([\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27BF])/);
    if (emojiMatch) {
        icon = emojiMatch[0];
        text = message.replace(icon, '').trim();
    }

    toast.innerHTML = `
        <span class="toast-icon">${icon}</span>
        <span class="toast-message">${text}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 5000);
};

// --- Custom Prompt & Confirmation Modal (Electron/Premium Compat) ---
window.asyncPrompt = (message, title = "Security Verification", inputType = "password", defaultValue = "") => {
    return new Promise((resolve) => {
        const isMulti = inputType === 'textarea' || (typeof defaultValue === 'string' && defaultValue.includes('\n'));
        const overlay = document.createElement('div');
        overlay.id = 'mec-custom-modal-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:${isMulti ? '520px' : '400px'}; max-width:92vw; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        const inputHtml = isMulti 
            ? `<textarea id="mec-modal-input" placeholder="Enter message..." style="width:100%; height:180px; box-sizing:border-box; background:rgba(0,0,0,0.3); border:1px solid rgba(56,189,248,0.3); padding:0.85rem; border-radius:12px; color:white; font-size:0.9rem; margin-bottom:1.5rem; outline:none; resize:vertical; font-family:monospace; line-height:1.5;">${defaultValue}</textarea>`
            : `<input type="${inputType}" id="mec-modal-input" value="${defaultValue}" placeholder="Enter details..." style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:1.5rem; outline:none; focus:border:#38bdf8;">`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#38bdf8; margin-bottom:0.5rem; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-shield-halved"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.2rem; line-height:1.5;">${message}</div>
            ${inputHtml}
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="modal-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600; transition:0.2s;">Cancel</button>
                <button id="modal-ok" style="background:linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%); color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(37,99,235,0.3);">Continue <i class="fa-solid fa-arrow-right" style="margin-left:5px; font-size:0.8rem;"></i></button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        // Animation
        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        });

        const input = document.getElementById('mec-modal-input');
        const ok = document.getElementById('modal-ok');
        const cancel = document.getElementById('modal-cancel');

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        ok.onclick = () => finish(input.value);
        cancel.onclick = () => finish(null);
        input.onkeydown = (e) => { 
            if(e.key === 'Enter' && (!isMulti || e.ctrlKey)) {
                e.preventDefault();
                ok.click();
            }
            if(e.key === 'Escape') cancel.click();
        };
        input.focus();
    });
};

window.asyncAuthPrompt = (message, title = "Admin Required") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.id = 'mec-auth-prompt-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:400px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid #ef4444; transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#ef4444; margin-bottom:0.5rem; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-lock"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.5rem; line-height:1.5;">${message}</div>
            <input type="text" id="mec-auth-user" placeholder="Username (e.g. admin@mec.lk)" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:0.8rem; outline:none; focus:border:#ef4444;">
            <input type="password" id="mec-auth-pass" placeholder="Password" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; margin-bottom:1.5rem; outline:none; focus:border:#ef4444;">
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="auth-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600; transition:0.2s;">Cancel</button>
                <button id="auth-ok" style="background:linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(239,68,68,0.3);">Verify & Execute</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
            document.getElementById('mec-auth-user').focus();
        });

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        const submitAuth = () => {
            const user = document.getElementById('mec-auth-user').value.trim();
            const pass = document.getElementById('mec-auth-pass').value;
            finish({ user, pass });
        };

        document.getElementById('auth-ok').onclick = submitAuth;
        document.getElementById('auth-cancel').onclick = () => finish(null);
        document.getElementById('mec-auth-pass').onkeydown = (e) => { if (e.key === 'Enter') submitAuth(); };
    });
};


window.asyncConfirm = (message, title = "Verification Required") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:400px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#ef4444; margin-bottom:0.5rem;"><i class="fa-solid fa-triangle-exclamation"></i> ${title}</div>
            <div style="font-size:0.95rem; opacity:0.9; margin-bottom:1.5rem; line-height:1.5;">${message}</div>
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="conf-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600;">Cancel</button>
                <button id="conf-ok" style="background:#ef4444; color:white; border:none; padding:0.8rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:700; box-shadow:0 10px 15px -3px rgba(239,68,68,0.3);">Confirm Delete</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        });

        const ok = document.getElementById('conf-ok');
        const cancel = document.getElementById('conf-cancel');

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        ok.onclick = () => finish(true);
        cancel.onclick = () => finish(false);
        overlay.onclick = (e) => { if (e.target === overlay) cancel.click(); };
    });
};

window.showDeleteOrVoidModal = ({ title = "Permanent Delete Confirmation", operatorInfo = "CEO / SUPER ADMIN", targetName = "this order" } = {}) => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.id = 'mec-delete-choice-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:9999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:460px; max-width:92vw; box-shadow:0 25px 60px -12px rgba(0,0,0,0.7), 0 0 25px rgba(239,68,68,0.25); border:1px solid rgba(239,68,68,0.4); transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', system-ui, sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.25rem; color:#f87171; margin-bottom:0.6rem; display:flex; align-items:center; gap:10px;">
                <i class="fa-solid fa-triangle-exclamation"></i> ${title}
            </div>
            <div style="background:rgba(239, 68, 68, 0.1); border:1px solid rgba(239, 68, 68, 0.25); padding:10px 14px; border-radius:12px; font-size:0.85rem; font-weight:700; color:#fca5a5; margin-bottom:1.2rem; display:flex; align-items:center; gap:8px;">
                <span>🚨</span> <span>${operatorInfo.toUpperCase()} DETECTED</span>
            </div>
            <div style="font-size:0.92rem; color:#cbd5e1; margin-bottom:1.2rem; line-height:1.5;">
                Select how you want to process <strong>${targetName}</strong>:
            </div>

            <div style="margin-bottom:1.5rem;">
                <label style="display:block; font-size:0.75rem; font-weight:800; color:#94a3b8; text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">
                    Choose Action (ක්‍රියාව තෝරන්න):
                </label>
                <select id="mec-delete-action-select" style="width:100%; box-sizing:border-box; background:#0f172a; border:2px solid rgba(239, 68, 68, 0.5); padding:0.9rem 1rem; border-radius:12px; color:#ffffff; font-size:0.95rem; font-weight:700; outline:none; cursor:pointer;">
                    <option value="DELETE" selected>🗑️ Permanent Delete (Database එකෙන් මුළුමනින්ම මකා දමන්න)</option>
                    <option value="VOID">🚫 Void Bill (Cancel / Void කර Records වල තබාගන්න)</option>
                </select>
                <div id="mec-delete-action-hint" style="font-size:0.78rem; color:#ef4444; margin-top:8px; font-weight:600; line-height:1.4;">
                    ⚠️ Permanent Delete: Database එකෙන් Record එක මුළුමනින්ම මකා දැමේ (Cannot be undone).
                </div>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="mec-choice-cancel" style="background:rgba(255,255,255,0.06); color:#94a3b8; border:1px solid rgba(255,255,255,0.1); padding:0.8rem 1.4rem; border-radius:12px; cursor:pointer; font-weight:700; transition:0.2s;">Cancel</button>
                <button id="mec-choice-ok" style="background:linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); color:white; border:none; padding:0.8rem 1.6rem; border-radius:12px; cursor:pointer; font-weight:800; box-shadow:0 10px 20px -3px rgba(239,68,68,0.4); display:inline-flex; align-items:center; gap:6px;">
                    <span id="mec-choice-btn-text">Confirm Delete</span>
                    <i class="fa-solid fa-arrow-right" style="font-size:0.8rem;"></i>
                </button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        });

        const selectEl = document.getElementById('mec-delete-action-select');
        const hintEl = document.getElementById('mec-delete-action-hint');
        const okBtn = document.getElementById('mec-choice-ok');
        const cancelBtn = document.getElementById('mec-choice-cancel');
        const btnText = document.getElementById('mec-choice-btn-text');

        selectEl.onchange = () => {
            if (selectEl.value === 'DELETE') {
                hintEl.innerHTML = "⚠️ Permanent Delete: Database එකෙන් Record එක මුළුමනින්ම මකා දැමේ (Cannot be undone).";
                hintEl.style.color = "#ef4444";
                selectEl.style.borderColor = "rgba(239, 68, 68, 0.6)";
                okBtn.style.background = "linear-gradient(135deg, #ef4444 0%, #b91c1c 100%)";
                btnText.innerText = "Confirm Delete";
            } else {
                hintEl.innerHTML = "ℹ️ Void: Record එක 'Voided' ලෙස සටහන් වන අතර History & Reports වල ඉතිරි වේ.";
                hintEl.style.color = "#f59e0b";
                selectEl.style.borderColor = "rgba(245, 158, 11, 0.6)";
                okBtn.style.background = "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)";
                btnText.innerText = "Confirm Void";
            }
        };

        const finish = (val) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(val); }, 200);
        };

        okBtn.onclick = () => finish(selectEl.value);
        cancelBtn.onclick = () => finish(null);
    });
};


// --- Admin Credentials moved to auth.js ---

const loginSection = document.getElementById('login-section');
const adminActions = document.getElementById('admin-actions');
const productListDiv = document.getElementById('admin-product-list');

const productsCol = collection(db, 'products');
const ordersCol = collection(db, 'orders');
const categoriesCol = collection(db, 'categories');
const expensesCol = collection(db, 'expenses');
const purchasesCol = collection(db, 'purchases');
const suppliersCol = collection(db, 'suppliers');
const incomeCol = collection(db, 'income');
const customersCol = collection(db, 'customers');
const employeesCol = collection(db, 'employees');
const attendanceCol = collection(db, 'attendance');
const payrollCol = collection(db, 'payroll');
const branchesCol = collection(db, 'branches');
const storesCol = collection(db, 'stores');
const repairJobsCol = collection(db, 'repairJobs');
const sinvoicesCol = collection(db, 'supplierInvoices');

let activeBranchFilter = 'All'; // Moved up to prevent RefError during snap load

window.currentInvoiceItems = [];
window.allSupplierInvoices = [];



// --- ERP System Logging ---
window.logAction = async (action, details = "") => {
    try {
        const storeId = window.getStoreId();
        const user = sessionStorage.getItem('userEmail') || 'Unknown';
        const role = sessionStorage.getItem('userRole') || 'None';
        
        await addDoc(collection(db, 'systemLogs'), {
            timestamp: serverTimestamp(),
            action,
            details,
            user,
            role,
            storeId,
            clientVersion: CLIENT_VERSION
        });
        
        // Update IT logs if visible
        const logContainer = document.getElementById('it-activity-logs');
        if (logContainer) {
            const entry = document.createElement('div');
            entry.style.padding = '0.75rem';
            entry.style.borderBottom = '1px solid #e2e8f0';
            entry.style.fontSize = '0.85rem';
            entry.innerHTML = `<span style="color:var(--primary-blue); font-weight:700;">[${new Date().toLocaleTimeString()}]</span> ${user} (${role}): <b>${action}</b> ${details}`;
            logContainer.prepend(entry);
        }
    } catch (e) { console.error("Log error:", e); }
};

// Global Security Check for Deletions
// Global Security Check for Deletions
// [v3.12.27] Enhanced: Soft-delete by default, Permanent only for SuperAdmin
window.verifyDeletePermission = async (docRef = null, softDeleteData = { status: 'Voided', isVoid: true }) => {
    const auth = await window.asyncAuthPrompt("Authorization required to remove this record.", "Security Verification");
    if (!auth) return false;

    // Resolve target store ID of the document
    let targetStoreId = null;
    if (docRef) {
        try {
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                targetStoreId = docSnap.data().storeId;
            }
        } catch (e) {
            console.error("Error fetching doc for storeId check:", e);
        }
    }
    if (!targetStoreId) {
        targetStoreId = window.getStoreId();
    }

    const userLower = auth.user.toLowerCase().trim();
    const passTrimmed = auth.pass.trim();

    const isSuperAdmin = (
        ( (userLower === 'malinduec@gmail.com' || userLower === 'malindu' || userLower === 'admin') && passTrimmed === 'malindu123' ) ||
        ( (userLower === 'mecposadmin@gmail.com' || userLower === 'admin' || userLower === 'admin@mec.lk') && passTrimmed === 'mecpos123' ) ||
        passTrimmed === 'malindu123' || passTrimmed === 'mecpos123' // Also allow just the master password
    );

    // MEC Book Shop CEO credentials: username: mecbookshop@gmail.com, pass: mec123
    const isMecCeo = ( (userLower === 'mecbookshop@gmail.com' || userLower === 'mecbookshop' || userLower === 'admin' || userLower === '') && passTrimmed === 'mec123' );
    const isMecStore = !targetStoreId || targetStoreId === 'mec-book-shop' || targetStoreId === 'mec-pos-shop' || targetStoreId === 'mec-pos' || targetStoreId === 'mec-pos-shop-v2';
    const isAuthorizedMecCeo = isMecCeo && isMecStore;

    // D & J Online Marketing CEO credentials: username: ireshadinali@gmail.com, pass: ireshadinali123
    const isDJCeo = ( (userLower === 'ireshadinali@gmail.com' || userLower === 'iresha' || userLower === 'admin') && passTrimmed === 'ireshadinali123' );
    const isDJStore = targetStoreId && (
        targetStoreId === 'd-and-j-online-marketing' ||
        targetStoreId === 'd-j-online-marketing' ||
        targetStoreId === 'd-and-j-online-mart' ||
        targetStoreId.includes('d-and-j') ||
        targetStoreId.includes('d-j') ||
        targetStoreId.includes('iresha') ||
        targetStoreId.includes('marketing')
    );
    const isAuthorizedDJCeo = isDJCeo && isDJStore;

    const isAuthorizedCeo = isAuthorizedMecCeo || isAuthorizedDJCeo;

    const isManager = (passTrimmed === 'mec123'); // Support legacy mec123 as manager pass

    const staff = (window.allEmployees || []).find(e => {
        const empPin = (e.pin || '').toString().trim();
        const empPass = (e.password || '').toString().trim();
        const empUser = (e.username || '').toLowerCase().trim();
        const empReg = (e.regno || '').toLowerCase().trim();
        const empEmail = (e.email || '').toLowerCase().trim();

        // 1. Direct PIN match in password or user field
        if (empPin && (empPin === passTrimmed || empPin === userLower)) return true;

        // 2. Matched by username/regno/email with password OR pin
        if (empUser === userLower || empReg === userLower || empEmail === userLower) {
            if (empPass && empPass === passTrimmed) return true;
            if (empPin && empPin === passTrimmed) return true;
        }

        return false;
    });

    const topTierRoles = ['CEO / Founder', 'Proprietor / Owner', 'Admin', 'SuperAdmin', 'CEO_Admin', 'Owner', 'CEO', 'Proprietor', 'Founder', 'Super Admin'];
    
    let isTopRole = isSuperAdmin || isAuthorizedCeo;
    let authorizerName = auth.user;
    let authorizerRole = 'Admin';

    if (staff) {
        authorizerName = staff.name || staff.fullName || staff.username || auth.user;
        authorizerRole = staff.role_access || staff.designation || 'Staff';
        const normRole = authorizerRole.toLowerCase().trim();
        if (topTierRoles.some(r => normRole.includes(r.toLowerCase()))) {
            isTopRole = true;
        }
    } else if (isSuperAdmin) {
        authorizerName = userLower.includes('malindu') ? 'Malindu Shamesh' : 'System Admin';
        authorizerRole = 'CEO / Founder';
    } else if (isAuthorizedMecCeo) {
        authorizerName = 'MEC Owner';
        authorizerRole = 'Proprietor / Owner';
    } else if (isAuthorizedDJCeo) {
        authorizerName = 'D&J Owner';
        authorizerRole = 'Proprietor / Owner';
    }

    if (isTopRole) {
        // Top-Tier Roles (CEO / Founder, Owner, Admin, SuperAdmin): Show Permanent Delete Confirmation Modal
        let operatorInfo = `${authorizerRole} (${authorizerName})`;
        const choice = await window.showDeleteOrVoidModal({
            title: "Permanent Delete Confirmation",
            operatorInfo: operatorInfo,
            targetName: "this record"
        });
        
        if (choice === null) {
            return false; // User cancelled
        }
        if (choice === 'DELETE') {
            return true; // Return true to let caller run hard deleteDoc()
        } else {
            // Soft delete / void instead
            if (docRef) {
                window.showToast("⏳ Voiding record instead of deletion...", "info");
                await updateDoc(docRef, { 
                    ...softDeleteData, 
                    status: 'Voided',
                    voidedBy: authorizerName, 
                    voidedByRole: authorizerRole,
                    voidedAt: serverTimestamp(),
                    updatedAt: serverTimestamp() 
                });
                window.showToast(`✅ Record VOIDED by ${authorizerName} (${authorizerRole}).`, "success");
            }
            return false;
        }
    } else {
        // Non-Top Roles (Sales Cashier, Store Keeper, Technician, etc.): Automatic Soft-Void with Audit Log
        if (docRef) {
            window.showToast(`⏳ Voiding record authorized by ${authorizerName} (${authorizerRole})...`, "info");
            await updateDoc(docRef, { 
                ...softDeleteData, 
                status: 'Voided',
                voidedBy: authorizerName, 
                voidedByRole: authorizerRole,
                voidedAt: serverTimestamp(),
                updatedAt: serverTimestamp() 
            });
            window.showToast(`✅ Record VOIDED by ${authorizerName} (${authorizerRole}) (Only CEO/Owner/Admin can hard delete).`, "success");
        } else {
            window.showToast("❌ Permanent delete restricted to CEO / Founder, Owner, Admin & SuperAdmin.", "error");
        }
        return false;
    }
};

// --- Theme Logic extracted to src/modules/theme.js ---

// Helper to filter data by current store
window.filterByStore = (list) => {
    const storeId = window.getStoreId();
    if (!list) return [];
    
    // Explicitly allow main MEC slugs to see data without a storeId (backward compatibility)
    const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'mec-pos-shop-v2');
    
    const filtered = list.filter(item => {
        if (storeId === 'master') return true; // Master account sees everything
        
        // Match by storeId directly
        if (item.storeId === storeId) return true;
        
        // Match by storeSlug or slug field (some employees stored with numeric storeId + slug)
        if (item.storeSlug === storeId || item.slug === storeId) return true;
        
        // MEC Book Shop: allow items without storeId, or with known MEC store identifiers
        if (isMainMec && (
            !item.storeId ||
            item.storeId === 'mec-book-shop' ||
            item.storeId === 'mec-pos-shop' ||
            item.storeId === 'mec-pos' ||
            item.storeId === 'mec-pos-shop-v2' ||
            item.storeId === 'mecbookshop' ||
            item.storeSlug === 'mec-book-shop' ||
            item.slug === 'mec-book-shop'
        )) return true;
        
        return false;
    });
    
    if (list.length > 0 && filtered.length === 0) {
        console.warn(`Filter active: ${list.length} total items, 0 visible for store: ${storeId}`);
    }
    
    return filtered;
};

// --- Branding Logic extracted to system.js ---

// [FIX] Removed duplicate unfiltered employees snapshot listener to prevent cross-tenant data leak.
// All employee listening and filtering is consolidated inside modules/auth.js.




window.currentInvoiceItems = window.currentInvoiceItems || []; // Ensure initialization

// Consolidated Supplier Item Modal controls moved to Supplier Invoice section (line 5370+)


window._adminProductLetterFilter = ''; // Globalization for alphabet filter

// --- Admin Theme Logic extracted to theme module ---

// --- UI Versioning moved to system.js ---

document.addEventListener('DOMContentLoaded', () => {
    // UI Version and Branding handled by system.js
    
    // Add Enter key listener for Login
    const loginEmail = document.getElementById('login-email');
    const loginPass = document.getElementById('login-password');
    const loginBtn = document.getElementById('login-btn');

    const handleEnter = (e) => {
        if (e.key === 'Enter') {
            loginBtn?.click();
        }
    };

    loginEmail?.addEventListener('keydown', handleEnter);
    loginPass?.addEventListener('keydown', handleEnter);

    // Clock logic is now running independently inside admin.html

    // Re-apply saved theme
    // (Handled by theme module)
});

// --- Auth Listeners and RBAC extracted to auth.js ---

    // Immediately apply cached store branding and subscription details if available
    const cachedStoreId = sessionStorage.getItem('userStoreId') || sessionStorage.getItem('tempStoreSlug') || 'mec-book-shop';
    
    // Load from C# Native Wrapper cache for instant loading without being affected by WebView clear cache
    loadOfflineCache(`storeInfo_${cachedStoreId}`).then(cachedStore => {
        if (cachedStore) {
            window.storeInfo = cachedStore;
            const brandName = cachedStore.name || 'MEC BOOK SHOP';
            
            // Update Text
            document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
                el.innerText = brandName;
            });

            if (cachedStore.logoUrl) {
                document.querySelectorAll('.login-header img, #admin-install-banner img').forEach(img => {
                    img.src = cachedStore.logoUrl;
                });
            }

            // Update Sidebar Subscription Info
            if (typeof window.updateSidebarSubscription === 'function') {
                window.updateSidebarSubscription(cachedStore);
            }

            // Update Header Website Button URL immediately from cache
            const webBtn = document.getElementById('header-website-btn');
            if (webBtn) {
                const webUrl = (typeof window.getStoreWebsiteUrl === 'function') 
                    ? window.getStoreWebsiteUrl(cachedStore) 
                    : (cachedStore.domain ? `https://${cachedStore.domain}` : (cachedStore.slug === 'mec-book-shop' || !cachedStore.slug ? 'https://mecbookshop.web.lk' : `https://mecpos.web.lk/store/${cachedStore.slug}`));
                webBtn.href = webUrl;
                webBtn.title = `Website: ${webUrl}`;
                webBtn.onclick = (e) => {
                    e.preventDefault();
                    if (typeof window.openStoreWebsite === 'function') {
                        window.openStoreWebsite(cachedStore);
                    } else if (typeof window.openExternalUrl === 'function') {
                        window.openExternalUrl(webUrl);
                    } else {
                        window.open(webUrl, '_blank');
                    }
                };
            }
        }
    });

    // Load Stores
    onSnapshot(storesCol, (snapshot) => {
        const stores = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allStores = stores;
        renderStoresUI(stores);

        // Dynamic branding for entire panel
        const currentStoreId = window.getStoreId();
        let storeInfo = stores.find(s => s.slug === currentStoreId);
        
        if (!storeInfo && (currentStoreId === 'mec-book-shop' || currentStoreId === 'mec-pos-shop' || currentStoreId === 'master' || !currentStoreId)) {
            storeInfo = stores.find(s => s.slug === 'mec-pos-shop' || s.slug === 'mec-book-shop');
            if (!storeInfo) storeInfo = stores[0];
        }

        if (storeInfo) {
            if (storeInfo.slug === 'mec-book-shop' || storeInfo.slug === 'mec-pos-shop' || !storeInfo.slug) {
                if (!storeInfo.logoUrl || storeInfo.logoUrl.includes('/logo.png') || storeInfo.logoUrl.includes('zenith_logo')) {
                    storeInfo.logoUrl = '/mec-logo.png';
                }
                if (!storeInfo.name) {
                    storeInfo.name = 'MEC Book Shop';
                }
            }

            window.storeInfo = storeInfo;
            const brandName = storeInfo.name || 'MEC BOOK SHOP';
            
            // Dynamic Merchant Company Name in Sidebar Header
            document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
                el.innerText = brandName;
            });

            // App Software Logo fixed in Sidebar (.nav-brand img)
            document.querySelectorAll('.nav-brand img').forEach(img => {
                img.src = './pos-logo.png';
                img.onerror = function() {
                    this.onerror = null;
                    this.src = './logo.png';
                };
            });

            const effectiveLogo = (storeInfo.logoUrl && !storeInfo.logoUrl.includes('/logo.png') && !storeInfo.logoUrl.includes('zenith_logo')) 
                ? storeInfo.logoUrl 
                : '/mec-logo.png';

            document.querySelectorAll('.login-header img, #admin-install-banner img').forEach(img => {
                img.src = effectiveLogo;
            });

            // Update Sidebar Subscription Info
            if (typeof window.updateSidebarSubscription === 'function') {
                window.updateSidebarSubscription(storeInfo);
            }

            // Update Header Website Button URL dynamically
            const webBtn = document.getElementById('header-website-btn');
            if (webBtn) {
                const webUrl = (typeof window.getStoreWebsiteUrl === 'function') 
                    ? window.getStoreWebsiteUrl(storeInfo) 
                    : (storeInfo.domain ? `https://${storeInfo.domain}` : (storeInfo.slug === 'mec-book-shop' || !storeInfo.slug ? 'https://mecbookshop.web.lk' : `https://mecpos.web.lk/store/${storeInfo.slug}`));
                webBtn.href = webUrl;
                webBtn.title = `Website: ${webUrl}`;
                webBtn.onclick = (e) => {
                    e.preventDefault();
                    if (typeof window.openStoreWebsite === 'function') {
                        window.openStoreWebsite(storeInfo);
                    } else if (typeof window.openExternalUrl === 'function') {
                        window.openExternalUrl(webUrl);
                    } else {
                        window.open(webUrl, '_blank');
                    }
                };
            }
        }
    });

    // Branches and Stores are still managed here as they are global
    const storeId = window.getStoreId();
    const isMaster = storeId === 'master';

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    threeMonthsAgo.setHours(0,0,0,0);
    const threeMonthsAgoTimestamp = Timestamp.fromDate(threeMonthsAgo);

    const branchQ = isMaster ? branchesCol : query(branchesCol, where('storeId', '==', storeId));
    const categoriesQ = isMaster ? categoriesCol : query(categoriesCol, where('storeId', '==', storeId));
    const suppliersQ = isMaster ? suppliersCol : query(suppliersCol, where('storeId', '==', storeId));
    const customersQ = isMaster ? customersCol : query(customersCol, where('storeId', '==', storeId));

    // Limit transactional queries to past 3 months
    const attendanceQ = isMaster ?
        query(attendanceCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(attendanceCol, where('storeId', '==', storeId));
    const payrollQ = isMaster ?
        query(payrollCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(payrollCol, where('storeId', '==', storeId));
    const purchasesQ = isMaster ?
        query(purchasesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(purchasesCol, where('storeId', '==', storeId));
    const incomeQ = isMaster ?
        query(incomeCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(incomeCol, where('storeId', '==', storeId));
    const sinvoicesQ = isMaster ?
        query(sinvoicesCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(sinvoicesCol, where('storeId', '==', storeId));

    const filterPastThreeMonths = (rawList) => {
        return rawList.filter(item => {
            const timeSecs = item.timestamp?.seconds || 0;
            return timeSecs >= threeMonthsAgoTimestamp.seconds;
        });
    };
    
    // Activity logs query: limit 100 per store, sorted client-side to prevent composite index errors
    const logsQuery = isMaster ? 
        query(collection(db, 'systemLogs'), orderBy("timestamp", "desc"), limit(100)) :
        query(collection(db, 'systemLogs'), where('storeId', '==', storeId), limit(100));

    onSnapshot(branchQ, (snapshot) => {
        const branches = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allBranches = branches;
        renderBranchesUI(branches);
        populateBranchDropdowns(branches);
        updateUserDisplay();
    });

    // NOTE: Products and Orders listeners are now managed in inventory.js and orders.js 
    // to avoid duplicate subscriptions and state conflicts. Logic for POS numbering 
    // and notifications is also centralized in the respective modules.

    onSnapshot(attendanceQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allAttendance = isMaster ? raw : filterPastThreeMonths(raw);
        syncAttendanceUI();
    });

    onSnapshot(payrollQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allPayroll = isMaster ? raw : filterPastThreeMonths(raw);
        renderAdminPayrollUI(window.allPayroll);
    });

    onSnapshot(categoriesQ, (snapshot) => {
        const categories = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allCategories = categories;
        renderCategoriesUI(categories);
        populateCategoryDropdowns(categories);
        if (typeof window.renderCategoryWholesaleRules === 'function') window.renderCategoryWholesaleRules();
    });

    onSnapshot(purchasesQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allPurchases = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => renderPurchasesUI(window.allPurchases));
    });

    onSnapshot(suppliersQ, (snapshot) => {
        const suppliers = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id, id: doc.id }));
        window.allSuppliers = suppliers;
        requestAnimationFrame(() => {
            renderSuppliersUI(suppliers);
            if (window.populateSupplierInvoicesDropdown) window.populateSupplierInvoicesDropdown();
            if (typeof populateSupplierDropdowns === 'function') populateSupplierDropdowns(suppliers);
        });
    });

    onSnapshot(incomeQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allIncome = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => {
            renderIncomeUI(window.allIncome);
            if (window.allOrders && typeof window.generateReports === 'function') window.generateReports(window.allOrders);
        });
    });

    onSnapshot(sinvoicesQ, (snapshot) => {
        const raw = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allSupplierInvoices = isMaster ? raw : filterPastThreeMonths(raw);
        requestAnimationFrame(() => {
            if (typeof window.renderSupplierInvoicesUI === 'function') window.renderSupplierInvoicesUI(window.allSupplierInvoices);
            if (typeof window.renderSupplierOverview === 'function') window.renderSupplierOverview();
            renderPurchasesUI(); // Keep Purchase History tab in sync
        });
    });

    onSnapshot(customersQ, (snapshot) => {
        const customers = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allCustomers = customers; 
        requestAnimationFrame(() => {
            if (typeof window.renderCustomersUI === 'function') window.renderCustomersUI(customers);
            if (typeof window.renderCreditLedgerUI === 'function') window.renderCreditLedgerUI();
        });
    });

    initReloadModule();

    // IT System Logs Listener
    onSnapshot(logsQuery, (snapshot) => {
        const logContainer = document.getElementById('it-activity-logs');
        if (!logContainer) return;
        
        // Sort logs client-side by timestamp descending to support both filtered and master queries
        const sortedDocs = [...snapshot.docs].sort((a, b) => {
            const timeA = a.data().timestamp?.seconds || 0;
            const timeB = b.data().timestamp?.seconds || 0;
            return timeB - timeA;
        });

        logContainer.innerHTML = sortedDocs.map(doc => {
            const data = doc.data();
            const time = data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleTimeString() : '...';
            const date = data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : '';
            return `
                <div style="padding: 0.75rem; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; border-left: 3px solid ${data.role === 'Admin' ? '#ef4444' : '#3b82f6'};">
                    <span style="color:var(--text-muted); font-size:0.7rem;">${date} ${time}</span><br>
                    <span style="font-weight: 700; color: var(--primary-blue);">${data.user}</span> [${data.role}]: 
                    <b>${data.action}</b> ${data.details}
                </div>
            `;
        }).join('');
    });
  
// Global Collections Sync
onSnapshot(storesCol, (snapshot) => {
    const stores = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
    window.allStores = stores;
    if (typeof window.renderStoresUI === 'function') window.renderStoresUI(stores);

    const currentStoreId = window.getStoreId();
    let storeInfo = stores.find(s => s.slug === currentStoreId);
    
    if (!storeInfo && (currentStoreId === 'mec-book-shop' || currentStoreId === 'mec-pos-shop')) {
        storeInfo = stores.find(s => s.slug === 'mec-pos-shop' || s.slug === 'mec-book-shop') || stores[0];
    }

    if (storeInfo) {
        window.storeInfo = storeInfo;
        
        // Cache plan data locally for instant UI rendering on next startup
        try {
            const planDataStr = JSON.stringify(storeInfo);
            localStorage.setItem('mecpos_plan_cache', planDataStr);
            // Save to physical file via C# wrapper (user requested physical file save in app folder)
            if (window.chrome?.webview) {
                const unifiedCache = {
                    storeInfo: storeInfo,
                    systemConfig: window.systemConfig || {}
                };
                window.chrome.webview.postMessage({ type: 'savePlanConfig', data: JSON.stringify(unifiedCache) });
            }
        } catch (e) {
            console.warn("Failed to cache plan data", e);
        }

        const brandName = storeInfo.name || 'MEC BOOK SHOP';
        document.querySelectorAll('.nav-brand .main, #print-report-store-name').forEach(el => {
            el.innerText = brandName;
        });
        
        // Also ensure UI is updated with this new cached data
        if (window.showAdminActions) window.showAdminActions();
        if (window.updateSidebarSubscription) window.updateSidebarSubscription(storeInfo);
        
        // Render favorites and modules from local cache immediately
        if (window.systemConfig) {
            const favs = window.systemConfig.favorites || [];
            if (window.renderFavoritesSidebar) window.renderFavoritesSidebar(favs);
            if (window.renderFavoritesSettings) window.renderFavoritesSettings(favs);
            if (window.updateModulesVisibility && window.systemConfig.modules) {
                window.updateModulesVisibility(window.systemConfig.modules);
            }
        }
    }
});


// --- Modularized Data Listeners handled by domain init functions ---

// POS & Form Initializers
if (window.generatePOSReceiptNo) window.generatePOSReceiptNo();
if (window.handlePOSSearch) window.handlePOSSearch('');

const productForm = document.getElementById('product-form');
if (productForm) {
    productForm.onsubmit = async (e) => {
        e.preventDefault();
        if (window.addProduct) await window.addProduct(e);
    };
}
const editProductForm = document.getElementById('edit-product-form');
if (editProductForm) {
    editProductForm.onsubmit = async (e) => {
        e.preventDefault();
        if (window.updateProduct) await window.updateProduct(e);
    };
}

document.getElementById('bulk-upload-btn')?.addEventListener('click', (e) => window.handleBulkUpload?.(e));
document.getElementById('branch-form')?.addEventListener('submit', (e) => window.addBranch?.(e));
document.getElementById('store-form')?.addEventListener('submit', (e) => window.addStore?.(e));
document.getElementById('category-form')?.addEventListener('submit', (e) => window.addCategory?.(e));
document.getElementById('supplier-form')?.addEventListener('submit', (e) => window.addSupplier?.(e));

// Role-based visibility initialization
const currentRole = sessionStorage.getItem('userRole');
if (currentRole === 'SuperAdmin') {
    const storeTab = document.getElementById('tab-stores');
    if (storeTab) storeTab.style.display = 'block';
    const purgeBtn = document.getElementById('clear-all-staff-btn');
    if (purgeBtn) purgeBtn.style.display = 'block';
}
const selector = document.getElementById('branch-selector-wrapper');
if (selector) {
    selector.style.display = 'block';
    const globalSelect = document.getElementById('global-branch-selector');
    if (globalSelect) {
        const canSwitchBranch = ['Admin', 'SuperAdmin', 'CEO_Admin', 'Manager'].includes(currentRole);
        globalSelect.disabled = !canSwitchBranch;
        if (!canSwitchBranch) {
            globalSelect.style.cursor = 'default';
            globalSelect.style.opacity = '0.95';
        }
    }
}


// --- Order Filtering Logic extracted to modules/orders.js ---

// --- POS Auth Logic moved to auth.js ---

// --- Navigation Logic extracted to auth.js ---

// --- Branch Management Logic ---
window.addBranch = async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const name = document.getElementById('branch-name').value.trim();
    const location = document.getElementById('branch-location').value.trim();
    const address = (document.getElementById('branch-address')?.value || location).trim();
    const phone = document.getElementById('branch-phone').value.trim();

    try {
        addDoc(branchesCol, {
            name,
            location,
            address,
            phone,
            storeId: window.getStoreId(),
            createdAt: serverTimestamp()
        }).catch(err => {
            console.error("Firestore add branch error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        window.showToast(`Branch "${name}" created.`, "success");
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("Error creating branch.", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderBranchesUI(branches) {
    const list = document.getElementById('admin-branch-list');
    if (!list) return;
    const filtered = window.filterByStore(branches);
    list.innerHTML = filtered.length === 0 ? '<div class="empty-state" style="grid-column: 1/-1; padding: 2rem; color: #64748b; background: #fff; border-radius:12px; border:1px dashed #cbd5e1; text-align:center;">No branches added yet.</div>' : filtered.map(b => `
        <div class="col-card branch-card" style="padding: 1.5rem; background: #fff; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 1rem;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h3 style="margin: 0; color: var(--primary-blue); font-size: 1.1rem; font-weight: 800;">${b.name}</h3>
                    <p style="margin: 5px 0 0 0; color: #334155; font-size: 0.88rem; font-weight: 600;">📍 ${b.address || b.location}</p>
                    ${b.location && b.address && b.location !== b.address ? `<p style="margin: 2px 0 0 0; color: #64748b; font-size: 0.8rem;">🏙️ ${b.location}</p>` : ''}
                    <p style="margin: 3px 0 0 0; color: #0284c7; font-size: 0.85rem; font-weight: 700;">📞 ${b.phone || 'N/A'}</p>
                </div>
                <button class="icon-btn delete" onclick="confirmDeleteBranch('${b.docId}')" title="Delete Branch">🗑️</button>
            </div>
        </div>
    `).join('');
}

window.confirmDeleteBranch = async (docId) => {
    const docRef = doc(db, 'branches', docId);
    if (!await window.verifyDeletePermission(docRef, { isDeleted: true, status: 'Void' })) return;
    await deleteDoc(docRef);
    window.showToast("Branch removed.", "info");
}

function populateBranchDropdowns(branches) {
    const empBranchSelect = document.getElementById('emp-branch-id');
    const filtered = window.filterByStore(branches);

    if (empBranchSelect) {
        empBranchSelect.innerHTML = '<option value="main">Main Branch - Horana</option>' + filtered.filter(b => b.docId !== 'main').map(b => `
            <option value="${b.docId}">${b.name}</option>
        `).join('');
    }

    if (typeof window.populateTerminalBranchSelectors === 'function') {
        window.populateTerminalBranchSelectors();
    }
    
    // Auto migrate past unassigned/Global orders to Horana (main)
    if (typeof window.migratePastOrdersToHoranaCloud === 'function') {
        window.migratePastOrdersToHoranaCloud();
    }
}

window.migratePastOrdersToHoranaCloud = async () => {
    const role = (sessionStorage.getItem('userRole') || '').toLowerCase();
    const email = (sessionStorage.getItem('userEmail') || '').toLowerCase();
    const isHighAdmin = email.includes('mec') || email.includes('malindu') || role.includes('admin') || role.includes('ceo') || role.includes('owner');
    if (!isHighAdmin || window._hasRunHoranaMigration) return;
    window._hasRunHoranaMigration = true;

    try {
        const unmigrated = (window.allOrders || []).filter(o => !o.branchId || o.branchId === 'Global' || o.branchId === 'NO_BRANCH' || !o.branch);
        if (unmigrated.length === 0) return;

        console.log(`[Auto-Migration] Syncing ${unmigrated.length} past orders to Horana (main)...`);
        let batch = writeBatch(db);
        let count = 0;
        let total = 0;

        for (const ord of unmigrated) {
            batch.update(doc(db, 'orders', ord.docId), {
                branchId: 'main',
                branch: 'Main Branch - Horana',
                branchName: 'Main Branch - Horana',
                pickupShopName: 'Main Branch - Horana'
            });
            count++;
            total++;
            if (count >= 350) {
                await batch.commit();
                batch = writeBatch(db);
                count = 0;
            }
        }
        if (count > 0) {
            await batch.commit();
        }
        console.log(`[Auto-Migration] ✅ Successfully updated ${total} past orders to Horana (main) in cloud database!`);
    } catch(err) {
        console.warn("[Auto-Migration] Note:", err.message);
    }
};

// --- Category Management Logic ---
window.addCategory = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('cat-name').value.trim();
    if (!name) return;

    const submitBtn = e && e.target ? (e.target.querySelector('button[type="submit"]') || e.target.querySelector('button')) : null;
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Saving category...", "info");
        addDoc(categoriesCol, {
            name,
            storeId: window.getStoreId(),
            createdAt: serverTimestamp()
        }).catch(err => {
            console.error("Firestore add category error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        document.getElementById('cat-name').value = '';
        window.showToast(`✅ Category "${name}" added!`, "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving category", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderCategoriesUI(categories) {
    const list = document.getElementById('admin-category-list');
    if (!list) return;

    const filtered = window.filterByStore(categories);
    
    list.innerHTML = filtered.length === 0 ? '<p style="opacity:0.5; padding: 20px; text-align:center;">No categories yet.</p>' : `
        <div style="display: grid; gap: 10px;">
            ${filtered.map(cat => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding: 12px 18px; background: rgba(255,255,255,0.03); border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                    <span style="font-weight: 700; color: white;">${cat.name}</span>
                    <button class="icon-btn delete" onclick="window.deleteCategory('${cat.docId}')" style="opacity:0.6;">🗑️</button>
                </div>
            `).join('')}
        </div>
    `;
    
    // Alias for inventory module
    window.renderAdminCategoriesUI = renderCategoriesUI;
}

window.deleteCategory = async (id) => {
    const docRef = doc(db, 'categories', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    try {
            await deleteDoc(docRef);
            window.showToast("🗑️ Category removed.", "success");
        } catch (err) {
            console.error(err);
            window.showToast("Error deleting category", "error");
        }
    };

function populateCategoryDropdowns(categories) {
    const pCatSelect = document.getElementById('p-category');
    const editPCatSelect = document.getElementById('edit-p-category');
    const qaCatSelect = document.getElementById('qa-prod-category');
    const filtered = window.filterByStore(categories);

    const options = '<option value="">-- No Category --</option>' + 
        filtered.map(c => `<option value="${c.name}">${c.name}</option>`).join('');

    if (pCatSelect) pCatSelect.innerHTML = options;
    if (editPCatSelect) editPCatSelect.innerHTML = options;
    if (qaCatSelect) qaCatSelect.innerHTML = options;
}

function populateSupplierDropdowns(suppliers) {
    const pSupSelect = document.getElementById('p-supplier');
    const editPSupSelect = document.getElementById('edit-p-supplier');
    const sourceList = Array.isArray(suppliers) ? suppliers : (window.allSuppliers || []);
    const filtered = typeof window.filterByStore === 'function' ? window.filterByStore(sourceList) : sourceList;

    const buildOptions = (selectedVal = '') => {
        let html = '<option value="">None / General</option>';
        filtered.forEach(s => {
            const sid = s.docId || s.id || '';
            const sname = s.name || '';
            const isSel = (selectedVal && (selectedVal === sid || selectedVal === sname)) ? 'selected' : '';
            html += `<option value="${sid}" ${isSel}>${sname}</option>`;
        });
        return html;
    };

    if (pSupSelect) {
        const cur = pSupSelect.value;
        pSupSelect.innerHTML = buildOptions(cur);
    }
    if (editPSupSelect) {
        const cur = editPSupSelect.value;
        editPSupSelect.innerHTML = buildOptions(cur);
    }
}

window.renderCategoriesUI = renderCategoriesUI;
window.populateCategoryDropdowns = populateCategoryDropdowns;
window.populateSupplierDropdowns = populateSupplierDropdowns;

// --- Store Management Logic (SaaS) ---
window.addStore = async (e) => {
    e.preventDefault();
    const name = document.getElementById('store-name').value;
    const owner = document.getElementById('store-owner').value;
    const phone = document.getElementById('store-phone').value;
    const address = document.getElementById('store-address').value;
    const slug = document.getElementById('store-slug').value.toLowerCase().replace(/\s+/g, '-');

    try {
        await addDoc(storesCol, {
            name, owner, phone, address, slug,
            status: 'active',
            createdAt: serverTimestamp()
        });
        window.showToast(`Store "${name}" provisioned successfully!`, "success");
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("Deployment failed.", "error");
    }
};

function renderStoresUI(stores) {
    const list = document.getElementById('admin-store-list');
    if (!list) return;
    list.innerHTML = stores.length === 0 ? '<p>No merchant stores found.</p>' : stores.map(s => `
        <div class="col-card store-card" style="padding: 1.5rem; background: #fff; border-bottom: 4px solid var(--primary-blue);">
            <div style="display:flex; justify-content:space-between; align-items:start;">
                <div>
                    <span class="status-badge" style="margin-bottom: 10px; background: #dcfce7; color: #166534;">Active</span>
                    <h3 style="margin: 5px 0; color: #0f172a;">${s.name}</h3>
                    <p style="margin: 0; color: #64748b; font-size: 0.9rem;">👤 Owner: ${s.owner}</p>
                    <p style="margin: 5px 0; color: #64748b; font-size: 0.85rem;">🔗 Slug: <strong>${s.slug}</strong></p>
                    <div style="margin-top: 15px; display: flex; gap: 8px; flex-wrap: wrap;">
                        <button class="secondary-action-btn" onclick="copyStoreAdminLink('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem;">📋 Admin URL</button>
                        <button class="secondary-action-btn" onclick="openStoreDashboard('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem;">🔑 Login</button>
                        <button class="secondary-action-btn" onclick="openStoreWebsite('${s.slug}')" style="padding: 4px 8px; font-size: 0.75rem; background: var(--success-green); color: white; border: none;">🌐 Storefront</button>
                    </div>
                </div>
                <button class="icon-btn delete" onclick="confirmDeleteStore('${s.docId}')">🗑️</button>
            </div>
        </div>
    `).join('');
}

window.getStoreWebsiteUrl = (store = window.storeInfo) => {
    let s = (typeof store === 'object' && store !== null) ? store : (window.storeInfo || {});
    
    // Resolve active store ID / slug from object, getStoreId, session, or local storage
    let storeId = '';
    if (typeof store === 'string' && store.trim() !== '') {
        storeId = store.trim().toLowerCase();
        if ((!s || !s.slug) && Array.isArray(window.allStores)) {
            s = window.allStores.find(st => (st.slug || '').toLowerCase() === storeId) || s;
        }
    } else {
        storeId = (s.slug || (typeof window.getStoreId === 'function' ? window.getStoreId() : '') || sessionStorage.getItem('userStoreId') || sessionStorage.getItem('tempStoreSlug') || localStorage.getItem('userStoreId') || localStorage.getItem('storeId') || '').toLowerCase().trim();
    }

    // 1. Direct website URL configured on store profile
    if (s.websiteUrl && typeof s.websiteUrl === 'string' && s.websiteUrl.trim() !== '') {
        const url = s.websiteUrl.trim();
        return (url.startsWith('http://') || url.startsWith('https://')) ? url : `https://${url}`;
    }

    // 2. Custom domain configured on store
    if (s.domain && typeof s.domain === 'string' && s.domain.trim() !== '') {
        const dom = s.domain.trim();
        return (dom.startsWith('http://') || dom.startsWith('https://')) ? dom : `https://${dom}`;
    }

    // 3. Known default merchant: MEC Book Shop
    if (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'master' || storeId.includes('mecbook')) {
        return 'https://mecbookshop.web.lk';
    }

    // 4. Multi-merchant storefront URL on mecpos.web.lk
    if (storeId) {
        return `https://mecpos.web.lk/store/${storeId}`;
    }

    return 'https://mecbookshop.web.lk';
};

window.copyStoreAdminLink = (slug) => {
    const baseUrl = window.location.hostname.includes('localhost') ? window.location.origin : 'https://mecpos.web.lk';
    const url = `${baseUrl}/admin/${slug}`;
    navigator.clipboard.writeText(url);
    window.showToast("Admin link copied!", "info");
};

window.openStoreDashboard = (slug) => {
    const baseUrl = window.location.hostname.includes('localhost') ? window.location.origin : 'https://mecpos.web.lk';
    const url = `${baseUrl}/admin/${slug}`;
    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(url);
    } else {
        window.open(url, '_blank');
    }
};

window.openStoreWebsite = (storeOrSlug = window.storeInfo) => {
    // Always resolve against live window.storeInfo if nothing passed
    const resolvedStore = storeOrSlug || window.storeInfo;
    let targetUrl = '';
    if (typeof resolvedStore === 'string' && resolvedStore.trim() !== '') {
        const matched = (window.allStores || []).find(s => (s.slug || '').toLowerCase() === resolvedStore.trim().toLowerCase());
        targetUrl = window.getStoreWebsiteUrl(matched || { slug: resolvedStore.trim().toLowerCase() });
    } else {
        targetUrl = window.getStoreWebsiteUrl(resolvedStore);
    }

    // Final safety fallback — never open an empty URL
    if (!targetUrl || targetUrl.trim() === '') targetUrl = 'https://mecbookshop.web.lk';

    console.log('[openStoreWebsite] Opening:', targetUrl, '| store:', resolvedStore?.slug || resolvedStore || '(none)');

    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(targetUrl);
    } else {
        window.open(targetUrl, '_blank');
    }
};

window.confirmDeleteStore = async (docId) => {
    const docRef = doc(db, 'stores', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Store removed.", "info");
};

// --- Global Filter State ---
// (activeBranchFilter moved to top)

window.switchBranchFilter = (val) => {
    activeBranchFilter = val;
    window.activeBranchFilter = val;
    localStorage.setItem('mec_terminal_branch', val);
    
    // Sync all dropdowns
    const posSelect = document.getElementById('pos-terminal-branch-select');
    const globalSelect = document.getElementById('global-branch-selector');
    if (posSelect && posSelect.value !== val) posSelect.value = val;
    if (globalSelect && globalSelect.value !== val) globalSelect.value = val;

    const summaryBranch = document.getElementById('summary-branch');
    if (summaryBranch) {
        summaryBranch.innerText = val === 'All' ? 'All Branches' : (val === 'main' ? 'Horana (Main Branch)' : (window.allBranches?.find(b => b.docId === val)?.name || val));
    }

    // Trigger UI updates
    if (window.allOrders && typeof window.renderAdminOrdersUI === 'function') window.renderAdminOrdersUI(window.allOrders);
    if (window.allEmployees && typeof window.renderAdminEmployeesUI === 'function') window.renderAdminEmployeesUI(window.allEmployees);
    if (typeof window.renderPOSPendingShopOrders === 'function') window.renderPOSPendingShopOrders(window.allOrders || []);
    if (typeof window.renderExpensesUI === 'function') window.renderExpensesUI(window.allExpenses || []);
    if (typeof window.renderIncomeUI === 'function') window.renderIncomeUI(window.allIncome || []);
    if (typeof window.renderExecutiveDashboard === 'function') window.renderExecutiveDashboard();
    if (typeof window.generateReports === 'function') window.generateReports(window.allOrders || []);
    if (typeof window.renderRepairJobsUI === 'function') window.renderRepairJobsUI(window.allRepairJobs || []);
    if (typeof window.handlePOSSearch === 'function') window.handlePOSSearch(document.getElementById('pos-search')?.value || '');
    
    const branchName = val === 'All' ? 'All Branches (Global)' : (val === 'main' || val === 'Horana' ? 'Horana (Main Branch)' : (window.allBranches?.find(b => b.docId === val)?.name || val));
    if (typeof window.showToast === 'function') window.showToast(`📍 Switched view to: ${branchName}`, "info");
};
window.setTerminalBranch = window.switchBranchFilter;

// --- Branch Information Resolver ---
window.getBranchInfo = (branchIdOrObj) => {
    // Default fallback (Main Branch - Horana)
    const defaultBranch = {
        name: window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP',
        branchName: 'Main Branch - Horana',
        address: window.storeInfo?.address || window.storeInfo?.location || window.STORE_CONFIG?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
        phone: window.storeInfo?.phone || window.STORE_CONFIG?.phone || '071 923 3388',
        email: window.storeInfo?.ownerEmail || window.STORE_CONFIG?.email || 'mecbookshop@gmail.com',
        location: 'Horana'
    };

    if (!branchIdOrObj) return defaultBranch;

    // If already a branch object passed in
    if (typeof branchIdOrObj === 'object') {
        const b = branchIdOrObj;
        return {
            name: b.name || defaultBranch.name,
            branchName: b.name || defaultBranch.branchName,
            address: b.address || b.location || defaultBranch.address,
            phone: b.phone || defaultBranch.phone,
            email: b.email || defaultBranch.email,
            location: b.location || defaultBranch.location
        };
    }

    const bId = String(branchIdOrObj).trim();
    if (bId === 'main' || bId === 'Global' || bId === 'All' || bId.toLowerCase().includes('horana')) {
        return defaultBranch;
    }

    // Lookup in window.allBranches or window.allStoreBranches
    const branches = window.allBranches || window.allStoreBranches || [];
    const found = branches.find(b => 
        (b.docId && b.docId === bId) || 
        (b.id && b.id === bId) || 
        (b.name && b.name.toLowerCase() === bId.toLowerCase())
    );

    if (found) {
        return {
            name: found.name || defaultBranch.name,
            branchName: found.name || defaultBranch.branchName,
            address: found.address || found.location || defaultBranch.address,
            phone: found.phone || defaultBranch.phone,
            email: found.email || defaultBranch.email,
            location: found.location || found.city || defaultBranch.location
        };
    }

    return defaultBranch;
};

// --- Modularized Domains (Inventory, Orders, Reports) ---


// --- POS Sharing & Printing ---
window.generatePOSReceiptNo = () => {
    const no = 'R-' + Math.floor(Math.random() * 900000 + 100000);
    document.getElementById('pos-receipt-no').innerText = no;
};

window.printPOSReceipt = (saleData = null) => { // TEST
    const isSnapshot = !!saleData;
    const snapshot = saleData || window.currentPendingPOSSale || window.lastSavedPOSOrder;
    const billItems = isSnapshot ? (snapshot.items || []) : (window.activePOSItems || []);
    if (billItems.length === 0) return;

    // Values either from snapshot parameter or UI elements
    const receiptNo = isSnapshot ? (snapshot.orderId || "POS-SALE") : (document.getElementById('pos-receipt-no')?.innerText || "POS-SALE");
    
    const grossTotal = billItems.reduce((s, i) => s + ((parseFloat(i.price) || 0) * (parseFloat(i.quantity) || 0)), 0);
    const itemDiscounts = billItems.reduce((s, i) => s + ((parseFloat(i.discount) || 0) * (parseFloat(i.quantity) || 0)), 0);
    
    let billDiscount = 0;
    let payableAmount = 0;
    let paidVal = 0;
    let cashBalanceText = "0.00";

    if (isSnapshot) {
        payableAmount = parseFloat(snapshot.baseAmount || snapshot.total || 0);
        billDiscount = snapshot.billDiscountAmount !== undefined 
            ? parseFloat(snapshot.billDiscountAmount || 0) 
            : Math.max(0, (grossTotal - itemDiscounts) - payableAmount);
        paidVal = snapshot.tenderedAmount !== undefined ? parseFloat(snapshot.tenderedAmount) : payableAmount;
        cashBalanceText = (snapshot.cashBalance || 0).toFixed(2);
    } else {
        billDiscount = parseFloat(document.getElementById('pos-bill-discount')?.value || 0);
        payableAmount = parseFloat(document.getElementById('pos-payable')?.innerText || (grossTotal - itemDiscounts - billDiscount));
        paidVal = parseFloat(document.getElementById('pay-modal-tendered')?.value || payableAmount);
        cashBalanceText = document.getElementById('pay-modal-cash-balance')?.innerText || "0.00";
    }

    const totalDiscount = snapshot?.totalDiscount !== undefined 
        ? parseFloat(snapshot.totalDiscount) 
        : (itemDiscounts + billDiscount);

    const payableText = payableAmount.toFixed(2);
    const grossTotalText = grossTotal.toFixed(2);
    const totalDiscountText = totalDiscount.toFixed(2);

    // Loyalty Points Earned Computation
    let earnedPts = 0;
    const resolvedCustomer = isSnapshot 
        ? (snapshot.customerId ? (window.allCustomers || []).find(c => c.docId === snapshot.customerId) : null) 
        : (window.currentPOSCustomer || null);

    if (snapshot?.earnedLoyaltyPoints !== undefined) {
        earnedPts = parseInt(snapshot.earnedLoyaltyPoints, 10) || 0;
    } else {
        if (resolvedCustomer) {
            const lRate = parseFloat(window.systemConfig?.loyaltyRate) || 500;
            earnedPts = lRate > 0 ? Math.floor(payableAmount / lRate) : 0;
        }
    }

    // Resolve Customer Information (Name & Phone)
    const customerName = snapshot?.userName || snapshot?.customerName || resolvedCustomer?.name || (document.getElementById('pos-cust-phone')?.dataset?.custName || '').trim() || '';
    const customerPhone = snapshot?.customerPhone || snapshot?.phone || resolvedCustomer?.phone || (document.getElementById('pos-cust-phone')?.value || '').trim() || '';

    // Computed Logic from current interaction / snapshot
    const redeemed = isSnapshot ? (snapshot.redeemedAmount || 0) : (window.appliedLoyaltyPointsOnThisBill || 0);
    const settled = snapshot?.outstandingIncluded ? (snapshot.outstandingAmount || 0) : 0;
    const manualPointsAdded = snapshot?.balanceToPoints ? (snapshot.changeAmount || 0) : 0;

    const pType = window.systemConfig?.printerType || 'thermal-80';
    
    // Resolve Issuing Branch Details (Address, Phone, Name)
    const orderBranchKey = snapshot?.branchId || snapshot?.branch || localStorage.getItem('mec_terminal_branch') || sessionStorage.getItem('userBranchId') || 'main';
    const activeBranchInfo = (typeof window.getBranchInfo === 'function') 
        ? window.getBranchInfo(orderBranchKey) 
        : {
            name: window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP',
            branchName: 'Main Branch - Horana',
            address: window.storeInfo?.address || window.storeInfo?.location || window.STORE_CONFIG?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
            phone: window.storeInfo?.phone || window.STORE_CONFIG?.phone || '071 923 3388'
        };

    const branchDisplayName = activeBranchInfo.branchName || activeBranchInfo.name || 'MEC BOOK SHOP';
    const branchAddressText = activeBranchInfo.address || activeBranchInfo.location || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana';
    const branchPhoneText = activeBranchInfo.phone || '071 923 3388';
    
    // Resolve Merchant Email & Website
    const branchEmailText = activeBranchInfo.email 
        || window.storeInfo?.ownerEmail 
        || window.storeInfo?.email 
        || window.STORE_CONFIG?.email 
        || ((branchDisplayName.toLowerCase().includes('mec') || orderBranchKey === 'main') ? 'mecbookshop@gmail.com' : '');
    
    let branchWebsiteRaw = (typeof window.getStoreWebsiteUrl === 'function') 
        ? window.getStoreWebsiteUrl(window.storeInfo) 
        : (window.storeInfo?.websiteUrl || window.storeInfo?.domain || 'https://mecbookshop.web.lk');
    // Display cleaner domain text without https:// or trailing slashes for neat receipt printing
    let branchWebsiteDisplay = branchWebsiteRaw ? branchWebsiteRaw.replace(/^https?:\/\//i, '').replace(/\/$/, '') : '';

    // Merchant Brand Logo Resolution
    const customMerchantLogo = window.systemConfig?.storeLogoUrl 
        || window.systemConfig?.logoUrl 
        || window.storeInfo?.logoUrl 
        || window.currentStoreData?.logoUrl
        || localStorage.getItem('mecpos_store_logo')
        || (typeof window.getMerchantDefaultLogo === 'function' ? window.getMerchantDefaultLogo() : '')
        || '/mec-logo.png';
    const merchantLogoHtml = (customMerchantLogo && !customMerchantLogo.includes('zenith_logo'))
        ? `<img src="${customMerchantLogo}" style="max-height: 75px; max-width: 220px; object-fit: contain; margin-bottom: 6px; display: block; image-rendering: -webkit-optimize-contrast;" onerror="this.style.display='none'" />`
        : '';
    const thermalMerchantLogoHtml = (customMerchantLogo && !customMerchantLogo.includes('zenith_logo'))
        ? `<img src="${customMerchantLogo}" style="max-height: 65px; max-width: 160px; object-fit: contain; margin: 0 auto 6px auto; display: block; filter: grayscale(100%) contrast(120%); image-rendering: -webkit-optimize-contrast;" onerror="this.style.display='none'" />`
        : '';

    let printHtml = '';

    if (pType === 'a4' || pType === 'a5') {
        const pageSize = pType === 'a4' ? 'A4' : 'A5';
        const maxWidth = pType === 'a4' ? '210mm' : '148mm';
        
        let a4ItemsHtml = billItems.map((item, idx) => {
            const itemPrice = parseFloat(item.price) || 0;
            const itemQty = parseFloat(item.quantity) || 0;
            const itemDisc = parseFloat(item.discount) || 0;
            const itemFinal = (itemPrice - itemDisc) * itemQty;
            return `
            <tr>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee;">${idx + 1}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; font-weight: 600;">${item.name}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: center;">${itemQty}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right;">${itemPrice.toFixed(2)}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right; color: ${itemDisc > 0 ? '#e11d48' : 'inherit'}; font-weight: ${itemDisc > 0 ? '600' : 'normal'};">${itemDisc > 0 ? '-' + itemDisc.toFixed(2) : '-'}</td>
                <td style="padding: 4px 5px; border-bottom: 1px solid #eee; text-align: right; font-weight: bold;">${itemFinal.toFixed(2)}</td>
            </tr>
            `;
        }).join('');

        const templateId = (window.systemConfig?.invTemplate || (pType === 'a5' ? 'a5' : 'classic')).toLowerCase();

        if (templateId === 'modern') {
            // MODERN EDGE TEMPLATE
            printHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Invoice #${receiptNo}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    @page { size: ${pageSize}; margin: 8mm; }
                    * { box-sizing: border-box; }
                    html, body { height: 100%; margin: 0; padding: 0; background: #fff; }
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', -apple-system, sans-serif; color: #0f172a; font-size: ${pageSize === 'A5' ? '11px' : '12px'}; line-height: 1.4; }
                    .page-container { min-height: 100vh; display: flex; flex-direction: column; padding: ${pageSize === 'A5' ? '4mm 4mm' : '8mm 8mm'}; }
                    .modern-topbar { display: flex; justify-content: space-between; align-items: stretch; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #ffffff; padding: ${pageSize === 'A5' ? '12px 16px' : '20px 24px'}; border-radius: 12px; margin-bottom: ${pageSize === 'A5' ? '12px' : '18px'}; }
                    .brand-name { font-size: ${pageSize === 'A5' ? '18px' : '24px'}; font-weight: 900; letter-spacing: -0.5px; color: #38bdf8; text-transform: uppercase; }
                    .branch-pill { display: inline-block; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 20px; padding: 2px 10px; font-size: 10px; font-weight: 700; margin-top: 4px; }
                    .store-contact { font-size: 10px; color: #94a3b8; margin-top: 6px; line-height: 1.4; }
                    .inv-hero { text-align: right; display: flex; flex-direction: column; justify-content: space-between; }
                    .inv-hero h1 { margin: 0; font-size: ${pageSize === 'A5' ? '20px' : '28px'}; font-weight: 900; color: #fff; letter-spacing: 2px; }
                    .inv-badge-no { display: inline-block; background: #0284c7; color: #fff; padding: 3px 12px; border-radius: 6px; font-size: 12px; font-weight: 800; margin-top: 4px; }
                    .modern-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: ${pageSize === 'A5' ? '8px 12px' : '10px 16px'}; margin-bottom: ${pageSize === 'A5' ? '12px' : '18px'}; }
                    .meta-block label { font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
                    .meta-block div { font-weight: 700; font-size: 12px; color: #0f172a; margin-top: 1px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                    th { background: #0f172a; color: #ffffff; padding: ${pageSize === 'A5' ? '6px 8px' : '9px 10px'}; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; text-align: left; }
                    th:first-child { border-radius: 8px 0 0 0; }
                    th:last-child { border-radius: 0 8px 0 0; }
                    .summary-container { display: flex; justify-content: flex-end; margin-top: 8px; }
                    .modern-summary { width: ${pageSize === 'A5' ? '240px' : '290px'}; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px 16px; }
                    .sum-row { display: flex; justify-content: space-between; margin-bottom: 5px; font-size: 11px; color: #475569; }
                    .sum-total { display: flex; justify-content: space-between; font-weight: 900; font-size: ${pageSize === 'A5' ? '14px' : '17px'}; color: #0f172a; border-top: 2px solid #0284c7; padding-top: 8px; margin-top: 6px; }
                    .loyalty-ribbon { margin-top: 8px; padding: 6px 10px; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 6px; color: #b45309; font-weight: 800; font-size: 10px; display: flex; justify-content: space-between; }
                    .modern-footer { margin-top: auto; border-top: 1px solid #e2e8f0; padding-top: 10px; text-align: center; font-size: 10px; color: #64748b; }
                </style>
            </head>
            <body>
                <div class="page-container">
                <div class="modern-topbar">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        ${merchantLogoHtml ? `<div style="background: #ffffff; padding: 4px 8px; border-radius: 8px; display: flex; align-items: center; justify-content: center;">${merchantLogoHtml.replace('margin-bottom: 6px;', 'margin-bottom: 0;')}</div>` : ''}
                        <div>
                            <div class="brand-name">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                            <div class="branch-pill">🏢 ${branchDisplayName}</div>
                            <div class="store-contact">
                                📍 ${branchAddressText}<br>
                                📞 Tel: ${branchPhoneText}<br>
                                ${branchEmailText ? `✉️ Email: ${branchEmailText}<br>` : ''}
                                ${branchWebsiteDisplay ? `🌐 Web: ${branchWebsiteDisplay}` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="inv-hero">
                        <h1>INVOICE</h1>
                        <div><span class="inv-badge-no">#${receiptNo}</span></div>
                    </div>
                </div>

                <div class="modern-meta">
                    <div class="meta-block">
                        <label>Issue Date & Time</label>
                        <div>${new Date().toLocaleDateString()} &nbsp;•&nbsp; ${new Date().toLocaleTimeString()}</div>
                    </div>
                    <div class="meta-block" style="text-align: right;">
                        <label>Customer Details</label>
                        <div style="font-weight: 700; color: #002060;">👤 ${customerName || 'Walk-in Customer'}${customerPhone ? ` &nbsp;•&nbsp; 📞 ${customerPhone}` : ''}</div>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th width="6%" style="text-align: center;">#</th>
                            <th width="44%">Item Description</th>
                            <th width="10%" style="text-align: center;">Qty</th>
                            <th width="14%" style="text-align: right;">Rate</th>
                            <th width="12%" style="text-align: right;">Discount</th>
                            <th width="14%" style="text-align: right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${a4ItemsHtml}
                    </tbody>
                </table>

                <div class="summary-container">
                    <div class="modern-summary">
                        <div class="sum-row" style="font-weight: 600;"><span>Gross Total:</span><span>LKR ${grossTotalText}</span></div>
                        <div class="sum-row" style="color: #ef4444; font-weight: 700;"><span>(-) Total Discount:</span><span>- LKR ${totalDiscountText}</span></div>
                        ${settled > 0 ? `<div class="sum-row" style="color: #e11d48; font-weight: 600;"><span>(+) Settled Outstanding:</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                        <div class="sum-total"><span>NET PAYABLE:</span><span>LKR ${payableText}</span></div>
                        <div class="loyalty-ribbon" style="background: #fef3c7; border: 1px solid #f59e0b; color: #b45309; font-weight: 800; padding: 6px 10px; border-radius: 6px; margin-top: 8px;">
                            <span>⭐ Loyalty Points Earned</span>
                            <span>+${earnedPts} Pts</span>
                        </div>
                        <div style="border-top: 1px dashed #cbd5e1; margin-top: 8px; padding-top: 8px;"></div>
                        ${redeemed > 0 ? `<div class="sum-row" style="color: #16a34a; font-weight: 700;"><span>Points Redeemed</span><span>- LKR ${redeemed.toFixed(2)}</span></div>` : ''}
                        <div class="sum-row"><span>Paid Amount</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                        <div class="sum-row" style="font-weight: 800; color: #0f172a; font-size: 12px;"><span>Cash Balance</span><span>LKR ${cashBalanceText}</span></div>
                    </div>
                </div>

                <div class="modern-footer">
                    <p style="margin: 0; font-weight: 700; color: #0f172a;">${window.systemConfig?.invFooter || 'Thank you for choosing us!'}</p>
                    <p style="margin: 3px 0 0; font-size: 10px; font-weight: 700; color: #0284c7; letter-spacing: 0.3px;">mecpos.web.lk</p>
                    <p style="margin: 1px 0 0; font-size: 9px; color: #64748b;">Software by MEC Global Solutions • Sri Lanka's leading cloud ERP & POS platform for modern merchants.</p>
                </div>
                </div>
                <script>
                    setTimeout(() => { window.focus(); window.print(); window.close(); }, 250);
                </script>
            </body>
            </html>
            `;
        } else if (templateId === 'minimal') {
            // CLEAN MINIMAL TEMPLATE
            printHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Invoice #${receiptNo}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    @page { size: ${pageSize}; margin: 8mm; }
                    * { box-sizing: border-box; }
                    html, body { height: 100%; margin: 0; padding: 0; background: #fff; }
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', -apple-system, sans-serif; color: #18181b; font-size: ${pageSize === 'A5' ? '11px' : '12px'}; line-height: 1.5; }
                    .page-container { min-height: 100vh; display: flex; flex-direction: column; padding: ${pageSize === 'A5' ? '4mm 4mm' : '8mm 8mm'}; }
                    .min-header { display: flex; justify-content: space-between; align-items: baseline; border-bottom: 2px solid #18181b; padding-bottom: 12px; margin-bottom: 16px; }
                    .min-brand { font-size: ${pageSize === 'A5' ? '18px' : '24px'}; font-weight: 800; text-transform: uppercase; letter-spacing: -0.5px; }
                    .min-branch { font-size: 10.5px; color: #52525b; margin-top: 3px; line-height: 1.4; }
                    .min-title { font-size: ${pageSize === 'A5' ? '18px' : '22px'}; font-weight: 300; letter-spacing: 2px; text-transform: uppercase; color: #18181b; }
                    .min-meta-row { display: flex; justify-content: space-between; font-size: 11px; color: #71717a; margin-bottom: 20px; border-bottom: 1px solid #f4f4f5; padding-bottom: 8px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th { border-bottom: 1px solid #18181b; padding: 6px 0; text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #71717a; font-weight: 600; }
                    .min-summary { float: right; width: ${pageSize === 'A5' ? '220px' : '260px'}; margin-top: 10px; }
                    .min-row { display: flex; justify-content: space-between; font-size: 11px; padding: 3px 0; color: #52525b; }
                    .min-net { display: flex; justify-content: space-between; font-weight: 800; font-size: ${pageSize === 'A5' ? '14px' : '16px'}; color: #18181b; border-top: 1.5px solid #18181b; margin-top: 6px; padding-top: 6px; }
                    .min-footer { clear: both; margin-top: auto; text-align: left; font-size: 10px; color: #a1a1aa; border-top: 1px solid #f4f4f5; padding-top: 12px; }
                </style>
            </head>
            <body>
                <div class="page-container">
                <div class="min-header">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        ${merchantLogoHtml ? `<div>${merchantLogoHtml.replace('margin-bottom: 6px;', 'margin-bottom: 0;')}</div>` : ''}
                        <div>
                            <div class="min-brand">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                            <div class="min-branch">
                                🏢 ${branchDisplayName} • 📍 ${branchAddressText} • 📞 ${branchPhoneText}
                                ${branchEmailText ? `<br>✉️ ${branchEmailText}` : ''}
                                ${branchWebsiteDisplay ? ` • 🌐 ${branchWebsiteDisplay}` : ''}
                            </div>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div class="min-title">INVOICE</div>
                        <div style="font-weight: 700; font-size: 12px; color: #18181b;">#${receiptNo}</div>
                    </div>
                </div>

                <div class="min-meta-row">
                    <div>Date: <strong>${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</strong></div>
                    <div>Customer: <strong>${customerName || 'Walk-in Customer'}${customerPhone ? ` (${customerPhone})` : ''}</strong></div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th width="6%">#</th>
                            <th width="46%">Description</th>
                            <th width="10%" style="text-align: center;">Qty</th>
                            <th width="14%" style="text-align: right;">Unit</th>
                            <th width="10%" style="text-align: right;">Disc</th>
                            <th width="14%" style="text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${a4ItemsHtml}
                    </tbody>
                </table>

                <div class="min-summary">
                    <div class="min-row" style="font-weight: 600;"><span>Gross Total:</span><span>LKR ${grossTotalText}</span></div>
                    <div class="min-row" style="color: #dc2626; font-weight: 700;"><span>(-) Total Discount:</span><span>- LKR ${totalDiscountText}</span></div>
                    ${settled > 0 ? `<div class="min-row" style="color: #dc2626; font-weight: 600;"><span>(+) Settled Outstanding:</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                    <div class="min-net"><span>TOTAL PAYABLE:</span><span>LKR ${payableText}</span></div>
                    <div class="min-row" style="margin-top: 6px; padding: 4px 6px; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 4px; font-weight: 700; color: #92400e;"><span>⭐ Points Earned:</span><span>+${earnedPts} Pts</span></div>
                    <div style="border-top: 1px dashed #e4e4e7; margin: 6px 0;"></div>
                    <div class="min-row"><span>Tendered</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                    <div class="min-row" style="font-weight: 700; color: #18181b;"><span>Balance</span><span>LKR ${cashBalanceText}</span></div>
                </div>

                <div class="min-footer">
                    <p style="margin: 0;">${window.systemConfig?.invFooter || 'Thank you for your visit.'}</p>
                    <p style="margin: 3px 0 0; font-size: 10px; font-weight: 700; color: #18181b;">mecpos.web.lk</p>
                    <p style="margin: 1px 0 0; font-size: 9px; color: #71717a;">Software by MEC Global Solutions • Sri Lanka's leading cloud ERP & POS platform for modern merchants.</p>
                </div>
                </div>
                <script>
                    setTimeout(() => { window.focus(); window.print(); window.close(); }, 250);
                </script>
            </body>
            </html>
            `;
        } else if (templateId === 'a5') {
            // COMPACT A5 LAYOUT
            printHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Invoice #${receiptNo}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    @page { size: A5; margin: 6mm; }
                    * { box-sizing: border-box; }
                    html, body { height: 100%; margin: 0; padding: 0; background: #fff; }
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', -apple-system, sans-serif; color: #1e293b; font-size: 11px; line-height: 1.35; }
                    .page-container { min-height: 100vh; display: flex; flex-direction: column; padding: 4mm 4mm; }
                    .a5-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #059669; padding-bottom: 8px; margin-bottom: 8px; }
                    .a5-brand { font-size: 17px; font-weight: 900; color: #059669; text-transform: uppercase; }
                    .a5-branch { font-size: 10px; font-weight: 700; color: #047857; margin-top: 2px; }
                    .a5-info { font-size: 9.5px; color: #64748b; line-height: 1.3; }
                    .a5-inv-badge { text-align: right; }
                    .a5-inv-badge h2 { margin: 0; font-size: 18px; color: #059669; font-weight: 900; }
                    .a5-no { font-size: 11px; font-weight: 800; background: #ecfdf5; color: #047857; padding: 2px 8px; border-radius: 4px; border: 1px solid #a7f3d0; display: inline-block; margin-top: 2px; }
                    .a5-meta-bar { display: flex; justify-content: space-between; font-size: 10px; background: #f0fdf4; border: 1px solid #bbf7d0; padding: 5px 8px; border-radius: 6px; margin-bottom: 8px; font-weight: 600; color: #166534; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-size: 10.5px; }
                    th { background: #059669; color: #fff; padding: 4px 6px; font-size: 9.5px; text-transform: uppercase; text-align: left; }
                    .a5-summary-wrap { display: flex; justify-content: flex-end; }
                    .a5-sum-box { width: 220px; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 10px; }
                    .a5-sum-row { display: flex; justify-content: space-between; font-size: 10.5px; margin-bottom: 3px; color: #475569; }
                    .a5-net { display: flex; justify-content: space-between; font-weight: 900; font-size: 13.5px; color: #059669; border-top: 1.5px solid #059669; padding-top: 5px; margin-top: 4px; }
                    .a5-footer { margin-top: auto; border-top: 1px dashed #cbd5e1; padding-top: 6px; text-align: center; font-size: 9px; color: #94a3b8; }
                </style>
            </head>
            <body>
                <div class="page-container">
                <div class="a5-header">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        ${merchantLogoHtml ? `<div>${merchantLogoHtml.replace('max-height: 75px;', 'max-height: 55px;').replace('margin-bottom: 6px;', 'margin-bottom: 0;')}</div>` : ''}
                        <div>
                            <div class="a5-brand">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                            <div class="a5-branch">🏢 ${branchDisplayName}</div>
                            <div class="a5-info">
                                📍 ${branchAddressText} • 📞 ${branchPhoneText}
                                ${branchEmailText ? `<br>✉️ ${branchEmailText}` : ''}
                                ${branchWebsiteDisplay ? ` • 🌐 ${branchWebsiteDisplay}` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="a5-inv-badge">
                        <h2>INVOICE</h2>
                        <div class="a5-no">#${receiptNo}</div>
                    </div>
                </div>

                <div class="a5-meta-bar">
                    <span>📅 Date: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</span>
                    <span>👤 Cust: <strong>${customerName || 'Walk-in Customer'}${customerPhone ? ` (${customerPhone})` : ''}</strong></span>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th width="6%" style="text-align: center;">#</th>
                            <th width="46%">Item</th>
                            <th width="10%" style="text-align: center;">Qty</th>
                            <th width="14%" style="text-align: right;">Price</th>
                            <th width="10%" style="text-align: right;">Disc</th>
                            <th width="14%" style="text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${a4ItemsHtml}
                    </tbody>
                </table>

                <div class="a5-summary-wrap">
                    <div class="a5-sum-box">
                        <div class="a5-sum-row" style="font-weight: 600;"><span>Gross Total:</span><span>LKR ${grossTotalText}</span></div>
                        <div class="a5-sum-row" style="color: #e11d48; font-weight: 700;"><span>(-) Total Discount:</span><span>- LKR ${totalDiscountText}</span></div>
                        ${settled > 0 ? `<div class="a5-sum-row" style="color: #e11d48; font-weight: 600;"><span>(+) Settled Outstanding:</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                        <div class="a5-net"><span>NET TOTAL:</span><span>LKR ${payableText}</span></div>
                        <div class="a5-sum-row" style="color: #b45309; font-weight: 800; margin-top: 5px; background: #fef3c7; border: 1px solid #f59e0b; padding: 3px 6px; border-radius: 4px;"><span>⭐ Loyalty Points:</span><span>+${earnedPts} Pts</span></div>
                        <div style="border-top: 1px dashed #cbd5e1; margin: 4px 0;"></div>
                        <div class="a5-sum-row"><span>Cash Paid</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                        <div class="a5-sum-row" style="font-weight: 800; color: #0f172a;"><span>Balance</span><span>LKR ${cashBalanceText}</span></div>
                    </div>
                </div>

                <div class="a5-footer">
                    <p style="margin: 0; font-weight: 700; color: #475569;">${window.systemConfig?.invFooter || 'Thank you for shopping with us!'}</p>
                    <p style="margin: 3px 0 0; font-weight: 700; color: #059669; font-size: 9.5px;">mecpos.web.lk</p>
                    <p style="margin: 1px 0 0; font-size: 8.5px; color: #94a3b8;">Software by MEC Global Solutions • Sri Lanka's leading cloud ERP & POS platform for modern merchants.</p>
                </div>
                </div>
                <script>
                    setTimeout(() => { window.focus(); window.print(); window.close(); }, 250);
                </script>
            </body>
            </html>
            `;
        } else {
            // CLASSIC ENTERPRISE TEMPLATE
            printHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Invoice ${receiptNo}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    @page { size: ${pageSize}; margin: 8mm; }
                    * { box-sizing: border-box; }
                    html, body { height: 100%; margin: 0; padding: 0; background: #fff; }
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', -apple-system, sans-serif; color: #1e293b; font-size: 12px; line-height: 1.5; }
                    .page-container { min-height: 100vh; display: flex; flex-direction: column; padding: ${pageSize === 'A5' ? '4mm 4mm' : '8mm 8mm'}; }
                    .invoice-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; border-bottom: 2px solid #002060; padding-bottom: 15px; }
                    .logo { font-size: 24px; font-weight: 800; color: #002060; text-transform: uppercase; letter-spacing: -0.5px; }
                    .branch-badge { display: inline-block; font-size: 11px; font-weight: 700; color: #0284c7; background: #e0f2fe; padding: 2px 8px; border-radius: 4px; margin-top: 4px; margin-bottom: 6px; }
                    .company-info { color: #555; font-size: 11px; line-height: 1.4; }
                    .invoice-title { text-align: right; }
                    .invoice-title h1 { margin: 0 0 5px 0; font-size: 26px; color: #002060; text-transform: uppercase; letter-spacing: 1px; font-weight: 900; }
                    .invoice-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px; background: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0; }
                    .meta-item label { display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 800; margin-bottom: 2px; }
                    .meta-item span { font-weight: 600; font-size: 12px; color: #002060; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; border: 1px solid #cbd5e1; }
                    th { background: #002060; color: white; padding: 7px 8px; text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
                    td { font-size: 11px; }
                    .summary-box { float: right; width: 280px; background: #fafafa; border: 1.5px solid #002060; border-radius: 8px; padding: 12px 14px; margin-top: 5px; }
                    .summary-line { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 12px; color: #475569; }
                    .discount-highlight { color: #e11d48; font-weight: 700; background: #fff1f2; padding: 2px 6px; border-radius: 4px; border: 1px dashed #fecdd3; }
                    .loyalty-badge { margin-top: 8px; padding: 6px 10px; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 6px; color: #92400e; font-weight: 800; font-size: 11px; display: flex; justify-content: space-between; }
                    .total-line { display: flex; justify-content: space-between; font-weight: 900; font-size: 16px; margin-top: 8px; padding-top: 8px; border-top: 2px solid #002060; color: #002060; }
                    .footer { clear: both; margin-top: auto; text-align: center; font-size: 10px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class="page-container">
                <div class="invoice-header">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        ${merchantLogoHtml ? `<div>${merchantLogoHtml.replace('margin-bottom: 6px;', 'margin-bottom: 0;')}</div>` : ''}
                        <div>
                            <div class="logo">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                            <div class="branch-badge">🏢 ${branchDisplayName}</div>
                            <div class="company-info">
                                📍 ${branchAddressText}<br>
                                📞 Tel: ${branchPhoneText}<br>
                                ${branchEmailText ? `✉️ Email: ${branchEmailText}<br>` : ''}
                                ${branchWebsiteDisplay ? `🌐 Web: ${branchWebsiteDisplay}` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="invoice-title">
                        <h1>INVOICE</h1>
                    </div>
                </div>
                
                <div class="invoice-meta" style="display: grid; grid-template-columns: 1fr 1.2fr 1fr; gap: 10px; margin-bottom: 15px; background: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <div class="meta-item">
                        <label>Invoice Number</label>
                        <span>#${receiptNo}</span>
                    </div>
                    <div class="meta-item">
                        <label>Customer Details</label>
                        <span style="font-weight: 700; color: #002060;">👤 ${customerName || 'Walk-in Customer'}${customerPhone ? `<br><small style="color: #64748b; font-weight: 600;">📞 ${customerPhone}</small>` : ''}</span>
                    </div>
                    <div class="meta-item" style="text-align: right;">
                        <label>Date & Time</label>
                        <span>${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</span>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th width="5%" style="text-align: center;">#</th>
                            <th width="45%">Item Description</th>
                            <th width="10%" style="text-align: center;">Qty</th>
                            <th width="15%" style="text-align: right;">Unit Price</th>
                            <th width="12%" style="text-align: right;">Discount</th>
                            <th width="13%" style="text-align: right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${a4ItemsHtml}
                    </tbody>
                </table>

                <div class="summary-box">
                    <div class="summary-line" style="font-weight: 600;"><span>Gross Total:</span><span>LKR ${grossTotalText}</span></div>
                    <div class="summary-line discount-highlight" style="margin: 2px 0;">
                        <span>(-) Total Discount:</span>
                        <span>- LKR ${totalDiscountText}</span>
                    </div>
                    ${settled > 0 ? `<div class="summary-line" style="color: #e30030; font-weight: 600;"><span>(+) Settled Outstanding:</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                    <div class="total-line"><span>NET PAYABLE:</span><span>LKR ${payableText}</span></div>
                    
                    <div class="loyalty-badge">
                        <span>⭐ Loyalty Points Earned:</span>
                        <span>+${earnedPts} Pts</span>
                    </div>
                    
                    <div style="margin-top: 10px; padding-top: 8px; border-top: 1px dashed #cbd5e1;"></div>
                    ${redeemed > 0 ? `<div class="summary-line" style="color: #16a34a; font-weight: 600;"><span>Redeemed Points</span><span>- LKR ${redeemed.toFixed(2)}</span></div>` : ''}
                    <div class="summary-line"><span>Amount Tendered</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                    <div class="summary-line" style="font-weight: 800; color: #0f172a; font-size: 13px;"><span>Balance</span><span>LKR ${cashBalanceText}</span></div>
                    ${manualPointsAdded > 0 ? `<div class="summary-line" style="font-style: italic; font-size: 10px; color: #0284c7;"><span>Change Pushed to Loyalty</span><span>LKR ${manualPointsAdded.toFixed(2)}</span></div>` : ''}
                </div>

                <div class="footer">
                    <p style="font-weight: 600; color: #475569; margin: 0 0 4px 0;">${window.systemConfig?.invFooter || 'Thank you for your business!'}</p>
                    <p style="font-weight: 700; color: #002060; font-size: 11px; margin: 0 0 2px 0;">mecpos.web.lk</p>
                    <p style="margin: 0; color: #64748b; font-size: 9.5px;">Software by MEC Global Solutions • Sri Lanka's leading cloud ERP & POS platform for modern merchants.</p>
                </div>
                </div>
                <script>
                    setTimeout(() => { window.focus(); window.print(); window.close(); }, 300);
                </script>
            </body>
            </html>
            `;
        }
    } else {
        let itemsHtml = billItems.map(item => {
            const itemPrice = parseFloat(item.price) || 0;
            const itemQty = parseFloat(item.quantity) || 0;
            const itemDisc = parseFloat(item.discount) || 0;
            const itemFinal = (itemPrice - itemDisc) * itemQty;
            const itemDiscTotal = itemDisc * itemQty;
            return `
            <div class="receipt-row" style="margin-bottom: 6px;">
                <div class="item-info" style="flex: 1; padding-right: 4px;">
                    <div class="item-name">${item.name}</div>
                    <div class="item-meta">${itemQty} x LKR ${itemPrice.toFixed(2)}${itemDisc > 0 ? ` <span style="color: #b91c1c; font-weight: 700;">(-${itemDisc.toFixed(2)} Disc)</span>` : ''}</div>
                    ${itemDiscTotal > 0 ? `<div style="font-size: 9px; color: #b91c1c;">Disc Total: -LKR ${itemDiscTotal.toFixed(2)}</div>` : ''}
                </div>
                <div class="item-total" style="font-weight: 700; text-align: right; white-space: nowrap;">LKR ${itemFinal.toFixed(2)}</div>
            </div>
            `;
        }).join('');

        // Dialog Voucher Thermal QR Section
        let dialogVouchersThermalHtml = '';
        const dialogItems = billItems.filter(item => item.isReload && item.reloadDetails && item.reloadDetails.voucherPin);
        if (dialogItems.length > 0) {
            dialogVouchersThermalHtml = `
                <div class="divider"></div>
                <div style="text-align: center; font-size: 10px; margin-top: 10px;">
                    <div style="font-weight: 800; text-transform: uppercase; color: #000; margin-bottom: 8px;">📱 DIALOG SCAN & RECHARGE</div>
                    ${dialogItems.map(item => `
                        <div style="margin-bottom: 10px;">
                            <div style="font-weight: 800; font-size: 13px; font-family: monospace;">PIN: ${item.reloadDetails.voucherPin}</div>
                            <div style="font-size: 8px; color: #666;">Scan QR below to recharge LKR ${item.price}</div>
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=110x110&data=${encodeURIComponent(item.reloadDetails.voucherUrl || `https://dialog.lk/scan-and-recharge?language=en#code=${btoa(item.reloadDetails.voucherPin)}`)}" 
                                 style="width: 100px; height: 100px; border: 1px solid #ccc; padding: 3px; border-radius: 4px; margin: 5px auto 0; display: block;" />
                        </div>
                    `).join('')}
                </div>
            `;
        }

        printHtml = `
            <html>
            <head>
                <title>Receipt ${receiptNo}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    @page { size: 80mm auto; margin: 0mm; }
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', -apple-system, sans-serif; padding: 10px 8px; color: #1a1a1a; max-width: 76mm; width: 100%; margin: 0 auto; line-height: 1.35; box-sizing: border-box; }
                    .header { text-align: center; margin-bottom: 12px; }
                    .logo { font-size: 18px; font-weight: 800; color: #002060; }
                    .branch-title { font-size: 11px; font-weight: 800; color: #0284c7; margin-top: 2px; }
                    .divider { border-bottom: 1px dashed #bbb; margin: 10px 0; }
                    .receipt-info { font-size: 11px; display: flex; justify-content: space-between; margin-bottom: 5px; color: #555; }
                    .receipt-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 12px; }
                    .item-name { font-weight: 700; text-transform: uppercase; }
                    .item-meta { font-size: 10px; color: #666; }
                    .summary-line { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 12px; }
                    .discount-line { color: #b91c1c; font-weight: 700; background: #fee2e2; padding: 2px 4px; border-radius: 3px; }
                    .loyalty-line { margin: 8px 0; padding: 4px 6px; background: #fef3c7; border: 1px solid #f59e0b; border-radius: 4px; font-weight: 800; font-size: 11px; color: #92400e; display: flex; justify-content: space-between; }
                    .total-line { display: flex; justify-content: space-between; font-weight: 800; font-size: 17px; margin-top: 6px; color: #002060; border-top: 1.5px solid #002060; padding-top: 4px; }
                    .footer { text-align: center; margin-top: 25px; font-size: 10px; color: #888; }
                </style>
            </head>
            <body>
                <div class="header">
                    ${thermalMerchantLogoHtml}
                    <div class="logo">${window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP'}</div>
                    <div class="branch-title">🏢 ${branchDisplayName}</div>
                    <div style="font-size: 10px; margin-top: 2px;">📍 ${branchAddressText}</div>
                    <div style="font-size: 10px;">📞 Tel: ${branchPhoneText}</div>
                    ${branchEmailText ? `<div style="font-size: 9.5px; color: #444;">✉️ ${branchEmailText}</div>` : ''}
                    ${branchWebsiteDisplay ? `<div style="font-size: 9.5px; color: #0284c7; font-weight: 700;">🌐 ${branchWebsiteDisplay}</div>` : ''}
                </div>
                <div class="receipt-info"><span>Date: ${new Date().toLocaleDateString()}</span><span>Inv: #${receiptNo}</span></div>
                <div class="receipt-info" style="margin-top: 2px; color: #111; font-weight: 600;">
                    <span>Cust: ${customerName || 'Walk-in Customer'}</span>
                    <span>${customerPhone ? `Tel: ${customerPhone}` : ''}</span>
                </div>
                <div class="divider"></div>
                ${itemsHtml}
                <div class="divider"></div>
                <div class="summary-line" style="font-weight: 600;"><span>Gross Total:</span><span>LKR ${grossTotalText}</span></div>
                <div class="summary-line discount-line" style="margin: 2px 0;"><span>(-) Total Discount:</span><span>- LKR ${totalDiscountText}</span></div>
                ${settled > 0 ? `<div class="summary-line" style="color: #e30030; font-weight: 600;"><span>(+) Settled Outstanding:</span><span>+ LKR ${settled.toFixed(2)}</span></div>` : ''}
                <div class="total-line"><span>NET PAYABLE:</span><span>LKR ${payableText}</span></div>
                
                ${earnedPts > 0 ? `
                <div class="loyalty-line">
                    <span>⭐ Loyalty Points Earned</span>
                    <span>+${earnedPts} Pts</span>
                </div>` : ''}
                
                <div class="divider" style="border-style: dashed; margin: 8px 0;"></div>
                ${redeemed > 0 ? `<div class="summary-line" style="color: #16a34a; font-weight: 600;"><span>Redeemed Points</span><span>- LKR ${redeemed.toFixed(2)}</span></div>` : ''}
                <div class="summary-line"><span>Cash Tendered</span><span>LKR ${paidVal.toFixed(2)}</span></div>
                <div class="summary-line" style="font-weight: 800; font-size: 13px; margin-top: 4px;"><span>CASH BALANCE</span><span>LKR ${cashBalanceText}</span></div>
                ${manualPointsAdded > 0 ? `<div class="summary-line" style="font-style: italic; font-size: 10px; color: #0284c7; margin-top: 3px;"><span>(Pushed to Loyalty: LKR ${manualPointsAdded.toFixed(2)})</span></div>` : ''}
                
                ${dialogVouchersThermalHtml}
                
                <div class="footer">
                    <p style="margin: 0 0 3px 0;">Thank you for shopping with us!</p>
                    <p style="margin: 0 0 2px 0; font-weight: 700; color: #002060;">mecpos.web.lk</p>
                    <p style="margin: 0; font-size: 8.5px; color: #666;">Software by MEC Global Solutions<br>Sri Lanka's leading cloud ERP & POS platform for modern merchants.</p>
                </div>
                <script>
                    setTimeout(() => {
                        window.focus();
                        window.print();
                        window.close();
                    }, 50);
                </script>
            </body>
            </html>
        `;
    }

    if (window.electron) {
        window.electron.send('print-receipt', { 
            html: printHtml, 
            printerName: window.systemConfig?.printerName || '',
            printerType: pType 
        });
    } else {
        // Use a hidden iframe to print to bypass browser popup blockers
        let iframe = document.getElementById('pos-print-iframe');
        if (!iframe) {
            iframe = document.createElement('iframe');
            iframe.id = 'pos-print-iframe';
            iframe.style.position = 'fixed';
            iframe.style.top = '-9999px';
            iframe.style.left = '-9999px';
            iframe.style.width = '0';
            iframe.style.height = '0';
            iframe.style.border = 'none';
            document.body.appendChild(iframe);
        }
        
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        doc.open();
        doc.write(printHtml);
        doc.close();
        
        setTimeout(() => {
            const prevTitle = document.title;
            try {
                document.title = branchDisplayName + ' - ' + receiptNo;
                iframe.contentWindow.focus();
                iframe.contentWindow.print();
            } catch (e) {
                console.error("Iframe print error:", e);
                // Fallback to window.open if iframe printing fails
                const width = (pType === 'a4' || pType === 'a5') ? 800 : 450;
                const height = (pType === 'a4' || pType === 'a5') ? 900 : 800;
                const printWindow = window.open('', 'POSReceipt', `width=${width},height=${height}`);
                if (printWindow) {
                    printWindow.document.write(printHtml);
                    printWindow.document.close();
                }
            } finally {
                setTimeout(() => { document.title = prevTitle; }, 1000);
            }
        }, 50);
    }
};

// window.shareOnWhatsApp definition moved to end of file for consistency


// This function has been consolidated with the one above.
// SMSLENZ_API_KEY and other constants are now used in the main sendSMSBilling function.

function getBillPlainText() {
    const receiptNo = document.getElementById('pos-receipt-no').innerText;
    const subtotal = document.getElementById('pos-subtotal').innerText;
    const discInput = document.getElementById('pos-bill-discount').value || 0;
    const discType = document.getElementById('pos-discount-type').value;
    const payable = document.getElementById('pos-payable').innerText;
    const paidEl = document.getElementById('pay-modal-tendered');
    const changeEl = document.getElementById('pay-modal-change');
    const paid = paidEl ? paidEl.value || payable : payable;
    const change = changeEl ? changeEl.innerText : "0.00";

    let text = `*MEC PLATFORM ERP - RECEIPT*\n`;
    text += `Receipt: ${receiptNo}\n`;
    text += `Date: ${new Date().toLocaleDateString()}\n\n`;

    currentPOSBill.forEach(item => {
        const netPrice = item.price - (item.discount || 0);
        text += `${item.name} x ${item.quantity} ${item.discount > 0 ? `[Disc ${item.discount}]` : ''} = LKR ${(netPrice * item.quantity).toFixed(2)}\n`;
    });

    text += `\nSubtotal: LKR ${subtotal}\n`;
    if (parseFloat(discInput) > 0) {
        text += `Discount (${discType === '%' ? discInput + '%' : 'LKR ' + discInput}): -LKR ${(parseFloat(subtotal) - parseFloat(payable)).toFixed(2)}\n`;
    }
    text += `*TOTAL PAYABLE: LKR ${payable}*\n`;
    text += `Paid: LKR ${paid}\n`;
    text += `Change: LKR ${change}\n\n`;
    text += `Track Order: mecbookshop.com.lk\n`;
    text += `Thank you for choosing MEC Network!`;
    return text;
}

// --- Sync/Update Logic ---
// --- Stock Management & Purchase History ---
let currentStockInvoice = [];

window.searchProductsForStock = (val) => {
    const resultsDiv = document.getElementById('stock-search-results');
    if (!resultsDiv) return;
    if (!val) { resultsDiv.style.display = 'none'; return; }

    const q = val.toLowerCase();
    const filtered = (window.allProducts || []).filter(p => p.name.toLowerCase().includes(q));

    resultsDiv.innerHTML = filtered.map(p => `
        <div class="search-result-item" onclick="addToStockInvoice('${p.docId}')">
            ${p.name} (Stock: ${p.stock})
        </div>
    `).join('');
    resultsDiv.style.display = 'block';
};

window.addToStockInvoice = (docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;
    if (!currentStockInvoice.find(x => x.docId === docId)) {
        currentStockInvoice.push({ ...p, addedQty: 1 });
    }
    document.getElementById('stock-search').value = '';
    document.getElementById('stock-search-results').style.display = 'none';
    renderStockInvoiceUI();
};



// --- Expenses UI & Logic ---
window.addExpense = async (e) => {
    e.preventDefault();
    const title = document.getElementById('exp-title').value;
    const category = document.getElementById('exp-category').value;
    const amount = parseFloat(document.getElementById('exp-amount').value);
    const date = document.getElementById('exp-date').value;
    let branchId = sessionStorage.getItem('userBranchId') || window.activeBranchFilter || 'main';
    if (branchId === 'Global' || branchId === 'All') branchId = 'main';
    const storeId = window.getStoreId();
    const staffId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Master';
    const staffName = sessionStorage.getItem('userName') || 'Staff';

    try {
        window.showToast(navigator.onLine ? "🚀 Recording expense..." : "💾 Saving expense locally...", "info");
        await addDoc(expensesCol, { 
            title, 
            category, 
            amount, 
            date, 
            branchId, 
            storeId, 
            staffId, 
            staffName, 
            timestamp: serverTimestamp() 
        });
        e.target.reset();
        window.showToast(navigator.onLine ? "✅ Expense recorded." : "✅ Recorded locally", "success");
    } catch (err) {
        console.error("Expense error:", err);
        window.showToast("Failed to record expense.", "error");
    }
};

function renderExpensesUI(expenses) {
    const div = document.getElementById('admin-expense-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();

    const startDateVal = document.getElementById('exp-filter-start-date')?.value;
    const endDateVal = document.getElementById('exp-filter-end-date')?.value;

    const filtered = expenses.filter(ex => {
        // Store filter
        if (ex.storeId && ex.storeId !== storeId) return false;
        if (!ex.storeId && storeId !== 'master') return false;

        // Branch filter
        const currentBranch = window.activeBranchFilter || (userBranch && userBranch !== 'Global' ? userBranch : 'All');
        if (currentBranch !== 'All') {
            const isFilterHorana = currentBranch === 'main' || currentBranch === 'Global' || currentBranch.toLowerCase().includes('horana');
            const expBranchId = (ex.branchId || 'main').toLowerCase();
            const isExpPanadura = expBranchId.includes('panadura') || expBranchId === 'j8lsw5vrjwmssc630dh0';

            if (isFilterHorana) {
                if (isExpPanadura) return false;
            } else if (currentBranch.toLowerCase().includes('panadura') || currentBranch === 'j8lsw5vrjwmssc630dh0') {
                if (!isExpPanadura) return false;
            } else {
                if (ex.branchId !== currentBranch) return false;
            }
        }

        // Date range filtering
        if (startDateVal && ex.date < startDateVal) return false;
        if (endDateVal && ex.date > endDateVal) return false;

        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    const totalAmount = sorted.reduce((sum, ex) => sum + (Number(ex.amount) || 0), 0);

    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8;">
            <span>Showing <strong>${sorted.length}</strong> record(s)</span>
            <span>Total Expense: <strong style="color: #ef4444; font-size: 1.05rem;">LKR ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
        </div>
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.length === 0 ? `<tr><td colspan="5" style="text-align:center; padding: 20px; color:#64748b;">No expenses found for selected range.</td></tr>` : ''}
                ${sorted.map(ex => `
                    <tr>
                        <td>${ex.date}</td>
                        <td>${ex.title}</td>
                        <td><span class="status-badge" style="background:#f1f5f9; color:#475569;">${ex.category}</span></td>
                        <td style="font-weight:700;">LKR ${(Number(ex.amount) || 0).toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteExpense('${ex.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteExpense = async (id) => {
    const docRef = doc(db, 'expenses', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Expense record removed.", "info");
};

// Helper to auto-resolve supplier invoice/purchase status dynamically
function resolvePurchaseInvoiceStatus(p) {
    const total = parseFloat(p.grandTotal || p.totalAmount || p.totalCost || 0);
    const paid = parseFloat(p.paidAmount || p.paid || 0);
    const isCheque = (p.paymentMethod || '').toLowerCase() === 'cheque';
    
    // Check if cheque date has passed (the day after or today)
    if (isCheque && p.chequeDate) {
        const today = new Date(); today.setHours(0,0,0,0);
        const chequeDay = new Date(p.chequeDate); chequeDay.setHours(0,0,0,0);
        if (chequeDay <= today) {
            return 'Paid';
        }
    }

    if (paid >= total && total > 0) return 'Paid';
    if (paid > 0 && paid < total) return 'Partially Paid';
    if (p.status === 'Paid') return 'Paid';
    if (p.status === 'Partially Paid') return 'Partially Paid';
    return 'Pending';
}

// --- Purchases History UI ---
function renderPurchasesUI(_unused) {
    const div = document.getElementById('admin-purchase-history');
    if (!div) return;
    // Purchases are stored in supplierInvoices, not the old 'purchases' collection
    const allInvoices = window.allSupplierInvoices || [];
    const filtered = window.filterByStore(allInvoices);
    const sorted = [...filtered].sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
    if (sorted.length === 0) {
        div.innerHTML = '<p style="color:#94a3b8; padding: 2rem 0;">No purchase history yet. Add stock via Smart Procurement → New Invoice / Purchase.</p>';
        return;
    }
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr>
                <th>Date</th>
                <th>Invoice No</th>
                <th>Supplier</th>
                <th>Items</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Status</th>
            </tr></thead>
            <tbody>
                ${sorted.map(p => {
                    const total = parseFloat(p.grandTotal || p.totalAmount || p.totalCost || 0);
                    const paid = parseFloat(p.paidAmount || p.paid || 0);
                    const autoStatus = resolvePurchaseInvoiceStatus(p);
                    const statusColor = autoStatus === 'Paid' ? '#10b981' : autoStatus === 'Partially Paid' ? '#f59e0b' : '#ef4444';
                    const itemsSummary = (p.items || []).map(i => `${i.name} (${i.qty})`).join(', ') || '—';
                    const isCheque = (p.paymentMethod || '').toLowerCase() === 'cheque';
                    const chequeLabel = (isCheque && p.chequeDate) ? `<br><small style="color:#f59e0b; font-size:0.65rem;">📅 Cheque: ${p.chequeDate}</small>` : '';
                    const invoiceJson = encodeURIComponent(JSON.stringify(p));
                    return `
                    <tr onclick="window.viewPurchaseDetails('${invoiceJson}')" style="cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='none'">
                        <td>${p.date || '—'}</td>
                        <td style="font-family:monospace; color:#38bdf8; font-weight: 700;">${p.invoiceNo || '—'}</td>
                        <td>${p.supplierName || '—'}${chequeLabel}</td>
                        <td style="font-size:0.8rem; max-width:250px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${itemsSummary}">${itemsSummary}</td>
                        <td style="font-weight:700;">LKR ${total.toFixed(2)}</td>
                        <td style="font-weight:700; color:#10b981;">LKR ${paid.toFixed(2)}</td>
                        <td><span class="status-badge" style="background:${statusColor}22; color:${statusColor}; border:1px solid ${statusColor}44;">${autoStatus}</span></td>
                    </tr>`;
                }).join('')}
            </tbody>
        </table>
    `;
}

window.viewPurchaseDetails = (encodedInvoice) => {
    try {
        const p = JSON.parse(decodeURIComponent(encodedInvoice));
        const total = parseFloat(p.grandTotal || p.totalAmount || p.totalCost || 0);
        const paid = parseFloat(p.paidAmount || p.paid || 0);
        const balance = total - paid;
        const autoStatus = resolvePurchaseInvoiceStatus(p);
        
        document.getElementById('pd-supplier').innerText = p.supplierName || '—';
        document.getElementById('pd-invoice-no').innerText = p.invoiceNo || '—';
        document.getElementById('pd-date').innerText = p.date || '—';
        document.getElementById('pd-status').innerText = autoStatus;
        
        document.getElementById('pd-grand-total').innerText = `LKR ${total.toFixed(2)}`;
        document.getElementById('pd-paid').innerText = `LKR ${paid.toFixed(2)}`;
        document.getElementById('pd-balance').innerText = `LKR ${balance.toFixed(2)}`;
        
        const tbody = document.getElementById('pd-items-body');
        if (tbody) {
            const items = p.items || [];
            if (items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:15px; color:#94a3b8;">No items in this purchase log.</td></tr>';
            } else {
                tbody.innerHTML = items.map(item => {
                    const itemCost = parseFloat(item.costPrice || item.cost || item.buyingPrice || 0);
                    const qty = parseFloat(item.qty || item.quantity || 0);
                    const itemTotal = itemCost * qty;
                    return `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px 15px; font-weight:700; color:#fff;">${item.name || '—'}</td>
                            <td style="padding: 10px 15px; text-align: center;">${qty}</td>
                            <td style="padding: 10px 15px; text-align: right;">LKR ${itemCost.toFixed(2)}</td>
                            <td style="padding: 10px 15px; text-align: right; font-weight:700; color:#38bdf8;">LKR ${itemTotal.toFixed(2)}</td>
                        </tr>
                    `;
                }).join('');
            }
        }
        
        const modal = document.getElementById('purchase-details-modal');
        if (modal) modal.style.display = 'flex';
    } catch (err) {
        console.error("Error viewing purchase details:", err);
    }
};


// --- Suppliers UI & Logic ---
window.addSupplier = async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const idField = document.getElementById('sup-id');
    const existingId = idField ? idField.value : '';
    
    const name = document.getElementById('sup-name').value;
    const contact = document.getElementById('sup-contact').value;
    const phone = document.getElementById('sup-phone').value;
    const address = document.getElementById('sup-address').value;

    try {
        if (existingId) {
            const docRef = doc(db, 'suppliers', existingId);
            updateDoc(docRef, {
                name, contact, phone, address,
                lastUpdated: serverTimestamp()
            }).catch(err => {
                console.error("Firestore update supplier error:", err);
                window.showToast("❌ Sync failed: " + err.message, "error");
            });
            window.showToast("✅ Supplier updated.", "success");
            window.cancelEditSupplier?.();
        } else {
            const supId = `SUP-${name.substring(0, 3).toUpperCase().replace(/\s/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
            setDoc(doc(collection(db, 'suppliers'), supId), { 
                name, 
                contact, 
                phone, 
                address, 
                docId: supId,
                storeId: window.getStoreId(),
                timestamp: serverTimestamp() 
            }).catch(err => {
                console.error("Firestore add supplier error:", err);
                window.showToast("❌ Sync failed: " + err.message, "error");
            });
            window.showToast("✅ Supplier added.", "success");
        }
        e.target.reset();
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving supplier", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

// Quick Category Logic
window.openQuickCategoryModal = (targetSelectId) => {
    const modal = document.getElementById('quick-category-modal');
    if (!modal) return;
    document.getElementById('qc-target-select').value = targetSelectId;
    document.getElementById('qc-name').value = '';
    modal.style.display = 'flex';
    document.getElementById('qc-name').focus();
};

window.saveQuickCategory = async (e) => {
    e.preventDefault();
    const name = document.getElementById('qc-name').value.trim();
    if (!name) return;

    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Adding category...", "info");
        addDoc(collection(db, 'categories'), {
            name,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp()
        }).catch(err => {
            console.error("Firestore quick add category error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        
        window.showToast("✅ Category added!", "success");
        document.getElementById('quick-category-modal').style.display = 'none';

        // Auto-select the new category in the target dropdown
        const targetId = document.getElementById('qc-target-select').value;
        const select = document.getElementById(targetId);
        if (select) {
            const option = document.createElement('option');
            option.value = name;
            option.text = name;
            option.selected = true;
            select.appendChild(option);
        }
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving category", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderSuppliersUI(suppliers) {
    const div = document.getElementById('admin-supplier-list');
    if (!div) return;
    const filtered = window.filterByStore(suppliers);
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr><th>Code</th><th>Name</th><th>Contact</th><th>Phone</th><th>Actions</th></tr></thead>
            <tbody>
                ${filtered.map(s => `
                    <tr>
                        <td style="color: #38bdf8; font-weight: bold; font-family: monospace;">${s.docId || '-'}</td>
                        <td><strong>${s.name}</strong></td>
                        <td>${s.contact || '-'}</td>
                        <td>${s.phone || '-'}</td>
                        <td>
                            <div style="display: flex; gap: 8px;">
                                <button class="icon-btn" onclick="window.editSupplier('${s.docId}')" style="color: #10b981; font-size: 1.2rem;">✏️</button>
                                <button class="icon-btn delete" onclick="deleteSupplier('${s.docId}')">🗑️</button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteSupplier = async (id) => {
    const docRef = doc(db, 'suppliers', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Supplier removed.", "info");
};

window.editSupplier = (id) => {
    const supplier = window.allSuppliers.find(s => s.docId === id);
    if (!supplier) return;
    
    document.getElementById('sup-id').value = supplier.docId;
    document.getElementById('sup-name').value = supplier.name || '';
    document.getElementById('sup-contact').value = supplier.contact || '';
    document.getElementById('sup-phone').value = supplier.phone || '';
    document.getElementById('sup-address').value = supplier.address || '';
    
    const submitBtn = document.querySelector('#supplier-form button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'Update Supplier Profile';
    
    document.getElementById('sup-cancel-btn').style.display = 'block';
    
    window.showSubTab('suppliers', 'add');
};

window.cancelEditSupplier = () => {
    document.getElementById('supplier-form').reset();
    document.getElementById('sup-id').value = '';
    
    const submitBtn = document.querySelector('#supplier-form button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'Save Supplier Profile';
    
    document.getElementById('sup-cancel-btn').style.display = 'none';
    window.showSubTab('suppliers', 'list');
};

window.openQuickSupplierModal = (targetSelectId) => {
    document.getElementById('qs-target-select').value = targetSelectId;
    document.getElementById('qs-name').value = '';
    document.getElementById('qs-phone').value = '';
    document.getElementById('quick-supplier-modal').style.display = 'flex';
    document.getElementById('qs-name').focus();
};

document.getElementById('quick-supplier-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('qs-name').value;
    const phone = document.getElementById('qs-phone').value;
    const targetSelectId = document.getElementById('qs-target-select').value;

    const supId = `SUP-${name.substring(0, 3).toUpperCase().replace(/\s/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
    try {
        window.showToast("Saving supplier...", "info");
        const docRef = doc(suppliersCol, supId);
        await setDoc(docRef, { 
            name, 
            phone, 
            docId: supId,
            storeId: window.getStoreId(),
            timestamp: serverTimestamp() 
        });

        // The Snapshot listener in admin.js will update window.allSuppliers automatically,
        // but we need to wait a moment for it to sync or manually trigger a select update.
        const newSupplierId = supId;
        
        // Manually update the target dropdown immediately for UX
        const targetSelect = document.getElementById(targetSelectId);
        if (targetSelect) {
            const option = new Option(name, newSupplierId);
            targetSelect.add(option);
            targetSelect.value = newSupplierId;
        }

        document.getElementById('quick-supplier-modal').style.display = 'none';
        window.showToast("✅ Supplier added and selected!", "success");
    } catch (err) {
        console.error(err);
        window.showToast("Error adding supplier", "error");
    }
});


// --- CSV Exports ---
window.downloadExpensesCSV = () => {
    const expenses = window.allExpenses || [];
    let csv = "Date,Title,Category,Amount\n";
    expenses.forEach(e => csv += `${e.date},${e.title},${e.category},${e.amount}\n`);
    downloadFile(csv, "expenses.csv");
};

window.downloadPurchasesCSV = () => {
    const purchases = window.allPurchases || [];
    let csv = "Date,Items,Total Cost\n";
    purchases.forEach(p => {
        const itemStr = p.items.map(i => `${i.name}(${i.qty})`).join(' | ');
        csv += `${p.date},"${itemStr}",${p.totalCost}\n`;
    });
    downloadFile(csv, "purchase_history.csv");
};

window.downloadFile = function(content, filename) {
    if (window.chrome?.webview) {
        try {
            let base64 = btoa(unescape(encodeURIComponent(content)));
            window.chrome.webview.postMessage(JSON.stringify({
                action: 'save_downloaded_file',
                filename: filename,
                base64: base64
            }));
            window.showToast?.(`✅ ${filename} Downloaded successfully to Downloads folder! <button type="button" onclick="window.openDownloadsFolder()" style="margin-left:10px; background:linear-gradient(135deg, #f59e0b, #d97706); color:#fff; border:none; padding:3px 10px; border-radius:6px; font-weight:800; cursor:pointer; font-size:0.75rem; box-shadow:0 2px 6px rgba(0,0,0,0.3);">📁 Open Folder</button>`, "success");
            return;
        } catch(e) {
            console.error("Native save failed, fallback to blob:", e);
        }
    }
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.showToast?.(`✅ ${filename} Downloaded successfully! <button type="button" onclick="window.openDownloadsFolder()" style="margin-left:10px; background:linear-gradient(135deg, #f59e0b, #d97706); color:#fff; border:none; padding:3px 10px; border-radius:6px; font-weight:800; cursor:pointer; font-size:0.75rem; box-shadow:0 2px 6px rgba(0,0,0,0.3);">📁 Open Folder</button>`, "success");
};

window.escapeCSV = (str) => {
    if (str === null || str === undefined) return '';
    return str.toString().replace(/"/g, '""');
};


// --- Income UI & Logic ---
window.addIncome = async (e) => {
    e.preventDefault();
    const title = document.getElementById('inc-title').value;
    const amount = parseFloat(document.getElementById('inc-amount').value);
    const date = document.getElementById('inc-date').value;

    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    try {
        window.showToast(navigator.onLine ? "🚀 Recording income..." : "💾 Saving income locally...", "info");
        await addDoc(incomeCol, { title, amount, date, branchId, storeId, timestamp: serverTimestamp() });
        e.target.reset();
        window.showToast(navigator.onLine ? "✅ Income recorded." : "✅ Recorded locally", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error saving income", "error");
    }
};

function renderIncomeUI(income) {
    const div = document.getElementById('admin-income-list');
    if (!div) return;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();

    const filtered = income.filter(inc => {
        // Store filter
        if (inc.storeId && inc.storeId !== storeId) return false;
        if (!inc.storeId && storeId !== 'master') return false;

        // Branch filter
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            return inc.branchId === userBranch || (!inc.branchId && userBranch === 'Global');
        } else if (activeBranchFilter !== 'All') {
            return inc.branchId === activeBranchFilter;
        }
        return true;
    });

    const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    div.innerHTML = `
        <table class="admin-table">
            <thead><tr><th>Date</th><th>Source</th><th>Amount</th><th>Actions</th></tr></thead>
            <tbody>
                ${sorted.map(inc => `
                    <tr>
                        <td>${inc.date}</td>
                        <td>${inc.title}</td>
                        <td style="font-weight:700; color:#10b981;">+ LKR ${inc.amount.toFixed(2)}</td>
                        <td><button class="icon-btn delete" onclick="deleteIncome('${inc.docId}')">🗑️</button></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

window.deleteIncome = async (id) => {
    const docRef = doc(db, 'income', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
};

// --- Customer ID Generation ---
window.generateCustomerID = () => {
    const custType = document.getElementById('cust-type').value;
    const custIdInput = document.getElementById('cust-id');
    const label = document.getElementById('cust-id-label');
    const filtered = window.filterByStore(window.allCustomers || []);

    if (!custIdInput) return;

    if (custType === 'wholesale') {
        const count = filtered.filter(c => c.customerType === 'wholesale').length;
        custIdInput.value = 'WHO-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Wholesale Shop ID';
    } else if (custType === 'loyalty') {
        const count = filtered.filter(c => c.customerType === 'loyalty').length;
        custIdInput.value = 'LO-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Loyalty Card No';
    } else {
        const count = filtered.filter(c => c.customerType === 'retail').length;
        custIdInput.value = 'RET-' + String(count + 1).padStart(3, '0');
        label.innerText = 'Member ID';
    }

    // [v3.9.63] Fallback if auto-generation is stuck
    if (!custIdInput.value || custIdInput.value === "") {
        const prefix = custType === 'wholesale' ? 'WHO' : (custType === 'loyalty' ? 'LO' : 'RET');
        custIdInput.value = prefix + "-" + Math.floor(100 + Math.random() * 899);
    }
};

// --- Customer UI & Logic ---
window.addCustomer = async (e) => {
    e.preventDefault();
    const name = document.getElementById('cust-name').value;
    const phone = document.getElementById('cust-phone').value;
    const email = document.getElementById('cust-email').value;
    const address = document.getElementById('cust-address').value;
    const customerType = document.getElementById('cust-type').value;
    const loyaltyCardNo = document.getElementById('cust-id').value;

    if (!name || !phone) {
        window.showToast("⚠️ Name and Phone are required!", "error");
        return;
    }

    const cleanedPhone = phone.trim().replace(/\D/g, '');
    const currentStoreId = window.getStoreId();
    const phoneExists = (window.allCustomers || []).some(c => {
        const cPhone = (c.phone || '').trim().replace(/\D/g, '');
        return cPhone === cleanedPhone && c.storeId === currentStoreId;
    });

    if (phoneExists) {
        window.showToast("⚠️ A customer with this phone number already exists!", "error");
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    try {
        window.showToast("🚀 Registering customer...", "info");
        addDoc(customersCol, { 
            name, phone, email, address, 
            loyaltyCardNo,
            customerType,
            storeId: window.getStoreId(), 
            timestamp: serverTimestamp(),
            outstanding: 0
        }).catch(err => {
            console.error("Firestore add customer error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        
        e.target.reset();
        window.generateCustomerID(); // Re-generate for next
        window.showToast(`✅ Customer registered! ID: ${loyaltyCardNo}`, "success");
        
        // Return to list view
        if (typeof window.showSubTab === 'function') window.showSubTab('customers', 'list');
    } catch (err) { 
        console.error(err);
        window.showToast("❌ Registration failed: " + err.message, "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
};

function renderCustomersUI(customers) {
    const div = document.getElementById('admin-customer-list');
    if (!div) return;

    const filtered = window.filterByStore(customers || []);
    const allOrders = window.allOrders || [];
    const allRepairs = window.allRepairJobs || [];

    // Build enriched customer objects with stats from orders & repairs
    const enriched = filtered.map(c => {
        const custOrders = allOrders.filter(o =>
            (o.customerId && o.customerId === c.docId) ||
            (o.customerPhone && c.phone && o.customerPhone === c.phone) ||
            (o.userName && o.userName !== 'Walk-in Customer' && o.userName === c.name)
        );
        const totalSpent = custOrders.reduce((s, o) => s + parseFloat(o.total || o.grandTotal || 0), 0);
        const lastOrder = custOrders.length ? custOrders.slice().sort((a, b) => {
            const ta = a.timestamp && a.timestamp.seconds ? a.timestamp.seconds : new Date(a.date || 0).getTime()/1000;
            const tb = b.timestamp && b.timestamp.seconds ? b.timestamp.seconds : new Date(b.date || 0).getTime()/1000;
            return tb - ta;
        })[0] : null;
        const lastVisit = lastOrder ? (lastOrder.timestamp && lastOrder.timestamp.seconds
            ? new Date(lastOrder.timestamp.seconds * 1000).toLocaleDateString()
            : new Date(lastOrder.date || lastOrder.createdAt || '').toLocaleDateString()) : '—';
        const repairCount = allRepairs.filter(r =>
            (r.customerPhone && c.phone && r.customerPhone === c.phone) ||
            (r.customerId && r.customerId === c.docId)
        ).length;
        return Object.assign({}, c, {_orders: custOrders.length, _spent: totalSpent, _lastVisit: lastVisit, _repairs: repairCount});
    });

    // Stats
    const totalSpentAll = enriched.reduce((s, c) => s + c._spent, 0);
    const loyaltyCount = enriched.filter(c => c.customerType === 'loyalty').length;
    const wholesaleCount = enriched.filter(c => c.customerType === 'wholesale').length;
    const totalLoyaltyPoints = enriched.reduce((s, c) => s + parseInt(c.loyaltyPoints || 0, 10), 0);

    // Search & filter
    const searchVal = (document.getElementById('crm-search') ? document.getElementById('crm-search').value : '').toLowerCase();
    const typeFilter = document.getElementById('crm-type-filter') ? document.getElementById('crm-type-filter').value : 'all';
    const sortBy = document.getElementById('crm-sort') ? document.getElementById('crm-sort').value : 'name';

    let list = enriched.filter(c => {
        const matchSearch = !searchVal ||
            (c.name || '').toLowerCase().includes(searchVal) ||
            (c.phone || '').toLowerCase().includes(searchVal) ||
            (c.loyaltyCardNo || '').toLowerCase().includes(searchVal) ||
            (c.email || '').toLowerCase().includes(searchVal);
        const matchType = typeFilter === 'all' || c.customerType === typeFilter;
        return matchSearch && matchType;
    });

    list.sort((a, b) => {
        if (sortBy === 'spent') return b._spent - a._spent;
        if (sortBy === 'orders') return b._orders - a._orders;
        if (sortBy === 'recent') {
            const da = a._lastVisit === '—' ? 0 : new Date(a._lastVisit).getTime();
            const db2 = b._lastVisit === '—' ? 0 : new Date(b._lastVisit).getTime();
            return db2 - da;
        }
        return (a.name || '').localeCompare(b.name || '');
    });

    function typeTag(t) {
        if (t === 'loyalty') return '<span style="background:#eef2ff;color:#6366f1;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #6366f133;">💎 Loyalty</span>';
        if (t === 'wholesale') return '<span style="background:#fffbeb;color:#d97706;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #d9770633;">📦 Wholesale</span>';
        return '<span style="background:#f0fdf4;color:#059669;padding:3px 10px;border-radius:20px;font-size:0.65rem;font-weight:800;border:1px solid #05996933;">🛍️ Retail</span>';
    }

    const rows = list.map(c => {
        const idTag = c.loyaltyCardNo ? '🪪 ' + c.loyaltyCardNo : '';
        const showPoints = c.customerType === 'loyalty' || (c.loyaltyPoints && c.loyaltyPoints > 0);
        const ptsTag = showPoints ? ' &nbsp;·&nbsp; ⭐ ' + (c.loyaltyPoints || 0) + ' pts' : '';
        const repairCell = c._repairs > 0 ? '<span style="color:#f59e0b;font-weight:800;">🔧 ' + c._repairs + '</span>' : '—';
        const did = c.docId;
        return '<tr style="border-bottom:1px solid rgba(255,255,255,0.04);cursor:pointer;" data-did="' + did + '">' +
            '<td style="padding:14px;"><div style="font-weight:800;font-size:0.95rem;">' + c.name + '</div>' +
            '<div style="font-size:0.72rem;color:#64748b;margin-top:2px;">' + idTag + ptsTag + '</div></td>' +
            '<td style="padding:14px;"><div style="font-size:0.85rem;">📱 ' + (c.phone || '—') + '</div>' +
            (c.email ? '<div style="font-size:0.72rem;color:#64748b;">✉️ ' + c.email + '</div>' : '') + '</td>' +
            '<td style="padding:14px;text-align:center;">' + typeTag(c.customerType) + '</td>' +
            '<td style="padding:14px;text-align:right;font-weight:800;color:#38bdf8;">' + c._orders + '</td>' +
            '<td style="padding:14px;text-align:right;font-weight:900;color:#10b981;">LKR ' + c._spent.toFixed(2) + '</td>' +
            '<td style="padding:14px;text-align:center;">' + repairCell + '</td>' +
            '<td style="padding:14px;text-align:center;font-size:0.82rem;color:#94a3b8;">' + c._lastVisit + '</td>' +
            '<td style="padding:14px;text-align:right;" data-stop="1">' +
            '<div style="display:flex;gap:6px;justify-content:flex-end;">' +
            '<button data-sms="' + did + '" title="Send SMS via SMSLenz" style="background:rgba(2,132,199,0.15);border:1px solid rgba(2,132,199,0.3);color:#0284c7;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">✉️</button>' +
            '<button data-wa="' + did + '" title="Send WhatsApp Message" style="background:rgba(37,211,102,0.15);border:1px solid rgba(37,211,102,0.3);color:#25d366;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">💬</button>' +
            '<button data-view="' + did + '" title="View Profile" style="background:rgba(99,102,241,0.15);border:1px solid rgba(99,102,241,0.3);color:#6366f1;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">👤</button>' +
            '<button data-qr="' + did + '" title="Print Loyalty QR Card" style="background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#10b981;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">🖨️</button>' +
            '<button data-edit="' + did + '" title="Edit" style="background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.2);color:#38bdf8;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">✏️</button>' +
            '<button data-del="' + did + '" title="Delete" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#ef4444;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:0.85rem;">🗑️</button>' +
            '</div></td>' +
            '</tr>';
    }).join('');

    div.innerHTML = '<div style="padding:0 0 20px 0;">' +
    '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:22px;">' +
        '<div style="background:linear-gradient(135deg,#6366f133,#6366f111);border:1px solid #6366f133;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#6366f1;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Customers</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#6366f1;margin-top:4px;">' + enriched.length + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#10b98133,#10b98111);border:1px solid #10b98133;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#10b981;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Revenue</div>' +
            '<div style="font-size:1.4rem;font-weight:900;color:#10b981;margin-top:4px;">LKR ' + totalSpentAll.toFixed(2) + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#8b5cf633,#8b5cf611);border:1px solid #8b5cf633;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#8b5cf6;font-weight:800;letter-spacing:1px;text-transform:uppercase;">💎 Loyalty Members</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#8b5cf6;margin-top:4px;">' + loyaltyCount + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#f59e0b33,#f59e0b11);border:1px solid #f59e0b33;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#f59e0b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">📦 Wholesale</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#f59e0b;margin-top:4px;">' + wholesaleCount + '</div></div>' +
        '<div style="background:linear-gradient(135deg,#06b6d433,#06b6d411);border:1px solid #06b6d433;border-radius:14px;padding:16px;">' +
            '<div style="font-size:0.65rem;color:#06b6d4;font-weight:800;letter-spacing:1px;text-transform:uppercase;">⭐ Total Loyalty Points</div>' +
            '<div style="font-size:2rem;font-weight:900;color:#06b6d4;margin-top:4px;">' + totalLoyaltyPoints + '</div></div>' +
    '</div>' +
    '<div style="display:flex;gap:12px;margin-bottom:18px;flex-wrap:wrap;align-items:center;">' +
        '<input id="crm-search" placeholder="🔍  Search name, phone, ID..." oninput="renderCustomersUI(window.allCustomers||[])" value="' + searchVal.replace(/"/g,'&quot;') + '" style="flex:1;min-width:200px;padding:10px 16px;border-radius:10px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.9rem;outline:none;">' +
        '<select id="crm-type-filter" onchange="renderCustomersUI(window.allCustomers||[])" style="padding:10px 14px;border-radius:10px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.85rem;">' +
            '<option value="all"' + (typeFilter==='all'?' selected':'') + '>All Types</option>' +
            '<option value="retail"' + (typeFilter==='retail'?' selected':'') + '>🛍️ Retail</option>' +
            '<option value="loyalty"' + (typeFilter==='loyalty'?' selected':'') + '>💎 Loyalty</option>' +
            '<option value="wholesale"' + (typeFilter==='wholesale'?' selected':'') + '>📦 Wholesale</option>' +
        '</select>' +
        '<select id="crm-sort" onchange="renderCustomersUI(window.allCustomers||[])" style="padding:10px 14px;border-radius:10px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);color:#fff;font-size:0.85rem;">' +
            '<option value="name"' + (sortBy==='name'?' selected':'') + '>Sort: Name A-Z</option>' +
            '<option value="spent"' + (sortBy==='spent'?' selected':'') + '>Sort: Top Spenders</option>' +
            '<option value="orders"' + (sortBy==='orders'?' selected':'') + '>Sort: Most Orders</option>' +
            '<option value="recent"' + (sortBy==='recent'?' selected':'') + '>Sort: Recent Visit</option>' +
        '</select>' +
        '<span style="font-size:0.8rem;color:#64748b;white-space:nowrap;">' + list.length + ' customers</span>' +
    '</div>' +
    (list.length === 0
        ? '<div style="text-align:center;padding:60px;color:#64748b;">No customers match your search.</div>'
        : '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;color:white;">' +
          '<thead><tr style="border-bottom:1px solid rgba(255,255,255,0.08);">' +
          '<th style="padding:12px 14px;text-align:left;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Customer</th>' +
          '<th style="padding:12px 14px;text-align:left;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Contact</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Type</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Orders</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Total Spent</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Repairs</th>' +
          '<th style="padding:12px 14px;text-align:center;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Last Visit</th>' +
          '<th style="padding:12px 14px;text-align:right;font-size:0.7rem;color:#64748b;font-weight:800;letter-spacing:1px;text-transform:uppercase;">Actions</th>' +
          '</tr></thead><tbody>' + rows + '</tbody></table></div>') +
    '</div>';

    // Event delegation for data-did rows and buttons (use cloneNode trick to clear old listeners)
    if (!div._crmListenerSet) {
        div._crmListenerSet = true;
        div.addEventListener('click', function(ev) {
            var btn = ev.target.closest('button');
            if (btn) {
                ev.stopPropagation();
                if (btn.dataset.sms) { window.sendCustomerDirectSMS(btn.dataset.sms); return; }
                if (btn.dataset.wa) { window.sendCustomerDirectWhatsApp(btn.dataset.wa); return; }
                if (btn.dataset.view) { window.viewCustomerProfile(btn.dataset.view); return; }
                if (btn.dataset.qr) { window.printCustomerQRCard(btn.dataset.qr); return; }
                if (btn.dataset.edit) { window.openCustomerEditModal(btn.dataset.edit); return; }
                if (btn.dataset.del) { window.deleteCustomer(btn.dataset.del); return; }
            }
            var tr = ev.target.closest('tr[data-did]');
            if (tr && !ev.target.closest('[data-stop]')) {
                window.viewCustomerProfile(tr.dataset.did);
            }
        });
    }
}

// Customer Profile Popup
window.viewCustomerProfile = function(id) {
    var c = (window.allCustomers || []).find(function(x) { return x.docId === id; });
    if (!c) return;

    var allOrders = window.allOrders || [];
    var allRepairs = window.allRepairJobs || [];

    var custOrders = allOrders.filter(function(o) {
        return (o.customerId && o.customerId === c.docId) ||
            (o.customerPhone && c.phone && o.customerPhone === c.phone) ||
            (o.userName && o.userName !== 'Walk-in Customer' && o.userName === c.name);
    }).sort(function(a, b) {
        var ta = a.timestamp && a.timestamp.seconds ? a.timestamp.seconds : 0;
        var tb = b.timestamp && b.timestamp.seconds ? b.timestamp.seconds : 0;
        return tb - ta;
    });

    var custRepairs = allRepairs.filter(function(r) {
        return (r.customerPhone && c.phone && r.customerPhone === c.phone) ||
            (r.customerId && r.customerId === c.docId);
    });

    var totalSpent = custOrders.reduce(function(s, o) { return s + parseFloat(o.total || o.grandTotal || 0); }, 0);

    var orderRows = custOrders.slice(0, 20).map(function(o) {
        var dateStr = o.timestamp && o.timestamp.seconds ? new Date(o.timestamp.seconds*1000).toLocaleDateString() : (o.date || '—');
        return '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#94a3b8;">' + dateStr + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#fff;font-weight:700;">#' + (o.orderId || o.id || '—') + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#64748b;">' + (o.paymentMethod || '—') + '</td>' +
            '<td style="padding:8px 10px;font-size:0.8rem;color:#10b981;font-weight:800;text-align:right;">LKR ' + parseFloat(o.total||o.grandTotal||0).toFixed(2) + '</td>' +
            '</tr>';
    }).join('');

    var repairRows = custRepairs.slice(0,5).map(function(r) {
        return '<div style="padding:8px 12px;background:rgba(245,158,11,0.08);border-radius:8px;font-size:0.8rem;margin-bottom:6px;">🔧 <strong>' + (r.deviceModel||r.device||r.itemDescription||'Device') + '</strong> — ' + (r.issue||r.description||'Repair') + ' <span style="float:right;color:#f59e0b;font-weight:800;">' + (r.status||'—') + '</span></div>';
    }).join('');

    document.getElementById('sinv-edit-modal-overlay') && document.getElementById('sinv-edit-modal-overlay').remove();
    var overlay = document.createElement('div');
    overlay.id = 'sinv-edit-modal-overlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:10000000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(10px);';
    overlay.onclick = function(e) { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = '<div style="width:600px;max-height:85vh;overflow-y:auto;background:#0f172a;border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:28px;box-shadow:0 30px 100px rgba(0,0,0,0.8);">' +
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:24px;">' +
            '<div style="display:flex;align-items:center;gap:14px;">' +
                '<div style="width:52px;height:52px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:900;color:white;">' + (c.name||'?')[0].toUpperCase() + '</div>' +
                '<div><div style="font-size:1.3rem;font-weight:900;color:#fff;">' + c.name + '</div>' +
                '<div style="font-size:0.8rem;color:#64748b;">📱 ' + (c.phone||'—') + ' &nbsp;·&nbsp; ' + (c.loyaltyCardNo||'No ID') + '</div></div>' +
            '</div>' +
            '<button onclick="document.getElementById(\'sinv-edit-modal-overlay\').remove()" style="background:rgba(255,255,255,0.05);border:none;color:white;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.2rem;">✕</button>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:24px;">' +
            '<div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#10b981;font-weight:800;letter-spacing:1px;">TOTAL SPENT</div>' +
                '<div style="font-size:1.2rem;font-weight:900;color:#10b981;">LKR ' + totalSpent.toFixed(2) + '</div></div>' +
            '<div style="background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#38bdf8;font-weight:800;letter-spacing:1px;">ORDERS</div>' +
                '<div style="font-size:1.3rem;font-weight:900;color:#38bdf8;">' + custOrders.length + '</div></div>' +
            '<div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.2);border-radius:12px;padding:14px;text-align:center;">' +
                '<div style="font-size:0.65rem;color:#f59e0b;font-weight:800;letter-spacing:1px;">LOYALTY PTS</div>' +
                '<div style="font-size:1.3rem;font-weight:900;color:#f59e0b;">' + (c.loyaltyPoints||0) + '</div></div>' +
        '</div>' +
        '<div style="margin-bottom:20px;">' +
            '<div style="font-size:0.8rem;font-weight:900;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px;">📋 Purchase History</div>' +
            (custOrders.length === 0
                ? '<div style="color:#475569;font-size:0.85rem;padding:20px;text-align:center;">No purchases found.</div>'
                : '<table style="width:100%;border-collapse:collapse;"><thead><tr style="border-bottom:1px solid rgba(255,255,255,0.08);"><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Date</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Order</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:left;">Method</th><th style="padding:8px 10px;font-size:0.68rem;color:#64748b;text-align:right;">Amount</th></tr></thead><tbody>' + orderRows + '</tbody></table>' +
                (custOrders.length > 20 ? '<div style="font-size:0.72rem;color:#64748b;padding:8px;text-align:center;">Showing 20 of ' + custOrders.length + ' orders</div>' : '')) +
        '</div>' +
        (custRepairs.length > 0 ? '<div><div style="font-size:0.8rem;font-weight:900;color:#94a3b8;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px;">🔧 Service Center History</div>' + repairRows + '</div>' : '') +
        '<div style="display:flex;gap:10px;margin-top:20px;flex-wrap:wrap;">' +
            '<button id="crm-profile-sms-btn" style="flex:1;min-width:140px;background:linear-gradient(135deg,#0284c7,#0369a1);border:none;color:white;padding:13px;border-radius:12px;font-weight:900;font-size:0.9rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;">✉️ Send SMS</button>' +
            '<button id="crm-profile-wa-btn" style="flex:1;min-width:140px;background:linear-gradient(135deg,#25d366,#128c7e);border:none;color:white;padding:13px;border-radius:12px;font-weight:900;font-size:0.9rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;">💬 WhatsApp</button>' +
            '<button id="crm-profile-edit-btn" style="flex:1;min-width:140px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;color:white;padding:13px;border-radius:12px;font-weight:900;font-size:0.9rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;">✏️ Edit</button>' +
        '</div>' +
    '</div>';

    document.body.appendChild(overlay);
    // Wire buttons
    var smsBtn = document.getElementById('crm-profile-sms-btn');
    if (smsBtn) {
        smsBtn.onclick = function() {
            window.sendCustomerDirectSMS(id);
        };
    }
    var waBtn = document.getElementById('crm-profile-wa-btn');
    if (waBtn) {
        waBtn.onclick = function() {
            window.sendCustomerDirectWhatsApp(id);
        };
    }
    var editBtn = document.getElementById('crm-profile-edit-btn');
    if (editBtn) {
        editBtn.onclick = function() {
            var ov = document.getElementById('sinv-edit-modal-overlay');
            if (ov) ov.remove();
            window.openCustomerEditModal(id);
        };
    }
};

window.openCustomerEditModal = (id) => {
    const cust = (window.allCustomers || []).find(c => c.docId === id);
    if (!cust) return;

    document.getElementById('edit-cust-id').value = id;
    document.getElementById('edit-cust-loyalty').value = cust.loyaltyCardNo || '-';
    document.getElementById('edit-cust-name').value = cust.name || '';
    document.getElementById('edit-cust-phone').value = cust.phone || '';
    document.getElementById('edit-cust-email').value = cust.email || '';
    document.getElementById('edit-cust-address').value = cust.address || '';
    document.getElementById('edit-cust-type').value = cust.customerType || 'retail';

    document.getElementById('customer-edit-modal').style.display = 'flex';
};

document.getElementById('edit-customer-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = e.target.querySelector('button[type="submit"]') || e.target.querySelector('button');
    const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '⏳ Saving...';
    }

    const id = document.getElementById('edit-cust-id').value;
    const data = {
        name: document.getElementById('edit-cust-name').value,
        phone: document.getElementById('edit-cust-phone').value,
        email: document.getElementById('edit-cust-email').value,
        address: document.getElementById('edit-cust-address').value,
        customerType: document.getElementById('edit-cust-type').value
    };

    try {
        updateDoc(doc(db, 'customers', id), data).catch(err => {
            console.error("Firestore update customer error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });
        document.getElementById('customer-edit-modal').style.display = 'none';
        window.showToast("✅ Customer updated successfully", "success");
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error updating customer", "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    }
});

window.deleteCustomer = async (id) => {
    const docRef = doc(db, 'customers', id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Customer record removed.", "info");
};

window.printCustomerQRCard = (id) => {
    const c = (window.allCustomers || []).find(x => x.docId === id);
    if (!c) {
        window.showToast("Customer not found!", "error");
        return;
    }
    document.getElementById('print-qr-cust-id').value = id;
    document.getElementById('customer-qr-print-modal').style.display = 'flex';
};

window.confirmPrintCustomerQRCard = (slot) => {
    document.getElementById('customer-qr-print-modal').style.display = 'none';
    
    const id = document.getElementById('print-qr-cust-id').value;
    const c = (window.allCustomers || []).find(x => x.docId === id);
    if (!c) {
        window.showToast("Customer not found!", "error");
        return;
    }
    
    const qrData = c.phone || c.loyaltyCardNo || c.docId;
    const storeName = window.STORE_CONFIG?.name || "MEC Book Shop";
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrData)}`;
    
    let positioningCss = '';
    if (slot > 0) {
        const row = Math.ceil(slot / 2) - 1;
        const col = (slot % 2 === 1) ? 0 : 1;
        const leftVal = 15 + col * 95;
        const topVal = 15 + row * 54;
        positioningCss = `position: absolute; left: ${leftVal}mm; top: ${topVal}mm; box-shadow: none; border: 1.5px solid #000;`;
    } else {
        positioningCss = `margin: auto; border: 2px solid #0ea5e9; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);`;
    }
    
    // Remove old iframe if it exists to ensure a clean lifecycle/reset in WebView2
    const oldIframe = document.getElementById('qr-print-iframe');
    if (oldIframe) {
        oldIframe.parentNode.removeChild(oldIframe);
    }
    
    // Create a fresh new iframe
    const iframe = document.createElement('iframe');
    iframe.id = 'qr-print-iframe';
    iframe.style.position = 'fixed';
    iframe.style.bottom = '0';
    iframe.style.right = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    document.body.appendChild(iframe);
    
    const iframeDoc = iframe.contentWindow.document;
    iframeDoc.open();
    iframeDoc.write(`
        <html>
        <head>
            <title>Print Loyalty Card</title>
            <style>
                @page {
                    size: A4;
                    margin: 0;
                }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    margin: 0;
                    padding: 0;
                    width: 210mm;
                    height: 297mm;
                    position: relative;
                    background: white;
                    -webkit-print-color-adjust: exact;
                }
                .card {
                    width: 85mm;
                    height: 50mm;
                    background: #ffffff;
                    border-radius: 8px;
                    padding: 4mm;
                    box-sizing: border-box;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                    ${positioningCss}
                }
                .header {
                    font-size: 0.75rem;
                    font-weight: 800;
                    color: #0284c7;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    border-bottom: 1px solid #e0f2fe;
                    padding-bottom: 2px;
                }
                .content {
                    display: flex;
                    align-items: center;
                    gap: 4mm;
                    margin: 2mm 0;
                    flex: 1;
                }
                .details {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                }
                .name {
                    font-size: 0.85rem;
                    font-weight: 800;
                    color: #1f2937;
                    margin-bottom: 2px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .info {
                    font-size: 0.65rem;
                    color: #4b5563;
                    margin: 1px 0;
                }
                .qr-code {
                    width: 22mm;
                    height: 22mm;
                    border: 1px solid #e5e7eb;
                    padding: 1px;
                    background: white;
                    border-radius: 4px;
                }
                .footer {
                    font-size: 0.55rem;
                    color: #9ca3af;
                    text-align: center;
                    margin-top: auto;
                    border-top: 1px dashed #f3f4f6;
                    padding-top: 2px;
                }
                @media print {
                    .card {
                        border: 1.5px solid #000;
                    }
                }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="header">${storeName}</div>
                <div class="content">
                    <div class="details">
                        <div class="name">${c.name}</div>
                        <div class="info"><b>ID:</b> ${c.loyaltyCardNo || "N/A"}</div>
                        <div class="info"><b>Phone:</b> ${c.phone || "—"}</div>
                        <div class="info"><b>Type:</b> ${c.customerType ? c.customerType.toUpperCase() : "RETAIL"}</div>
                    </div>
                    <img class="qr-code" src="${qrUrl}" alt="QR Code" id="qr-img">
                </div>
                <div class="footer">Scan at POS to retrieve customer profile</div>
            </div>
            <script>
                document.getElementById('qr-img').onload = function() {
                    setTimeout(function() {
                        window.focus();
                        window.print();
                    }, 300);
                };
            <\/script>
        </body>
        </html>
    `);
    iframeDoc.close();
};

// --- Sync & Clock ---
// Duplicate removed. Unified at line 3833.

// --- Power Tools: Emergency Cleanup ---
window.purgeBadProducts = async () => {
    if (!await window.verifyDeletePermission()) return;
    
    const batch = writeBatch(db);
    let deletedCount = 0;
    
    (window.allProducts || []).forEach(p => {
        const nameStr = p.name ? p.name.toString().trim() : '';
        // If name is purely numeric (digits/dots) and doesn't look like a real name
        // Also check if SKU is missing or if name is a long barcode ( > 5 digits)
        if (/^\d+(\.\d+)?$/.test(nameStr) && (nameStr.length > 5 || !p.sku)) {
            batch.delete(doc(db, 'products', p.docId));
            deletedCount++;
        }
    });
    
    if (deletedCount > 0) {
        await batch.commit();
        window.showToast(`✅ Successfully purged ${deletedCount} bad products!`, "success");
    } else {
        window.showToast("No products with numeric names were found.", "info");
    }
};

window.previewMainImage = (input, previewId) => {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px; margin-top: 10px;">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
};

window.toggleVariantSection = (checked) => {
    document.getElementById('variants-container').style.display = checked ? 'block' : 'none';
    document.getElementById('p-main-image-group').style.display = checked ? 'none' : 'block';
    // Base fields are now inside the stocks tab, so we don't strictly need to hide them if we use a different approach, 
    // but the user wants variants to replace base stock.
};

window.addVariantField = () => {
    const list = document.getElementById('variant-list');
    if (!list) return;
    const id = Date.now();
    const div = document.createElement('div');
    div.className = 'variant-row';
    
    div.style = `
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(99,179,237,0.15);
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 14px;
        position: relative;
    `;
    
    const supplierOptions = (window.allSuppliers || []).map(s => 
        `<option value="${s.name}">${s.name}</option>`
    ).join('');

    const pName = document.getElementById('p-name')?.value || 'ITEM';
    const pSup = document.getElementById('p-supplier');
    const pSupId = pSup ? pSup.value : 'SUP-GEN-0000';
    
    // Generate a structured placeholder ID (Size/Color will be 0000 until edited)
    const baseId = window.generateStructuredSKU ? window.generateStructuredSKU({ name: pName, supplierId: pSupId, price: 0, cost: 0 }) : `SKU-TEMP-${Math.floor(Math.random()*1000)}`;

    div.innerHTML = `
        <!-- Header row: Variant ID + delete button -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:0.65rem; opacity:0.5; text-transform:uppercase; letter-spacing:0.08em;">Variant ID</span>
                <input type="text" class="v-id" value="${baseId}" 
                    style="font-weight:700; color:#38bdf8; font-size:0.85rem; background:rgba(56,189,248,0.07); 
                           border:1px solid rgba(56,189,248,0.2); border-radius:8px; padding:4px 10px; width:140px; height:32px;">
            </div>
            <button type="button" onclick="this.closest('.variant-row').remove()" 
                style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.3); color:#f87171;
                       border-radius:8px; width:30px; height:30px; cursor:pointer; font-size:0.85rem;
                       display:flex; align-items:center; justify-content:center; flex-shrink:0;">✕</button>
        </div>

        <!-- Hidden fields for backward compatibility -->
        <select class="v-supplier" style="display:none;"><option value="General">General</option>${supplierOptions}</select>
        <input type="hidden" class="v-name" value="Variant Item">
        <input type="hidden" class="v-wholesale" value="0">
        <input type="hidden" class="v-loyalty" value="0">
        <input type="hidden" class="v-stock" value="0">

        <!-- Main clean fields grid: Size, Color, Cost, MRP only -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em; color:#c084fc;">📐 Size</label>
                <select class="v-size"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.25); height:36px; border-radius:8px; width:100%; color:#e2e8f0; border:1px solid rgba(192,132,252,0.25); padding:0 8px;"
                    onchange="(function(sel){ const c = sel.parentElement.querySelector('.v-size-custom'); if(c){ c.style.display = sel.value==='__other__' ? 'block' : 'none'; if(sel.value!=='__other__') c.value=''; } })(this)">
                    <option value="">-- Select Size --</option>
                    <option>XS</option><option>S</option><option>M</option><option>L</option>
                    <option>XL</option><option>XXL</option><option>XXXL</option>
                    <option>250g</option><option>500g</option><option>1kg</option><option>2kg</option><option>5kg</option>
                    <option>250ml</option><option>500ml</option><option>1L</option><option>2L</option>
                    <option>Standard</option><option>Small</option><option>Medium</option><option>Large</option><option>One Size</option>
                    <option value="__other__">Other (Custom)...</option>
                </select>
                <input type="text" class="v-size-custom" placeholder="Type custom size..."
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px; margin-top:4px; width:100%; display:none;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em; color:#7dd3fc;">🎨 Color</label>
                <select class="v-color"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.25); height:36px; border-radius:8px; width:100%; color:#e2e8f0; border:1px solid rgba(99,179,237,0.25); padding:0 8px;"
                    onchange="(function(sel){ const c = sel.parentElement.querySelector('.v-color-custom'); if(c){ c.style.display = sel.value==='__other__' ? 'block' : 'none'; if(sel.value!=='__other__') c.value=''; } })(this)">
                    <option value="">-- Select Color --</option>
                    <option>Red</option><option>Blue</option><option>Black</option><option>Green</option>
                    <option>Yellow</option><option>White</option><option>Orange</option><option>Purple</option>
                    <option>Pink</option><option>Brown</option><option>Grey</option><option>Navy</option>
                    <option>Maroon</option><option>Gold</option><option>Silver</option><option>Beige</option>
                    <option>Cyan</option><option>Magenta</option><option>Cream</option><option>Transparent</option>
                    <option value="__other__">Other (Custom)...</option>
                </select>
                <input type="text" class="v-color-custom" placeholder="Type custom color..."
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px; margin-top:4px; width:100%; display:none;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Cost (Buying)</label>
                <input type="number" class="v-cost" step="0.01" min="0" placeholder="0.00"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">MRP (Selling)</label>
                <input type="number" class="v-price" step="0.01" min="0" placeholder="0.00" oninput="window.autoCalculateVariantPrices(this)"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
        </div>

        <!-- Variant image row -->
        <div style="display:flex; align-items:center; gap:12px; margin-top:12px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.05);">
            <div id="v-prev-${id}" style="width:44px; height:44px; border-radius:10px; overflow:hidden; border:1px solid rgba(255,255,255,0.15); background:rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; font-size:0.55rem; color:#64748b; flex-shrink:0;">No Img</div>
            <div class="input-group" style="margin-bottom:0; flex:1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Variant Image (optional)</label>
                <input type="file" class="v-image-upload" onchange="window.previewVariantImage(this, 'v-prev-${id}')" 
                    style="font-size:0.75rem; width:100%;">
            </div>
        </div>
    `;
    list.appendChild(div);
};

window.toggleStockVisibility = (mode, stockInputId) => {
    const stockInput = document.getElementById(stockInputId);
    if (!stockInput) return;
    const group = stockInput.closest('.input-group');
    
    const wStockId = stockInputId.replace('-stock', '-wstock');
    const wStockInput = document.getElementById(wStockId);
    const wGroup = wStockInput?.closest('.input-group');

    const isEdit = stockInputId.includes('edit');
    const payBoxId = isEdit ? 'edit-p-pay-methods-box' : 'p-pay-methods-box';
    const payBox = document.getElementById(payBoxId);

    // Payment checkboxes
    const prefix = isEdit ? 'edit-' : '';
    const codBox = document.getElementById(`${prefix}p-pay-cod`);
    const bankBox = document.getElementById(`${prefix}p-pay-bank`);
    const shopBox = document.getElementById(`${prefix}p-pay-shop`);

    if (mode === 'Service' || mode === 'Technical') {
        if (group) group.style.display = 'none';
        if (wGroup) wGroup.style.display = 'none';
        if (payBox) payBox.style.display = 'none';
        stockInput.value = 999999;
        if (wStockInput) wStockInput.value = 999999;
        
        // Rules for Service/Repair (Payment options disabled/hidden)
        // We set them to true as a default but they won't be relevant for POS filtering usually
        if (codBox) codBox.checked = true;
        if (bankBox) bankBox.checked = true;
        if (shopBox) shopBox.checked = true;
    } else {
        if (group) group.style.display = 'block';
        if (wGroup) wGroup.style.display = 'block';
        if (payBox) payBox.style.display = 'block';
        if (stockInput.value === '999999') stockInput.value = 0;
        if (wStockInput && wStockInput.value === '999999') wStockInput.value = 0;

        if (mode === 'Shop') {
            if (codBox) codBox.checked = true;
            if (bankBox) bankBox.checked = true;
            if (shopBox) shopBox.checked = true;
        } else if (mode === 'Warehouse') {
            if (codBox) codBox.checked = true;
            if (bankBox) bankBox.checked = true;
            if (shopBox) shopBox.checked = false; // Warehouse/Web: No shop pickup
        }
    }
};



window.previewVariantImage = (input, previewId) => {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
};

window.addProduct = async function(e) {
    if (e && e.preventDefault) e.preventDefault();
    
    // Safety: ensure it is a form submission or we have the form reference
    const form = e?.target || document.getElementById('product-form');
    if (!form) {
        console.error("Product form not found during submission");
        return;
    }

    if (window._isPublishing) {
        window.showToast("⏳ Please wait, already publishing...", "warning");
        return;
    }
    const submitBtn = form.querySelector('button[type="submit"]');
    
    try {
        window._isPublishing = true;
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerText = "⌛ Publishing...";
        }
        window.showToast("🚀 Publishing product...", "info");

        const name = document.getElementById('p-name')?.value || 'Unnamed';
        const category = document.getElementById('p-category')?.value || '';
        const mode = document.getElementById('p-mode')?.value || 'Shop';
        const hasVariants = document.getElementById('p-has-variants')?.checked || false;

        let productData = {
            name,
            sku: document.getElementById('p-sku')?.value?.trim() || '',
            category,
            mode,
            hasVariants,
            expiryDate: document.getElementById('p-expiry')?.value || '',
            storeId: window.getStoreId(),
            timestamp: serverTimestamp(),
            payMethods: (mode === 'Service' || mode === 'Technical') ? 
                { cod: true, bank: true, shop: true } : 
                {
                    cod: document.getElementById('p-pay-cod')?.checked ?? true,
                    bank: document.getElementById('p-pay-bank')?.checked ?? true,
                    shop: document.getElementById('p-pay-shop')?.checked ?? true
                }
        };

        if (hasVariants) {
            const variants = [];
            const rows = document.querySelectorAll('#variant-list .variant-row');
            for (const row of rows) {
                const vImageFile = row.querySelector('input[type="file"]')?.files[0];
                let vImageUrl = "";
                if (vImageFile) vImageUrl = await window.toBase64(vImageFile);
                
                variants.push({
                    name: row.querySelector('.v-name').value,
                    cost: Math.round((parseFloat(row.querySelector('.v-cost').value) || 0) * 1000) / 1000,
                    price: Math.round((parseFloat(row.querySelector('.v-price').value) || 0) * 1000) / 1000,
                    wholesalePrice: Math.round((parseFloat(row.querySelector('.v-wholesale')?.value) || 0) * 1000) / 1000,
                    loyaltyPrice: Math.round((parseFloat(row.querySelector('.v-loyalty')?.value) || 0) * 1000) / 1000,
                    discount: Math.round((parseFloat(row.querySelector('.v-discount').value) || 0) * 1000) / 1000,
                    stock: parseInt(row.querySelector('.v-stock').value) || 0,
                    image: vImageUrl
                });
            }
            productData.variants = variants;
            if (variants.length > 0) {
                const first = variants[0];
                productData.cost = first.cost;
                productData.price = first.price;
                productData.wholesalePrice = first.wholesalePrice;
                productData.loyaltyPrice = first.loyaltyPrice;
                productData.discount = first.discount;
                productData.stock = variants.reduce((sum, v) => sum + v.stock, 0);
                productData.image = first.image;
            }
        } else {
            productData.cost = Math.round((parseFloat(document.getElementById('p-cost')?.value) || 0) * 1000) / 1000;
            productData.price = Math.round((parseFloat(document.getElementById('p-price')?.value) || 0) * 1000) / 1000;
            productData.wholesalePrice = Math.round((parseFloat(document.getElementById('p-wholesale-price')?.value) || 0) * 1000) / 1000;
            productData.loyaltyPrice = Math.round((parseFloat(document.getElementById('p-loyalty-price')?.value) || 0) * 1000) / 1000;
            productData.discount = Math.round((parseFloat(document.getElementById('p-discount')?.value) || 0) * 1000) / 1000;
            
            if (mode === 'Service' || mode === 'Technical') {
                productData.stock = 999999;
                productData.wStock = 999999;
            } else {
                productData.stock = parseInt(document.getElementById('p-stock')?.value) || 0;
                productData.wStock = parseInt(document.getElementById('p-wstock')?.value) || 0;
            }
            
            const imageFile = document.getElementById('p-image')?.files[0];
            if (imageFile) productData.image = await window.toBase64(imageFile);
        }

        const pRef = doc(productsCol);
        const pId = pRef.id;
        productData.docId = pId;

        setDoc(pRef, productData).catch(err => {
            console.error("Firestore add product error:", err);
            window.showToast("❌ Sync failed: " + err.message, "error");
        });

        window.showToast("✅ Product published!", "success");
        document.getElementById('product-form-modal').style.display = 'none';
        form.reset();
        document.getElementById('p-image-preview').innerHTML = "";
        document.getElementById('variant-list').innerHTML = "";
        
        if (window._isFromSINV) {
            window._isFromSINV = false;
            window.allProducts = window.allProducts || [];
            window.allProducts.push(productData);
            
            const searchInput = document.getElementById('sinv-search');
            if (searchInput) {
                searchInput.value = productData.sku || productData.name;
                window.handleSINVSearch(searchInput.value);
            }
            setTimeout(() => {
                window.addToSupplierInvoice(pId);
            }, 500);
        }
    } catch (err) {
        console.error("Add Product Error:", err);
        window.showToast("❌ Error publishing product", "error");
    } finally {
        window._isPublishing = false;
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = "Create Product & Publish";
        }
    }
};

window.toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});

// --- Edit Product Logic & Modal Management ---
window.openEditModalByName = (encodedName) => {
    const name = decodeURIComponent(encodedName);
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim() === name);
    
    if (variants.length === 0) {
        window.showToast("Product variants not found!", "error");
        return;
    }

    // If only 1 variant exists, open the individual edit modal directly to expose all fields
    if (variants.length === 1) {
        window.openEditModal(variants[0].docId);
        return;
    }

    window.currentEditingGroupName = name;
    window.currentEditingId = null; // Mark as group edit
    
    const firstProduct = variants[0];
    const modal = document.getElementById('edit-modal');
    const variantSection = document.getElementById('edit-variants-section');
    const variantList = document.getElementById('edit-variants-list-container');
    const variantCount = document.getElementById('variant-count-badge');
    
    // 1. Reset View and pre-fill common fields from first variant
    document.getElementById('edit-p-name').value = name;
    
    const catSelect = document.getElementById('edit-p-category');
    if (catSelect) {
        window.populateCategoryDropdowns(window.allCategories || []);
        catSelect.value = firstProduct.category || '';
    }

    if (document.getElementById('edit-p-mode')) {
        document.getElementById('edit-p-mode').value = firstProduct.mode || 'Shop';
        window.toggleStockVisibility(firstProduct.mode || 'Shop', 'edit-p-stock');
    }

    const supSelect = document.getElementById('edit-p-supplier');
    if (supSelect) {
        const sourceList = Array.isArray(window.allSuppliers) ? window.allSuppliers : [];
        const filtered = typeof window.filterByStore === 'function' ? window.filterByStore(sourceList) : sourceList;
        const matched = filtered.find(s => 
            (firstProduct.supplierId && (s.docId === firstProduct.supplierId || s.id === firstProduct.supplierId || s.name === firstProduct.supplierId)) ||
            (firstProduct.supplierName && (s.name === firstProduct.supplierName || s.docId === firstProduct.supplierName))
        );
        const selectedId = matched ? (matched.docId || matched.id) : (firstProduct.supplierId || '');
        const optionsHtml = filtered.map(s => {
            const sid = s.docId || s.id || '';
            const isSel = (sid === selectedId || s.name === selectedId || (firstProduct.supplierName && s.name === firstProduct.supplierName)) ? 'selected' : '';
            return `<option value="${sid}" ${isSel}>${s.name}</option>`;
        }).join('');
        supSelect.innerHTML = '<option value="">None / General</option>' + optionsHtml;
        if (selectedId) supSelect.value = selectedId;
    }

    if (firstProduct.payMethods) {
        document.getElementById('edit-p-pay-cod').checked = firstProduct.payMethods.cod !== false;
        document.getElementById('edit-p-pay-bank').checked = firstProduct.payMethods.bank !== false;
        document.getElementById('edit-p-pay-shop').checked = firstProduct.payMethods.shop !== false;
    } else {
        document.getElementById('edit-p-pay-cod').checked = true;
        document.getElementById('edit-p-pay-bank').checked = true;
        document.getElementById('edit-p-pay-shop').checked = true;
    }

    // Pre-fill variant-specific fields for group edit view
    document.getElementById('edit-p-sku').value = firstProduct.sku || '';
    document.getElementById('edit-p-sku').disabled = true;
    const scannerBtn = document.getElementById('edit-p-sku-scan');
    if (scannerBtn) scannerBtn.disabled = true;

    document.getElementById('edit-p-size').value = firstProduct.size || '';
    document.getElementById('edit-p-color').value = firstProduct.color || '';
    document.getElementById('edit-p-cost').value = firstProduct.cost || 0;
    document.getElementById('edit-p-price').value = firstProduct.price || 0;
    document.getElementById('edit-p-discount').value = firstProduct.discount || 0;
    // Auto-calculate wholesale/loyalty from retail if not stored on the product
    const _grpRetail = parseFloat(firstProduct.price) || 0;
    const _grpWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _grpLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('edit-p-wholesale-price').value = (parseFloat(firstProduct.wholesalePrice) > 0)
        ? firstProduct.wholesalePrice
        : (window.calculateDynamicWholesalePrice ? window.calculateDynamicWholesalePrice(firstProduct.cost, firstProduct.price, firstProduct.category).toFixed(2) : (_grpRetail * (1 - _grpWsPct / 100)).toFixed(2));
    document.getElementById('edit-p-loyalty-price').value = (parseFloat(firstProduct.loyaltyPrice) > 0)
        ? firstProduct.loyaltyPrice
        : (_grpRetail * (1 - _grpLoyPct / 100)).toFixed(2);
    document.getElementById('edit-p-stock').value = firstProduct.stock || 0;
    document.getElementById('edit-p-wstock').value = firstProduct.wStock || 0;
    document.getElementById('edit-p-expiry').value = firstProduct.expiryDate || '';

    const mainImgPrev = document.getElementById('edit-p-image-preview');
    if (mainImgPrev) {
        mainImgPrev.innerHTML = firstProduct.image ? `<img src="${firstProduct.image}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">` : '';
    }

    // 2. Manage Visibility
    variantSection.style.display = 'block';
    variantCount.innerText = `${variants.length} VARIANTS`;
    
    // Show all fields
    const formGroups = document.querySelectorAll('#edit-product-form .input-group, #edit-p-pay-methods-box');
    formGroups.forEach(group => {
        group.style.display = 'block';
        if (group.parentElement.classList.contains('form-grid-3')) {
            group.parentElement.style.display = 'grid';
        }
    });
    
    // Render Beautiful Variant Cards
    const _colorMap = {
        'red':'#ef4444','blue':'#3b82f6','black':'#334155','green':'#22c55e',
        'yellow':'#eab308','orange':'#f97316','purple':'#a855f7','pink':'#ec4899',
        'white':'#e2e8f0','grey':'#64748b','gray':'#64748b','brown':'#92400e',
        'navy':'#1e3a5f','cyan':'#06b6d4','gold':'#d97706','silver':'#94a3b8',
        'maroon':'#7f1d1d','violet':'#7c3aed','teal':'#0d9488','lime':'#84cc16'
    };
    const _getColorDots = (colorStr) => {
        if (!colorStr) return '';
        return colorStr.split(/[,\/\s]+/).filter(Boolean).map(c => {
            const hex = _colorMap[c.trim().toLowerCase()] || '#475569';
            return `<span title="${c.trim()}" style="display:inline-block;width:14px;height:14px;border-radius:50%;background:${hex};border:2px solid rgba(255,255,255,0.3);flex-shrink:0;"></span>`;
        }).join('');
    };
    variantList.innerHTML = `
        <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(175px,1fr)); gap:12px; padding:4px 2px;">
            ${variants.map(v => {
                const stk = v.stock || 0;
                const stkColor = stk === 0 ? '#ef4444' : stk < 5 ? '#f97316' : '#10b981';
                const stkLabel = stk === 0 ? '❌ Out of Stock' : stk < 5 ? '⚠️ Low Stock' : '✅ In Stock';
                const hasImg = v.image && !v.image.includes('logo.png');
                return `
                <div style="background:linear-gradient(160deg,rgba(30,41,59,0.98),rgba(15,23,42,0.95));border:1px solid rgba(99,179,237,0.18);border-radius:18px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 2px 12px rgba(0,0,0,0.3);transition:transform 0.15s,box-shadow 0.15s;"
                     onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 10px 30px rgba(56,189,248,0.18)'"
                     onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 2px 12px rgba(0,0,0,0.3)'">

                    <!-- Product Image -->
                    <div style="height:115px;background:rgba(0,0,0,0.35);position:relative;overflow:hidden;cursor:pointer;" onclick="window.viewFullImage('${v.image}')">
                        <img src="${v.image || '/logo.png'}" onerror="this.src='/logo.png'"
                             style="width:100%;height:100%;object-fit:${hasImg?'cover':'contain'};padding:${hasImg?'0':'16px'};opacity:${hasImg?'1':'0.35'};">
                        <!-- Stock overlay badge -->
                        <div style="position:absolute;top:8px;left:8px;background:${stkColor}22;border:1px solid ${stkColor}55;color:${stkColor};font-size:0.58rem;font-weight:800;padding:3px 8px;border-radius:20px;backdrop-filter:blur(6px);letter-spacing:0.03em;">
                            ${stkLabel}
                        </div>
                        <!-- Image zoom hint -->
                        <div style="position:absolute;bottom:6px;right:8px;color:rgba(255,255,255,0.25);font-size:0.6rem;">🔍</div>
                    </div>

                    <!-- Card Body -->
                    <div style="padding:11px 13px;flex:1;display:flex;flex-direction:column;gap:7px;">

                        <!-- Color swatches row -->
                        ${v.color ? `
                        <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
                            <div style="display:flex;gap:3px;align-items:center;">${_getColorDots(v.color)}</div>
                            <span style="font-size:0.7rem;color:#94a3b8;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:105px;" title="${v.color}">${v.color}</span>
                        </div>` : ''}

                        <!-- Size badge -->
                        ${v.size ? `
                        <div>
                            <span style="background:rgba(99,179,237,0.1);color:#7dd3fc;font-size:0.68rem;font-weight:700;padding:3px 9px;border-radius:7px;border:1px solid rgba(99,179,237,0.2);">📐 ${v.size}</span>
                        </div>` : ''}

                        <!-- MRP Price block -->
                        <div style="background:rgba(56,189,248,0.06);border:1px solid rgba(56,189,248,0.12);border-radius:10px;padding:7px 10px;margin-top:2px;">
                            <div style="font-size:0.58rem;color:#64748b;text-transform:uppercase;letter-spacing:0.08em;font-weight:700;margin-bottom:2px;">MRP</div>
                            <div style="font-size:1.1rem;font-weight:900;color:#f0f9ff;letter-spacing:-0.5px;line-height:1;">
                                <span style="font-size:0.65rem;color:#38bdf8;font-weight:700;vertical-align:super;">LKR</span>
                                <span style="color:#38bdf8;">${(v.price || 0).toLocaleString()}</span>
                            </div>
                            ${v.cost ? `<div style="font-size:0.6rem;color:#475569;margin-top:2px;">Cost: LKR ${(v.cost||0).toLocaleString()}</div>` : ''}
                        </div>

                        <!-- Stock count row -->
                        <div style="display:flex;align-items:center;justify-content:space-between;">
                            <div style="font-size:0.68rem;color:#64748b;">
                                Qty: <span style="font-weight:900;color:${stkColor};font-size:0.8rem;">${stk}</span>
                            </div>
                            <div style="font-size:0.57rem;font-family:monospace;color:#334155;background:rgba(255,255,255,0.04);padding:2px 5px;border-radius:4px;">${v.variantId || ''}</div>
                        </div>
                    </div>

                    <!-- Action buttons -->
                    <div style="display:flex;border-top:1px solid rgba(255,255,255,0.05);background:rgba(0,0,0,0.25);">
                        <button type="button" onclick="window.openEditModal('${v.docId || v.id}', true)"
                            style="flex:1;padding:9px 5px;font-size:0.75rem;font-weight:700;color:#7dd3fc;background:transparent;border:none;cursor:pointer;border-right:1px solid rgba(255,255,255,0.05);transition:background 0.1s;"
                            onmouseover="this.style.background='rgba(56,189,248,0.12)'" onmouseout="this.style.background='transparent'">
                            ✏️ Edit
                        </button>
                        <button type="button" onclick="window.confirmDeleteVariant('${v.docId || v.id}', '${v.variantId}')"
                            style="flex:1;padding:9px 5px;font-size:0.75rem;font-weight:700;color:#f87171;background:transparent;border:none;cursor:pointer;transition:background 0.1s;"
                            onmouseover="this.style.background='rgba(239,68,68,0.12)'" onmouseout="this.style.background='transparent'">
                            🗑️ Delete
                        </button>
                    </div>
                </div>`;
            }).join('')}
        </div>
    `;

    modal.style.display = 'flex';
};

window.openEditModal = (id, isFromGroup = false) => {
    const product = (window.allProducts || []).find(p => p.docId === id);
    if (!product) {
        window.showToast("Product not found!", "error");
        return;
    }

    window.currentEditingId = id;
    
    document.getElementById('edit-variant-list').innerHTML = '';
    const epPreview = document.getElementById('edit-p-image-preview');
    if(epPreview) epPreview.innerHTML = '';

    // 1. Restore all fields visibility (Individual Mode)
    const variantSection = document.getElementById('edit-variants-section');
    if (variantSection) variantSection.style.display = 'none';
    
    const formGroups = document.querySelectorAll('#edit-product-form .input-group, #edit-p-pay-methods-box');
    formGroups.forEach(el => el.style.display = 'block');
    
    const grids = document.querySelectorAll('#edit-product-form .form-grid-3');
    grids.forEach(el => el.style.display = 'grid');

    // Enable SKU editing in individual edit mode
    document.getElementById('edit-p-sku').disabled = false;
    const scannerBtn = document.getElementById('edit-p-sku-scan');
    if (scannerBtn) scannerBtn.disabled = false;

    // 2. Populate Fields
    document.getElementById('edit-p-name').value = product.name || 'Unnamed';
    document.getElementById('edit-p-sku').value = product.sku || '';
    
    // 2. Category Dropdown
    const catSelect = document.getElementById('edit-p-category');
    if (catSelect) {
        window.populateCategoryDropdowns(window.allCategories || []);
        catSelect.value = product.category || '';
    }

    // 3. Mode & Base Fields
    if (document.getElementById('edit-p-mode')) {
        document.getElementById('edit-p-mode').value = product.mode || 'Shop';
        window.toggleStockVisibility(product.mode || 'Shop', 'edit-p-stock');
    }

    // [MOD] Populate and Set Primary Supplier
    const supSelect = document.getElementById('edit-p-supplier');
    if (supSelect) {
        const sourceList = Array.isArray(window.allSuppliers) ? window.allSuppliers : [];
        const filtered = typeof window.filterByStore === 'function' ? window.filterByStore(sourceList) : sourceList;
        const matched = filtered.find(s => 
            (product.supplierId && (s.docId === product.supplierId || s.id === product.supplierId || s.name === product.supplierId)) ||
            (product.supplierName && (s.name === product.supplierName || s.docId === product.supplierName))
        );
        const selectedId = matched ? (matched.docId || matched.id) : (product.supplierId || '');
        const optionsHtml = filtered.map(s => {
            const sid = s.docId || s.id || '';
            const isSel = (sid === selectedId || s.name === selectedId || (product.supplierName && s.name === product.supplierName)) ? 'selected' : '';
            return `<option value="${sid}" ${isSel}>${s.name}</option>`;
        }).join('');
        
        // If product has a supplierName not in filtered list, prepend it so it's not lost
        let customSupOption = '';
        if (product.supplierName && !filtered.some(s => s.name === product.supplierName || s.docId === product.supplierId)) {
            customSupOption = `<option value="${selectedId || product.supplierName}" selected>${product.supplierName}</option>`;
        }
        
        supSelect.innerHTML = '<option value="">None / General</option>' + customSupOption + optionsHtml;
        if (selectedId) supSelect.value = selectedId;
    }

    // Render existing variants so they can be edited or removed (populated after supplier is set)
    if (product.variants && product.variants.length > 0) {
        product.variants.forEach(v => {
            window.addEditVariantField('edit-variant-list', v);
        });
    }

    document.getElementById('edit-p-size').value = product.size || '';
    document.getElementById('edit-p-color').value = product.color || '';

    document.getElementById('edit-p-cost').value = product.cost || 0;
    document.getElementById('edit-p-price').value = product.price || 0;
    document.getElementById('edit-p-discount').value = product.discount || 0;
    // Auto-calculate wholesale/loyalty from retail if not stored on the product
    const _editRetail = parseFloat(product.price) || 0;
    const _editWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _editLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('edit-p-wholesale-price').value = (parseFloat(product.wholesalePrice) > 0)
        ? product.wholesalePrice
        : (window.calculateDynamicWholesalePrice ? window.calculateDynamicWholesalePrice(product.cost, product.price, product.category).toFixed(2) : (_editRetail * (1 - _editWsPct / 100)).toFixed(2));
    document.getElementById('edit-p-loyalty-price').value = (parseFloat(product.loyaltyPrice) > 0)
        ? product.loyaltyPrice
        : (_editRetail * (1 - _editLoyPct / 100)).toFixed(2);
    document.getElementById('edit-p-stock').value = product.stock || 0;
    document.getElementById('edit-p-wstock').value = product.wStock || 0;
    document.getElementById('edit-p-expiry').value = product.expiryDate || '';

    // 4. Payment Methods
    if (product.payMethods) {
        document.getElementById('edit-p-pay-cod').checked = product.payMethods.cod !== false;
        document.getElementById('edit-p-pay-bank').checked = product.payMethods.bank !== false;
        document.getElementById('edit-p-pay-shop').checked = product.payMethods.shop !== false;
    } else {
        document.getElementById('edit-p-pay-cod').checked = true;
        document.getElementById('edit-p-pay-bank').checked = true;
        document.getElementById('edit-p-pay-shop').checked = true;
    }

    // 5. Main Image Preview
    const mainImgPrev = document.getElementById('edit-p-image-preview');
    if (mainImgPrev) {
        mainImgPrev.innerHTML = product.image ? `<img src="${product.image}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">` : '';
    }

    const modal = document.getElementById('edit-modal');
    modal.style.display = 'flex';

    // If coming from group, add a back button or change footer
    const footer = modal.querySelector('.modal-footer');
    if (isFromGroup) {
        const backBtnId = 'edit-back-to-group-btn';
        if (!document.getElementById(backBtnId)) {
            const backBtn = document.createElement('button');
            backBtn.id = backBtnId;
            backBtn.type = 'button';
            backBtn.className = 'action-btn';
            backBtn.style = 'background: #334155; color: white; margin-right: auto;';
            backBtn.innerHTML = '← Back to Group';
            backBtn.onclick = () => window.openEditModalByName(encodeURIComponent(product.name));
            footer.prepend(backBtn);
        } else {
            document.getElementById(backBtnId).style.display = 'block';
            document.getElementById(backBtnId).onclick = () => window.openEditModalByName(encodeURIComponent(product.name));
        }
    } else {
        const backBtn = document.getElementById('edit-back-to-group-btn');
        if (backBtn) backBtn.style.display = 'none';
    }
};

window.closeEditModal = () => {
    document.getElementById('edit-modal').style.display = 'none';
};

window.toggleEditVariantSection = (checked) => {
    document.getElementById('edit-variants-container').style.display = checked ? 'block' : 'none';
    document.getElementById('edit-p-main-image-group').style.display = checked ? 'none' : 'block';
    document.getElementById('edit-p-base-fields').style.display = checked ? 'none' : 'block';
};

window.openBatchEditModal = (prodId, variantId) => {
    const product = (window.allProducts || []).find(p => p.docId === prodId);
    if (!product || !product.variants) return;

    const variant = product.variants.find(v => v.variantId === variantId);
    if (!variant) return;

    document.getElementById('be-product-id').value = prodId;
    document.getElementById('be-variant-id').value = variantId;
    document.getElementById('be-product-name').innerText = product.name;
    document.getElementById('be-batch-info').innerText = `Supplier: ${variant.supplierName || 'N/A'} | Variant: ${variant.variantLabel || 'General'}`;
    
    document.getElementById('be-buying').value = variant.buyingPrice || 0;
    const _beRetail = parseFloat(variant.sellingPrice) || 0;
    document.getElementById('be-retail').value = _beRetail;
    // Auto-calculate wholesale/loyalty from retail if not stored on the variant
    const _beWsPct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const _beLoyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    document.getElementById('be-wholesale').value = (parseFloat(variant.wholesalePrice) > 0)
        ? variant.wholesalePrice
        : (window.calculateDynamicWholesalePrice ? window.calculateDynamicWholesalePrice(variant.buyingPrice, variant.sellingPrice).toFixed(2) : (_beRetail * (1 - _beWsPct / 100)).toFixed(2));
    document.getElementById('be-loyalty').value = (parseFloat(variant.loyaltyPrice) > 0)
        ? variant.loyaltyPrice
        : (_beRetail * (1 - _beLoyPct / 100)).toFixed(2);
    document.getElementById('be-stock').value = variant.stock || 0;
    document.getElementById('be-size').value = variant.size || '';
    document.getElementById('be-color').value = variant.color || '';
    
    document.getElementById('be-image').value = '';
    const imgPreview = document.getElementById('be-image-preview');
    if (variant.image) {
        imgPreview.innerHTML = `<img src="${variant.image}" style="max-width: 150px; border-radius: 8px;">`;
    } else {
        imgPreview.innerHTML = '';
    }

    document.getElementById('batch-edit-modal').style.display = 'flex';
};

window.closeBatchEditModal = () => {
    document.getElementById('batch-edit-modal').style.display = 'none';
};

window.saveBatchEdit = async () => {
    const prodId = document.getElementById('be-product-id').value;
    const variantId = document.getElementById('be-variant-id').value;

    const buying = Number(document.getElementById('be-buying').value);
    const retail = Number(document.getElementById('be-retail').value);
    const wholesale = Number(document.getElementById('be-wholesale').value);
    const loyalty = Number(document.getElementById('be-loyalty').value);
    const stock = Number(document.getElementById('be-stock').value);
    const size = document.getElementById('be-size').value.trim();
    const color = document.getElementById('be-color').value.trim();

    const saveBtn = document.querySelector('#batch-edit-modal .login-submit-btn');
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerText = "💾 SAVING...";
    }

    try {
        const product = (window.allProducts || []).find(p => p.docId === prodId);
        if (!product) throw new Error("Product not found");

        const variants = [...(product.variants || [])];
        const vIdx = variants.findIndex(v => v.variantId === variantId);
        if (vIdx === -1) throw new Error("Batch not found");

        let newImage = variants[vIdx].image || '';
        const imageFile = document.getElementById('be-image').files[0];
        if (imageFile) {
            newImage = await window.resizeImageToBase64(imageFile, 1000); // 1000px HD for variants
        }

        variants[vIdx] = {
            ...variants[vIdx],
            buyingPrice: Math.round(buying  * 100) / 100,
            sellingPrice: Math.round(retail  * 100) / 100,
            wholesalePrice: Math.round(wholesale  * 100) / 100,
            loyaltyPrice: Math.round(loyalty  * 100) / 100,
            stock: stock,
            size: size,
            color: color,
            image: newImage,
            lastUpdated: Date.now()
        };

        const totalStock = variants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
        
        // Optimistic UI update: close modal and show toast instantly
        window.closeBatchEditModal();
        window.showToast("Batch updated successfully!", "success");

        // Update Firestore in the background
        const pRef = doc(db, "products", prodId);
        updateDoc(pRef, {
            variants: variants,
            stock: totalStock,
            totalStock: totalStock,
            lastUpdated: serverTimestamp()
        }).catch(err => {
            console.error("Firestore batch update error:", err);
            window.showToast("Cloud update delay: " + err.message, "warning");
        });

    } catch (err) {
        console.error(err);
        window.showToast("Error updating batch: " + err.message, "error");
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerText = "💾 SAVE BATCH";
        }
    }
};

window.switchProdModalTab = (btn, tabId, formId) => {
    // tabId is either 'p-general', 'p-stocks', 'edit-p-general', or 'edit-p-stocks'
    const modal = btn.closest('.admin-modal');
    modal.querySelectorAll('.prod-tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    modal.querySelectorAll('.prod-tab-view').forEach(v => v.style.display = 'none');
    document.getElementById(tabId + '-tab').style.display = 'block';
};

window.addEditVariantField = (listId = 'edit-variant-list', v = null) => {
    const list = document.getElementById(listId);
    if (!list) return;

    // Detect mode to determine if supplier is needed
    const modeSelect = listId === 'variant-list' ? document.getElementById('p-mode') : document.getElementById('edit-p-mode');
    const isService = modeSelect ? (modeSelect.value === 'Service' || modeSelect.value === 'Technical') : false;

    // Get base values to pre-fill if possible
    const baseCost = v ? (v.buyingPrice || v.cost || 0) : (parseFloat(document.getElementById(listId === 'variant-list' ? 'p-cost' : 'edit-p-cost')?.value) || 0);
    const basePrice = v ? (v.sellingPrice || v.price || 0) : (parseFloat(document.getElementById(listId === 'variant-list' ? 'p-price' : 'edit-p-price')?.value) || 0);
    const baseWS = v ? (v.wholesalePrice || 0) : 0;
    const baseLoyalty = v ? (v.loyaltyPrice || 0) : 0;
    const baseStock = v ? (v.stock || 0) : 0;
    const baseSize = v ? (v.size || '') : '';
    const baseColor = v ? (v.color || '') : '';
    const baseVariantId = v ? (v.variantId || `VAR-${Math.floor(1000 + Math.random()*9000)}`) : `VAR-${Math.floor(1000 + Math.random()*9000)}`;

    const id = Date.now();
    const div = document.createElement('div');
    div.className = 'variant-row';
    
    div.style = `
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(99,179,237,0.15);
        border-radius: 16px;
        padding: 16px;
        margin-bottom: 14px;
        position: relative;
    `;
    
    // Filter suppliers by current store
    const sourceSuppliers = Array.isArray(window.allSuppliers) ? window.allSuppliers : [];
    const availableSuppliers = typeof window.filterByStore === 'function' ? window.filterByStore(sourceSuppliers) : sourceSuppliers;

    // Detect target/pre-selected supplier from variant or parent form
    const parentSupEl = document.getElementById(listId === 'variant-list' ? 'p-supplier' : 'edit-p-supplier');
    const parentSupName = (parentSupEl && parentSupEl.selectedIndex >= 0 && parentSupEl.value !== '') ? parentSupEl.options[parentSupEl.selectedIndex].text : '';
    const parentSupId = parentSupEl ? parentSupEl.value : '';

    const targetSupplierName = (v && (v.supplierName || v.supplierId)) ? (v.supplierName || v.supplierId) : parentSupName;

    let matchedInList = false;
    let supplierOptions = availableSuppliers.map(s => {
        const isSel = (targetSupplierName && (s.name === targetSupplierName || s.docId === targetSupplierName || s.id === targetSupplierName)) ||
                      (v && (v.supplierName === s.name || v.supplierName === s.docId || v.supplierId === s.id || v.supplierId === s.docId || v.supplierId === s.name));
        if (isSel) matchedInList = true;
        return `<option value="${s.name}" ${isSel ? 'selected' : ''}>${s.name}</option>`;
    }).join('');

    // If variant or parent has a supplier that isn't in availableSuppliers list, preserve it as an option so it's not lost
    if (targetSupplierName && targetSupplierName !== 'General' && !matchedInList) {
        supplierOptions = `<option value="${targetSupplierName}" selected>${targetSupplierName}</option>` + supplierOptions;
    }

    // Supplier dropdown html - hidden from UI but field kept for data compatibility
    const supplierColHtml = isService ? '' : `
        <div class="input-group" style="margin-bottom:0; display:none;">
            <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Supplier</label>
            <select class="v-supplier" style="font-size:0.82rem; background: rgba(0,0,0,0.25); height: 36px; border-radius:8px;">
                <option value="General" ${(!targetSupplierName || targetSupplierName === 'General') ? 'selected' : ''}>General</option>
                ${supplierOptions}
            </select>
        </div>
    `;

    const hasSizeInit = !!baseSize;
    const hasColorInit = !!baseColor || (!hasSizeInit); // Default to color if none

    div.innerHTML = `
        <!-- Header row: Variant ID + Type Toggles + Delete button -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; flex-wrap:wrap; gap:8px;">
            <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:0.65rem; opacity:0.5; text-transform:uppercase; letter-spacing:0.08em;">Variant ID</span>
                <input type="text" class="v-id" value="${baseVariantId}" 
                    style="font-weight:700; color:#38bdf8; font-size:0.85rem; background:rgba(56,189,248,0.07); 
                           border:1px solid rgba(56,189,248,0.2); border-radius:8px; padding:4px 10px; width:130px; height:32px;">
            </div>

            <!-- Toggles for Size & Color -->
            <div style="display:flex; align-items:center; gap:14px; background:rgba(0,0,0,0.25); padding:4px 12px; border-radius:20px; border:1px solid rgba(255,255,255,0.08);">
                <label style="font-size:0.75rem; font-weight:700; color:#7dd3fc; display:flex; align-items:center; gap:5px; cursor:pointer; margin:0;">
                    <input type="checkbox" class="v-has-color-toggle" ${hasColorInit ? 'checked' : ''} 
                        onchange="const b = this.closest('.variant-row').querySelector('.v-color-box'); if(b) b.style.display = this.checked ? 'block' : 'none';">
                    🎨 Color
                </label>
                <label style="font-size:0.75rem; font-weight:700; color:#c084fc; display:flex; align-items:center; gap:5px; cursor:pointer; margin:0;">
                    <input type="checkbox" class="v-has-size-toggle" ${hasSizeInit ? 'checked' : ''} 
                        onchange="const b = this.closest('.variant-row').querySelector('.v-size-box'); if(b) b.style.display = this.checked ? 'block' : 'none';">
                    📐 Size
                </label>
            </div>

            <button type="button" onclick="this.closest('.variant-row').remove()" 
                style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.3); color:#f87171;
                       border-radius:8px; width:30px; height:30px; cursor:pointer; font-size:0.85rem;
                       display:flex; align-items:center; justify-content:center; flex-shrink:0;">✕</button>
        </div>

        <!-- Main fields grid -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            ${supplierColHtml}

            <!-- Color Box (toggled) -->
            <div class="input-group v-color-box" style="margin-bottom:0; display:${hasColorInit ? 'block' : 'none'};">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em; color:#7dd3fc;">🎨 Color / Shade</label>
                <select class="v-color"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.25); height:36px; border-radius:8px; width:100%; color:#e2e8f0; border:1px solid rgba(99,179,237,0.25); padding:0 8px;"
                    onchange="(function(sel){ const customBox = sel.parentElement.querySelector('.v-color-custom'); if(customBox){ if(sel.value==='__other__'){ customBox.style.display='block'; } else { customBox.style.display='none'; customBox.value=''; } } })(this)">
                    <option value="">-- Select Color --</option>
                    ${['Red','Blue','Black','Green','Yellow','White','Orange','Purple','Pink','Brown','Grey','Navy','Maroon','Gold','Silver','Beige','Cyan','Magenta','Cream','Transparent'].map(c=>`<option value="${c}" ${baseColor===c?'selected':''}>${c}</option>`).join('')}
                    <option value="__other__" ${(baseColor && !['Red','Blue','Black','Green','Yellow','White','Orange','Purple','Pink','Brown','Grey','Navy','Maroon','Gold','Silver','Beige','Cyan','Magenta','Cream','Transparent'].includes(baseColor))?'selected':''}>Other (Custom)...</option>
                </select>
                <input type="text" class="v-color-custom" placeholder="Type custom color..."
                    value="${(baseColor && !['Red','Blue','Black','Green','Yellow','White','Orange','Purple','Pink','Brown','Grey','Navy','Maroon','Gold','Silver','Beige','Cyan','Magenta','Cream','Transparent'].includes(baseColor)) ? baseColor : ''}"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px; margin-top:4px; width:100%; display:${(baseColor && !['Red','Blue','Black','Green','Yellow','White','Orange','Purple','Pink','Brown','Grey','Navy','Maroon','Gold','Silver','Beige','Cyan','Magenta','Cream','Transparent'].includes(baseColor)) ? 'block' : 'none'};">
            </div>

            <!-- Size Box (toggled) -->
            <div class="input-group v-size-box" style="margin-bottom:0; display:${hasSizeInit ? 'block' : 'none'};">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em; color:#c084fc;">📐 Size / Measurement</label>
                <select class="v-size"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.25); height:36px; border-radius:8px; width:100%; color:#e2e8f0; border:1px solid rgba(192,132,252,0.25); padding:0 8px;"
                    onchange="(function(sel){ const customBox = sel.parentElement.querySelector('.v-size-custom'); if(customBox){ if(sel.value==='__other__'){ customBox.style.display='block'; } else { customBox.style.display='none'; customBox.value=''; } } })(this)">
                    <option value="">-- Select Size --</option>
                    ${['XS','S','M','L','XL','XXL','XXXL','250g','500g','1kg','2kg','5kg','250ml','500ml','1L','2L','Standard','Small','Medium','Large','One Size'].map(s=>`<option value="${s}" ${baseSize===s?'selected':''}>${s}</option>`).join('')}
                    <option value="__other__" ${(baseSize && !['XS','S','M','L','XL','XXL','XXXL','250g','500g','1kg','2kg','5kg','250ml','500ml','1L','2L','Standard','Small','Medium','Large','One Size'].includes(baseSize))?'selected':''}>Other (Custom)...</option>
                </select>
                <input type="text" class="v-size-custom" placeholder="Type custom size..."
                    value="${(baseSize && !['XS','S','M','L','XL','XXL','XXXL','250g','500g','1kg','2kg','5kg','250ml','500ml','1L','2L','Standard','Small','Medium','Large','One Size'].includes(baseSize)) ? baseSize : ''}"
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px; margin-top:4px; width:100%; display:${(baseSize && !['XS','S','M','L','XL','XXL','XXXL','250g','500g','1kg','2kg','5kg','250ml','500ml','1L','2L','Standard','Small','Medium','Large','One Size'].includes(baseSize)) ? 'block' : 'none'};">
            </div>

            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Cost (Buying)</label>
                <input type="number" class="v-cost" value="${baseCost}" step="0.01" min="0" placeholder="Cost" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>
            <div class="input-group" style="margin-bottom:0;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">MRP (Selling)</label>
                <input type="number" class="v-price" value="${basePrice}" step="0.01" min="0" placeholder="Selling" oninput="window.autoCalculateVariantPrices(this)" 
                    style="font-size:0.82rem; background:rgba(0,0,0,0.2); height:36px; border-radius:8px;">
            </div>

            <!-- Hidden values preserved for system compatibility -->
            <input type="hidden" class="v-wholesale" value="${baseWS}">
            <input type="hidden" class="v-loyalty" value="${baseLoyalty}">
            <input type="hidden" class="v-stock" value="${baseStock}">
        </div>

        <!-- Variant image row -->
        <div style="display:flex; align-items:center; gap:12px; margin-top:12px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.05);">
            <div id="ev-prev-${id}" style="width:44px; height:44px; border-radius:10px; overflow:hidden; border:1px solid rgba(255,255,255,0.15); background:rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center; font-size:0.55rem; color:#64748b; flex-shrink:0;">No Img</div>
            <div class="input-group" style="margin-bottom:0; flex:1;">
                <label style="font-size:0.65rem; opacity:0.7; text-transform:uppercase; letter-spacing:0.05em;">Variant Image (optional)</label>
                <input type="file" class="v-image-upload" onchange="window.previewVariantImage(this, 'ev-prev-${id}')" 
                    style="font-size:0.75rem; width:100%;">
            </div>
        </div>
    `;
    list.appendChild(div);

    // Restore existing image using a WeakMap cache (avoids large data- attribute limits)
    if (v && v.image) {
        if (!window._variantImageCache) window._variantImageCache = new WeakMap();
        window._variantImageCache.set(div, v.image);
        // Also set dataset as fallback (short-circuit for small images)
        try { div.dataset.existingImage = v.image; } catch(e) {}
        const prevEl = div.querySelector(`#ev-prev-${id}`);
        if (prevEl) {
            prevEl.innerHTML = `<img src="${v.image}" style="width:100%;height:100%;object-fit:cover;">`;
        }
    }
};




// --- Extended Product & Bulk Upload logic extracted to modules/inventory.js ---

window.calcInput = (val) => {
    const disp = document.getElementById('calc-display');
    if (disp) disp.value += val;
};
window.calcClear = () => {
    const disp = document.getElementById('calc-display');
    if (disp) disp.value = '';
};
window.viewFullImage = (src) => {
    if (!src || src === '/logo.png') return;
    const overlay = document.createElement('div');
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); z-index:999999; display:flex; align-items:center; justify-content:center; cursor:zoom-out;";
    overlay.onclick = () => overlay.remove();
    const img = document.createElement('img');
    img.src = src;
    img.style = "max-width:90%; max-height:90%; border-radius:12px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);";
    overlay.appendChild(img);
    document.body.appendChild(overlay);
};

window.calcResult = () => {
    const disp = document.getElementById('calc-display');
    if (!disp) return;
    try {
        const sanitized = disp.value.replace(/[^0-9+\-*/.]/g, '');
        disp.value = eval(sanitized);
    } catch (e) {
        disp.value = "Error";
    }
};

window.showCalculator = () => {
    document.getElementById('calc-display').value = '';
    document.getElementById('calc-modal').style.display = 'flex';
};

// Repair intake functions migrated to modules/repairs.js

// --- HRM System Logic ---
window.generateEmployeeID = (force = false) => {
    const regnoInput = document.getElementById('emp-regno');
    if (!regnoInput || window.editingEmployeeId) return;

    const filtered = window.filterByStore(window.allEmployees || []);
    const nextId = 'EMP-' + String(filtered.length + 1).padStart(3, '0');
    
    const currentVal = regnoInput.value.trim();
    // Only update if it's currently a default/placeholder value OR if we are forcing it (on page load)
    const isBlankOrDefault = !currentVal || currentVal === '' || currentVal === 'EMP-001' || currentVal === 'EMP-000';

    if (force || isBlankOrDefault) {
        if (regnoInput.value !== nextId) {
            regnoInput.value = nextId;
        }
    }

    const pinInput = document.getElementById('emp-pin');
    if (pinInput && !pinInput.value.trim() && !window.editingEmployeeId) {
        window.generateEmployeePIN();
    }
};

// ─── Auto-generate a unique 6-digit numeric PIN for employee ──────────────────
window.generateEmployeePIN = () => {
    const pinInput = document.getElementById('emp-pin');
    if (!pinInput) return;
    // Generate a random 6-digit PIN (100000–999999), avoid all-zeros
    const pin = String(Math.floor(100000 + Math.random() * 900000));
    pinInput.value = pin;
    return pin;
};

window.showHRMSubTab = (tab) => {
    document.querySelectorAll('.hrm-sub-content').forEach(c => c.style.display = 'none');
    // [FIX] Scope to HRM sub-nav only — avoid clearing active state of other sub-tab-btns (e.g. Reload)
    const hrmSubNav = document.querySelector('#section-hrm .hrm-sub-nav');
    if (hrmSubNav) {
        hrmSubNav.querySelectorAll('.sub-tab-btn').forEach(b => b.classList.remove('active'));
    }
    const subEl = document.getElementById(`hrm-sub-${tab}`);
    if (subEl) subEl.style.display = 'block';
    const btnEl = document.getElementById(`hrm-btn-${tab}`);
    if (btnEl) btnEl.classList.add('active');

    if (tab === 'employees' && !window.editingEmployeeId) {
        window.generateEmployeeID?.();
    } else if (tab === 'attendance') {
        if (typeof syncAttendanceUI === 'function') syncAttendanceUI();
    } else if (tab === 'payroll') {
        if (typeof populatePayrollStaffDropdown === 'function') populatePayrollStaffDropdown();
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const defaultMonth = `${year}-${month}`;

        const batchMonthInput = document.getElementById('payroll-batch-month');
        if (batchMonthInput && !batchMonthInput.value) {
            batchMonthInput.value = defaultMonth;
        }

        const monthInput = document.getElementById('pay-month');
        if (monthInput && !monthInput.value) {
            monthInput.value = defaultMonth;
        }

        setTimeout(() => {
            if (typeof window.runSriLankaBatchPreview === 'function') {
                window.runSriLankaBatchPreview(batchMonthInput?.value || defaultMonth);
            }
        }, 150);
    }
};

window.shareStaffPortal = async (phone, name, pin, username, password) => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can share employee credentials.", "error");
    }
    if (!phone) return window.showToast("No phone number found!", "warning");
    
    // Backwards-compatibility if called with (phone, pin, username, password)
    let empName = name;
    let empPin = pin;
    if (typeof empName === 'string' && (empName.startsWith('EMP-') || (/^\d+$/.test(empName) && empName.length <= 6))) {
        empPin = empName;
        empName = 'Employee';
    }

    const directPortalUrl = `https://mecbookshop.com.lk/staff?phone=${encodeURIComponent(phone)}&pin=${encodeURIComponent(displayPin)}`;
    const appDownloadUrl = `https://github.com/malinduec99/mec-pos-releases/releases/download/v3.38.17/mec-employee-attendance.apk`;
    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const displayPin = empPin || '';
    const displayName = empName || 'Employee';
    let message = `*${bizName.toUpperCase()} STAFF PORTAL*\n\n` +
                  `Hello *${displayName}*! You can now access your Pay Slips and Attendance reports online.\n\n` +
                  `📱 *Direct Login Link:*\n${directPortalUrl}\n\n` +
                  `📲 *Download Staff Attendance App:*\n${appDownloadUrl}\n\n` +
                  (username ? `👤 *Username:* ${username}\n` : '') +
                  (password ? `🔐 *Password:* ${password}\n` : '') +
                  (displayPin ? `🔑 *App PIN:* ${displayPin}\n` : '') +
                  `\nClick the link above to sign in instantly or use the Attendance Mobile App!`;
    
    await window.dispatchWhatsApp(phone, message);
};

// --- HRM Role Permission: Strictly Only CEO & HR Manager can Edit, Delete, Send SMS/WhatsApp, Record Leave ---
window.canManageEmployees = () => {
    const role = (sessionStorage.getItem('userRole') || '').trim().toLowerCase();
    const designation = (sessionStorage.getItem('userDesignation') || '').trim().toLowerCase();
    const email = (sessionStorage.getItem('userEmail') || '').trim().toLowerCase();
    const username = (sessionStorage.getItem('userUsername') || '').trim().toLowerCase();
    const roleAccess = (sessionStorage.getItem('userRoleAccess') || sessionStorage.getItem('userRole_access') || '').trim().toLowerCase();

    // 1. Super Admin / Platform Admin
    if (role === 'superadmin' || designation.includes('super administrator') || email.includes('superadmin')) {
        return true;
    }

    // 2. CEO / Founder / Owner / Proprietor
    const isCeo = (
        role === 'ceo_admin' || role === 'ceo' || role === 'owner' || role === 'founder' || role === 'proprietor' ||
        role.includes('ceo') || designation.includes('ceo') ||
        role.includes('founder') || designation.includes('founder') ||
        role.includes('owner') || designation.includes('owner') ||
        role.includes('proprietor') || designation.includes('proprietor') ||
        email.includes('ceo') || email.includes('owner') || email.includes('malindu') || email.includes('mecbookshop') ||
        username === 'malindu' || username === 'ceo'
    );
    if (isCeo) return true;

    // 3. HR Manager
    const isHrManager = (
        role === 'hr_manager' || role === 'hr' ||
        role.includes('hr') || designation.includes('hr') ||
        role.includes('human resource') || designation.includes('human resource') ||
        roleAccess === 'hr_manager' || roleAccess.includes('hr')
    );
    if (isHrManager) return true;

    // 4. System Administrator (Admin)
    if (role === 'admin') return true;

    return false;
};

// --- HRM Permission Control: View Employee Credentials (PIN & Password) ---
window.canViewEmployeeCredentials = () => {
    return window.canManageEmployees();
};

window.toggleEmployeeCredential = (elemId) => {
    if (!window.canViewEmployeeCredentials()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can view employee credentials.", "error");
    }
    const el = document.getElementById(elemId);
    if (!el) return;
    const secret = el.getAttribute('data-secret');
    if (!secret) return;

    const isMasked = el.innerText.includes('•');
    if (isMasked) {
        el.innerText = secret;
        el.style.fontWeight = '800';
        el.style.letterSpacing = '1px';
    } else {
        el.innerText = secret.length <= 6 ? '••••••' : '••••••••';
        el.style.fontWeight = '700';
        el.style.letterSpacing = '1.5px';
    }
    el.style.color = '#38bdf8';
};

function renderAdminEmployeesUI(employees) {
    const listDiv = document.getElementById('admin-employee-list');
    const tableBody = document.getElementById('employee-list-table-body');
    if (!listDiv) return;
    const storeId = window.getStoreId();
    
    // Branch Filter Logic for HRM
    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const canManage = window.canManageEmployees();
    const canViewCreds = window.canViewEmployeeCredentials();

    // Disable or enable Left Registration Form Submit button based on permission
    const formSubmitBtn = document.querySelector('#employee-form button[type="submit"]');
    if (formSubmitBtn) {
        if (!canManage) {
            formSubmitBtn.disabled = true;
            formSubmitBtn.style.opacity = '0.5';
            formSubmitBtn.style.cursor = 'not-allowed';
            formSubmitBtn.title = "Only CEO / HR Manager can register employees.";
        } else {
            formSubmitBtn.disabled = false;
            formSubmitBtn.style.opacity = '1';
            formSubmitBtn.style.cursor = 'pointer';
            formSubmitBtn.title = "";
        }
    }

    const filtered = employees.filter(emp => {
        // Store Filter (SaaS boundaries)
        const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master');
        
        // Hide Platform Super Admin account from merchant HRM views
        if (emp.name === 'Super Admin' || emp.role === 'SuperAdmin' || emp.role === 'Super Administrator') return false;

        if (emp.storeId && emp.storeId !== storeId) return false;
        if (!emp.storeId && !isMainMec) return false;

        // Branch Visibility
        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            // Staff only see their own branch
            if (emp.branchId && emp.branchId !== userBranch) return false;
            if (!emp.branchId && userBranch !== 'Global') return false;
        } else {
            // Admins see all matching branches for the store, filtered by the dropdown
            if (activeBranchFilter !== 'All' && emp.branchId !== activeBranchFilter) return false;
        }
        return true;
    });

    listDiv.innerHTML = filtered.map(emp => {
        const branchName = emp.branchId === 'Global' ? 'Main Office' : (window.allBranches?.find(b => b.docId === emp.branchId)?.name || 'N/A');
        const safeName = emp.name || 'Unknown';
        
        let pinDisplayHtml = '<span style="color:#94a3b8; font-weight:400;">Not set</span>';
        if (emp.pin) {
            if (canViewCreds) {
                pinDisplayHtml = `
                    <span id="pin-txt-${emp.docId}" data-secret="${emp.pin}" style="background:#0f172a; color:#38bdf8; border:1px solid #334155; padding:3px 8px; border-radius:6px; font-family:monospace; letter-spacing:1.5px; font-weight:700; display:inline-block; vertical-align:middle;">••••••</span>
                    <button type="button" onclick="window.toggleEmployeeCredential('pin-txt-${emp.docId}')" style="border:1px solid rgba(56, 189, 248, 0.3); background:rgba(56, 189, 248, 0.12); color:#38bdf8; border-radius:6px; cursor:pointer; font-size:0.85rem; padding:2px 6px; margin-left:4px; vertical-align:middle;" title="View / Hide PIN">👁️</button>
                `;
            } else {
                pinDisplayHtml = `<span style="background:#1e293b; color:#94a3b8; border:1px solid #334155; padding:3px 8px; border-radius:6px; font-family:monospace;" title="Protected by Permission Role">•••••• 🔒</span>`;
            }
        }

        // Action Buttons: Only accessible to CEO & HR Manager
        const actionsHtml = canManage ? `
            <div style="position:absolute; top:12px; right:12px; display:flex; gap:8px; background: rgba(241, 245, 249, 0.9); padding: 6px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); backdrop-filter: blur(5px); border: 1px solid rgba(255,255,255,0.5);">
                <button onclick="window.sendEmployeeSMS('${emp.phone}', '${safeName}', '${emp.pin || emp.regno}', '${emp.username || ''}', '${emp.password || ''}', '${emp.role_access || emp.role || 'Staff'}', ${!emp.pinChanged})" style="border:none; background:white; color:#0284c7; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(2,132,199,0.25)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Send Login SMS (SMSLenz)">✉️</button>
                <button onclick="window.recordEmployeeLeave('${emp.docId}', '${safeName}')" style="border:none; background:white; color:#10b981; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(16,185,129,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Record Leave">🗓️</button>
                <button onclick="window.shareStaffPortal('${emp.phone}', '${safeName}', '${emp.pin || emp.regno}', '${emp.username || ''}', '${emp.password || ''}')" style="border:none; background:white; color:#25D366; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(37,211,102,0.25)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Share Portal Link via WhatsApp">💬</button>
                <button onclick="window.editEmployee('${emp.docId}')" style="border:none; background:white; color:#f59e0b; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(245,158,11,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Edit Staff">✏️</button>
                <button onclick="confirmDeleteEmployee('${emp.docId}')" style="border:none; background:white; color:#ef4444; width:34px; height:34px; border-radius:10px; cursor:pointer; font-size:1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); display:flex; align-items:center; justify-content:center;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 12px rgba(239,68,68,0.2)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.06)'" title="Delete Staff">🗑️</button>
            </div>
        ` : `
            <div style="position:absolute; top:12px; right:12px; background: rgba(241, 245, 249, 0.85); padding: 5px 12px; border-radius: 10px; font-size: 0.72rem; color: #94a3b8; font-weight: 800; border: 1px solid #e2e8f0; display:flex; align-items:center; gap:4px;" title="Restricted to CEO & HR Manager">
                <span>🔒</span> CEO / HR Only
            </div>
        `;

        return `
        <div class="employee-card">
            <div style="position:absolute; top:12px; left:12px; background:var(--primary-blue); color:white; font-size:0.65rem; padding:3px 8px; border-radius:10px; font-weight:800;">${emp.regno || 'NO-ID'}</div>
            <div class="emp-avatar">${safeName.charAt(0).toUpperCase()}</div>
            <div class="emp-name">${safeName}</div>
            <div class="emp-role">${emp.role}</div>
            <div style="font-size:0.75rem; color:var(--primary-blue); font-weight:700; margin-bottom:5px;">🏢 ${branchName}</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:4px;">📞 ${emp.phone}</div>
            <div style="font-size:0.8rem; color:#0284c7; margin-bottom:8px; font-weight:700; display:flex; align-items:center; gap:4px;">🔑 App PIN: ${pinDisplayHtml}</div>
            <div style="font-weight:700; color:var(--success-green);">Basic: LKR ${emp.salary || 0}</div>
            <div style="font-size:0.85rem; font-weight:600; color:var(--primary-blue);">Commission: ${emp.commission || 0}%</div>
            ${actionsHtml}
        </div>
    `;
    }).join('');

    if (tableBody) {
        tableBody.innerHTML = filtered.map(emp => {
            let passDisplayHtml = '-';
            if (emp.password) {
                if (canViewCreds) {
                    passDisplayHtml = `
                        <div style="display:inline-flex; align-items:center; gap:6px;">
                            <span id="pass-txt-${emp.docId}" data-secret="${emp.password}" style="background:#0f172a; color:#38bdf8; border:1px solid #334155; padding:4px 10px; border-radius:6px; font-family:monospace; font-size:0.9rem; font-weight:700; letter-spacing:1.5px; user-select:all; display:inline-block; vertical-align:middle;">••••••••</span>
                            <button type="button" onclick="window.toggleEmployeeCredential('pass-txt-${emp.docId}')" style="border:1px solid rgba(56, 189, 248, 0.3); background:rgba(56, 189, 248, 0.12); color:#38bdf8; border-radius:6px; cursor:pointer; font-size:0.9rem; padding:3px 8px; vertical-align:middle; transition:all 0.2s;" onmouseover="this.style.background='rgba(56, 189, 248, 0.25)'" onmouseout="this.style.background='rgba(56, 189, 248, 0.12)'" title="View / Hide Password">👁️</button>
                        </div>
                    `;
                } else {
                    passDisplayHtml = `<span style="background:#1e293b; color:#94a3b8; border:1px solid #334155; padding:4px 10px; border-radius:6px; font-family:monospace; font-size:0.85rem;" title="Protected by Permission Role">•••••••• 🔒</span>`;
                }
            }

            const tableActionsHtml = canManage ? `
                <button onclick="window.editEmployee('${emp.docId}')" class="icon-btn edit" title="Edit Staff">✏️</button>
                <button onclick="confirmDeleteEmployee('${emp.docId}')" class="icon-btn delete" title="Delete Staff">🗑️</button>
            ` : `<span style="color:#94a3b8; font-size:0.75rem; font-weight:700;">🔒 CEO / HR Only</span>`;

            return `
                <tr>
                    <td>${emp.regno || '-'}</td>
                    <td style="font-weight:bold; color:var(--primary-blue);">${emp.name || 'Unknown'}</td>
                    <td>${emp.phone}</td>
                    <td>${emp.address || '-'}</td>
                    <td>${emp.username || '-'}</td>
                    <td>${passDisplayHtml}</td>
                    <td>${tableActionsHtml}</td>
                </tr>
            `;
        }).join('');
    }
}

window.downloadEmployeeExcel = () => {
    const tableBody = document.getElementById('employee-list-table-body');
    if (!tableBody) return;
    const canViewCreds = window.canViewEmployeeCredentials();
    
    let csv = "Register No,Name,Phone,Address,System Username,System Password\n";
    const rows = tableBody.querySelectorAll('tr');
    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        if (cols.length >= 6) {
            const reg = cols[0].innerText.trim();
            const name = cols[1].innerText.trim();
            const phone = cols[2].innerText.trim();
            const addr = cols[3].innerText.trim();
            const usr = cols[4].innerText.trim();
            const pwd = canViewCreds ? (cols[5].querySelector('span[data-secret]')?.getAttribute('data-secret') || cols[5].innerText.trim()) : '[RESTRICTED]';
            csv += `"${reg}","${name}","${phone}","${addr}","${usr}","${pwd}"\n`;
        }
    });

    downloadFile(csv, "employee_list.csv");
};

// --- Attendance Date Range & Filter Helpers ---
window.getAttendanceFilterDates = () => {
    const startInput = document.getElementById('attendance-start-date');
    const endInput = document.getElementById('attendance-end-date');
    const legacyInput = document.getElementById('attendance-date-filter');
    const today = new Date().toISOString().split('T')[0];

    let startDate = startInput?.value || legacyInput?.value || today;
    let endDate = endInput?.value || startDate;

    if (startInput && !startInput.value) startInput.value = startDate;
    if (endInput && !endInput.value) endInput.value = endDate;
    if (legacyInput) legacyInput.value = startDate;

    return { startDate, endDate, isRange: startDate !== endDate };
};

window.setAttendanceDatePreset = (preset) => {
    const startInput = document.getElementById('attendance-start-date');
    const endInput = document.getElementById('attendance-end-date');
    const legacyInput = document.getElementById('attendance-date-filter');
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    if (preset === 'today') {
        if (startInput) startInput.value = todayStr;
        if (endInput) endInput.value = todayStr;
        if (legacyInput) legacyInput.value = todayStr;
    } else if (preset === 'month') {
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const firstDay = `${y}-${m}-01`;
        const lastDayDate = new Date(y, now.getMonth() + 1, 0);
        const lastDay = `${y}-${m}-${String(lastDayDate.getDate()).padStart(2, '0')}`;
        if (startInput) startInput.value = firstDay;
        if (endInput) endInput.value = lastDay;
        if (legacyInput) legacyInput.value = firstDay;
    }
    syncAttendanceUI();
};

window.onAttendanceDateRangeChange = () => {
    const startInput = document.getElementById('attendance-start-date');
    const endInput = document.getElementById('attendance-end-date');
    const legacyInput = document.getElementById('attendance-date-filter');

    if (startInput && endInput) {
        if (!startInput.value && endInput.value) startInput.value = endInput.value;
        if (startInput.value && !endInput.value) endInput.value = startInput.value;
        if (startInput.value && endInput.value && startInput.value > endInput.value) {
            endInput.value = startInput.value;
        }
        if (legacyInput) legacyInput.value = startInput.value;
    }
    syncAttendanceUI();
};

window.downloadAttendanceReport = () => {
    const { startDate, endDate, isRange } = window.getAttendanceFilterDates();
    const employees = window.allEmployees || [];
    const attendance = window.allAttendance || [];

    let csv = "Employee Name,Role,Status,In Time,Out Time,Worked Duration,OT Minutes,Note,Remarks / Audit,Date\n";
    employees.forEach(emp => {
        if (isRange) {
            const records = attendance.filter(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date >= startDate && a.date <= endDate);
            records.forEach(record => {
                const status = record ? record.status : 'Pending';
                const inTime = record?.inTime || record?.time || '--:--';
                const outTime = record?.outTime || '--:--';
                const worked = record?.workedDuration || '--';
                const otMins = record?.otMinutes ?? (record?.otHours ? Math.round(record.otHours * 60) : 0);
                const ot = otMins > 0 ? `${otMins} mins` : '0 mins';
                const note = (record?.note || '-').replace(/"/g, '""');
                const remark = (record?.editRemark || '-').replace(/"/g, '""');
                csv += `"${emp.name}","${emp.role}","${status}","${inTime}","${outTime}","${worked}","${ot}","${note}","${remark}","${record.date}"\n`;
            });
        } else {
            const record = attendance.find(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date === startDate);
            const status = record ? record.status : 'Pending';
            const inTime = record?.inTime || record?.time || '--:--';
            const outTime = record?.outTime || '--:--';
            const worked = record?.workedDuration || '--';
            const otMins = record?.otMinutes ?? (record?.otHours ? Math.round(record.otHours * 60) : 0);
            const ot = otMins > 0 ? `${otMins} mins` : '0 mins';
            const note = (record?.note || '-').replace(/"/g, '""');
            const remark = (record?.editRemark || '-').replace(/"/g, '""');
            csv += `"${emp.name}","${emp.role}","${status}","${inTime}","${outTime}","${worked}","${ot}","${note}","${remark}","${startDate}"\n`;
        }
    });

    const fileName = isRange ? `attendance_report_${startDate}_to_${endDate}.csv` : `attendance_report_${startDate}.csv`;
    downloadFile(csv, fileName);
};

function syncAttendanceUI() {
    const tableBody = document.getElementById('attendance-log-body');
    if (!tableBody) return;

    const { startDate, endDate, isRange } = window.getAttendanceFilterDates();
    const employees = window.allEmployees || [];
    const attendance = window.allAttendance || [];

    const storeId = window.getStoreId();
    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');

    const filteredEmployees = employees.filter(emp => {
        const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master');
        if (emp.storeId && emp.storeId !== storeId) return false;
        if (!emp.storeId && !isMainMec) return false;

        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            if (emp.branchId && emp.branchId !== userBranch) return false;
            if (!emp.branchId && userBranch !== 'Global') return false;
        } else {
            if (activeBranchFilter !== 'All' && emp.branchId !== activeBranchFilter) return false;
        }
        return true;
    });

    // Populate Staff Filter Dropdown if needed
    const staffFilterEl = document.getElementById('attendance-staff-filter');
    if (staffFilterEl) {
        const currStaffVal = staffFilterEl.value || 'ALL';
        const expectedCount = filteredEmployees.length + 1;
        if (staffFilterEl.options.length !== expectedCount) {
            staffFilterEl.innerHTML = '<option value="ALL">👥 All Employees</option>' + 
                filteredEmployees.map(e => `<option value="${e.docId}">${e.name} (${e.role || 'Staff'})</option>`).join('');
            staffFilterEl.value = filteredEmployees.some(e => e.docId === currStaffVal) ? currStaffVal : 'ALL';
        }
    }

    const selectedStaffId = staffFilterEl?.value || 'ALL';

    // SCENARIO 1: Date Range View (Month / Custom Range) with ALL Employees -> Aggregated Summary
    if (isRange && selectedStaffId === 'ALL') {
        tableBody.innerHTML = filteredEmployees.map(emp => {
            const empRecords = attendance.filter(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date >= startDate && a.date <= endDate);
            
            let presentCount = 0;
            let halfDayCount = 0;
            let dayOffCount = 0;
            let absentCount = 0;
            let totalWorkedMins = 0;
            let totalOtMins = 0;

            empRecords.forEach(r => {
                if (r.status === 'Present') presentCount++;
                else if (r.status === 'Half Day') halfDayCount++;
                else if (r.status === 'Day Off') dayOffCount++;
                else if (r.status === 'Absent') absentCount++;

                totalWorkedMins += (r.workedMinutes || 0);
                const ot = r.otMinutes ?? (r.otHours ? Math.round(r.otHours * 60) : 0);
                totalOtMins += ot;
            });

            const workedHours = Math.floor(totalWorkedMins / 60);
            const workedMinsRem = totalWorkedMins % 60;
            const workedTotalStr = totalWorkedMins > 0 ? `${workedHours}h ${workedMinsRem}m (${empRecords.length} shifts)` : '--';
            const otBadge = totalOtMins > 0 
                ? `<span style="background:rgba(16,185,129,0.18); color:#10b981; font-weight:800; padding:3px 8px; border-radius:6px; font-size:0.8rem; border:1px solid rgba(16,185,129,0.3);">⚡ +${totalOtMins} mins</span>`
                : `<span style="color:#64748b; font-size:0.8rem;">0 mins</span>`;

            return `
                <tr>
                    <td style="font-weight:700;">${emp.name}</td>
                    <td style="color:#94a3b8; font-size:0.85rem;">${emp.role}</td>
                    <td>
                        <div style="display:flex; flex-wrap:wrap; gap:4px; font-size:0.75rem;">
                            <span style="background:rgba(16,185,129,0.15); color:#10b981; padding:2px 6px; border-radius:4px; font-weight:700;">🟢 ${presentCount} FD</span>
                            <span style="background:rgba(245,158,11,0.15); color:#f59e0b; padding:2px 6px; border-radius:4px; font-weight:700;">🟡 ${halfDayCount} HD</span>
                            <span style="background:rgba(168,85,247,0.15); color:#a855f7; padding:2px 6px; border-radius:4px; font-weight:700;">🟣 ${dayOffCount} DO</span>
                            ${absentCount > 0 ? `<span style="background:rgba(239,68,68,0.15); color:#ef4444; padding:2px 6px; border-radius:4px; font-weight:700;">🔴 ${absentCount} A</span>` : ''}
                        </div>
                    </td>
                    <td style="color:#64748b; font-size:0.8rem;">Range View</td>
                    <td style="color:#64748b; font-size:0.8rem;">Range View</td>
                    <td style="font-size:0.85rem; font-weight:600; color:#38bdf8;">${workedTotalStr}</td>
                    <td>${otBadge}</td>
                    <td style="font-size:0.8rem; color:#94a3b8;">${empRecords.length} records logged in period</td>
                    <td style="font-size:0.8rem; color:#cbd5e1;">Period: ${startDate} to ${endDate}</td>
                    <td style="text-align:center;">
                        <button onclick="window.downloadIndividualAttendancePDF('${emp.docId}')" class="action-btn" style="padding: 4px 10px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 4px; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 8px; cursor: pointer; font-weight: 700;" title="Download Full Month A4 PDF for ${emp.name}">
                            <span>📄</span> A4 PDF
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
        return;
    }

    // SCENARIO 2: Single Employee Selected across Range OR Single Day View for filtered employees
    let displayList = [];

    if (isRange && selectedStaffId !== 'ALL') {
        const targetEmp = filteredEmployees.find(e => e.docId === selectedStaffId);
        if (!targetEmp) return;

        // Iterate day-by-day across the date range for this single employee
        let curr = new Date(startDate);
        const endD = new Date(endDate);
        while (curr <= endD) {
            const year = curr.getFullYear();
            const month = String(curr.getMonth() + 1).padStart(2, '0');
            const day = String(curr.getDate()).padStart(2, '0');
            const dateStr = `${year}-${month}-${day}`;
            const rec = attendance.find(a => (a.empId === targetEmp.docId || a.empId === targetEmp.regno) && a.date === dateStr);
            displayList.push({ emp: targetEmp, record: rec || null, date: dateStr });
            curr.setDate(curr.getDate() + 1);
        }
    } else {
        // Single Day View (startDate === endDate)
        const staffPool = selectedStaffId !== 'ALL' 
            ? filteredEmployees.filter(e => e.docId === selectedStaffId)
            : filteredEmployees;

        displayList = staffPool.map(emp => {
            const rec = attendance.find(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date === startDate);
            return { emp, record: rec || null, date: startDate };
        });
    }

    tableBody.innerHTML = displayList.map(item => {
        const { emp, record, date } = item;
        const status = record ? record.status : 'Pending';

        let statusBadge = '<span style="color:#94a3b8; font-size:0.75rem; font-weight:700;">⚪ Pending</span>';
        if (status === 'Present') {
            statusBadge = '<span style="background:rgba(16,185,129,0.15); color:#10b981; padding:3px 8px; border-radius:6px; font-weight:800; font-size:0.75rem;">🟢 Full Day</span>';
        } else if (status === 'Half Day') {
            statusBadge = '<span style="background:rgba(245,158,11,0.15); color:#f59e0b; padding:3px 8px; border-radius:6px; font-weight:800; font-size:0.75rem;">🟡 Half Day</span>';
        } else if (status === 'Day Off') {
            statusBadge = '<span style="background:rgba(168,85,247,0.15); color:#a855f7; padding:3px 8px; border-radius:6px; font-weight:800; font-size:0.75rem;">🟣 Day Off</span>';
        } else if (status === 'On Leave') {
            statusBadge = '<span style="background:rgba(56,189,248,0.15); color:#38bdf8; padding:3px 8px; border-radius:6px; font-weight:800; font-size:0.75rem;">🏖️ On Leave</span>';
        } else if (status === 'Absent') {
            statusBadge = '<span style="background:rgba(239,68,68,0.15); color:#ef4444; padding:3px 8px; border-radius:6px; font-weight:800; font-size:0.75rem;">🔴 Absent</span>';
        }

        const inTime = record?.inTime || record?.time || '--:--';
        const outTime = record?.outTime || '--:--';
        const workedStr = record?.workedDuration || (record?.inTime && !record?.outTime ? '⏱️ In Shift' : '--');
        const otMins = record?.otMinutes ?? (record?.otHours ? Math.round(record.otHours * 60) : 0);
        const otBadge = otMins > 0
            ? `<span style="background:rgba(16,185,129,0.18); color:#10b981; font-weight:800; padding:3px 8px; border-radius:6px; font-size:0.8rem; border:1px solid rgba(16,185,129,0.3);">⚡ +${otMins} mins</span>`
            : `<span style="color:#64748b; font-size:0.8rem;">0 mins</span>`;

        const nameDisplay = isRange && selectedStaffId !== 'ALL' 
            ? `${date} (${new Date(date).toLocaleDateString('en-US', { weekday: 'short' })})`
            : emp.name;

        return `
            <tr>
                <td style="font-weight:700;">${nameDisplay}</td>
                <td style="color:#94a3b8; font-size:0.85rem;">${emp.role}</td>
                <td>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <div>${statusBadge}</div>
                        <div style="display:flex; gap:3px; margin-top:2px;">
                            <button onclick="window.markAttendance('${emp.docId}', 'Present')" class="action-btn ${status === 'Present' ? 'success' : ''}" style="padding:2px 6px; font-size:0.65rem;" title="Mark Full Day (FD)">FD</button>
                            <button onclick="window.markAttendance('${emp.docId}', 'Half Day')" class="action-btn ${status === 'Half Day' ? 'warning' : ''}" style="padding:2px 6px; font-size:0.65rem;" title="Mark Half Day (HD)">HD</button>
                            <button onclick="window.markAttendance('${emp.docId}', 'Day Off')" class="action-btn ${status === 'Day Off' ? 'primary' : ''}" style="padding:2px 6px; font-size:0.65rem;" title="Mark Day Off (DO)">DO</button>
                            <button onclick="window.markAttendance('${emp.docId}', 'Absent')" class="action-btn ${status === 'Absent' ? 'danger' : ''}" style="padding:2px 6px; font-size:0.65rem;" title="Mark Absent (A)">A</button>
                        </div>
                    </div>
                </td>
                <td style="font-weight:700; color:#38bdf8;">${inTime}</td>
                <td style="font-weight:700; color:#f59e0b;">${outTime}</td>
                <td style="font-size:0.85rem; font-weight:600;">${workedStr}</td>
                <td>${otBadge}</td>
                <td style="font-size:0.8rem; color:#94a3b8; max-width:200px;">${record?.note || '-'}</td>
                <td style="font-size:0.8rem; max-width:240px;">
                    ${record?.editRemark ? `
                        <div style="background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.25); border-left:3px solid #f59e0b; padding:5px 8px; border-radius:6px; color:#fef3c7;">
                            <div style="font-weight:700; font-size:0.75rem; color:#f59e0b; display:flex; align-items:center; gap:4px;">
                                <span>🛡️</span> <span>${record.editedBy || 'Authorized'}</span>
                                <span style="opacity:0.75; font-size:0.7rem; font-weight:normal;">(${record.editedRole || 'Admin'})</span>
                            </div>
                            <div style="font-size:0.75rem; margin-top:3px; color:#cbd5e1; line-height:1.3; word-break:break-word;">
                                ${record.editReason || record.editRemark}
                            </div>
                        </div>
                    ` : '<span style="color:#64748b; font-size:0.8rem;">-</span>'}
                </td>
                <td style="text-align:center;">
                    <button onclick="window.downloadIndividualAttendancePDF('${emp.docId}')" class="action-btn" style="padding: 4px 10px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 4px; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 8px; cursor: pointer; font-weight: 700;" title="Download Full Month A4 PDF for ${emp.name}">
                        <span>📄</span> A4 PDF
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// --- Printable A4 PDF Report Generation Engine ---
window.downloadIndividualAttendancePDF = (empId) => {
    window.downloadAttendancePDF(empId);
};

window.downloadAttendancePDF = async (targetEmpId = null) => {
    const { startDate, endDate, isRange } = window.getAttendanceFilterDates();
    const employees = window.allEmployees || [];
    const attendance = window.allAttendance || [];
    const storeInfo = window.storeInfo || {};
    const storeName = storeInfo.name || storeInfo.storeName || 'MEC POS & Bookshop';
    const storePhone = storeInfo.phone || storeInfo.contact || '077 123 4567';
    const storeAddress = storeInfo.address || 'Commercial Centre, Sri Lanka';
    const activeBranchName = activeBranchFilter !== 'All' 
        ? (window.allBranches?.find(b => b.docId === activeBranchFilter)?.name || activeBranchFilter) 
        : 'All Branches / Main Store';

    const staffFilterEl = document.getElementById('attendance-staff-filter');
    const effectiveEmpId = targetEmpId || (staffFilterEl?.value !== 'ALL' ? staffFilterEl?.value : null);

    // If effectiveEmpId is set, generate Individual Monthly A4 Timesheet
    if (effectiveEmpId) {
        const emp = employees.find(e => e.docId === effectiveEmpId || e.regno === effectiveEmpId);
        if (!emp) return window.showToast("Employee record not found.", "error");

        // Strictly respect user selected dates
        const pStart = startDate;
        const pEnd = endDate;

        // Build list of all days in the selected date range
        const dayRows = [];
        const [sy, sm, sd] = pStart.split('-').map(Number);
        const [ey, em, ed] = pEnd.split('-').map(Number);
        const curr = new Date(sy, sm - 1, sd, 12, 0, 0);
        const endD = new Date(ey, em - 1, ed, 12, 0, 0);

        let countFD = 0;
        let countHD = 0;
        let countDO = 0;
        let countA = 0;
        let totalWorkedMinutes = 0;
        let totalOvertimeMinutes = 0;

        while (curr <= endD) {
            const y = curr.getFullYear();
            const m = String(curr.getMonth() + 1).padStart(2, '0');
            const d = String(curr.getDate()).padStart(2, '0');
            const dateStr = `${y}-${m}-${d}`;
            const dayName = curr.toLocaleDateString('en-US', { weekday: 'short' });
            const dayNum = curr.getDate();
            const isWeekend = curr.getDay() === 0; // Sunday

            const rec = attendance.find(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date === dateStr);
            const status = rec?.status || (isWeekend ? 'Day Off' : 'Pending');
            const inTime = rec?.inTime || rec?.time || '--:--';
            const outTime = rec?.outTime || '--:--';
            const worked = rec?.workedDuration || (rec?.inTime && !rec?.outTime ? 'In Shift' : '--');
            const otMins = rec?.otMinutes ?? (rec?.otHours ? Math.round(rec.otHours * 60) : 0);
            const ot = otMins > 0 ? `+${otMins} mins` : '0 mins';
            const remarks = rec?.editRemark || rec?.note || '-';

            if (status === 'Present') countFD++;
            else if (status === 'Half Day') countHD++;
            else if (status === 'Day Off') countDO++;
            else if (status === 'Absent') countA++;

            totalWorkedMinutes += (rec?.workedMinutes || 0);
            totalOvertimeMinutes += otMins;

            dayRows.push({
                dayNum,
                dateStr,
                dayName,
                isWeekend,
                status,
                inTime,
                outTime,
                worked,
                otMins,
                ot,
                remarks
            });

            curr.setDate(curr.getDate() + 1);
        }

        const totalWorkedHours = Math.floor(totalWorkedMinutes / 60);
        const totalWorkedMinsRem = totalWorkedMinutes % 60;
        const totalOtHours = +(totalOvertimeMinutes / 60).toFixed(2);
        const dateRangeLabel = pStart === pEnd ? pStart : `${pStart} to ${pEnd}`;
        const isSingleDay = pStart === pEnd;

        const printHtml = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>${emp.name} - Attendance (${dateRangeLabel})</title>
                <style>
                    @page {
                        size: A4 portrait;
                        margin: 10mm 12mm 12mm 12mm;
                    }
                    * { box-sizing: border-box; }
                    body {
                        font-family: 'Segoe UI', Inter, -apple-system, BlinkMacSystemFont, Arial, sans-serif;
                        color: #0f172a;
                        background: #fff;
                        margin: 0;
                        padding: 0;
                        font-size: 11px;
                        line-height: 1.4;
                    }
                    .header-container {
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-start;
                        border-bottom: 2.5px solid #0284c7;
                        padding-bottom: 8px;
                        margin-bottom: 12px;
                    }
                    .store-brand h1 {
                        margin: 0;
                        font-size: 18px;
                        font-weight: 900;
                        color: #0369a1;
                        letter-spacing: -0.5px;
                    }
                    .store-brand p {
                        margin: 2px 0 0 0;
                        font-size: 9px;
                        color: #64748b;
                    }
                    .report-badge {
                        text-align: right;
                    }
                    .report-badge h2 {
                        margin: 0;
                        font-size: 13px;
                        font-weight: 800;
                        color: #0f172a;
                        text-transform: uppercase;
                    }
                    .report-badge span {
                        font-size: 9.5px;
                        color: #0284c7;
                        font-weight: 700;
                    }
                    .emp-card {
                        background: #f8fafc;
                        border: 1px solid #e2e8f0;
                        border-radius: 8px;
                        padding: 8px 12px;
                        margin-bottom: 12px;
                        display: flex;
                        flex-direction: row;
                        justify-content: space-between;
                        gap: 10px;
                    }
                    .emp-card-item {
                        flex: 1;
                    }
                    .emp-card-item:first-child {
                        flex: 1.5;
                    }
                    .emp-card-item label {
                        display: block;
                        font-size: 8px;
                        color: #64748b;
                        font-weight: 700;
                        text-transform: uppercase;
                    }
                    .emp-card-item value {
                        display: block;
                        font-size: 11px;
                        font-weight: 700;
                        color: #0f172a;
                    }
                    .kpi-row {
                        display: flex;
                        flex-direction: row;
                        gap: 8px;
                        margin-bottom: 14px;
                    }
                    .kpi-card {
                        flex: 1;
                        background: #ffffff;
                        border: 1px solid #cbd5e1;
                        border-radius: 6px;
                        padding: 6px 8px;
                        text-align: center;
                    }
                    .kpi-card .kpi-val {
                        font-size: 14px;
                        font-weight: 900;
                    }
                    .kpi-card .kpi-lbl {
                        font-size: 8px;
                        font-weight: 700;
                        color: #64748b;
                        text-transform: uppercase;
                    }
                    table.timesheet-table {
                        width: 100%;
                        border-collapse: collapse;
                        font-size: 9.5px;
                        margin-bottom: 14px;
                    }
                    table.timesheet-table th {
                        background: #0f172a;
                        color: #ffffff;
                        padding: 5px 6px;
                        text-align: left;
                        font-size: 8.5px;
                        font-weight: 700;
                        border: 1px solid #0f172a;
                        text-transform: uppercase;
                    }
                    table.timesheet-table td {
                        padding: 4px 6px;
                        border: 1px solid #e2e8f0;
                        vertical-align: middle;
                        word-break: break-word;
                    }
                    table.timesheet-table tr:nth-child(even) {
                        background: #f8fafc;
                    }
                    .status-tag {
                        display: inline-block;
                        padding: 1px 5px;
                        border-radius: 4px;
                        font-weight: 700;
                        font-size: 8.5px;
                    }
                    .status-present { background: #dcfce7; color: #15803d; }
                    .status-halfday { background: #fef3c7; color: #b45309; }
                    .status-dayoff { background: #f3e8ff; color: #7e22ce; }
                    .status-absent { background: #fee2e2; color: #b91c1c; }
                    .status-pending { background: #f1f5f9; color: #64748b; }
                    .ot-tag {
                        font-weight: 800;
                        color: #0284c7;
                    }
                    .signatures-container {
                        display: flex;
                        flex-direction: row;
                        gap: 25px;
                        margin-top: 24px;
                        page-break-inside: avoid;
                    }
                    .sig-box {
                        flex: 1;
                        border-top: 1.5px dashed #94a3b8;
                        padding-top: 5px;
                        text-align: center;
                    }
                    .sig-box .title {
                        font-size: 9px;
                        font-weight: 800;
                        color: #334155;
                        text-transform: uppercase;
                    }
                    .sig-box .sub {
                        font-size: 8px;
                        color: #64748b;
                    }
                    @media print {
                        .no-print { display: none !important; }
                    }
                </style>
            </head>
            <body>
                <div class="no-print" style="position:fixed; top:10px; right:15px; z-index:9999; display:flex; gap:8px;">
                    <button onclick="window.print()" style="background:#0284c7; color:white; border:none; padding:8px 16px; border-radius:6px; font-weight:bold; cursor:pointer; font-size:12px; box-shadow:0 4px 10px rgba(0,0,0,0.15);">🖨️ Print / Save as PDF</button>
                    <button onclick="window.close()" style="background:#64748b; color:white; border:none; padding:8px 12px; border-radius:6px; cursor:pointer; font-size:12px;">Close</button>
                </div>

                <div class="header-container">
                    <div class="store-brand">
                        <h1>${storeName}</h1>
                        <p>📍 ${storeAddress} | 📞 ${storePhone} | Branch: ${activeBranchName}</p>
                    </div>
                    <div class="report-badge">
                        <h2>${isSingleDay ? 'Daily Attendance Timesheet' : 'Attendance Timesheet'}</h2>
                        <span>Period: ${dateRangeLabel}</span>
                    </div>
                </div>

                <div class="emp-card">
                    <div class="emp-card-item">
                        <label>Employee Name</label>
                        <value>${emp.name}</value>
                    </div>
                    <div class="emp-card-item">
                        <label>Role / Designation</label>
                        <value>${emp.role || 'Staff'}</value>
                    </div>
                    <div class="emp-card-item">
                        <label>Staff ID / Reg No</label>
                        <value>${emp.regno || emp.docId || '-'}</value>
                    </div>
                </div>

                <div class="kpi-row">
                    <div class="kpi-card" style="border-left: 3px solid #16a34a;">
                        <div class="kpi-val" style="color: #16a34a;">${countFD}</div>
                        <div class="kpi-lbl">Full Days (FD)</div>
                    </div>
                    <div class="kpi-card" style="border-left: 3px solid #d97706;">
                        <div class="kpi-val" style="color: #d97706;">${countHD}</div>
                        <div class="kpi-lbl">Half Days (HD)</div>
                    </div>
                    <div class="kpi-card" style="border-left: 3px solid #9333ea;">
                        <div class="kpi-val" style="color: #9333ea;">${countDO}</div>
                        <div class="kpi-lbl">Day Offs (DO)</div>
                    </div>
                    <div class="kpi-card" style="border-left: 3px solid #dc2626;">
                        <div class="kpi-val" style="color: #dc2626;">${countA}</div>
                        <div class="kpi-lbl">Absent (A)</div>
                    </div>
                    <div class="kpi-card" style="border-left: 3px solid #0284c7;">
                        <div class="kpi-val" style="color: #0284c7;">${totalWorkedHours}h ${totalWorkedMinsRem}m</div>
                        <div class="kpi-lbl">Total Worked</div>
                    </div>
                    <div class="kpi-card" style="border-left: 3px solid #0d9488;">
                        <div class="kpi-val" style="color: #0d9488;">+${totalOvertimeMinutes}m</div>
                        <div class="kpi-lbl">Total OT Mins (${totalOtHours}h)</div>
                    </div>
                </div>

                <table class="timesheet-table">
                    <thead>
                        <tr>
                            <th style="width: 25px; text-align:center;">#</th>
                            <th style="width: 75px;">Date</th>
                            <th style="width: 45px;">Day</th>
                            <th style="width: 75px;">Status</th>
                            <th style="width: 55px;">In Time</th>
                            <th style="width: 55px;">Out Time</th>
                            <th style="width: 80px;">Worked Time</th>
                            <th style="width: 75px;">OT (Mins)</th>
                            <th>Remarks & Audit Trail</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${dayRows.map(r => {
                            let tagClass = 'status-pending';
                            if (r.status === 'Present') tagClass = 'status-present';
                            else if (r.status === 'Half Day') tagClass = 'status-halfday';
                            else if (r.status === 'Day Off') tagClass = 'status-dayoff';
                            else if (r.status === 'Absent') tagClass = 'status-absent';

                            return `
                                <tr>
                                    <td style="text-align:center; font-weight:700; color:#64748b;">${r.dayNum}</td>
                                    <td style="font-weight:700;">${r.dateStr}</td>
                                    <td style="color:${r.isWeekend ? '#ef4444' : '#64748b'}; font-weight:${r.isWeekend ? '800' : '600'};">${r.dayName}</td>
                                    <td><span class="status-tag ${tagClass}">${r.status}</span></td>
                                    <td style="font-weight:700; color:#0369a1;">${r.inTime}</td>
                                    <td style="font-weight:700; color:#d97706;">${r.outTime}</td>
                                    <td style="font-weight:600;">${r.worked}</td>
                                    <td class="${r.otMins > 0 ? 'ot-tag' : ''}">${r.otMins > 0 ? `+${r.otMins} mins` : '0 mins'}</td>
                                    <td style="font-size:8px; color:#475569;">${r.remarks}</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>

                <div class="signatures-container">
                    <div class="sig-box">
                        <div class="title">Employee Signature</div>
                        <div class="sub">${emp.name}</div>
                    </div>
                    <div class="sig-box">
                        <div class="title">HR / Branch Supervisor</div>
                        <div class="sub">Verified & Reconciled</div>
                    </div>
                    <div class="sig-box">
                        <div class="title">CEO / Managing Director</div>
                        <div class="sub">Authorized Approval</div>
                    </div>
                </div>
            </body>
            </html>
        `;

        const filenameLabel = pStart === pEnd ? pStart : `${pStart}_to_${pEnd}`;
        const filename = `${emp.name.replace(/\s+/g, '_')}_Attendance_${filenameLabel}.pdf`;
        await window.saveOrPrintA4PDF(printHtml, filename, 'portrait');
        return;
    }

    // SCENARIO 2: All Employees Monthly / Range Summary (A4 Landscape)
    const filteredEmployees = employees.filter(emp => {
        const isMainMec = (storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master');
        if (emp.storeId && emp.storeId !== storeId) return false;
        if (!emp.storeId && !isMainMec) return false;

        if (userRole !== 'Admin' && userRole !== 'SuperAdmin' && userRole !== 'CEO_Admin') {
            if (emp.branchId && emp.branchId !== userBranch) return false;
            if (!emp.branchId && userBranch !== 'Global') return false;
        } else {
            if (activeBranchFilter !== 'All' && emp.branchId !== activeBranchFilter) return false;
        }
        return true;
    });

    let overallFD = 0;
    let overallHD = 0;
    let overallDO = 0;
    let overallA = 0;
    let overallWorkedMins = 0;
    let overallOtMins = 0;

    const summaryRows = filteredEmployees.map((emp, idx) => {
        const empRecords = attendance.filter(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date >= startDate && a.date <= endDate);

        let pCount = 0;
        let hdCount = 0;
        let doCount = 0;
        let aCount = 0;
        let wMins = 0;
        let otMins = 0;

        empRecords.forEach(r => {
            if (r.status === 'Present') pCount++;
            else if (r.status === 'Half Day') hdCount++;
            else if (r.status === 'Day Off') doCount++;
            else if (r.status === 'Absent') aCount++;

            wMins += (r.workedMinutes || 0);
            const ot = r.otMinutes ?? (r.otHours ? Math.round(r.otHours * 60) : 0);
            otMins += ot;
        });

        overallFD += pCount;
        overallHD += hdCount;
        overallDO += doCount;
        overallA += aCount;
        overallWorkedMins += wMins;
        overallOtMins += otMins;

        const wHours = Math.floor(wMins / 60);
        const wRem = wMins % 60;
        const otHours = +(otMins / 60).toFixed(2);

        return {
            idx: idx + 1,
            regno: emp.regno || `EMP-${idx+1}`,
            name: emp.name,
            role: emp.role || 'Staff',
            shiftsCount: empRecords.length,
            pCount,
            hdCount,
            doCount,
            aCount,
            workedStr: wMins > 0 ? `${wHours}h ${wRem}m` : '--',
            otMins,
            otHours
        };
    });

    const totWHours = Math.floor(overallWorkedMins / 60);
    const totWRem = overallWorkedMins % 60;
    const totOtHours = +(overallOtMins / 60).toFixed(2);

    const printHtml = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Attendance & OT Summary (${startDate} to ${endDate})</title>
            <style>
                @page {
                    size: A4 landscape;
                    margin: 8mm 10mm 10mm 10mm;
                }
                * { box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', Inter, -apple-system, BlinkMacSystemFont, Arial, sans-serif;
                    color: #0f172a;
                    background: #fff;
                    margin: 0;
                    padding: 0;
                    font-size: 10px;
                    line-height: 1.4;
                }
                .header-container {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    border-bottom: 2.5px solid #0284c7;
                    padding-bottom: 8px;
                    margin-bottom: 12px;
                }
                .store-brand h1 {
                    margin: 0;
                    font-size: 19px;
                    font-weight: 900;
                    color: #0369a1;
                    letter-spacing: -0.5px;
                }
                .store-brand p {
                    margin: 2px 0 0 0;
                    font-size: 9.5px;
                    color: #64748b;
                }
                .report-badge {
                    text-align: right;
                }
                .report-badge h2 {
                    margin: 0;
                    font-size: 14px;
                    font-weight: 800;
                    color: #0f172a;
                    text-transform: uppercase;
                }
                .report-badge span {
                    font-size: 10px;
                    color: #0284c7;
                    font-weight: 700;
                }
                .kpi-row {
                    display: flex;
                    flex-direction: row;
                    gap: 8px;
                    margin-bottom: 14px;
                }
                .kpi-card {
                    flex: 1;
                    background: #f8fafc;
                    border: 1px solid #cbd5e1;
                    border-radius: 6px;
                    padding: 6px 8px;
                    text-align: center;
                }
                .kpi-card .kpi-val {
                    font-size: 14px;
                    font-weight: 900;
                }
                .kpi-card .kpi-lbl {
                    font-size: 8px;
                    font-weight: 700;
                    color: #64748b;
                    text-transform: uppercase;
                }
                table.summary-table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 9.5px;
                    margin-bottom: 16px;
                }
                table.summary-table th {
                    background: #0f172a;
                    color: #ffffff;
                    padding: 6px 8px;
                    text-align: left;
                    font-size: 8.5px;
                    font-weight: 700;
                    border: 1px solid #0f172a;
                    text-transform: uppercase;
                }
                table.summary-table td {
                    padding: 5px 8px;
                    border: 1px solid #e2e8f0;
                    vertical-align: middle;
                    word-break: break-word;
                }
                table.summary-table tr:nth-child(even) {
                    background: #f8fafc;
                }
                .signatures-container {
                    display: flex;
                    flex-direction: row;
                    gap: 40px;
                    margin-top: 30px;
                    page-break-inside: avoid;
                }
                .sig-box {
                    flex: 1;
                    border-top: 1.5px dashed #94a3b8;
                    padding-top: 5px;
                    text-align: center;
                }
                .sig-box .title {
                    font-size: 9.5px;
                    font-weight: 800;
                    color: #334155;
                    text-transform: uppercase;
                }
                .sig-box .sub {
                    font-size: 8.5px;
                    color: #64748b;
                }
                @media print {
                    .no-print { display: none !important; }
                }
            </style>
        </head>
        <body>
            <div class="no-print" style="position:fixed; top:10px; right:15px; z-index:9999; display:flex; gap:8px;">
                <button onclick="window.print()" style="background:#0284c7; color:white; border:none; padding:8px 16px; border-radius:6px; font-weight:bold; cursor:pointer; font-size:12px; box-shadow:0 4px 10px rgba(0,0,0,0.15);">🖨️ Print / Save as PDF</button>
                <button onclick="window.close()" style="background:#64748b; color:white; border:none; padding:8px 12px; border-radius:6px; cursor:pointer; font-size:12px;">Close</button>
            </div>

            <div class="header-container">
                <div class="store-brand">
                    <h1>${storeName}</h1>
                    <p>📍 ${storeAddress} | 📞 ${storePhone} | Branch: ${activeBranchName}</p>
                </div>
                <div class="report-badge">
                    <h2>Staff Attendance & OT Summary Report</h2>
                    <span>Period: ${startDate === endDate ? startDate : `${startDate} to ${endDate}`}</span>
                </div>
            </div>

            <div class="kpi-row">
                <div class="kpi-card" style="border-left: 3px solid #0284c7;">
                    <div class="kpi-val" style="color: #0284c7;">${filteredEmployees.length}</div>
                    <div class="kpi-lbl">Total Staff</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #16a34a;">
                    <div class="kpi-val" style="color: #16a34a;">${overallFD}</div>
                    <div class="kpi-lbl">Total FD</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #d97706;">
                    <div class="kpi-val" style="color: #d97706;">${overallHD}</div>
                    <div class="kpi-lbl">Total HD</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #9333ea;">
                    <div class="kpi-val" style="color: #9333ea;">${overallDO}</div>
                    <div class="kpi-lbl">Day Offs</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #dc2626;">
                    <div class="kpi-val" style="color: #dc2626;">${overallA}</div>
                    <div class="kpi-lbl">Total Absent</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #0369a1;">
                    <div class="kpi-val" style="color: #0369a1;">${totWHours}h ${totWRem}m</div>
                    <div class="kpi-lbl">Total Worked</div>
                </div>
                <div class="kpi-card" style="border-left: 3px solid #0d9488;">
                    <div class="kpi-val" style="color: #0d9488;">+${overallOtMins} mins</div>
                    <div class="kpi-lbl">Total OT (${totOtHours}h)</div>
                </div>
            </div>

            <table class="summary-table">
                <thead>
                    <tr>
                        <th style="width: 25px; text-align:center;">#</th>
                        <th style="width: 70px;">Reg No</th>
                        <th>Staff Name</th>
                        <th style="width: 110px;">Role</th>
                        <th style="width: 50px; text-align:center;">Shifts</th>
                        <th style="width: 55px; text-align:center;">FD</th>
                        <th style="width: 55px; text-align:center;">HD</th>
                        <th style="width: 55px; text-align:center;">DO</th>
                        <th style="width: 55px; text-align:center;">A</th>
                        <th style="width: 90px; text-align:right;">Worked Time</th>
                        <th style="width: 90px; text-align:right;">OT (Mins)</th>
                        <th style="width: 75px; text-align:right;">OT Hours</th>
                    </tr>
                </thead>
                <tbody>
                    ${summaryRows.map(r => `
                        <tr>
                            <td style="text-align:center; color:#64748b; font-weight:700;">${r.idx}</td>
                            <td style="font-family:monospace; font-weight:700; color:#0369a1;">${r.regno}</td>
                            <td style="font-weight:700;">${r.name}</td>
                            <td style="color:#64748b;">${r.role}</td>
                            <td style="text-align:center; font-weight:700;">${r.shiftsCount}</td>
                            <td style="text-align:center; color:#15803d; font-weight:800;">${r.pCount}</td>
                            <td style="text-align:center; color:#b45309; font-weight:800;">${r.hdCount}</td>
                            <td style="text-align:center; color:#7e22ce; font-weight:700;">${r.doCount}</td>
                            <td style="text-align:center; color:#b91c1c; font-weight:700;">${r.aCount}</td>
                            <td style="text-align:right; font-weight:700; color:#0f172a;">${r.workedStr}</td>
                            <td style="text-align:right; font-weight:800; color:#0284c7;">${r.otMins > 0 ? `+${r.otMins} mins` : '0 mins'}</td>
                            <td style="text-align:right; color:#475569;">${r.otHours > 0 ? `${r.otHours} hrs` : '-'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>

            <div class="signatures-container">
                <div class="sig-box">
                    <div class="title">Prepared By (HR Officer)</div>
                    <div class="sub">Human Resources Department</div>
                </div>
                <div class="sig-box">
                    <div class="title">Checked By (Internal Audit / Accounts)</div>
                    <div class="sub">Payroll & Shift Verification</div>
                </div>
                <div class="sig-box">
                    <div class="title">Approved By (CEO / Director)</div>
                    <div class="sub">Executive Authorization</div>
                </div>
            </div>
        </body>
        </html>
    `;

    const summaryDateLabel = startDate === endDate ? startDate : `${startDate}_to_${endDate}`;
    const filename = `Attendance_Summary_${summaryDateLabel}.pdf`;
    await window.saveOrPrintA4PDF(printHtml, filename, 'landscape');
};

// Helper to trigger direct html2pdf save or print preview fallback
window.saveOrPrintA4PDF = async (htmlContent, filename, orientation = 'portrait') => {
    let container = null;
    const savedScrollX = window.pageXOffset || document.documentElement.scrollLeft || 0;
    const savedScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;

    // If html2pdf is available, download directly
    if (window.html2pdf && typeof window.html2pdf === 'function') {
        try {
            window.showToast?.("⏳ Formatting & Generating Official A4 PDF...", "info");

            // Temporarily scroll window to top (0,0) so html2canvas coordinate mapping has zero offset error
            window.scrollTo(0, 0);

            const targetWidthPx = orientation === 'landscape' ? 1120 : 794;

            container = document.createElement('div');
            container.id = 'pdf-render-temp-container';
            container.style.position = 'absolute';
            container.style.left = '0px';
            container.style.top = '0px';
            container.style.width = `${targetWidthPx}px`;
            container.style.minWidth = `${targetWidthPx}px`;
            container.style.maxWidth = `${targetWidthPx}px`;
            container.style.backgroundColor = '#ffffff';
            container.style.color = '#0f172a';
            container.style.zIndex = '99999999';
            container.style.boxSizing = 'border-box';
            container.style.padding = '14px 18px';
            container.style.margin = '0';
            container.style.overflow = 'visible';
            container.style.display = 'block';

            // Cleanly parse htmlContent, remove any .no-print elements
            const parser = new DOMParser();
            const doc = parser.parseFromString(htmlContent, 'text/html');
            doc.querySelectorAll('.no-print').forEach(el => el.remove());

            const styleTags = Array.from(doc.querySelectorAll('style')).map(s => s.outerHTML).join('\n');
            const bodyContent = doc.body ? doc.body.innerHTML : htmlContent;

            container.innerHTML = `
                <style>
                    #pdf-render-temp-container {
                        font-family: 'Segoe UI', Inter, -apple-system, BlinkMacSystemFont, Arial, sans-serif !important;
                        color: #0f172a !important;
                        background: #ffffff !important;
                        -webkit-print-color-adjust: exact !important;
                        print-color-adjust: exact !important;
                    }
                    #pdf-render-temp-container * {
                        box-sizing: border-box !important;
                    }
                    #pdf-render-temp-container table {
                        page-break-inside: auto;
                    }
                    #pdf-render-temp-container tr {
                        page-break-inside: avoid;
                        page-break-after: auto;
                    }
                    #pdf-render-temp-container thead {
                        display: table-header-group;
                    }
                    #pdf-render-temp-container tfoot {
                        display: table-footer-group;
                    }
                </style>
                ${styleTags}
                <div style="background:#ffffff; color:#0f172a; width:100%;">
                    ${bodyContent}
                </div>
            `;
            document.body.appendChild(container);

            // Give browser time to layout DOM & compute styles before capture
            await new Promise(r => setTimeout(r, 250));

            const opt = {
                margin: [8, 8, 8, 8],
                filename: filename,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: {
                    scale: 2,
                    useCORS: true,
                    letterRendering: true,
                    backgroundColor: '#ffffff',
                    scrollX: 0,
                    scrollY: 0
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: orientation },
                pagebreak: { mode: ['css', 'legacy'] }
            };

            await new Promise((resolve, reject) => {
                window.html2pdf().set(opt).from(container).toContainer().toCanvas().toImg().toPdf().get('pdf').then(async (pdf) => {
                    try {
                        const dataUri = pdf.output('datauristring');
                        if (window.chrome?.webview && typeof dataUri === 'string' && dataUri.includes(',')) {
                            const base64Data = dataUri.split(',')[1];
                            if (base64Data && base64Data.length > 500) {
                                window.chrome.webview.postMessage(JSON.stringify({
                                    action: 'save_downloaded_file',
                                    filename: filename,
                                    base64: base64Data
                                }));
                                window.showToast?.(`✅ A4 PDF Downloaded successfully to Downloads folder! <button type="button" onclick="window.openDownloadsFolder()" style="margin-left:10px; background:linear-gradient(135deg, #f59e0b, #d97706); color:#fff; border:none; padding:3px 10px; border-radius:6px; font-weight:800; cursor:pointer; font-size:0.75rem; box-shadow:0 2px 6px rgba(0,0,0,0.3);">📁 Open Folder</button>`, "success");
                                resolve();
                                return;
                            }
                        }

                        // Standard browser download fallback
                        pdf.save(filename);
                        window.showToast?.(`✅ A4 PDF Downloaded successfully! <button type="button" onclick="window.openDownloadsFolder()" style="margin-left:10px; background:linear-gradient(135deg, #f59e0b, #d97706); color:#fff; border:none; padding:3px 10px; border-radius:6px; font-weight:800; cursor:pointer; font-size:0.75rem; box-shadow:0 2px 6px rgba(0,0,0,0.3);">📁 Open Folder</button>`, "success");
                        resolve();
                    } catch (e) {
                        reject(e);
                    }
                }).catch(reject);
            });
            return;
        } catch (err) {
            console.warn("html2pdf generation failed, falling back to print dialog:", err);
        } finally {
            if (container && container.parentNode) {
                container.parentNode.removeChild(container);
            }
            // Restore previous scroll position
            window.scrollTo(savedScrollX, savedScrollY);
        }
    }

    // Direct browser print preview with Save as PDF fallback
    const printWindow = window.open('', '_blank', 'width=1100,height=850');
    if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
        }, 500);
    } else {
        window.showToast("⚠️ Pop-up blocked. Please allow pop-ups to print/download PDF.", "warning");
    }
};

// Attendance In/Out punch times are tamper-proof and strictly read-only
window.editEmployeeAttendanceTimes = async () => {
    window.showToast("🔒 Security Restriction: Attendance In/Out punch times cannot be modified manually.", "warning");
};

// --- Exact Attendance Metrics Calculation (to the exact minute) ---
window.calculateExactAttendanceMetrics = (inTimeStr, outTimeStr, inMs = null, outMs = null) => {
    let totalMinutes = 0;
    if (inMs && outMs && outMs > inMs) {
        totalMinutes = Math.max(0, Math.floor((outMs - inMs) / 60000));
    } else if (inTimeStr && outTimeStr && inTimeStr !== '--:--' && outTimeStr !== '--:--') {
        const parseMins = (str) => {
            const parts = str.trim().split(':').map(Number);
            const h = parts[0] || 0;
            const m = parts[1] || 0;
            return h * 60 + m;
        };
        const mIn = parseMins(inTimeStr);
        const mOut = parseMins(outTimeStr);
        totalMinutes = Math.max(0, mOut - mIn);
    }

    if (totalMinutes <= 0) {
        return {
            workedMinutes: 0,
            workedDuration: '--',
            otHours: 0,
            otMinutes: 0,
            otDuration: '0 mins'
        };
    }

    const workedHours = Math.floor(totalMinutes / 60);
    const workedMins = totalMinutes % 60;
    const workedDurationStr = workedHours > 0
        ? `${workedHours} hrs ${workedMins} mins`
        : `${workedMins} mins`;

    // Standard Shift: 8 hours = 480 minutes. OT calculated ONLY when working hours > 8 hours!
    let otMinutes = 0;
    let otHoursDecimal = 0;
    let otDurationStr = '0 mins';

    if (totalMinutes > 480) {
        otMinutes = totalMinutes - 480;
        otHoursDecimal = +(otMinutes / 60).toFixed(2);
        otDurationStr = `${otMinutes} mins`;
    }

    return {
        workedMinutes: totalMinutes,
        workedDuration: workedDurationStr,
        otHours: otHoursDecimal,
        otMinutes: otMinutes,
        otDuration: otDurationStr
    };
};

// --- Attendance Status Override with Password Verification & Remark Audit ---
window.currentAttendanceOverride = null;

window.openAttendanceOverrideModal = (empId, targetStatus = 'Present') => {
    // Permission check: CEO, HR Manager, Admin, Super Admin
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO, HR Manager, Admin, or Super Admin can modify attendance records.", "error");
    }

    const employees = window.allEmployees || [];
    const emp = employees.find(e => e.docId === empId || e.regno === empId);
    if (!emp) {
        return window.showToast("Employee record not found.", "error");
    }

    const filterDateInput = document.getElementById('attendance-date-filter');
    const selectedDate = filterDateInput?.value || new Date().toISOString().split('T')[0];
    const attendance = window.allAttendance || [];
    const existing = attendance.find(a => (a.empId === emp.docId || a.empId === emp.regno) && a.date === selectedDate);
    const currStatus = existing?.status || 'Pending';

    window.currentAttendanceOverride = {
        empId: emp.docId,
        empName: emp.name,
        empRole: emp.role || 'Staff',
        date: selectedDate,
        currentStatus: currStatus,
        targetStatus: targetStatus,
        existingRecord: existing || null
    };

    const nameEl = document.getElementById('att-override-emp-name');
    const dateEl = document.getElementById('att-override-date');
    const currEl = document.getElementById('att-override-curr-status');
    const passInput = document.getElementById('att-override-pass');
    const reasonInput = document.getElementById('att-override-reason');

    if (nameEl) nameEl.innerText = `${emp.name} (${emp.role || 'Staff'})`;
    if (dateEl) dateEl.innerText = selectedDate;
    if (currEl) currEl.innerHTML = `<span style="font-weight:700;">${currStatus}</span>`;
    if (passInput) passInput.value = '';
    if (reasonInput) reasonInput.value = '';

    window.selectOverrideStatus(targetStatus);

    const modal = document.getElementById('attendance-override-modal');
    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => passInput?.focus(), 150);
    }
};

window.selectOverrideStatus = (status) => {
    if (!window.currentAttendanceOverride) return;
    window.currentAttendanceOverride.targetStatus = status;

    const badgeEl = document.getElementById('att-override-new-status-badge');
    const statusBadges = {
        'Present': '<span style="background:rgba(16,185,129,0.2); color:#10b981; padding:3px 8px; border-radius:6px; font-weight:800;">🟢 Full Day</span>',
        'Half Day': '<span style="background:rgba(245,158,11,0.2); color:#f59e0b; padding:3px 8px; border-radius:6px; font-weight:800;">🟡 Half Day</span>',
        'Day Off': '<span style="background:rgba(168,85,247,0.2); color:#a855f7; padding:3px 8px; border-radius:6px; font-weight:800;">🟣 Day Off</span>',
        'Absent': '<span style="background:rgba(239,68,68,0.2); color:#ef4444; padding:3px 8px; border-radius:6px; font-weight:800;">🔴 Absent</span>'
    };
    if (badgeEl) badgeEl.innerHTML = statusBadges[status] || status;

    const btns = {
        'Present': document.getElementById('att-target-present'),
        'Half Day': document.getElementById('att-target-halfday'),
        'Day Off': document.getElementById('att-target-dayoff'),
        'Absent': document.getElementById('att-target-absent')
    };

    Object.keys(btns).forEach(key => {
        const btn = btns[key];
        if (!btn) return;
        if (key === status) {
            btn.style.opacity = '1';
            btn.style.transform = 'scale(1.03)';
            btn.style.boxShadow = '0 0 10px rgba(245, 158, 11, 0.4)';
        } else {
            btn.style.opacity = '0.55';
            btn.style.transform = 'scale(1)';
            btn.style.boxShadow = 'none';
        }
    });
};

window.closeAttendanceOverrideModal = () => {
    const modal = document.getElementById('attendance-override-modal');
    if (modal) modal.style.display = 'none';
    window.currentAttendanceOverride = null;
};

window.submitAttendanceStatusOverride = async () => {
    const ctx = window.currentAttendanceOverride;
    if (!ctx) return;

    const passInput = document.getElementById('att-override-pass');
    const reasonInput = document.getElementById('att-override-reason');
    const enteredPass = (passInput?.value || '').trim();
    const enteredReason = (reasonInput?.value || '').trim();

    if (!enteredPass) {
        passInput?.focus();
        return window.showToast("🔑 Please enter your HR Manager / CEO / Admin password or PIN.", "warning");
    }

    if (!enteredReason) {
        reasonInput?.focus();
        return window.showToast("📝 Please provide a reason / remark for modifying the attendance status.", "warning");
    }

    const submitBtn = document.getElementById('att-override-submit-btn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span>⏳</span> Verifying...`;
    }

    try {
        // --- Credential & Role Verification ---
        let authorizerName = null;
        let authorizerRole = null;

        // 1. Master / Super Admin credentials
        if (enteredPass === 'malindu123' || enteredPass === 'mecpos123') {
            authorizerName = 'Malindu Shamesh';
            authorizerRole = 'Super Admin';
        }
        // 2. MEC CEO credentials
        else if (enteredPass === 'mec123') {
            authorizerName = 'CEO / Founder';
            authorizerRole = 'CEO';
        }
        // 3. Match against employees database
        else {
            const employees = window.allEmployees || [];
            const matchedStaff = employees.find(e => {
                const pin = (e.pin || '').toString().trim();
                const pass = (e.password || '').toString().trim();
                return (pin && pin === enteredPass) || (pass && pass === enteredPass);
            });

            if (matchedStaff) {
                const r = (matchedStaff.role || '').toLowerCase();
                const des = (matchedStaff.designation || '').toLowerCase();
                const acc = (matchedStaff.role_access || '').toLowerCase();

                const isCeo = r.includes('ceo') || des.includes('ceo') || r.includes('founder') || des.includes('founder') || r.includes('owner') || des.includes('owner') || r.includes('proprietor') || des.includes('proprietor');
                const isHr = r.includes('hr') || des.includes('hr') || r.includes('human resource') || des.includes('human resource') || acc.includes('hr');
                const isAdmin = r.includes('admin') || des.includes('admin') || acc.includes('admin');

                if (isCeo || isHr || isAdmin) {
                    authorizerName = matchedStaff.name || matchedStaff.fullName || 'Authorized Staff';
                    authorizerRole = isCeo ? 'CEO' : (isHr ? 'HR Manager' : (matchedStaff.role || 'Admin'));
                } else {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = `<span>🛡️</span> Verify & Update Status`;
                    }
                    return window.showToast(`🔒 Permission Denied: Staff "${matchedStaff.name}" (${matchedStaff.role}) is not authorized to override attendance. Only HR Manager, CEO, or Admin can make changes.`, "error");
                }
            }
        }

        // If still unverified, check active merchant store owner credentials
        if (!authorizerName && window.storeInfo) {
            const storeOwnerPass = window.storeInfo.adminPassword || window.storeInfo.password;
            if (storeOwnerPass && storeOwnerPass.trim() === enteredPass) {
                authorizerName = window.storeInfo.ownerName || window.storeInfo.name || 'Store Owner';
                authorizerRole = 'CEO / Owner';
            }
        }

        if (!authorizerName) {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = `<span>🛡️</span> Verify & Update Status`;
            }
            return window.showToast("❌ Authentication Failed: Invalid Password or PIN. Authorization requires CEO, HR Manager, or Admin credentials.", "error");
        }

        // --- Save Updated Attendance Record ---
        const nowTime = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
        const existing = ctx.existingRecord;
        const remarkText = `Edited by ${authorizerName} (${authorizerRole}): ${enteredReason}`;

        const inTimeVal = existing?.inTime || existing?.time || nowTime;
        const outTimeVal = existing?.outTime || '--:--';

        // Calculate worked time & OT metrics down to the exact minute
        const metrics = window.calculateExactAttendanceMetrics(
            inTimeVal,
            outTimeVal,
            existing?.inTimestamp || existing?.timestamp,
            existing?.outTimestamp
        );

        let workedDuration = existing?.workedDuration || (metrics.workedMinutes > 0 ? metrics.workedDuration : '--');
        let workedMinutes = existing?.workedMinutes || metrics.workedMinutes || 0;
        let otHours = existing?.otHours || 0;
        let otMinutes = existing?.otMinutes || 0;
        let otDuration = existing?.otDuration || '0 mins';

        if (ctx.targetStatus === 'Present') {
            // Full Day: recalculate OT down to the minute if worked > 8 hours (480 mins)
            if (metrics.workedMinutes > 0) {
                workedDuration = metrics.workedDuration;
                workedMinutes = metrics.workedMinutes;
                otHours = metrics.otHours;
                otMinutes = metrics.otMinutes;
                otDuration = metrics.otDuration;
            }
        } else if (ctx.targetStatus === 'Half Day') {
            if (metrics.workedMinutes > 0) {
                workedDuration = metrics.workedDuration;
                workedMinutes = metrics.workedMinutes;
            }
            otHours = 0;
            otMinutes = 0;
            otDuration = '0 mins';
        } else if (ctx.targetStatus === 'Day Off' || ctx.targetStatus === 'Absent') {
            otHours = 0;
            otMinutes = 0;
            otDuration = '0 mins';
        }

        const payload = {
            empId: ctx.empId,
            empName: ctx.empName,
            date: ctx.date,
            status: ctx.targetStatus,
            storeId: window.getStoreId(),
            time: existing?.time || nowTime,
            inTime: inTimeVal,
            outTime: outTimeVal,
            workedDuration: workedDuration,
            workedMinutes: workedMinutes,
            otHours: otHours,
            otMinutes: otMinutes,
            otDuration: otDuration,
            editedBy: authorizerName,
            editedRole: authorizerRole,
            editReason: enteredReason,
            editRemark: remarkText,
            editedAt: serverTimestamp(),
            timestamp: existing?.timestamp || serverTimestamp()
        };

        if (existing?.docId) {
            await updateDoc(doc(db, 'attendance', existing.docId), payload);
        } else {
            await addDoc(attendanceCol, payload);
        }

        // Audit log in systemLogs
        try {
            await addDoc(collection(db, 'systemLogs'), {
                action: 'Attendance Status Override',
                user: authorizerName,
                role: authorizerRole,
                storeId: window.getStoreId(),
                details: `Changed attendance status for ${ctx.empName} from "${ctx.currentStatus}" to "${ctx.targetStatus}" on ${ctx.date}. Reason: ${enteredReason}`,
                timestamp: serverTimestamp()
            });
        } catch (logErr) {
            console.warn("Audit log notice:", logErr);
        }

        window.closeAttendanceOverrideModal();
        window.showToast(`✅ Status updated to "${ctx.targetStatus}" by ${authorizerName} (${authorizerRole})`, "success");
        syncAttendanceUI();

    } catch (err) {
        console.error("Attendance override error:", err);
        window.showToast("Failed to update status: " + err.message, "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<span>🛡️</span> Verify & Update Status`;
        }
    }
};

window.markAttendance = (empId, status) => {
    window.openAttendanceOverrideModal(empId, status);
};

function renderAdminPayrollUI(payroll) {
    const listDiv = document.getElementById('admin-payroll-list');
    if (!listDiv) return;
    
    const query = (document.getElementById('payroll-history-search')?.value || '').toLowerCase().trim();
    const filtered = query ? payroll.filter(p => (p.empName || '').toLowerCase().includes(query) || (p.month || '').includes(query) || (p.empRegNo || '').toLowerCase().includes(query)) : payroll;

    if (filtered.length === 0) {
        listDiv.innerHTML = `<div style="text-align:center; padding: 2.5rem; color:#64748b;">No committed payroll records found.</div>`;
        return;
    }

    listDiv.innerHTML = filtered.map(p => {
        const netAmt = parseFloat(p.netSalary || p.amount || 0);
        const epf8 = parseFloat(p.employeeEpf8 || 0);
        const epf12 = parseFloat(p.employerEpf12 || 0);
        const etf3 = parseFloat(p.employerEtf3 || 0);
        const dateStr = p.timestamp?.seconds ? new Date(p.timestamp.seconds * 1000).toLocaleDateString() : '';

        return `
            <div style="padding: 12px 16px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                <div>
                    <div style="font-weight: 800; color: #f8fafc; font-size: 0.95rem;">${p.empName || 'Staff'} ${p.empRegNo ? `<span style="font-size:0.75rem; color:#94a3b8; font-weight:normal;">(${p.empRegNo})</span>` : ''}</div>
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">
                        <span style="color: #38bdf8; font-weight: 700;">📅 ${p.month}</span>
                        ${dateStr ? `<span> • Committed: ${dateStr}</span>` : ''}
                        ${p.status ? `<span> • <span style="color:#10b981; font-weight:700;">${p.status}</span></span>` : ''}
                    </div>
                    <div style="display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap;">
                        ${epf8 > 0 ? `<span style="font-size: 0.65rem; background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); padding: 1px 6px; border-radius: 4px; font-weight: 700;">EPF 8%: -LKR ${epf8.toFixed(2)}</span>` : ''}
                        ${(epf12 + etf3) > 0 ? `<span style="font-size: 0.65rem; background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); padding: 1px 6px; border-radius: 4px; font-weight: 700;">Employer 15%: +LKR ${(epf12 + etf3).toFixed(2)}</span>` : ''}
                        ${p.allowanceProtected ? `<span style="font-size: 0.65rem; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 1px 6px; border-radius: 4px; font-weight: 800;">🛡️ MC Protected</span>` : ''}
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="text-align: right;">
                        <div style="font-weight: 900; color: #38bdf8; font-size: 1.1rem;">LKR ${netAmt.toFixed(2)}</div>
                        <div style="font-size: 0.68rem; color: #64748b;">Net Take-Home</div>
                    </div>
                    <div style="display:flex; gap:4px;">
                        <button onclick="window.viewEmployeePayslip('${p.empId || p.docId}', '${p.month}')" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 5px 9px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;" title="View / Print Official Payslip">🖨️ Slip</button>
                        <button onclick="window.downloadPaysheet('${p.docId}')" class="action-btn" style="background: rgba(255, 255, 255, 0.05); color: #cbd5e1; border: 1px solid rgba(255, 255, 255, 0.1); padding: 5px 8px; border-radius: 8px; font-size: 0.75rem; cursor: pointer;" title="Download Text Paysheet">📥</button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

window.filterPayrollHistoryUI = () => {
    if (window.allPayroll) {
        renderAdminPayrollUI(window.allPayroll);
    }
};

window.downloadPaysheet = (pId) => {
    const p = (window.allPayroll || []).find(x => x.docId === pId);
    if (!p) return;

    let content = `------------------------------------------\n`;
    content += `        MEC BOOK SHOP - PAY SHEET       \n`;
    content += `------------------------------------------\n`;
    content += `Employee: ${p.empName} (${p.empRegNo || p.empId || ''})\n`;
    content += `Month:    ${p.month}\n`;
    content += `Amount:   LKR ${parseFloat(p.netSalary || p.amount || 0).toFixed(2)}\n`;
    if (p.employeeEpf8) content += `EPF 8%:   -LKR ${parseFloat(p.employeeEpf8).toFixed(2)}\n`;
    if (p.employerEpf12) content += `EPF 12%:  +LKR ${parseFloat(p.employerEpf12).toFixed(2)} (Employer)\n`;
    if (p.employerEtf3) content += `ETF 3%:   +LKR ${parseFloat(p.employerEtf3).toFixed(2)} (Employer)\n`;
    content += `Note:     ${p.note || '-'}\n`;
    content += `Date:     ${new Date(p.timestamp?.seconds * 1000).toLocaleDateString()}\n`;
    content += `------------------------------------------\n`;
    content += `Generated by MEC POS Zenith Compliance Engine\n`;

    downloadFile(content, `paysheet_${(p.empName || 'staff').replace(/\s+/g, '_')}_${p.month}.txt`);
};

// ==========================================
// UNIFIED MESSAGING ENGINE (SMSLENZ + WHATSAPP API)
// ==========================================

window.normalizePhone = (phone) => {
    if (!phone) return { raw: '', formatted: '', withPlus: '', isValid: false };
    let cleaned = String(phone).replace(/\D/g, '');
    if (cleaned.startsWith('0')) {
        cleaned = '94' + cleaned.substring(1);
    } else if (!cleaned.startsWith('94') && cleaned.length === 9) {
        cleaned = '94' + cleaned;
    }
    const isValid = cleaned.length === 11 && cleaned.startsWith('947');
    return {
        raw: String(phone).trim(),
        formatted: cleaned,
        withPlus: '+' + cleaned,
        isValid: isValid || (cleaned.length >= 10)
    };
};

window.dispatchSMS = async (phone, message, options = {}) => {
    const norm = window.normalizePhone(phone);
    if (!norm.formatted || norm.formatted.length < 10) {
        if (!options.silent) window.showToast("Invalid phone number for SMS. (Requires e.g. 07XXXXXXXX)", "warning");
        return { success: false, error: "Invalid phone number" };
    }

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';

    const smsConf = window.systemConfig?.smsConfig || {};
    let apiBase = (smsConf.apiBase?.trim() || (isMec ? "https://smslenz.lk/api/send-sms" : ""));
    if (apiBase && !apiBase.includes("send-sms")) {
        apiBase = "https://smslenz.lk/api/send-sms";
    }
    const apiKey = (smsConf.apiKey?.trim() || (isMec ? "40b621ec-69ba-48c4-869b-cf30f3f58791" : ""));
    const userId = (smsConf.userId?.trim() || (isMec ? "981" : ""));
    const senderId = (smsConf.senderId?.trim() || (isMec ? "MECBookShop" : ""));

    if (!apiKey || !userId) {
        if (!options.silent) window.showToast("⚠️ SMS Gateway not configured in Settings.", "warning");
        return { success: false, error: "SMS Gateway credentials missing" };
    }

    try {
        const contactNumber = norm.withPlus || ('+' + norm.formatted);
        const url = new URL(apiBase);
        url.searchParams.set("user_id", userId);
        url.searchParams.set("api_key", apiKey);
        url.searchParams.set("sender_id", senderId);
        url.searchParams.set("contact", contactNumber);
        url.searchParams.set("message", message);

        let data = null;
        let dispatched = false;

        // Pipeline 0: Native C# wrapper bridge (Desktop App — 100% bypass of WebView2 sandbox/CORS)
        if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage(JSON.stringify({
                    type: "send-sms",
                    user_id: userId,
                    api_key: apiKey,
                    sender_id: senderId,
                    contact: contactNumber,
                    message: message
                }));
                dispatched = true;
                console.log("[SMSLenz] Dispatched via C# Native Bridge");
            } catch (nativeErr) {
                console.warn("[SMSLenz] Native C# bridge failed, falling back to web:", nativeErr);
            }
        }

        // Pipeline 1: Standard fetch (supports reading JSON response)
        try {
            const resp = await fetch(url.toString(), { method: 'GET' });
            data = await resp.json().catch(() => null);
            if (resp.ok && data && (data.success || data.status === 'success')) {
                dispatched = true;
            }
        } catch (fetchErr) {
            console.warn("[SMSLenz] Pipeline 1 (fetch) note:", fetchErr.message);
        }

        // Pipeline 2: No-CORS fetch fallback (guarantees GET request reaches server even if CORS blocked)
        if (!dispatched) {
            try {
                await fetch(url.toString(), { method: 'GET', mode: 'no-cors' });
                dispatched = true;
                data = { success: true, message: "Dispatched via gateway" };
            } catch (noCorsErr) {
                console.warn("[SMSLenz] Pipeline 2 (no-cors) note:", noCorsErr.message);
            }
        }

        // Pipeline 3: Image beacon fallback (pure browser GET ping, bypasses any fetch sandbox restrictions)
        if (!dispatched) {
            try {
                const img = new Image();
                img.src = url.toString();
                dispatched = true;
                data = { success: true, message: "Dispatched via beacon" };
            } catch (beaconErr) {
                console.error("[SMSLenz] Pipeline 3 (beacon) failed:", beaconErr);
            }
        }

        if (dispatched) {
            console.log(`[SMSLenz] Successfully dispatched SMS to ${norm.formatted} via [${senderId}]`);
            if (!options.silent) {
                window.showToast(`✉️ SMS sent via SMSLenz [${senderId}] to ${norm.formatted}!`, "success");
            }
        } else {
            console.error("[SMSLenz] Gateway dispatch failed on all pipelines:", data);
            if (!options.silent) {
                window.showToast(`⚠️ SMS Gateway: ${data?.message || "Failed to send SMS"}`, "error");
            }
            return { success: false, error: data?.message };
        }

        // Log to Firestore ai_copilot_logs if available
        try {
            if (typeof addDoc === 'function' && typeof collection === 'function' && typeof db !== 'undefined') {
                await addDoc(collection(db, 'ai_copilot_logs'), {
                    type: 'SMS',
                    title: `SMS Sent [${senderId}]`,
                    description: `SMS dispatched to ${norm.formatted}. Message: "${message.substring(0, 100)}${message.length > 100 ? '...' : ''}"`,
                    phone: norm.formatted,
                    storeId: typeof window.getStoreId === 'function' ? window.getStoreId() : 'master',
                    timestamp: serverTimestamp()
                });
            }
        } catch (logErr) {
            console.warn("SMS log warn:", logErr);
        }

        return { success: true, senderId, contact: norm.formatted, data };
    } catch (error) {
        console.error("SMS Dispatch Error:", error);
        if (!options.silent) window.showToast("Failed to dispatch SMS via SMSLenz.", "error");
        return { success: false, error };
    }
};

window.dispatchWhatsApp = async (phone, message, options = {}) => {
    const norm = window.normalizePhone(phone);
    if (!norm.formatted || norm.formatted.length < 10) {
        if (!options.silent) window.showToast("Customer phone required for WhatsApp.", "warning");
        return { success: false, error: "Invalid phone number" };
    }

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';

    const metaConf = window.systemConfig?.metaWhatsappConfig || {};
    let phoneNumberId = metaConf.phoneNumberId?.trim() || (isMec ? "1458508587349126" : "");
    if (isMec && (!phoneNumberId || phoneNumberId === "61595312696922" || phoneNumberId === "1299065503300070")) {
        phoneNumberId = "1458508587349126";
    }
    let accessToken = metaConf.accessToken?.trim() || (isMec ? "EAAaRKVpmPacBS9WVgvFzcoJdiCkvzTI0xEf7gAYbQzwmJFhvd3ufDPUtrdouPdNZA3gZCsEkPRhDfIJlMXcjQRmWZC3ZBt3slSuZBq6xSk8t8OcZCFoZAvXfYmgKe9zdi91ngAm4WbhfFdDuYTZA2RR6OHgnH5Vmq2UZAnrJVyIOnVVqC0GazulveFZCkPwBJr8YLNLAZDZD" : "");
    if (isMec && (!accessToken || !accessToken.startsWith("EAAaRKVpmPac"))) {
        accessToken = "EAAaRKVpmPacBS9WVgvFzcoJdiCkvzTI0xEf7gAYbQzwmJFhvd3ufDPUtrdouPdNZA3gZCsEkPRhDfIJlMXcjQRmWZC3ZBt3slSuZBq6xSk8t8OcZCFoZAvXfYmgKe9zdi91ngAm4WbhfFdDuYTZA2RR6OHgnH5Vmq2UZAnrJVyIOnVVqC0GazulveFZCkPwBJr8YLNLAZDZD";
    }

    // Universal WhatsApp Link (opens WhatsApp Desktop App on Windows or WhatsApp Web)
    const encoded = encodeURIComponent(message);
    const targetUrl = `https://wa.me/${norm.formatted}?text=${encoded}`;

    // 1. Send strictly via Meta WhatsApp Cloud API directly
    let metaDispatched = false;
    let metaError = null;

    if (!options.forceWeb) {
        try {
            let requestBody;
            if (options.template) {
                requestBody = {
                    messaging_product: "whatsapp",
                    recipient_type: "individual",
                    to: norm.formatted,
                    type: "template",
                    template: options.template
                };
            } else {
                requestBody = {
                    messaging_product: "whatsapp",
                    recipient_type: "individual",
                    to: norm.formatted,
                    type: "text",
                    text: { preview_url: false, body: message }
                };
            }

            const resp = await fetch(`https://graph.facebook.com/v22.0/${phoneNumberId}/messages`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });
            const data = await resp.json().catch(() => null);
            if (resp.ok && data?.messages && data.messages.length > 0) {
                console.log("✅ Dispatched directly via Meta WhatsApp API:", data);
                metaDispatched = true;
                // Check if contact was valid (detect test mode delivery issues)
                const contactStatus = data?.contacts?.[0]?.wa_id;
                if (!contactStatus) {
                    console.warn("⚠️ Meta API: Contact wa_id missing — may be test mode or invalid number:", data);
                }
            } else {
                metaError = data?.error?.message || "Meta API Error";
                console.warn("Meta WhatsApp API response:", data);
            }
        } catch (e) {
            metaError = e.message;
            console.warn("Meta WhatsApp fetch failed:", e);
        }
    }

    // 2. Direct API Dispatch Success
    if (metaDispatched) {
        if (!options.silent) {
            window.showToast("✅ Sent directly via WhatsApp Cloud API!", "success");
        }
        return { success: true, metaDispatched: true, type: 'meta_api' };
    }

    // 3. Handle Meta API Error Without Opening Browser or Desktop App
    console.error("WhatsApp API Error:", metaError);
    if (!options.silent) {
        if (metaError && metaError.includes("not in allowed list")) {
            window.showToast(`⚠️ Meta App Development Mode: Phone ${norm.formatted} not in test list. Switch App to Live Mode to send to everyone!`, "error");
        } else if (metaError && metaError.includes("24 hours")) {
            window.showToast(`⚠️ WhatsApp: 24h conversation window closed for ${norm.formatted}.`, "warning");
        } else {
            window.showToast(`⚠️ WhatsApp API Error: ${metaError || 'Failed to dispatch'}`, "error");
        }
    }

    // 4. ONLY open WhatsApp Web / Desktop if user EXPLICITLY requested forceWeb: true
    if (options.forceWeb === true) {
        if (typeof window.openExternalUrl === 'function') {
            window.openExternalUrl(targetUrl);
        } else if (window.electronAPI?.openExternal) {
            window.electronAPI.openExternal(targetUrl);
        } else if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage(JSON.stringify({ type: 'openExternalUrl', action: 'openExternalUrl', url: targetUrl }));
            } catch (e) {
                window.open(targetUrl, '_blank');
            }
        } else {
            window.open(targetUrl, '_blank');
        }
        return { success: true, metaDispatched: false, targetUrl, type: 'web_direct' };
    }

    return { success: false, error: metaError, metaDispatched: false };
};

window.sendCustomerDirectSMS = async (customerId) => {
    const cust = (window.allCustomers || []).find(c => c.docId === customerId);
    if (!cust) return window.showToast("Customer not found.", "warning");
    if (!cust.phone) return window.showToast("Customer has no phone number on file.", "warning");

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const debt = parseFloat(cust.creditBalance || cust.outstanding || 0);
    const pts = cust.loyaltyPoints || 0;
    
    let defaultMsg = `Dear ${cust.name}, Thank you for being a valued customer of ${bizName}!`;
    if (debt > 0) {
        defaultMsg = `Dear ${cust.name}, kindly note your outstanding account balance at ${bizName} is LKR ${debt.toFixed(2)}. Thank you for your continued support!`;
    } else if (pts > 0) {
        defaultMsg = `Dear ${cust.name}, you have ${pts} loyalty points accumulated at ${bizName}. Visit us soon to redeem!`;
    }

    const msg = await window.asyncPrompt(`Enter SMS text for ${cust.name} (${cust.phone}):`, "Send Customer SMS (SMSLenz)", "text", defaultMsg);
    if (!msg) return;

    await window.dispatchSMS(cust.phone, msg);
};

window.sendCustomerDirectWhatsApp = async (customerId) => {
    const cust = (window.allCustomers || []).find(c => c.docId === customerId);
    if (!cust) return window.showToast("Customer not found.", "warning");
    if (!cust.phone) return window.showToast("Customer has no phone number on file.", "warning");

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const debt = parseFloat(cust.creditBalance || cust.outstanding || 0);
    const pts = cust.loyaltyPoints || 0;
    
    let defaultMsg = `*Greetings from ${bizName}!* 📚✨\n\nDear *${cust.name}*,\nThank you for choosing ${bizName}. We are always pleased to serve you!\n\n${debt > 0 ? `*Outstanding Balance:* LKR ${debt.toFixed(2)}\nKindly settle at your earliest convenience.\n\n` : ''}${pts > 0 ? `*Loyalty Points Balance:* ${pts} points\n\n` : ''}For inquiries, contact: ${window.systemConfig?.invPhone || '071 923 3388'}`;

    const msg = await window.asyncPrompt(`Review or edit WhatsApp message for ${cust.name}:`, "Send WhatsApp Message", "text", defaultMsg);
    if (!msg) return;

    await window.dispatchWhatsApp(cust.phone, msg);
};

window.sendEmployeeSMS = async (phone, name, pin, username, password, role, isTemporary = false) => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can dispatch employee login SMS.", "error");
    }
    if (!phone) return window.showToast("No phone number found!", "warning");
    
    const norm = window.normalizePhone(phone);
    if (!norm.isValid && norm.formatted.length < 10) {
        return window.showToast("Invalid phone number format for SMS. Expected Sri Lankan mobile number (e.g. 07XXXXXXXX).", "error");
    }

    const portalUrl = 'https://mecbookshop.com.lk/staff';
    const bizName = window.systemConfig?.bizName || 'MEC BOOK SHOP';
    const staffName = name || 'Employee';
    const staffPin = pin || '';
    
    const directLoginUrl = `https://mecbookshop.com.lk/staff?phone=${encodeURIComponent(norm.formatted)}&pin=${encodeURIComponent(staffPin)}`;
    const appDownloadUrl = `https://github.com/malinduec99/mec-pos-releases/releases/download/v3.38.17/mec-employee-attendance.apk`;
    
    let defaultMsg = `${bizName.toUpperCase()} - STAFF PORTAL\n\n` +
                     `Hello ${staffName},\n` +
                     `Welcome to ${bizName}!\n\n` +
                     `📱 Direct Login Link:\n${directLoginUrl}\n\n` +
                     `📲 Download Staff Attendance App:\n${appDownloadUrl}\n\n` +
                     `🔑 YOUR LOGIN CREDENTIALS:\n` +
                     `• Mobile: ${norm.raw || phone}\n` +
                     (staffPin ? `• Security PIN: ${staffPin} ${isTemporary ? '(Temporary - 1-Time Use)' : ''}\n` : '') +
                     (password ? `• Password: ${password}\n` : '') +
                     (username ? `• Username: ${username}\n` : '') +
                     (role && role !== 'none' ? `• Access Role: ${role}\n` : '') +
                     `\n👉 Click the direct link to sign in or download the Staff Attendance App!`;

    const msg = await window.asyncPrompt(`Enter SMS message for ${staffName} (${norm.formatted}) via SMSLenz:`, `SMS Dispatch (SMSLenz)`, "textarea", defaultMsg);
    if (!msg) return;

    await window.dispatchSMS(norm.formatted, msg);
};

window.sendDirectSMS = async (phone, msg) => {
    if (!phone || !msg) return;
    await window.dispatchSMS(phone, msg, { silent: true });
};

window.recordEmployeeLeave = async (empId, name) => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can record staff leave.", "error");
    }
    const reason = await window.asyncPrompt(`Record Leave for ${name}. Enter reason/type (e.g. Sick Leave, Annual):`, "Leave Registration", "text");
    if (reason === null) return;

    const date = await window.asyncPrompt(`Enter Date (YYYY-MM-DD):`, "Leave Date", "text", new Date().toISOString().split('T')[0]);
    if (!date) return;

    try {
        await addDoc(collection(db, 'attendance'), {
            empId,
            date,
            status: 'On Leave',
            note: reason,
            time: '--:--',
            storeId: window.getStoreId(),
            timestamp: serverTimestamp()
        });
        window.showToast(`✅ Leave recorded for ${name}`, "success");
        if (typeof syncAttendanceUI === 'function') syncAttendanceUI();

        // Dispatch Leave Notification SMS to Employee
        try {
            const emp = (window.allEmployees || []).find(e => e.docId === empId);
            if (emp && emp.phone) {
                const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
                const leaveMsg = `Hello ${name}, your leave for ${date} (${reason}) has been recorded at ${bizName}.`;
                window.dispatchSMS(emp.phone, leaveMsg, { silent: true });
            }
        } catch (e) {
            console.warn("Leave SMS notice error:", e);
        }
    } catch (err) {
        console.error(err);
        window.showToast("Failed to record leave.", "error");
    }
};

function populatePayrollStaffDropdown(employees) {
    const list = employees || window.allEmployees || [];
    const paySelect = document.getElementById('pay-emp-id');
    const posSelect = document.getElementById('pos-cashier-id');
    const filtered = window.filterByStore(list);

    const options = '<option value="">Select Employee</option>' + filtered.map(e => `<option value="${e.docId}">${e.name} (${e.role || 'Staff'})</option>`).join('');

    if (paySelect) paySelect.innerHTML = options;
    if (posSelect) posSelect.innerHTML = options;
}
window.populatePayrollStaffDropdown = populatePayrollStaffDropdown;

// ─── Sri Lanka Statutory Payroll Compliance Controller ────────────────────────
window.activeBatchPayrollRecords = [];

window.onPayrollMonthChanged = () => {
    const monthStr = document.getElementById('payroll-batch-month')?.value;
    if (monthStr) {
        window.runSriLankaBatchPreview(monthStr);
    }
};

window.calculateStaffPayroll = () => {
    const empId = document.getElementById('pay-emp-id')?.value;
    const monthStr = document.getElementById('pay-month')?.value; // YYYY-MM
    const infoBox = document.getElementById('payroll-calc-info');
    const amountInput = document.getElementById('pay-amount');

    if (!empId || !monthStr) {
        if (infoBox) infoBox.style.display = 'none';
        return;
    }

    const emp = (window.allEmployees || []).find(e => e.docId === empId);
    if (!emp) return;

    const calc = calculateSriLankaPayrollForEmployee({
        emp,
        monthStr,
        allOrders: window.allOrders || [],
        allLeaveRequests: window.allLeaveRequests || [],
        advanceDeductions: 0
    });

    const allowanceRow = document.getElementById('calc-attendance-allowance-row');
    const allowanceLabel = document.getElementById('calc-allowance-label');
    const allowanceVal = document.getElementById('calc-attendance-allowance');

    if (emp.attendanceAllowance || emp.allowance) {
        if (allowanceRow) allowanceRow.style.display = 'flex';
        if (allowanceLabel) {
            allowanceLabel.innerHTML = calc.allowanceProtected 
                ? `🛡️ Allowance (Medical Protected):` 
                : (calc.payableAttendanceAllowance > 0 ? `Attendance Allowance:` : `⚠️ Allowance (Forfeited):`);
        }
        if (allowanceVal) {
            allowanceVal.innerText = calc.payableAttendanceAllowance > 0 
                ? `+ LKR ${calc.payableAttendanceAllowance.toFixed(2)}` 
                : `LKR 0.00`;
            allowanceVal.style.color = calc.payableAttendanceAllowance > 0 ? '#10b981' : '#ef4444';
        }
    } else if (allowanceRow) {
        allowanceRow.style.display = 'none';
    }

    const baseEl = document.getElementById('calc-base-salary');
    if (baseEl) baseEl.innerText = `LKR ${calc.epfBase.toFixed(2)}`;
    
    const salesEl = document.getElementById('calc-monthly-sales');
    if (salesEl) salesEl.innerText = `LKR ${calc.totalSales.toFixed(2)}`;

    const commEl = document.getElementById('calc-commission');
    if (commEl) commEl.innerText = `LKR ${calc.commissionEarned.toFixed(2)} (${calc.commissionPct}%)`;

    const epfEl = document.getElementById('calc-epf-deduction');
    if (epfEl) epfEl.innerText = `- LKR ${calc.employeeEpf8.toFixed(2)}`;

    const totalEl = document.getElementById('calc-total-payable');
    if (totalEl) totalEl.innerText = `LKR ${calc.netSalary.toFixed(2)}`;

    if (amountInput) amountInput.value = calc.netSalary.toFixed(2);
    if (infoBox) infoBox.style.display = 'block';
};

window.runSriLankaBatchPreview = (monthStr) => {
    if (!monthStr) {
        monthStr = document.getElementById('payroll-batch-month')?.value;
    }
    if (!monthStr) {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        monthStr = `${y}-${m}`;
        const input = document.getElementById('payroll-batch-month');
        if (input) input.value = monthStr;
    }

    const employees = (window.allEmployees || []).filter(e => e.status !== 'Terminated' && e.status !== 'Inactive');
    if (employees.length === 0) {
        const tbody = document.getElementById('payroll-batch-table-body');
        if (tbody) tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding: 2.5rem; opacity: 0.5;">No active staff records found.</td></tr>`;
        return;
    }

    const records = employees.map(emp => {
        return calculateSriLankaPayrollForEmployee({
            emp,
            monthStr,
            allOrders: window.allOrders || [],
            allLeaveRequests: window.allLeaveRequests || [],
            advanceDeductions: 0
        });
    });

    window.activeBatchPayrollRecords = records;

    // Aggregate statistics
    let totalGross = 0;
    let totalEpfBase = 0;
    let totalEmp8 = 0;
    let totalEmpl12 = 0;
    let totalEtf3 = 0;
    let totalApit = 0;
    let totalNet = 0;
    let totalCost = 0;

    records.forEach(r => {
        totalGross += r.grossEarnings;
        totalEpfBase += r.epfBase;
        totalEmp8 += r.employeeEpf8;
        totalEmpl12 += r.employerEpf12;
        totalEtf3 += r.employerEtf3;
        totalApit += r.apitTax;
        totalNet += r.netSalary;
        totalCost += r.totalCompanyCost;
    });

    // Update 4 stat cards
    const grossEl = document.getElementById('payroll-stat-gross');
    if (grossEl) grossEl.innerText = `LKR ${totalGross.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    const epfEl = document.getElementById('payroll-stat-epf');
    if (epfEl) epfEl.innerText = `LKR ${(totalEmp8 + totalEmpl12).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const epfSubEl = document.getElementById('payroll-stat-epf-sub');
    if (epfSubEl) epfSubEl.innerText = `8% Emp (LKR ${totalEmp8.toFixed(2)}) + 12% Emplr (LKR ${totalEmpl12.toFixed(2)})`;

    const etfEl = document.getElementById('payroll-stat-etf');
    if (etfEl) etfEl.innerText = `LKR ${totalEtf3.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    const netEl = document.getElementById('payroll-stat-net');
    if (netEl) netEl.innerText = `LKR ${totalNet.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const costEl = document.getElementById('payroll-stat-cost');
    if (costEl) costEl.innerText = `Total Employer Cost: LKR ${totalCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    // Render Preview Table
    const tbody = document.getElementById('payroll-batch-table-body');
    if (tbody) {
        tbody.innerHTML = records.map((r, idx) => {
            const alreadyCommitted = (window.allPayroll || []).some(p => (p.empId === r.empId || p.empId === r.empRegNo) && p.month === monthStr);

            let allowanceBadge = `<span style="color:#64748b; font-size:0.75rem;">None</span>`;
            if (r.monthlyAttendanceAllowance > 0) {
                if (r.allowanceProtected) {
                    allowanceBadge = `
                        <div>
                            <span style="font-weight:700; color:#10b981;">+${r.payableAttendanceAllowance.toFixed(2)}</span>
                            <div style="font-size:0.65rem; color:#34d399; font-weight:800; display:flex; align-items:center; gap:3px;">
                                <span>🛡️</span> Protected (MC)
                            </div>
                        </div>
                    `;
                } else if (r.payableAttendanceAllowance > 0) {
                    allowanceBadge = `<span style="font-weight:700; color:#10b981;">+${r.payableAttendanceAllowance.toFixed(2)}</span>`;
                } else {
                    allowanceBadge = `
                        <div>
                            <span style="font-weight:700; color:#ef4444; text-decoration:line-through;">0.00</span>
                            <div style="font-size:0.65rem; color:#f87171;">⚠️ Forfeited</div>
                        </div>
                    `;
                }
            }

            return `
                <tr style="${alreadyCommitted ? 'background: rgba(16, 185, 129, 0.05);' : ''}">
                    <td>
                        <div style="font-weight: 800; color: #f8fafc;">${r.empName}</div>
                        <div style="font-size: 0.7rem; color: #94a3b8; display:flex; gap:6px;">
                            <span>${r.empRegNo}</span>
                            <span>•</span>
                            <span>${r.empRole}</span>
                            ${r.epfNumber ? `<span>• EPF: ${r.epfNumber}</span>` : ''}
                        </div>
                    </td>
                    <td style="font-weight: 700; color: #cbd5e1;">LKR ${r.epfBase.toFixed(2)}</td>
                    <td>
                        ${r.commissionEarned > 0 ? `<div style="font-weight:700; color:#38bdf8;">+${r.commissionEarned.toFixed(2)}</div><div style="font-size:0.65rem; color:#64748b;">${r.commissionPct}% of Sales</div>` : '<span style="color:#64748b; font-size:0.75rem;">0.00</span>'}
                    </td>
                    <td>${allowanceBadge}</td>
                    <td style="font-weight: 800; color: #f8fafc;">LKR ${r.grossEarnings.toFixed(2)}</td>
                    <td style="color: #ef4444; font-weight: 700;">-${r.employeeEpf8.toFixed(2)}</td>
                    <td style="color: ${r.apitTax > 0 ? '#ef4444' : '#64748b'}; font-weight: 600;">${r.apitTax > 0 ? '-' + r.apitTax.toFixed(2) : '0.00'}</td>
                    <td style="font-weight: 900; color: #38bdf8; font-size: 0.95rem;">LKR ${r.netSalary.toFixed(2)}</td>
                    <td style="font-size: 0.72rem; color: #10b981; line-height: 1.3;">
                        <div>EPF 12%: LKR ${r.employerEpf12.toFixed(2)}</div>
                        <div>ETF 3%: LKR ${r.employerEtf3.toFixed(2)}</div>
                    </td>
                    <td style="text-align: right; white-space: nowrap;">
                        <button type="button" onclick="window.viewEmployeePayslip('${r.empId}', '${monthStr}')" class="action-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;">
                            <span>🖨️</span> Payslip
                        </button>
                        ${alreadyCommitted ? `
                            <span style="background: rgba(16, 185, 129, 0.2); color: #34d399; padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; font-weight: 800; margin-left: 4px;">
                                ✓ Committed
                            </span>
                        ` : ''}
                    </td>
                </tr>
            `;
        }).join('');
    }

    const badge = document.getElementById('payroll-batch-status-badge');
    if (badge) {
        badge.innerHTML = `⚡ ${records.length} Employees Calculated for ${monthStr}`;
    }
};

window.commitSriLankaPayrollBatch = async () => {
    const monthStr = document.getElementById('payroll-batch-month')?.value;
    if (!monthStr) {
        return window.showToast("⚠️ Please select payroll month first!", "warning");
    }

    if (!window.activeBatchPayrollRecords || window.activeBatchPayrollRecords.length === 0) {
        window.runSriLankaBatchPreview(monthStr);
    }

    const records = window.activeBatchPayrollRecords || [];
    if (records.length === 0) {
        return window.showToast("⚠️ No active employees to commit.", "warning");
    }

    const totalNet = records.reduce((sum, r) => sum + r.netSalary, 0);
    const totalStatutory = records.reduce((sum, r) => sum + r.totalStatutoryContribution, 0);
    const totalCompanyCost = records.reduce((sum, r) => sum + r.totalCompanyCost, 0);

    const proceed = await window.asyncConfirm(
        `🏛️ Approve & Commit Batch Payroll for ${monthStr}?\n\n` +
        `• Employees: ${records.length}\n` +
        `• Total Net Salary Disbursal: LKR ${totalNet.toFixed(2)}\n` +
        `• Central Bank EPF/ETF Remittance (23%): LKR ${totalStatutory.toFixed(2)}\n` +
        `• Total Employment Cost: LKR ${totalCompanyCost.toFixed(2)}\n\n` +
        `This will record itemized payroll entries and post a General Ledger Journal Voucher to MEC Accounting expenses.`,
        "Batch Payroll Approver"
    );

    if (!proceed) return;

    window.showToast("🚀 Committing batch payroll and posting accounting journals...", "info");

    let newlyCommitted = 0;
    const storeId = window.getStoreId();

    for (const r of records) {
        const alreadyCommitted = (window.allPayroll || []).some(p => (p.empId === r.empId || p.empId === r.empRegNo) && p.month === monthStr);
        if (alreadyCommitted) continue;

        const payload = {
            empId: r.empId,
            empRegNo: r.empRegNo,
            empName: r.empName,
            empRole: r.empRole,
            nic: r.nic,
            epfNumber: r.epfNumber,
            bankName: r.bankName,
            bankBranch: r.bankBranch,
            bankAccount: r.bankAccount,
            month: r.month,
            
            basicSalary: r.basicSalary,
            braAllowance: r.braAllowance,
            colaAllowance: r.colaAllowance,
            fixedAllowance: r.fixedAllowance,
            epfBase: r.epfBase,
            
            totalSales: r.totalSales,
            commissionPct: r.commissionPct,
            commissionEarned: r.commissionEarned,
            monthlyAttendanceAllowance: r.monthlyAttendanceAllowance,
            payableAttendanceAllowance: r.payableAttendanceAllowance,
            allowanceProtected: r.allowanceProtected,
            allowanceRemarks: r.allowanceRemarks,
            grossEarnings: r.grossEarnings,
            
            employeeEpf8: r.employeeEpf8,
            apitTax: r.apitTax,
            advanceDeductions: r.advanceDeductions,
            totalEmployeeDeductions: r.totalEmployeeDeductions,
            amount: r.netSalary,
            netSalary: r.netSalary,
            
            employerEpf12: r.employerEpf12,
            employerEtf3: r.employerEtf3,
            totalStatutoryContribution: r.totalStatutoryContribution,
            totalCompanyCost: r.totalCompanyCost,
            
            note: `Compliance Run: Base ${r.epfBase} | Comm ${r.commissionEarned.toFixed(2)} | Att ${r.payableAttendanceAllowance.toFixed(2)} | EPF -${r.employeeEpf8.toFixed(2)} | Net ${r.netSalary.toFixed(2)}`,
            status: 'Approved',
            storeId: storeId,
            branchId: 'Global',
            timestamp: serverTimestamp()
        };

        try {
            await addDoc(payrollCol, payload);
            newlyCommitted++;
        } catch (err) {
            console.error("Payroll save error:", err);
        }
    }

    // Double-Entry General Ledger Journal Voucher to expenses
    try {
        await addDoc(expensesCol, {
            title: `Monthly Staff Payroll & Statutory Remittance (${monthStr})`,
            category: 'Staff Salaries & EPF',
            amount: totalCompanyCost,
            netSalaryTotal: totalNet,
            epfRemittanceTotal: records.reduce((sum, r) => sum + r.totalEpfRemittance, 0),
            etfRemittanceTotal: records.reduce((sum, r) => sum + r.employerEtf3, 0),
            staffCount: records.length,
            month: monthStr,
            date: new Date().toISOString().split('T')[0],
            storeId: storeId,
            branchId: 'Global',
            note: `Sri Lanka Statutory Payroll Batch for ${records.length} staff. Net Bank Disbursal: LKR ${totalNet.toFixed(2)}, Total CBSL EPF/ETF (23%): LKR ${totalStatutory.toFixed(2)}`,
            timestamp: serverTimestamp()
        });
    } catch (e) {
        console.error("Journal posting error:", e);
    }

    window.showToast(`✅ Successfully Committed ${newlyCommitted} Payroll Records & Posted Accounting Journal!`, "success");
    window.runSriLankaBatchPreview(monthStr);
};

window.viewEmployeePayslip = (empId, monthStr) => {
    let record = (window.activeBatchPayrollRecords || []).find(r => r.empId === empId || r.empRegNo === empId);
    if (!record) {
        // Fallback to committed history
        const committed = (window.allPayroll || []).find(p => (p.empId === empId || p.empRegNo === empId || p.docId === empId) && (!monthStr || p.month === monthStr));
        if (committed) {
            record = {
                empName: committed.empName,
                empRegNo: committed.empRegNo || committed.empId,
                empRole: committed.empRole || 'Staff Member',
                month: committed.month,
                nic: committed.nic || '',
                epfNumber: committed.epfNumber || '',
                bankName: committed.bankName || 'Commercial Bank',
                bankAccount: committed.bankAccount || '',
                basicSalary: committed.basicSalary || committed.amount,
                braAllowance: committed.braAllowance || 0,
                colaAllowance: committed.colaAllowance || 0,
                fixedAllowance: committed.fixedAllowance || 0,
                epfBase: committed.epfBase || (committed.basicSalary || committed.amount),
                commissionPct: committed.commissionPct || 0,
                commissionEarned: committed.commissionEarned || 0,
                payableAttendanceAllowance: committed.payableAttendanceAllowance || 0,
                allowanceProtected: !!committed.allowanceProtected,
                grossEarnings: committed.grossEarnings || committed.amount,
                employeeEpf8: committed.employeeEpf8 || 0,
                apitTax: committed.apitTax || 0,
                advanceDeductions: committed.advanceDeductions || 0,
                totalEmployeeDeductions: committed.totalEmployeeDeductions || (committed.employeeEpf8 || 0),
                netSalary: committed.netSalary || committed.amount,
                employerEpf12: committed.employerEpf12 || 0,
                employerEtf3: committed.employerEtf3 || 0,
                totalStatutoryContribution: committed.totalStatutoryContribution || 0,
                totalCompanyCost: committed.totalCompanyCost || committed.amount
            };
        }
    }

    if (!record) {
        return window.showToast("⚠️ Payslip record could not be found.", "error");
    }

    const html = generatePayslipHTML(record, {
        name: 'MEC BOOK SHOP',
        address: 'Colombo, Sri Lanka',
        phone: '+94 11 234 5678'
    });

    const printWin = window.open('', '_blank', 'width=850,height=900,menubar=no,toolbar=no,location=no,status=no');
    if (printWin) {
        printWin.document.open();
        printWin.document.write(html);
        printWin.document.close();
        setTimeout(() => printWin.print(), 350);
    } else {
        window.showToast("⚠️ Pop-up blocked! Please allow pop-ups for this site.", "warning");
    }
};

window.batchPrintAllPayslips = () => {
    const records = window.activeBatchPayrollRecords || [];
    if (records.length === 0) {
        return window.showToast("⚠️ Please run batch preview first to load payslips.", "warning");
    }

    const slipsHtml = records.map(r => generatePayslipHTML(r, {
        name: 'MEC BOOK SHOP',
        address: 'Colombo, Sri Lanka'
    })).join('<div style="page-break-after: always; height: 0;"></div>');

    const printWin = window.open('', '_blank', 'width=850,height=900');
    if (printWin) {
        printWin.document.open();
        printWin.document.write(slipsHtml);
        printWin.document.close();
        setTimeout(() => printWin.print(), 500);
    }
};

window.exportEPFCForm = () => {
    const monthStr = document.getElementById('payroll-batch-month')?.value || new Date().toISOString().slice(0, 7);
    const records = window.activeBatchPayrollRecords || [];
    if (records.length === 0) {
        return window.showToast("⚠️ Run batch preview first to generate EPF C-Form data.", "warning");
    }
    const txt = generateCentralBankEPFCFormText(records, 'EPF/MEC/99812', monthStr);
    window.downloadFile(txt, `EPF_C_FORM_${monthStr.replace('-', '')}.txt`);
};

window.exportETFFormII = () => {
    const monthStr = document.getElementById('payroll-batch-month')?.value || new Date().toISOString().slice(0, 7);
    const records = window.activeBatchPayrollRecords || [];
    if (records.length === 0) {
        return window.showToast("⚠️ Run batch preview first to generate ETF schedule.", "warning");
    }
    const csv = generateETFScheduleCSV(records, 'ETF/MEC/7721', monthStr);
    window.downloadFile(csv, `ETF_FORM_II_${monthStr.replace('-', '')}.csv`);
};

window.exportBankBulkSalaryFile = () => {
    const monthStr = document.getElementById('payroll-batch-month')?.value || new Date().toISOString().slice(0, 7);
    const records = window.activeBatchPayrollRecords || [];
    if (records.length === 0) {
        return window.showToast("⚠️ Run batch preview first to generate bank upload file.", "warning");
    }
    const csv = generateBankBulkTransferCSV(records, '10002938471', monthStr);
    window.downloadFile(csv, `BANK_BULK_SALARY_${monthStr.replace('-', '')}.csv`);
};

window.runAIPayrollProcess = window.commitSriLankaPayrollBatch;


window.openAddEmployeeModal = () => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can register staff.", "error");
    }
    window.editingEmployeeId = null;
    const form = document.getElementById('employee-form');
    if (form) form.reset();

    const titleEl = document.getElementById('employee-modal-title');
    if (titleEl) titleEl.innerHTML = `<span>👤</span> Add New Staff Member`;
    const subEl = document.getElementById('employee-modal-subtitle');
    if (subEl) subEl.innerText = "Enter staff credentials, designation, branch and access permissions";

    const submitBtn = document.querySelector('#employee-form button[type="submit"]');
    if (submitBtn) submitBtn.innerText = "Register Employee";

    const pInput = document.getElementById('emp-password');
    const pinInp = document.getElementById('emp-pin');
    if (pInput) { pInput.disabled = false; pInput.placeholder = "Password"; }
    if (pinInp) { pinInp.disabled = false; pinInp.placeholder = "6-digit PIN"; }

    window.generateEmployeeID?.();
    window.generateEmployeePIN?.();

    const modal = document.getElementById('add-employee-modal');
    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => document.getElementById('emp-name')?.focus(), 100);
    }
};

window.closeAddEmployeeModal = () => {
    const modal = document.getElementById('add-employee-modal');
    if (modal) modal.style.display = 'none';
    window.editingEmployeeId = null;
    const submitBtn = document.querySelector('#employee-form button[type="submit"]');
    if (submitBtn) submitBtn.innerText = "Register Employee";
    const form = document.getElementById('employee-form');
    if (form) form.reset();
};

window.editingEmployeeId = null;

window.editEmployee = (docId) => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can edit employee details.", "error");
    }
    const emp = (window.allEmployees || []).find(e => e.docId === docId);
    if (!emp) return;

    const canView = window.canViewEmployeeCredentials();

    window.showHRMSubTab('employees');
    window.editingEmployeeId = docId;
    document.getElementById('emp-name').value = emp.name || '';
    document.getElementById('emp-role').value = emp.role || 'Other';
    document.getElementById('emp-phone').value = emp.phone || '';
    document.getElementById('emp-regno').value = emp.regno || '';
    document.getElementById('emp-address').value = emp.address || '';
    if (document.getElementById('emp-nic')) document.getElementById('emp-nic').value = emp.nic || '';
    if (document.getElementById('emp-epf-no')) document.getElementById('emp-epf-no').value = emp.epfNumber || emp.epfNo || '';
    if (document.getElementById('emp-bra')) document.getElementById('emp-bra').value = emp.braAllowance || emp.budgetaryAllowance || 0;
    if (document.getElementById('emp-cola')) document.getElementById('emp-cola').value = emp.colaAllowance || emp.livingAllowance || 0;
    if (document.getElementById('emp-fixed-allowance')) document.getElementById('emp-fixed-allowance').value = emp.fixedAllowance || 0;
    if (document.getElementById('emp-attendance-allowance')) document.getElementById('emp-attendance-allowance').value = emp.attendanceAllowance || emp.allowance || 0;
    if (document.getElementById('emp-bank-name')) document.getElementById('emp-bank-name').value = emp.bankName || 'Commercial Bank';
    if (document.getElementById('emp-bank-branch')) document.getElementById('emp-bank-branch').value = emp.bankBranch || '';
    if (document.getElementById('emp-bank-account')) document.getElementById('emp-bank-account').value = emp.bankAccount || emp.accountNo || '';
    document.getElementById('emp-salary').value = emp.salary || 0;
    document.getElementById('emp-commission').value = emp.commission || 0;
    document.getElementById('emp-ot-rate').value = emp.otRate || 0;
    document.getElementById('emp-late-rate').value = emp.latePenalty || 0;
    document.getElementById('emp-epf-enabled').checked = emp.epfEnabled !== false;
    document.getElementById('emp-apit-enabled').checked = !!emp.apitEnabled;
    document.getElementById('emp-hardware-id').value = emp.hardwareId || "";
    document.getElementById('emp-username').value = emp.username || "";
    
    // Protect Password and PIN based on Permission Role
    const passInput = document.getElementById('emp-password');
    const pinInput = document.getElementById('emp-pin');
    if (canView) {
        if (passInput) {
            passInput.value = emp.password || "";
            passInput.disabled = false;
            passInput.placeholder = "Password";
        }
        if (pinInput) {
            pinInput.value = emp.pin || '';
            pinInput.disabled = false;
            pinInput.placeholder = "App PIN (leave blank for Auto ID)";
        }
    } else {
        if (passInput) {
            passInput.value = emp.password ? "••••••••" : "";
            passInput.disabled = true;
            passInput.placeholder = "•••••••• (Protected)";
        }
        if (pinInput) {
            pinInput.value = emp.pin ? "••••••" : "";
            pinInput.disabled = true;
            pinInput.placeholder = "•••••• (Protected)";
        }
    }

    document.getElementById('emp-access-role').value = emp.role_access || 'none';
    document.getElementById('emp-branch-id').value = emp.branchId || 'Global';

    const submitBtn = document.querySelector('#employee-form button[type="submit"]');
    if (submitBtn) submitBtn.innerText = "💾 Save Changes";

    const titleEl = document.getElementById('employee-modal-title');
    if (titleEl) titleEl.innerHTML = `<span>✏️</span> Edit Staff: ${emp.name}`;
    const subEl = document.getElementById('employee-modal-subtitle');
    if (subEl) subEl.innerText = `Updating credentials and access for ${emp.regno || emp.name}`;

    const modal = document.getElementById('add-employee-modal');
    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => document.getElementById('emp-name')?.focus(), 100);
    }
};

document.getElementById('employee-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can register or update staff.", "error");
    }
    const isEditing = !!window.editingEmployeeId;
    const existingEmp = isEditing ? (window.allEmployees || []).find(e => e.docId === window.editingEmployeeId) : null;
    const canView = window.canViewEmployeeCredentials();

    const name = document.getElementById('emp-name')?.value || 'New Staff';
    const role = document.getElementById('emp-role')?.value || 'Staff';
    const phone = document.getElementById('emp-phone')?.value || '';
    const regno = document.getElementById('emp-regno')?.value || '';
    const address = document.getElementById('emp-address')?.value || '';
    const role_access = document.getElementById('emp-access-role')?.value || 'none';
    const branchId = document.getElementById('emp-branch-id')?.value || 'Global';
    const storeId = window.getStoreId();

    let rawPin = document.getElementById('emp-pin')?.value?.trim() || "";
    let rawPass = document.getElementById('emp-password')?.value?.trim() || "";

    let finalPin = rawPin;
    let finalPass = rawPass;
    let isTempPin = false;
    let mustReset = false;
    let pinChanged = false;

    if (isEditing) {
        if (!canView) {
            // Unauthorized editor: preserve existing sensitive credentials untouched
            finalPin = existingEmp?.pin || "";
            finalPass = existingEmp?.password || "";
        }
        isTempPin = existingEmp?.isTemporaryPin ?? false;
        mustReset = existingEmp?.mustResetPin ?? false;
        pinChanged = existingEmp?.pinChanged ?? (!!existingEmp?.pin && existingEmp.pin !== existingEmp.regno);
    } else {
        // Registering a brand new employee
        if (!finalPin) {
            // Default initial PIN is Employee Register Number (e.g. EMP-005)
            // One-time use only: must reset on first login!
            finalPin = regno;
            isTempPin = true;
            mustReset = true;
            pinChanged = false;
        } else {
            // Admin explicitly entered a custom PIN
            isTempPin = false;
            mustReset = false;
            pinChanged = true;
        }
    }

    const staffData = { 
        name, role, phone, regno, address, 
        nic: document.getElementById('emp-nic')?.value?.trim() || "",
        epfNumber: document.getElementById('emp-epf-no')?.value?.trim() || "",
        salary: parseFloat(document.getElementById('emp-salary')?.value) || 0,
        braAllowance: parseFloat(document.getElementById('emp-bra')?.value) || 0,
        colaAllowance: parseFloat(document.getElementById('emp-cola')?.value) || 0,
        fixedAllowance: parseFloat(document.getElementById('emp-fixed-allowance')?.value) || 0,
        attendanceAllowance: parseFloat(document.getElementById('emp-attendance-allowance')?.value) || 0,
        bankName: document.getElementById('emp-bank-name')?.value || "Commercial Bank",
        bankBranch: document.getElementById('emp-bank-branch')?.value?.trim() || "",
        bankAccount: document.getElementById('emp-bank-account')?.value?.trim() || "",
        commission: parseFloat(document.getElementById('emp-commission')?.value) || 0,
        otRate: parseFloat(document.getElementById('emp-ot-rate')?.value) || 0,
        latePenalty: parseFloat(document.getElementById('emp-late-rate')?.value) || 0,
        epfEnabled: document.getElementById('emp-epf-enabled')?.checked ?? true,
        apitEnabled: !!document.getElementById('emp-apit-enabled')?.checked,
        hardwareId: document.getElementById('emp-hardware-id')?.value?.trim() || "",
        username: document.getElementById('emp-username')?.value?.trim() || "",
        password: finalPass,
        pin: finalPin,
        isTemporaryPin: isTempPin,
        mustResetPin: mustReset,
        pinChanged: pinChanged,
        role_access, branchId, storeId, 
        timestamp: serverTimestamp() 
    };

    // System-wide Unique Username Validation
    if (staffData.username) {
        try {
            window.showToast("🔍 Checking username uniqueness across system...", "info");
            const dupEmpSnap = await getDocs(query(collection(db, 'employees'), where('username', '==', staffData.username)));
            const isDupEmp = dupEmpSnap.docs.some(d => !isEditing || d.id !== window.editingEmployeeId);
            if (isDupEmp) {
                window.showToast(`❌ System Username "${staffData.username}" is already in use by another staff member! Please enter a unique username.`, "error");
                const statusEl = document.getElementById('emp-username-status');
                if (statusEl) {
                    statusEl.innerText = `❌ Username "${staffData.username}" is already in use!`;
                    statusEl.style.color = '#ef4444';
                }
                document.getElementById('emp-username')?.focus();
                return;
            }

            // Also verify it doesn't conflict with another employee's email
            const dupEmailSnap = await getDocs(query(collection(db, 'employees'), where('email', '==', staffData.username.toLowerCase())));
            const isDupEmail = dupEmailSnap.docs.some(d => !isEditing || d.id !== window.editingEmployeeId);
            if (isDupEmail) {
                window.showToast(`❌ System Username "${staffData.username}" matches an existing staff email!`, "error");
                document.getElementById('emp-username')?.focus();
                return;
            }

            // Also verify it doesn't conflict with a merchant store email
            const dupStoreSnap = await getDocs(query(collection(db, 'stores'), where('email', '==', staffData.username.toLowerCase()), limit(1)));
            if (!dupStoreSnap.empty) {
                window.showToast(`❌ System Username "${staffData.username}" matches a registered store account!`, "error");
                document.getElementById('emp-username')?.focus();
                return;
            }
        } catch (vErr) {
            console.warn("Username uniqueness check warning:", vErr);
        }
    }

    try {
        window.showToast(navigator.onLine ? "🚀 Syncing staff details..." : "💾 Saving staff record locally...", "info");
        if (isEditing) {
            await updateDoc(doc(db, 'employees', window.editingEmployeeId), staffData);
            window.showToast(navigator.onLine ? "✅ Staff Details Updated!" : "✅ Saved Locally", "success");
            window.editingEmployeeId = null;
            const submitBtn = document.querySelector('#employee-form button[type="submit"]');
            if (submitBtn) submitBtn.innerText = "Register Employee";
            
            // Re-enable inputs if they were disabled
            const pInput = document.getElementById('emp-password');
            const pinInp = document.getElementById('emp-pin');
            if (pInput) pInput.disabled = false;
            if (pinInp) pinInp.disabled = false;
        } else {
            await addDoc(employeesCol, staffData);
            window.showToast(navigator.onLine ? "✅ Staff Registered Successfully!" : "✅ Registered Locally", "success");
            
            // Auto prompt for sending login credentials & 1-time PIN via SMS
            if (phone) {
                setTimeout(() => {
                    window.sendEmployeeSMS(phone, name, finalPin || regno, staffData.username, staffData.password, role_access, isTempPin);
                }, 600);
            }
        }
        e.target.reset();
        const statusEl = document.getElementById('emp-username-status');
        if (statusEl) statusEl.innerText = '';
        window.generateEmployeeID(); // Re-generate for next if new
        window.closeAddEmployeeModal();
    } catch (err) {
        console.error(err);
        window.showToast("Error processing request!", "error");
    }
});

// Live Username Uniqueness Validation Listener
let _empUsernameDebounce = null;
document.getElementById('emp-username')?.addEventListener('input', (e) => {
    const statusEl = document.getElementById('emp-username-status');
    const val = e.target.value?.trim();
    if (!val) {
        if (statusEl) statusEl.innerText = '';
        return;
    }
    if (statusEl) {
        statusEl.innerText = 'Checking availability...';
        statusEl.style.color = '#38bdf8';
    }
    clearTimeout(_empUsernameDebounce);
    _empUsernameDebounce = setTimeout(async () => {
        try {
            const isEditing = !!window.editingEmployeeId;
            const snap = await getDocs(query(collection(db, 'employees'), where('username', '==', val)));
            const taken = snap.docs.some(d => !isEditing || d.id !== window.editingEmployeeId);
            if (taken) {
                if (statusEl) {
                    statusEl.innerText = `❌ Username "${val}" is already taken!`;
                    statusEl.style.color = '#ef4444';
                }
            } else {
                if (statusEl) {
                    statusEl.innerText = `✅ Username "${val}" is available.`;
                    statusEl.style.color = '#10b981';
                }
            }
        } catch (_) {}
    }, 400);
});

// Hardware Sync Implementation Stub
window.testHardwareConnection = () => {
    const ip = document.getElementById('hrm-hw-ip').value;
    const port = document.getElementById('hrm-hw-port').value;
    const statusEl = document.getElementById('hrm-hw-status');
    const logsEl = document.getElementById('hrm-hw-logs');

    if (!ip) return window.showToast("Please enter Device IP", "warning");

    statusEl.innerText = "Connecting...";
    statusEl.style.color = "#fbbf24";
    logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] Pinging ${ip}:${port}...`;

    // Simulated Hardware Polling Logic
    setTimeout(() => {
        if (ip.includes('192.168')) {
            statusEl.innerText = "Online & Syncing";
            statusEl.style.color = "#10b981";
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] ✅ Device Connected!`;
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] 📥 Fetching 42 new attendance logs...`;
            window.showToast("Biometric Device Synced Successfully!", "success");
        } else {
            statusEl.innerText = "Connection Failed";
            statusEl.style.color = "#ef4444";
            logsEl.innerHTML += `<br>[${new Date().toLocaleTimeString()}] ❌ Network Timeout. Check IP.`;
            window.showToast("Device Connection Failed!", "error");
        }
    }, 2000);
};

document.getElementById('payroll-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const empId = document.getElementById('pay-emp-id').value;
    const amount = parseFloat(document.getElementById('pay-amount').value);
    const month = document.getElementById('pay-month').value;
    const note = document.getElementById('pay-note').value;

    const emp = window.allEmployees.find(e => e.docId === empId);
    if (!emp) return;

    window.showToast(navigator.onLine ? "🚀 Processing payroll..." : "💾 Saving payroll locally...", "info");
    await addDoc(payrollCol, { 
        empId, 
        empName: emp.name, 
        amount, 
        month, 
        note, 
        storeId: window.getStoreId(),
        timestamp: serverTimestamp() 
    });

    // Also log as Expense automatically
    await addDoc(expensesCol, {
        title: `Salary: ${emp.name} (${month})`,
        category: 'Salary',
        amount,
        date: new Date().toISOString().split('T')[0],
        storeId: window.getStoreId(),
        timestamp: serverTimestamp()
    });

    e.target.reset();
    window.showToast(navigator.onLine ? "✅ Salary Payment Recorded & Linked to Expenses!" : "✅ Salary Saved Locally & Linked", "success");
});

window.confirmDeleteEmployee = async (docId) => {
    if (!window.canManageEmployees()) {
        return window.showToast("🔒 Permission Denied: Only CEO / HR Manager can delete employees.", "error");
    }
    const docRef = doc(db, 'employees', docId);
    if (!await window.verifyDeletePermission(docRef, { status: 'Terminated', isVoid: true })) return;
    await deleteDoc(docRef);
    window.showToast("Staff Removed", "info");
};

// Initialized HRM sub-tab
window.showHRMSubTab('employees');

if (sessionStorage.getItem('isAdminLoggedIn')) showAdminActions();



// --- Bulk Deletion for MEC Book Shop (SuperAdmin Clean-up) ---
window.clearAllStaff = async () => {
    const role = sessionStorage.getItem('userRole');
    if (role !== 'SuperAdmin') {
        alert("CRITICAL: Only SuperAdmin can perform this action.");
        return;
    }

    const confirmPurge = confirm("🚨 CRITICAL WARNING!\n\nThis will PERMANENTLY delete ALL existing staff/employee usernames and passwords from the database.\n\nOnly the main 'mecbookshop@gmail.com' will remain.\n\nContinue with deletion?");
    
    if (!confirmPurge) return;

    try {
        const batch = writeBatch(db);
        const snapshot = await getDocs(employeesCol);
        
        if (snapshot.empty) {
            window.showToast("No employee records to clear.", "info");
            return;
        }

        snapshot.docs.forEach((docSnap) => {
            batch.delete(docSnap.ref);
        });

        await batch.commit();
        window.showToast(`System Cleaned: ${snapshot.size} employee records removed.`, "success");
        setTimeout(() => location.reload(), 2000);

    } catch (err) {
        console.error("Purge Error:", err);
        window.showToast("Failed to clear staff list.", "error");
    }
};



// --- Website Developer Functions (Web Studio) ---
window.handleWebBannerUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    window.showToast("⏳ Optimizing banner image...", "info");
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const maxSize = 1200;

            if (width > height) {
                if (width > maxSize) {
                    height *= maxSize / width;
                    width = maxSize;
                }
            } else {
                if (height > maxSize) {
                    width *= maxSize / height;
                    height = maxSize;
                }
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.75);
            
            const previewImg = document.getElementById('banner-preview-img');
            if (previewImg) {
                previewImg.src = compressedBase64;
                previewImg.style.display = 'block';
            }
            window.currentWebBannerBase64 = compressedBase64;
            window.showToast("🖼️ Banner optimized & preview updated! Remember to save.", "success");
        };
        img.onerror = () => {
            window.showToast("❌ Error loading image file.", "error");
        };
        img.src = e.target.result;
    };
    reader.onerror = () => {
        window.showToast("❌ Error reading file.", "error");
    };
    reader.readAsDataURL(file);
};

window.extractAndSetThemeColor = function(url) {
    if (!url) return;
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.onload = function() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const maxDim = 100;
        let w = img.width, h = img.height;
        if (w > maxDim || h > maxDim) {
             const ratio = Math.min(maxDim/w, maxDim/h);
             w *= ratio; h *= ratio;
        }
        canvas.width = w; canvas.height = h;
        ctx.drawImage(img, 0, 0, w, h);
        try {
            const data = ctx.getImageData(0, 0, w, h).data;
            const colors = {};
            let maxCount = 0;
            let dominantHex = "";
            for (let i = 0; i < data.length; i += 4) {
                if (data[i+3] < 128) continue; // ignore transparent
                const r = data[i], g = data[i+1], b = data[i+2];
                // ignore too white or too black
                if (r > 240 && g > 240 && b > 240) continue;
                if (r < 15 && g < 15 && b < 15) continue;
                
                // round to group similar colors
                const r10 = Math.round(r/10)*10;
                const g10 = Math.round(g/10)*10;
                const b10 = Math.round(b/10)*10;
                const key = `${r10},${g10},${b10}`;
                colors[key] = (colors[key] || 0) + 1;
                if (colors[key] > maxCount) {
                    maxCount = colors[key];
                    dominantHex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
                }
            }
            if (dominantHex) {
                const colorInput = document.getElementById('web-theme-primary');
                if (colorInput && colorInput.value !== dominantHex) {
                    colorInput.value = dominantHex;
                    window.showToast("✨ AI detected theme color from logo!", "success");
                    // Give a visual hint that it changed
                    colorInput.style.boxShadow = "0 0 10px " + dominantHex;
                    setTimeout(() => colorInput.style.boxShadow = "none", 2000);
                }
            }
        } catch(e) {
            console.log("Could not extract color (likely CORS)", e);
        }
    };
    img.src = url;
};

window.saveWebBranding = async (e) => {
    e.preventDefault();
    const title = document.getElementById('web-site-title').value;
    const desc = document.getElementById('web-site-desc').value;
    const logoUrl = document.getElementById('web-site-logo-url').value;
    const domain = document.getElementById('web-site-domain').value.trim().toLowerCase();
    const primaryColor = document.getElementById('web-theme-primary').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            const currentData = snap.docs[0].data();
            const webDesign = currentData.webDesign || {};
            webDesign.primary = primaryColor;
            
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webTitle: title,
                webDescription: desc,
                webLogo: logoUrl,
                domain: domain,
                webDesign: webDesign,
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Website branding updated successfully!", "success");
        } else {
            const webDesign = { primary: primaryColor };
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webTitle: title,
                webDescription: desc,
                webLogo: logoUrl,
                domain: domain,
                webDesign: webDesign,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Website branding created and updated successfully!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error updating branding", "error");
    }
};

window.saveWebDesign = async () => {
    const primary = document.getElementById('web-theme-primary').value;
    const accent = document.getElementById('web-theme-accent').value;
    const heroBg = document.getElementById('web-hero-bg').value;
    
    const settings = {
        primary,
        accent,
        heroBg,
        showFeatured: document.getElementById('web-show-featured').checked,
        showReviews: document.getElementById('web-show-reviews').checked,
        showServices: document.getElementById('web-show-services').checked,
        forceDarkMode: document.getElementById('web-enable-darkmode').checked,
        bannerUrl: window.currentWebBannerBase64 || null
    };

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webDesign: settings,
                updatedAt: serverTimestamp()
            });
            window.showToast("🎨 Design changes applied to live site!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webDesign: settings,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🎨 Design profile created and changes applied!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving design", "error");
    }
};

window.saveWebContent = async () => {
    const welcome = document.getElementById('web-hero-welcome').value;
    const announce = document.getElementById('web-announcement').value;
    const footer = document.getElementById('web-footer-name').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webContent: { welcome, announce, footer },
                updatedAt: serverTimestamp()
            });
            window.showToast("📝 Website content updated!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webContent: { welcome, announce, footer },
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("📝 Website content created and updated!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving content", "error");
    }
};

window.saveWebEpinics = async () => {
    const multiVendor = document.getElementById('web-enable-multivendor').checked;
    const affiliate = document.getElementById('web-enable-affiliate').checked;
    const liveTracking = document.getElementById('web-enable-live-tracking').checked;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webEpinics: { multiVendor, affiliate, liveTracking },
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Epinics Enterprise modules synced!", "success");
        } else {
            await addDoc(storesCol, {
                slug: storeId,
                name: storeId === 'mec-book-shop' ? 'MEC Book Shop' : storeId,
                webEpinics: { multiVendor, affiliate, liveTracking },
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });
            window.showToast("🚀 Epinics Enterprise modules created and synced!", "success");
        }
        if (typeof window.renderEpinicsManagement === 'function') {
            await window.renderEpinicsManagement();
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving Epinics settings", "error");
    }
};

window.loadWebSettings = async () => {
    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            const data = snap.docs[0].data();
            
            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.value = val;
            };
            const setChecked = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.checked = val;
            };

            // Branding
            setVal('web-site-title', data.webTitle || '');
            setVal('web-site-desc', data.webDescription || '');
            setVal('web-site-logo-url', data.webLogo || '');
            setVal('web-site-domain', data.domain || '');
            
            const preview = document.getElementById('web-logo-preview');
            if (preview && data.webLogo) {
                preview.innerHTML = '';
                preview.style.backgroundImage = `url(${data.webLogo})`;
                preview.style.backgroundSize = 'contain';
                preview.style.backgroundRepeat = 'no-repeat';
                preview.style.backgroundPosition = 'center';
            }

            // Design
            if (data.webDesign) {
                const wd = data.webDesign;
                setVal('web-theme-primary', wd.primary || '#002060');
                setVal('web-theme-accent', wd.accent || '#00aeef');
                setVal('web-hero-bg', wd.heroBg || 'gradient');
                setChecked('web-show-featured', wd.showFeatured !== false);
                setChecked('web-show-reviews', wd.showReviews !== false);
                setChecked('web-show-services', wd.showServices !== false);
                setChecked('web-enable-darkmode', wd.forceDarkMode === true);

                const bPreview = document.getElementById('banner-preview-img');
                if (bPreview) {
                    const firestoreBanner = wd.bannerUrl;
                    const bannerUrl = (firestoreBanner && firestoreBanner.length > 10)
                      ? firestoreBanner
                      : (window.getStoreId() === 'mec-book-shop' ? '/banner.png' : '');
                    
                    if (bannerUrl) {
                        bPreview.src = bannerUrl;
                        bPreview.style.display = 'block';
                        window.currentWebBannerBase64 = bannerUrl;
                    } else {
                        bPreview.src = '';
                        bPreview.style.display = 'none';
                        window.currentWebBannerBase64 = null;
                    }
                }
            }

            // Content
            if (data.webContent) {
                setVal('web-hero-welcome', data.webContent.welcome || '');
                setVal('web-announcement', data.webContent.announce || '');
                setVal('web-footer-name', data.webContent.footer || 'MEC Book Shop System');
            }

            // SEO & Analytics
            if (data.webSEO) {
                setVal('web-seo-keywords', data.webSEO.keywords || '');
                setVal('web-analytics-id', data.webSEO.analyticsId || '');
                setVal('web-pixel-id', data.webSEO.pixelId || '');
                setVal('web-contact-phone', data.webSEO.contactPhone || '');
                setVal('web-meta-desc', data.webSEO.metaDesc || '');
            }

            // Epinics
            if (data.webEpinics) {
                setChecked('web-enable-multivendor', !!data.webEpinics.multiVendor);
                setChecked('web-enable-affiliate', !!data.webEpinics.affiliate);
                setChecked('web-enable-live-tracking', data.webEpinics.liveTracking !== false);
            }
            
            if (typeof window.renderEpinicsManagement === 'function') {
                await window.renderEpinicsManagement();
            }
        }
    } catch (err) {
        console.error("Error loading web settings:", err);
    }
};

window.renderEpinicsManagement = async () => {
    const epinicsContainer = document.getElementById('epinics-admin-management');
    if (!epinicsContainer) return;

    const multiVendor = document.getElementById('web-enable-multivendor')?.checked;
    const affiliate = document.getElementById('web-enable-affiliate')?.checked;

    if (!multiVendor && !affiliate) {
        epinicsContainer.style.display = 'none';
        return;
    }
    epinicsContainer.style.display = 'block';

    const vendorShopsSec = document.getElementById('vendor-shops-admin-section');
    const vendorProdsSec = document.getElementById('vendor-products-admin-section');
    const affiliatesSec = document.getElementById('affiliates-admin-section');

    const storeId = window.getStoreId();

    if (multiVendor) {
        if (vendorShopsSec) vendorShopsSec.style.display = 'block';
        if (vendorProdsSec) vendorProdsSec.style.display = 'block';

        // Load Vendor Shops
        try {
            const qShops = query(collection(db, 'vendor_shops'), where('storeId', '==', storeId));
            const snapShops = await getDocs(qShops);
            const tbody = document.getElementById('admin-vendor-shops-tbody');
            if (tbody) {
                if (snapShops.empty) {
                    tbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">No vendor shops registered.</td></tr>`;
                } else {
                    let html = '';
                    snapShops.forEach(docSnap => {
                        const shop = docSnap.data();
                        const docId = docSnap.id;
                        const statusColor = shop.status === 'active' ? '#10b981' : '#fbbf24';
                        let actionsHtml = '';
                        if (shop.status === 'pending') {
                            actionsHtml = `
                                <button onclick="window.approveVendorShop('${docId}')" style="background:#10b981; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold; margin-right:5px;">Approve</button>
                                <button onclick="window.rejectVendorShop('${docId}')" style="background:#ef4444; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold;">Reject</button>
                            `;
                        } else {
                            actionsHtml = `<span style="color:#64748b; font-size:0.8rem;">None</span>`;
                        }
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${shop.shopName || ''}</td>
                                <td style="padding:12px;">${shop.ownerName || ''}</td>
                                <td style="padding:12px;">${shop.email || ''}</td>
                                <td style="padding:12px;">${shop.phone || ''}</td>
                                <td style="padding:12px; color:${statusColor}; font-weight:bold; text-transform:uppercase; font-size:0.85rem;">${shop.status || 'pending'}</td>
                                <td style="padding:12px;">${actionsHtml}</td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering vendor shops:", err);
        }

        // Load Pending Products
        try {
            const qProds = query(productsCol, where('status', '==', 'pending'), where('storeId', '==', storeId));
            const snapProds = await getDocs(qProds);
            const tbody = document.getElementById('admin-pending-products-tbody');
            if (tbody) {
                if (snapProds.empty) {
                    tbody.innerHTML = `<tr><td colspan="5" style="padding: 20px; text-align: center; color: #64748b;">No pending products.</td></tr>`;
                } else {
                    let html = '';
                    snapProds.forEach(docSnap => {
                        const prod = docSnap.data();
                        const docId = docSnap.id;
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${prod.name || ''}</td>
                                <td style="padding:12px;">${prod.category || ''}</td>
                                <td style="padding:12px; color:#fbbf24; font-weight:bold;">LKR ${prod.price || 0}</td>
                                <td style="padding:12px; color:#94a3b8;">${prod.vendorId || ''}</td>
                                <td style="padding:12px;">
                                    <button onclick="window.approveVendorProduct('${docId}')" style="background:#10b981; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold; margin-right:5px;">Approve</button>
                                    <button onclick="window.deleteVendorProduct('${docId}')" style="background:#ef4444; border:none; color:white; padding:5px 10px; border-radius:5px; font-size:0.8rem; cursor:pointer; font-weight:bold;">Reject</button>
                                </td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering pending products:", err);
        }
    } else {
        if (vendorShopsSec) vendorShopsSec.style.display = 'none';
        if (vendorProdsSec) vendorProdsSec.style.display = 'none';
    }

    if (affiliate) {
        if (affiliatesSec) affiliatesSec.style.display = 'block';

        // Load Affiliates
        try {
            const qAff = query(collection(db, 'affiliates'), where('storeId', '==', storeId));
            const snapAff = await getDocs(qAff);
            const tbody = document.getElementById('admin-affiliates-tbody');
            if (tbody) {
                if (snapAff.empty) {
                    tbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">No registered affiliates.</td></tr>`;
                } else {
                    let html = '';
                    snapAff.forEach(docSnap => {
                        const aff = docSnap.data();
                        html += `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                                <td style="padding:12px; font-weight:bold;">${aff.name || ''}</td>
                                <td style="padding:12px;">${aff.email || ''}</td>
                                <td style="padding:12px; color:#38bdf8; font-weight:bold;">${aff.code || ''}</td>
                                <td style="padding:12px;">${aff.clicks || 0}</td>
                                <td style="padding:12px;">${aff.salesCount || 0}</td>
                                <td style="padding:12px; color:#fbbf24; font-weight:bold;">LKR ${(aff.totalCommission || 0).toFixed(2)}</td>
                            </tr>
                        `;
                    });
                    tbody.innerHTML = html;
                }
            }
        } catch (err) {
            console.error("Error rendering affiliates:", err);
        }
    } else {
        if (affiliatesSec) affiliatesSec.style.display = 'none';
    }
};

window.approveVendorShop = async (docId) => {
    if (!confirm('Are you sure you want to approve this shop request?')) return;
    try {
        await updateDoc(doc(db, 'vendor_shops', docId), { status: 'active' });
        window.showToast("Shop approved successfully!", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error approving shop", "error");
    }
};

window.rejectVendorShop = async (docId) => {
    if (!confirm('Are you sure you want to reject and delete this shop request?')) return;
    try {
        await deleteDoc(doc(db, 'vendor_shops', docId));
        window.showToast("Shop request deleted.", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error rejecting shop", "error");
    }
};

window.approveVendorProduct = async (docId) => {
    if (!confirm('Are you sure you want to approve this product?')) return;
    try {
        await updateDoc(doc(db, 'products', docId), { status: 'active' });
        window.showToast("Product approved and is now live!", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error approving product", "error");
    }
};

window.deleteVendorProduct = async (docId) => {
    if (!confirm('Are you sure you want to reject and delete this product?')) return;
    try {
        await deleteDoc(doc(db, 'products', docId));
        window.showToast("Product rejected and deleted.", "success");
        await window.renderEpinicsManagement();
    } catch (err) {
        console.error(err);
        window.showToast("Error rejecting product", "error");
    }
};

window.saveWebSEO = async () => {
    const keywords = document.getElementById('web-seo-keywords').value;
    const analyticsId = document.getElementById('web-analytics-id').value;
    const pixelId = document.getElementById('web-pixel-id').value;
    const contactPhone = document.getElementById('web-contact-phone').value;
    const metaDesc = document.getElementById('web-meta-desc').value;

    try {
        const storeId = window.getStoreId();
        const q = query(storesCol, where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                webSEO: { keywords, analyticsId, pixelId, contactPhone, metaDesc },
                updatedAt: serverTimestamp()
            });
            window.showToast("🔍 SEO & Analytics settings updated!", "success");
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error saving SEO settings", "error");
    }
};

// --- SUPPLIER INVOICE MANAGEMENT [NEW] ---
window.currentInvoiceItems = [];

window.renderSupplierInvoicesUI = () => {
    const listBody = document.getElementById('supplier-invoices-body');
    if (!listBody) return;

    const invoices = window.allSupplierInvoices || [];
    
    if (invoices.length === 0) {
        listBody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 4rem; color: #64748b;">
            <div style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.2;">📁</div>
            <p style="font-weight: 700; font-size: 1.1rem; opacity: 0.5;">No invoices found in your system.</p>
        </td></tr>`;
        return;
    }

    // Sort DESC for list view
    invoices.sort((a,b) => {
        const da = a.timestamp?.seconds ? a.timestamp.seconds : new Date(a.date).getTime() / 1000;
        const db = b.timestamp?.seconds ? b.timestamp.seconds : new Date(b.date).getTime() / 1000;
        return db - da;
    });

    listBody.innerHTML = '';
    invoices.forEach(inv => {
        const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
        const paid = parseFloat(inv.paidAmount || inv.paid || 0);
        const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();

        // Auto-resolve cheque status: if chequeDate has passed, show Paid
        let status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
        const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
        if (isCheque && inv.chequeStatus === 'pending' && inv.chequeDate) {
            const today = new Date(); today.setHours(0,0,0,0);
            const chequeDay = new Date(inv.chequeDate); chequeDay.setHours(0,0,0,0);
            if (chequeDay <= today) status = 'Paid';
        }

        const statusColor = status === 'Paid' ? '#10b981' : status === 'Partially Paid' ? '#f59e0b' : '#fbbf24';
        const statusBg   = status === 'Paid' ? '#10b98133' : status === 'Partially Paid' ? '#f59e0b33' : '#fbbf2433';
        const methodIcon = isCheque ? '🧾' : (inv.paymentMethod === 'Bank' ? '🏦' : (inv.paymentMethod === 'Credit' ? '⏳' : '💵'));
        const chequeDateLabel = isCheque && inv.chequeDate ? `<div style="font-size:0.65rem; color:#f59e0b; margin-top:2px;">📅 ${inv.chequeDate}</div>` : '';
        const showMarkPaid = isCheque && status === 'Pending' && inv.chequeStatus === 'pending';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${dateStr}</td>
            <td style="font-weight: 800; color: #38bdf8; cursor: pointer; text-decoration: underline;" onclick="window.showSupplierInvoiceDetails('${inv.docId || inv.id}')" title="Click to view details">${inv.invoiceNo}</td>
            <td>${inv.supplierName}<br><span style="font-size:0.7rem; color:#64748b;">${methodIcon} ${inv.paymentMethod || 'Cash'}</span>${chequeDateLabel}</td>
            <td style="text-align: center;">${(inv.items || []).length} items</td>
            <td style="font-weight: 800;">LKR ${total.toLocaleString()}</td>
            <td>
                <span class="status-badge" style="background: ${statusBg}; color: ${statusColor}; padding: 4px 10px; border-radius: 8px; font-size: 0.65rem; font-weight:800;">${status}</span>
                ${showMarkPaid ? `<br><button onclick="window.markChequeAsPaid('${inv.docId || inv.id}')" style="margin-top:4px; font-size:0.6rem; padding:3px 8px; border-radius:6px; background:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.4); color:#10b981; cursor:pointer; font-weight:800;">✅ Mark Paid</button>` : ''}
            </td>
            <td style="text-align: right; display:flex; gap:6px; justify-content:flex-end; align-items:center; padding: 10px 12px;">
                <button onclick="window.viewSupplierInvoice('${inv.docId || inv.id}')" 
                    title="View / Print Invoice"
                    style="background: rgba(16,185,129,0.15); border: 1px solid rgba(16,185,129,0.3); color: #10b981; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(16,185,129,0.3)'" onmouseout="this.style.background='rgba(16,185,129,0.15)'">🖨️</button>
                <button onclick="window.editSupplierInvoice('${inv.docId || inv.id}')" 
                    title="Edit Invoice"
                    style="background: rgba(56,189,248,0.15); border: 1px solid rgba(56,189,248,0.3); color: #38bdf8; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(56,189,248,0.3)'" onmouseout="this.style.background='rgba(56,189,248,0.15)'">✏️</button>
                <button onclick="window.deleteSupplierInvoice('${inv.docId || inv.id}')" 
                    title="Delete Invoice"
                    style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); color: #ef4444; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:0.9rem; display:flex; align-items:center; justify-content:center; transition:all 0.2s;"
                    onmouseover="this.style.background='rgba(239,68,68,0.25)'" onmouseout="this.style.background='rgba(239,68,68,0.1)'">🗑️</button>
            </td>
        `;
        // Make the row clickable (except action buttons)
        tr.style.cursor = 'pointer';
        tr.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;
            window.showSupplierInvoiceDetails(inv.docId || inv.id);
        });
        listBody.appendChild(tr);
    });
};


// ─────────────────────────────────────────────────────────────────────────────
// VIEW / PRINT SUPPLIER INVOICE (A4 Printable)
// ─────────────────────────────────────────────────────────────────────────────
window.viewSupplierInvoice = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const balance = total - paid;
    const status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
    const statusColor = status === 'Paid' ? '#16a34a' : status === 'Partially Paid' ? '#d97706' : '#dc2626';
    const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
    const methodLabel = isCheque ? '🧾 Cheque' : ((inv.paymentMethod || '').toLowerCase() === 'bank' ? '🏦 Bank Transfer' : ((inv.paymentMethod || '').toLowerCase() === 'credit' ? '⏳ Credit' : '💵 Cash'));
    const storeName = (window.systemConfig && window.systemConfig.shopName) || 'MEC BOOK SHOP';
    const storeAddress = (window.systemConfig && window.systemConfig.address) || '';
    const storePhone = (window.systemConfig && window.systemConfig.phone) || '';

    const itemRows = (inv.items || []).map(function(item, i) {
        const cost = parseFloat(item.buying || item.buyingPrice || item.cost || item.netCost || 0);
        const qty  = parseFloat(item.qty || item.quantity || 0);
        const lineTotal = parseFloat(item.totalCost || item.total || (cost * qty) || 0);
        const desc = [item.sku ? 'SKU: ' + item.sku : '', item.variant || item.variantLabel || ''].filter(Boolean).join(' | ');
        return '<tr style="border-bottom:1px solid #e5e7eb;">' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;vertical-align:top;">' + (i+1) + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;font-weight:600;vertical-align:top;">' + (item.name || '—') + (desc ? '<br><span style="font-size:0.7rem;color:#6b7280;font-weight:400;">' + desc + '</span>' : '') + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:center;vertical-align:top;">' + qty + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:right;vertical-align:top;">LKR ' + cost.toFixed(2) + '</td>' +
            '<td style="padding:10px 8px;font-size:0.82rem;color:#111827;text-align:right;font-weight:700;vertical-align:top;">LKR ' + lineTotal.toFixed(2) + '</td>' +
            '</tr>';
    }).join('');

    const chequeLine = (isCheque && inv.chequeDate) ? '<br><small style="color:#92400e;">📅 Cheque Date: ' + inv.chequeDate + '</small>' : '';
    const sep = storeAddress && storePhone ? ' &nbsp;|&nbsp; ' : '';

    const printHTML = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Supplier Invoice #' + (inv.invoiceNo || '') + '</title>' +
'<style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:"Segoe UI",Arial,sans-serif;background:#f1f5f9;display:flex;justify-content:center;padding:20px;}' +
'.page{width:210mm;min-height:297mm;background:#fff;padding:32px 38px;box-shadow:0 4px 40px rgba(0,0,0,.12);position:relative;}' +
'.hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:26px;border-bottom:3px solid #0f172a;padding-bottom:18px;}' +
'.shop-name{font-size:1.55rem;font-weight:900;color:#0f172a;}.shop-sub{font-size:0.76rem;color:#64748b;margin-top:4px;}' +
'.inv-title{text-align:right;}.inv-title h2{font-size:1rem;font-weight:900;color:#0f172a;text-transform:uppercase;letter-spacing:2px;}' +
'.inv-no{font-size:1.6rem;font-weight:900;color:#6366f1;margin-top:4px;}' +
'.meta{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:22px;background:#f8fafc;border-radius:10px;padding:14px;border:1px solid #e2e8f0;}' +
'.meta label{font-size:0.63rem;font-weight:800;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;display:block;margin-bottom:3px;}' +
'.meta span{font-size:0.87rem;font-weight:700;color:#1e293b;}' +
'table{width:100%;border-collapse:collapse;margin-bottom:18px;}' +
'thead tr{background:#0f172a;}thead th{padding:10px 8px;font-size:0.7rem;font-weight:800;color:#fff;text-transform:uppercase;letter-spacing:.8px;text-align:left;}' +
'thead th:nth-child(3){text-align:center;}thead th:nth-child(4),thead th:nth-child(5){text-align:right;}' +
'tbody tr:nth-child(even){background:#f8fafc;}' +
'.tw{display:flex;justify-content:flex-end;margin-top:6px;}.tb{width:270px;}' +
'.tr{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #e2e8f0;font-size:0.85rem;}' +
'.tg{font-size:1rem;font-weight:900;color:#0f172a;border-bottom:2px solid #0f172a;padding:10px 0;display:flex;justify-content:space-between;}' +
'.badge{display:inline-block;padding:4px 14px;border-radius:20px;font-size:0.72rem;font-weight:800;text-transform:uppercase;letter-spacing:1px;}' +
'.ftr{margin-top:36px;border-top:1px solid #e2e8f0;padding-top:14px;display:flex;justify-content:space-between;color:#94a3b8;font-size:0.7rem;}' +
'.wm{position:absolute;bottom:80px;right:36px;font-size:3.5rem;font-weight:900;color:rgba(99,102,241,.05);transform:rotate(-15deg);pointer-events:none;letter-spacing:4px;}' +
'@media print{body{background:white;padding:0;}.page{box-shadow:none;}.no-print{display:none!important;}}' +
'</style></head><body><div class="page">' +
'<div class="wm">MEC ERP</div>' +
'<div class="hdr">' +
'  <div><div class="shop-name">' + storeName + '</div><div class="shop-sub">' + storeAddress + sep + storePhone + '</div></div>' +
'  <div class="inv-title"><h2>Supplier Invoice</h2><div class="inv-no">#' + (inv.invoiceNo || '—') + '</div>' +
'    <div style="margin-top:8px;"><span class="badge" style="background:' + statusColor + '22;color:' + statusColor + ';border:1px solid ' + statusColor + '44;">' + status + '</span></div></div>' +
'</div>' +
'<div class="meta">' +
'  <div><label>Supplier</label><span>' + (inv.supplierName || '—') + '</span></div>' +
'  <div><label>Posting Date</label><span>' + (inv.date || '—') + '</span></div>' +
'  <div><label>Payment Method</label><span>' + methodLabel + chequeLine + '</span></div>' +
'  <div><label>Amount Paid</label><span style="color:#16a34a;">LKR ' + paid.toFixed(2) + '</span></div>' +
'</div>' +
'<table>' +
'  <thead><tr><th style="width:30px;">#</th><th>Item Description</th><th style="text-align:center;width:60px;">Qty</th><th style="text-align:right;width:120px;">Unit Cost</th><th style="text-align:right;width:130px;">Total Cost</th></tr></thead>' +
'  <tbody>' + itemRows + '</tbody>' +
'</table>' +
'<div class="tw"><div class="tb">' +
'  <div class="tg"><span>Grand Total</span><span>LKR ' + total.toFixed(2) + '</span></div>' +
'  <div class="tr"><span>Amount Paid</span><span style="color:#16a34a;">LKR ' + paid.toFixed(2) + '</span></div>' +
'  <div class="tr" style="font-weight:800;color:' + statusColor + ';"><span>' + (balance > 0 ? 'Balance Due' : 'Overpaid') + '</span><span>LKR ' + Math.abs(balance).toFixed(2) + '</span></div>' +
'</div></div>' +
'<div style="margin-top:20px;padding:12px 16px;background:' + statusColor + '11;border-radius:8px;border-left:4px solid ' + statusColor + ';display:flex;justify-content:space-between;align-items:center;">' +
'  <span style="font-size:0.8rem;color:' + statusColor + ';font-weight:700;">Payment Status: ' + status + '</span>' +
'  <span style="font-size:0.7rem;color:#6b7280;">Generated: ' + new Date().toLocaleString() + '</span>' +
'</div>' +
'<div class="ftr"><div>Computer generated document — No signature required.</div><div>' + storeName + ' &copy; ' + new Date().getFullYear() + '</div></div>' +
'<div class="no-print" style="text-align:center;margin-top:30px;">' +
'  <button onclick="window.print()" style="background:#0f172a;color:white;border:none;padding:14px 40px;border-radius:10px;font-size:1rem;font-weight:800;cursor:pointer;margin-right:12px;">🖨️ Print / Save PDF</button>' +
'  <button onclick="window.close()" style="background:#f1f5f9;color:#374151;border:1px solid #e5e7eb;padding:14px 30px;border-radius:10px;font-size:1rem;font-weight:700;cursor:pointer;">✕ Close</button>' +
'</div>' +
'</div></body></html>';

    // Use a hidden iframe to print to bypass browser popup blockers and "about:" protocols
    let iframe = document.getElementById('sinv-print-iframe');
    if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'sinv-print-iframe';
        iframe.style.position = 'fixed';
        iframe.style.top = '-9999px';
        iframe.style.left = '-9999px';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = 'none';
        document.body.appendChild(iframe);
    }
    
    const doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(printHTML);
    doc.close();
    
    setTimeout(() => {
        try {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        } catch (e) {
            console.error("Iframe print error:", e);
            window.showToast('Failed to open print dialog.', 'error');
        }
    }, 500);
};

window.showSupplierInvoiceDetails = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const balance = total - paid;
    const status = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));
    const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque';
    const methodLabel = isCheque ? '🧾 Cheque' : ((inv.paymentMethod || '').toLowerCase() === 'bank' ? '🏦 Bank Transfer' : ((inv.paymentMethod || '').toLowerCase() === 'credit' ? '⏳ Credit' : '💵 Cash'));
    const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();

    const noEl = document.getElementById('sinv-detail-no');
    const supEl = document.getElementById('sinv-detail-supplier');
    const dateEl = document.getElementById('sinv-detail-date');
    const methodEl = document.getElementById('sinv-detail-method');
    const itemsBody = document.getElementById('sinv-detail-items-body');
    const totalEl = document.getElementById('sinv-detail-total');
    const paidEl = document.getElementById('sinv-detail-paid');
    const balLabelEl = document.getElementById('sinv-detail-balance-label');
    const balEl = document.getElementById('sinv-detail-balance');

    if (noEl) noEl.innerText = inv.invoiceNo || '—';
    if (supEl) supEl.innerText = inv.supplierName || '—';
    if (dateEl) dateEl.innerText = dateStr;
    if (methodEl) methodEl.innerText = methodLabel + (isCheque && inv.chequeDate ? ` (Cheque Date: ${inv.chequeDate})` : '');
    if (totalEl) totalEl.innerText = 'LKR ' + total.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    if (paidEl) paidEl.innerText = 'LKR ' + paid.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    if (balLabelEl) balLabelEl.innerText = balance >= 0 ? 'Balance Due:' : 'Overpaid:';
    if (balEl) {
        balEl.innerText = 'LKR ' + Math.abs(balance).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        balEl.style.color = balance > 0 ? '#ef4444' : '#10b981';
    }

    if (itemsBody) {
        itemsBody.innerHTML = (inv.items || []).map(function(item, i) {
            const cost = parseFloat(item.buying || item.buyingPrice || item.cost || item.netCost || 0);
            const qty  = parseFloat(item.qty || item.quantity || 0);
            const lineTotal = parseFloat(item.totalCost || item.total || (cost * qty) || 0);
            const desc = [item.sku ? 'SKU: ' + item.sku : '', item.variant || item.variantLabel || ''].filter(Boolean).join(' | ');
            return `
                <tr style="border-bottom:1px solid rgba(255,255,255,0.05);">
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc;">${i + 1}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; font-weight:600;">
                        ${item.name || '—'}
                        ${desc ? `<br><span style="font-size:0.7rem; color:#94a3b8; font-weight:400;">${desc}</span>` : ''}
                    </td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:center;">${qty}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:right;">LKR ${cost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                    <td style="padding:12px 10px; font-size:0.85rem; color:#f8fafc; text-align:right; font-weight:700;">LKR ${lineTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                </tr>
            `;
        }).join('');
    }

    const modal = document.getElementById('supplier-invoice-detail-modal');
    if (modal) modal.style.display = 'flex';
};

window.populateSupplierInvoicesDropdown = () => {
    const select = document.getElementById('sinv-supplier-id');
    if (!select) return;
    
    const prevVal = select.value;
    // Use the global list and our standardized filter for backward compatibility
    const suppliers = window.filterByStore(window.allSuppliers || []);
    
    select.innerHTML = '<option value="">-- Choose Supplier --</option>';
    suppliers.forEach(sup => {
        select.innerHTML += `<option value="${sup.docId}">${sup.name}</option>`;
    });

    if (prevVal) {
        select.value = prevVal;
    }

    // Attach persistence listeners to SINV header inputs once
    if (!window._sinvInputsBound) {
        window._sinvInputsBound = true;
        ['sinv-no', 'sinv-date', 'sinv-pay-method', 'sinv-paid'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('input', () => window.saveSinvDraft?.());
                el.addEventListener('change', () => window.saveSinvDraft?.());
            }
        });
        if (select) {
            select.addEventListener('change', () => window.saveSinvDraft?.());
        }
    }

    // If draft exists and not loaded yet, attempt restoration
    if ((!window.currentInvoiceItems || window.currentInvoiceItems.length === 0) && typeof window.loadSinvDraft === 'function') {
        window.loadSinvDraft();
    }
};

window.enterSupplierInvoiceNativeFS = () => {
    const el = document.getElementById('supplier-invoices-add-view');
    if (!el) return;

    if (typeof window.loadSinvDraft === 'function' && (!window.currentInvoiceItems || window.currentInvoiceItems.length === 0)) {
        window.loadSinvDraft();
    }
    
    // [NEW] Stock Entry Splash Screen Sequence
    const splash = document.getElementById('sinv-terminal-splash');
    if (splash) {
        splash.style.display = 'flex';
        splash.style.opacity = '1';
        setTimeout(() => {
            splash.style.transition = 'opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
            splash.style.opacity = '0';
            setTimeout(() => {
                splash.style.display = 'none';
            }, 400);
        }, 800);
    }

    // Add immersive class
    el.classList.add('native-fs');
    document.body.classList.add('pos-fullscreen-mode');
    
    const btn = document.getElementById('sinv-fs-btn');
    if (btn) btn.innerHTML = '🗗 EXIT FULLSCREEN';
    
    // Auto focus search
    setTimeout(() => {
        const searchInput = document.getElementById('sinv-search');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }, 1300);
};

window.exitSupplierInvoiceNativeFS = () => {
    const el = document.getElementById('supplier-invoices-add-view');
    if (!el) return;
    
    el.classList.remove('native-fs');
    document.body.classList.remove('pos-fullscreen-mode');
    
    const btn = document.getElementById('sinv-fs-btn');
    if (btn) btn.innerHTML = '🖥️ FULLSCREEN';
    
    // Exit true browser fullscreen (Disabled to match enter function)
    // try {
    //     if (document.fullscreenElement || document.webkitFullscreenElement) {
    //         if (document.exitFullscreen) document.exitFullscreen();
    //         else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    //     }
    // } catch (e) { console.warn("FS Exit Denied:", e); }
};

window.openVariantPickerForSINV = (name) => {
    // products sharing the same name (top-level doc per variant from products collection)
    const products = (window.allProducts || []).filter(p => (p.name || '').trim() === name);
    if (products.length === 0) return;

    // Collect ALL internal batch variants from all matching products
    const allBatches = [];
    products.forEach(p => {
        const internalVariants = p.variants || [];
        if (internalVariants.length > 0) {
            internalVariants.forEach((v, idx) => {
                allBatches.push({
                    docId: p.docId,
                    image: p.image,
                    sku: v.sku || p.sku,
                    batchLabel: v.variantLabel || v.supplierName || `Batch ${idx + 1}`,
                    cost: v.buyingPrice || v.cost || 0,
                    mrp: v.sellingPrice || p.price || 0,
                    stock: v.stock || 0,
                    variantId: v.variantId,
                    supplierName: v.supplierName || '',
                    addedDate: v.addedDate || ''
                });
            });
        } else {
            // No internal variants – treat the product itself as one batch
            allBatches.push({
                docId: p.docId,
                image: p.image,
                sku: p.sku,
                batchLabel: 'Standard',
                cost: p.cost || 0,
                mrp: p.price || 0,
                stock: p.stock || 0,
                variantId: null,
                supplierName: '',
                addedDate: ''
            });
        }
    });

    const totalStock = allBatches.reduce((s, b) => s + b.stock, 0);
    const lastMRP = allBatches.length > 0 ? allBatches[allBatches.length - 1].mrp : 0;

    const overlay = document.createElement('div');
    overlay.id = "sinv-variant-picker-overlay";
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:10000000; display:flex; align-items:center; justify-content:center; backdrop-filter: blur(8px); animation: fadeIn 0.2s ease;";
    overlay.onclick = (e) => { if(e.target === overlay) overlay.remove(); };
    
    const content = document.createElement('div');
    content.style = "width: 560px; max-height: 85vh; overflow-y: auto; padding: 25px; border-radius: 28px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 25px 100px rgba(0,0,0,0.8); position: relative; animation: slideUp 0.3s ease-out;";
    
    content.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; position: sticky; top: 0; background: #0f172a; padding: 10px 0; z-index: 10;">
            <div>
                <h3 style="margin: 0; font-size: 1.4rem; font-weight: 900; color: #fff; letter-spacing: -0.5px;">${name}</h3>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">${allBatches.length} BATCH${allBatches.length > 1 ? 'ES' : ''} &nbsp;•&nbsp; TOTAL STOCK: <span style="color:#10b981;font-weight:800;">${totalStock}</span> &nbsp;•&nbsp; LAST MRP: <span style="color:#fbbf24;font-weight:800;">LKR ${lastMRP.toLocaleString()}</span></div>
            </div>
            <button onclick="this.closest('#sinv-variant-picker-overlay').remove()" style="background: rgba(255,255,255,0.05); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">✕</button>
        </div>

        <!-- Summary bar -->
        <div style="display:flex; gap:10px; margin-bottom:18px; padding:12px 16px; background:rgba(56,189,248,0.06); border:1px solid rgba(56,189,248,0.15); border-radius:14px;">
            ${allBatches.map((b, i) => `
                <div style="flex:1; text-align:center; padding:8px; background:rgba(255,255,255,0.03); border-radius:10px; border:1px solid rgba(255,255,255,0.06);">
                    <div style="font-size:0.6rem; color:#64748b; font-weight:700; letter-spacing:0.5px;">BATCH ${i + 1}</div>
                    <div style="font-size:1.1rem; font-weight:900; color:${b.stock < 5 ? '#ef4444' : '#10b981'}; margin:4px 0;">${b.stock}</div>
                    <div style="font-size:0.65rem; color:#38bdf8; font-weight:700;">MRP ${b.mrp.toLocaleString()}</div>
                    <div style="font-size:0.6rem; color:#94a3b8;">COST ${b.cost.toLocaleString()}</div>
                </div>
            `).join('')}
        </div>

        <!-- SELECT heading -->
        <div style="font-size:0.7rem; color:#64748b; font-weight:700; letter-spacing:1px; margin-bottom:12px;">SELECT A BATCH TO ADD MORE STOCK →</div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
            ${products.map((v, pidx) => `
                <div class="variant-item-pick" onclick="window.selectVariantForSINV('${v.docId}')" 
                    style="padding: 16px 18px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 16px; cursor: pointer; transition: all 0.2s; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 14px;">
                        <div style="width: 38px; height: 38px; border-radius: 10px; overflow: hidden; background: #000; border: 1px solid rgba(255,255,255,0.1); flex-shrink:0;">
                            <img src="${v.image || '/logo.png'}" style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div>
                            <div style="font-weight: 800; color: #38bdf8; font-size: 0.95rem;">${v.size || 'Standard'}${v.color ? ` / ${v.color}` : ''}</div>
                            <div style="font-size: 0.65rem; color: #64748b; margin-top: 3px; font-family: monospace;">${v.sku || '-'}</div>
                            <div style="font-size: 0.65rem; color: #94a3b8; margin-top: 2px;">${(v.variants||[]).length} internal batch${(v.variants||[]).length !== 1 ? 'es' : ''}</div>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: 900; color: #fff; font-size: 1.05rem;">LKR ${(v.price || 0).toLocaleString()}</div>
                        <div style="font-size: 0.72rem; color: #38bdf8; font-weight: 800; margin-top: 2px;">COST: LKR ${(v.cost || 0).toLocaleString()}</div>
                        <div style="font-size: 0.68rem; color: ${(v.stock || 0) < 5 ? '#ef4444' : '#10b981'}; font-weight: 800; margin-top: 3px;">STOCK: ${v.stock || 0}</div>
                    </div>
                </div>
            `).join('')}
        </div>
        <style>
            .variant-item-pick:hover {
                background: rgba(56, 189, 248, 0.1) !important;
                border-color: #38bdf8 !important;
                transform: translateX(5px);
            }
        </style>
    `;
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
};

window.selectVariantForSINV = (docId) => {
    document.getElementById('sinv-variant-picker-overlay')?.remove();
    window.addToSupplierInvoice(docId);
};

window.sinvSelectedIndex = -1;
window.highlightSINVSearchItem = (items) => {
    for (let i = 0; i < items.length; i++) {
        if (i === window.sinvSelectedIndex) {
            items[i].classList.add('selected');
            items[i].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            items[i].classList.remove('selected');
        }
    }
};

window.poSelectedIndex = -1;
window.highlightPOSearchItem = (items) => {
    for (let i = 0; i < items.length; i++) {
        if (i === window.poSelectedIndex) {
            items[i].style.background = 'rgba(56, 189, 248, 0.15)';
            items[i].style.borderLeft = '4px solid #38bdf8';
            items[i].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            items[i].style.background = 'transparent';
            items[i].style.borderLeft = '4px solid transparent';
        }
    }
};

window.handleSINVSearch = (val) => {
    console.log(`[SINV Debug] handleSINVSearch triggered with val: "${val}"`);
    const listDiv = document.getElementById('sinv-product-list');
    if (!listDiv) return;
    
    window.sinvSelectedIndex = -1;
    
    if (!window.allProducts || window.allProducts.length === 0) {
        console.warn("[SINV Debug] Catalog is empty during search.");
        listDiv.innerHTML = '<div style="color: #64748b; text-align: center; padding: 20px;">Loading catalog...</div>';
        return;
    }

    const q = (val || "").toLowerCase().trim();
    const sq = window.toSinhala ? window.toSinhala(val) : "";
    
    const filtered = (window.allProducts || []).filter(p => {
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return (p.name && (p.name.toLowerCase().includes(q) || (sq && p.name.includes(sq)))) || 
               window.matchProductSku(p.sku, q) ||
               matchesVariantSku;
    }).sort((a, b) => {
        const aStarts = a.name?.toLowerCase().startsWith(q) || a.sku?.toLowerCase().startsWith(q);
        const bStarts = b.name?.toLowerCase().startsWith(q) || b.sku?.toLowerCase().startsWith(q);
        if (aStarts && !bStarts) return -1;
        if (!aStarts && bStarts) return 1;
        return 0;
    });

    // Group by name
    const grouped = new Map();
    filtered.forEach(p => {
        const name = (p.name || '').trim();
        if (!grouped.has(name)) grouped.set(name, []);
        grouped.get(name).push(p);
    });

    listDiv.innerHTML = '';
    if (filtered.length === 0 && q) {
        listDiv.innerHTML = `
            <div style="color: #64748b; text-align: center; padding: 20px; border: 1px dashed rgba(255,255,255,0.1); border-radius: 12px; animation: fadeIn 0.3s ease;">
                <p style="margin-bottom: 12px; font-size: 0.85rem;">Not in catalog: "${val}"</p>
                <button onclick="window.openSINVQuickProductModal('${val.replace(/'/g, "\\'")}')" 
                    style="background: #38bdf8; color: #0f172a; border: none; padding: 10px 18px; border-radius: 8px; font-weight: 900; cursor: pointer; font-size: 0.75rem; letter-spacing: 0.5px;">
                    ➕ ADD AS NEW PRODUCT
                </button>
            </div>`;
    }

    grouped.forEach((variants, name) => {
        const first = variants[0];
        const hasMultiple = variants.length > 1;
        
        const itemDiv = document.createElement('div');
        itemDiv.className = 'pos-v2-item sinv-search-item';
        itemDiv.onmouseover = () => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            window.sinvSelectedIndex = Array.from(items).indexOf(itemDiv);
            window.highlightSINVSearchItem(items);
        };
        itemDiv.onmouseout = () => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            const idx = Array.from(items).indexOf(itemDiv);
            if (window.sinvSelectedIndex !== idx) {
                itemDiv.classList.remove('selected');
            }
        };
        
        // Calculate price and batch info across all variants
        let retailPrice = 0;
        let totalStock = 0;
        
        // Find best retail price from top-level or child batches
        if (first.price !== undefined && first.price !== null && first.price !== '') {
            retailPrice = parseFloat(first.price) || 0;
        } else if (first.sellingPrice !== undefined && first.sellingPrice !== null && first.sellingPrice !== '') {
            retailPrice = parseFloat(first.sellingPrice) || 0;
        } else if (first.mrp !== undefined && first.mrp !== null && first.mrp !== '') {
            retailPrice = parseFloat(first.mrp) || 0;
        }

        // Check variants array for more accurate latest selling price if 0
        variants.forEach(p => {
            const pVariants = p.variants || [];
            if (pVariants.length > 0) {
                pVariants.forEach(v => {
                    totalStock += (parseFloat(v.stock) || 0);
                    if (!retailPrice) {
                        const vp = v.sellingPrice || v.price || v.mrp;
                        if (vp) retailPrice = parseFloat(vp) || 0;
                    }
                });
            } else {
                totalStock += (parseFloat(p.stock) || 0);
                if (!retailPrice) {
                    const pp = p.price || p.sellingPrice || p.mrp;
                    if (pp) retailPrice = parseFloat(pp) || 0;
                }
            }
        });

        const formattedPrice = (retailPrice > 0) 
            ? retailPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) 
            : '0.00';

        const defaultImg = '/logo.png';
        const imgSrc = (first.image && !first.image.includes('/logo.png') && !first.image.includes('zenith_logo')) ? first.image : defaultImg;

        // POS Terminal Card Template
        itemDiv.innerHTML = `
            <div class="img-box">
                <img src="${imgSrc}" loading="lazy" decoding="async" onerror="this.src='${defaultImg}';">
            </div>
            <div class="info-box">
                <span class="name" title="${name}">${name}</span>
                <div class="price">
                    <span style="font-size: 0.72rem; color: #94a3b8; font-weight: 700; margin-right: 2px;">LKR</span>${formattedPrice}
                </div>
                <div class="stock-badge" style="color: ${hasMultiple ? '#38bdf8' : (totalStock < 5 ? '#ef4444' : '#10b981')};">
                    ${hasMultiple ? `${variants.length} Batches` : `Stock: ${totalStock}`}
                </div>
            </div>
        `;
        
        itemDiv.onclick = (e) => {
            e.stopPropagation();
            if (hasMultiple) {
                window.openVariantPickerForSINV(name);
            } else {
                window.addToSupplierInvoice(first.docId);
            }
        };
        listDiv.appendChild(itemDiv);
    });

    const searchInput = document.getElementById('sinv-search');
    if (searchInput) {
        searchInput.onkeydown = (e) => {
            const items = listDiv.querySelectorAll('.sinv-search-item');
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (items.length > 0) {
                    window.sinvSelectedIndex = (window.sinvSelectedIndex + 1) % items.length;
                    window.highlightSINVSearchItem(items);
                }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (items.length > 0) {
                    window.sinvSelectedIndex = (window.sinvSelectedIndex - 1 + items.length) % items.length;
                    window.highlightSINVSearchItem(items);
                }
            } else if (e.key === 'Enter') {
                if (window.sinvSelectedIndex >= 0 && window.sinvSelectedIndex < items.length) {
                    e.preventDefault();
                    items[window.sinvSelectedIndex].click();
                    searchInput.value = '';
                    window.handleSINVSearch('');
                } else if (items.length > 0) {
                    e.preventDefault();
                    items[0].click();
                    searchInput.value = '';
                    window.handleSINVSearch('');
                }
            }
        };
    }
};

window.openSINVQuickProductModal = (suggestedName = '') => {
    const modal = document.getElementById('sinv-quick-product-modal');
    if (modal) {
        if (window.allCategories && window.populateCategoryDropdowns) {
            window.populateCategoryDropdowns(window.allCategories);
        }
        modal.style.display = 'flex';
        const nameInput = document.getElementById('qa-prod-name');
        if (nameInput) {
            nameInput.value = suggestedName || '';
            setTimeout(() => {
                nameInput.focus();
                if (suggestedName) {
                    nameInput.select();
                }
            }, 100);
        }
    }
};

window.addNewItemToInvoice = (suggestedName) => {
    window.openSINVQuickProductModal(suggestedName);
};


window.openSupplierItemModal = () => {
    const modal = document.getElementById('supplier-item-modal');
    if (modal) {
        modal.style.display = 'flex';
        modal.style.zIndex = '9999999';
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        console.log("Modal opened successfully");
        
        // Auto-focus Quantity for speed
        setTimeout(() => {
            const qtyInput = document.getElementById('sinv-item-qty');
            if (qtyInput) {
                qtyInput.focus();
                qtyInput.select();
            }
        }, 100);

        // Enter key to confirm inside modal
        modal.onkeydown = (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                window.confirmAddInvoiceItem();
            }
        };
    } else {
        alert("Error: supplier-item-modal not found");
    }
};

window.closeSupplierItemModal = () => {
    const modal = document.getElementById('supplier-item-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    window.quickStockAddMode = false;
    window.quickStockAddVariantId = null;
    window._sinvRefBuying = 0;
    window._sinvRefRetail = 0;
    
    const stockBadge = document.getElementById('sinv-modal-stock-badge');
    if (stockBadge) stockBadge.style.display = 'none';

    // Hide current price panel
    const priceWrap = document.getElementById('sinv-current-price-wrap');
    if (priceWrap) priceWrap.style.display = 'none';
    
    // Clear inputs safely for next entry
    const ids = ['sinv-item-search','sinv-item-id','sinv-item-qty','sinv-item-buying','sinv-item-disc','sinv-item-net-cost','sinv-item-retail','sinv-item-sd', 'sinv-item-loyalty', 'sinv-item-wholesale', 'sinv-item-serial', 'sinv-item-expiry', 'sinv-item-warranty', 'sinv-item-variant', 'sinv-item-code'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = (id === 'sinv-item-qty' ? '1' : (id === 'sinv-item-net-cost' ? 'Rs 0.00' : ''));
    });
};

window.addToSupplierInvoice = (docId) => {
    console.log(`[SINV Debug] addToSupplierInvoice triggered for docId: ${docId}`);
    // [v3.12.18] Reset quick modes to ensure we are in Batch Mode
    window.quickStockAddMode = false;
    window.quickStockAddVariantId = null;

    try {
        if (!docId) return;
        const p = (window.allProducts || []).find(x => x.docId === docId);
        if (!p) {
            console.error(`[SINV Debug] Product not found in addToSupplierInvoice for docId: ${docId}`);
            return;
        }

        window.showToast(`Selected: ${p.name}`, "info");
        window.selectProductForInvoice(docId);
        window.openSupplierItemModal();
    } catch (e) {
        console.error(e);
        alert("Error selecting product: " + e.message);
    }
};

window.selectProductForInvoice = (docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;

    // 1. Basic Info
    const displayName = p.name + (p.size ? ` (${p.size})` : '') + (p.color ? ` (${p.color})` : '');
    document.getElementById('sinv-modal-product-name').innerText = displayName;
    document.getElementById('sinv-modal-sku-badge').innerText = `SKU: ${p.sku || 'N/A'}`;
    document.getElementById('sinv-item-id').value = docId;
    document.getElementById('sinv-item-name').value = displayName;
    document.getElementById('sinv-item-code').value = p.sku || '';
    
    // 2. Default Prices – use the MOST RECENT batch prices if variants exist
    let lastCost = p.cost || 0;
    let lastRetail = p.price || 0;
    let lastWholesale = p.wholesalePrice || 0;
    let lastLoyalty = p.loyaltyPrice || 0;
    if (p.variants && p.variants.length > 0) {
        const sorted = [...p.variants].sort((a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0));
        const latest = sorted[0];
        lastCost = latest.buyingPrice || latest.cost || lastCost;
        lastRetail = latest.sellingPrice || lastRetail;
        lastWholesale = latest.wholesalePrice || lastWholesale;
        lastLoyalty = latest.loyaltyPrice || lastLoyalty;
    }
    document.getElementById('sinv-item-buying').value = lastCost;
    document.getElementById('sinv-item-retail').value = lastRetail;
    
    // Set editable new prices defaulting to current values
    document.getElementById('sinv-item-new-buying').value = lastCost;
    document.getElementById('sinv-item-new-retail').value = lastRetail;
    
    document.getElementById('sinv-item-wholesale').value = lastWholesale;
    document.getElementById('sinv-item-loyalty').value = lastLoyalty;
    document.getElementById('sinv-item-qty').value = 1;

    // 3. Show Current Price Panel (read-only reference bar)
    // Store the reference prices so checkSINVPriceMatch can compare
    window._sinvRefBuying = lastCost;
    window._sinvRefRetail = lastRetail;

    const priceWrap = document.getElementById('sinv-current-price-wrap');
    const buyingDisplay = document.getElementById('sinv-current-buying-display');
    const retailDisplay = document.getElementById('sinv-current-retail-display');

    if (priceWrap && buyingDisplay && retailDisplay) {
        // Only show if product already has a price on record
        if (lastCost > 0 || lastRetail > 0) {
            priceWrap.style.display = 'block';
            buyingDisplay.innerText = `LKR ${Number(lastCost).toFixed(2)}`;
            retailDisplay.innerText = `LKR ${Number(lastRetail).toFixed(2)}`;
        } else {
            priceWrap.style.display = 'none';
        }
    }

    // 4. Variant chips
    const variantWrap = document.getElementById('sinv-existing-variants-wrap');
    const variantList = document.getElementById('sinv-existing-variants-list');
    
    if (p.variants && p.variants.length > 0) {
        variantWrap.style.display = 'block';
        variantList.innerHTML = p.variants.map((v, idx) => `
            <div class="variant-chip" onclick="window.loadVariantPrices(${idx}, '${docId}')" 
                style="padding: 10px 15px; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 12px; cursor: pointer; display: flex; flex-direction: column; gap: 4px;">
                <span style="font-size: 0.65rem; font-weight: 800; color: #7dd3fc; opacity: 0.7;">${v.supplierName ? v.supplierName.substring(0, 15).toUpperCase() : `VARIANT ${idx + 1}`}</span>
                <span style="font-weight: 900; font-size: 0.9rem;">Cost: ${v.buyingPrice || v.cost || 0}</span>
                <span style="font-size: 0.7rem; opacity: 0.8;">Stk: ${v.stock || 0}</span>
            </div>
        `).join('');
    } else {
        variantWrap.style.display = 'none';
        variantList.innerHTML = '';
    }

    window.calcInvoiceLineTotal();
    window.checkSINVPriceMatch();
};

// Checks if entered prices match the existing record, shows badge accordingly
window.checkSINVPriceMatch = () => {
    const badge = document.getElementById('sinv-price-match-badge');
    const buyingInput = document.getElementById('sinv-item-new-buying');
    const retailInput = document.getElementById('sinv-item-new-retail');
    if (!badge || !buyingInput || !retailInput) return;

    const refBuying = window._sinvRefBuying || 0;
    const refRetail = window._sinvRefRetail || 0;
    const newBuying = parseFloat(buyingInput.value) || 0;
    const newRetail = parseFloat(retailInput.value) || 0;

    const buyingChanged = Math.abs(newBuying - refBuying) >= 0.01;
    const retailChanged = Math.abs(newRetail - refRetail) >= 0.01;

    if (buyingChanged || retailChanged) {
        badge.innerText = '⚠️ NEW PRICE — New Variant Batch will be created';
        badge.style.background = 'rgba(251,191,36,0.15)';
        badge.style.color = '#fbbf24';
        badge.style.borderColor = 'rgba(251,191,36,0.4)';
        // Highlight the buying/retail inputs to show they're "new"
        buyingInput.style.borderColor = buyingChanged ? 'rgba(251,191,36,0.6)' : '';
        retailInput.style.borderColor = retailChanged ? 'rgba(251,191,36,0.6)' : '';
    } else {
        badge.innerText = '✓ SAME PRICE — Stock will be added to existing';
        badge.style.background = 'rgba(16,185,129,0.15)';
        badge.style.color = '#10b981';
        badge.style.borderColor = 'rgba(16,185,129,0.3)';
        buyingInput.style.borderColor = '';
        retailInput.style.borderColor = '';
    }
};

window.loadVariantPrices = (idx, docId) => {
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p || !p.variants || !p.variants[idx]) return;
    
    const v = p.variants[idx];
    document.getElementById('sinv-item-new-buying').value = v.buyingPrice || v.cost || 0;
    document.getElementById('sinv-item-new-retail').value = v.sellingPrice || v.price || 0;
    document.getElementById('sinv-item-wholesale').value = v.wholesalePrice || 0;
    document.getElementById('sinv-item-loyalty').value = v.loyaltyPrice || 0;
    
    window.calcInvoiceLineTotal();
    window.showToast(`✅ Loaded Variant ${idx+1} pricing`, "info");
};


window.calcInvoiceLineTotal = () => {
    const buying = parseFloat(document.getElementById('sinv-item-new-buying').value) || 0;
    const disc = parseFloat(document.getElementById('sinv-item-disc').value) || 0;
    const qty = parseFloat(document.getElementById('sinv-item-qty').value) || 1;
    const retail = parseFloat(document.getElementById('sinv-item-new-retail').value) || 0;
    
    // Net Cost and Total
    const net = buying * (1 - disc / 100);
    const totalCost = net * qty;
    const netEl = document.getElementById('sinv-item-net-cost');
    if (netEl) netEl.value = net.toFixed(2);
    
    // Profit Margin evaluation (Gross Margin Calculation)
    // Formula: (Selling Price - Cost) / Selling Price
    const profitMarginSpan = document.getElementById('sinv-profit-margin-display');
    if (profitMarginSpan) {
        if (retail > 0 && retail > net) {
            const profit = retail - net;
            const margin = (profit / retail) * 100; 
            profitMarginSpan.innerText = `${margin.toFixed(2)}%`;
            
            // Professional Margin Indicators
            if (margin >= 25) profitMarginSpan.style.color = '#10b981'; // Healthy Margin
            else if (margin >= 5) profitMarginSpan.style.color = '#fbbf24'; // Narrow Margin
            else profitMarginSpan.style.color = '#ef4444'; // Critical Margin
        } else {
            profitMarginSpan.innerText = '0.00%';
            profitMarginSpan.style.color = '#ef4444';
        }
    }
};

window.quickStockAddMode = false;
window.quickStockAddVariantId = null;

window.openQuickStockAdd = (docId, variantId = '') => {
    window.quickStockAddMode = true;
    window.quickStockAddVariantId = variantId;
    
    const p = window.allProducts.find(x => x.docId === docId);
    if (!p) return;

    window.selectProductForInvoice(docId);
    
    // If variantId is provided, auto-load that variant's prices
    if (variantId && p.variants) {
        const vIdx = p.variants.findIndex(v => v.variantId === variantId);
        if (vIdx !== -1) {
            window.loadVariantPrices(vIdx, docId);
        }
    }

    // Change Modal Title for clarity
    const modalTitle = document.getElementById('sinv-modal-product-name');
    if (modalTitle) modalTitle.innerText = "Direct Stock Addition";
    
    // Show Current Stock Badge
    const stockBadge = document.getElementById('sinv-modal-stock-badge');
    if (stockBadge) {
        let currentQty = p.stock || 0;
        if (variantId && p.variants) {
            const v = p.variants.find(vx => vx.variantId === variantId);
            if (v) currentQty = v.stock || 0;
        }
        stockBadge.innerText = `Current Stock: ${currentQty}`;
        stockBadge.style.display = 'inline-block';
    }
    
    window.openSupplierItemModal();
};

window.confirmAddInvoiceItem = async (keepOpen = false) => {
    console.log("[SINV Debug] confirmAddInvoiceItem triggered.");
    if (!window.allProducts || window.allProducts.length === 0) {
        console.warn("[SINV Debug] window.allProducts is empty or undefined!");
        window.showToast("Catalog is loading, please wait...", "warning");
        return;
    }

    const id = document.getElementById('sinv-item-id').value;
    const nameStr = document.getElementById('sinv-item-name').value.trim();
    const qty = parseFloat(document.getElementById('sinv-item-qty').value) || 0;
    const buying = parseFloat(document.getElementById('sinv-item-new-buying').value) || 0;
    const disc = parseFloat(document.getElementById('sinv-item-disc').value) || 0;
    const retail = parseFloat(document.getElementById('sinv-item-new-retail').value) || 0;
    const sd = parseFloat(document.getElementById('sinv-item-sd').value) || 0;
    const loyalty = parseFloat(document.getElementById('sinv-item-loyalty').value) || 0;
    const wholesale = parseFloat(document.getElementById('sinv-item-wholesale').value) || 0;
    
    const expiry = document.getElementById('sinv-item-expiry').value;
    const warranty = document.getElementById('sinv-item-warranty').value.trim();
    const sku = document.getElementById('sinv-item-code').value.trim();
    const variant = document.getElementById('sinv-item-variant').value.trim();

    if (!nameStr || qty <= 0) return window.showToast("Please enter a valid product and quantity.", "warning");

    const netCost = buying * (1 - disc / 100);
    const totalCost = netCost * qty;

    if (window.quickStockAddMode) {
        // DIRECT SAVE TO FIRESTORE
        try {
            const pRef = doc(db, "products", id);
            const p = window.allProducts.find(x => x.docId === id);
            if (!p) throw new Error("Product not found");

            if (window.quickStockAddVariantId) {
                // Update specific variant with Weighted Average Cost (WAC)
                const variants = [...(p.variants || [])];
                const vIdx = variants.findIndex(v => v.variantId === window.quickStockAddVariantId);
                if (vIdx !== -1) {
                    const oldStock = parseFloat(variants[vIdx].stock) || 0;
                    const oldCost = parseFloat(variants[vIdx].cost || variants[vIdx].buyingPrice) || 0;
                    const newTotalStock = oldStock + qty;
                    // WAC: (old_stock × old_cost + new_qty × new_cost) / total_stock
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (qty * buying)) / newTotalStock
                        : buying;
                    variants[vIdx].stock = newTotalStock;
                    variants[vIdx].cost = parseFloat(wacCost.toFixed(4));
                    variants[vIdx].buyingPrice = parseFloat(wacCost.toFixed(4));
                    variants[vIdx].sellingPrice = retail;
                    variants[vIdx].wholesalePrice = wholesale;
                    variants[vIdx].loyaltyPrice = loyalty;
                    variants[vIdx].expiry = expiry;
                    variants[vIdx].warranty = warranty;
                }
                await updateDoc(pRef, { variants });
            } else {
                // Update base product with Weighted Average Cost (WAC)
                const hasVariants = p.variants && p.variants.length > 0;
                const priceDiffers = Math.abs((p.cost || 0) - buying) >= 0.01 || Math.abs((p.price || 0) - retail) >= 0.01;

                if (hasVariants || priceDiffers) {
                    let variants = [...(p.variants || [])];
                    if (variants.length === 0 && (parseFloat(p.stock) || 0) > 0) {
                        const origPrice = parseFloat(p.price) || 0;
                        variants.push({
                            variantId: 'base-' + p.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: p.size || p.color || `Batch @ LKR ${origPrice.toFixed(2)}`,
                            buyingPrice: parseFloat(p.cost) || 0,
                            cost: parseFloat(p.cost) || 0,
                            sellingPrice: origPrice,
                            wholesalePrice: parseFloat(p.wholesalePrice) || origPrice,
                            loyaltyPrice: parseFloat(p.loyaltyPrice) || origPrice,
                            stock: parseFloat(p.stock) || 0,
                            sku: p.sku || '',
                            expiry: p.expiryDate || '',
                            warranty: p.warranty || '',
                            addedDate: p.addedDate || new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    // Look for variant with same price
                    const vIdx = variants.findIndex(v =>
                        Math.abs(Number(v.buyingPrice || v.cost) - buying) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - retail) < 0.01
                    );

                    if (vIdx !== -1) {
                        // Same price -> WAC merge
                        const oldVStock = parseFloat(variants[vIdx].stock) || 0;
                        const oldVCost = parseFloat(variants[vIdx].cost || variants[vIdx].buyingPrice) || 0;
                        const newTotalStock = oldVStock + qty;
                        const wacCost = newTotalStock > 0
                            ? ((oldVStock * oldVCost) + (qty * buying)) / newTotalStock
                            : buying;
                        variants[vIdx].stock = newTotalStock;
                        variants[vIdx].cost = parseFloat(wacCost.toFixed(4));
                        variants[vIdx].buyingPrice = parseFloat(wacCost.toFixed(4));
                        variants[vIdx].sellingPrice = retail;
                        variants[vIdx].wholesalePrice = wholesale;
                        variants[vIdx].loyaltyPrice = loyalty;
                        variants[vIdx].expiry = expiry;
                        variants[vIdx].warranty = warranty;
                    } else {
                        // Different price -> create new variant
                        variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: variant || `Batch @ LKR ${retail.toFixed(2)}`,
                            buyingPrice: buying,
                            cost: buying,
                            sellingPrice: retail,
                            wholesalePrice: wholesale,
                            loyaltyPrice: loyalty,
                            stock: qty,
                            sku: sku || p.sku || '',
                            expiry: expiry || '',
                            warranty: warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    const wacBaseCost = totalCalculatedStock > 0
                        ? variants.reduce((sum, v) => sum + ((parseFloat(v.cost || v.buyingPrice) || 0) * (parseFloat(v.stock) || 0)), 0) / totalCalculatedStock
                        : buying;

                    await updateDoc(pRef, {
                        variants: variants,
                        stock: totalCalculatedStock,
                        totalStock: totalCalculatedStock,
                        cost: parseFloat(wacBaseCost.toFixed(4)),
                        price: retail,
                        wholesalePrice: wholesale,
                        loyaltyPrice: loyalty,
                        expiryDate: expiry,
                        warranty: warranty
                    });
                } else {
                    // Update base product with Weighted Average Cost (WAC)
                    const oldStock = parseFloat(p.stock) || 0;
                    const oldCost = parseFloat(p.cost) || 0;
                    const newTotalStock = oldStock + qty;
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (qty * buying)) / newTotalStock
                        : buying;
                    await updateDoc(pRef, {
                        stock: newTotalStock,
                        cost: parseFloat(wacCost.toFixed(4)),
                        price: retail,
                        wholesalePrice: wholesale,
                        loyaltyPrice: loyalty,
                        expiryDate: expiry,
                        warranty: warranty
                    });
                }
            }

            // Success: Clean up
            window.quickStockAddMode = false;
            window.quickStockAddVariantId = null;
            
            window.closeSupplierItemModal();
            window.showToast("✅ Stock updated successfully!", "success");
            
            // Refresh product list globally
            if (typeof window.loadAllProducts === 'function') window.loadAllProducts();

        } catch (err) {
            console.error(err);
            window.showToast("Failed to update stock: " + err.message, "error");
        } finally {
            window.quickStockAddMode = false;
            window.quickStockAddVariantId = null;
            // Force table refresh in case it was partially updated
            if (typeof window.renderInvoiceItemsTable === 'function') window.renderInvoiceItemsTable();
        }
        return;
    }

    // BATCH MODE (Invoice)
    window.currentInvoiceItems.push({
        docId: id || 'NEW',
        sku: sku,
        name: nameStr,
        variant: variant,
        qty: qty,
        buying: buying,
        discount: disc,
        unitCost: netCost,
        totalCost: totalCost,
        retail: retail,
        sellingDiscount: sd,
        loyalty: loyalty,
        wholesale: wholesale,
        expiry: expiry,
        warranty: warranty
    });

    if (keepOpen) {
        document.getElementById('sinv-item-search').value = '';
        document.getElementById('sinv-item-id').value = '';
        
        const nameInput = document.getElementById('sinv-item-name');
        if (nameInput) {
            nameInput.value = '';
            nameInput.readOnly = false;
        }
        
        const skuInput = document.getElementById('sinv-item-code');
        if (skuInput) {
            skuInput.value = '';
            skuInput.readOnly = false;
        }
        
        document.getElementById('sinv-item-qty').value = '1';
        document.getElementById('sinv-item-new-buying').value = '';
        document.getElementById('sinv-item-new-retail').value = '';
        document.getElementById('sinv-item-disc').value = '0';
        document.getElementById('sinv-item-sd').value = '0';
        document.getElementById('sinv-item-wholesale').value = '';
        document.getElementById('sinv-item-loyalty').value = '';
        document.getElementById('sinv-item-variant').value = '';
        
        window.calcInvoiceLineTotal(); // Reset totals display
        
        // Let user search or type a new product name immediately
        document.getElementById('sinv-item-search').focus();
    } else {
        window.closeSupplierItemModal();
        setTimeout(() => document.getElementById('sinv-search')?.focus(), 300);
    }
    
    window.renderInvoiceItemsTable();
};

window.updateSinvCartQty = (index, newQty, inputEl) => {
    const qty = parseFloat(newQty) || 0;
    const item = window.currentInvoiceItems[index];
    if (!item) return;

    item.qty = qty;
    const discountRs = item.discountRs || 0;
    item.totalCost = Math.max(0, (item.unitCost * qty) - discountRs);
    item.discountedCost = item.totalCost;
    
    if (inputEl) {
        const tr = inputEl.closest('tr');
        if (tr) {
            const tdTotal = tr.querySelector('.sinv-total-cell');
            if (tdTotal) {
                tdTotal.innerText = item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2});
            }
        }
    }

    let grand = 0;
    window.currentInvoiceItems.forEach(i => grand += i.totalCost);
    const grandTotalEl = document.getElementById('sinv-grand-total');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;
};

// Update discount for a row item — called when either % or Rs input changes
window.updateSinvDiscount = (index, type, value, inputEl) => {
    const item = window.currentInvoiceItems[index];
    if (!item) return;

    const rawCost = item.unitCost * item.qty;
    const val = parseFloat(value) || 0;

    if (type === 'pct') {
        item.discountPct = Math.min(100, Math.max(0, val));
        item.discountRs = parseFloat(((rawCost * item.discountPct) / 100).toFixed(2));
    } else {
        item.discountRs = Math.min(rawCost, Math.max(0, val));
        item.discountPct = parseFloat(((item.discountRs / rawCost) * 100).toFixed(2));
    }

    item.totalCost = Math.max(0, rawCost - item.discountRs);
    item.discountedCost = item.totalCost;

    // Update sibling inputs in same row
    if (inputEl) {
        const tr = inputEl.closest('tr');
        if (tr) {
            const pctInput = tr.querySelector('.sinv-disc-pct');
            const rsInput  = tr.querySelector('.sinv-disc-rs');
            const totalCell = tr.querySelector('.sinv-total-cell');
            if (pctInput && type !== 'pct') pctInput.value = item.discountPct;
            if (rsInput  && type !== 'rs')  rsInput.value  = item.discountRs;
            if (totalCell) totalCell.innerText = item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2});
        }
    }

    // Recalculate grand total
    let grand = 0;
    window.currentInvoiceItems.forEach(i => grand += i.totalCost);
    const grandTotalEl = document.getElementById('sinv-grand-total');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;
    window.saveSinvDraft?.();
};

window.getSinvDraftStorageKey = () => {
    const storeId = (typeof window.getStoreId === 'function') ? window.getStoreId() : 'default';
    return `mec_sinv_draft_${storeId}`;
};

window.saveSinvDraft = () => {
    try {
        const key = window.getSinvDraftStorageKey();
        const invNoEl = document.getElementById('sinv-no');
        const supplierEl = document.getElementById('sinv-supplier-id');
        const dateEl = document.getElementById('sinv-date');
        const payMethodEl = document.getElementById('sinv-pay-method');
        const paidEl = document.getElementById('sinv-paid');

        const draft = {
            items: window.currentInvoiceItems || [],
            invoiceNo: invNoEl ? invNoEl.value : '',
            supplierId: supplierEl ? supplierEl.value : '',
            date: dateEl ? dateEl.value : '',
            paymentMethod: payMethodEl ? payMethodEl.value : '',
            paid: paidEl ? paidEl.value : '',
            updatedAt: Date.now()
        };

        if ((draft.items && draft.items.length > 0) || (draft.invoiceNo && draft.invoiceNo.trim())) {
            localStorage.setItem(key, JSON.stringify(draft));
        } else {
            localStorage.removeItem(key);
        }
    } catch (e) {
        console.warn("[SINV] Failed to save draft to localStorage:", e);
    }
};

window.loadSinvDraft = () => {
    try {
        const key = window.getSinvDraftStorageKey();
        const saved = localStorage.getItem(key);
        if (!saved) return false;
        const draft = JSON.parse(saved);
        if (!draft) return false;

        if (Array.isArray(draft.items) && draft.items.length > 0) {
            window.currentInvoiceItems = draft.items;
        }

        const invNoEl = document.getElementById('sinv-no');
        const supplierEl = document.getElementById('sinv-supplier-id');
        const dateEl = document.getElementById('sinv-date');
        const payMethodEl = document.getElementById('sinv-pay-method');
        const paidEl = document.getElementById('sinv-paid');

        if (invNoEl && draft.invoiceNo) invNoEl.value = draft.invoiceNo;
        if (supplierEl && draft.supplierId) supplierEl.value = draft.supplierId;
        if (dateEl && draft.date) dateEl.value = draft.date;
        if (payMethodEl && draft.paymentMethod) payMethodEl.value = draft.paymentMethod;
        if (paidEl && draft.paid !== undefined && draft.paid !== '') paidEl.value = draft.paid;

        window.renderInvoiceItemsTable(false);
        console.log(`[SINV] Draft restored with ${window.currentInvoiceItems.length} items`);
        return true;
    } catch (e) {
        console.warn("[SINV] Failed to restore draft:", e);
        return false;
    }
};

window.clearSinvDraft = () => {
    try {
        const key = window.getSinvDraftStorageKey();
        localStorage.removeItem(key);
    } catch (e) {
        console.warn("[SINV] Failed to clear draft storage:", e);
    }
};

window.renderInvoiceItemsTable = (triggerSave = true) => {
    const body = document.getElementById('sinv-items-body');
    if (!body) return;

    if (window.currentInvoiceItems.length === 0) {
        body.innerHTML = `<tr><td colspan="6" style="padding: 100px 0; text-align: center; color: rgba(255,255,255,0.2); font-weight: 800; font-size: 1rem;">No items added to this order.</td></tr>`;
    } else {
        body.innerHTML = '';
    }
    
    let grand = 0;

    window.currentInvoiceItems.forEach((item, index) => {
        // Ensure discount fields exist
        if (item.discountPct === undefined) item.discountPct = 0;
        if (item.discountRs  === undefined) item.discountRs  = 0;
        // Recalculate totalCost respecting discount
        const rawCost = item.unitCost * item.qty;
        item.totalCost = Math.max(0, rawCost - item.discountRs);
        item.discountedCost = item.totalCost;
        grand += item.totalCost;
        
        const tr = document.createElement('tr');
        tr.style.cssText = 'border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;';
        tr.onmouseover = () => tr.style.background = 'rgba(255,255,255,0.02)';
        tr.onmouseout = () => tr.style.background = 'transparent';

        tr.innerHTML = `
            <td style="padding: 18px 15px;">
                <div style="font-weight: 800; color: #fff; font-size: 1.05rem; letter-spacing: 0.3px;">${item.name}</div>
                <div style="font-size: 0.75rem; color: #64748b; font-family: 'JetBrains Mono', monospace; margin-top: 5px;">SKU: ${item.sku}</div>
            </td>
            <td style="padding: 15px; text-align: center; font-weight: 700; color: #94a3b8; font-size: 1.1rem;">${item.buying.toFixed(2)}</td>
            <td style="padding: 15px; text-align: center;">
                <input type="number" min="0" value="${item.qty}" step="any"
                    oninput="window.updateSinvCartQty(${index}, this.value, this)"
                    onblur="if(!this.value || this.value<=0) window.removeInvoiceItem(${index})"
                    style="background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 8px; border-radius: 12px; font-weight: 950; font-size: 1.2rem; border: 1px solid rgba(56, 189, 248, 0.2); width: 80px; text-align: center; outline: none;">
            </td>
            <td style="padding: 10px 15px; text-align: center; min-width: 160px;">
                <div style="display: flex; flex-direction: column; gap: 5px; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 4px; width: 100%;">
                        <input type="number" min="0" max="100" step="0.1" value="${item.discountPct || 0}"
                            class="sinv-disc-pct"
                            oninput="window.updateSinvDiscount(${index}, 'pct', this.value, this)"
                            style="background: rgba(245, 158, 11, 0.08); color: #f59e0b; padding: 6px 8px; border-radius: 8px; font-weight: 800; font-size: 0.9rem; border: 1px solid rgba(245, 158, 11, 0.25); width: 70px; text-align: center; outline: none;">
                        <span style="font-size: 0.75rem; color: #f59e0b; font-weight: 900;">%</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 4px; width: 100%;">
                        <input type="number" min="0" step="0.01" value="${item.discountRs || 0}"
                            class="sinv-disc-rs"
                            oninput="window.updateSinvDiscount(${index}, 'rs', this.value, this)"
                            style="background: rgba(245, 158, 11, 0.08); color: #fbbf24; padding: 6px 8px; border-radius: 8px; font-weight: 800; font-size: 0.9rem; border: 1px solid rgba(245, 158, 11, 0.25); width: 70px; text-align: center; outline: none;">
                        <span style="font-size: 0.75rem; color: #fbbf24; font-weight: 900;">Rs</span>
                    </div>
                </div>
            </td>
            <td class="sinv-total-cell" style="padding: 15px; text-align: right; font-weight: 950; color: #fff; font-size: 1.3rem; letter-spacing: 0.5px;">${item.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
            <td style="padding: 15px; text-align: right;">
                <button onclick="window.removeInvoiceItem(${index})" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #ef4444; padding: 10px 15px; border-radius: 12px; cursor: pointer; transition: all 0.2s; font-size: 1.2rem;">🗑️</button>
            </td>
        `;
        if (window.currentInvoiceItems.length > 0) body.appendChild(tr);
    });

    const grandTotalEl = document.getElementById('sinv-grand-total');
    const itemCountEl = document.getElementById('sinv-item-count');
    if (grandTotalEl) grandTotalEl.innerText = grand.toLocaleString(undefined, {minimumFractionDigits: 2});
    if (itemCountEl) itemCountEl.innerText = window.currentInvoiceItems.length.toString();

    const paidEl = document.getElementById('sinv-paid');
    if (paidEl) paidEl.value = grand;

    if (triggerSave && typeof window.saveSinvDraft === 'function') {
        window.saveSinvDraft();
    }

    // Auto-scroll to bottom
    const scrollParent = body.parentElement.parentElement;
    if (scrollParent) scrollParent.scrollTop = scrollParent.scrollHeight;
};

window.removeInvoiceItem = (index) => {
    window.currentInvoiceItems.splice(index, 1);
    window.renderInvoiceItemsTable();
};

window.saveSupplierInvoice = async () => {
    const invNoEl = document.getElementById('sinv-no');
    const supplierEl = document.getElementById('sinv-supplier-id');
    const dateEl = document.getElementById('sinv-date');
    const payMethodEl = document.getElementById('sinv-pay-method');
    const paidEl = document.getElementById('sinv-paid');

    const invNo = invNoEl?.value?.trim();
    const supplierId = supplierEl?.value;
    const date = dateEl?.value;
    const payMethod = payMethodEl?.value;
    const paid = parseFloat(paidEl?.value) || 0;
    
    console.log("Attempting to save invoice:", { invNo, supplierId, date, itemsCount: window.currentInvoiceItems?.length });

    if (!invNo || invNo === 'INV-...') {
        return window.showToast("Please enter an Invoice Reference number.", "warning");
    }
    if (!supplierId || supplierId === "" || supplierEl.selectedIndex === 0) {
        return window.showToast("Please select a Primary Supplier.", "warning");
    }
    if (!date) {
        return window.showToast("Please select a Posting Date.", "warning");
    }
    if (!window.currentInvoiceItems || window.currentInvoiceItems.length === 0) {
        return window.showToast("Please add at least one item to the invoice.", "warning");
    }

    const supplierTxt = supplierEl.options[supplierEl.selectedIndex].text;
    const storeId = window.getStoreId();
    let total = 0;
    window.currentInvoiceItems.forEach(i => total += i.totalCost);

    try {
        window.showToast("⏳ Processing Inventory Update...", "info");
        
        // 1. Add to supplierInvoices
        const isCheque = (payMethod || '').toLowerCase() === 'cheque';
        const chequeDate = isCheque ? (window._confirmedChequeDate || null) : null;
        // Cheque invoices are always Pending until cheque date passes (even if full amount noted)
        const invoiceStatus = isCheque ? 'Pending' :
            (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));

        const invData = {
            invoiceNo: invNo,
            supplierId: supplierId,
            supplierName: supplierTxt,
            date: date,
            paymentMethod: payMethod,
            paid: paid,
            paidAmount: paid,
            grandTotal: total,
            totalAmount: total,
            status: invoiceStatus,
            chequeDate: chequeDate,
            chequeStatus: isCheque ? 'pending' : null,
            items: window.currentInvoiceItems,
            storeId: storeId,
            timestamp: serverTimestamp()
        };
        
        const invRef = await addDoc(sinvoicesCol, invData);
        console.log("Invoice document created:", invRef.id);

        // 2. Update Products Stock and Variants Logic
        const batch = writeBatch(db);
        let updateCount = 0;
        
        // Track accumulated updates for existing products to prevent overwrites in the same batch
        const accumulatedUpdates = {};
        // Track newly created products to prevent duplicate docs for the same new SKU
        const newProductsMap = {};

        for (const item of window.currentInvoiceItems) {
            if (item.docId && item.docId !== 'NEW') {
                const pRef = doc(db, "products", item.docId);
                
                // Get from accumulated updates first, or fallback to allProducts
                let p = accumulatedUpdates[item.docId];
                if (!p) {
                    const originalP = (window.allProducts || []).find(x => x.docId === item.docId);
                    if (originalP) {
                        p = JSON.parse(JSON.stringify(originalP)); // Deep clone
                        accumulatedUpdates[item.docId] = p;
                    }
                }
                
                if (p) {
                    let variants = p.variants || [];
                    const incomingBuyingPrice = Number(item.buying);
                    const incomingRetailPrice = Number(item.retail);

                    // If variants is empty and the product has existing stock, convert the base stock to a variant first!
                    if (variants.length === 0 && (parseFloat(p.stock) || 0) > 0) {
                        variants.push({
                            variantId: 'base-' + p.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: p.supplierId || '',
                            supplierName: p.supplierName || 'General',
                            variantLabel: p.size || p.color || 'Existing Stock',
                            buyingPrice: parseFloat(p.cost) || 0,
                            cost: parseFloat(p.cost) || 0,
                            sellingPrice: parseFloat(p.price) || 0,
                            wholesalePrice: parseFloat(p.wholesalePrice) || 0,
                            loyaltyPrice: parseFloat(p.loyaltyPrice) || 0,
                            stock: parseFloat(p.stock) || 0,
                            sku: p.sku || '',
                            expiry: p.expiryDate || '',
                            warranty: p.warranty || '',
                            addedDate: p.addedDate || new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    // SMART BATCH LOGIC:
                    const existingVariantIndex = variants.findIndex(v =>
                        v.supplierId === supplierId &&
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                    );

                    if (existingVariantIndex !== -1) {
                        // Same price → WAC merge into existing batch
                        const oldStock = parseFloat(variants[existingVariantIndex].stock) || 0;
                        variants[existingVariantIndex].stock = oldStock + Number(item.qty);
                        variants[existingVariantIndex].lastUpdated = Date.now();
                    } else {
                        // Different price → NEW batch/variant
                        variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: incomingBuyingPrice,
                            cost: incomingBuyingPrice,
                            sellingPrice: incomingRetailPrice,
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }

                    const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    
                    // Update our accumulated record
                    p.variants = variants;
                    p.stock = totalCalculatedStock;
                    p.totalStock = totalCalculatedStock;
                    p.cost = incomingBuyingPrice; // update latest cost
                    p.price = incomingRetailPrice; // update latest price
                    
                    // Note: We'll do the actual batch.update() outside the loop!
                }
            } else if (item.docId === 'NEW') {
                const skuKey = (item.sku || ('temp-' + Date.now())).toLowerCase();
                
                // If we already created a new product for this SKU in the SAME invoice, just add as a variant
                if (newProductsMap[skuKey]) {
                    const existingNewP = newProductsMap[skuKey];
                    const existingVariantIndex = existingNewP.variants.findIndex(v =>
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - Number(item.buying)) < 0.01
                    );
                    
                    if (existingVariantIndex !== -1) {
                        existingNewP.variants[existingVariantIndex].stock += Number(item.qty);
                    } else {
                        existingNewP.variants.push({
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5), 
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: Number(item.buying),
                            sellingPrice: Number(item.retail),
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        });
                    }
                    existingNewP.stock += Number(item.qty);
                    existingNewP.totalStock += Number(item.qty);
                } else {
                    const pRef = doc(collection(db, "products"));
                    newProductsMap[skuKey] = {
                        ref: pRef,
                        name: item.name,
                        sku: item.sku || '',
                        cost: Number(item.buying),
                        price: Number(item.retail),
                        stock: Number(item.qty),
                        totalStock: Number(item.qty),
                        mode: "Shop", // ADDED MODE HERE
                        variants: [{
                            variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5), 
                            supplierId: supplierId,
                            supplierName: supplierTxt,
                            variantLabel: item.variant || '',
                            buyingPrice: Number(item.buying),
                            sellingPrice: Number(item.retail),
                            wholesalePrice: Number(item.wholesale || 0),
                            loyaltyPrice: Number(item.loyalty || 0),
                            stock: Number(item.qty),
                            sku: item.sku || '',
                            expiry: item.expiry || '',
                            warranty: item.warranty || '',
                            addedDate: new Date().toISOString(),
                            lastUpdated: Date.now()
                        }],
                        category: "General",
                        brand: "SINV Auto-Added",
                        storeId: storeId,
                        lastUpdated: serverTimestamp(),
                        timestamp: serverTimestamp()
                    };
                }
            }
        }
        
        // Execute accumulated updates
        for (const [docId, pData] of Object.entries(accumulatedUpdates)) {
            const pRef = doc(db, "products", docId);
            batch.update(pRef, {
                variants: pData.variants,
                stock: pData.stock,
                totalStock: pData.totalStock,
                cost: pData.cost,
                price: pData.price,
                lastStockUpdate: serverTimestamp(),
                lastUpdated: serverTimestamp()
            });
            updateCount++;
        }
        
        // Execute accumulated new products
        for (const [skuKey, newPData] of Object.entries(newProductsMap)) {
            const pRef = newPData.ref;
            delete newPData.ref; // remove ref from data
            batch.set(pRef, newPData);
            updateCount++;
        }
        
        await batch.commit();
        console.log(`Success: ${updateCount} products updated in inventory.`);

        window.showToast("🚀 Inventory Updated Successfully!", "success");
        window.clearCurrentInvoice();
        if (window.showSubTab) window.showSubTab('supplier-invoices', 'list');
        
    } catch (err) {
        console.error("Critical error saving invoice:", err);
        window.showToast("Critical Error: " + err.message, "error");
    }
};

window.quickAddProductForSINV = async () => {
    const name = document.getElementById('qa-prod-name').value.trim();
    const price = Math.round((parseFloat(document.getElementById('qa-prod-price').value) || 0) * 1000) / 1000;
    const cost = Math.round((parseFloat(document.getElementById('qa-prod-cost').value) || 0) * 1000) / 1000;
    const category = document.getElementById('qa-prod-category').value || "General";
    const mode = document.getElementById('qa-prod-mode').value || "Shop";
    let sku = document.getElementById('qa-prod-sku').value.trim();

    if(!name || isNaN(price) || isNaN(cost)) {
        window.showToast("Please enter product name, price, and cost.", "error");
        return;
    }
    if(!sku) {
        sku = 'QA' + Math.floor(Math.random() * 1000000);
    }

    try {
        const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
        const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;

        const prodData = {
            name,
            sellingPrice: price,
            totalStock: 0,
            cost: cost,
            price: price,
            wholesalePrice: Math.round((price * (1 - wholesalePct / 100)) * 1000) / 1000,
            loyaltyPrice: Math.round((price * (1 - loyaltyPct / 100)) * 1000) / 1000,
            sku,
            brand: "Quick Add",
            category,
            mode,
            stock: 0,
            searchRef: name.toLowerCase(),
            storeId: window.getStoreId(),
            createdAt: new Date()
        };
        
        // Use globally imported addDoc and collection from admin.js top
        const docRef = await addDoc(collection(db, 'products'), prodData);
        window.showToast("Product added successfully!", "success");
        document.getElementById('sinv-quick-product-modal').style.display = 'none';
        
        // Push locally so it's instantly available in search & selection
        const createdProd = { id: docRef.id, docId: docRef.id, ...prodData };
        if (!window.allProducts) window.allProducts = [];
        window.allProducts.unshift(createdProd);

        // Clear fields
        document.getElementById('qa-prod-name').value = '';
        document.getElementById('qa-prod-price').value = '';
        document.getElementById('qa-prod-cost').value = '';
        document.getElementById('qa-prod-sku').value = '';
        document.getElementById('qa-prod-category').value = '';
        document.getElementById('qa-prod-mode').value = 'Shop';
        
        // Auto select and open in supplier invoice item modal
        if (typeof window.addToSupplierInvoice === 'function') {
            window.addToSupplierInvoice(docRef.id);
        } else {
            const searchInput = document.getElementById('sinv-search');
            if (searchInput) {
                searchInput.value = sku;
                window.handleSINVSearch(sku);
            }
        }
    } catch(err) {
        console.error(err);
        window.showToast("Failed to add product.", "error");
    }
};

window.clearCurrentInvoice = () => {
    window.currentInvoiceItems = [];
    if (document.getElementById('sinv-no')) document.getElementById('sinv-no').value = '';
    if (document.getElementById('sinv-paid')) document.getElementById('sinv-paid').value = '0';
    if (document.getElementById('sinv-search')) document.getElementById('sinv-search').value = '';
    if (typeof window.clearSinvDraft === 'function') window.clearSinvDraft();
    window.renderInvoiceItemsTable(false);
    window.handleSINVSearch('');
};

window.handleSupplierInvoiceBulkCSV = (input) => {
    if (!input.files[0]) return;
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
        const text = e.target.result;
        const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
        if (lines.length < 2) return window.showToast("CSV is empty.", "error");

        const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
        const rows = lines.slice(1);

        // Map columns
        const colMap = {
            sku: headers.findIndex(h => h.includes('sku') || h.includes('code')),
            name: headers.findIndex(h => h.includes('name') || h.includes('product')),
            qty: headers.findIndex(h => h.includes('qty') || h.includes('quantity')),
            buying: headers.findIndex(h => h.includes('buying') || h.includes('cost')),
            disc: headers.findIndex(h => h.includes('discount') || h.includes('disc')),
            retail: headers.findIndex(h => h.includes('retail') || h.includes('price')),
            sd: headers.findIndex(h => h.includes('selling discount')),
            loyalty: headers.findIndex(h => h.includes('loyalty')),
            wholesale: headers.findIndex(h => h.includes('wholesale'))
        };

        if (colMap.name === -1 && colMap.sku === -1) {
             return window.showToast("CSV must have 'Name' or 'SKU' column.", "error");
        }

        let foundCount = 0;
        rows.forEach(row => {
            const cols = row.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
            const name = colMap.name !== -1 ? cols[colMap.name] : '';
            const sku = colMap.sku !== -1 ? cols[colMap.sku] : '';
            
            if (!name && !sku) return;

            // Find existing product by SKU or Name
            const p = window.allProducts.find(x => (sku && x.sku === sku) || (name && (x.name || '').toLowerCase() === name.toLowerCase()));
            
            if (p) {
                const qty = parseFloat(cols[colMap.qty]) || 1;
                const buying = parseFloat(cols[colMap.buying]) || p.cost || 0;
                const disc = parseFloat(cols[colMap.disc]) || 0;
                const net = buying * (1 - disc / 100);
                
                window.currentInvoiceItems.push({
                    docId: p.docId,
                    sku: p.sku || sku,
                    name: p.name || name,
                    qty: qty,
                    buying: buying,
                    discount: disc,
                    unitCost: net,
                    totalCost: net * qty,
                    retail: parseFloat(cols[colMap.retail]) || p.price || 0,
                    sellingDiscount: parseFloat(cols[colMap.sd]) || p.discount || 0,
                    loyalty: parseFloat(cols[colMap.loyalty]) || p.loyaltyPrice || 0,
                    wholesale: parseFloat(cols[colMap.wholesale]) || p.wholesalePrice || 0
                });
                foundCount++;
            }
        });

        window.showToast(`📥 Processed ${foundCount} items from CSV.`, "success");
        window.renderInvoiceItemsTable();
        input.value = ''; // Reset input
    };

    reader.readAsText(file);
};

window.deleteSupplierInvoice = async (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const docRef = doc(db, "supplierInvoices", id);
    if (!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    
    try {
        window.showToast("⏳ Reverting stock...", "info");
        const batch = writeBatch(db);
        let updateCount = 0;

        for (const item of (inv.items || [])) {
            if (item.docId && item.docId !== 'NEW') {
                const p = (window.allProducts || []).find(x => x.docId === item.docId);
                if (p) {
                    const pRef = doc(db, "products", item.docId);
                    let variants = [...(p.variants || [])];
                    const incomingBuyingPrice = Number(item.buying);
                    const incomingRetailPrice = Number(item.retail);
                    const qtyToRemove = parseFloat(item.qty) || 0;

                    const existingVariantIndex = variants.findIndex(v =>
                        v.supplierId === inv.supplierId &&
                        (v.variantLabel || '') === (item.variant || '') &&
                        Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                        Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                    );

                    if (existingVariantIndex !== -1) {
                        variants[existingVariantIndex].stock = Math.max(0, (parseFloat(variants[existingVariantIndex].stock) || 0) - qtyToRemove);
                    }

                    const newTotalStock = Math.max(0, (parseFloat(p.stock) || 0) - qtyToRemove);
                    
                    batch.update(pRef, {
                        variants: variants,
                        stock: newTotalStock,
                        totalStock: newTotalStock,
                        lastUpdated: Date.now()
                    });
                    updateCount++;
                }
            }
        }

        if (updateCount > 0) {
            await batch.commit();
        }

        await deleteDoc(docRef);
        window.showToast("🗑️ Invoice record deleted and stock reverted.", "success");
    } catch(err) { console.error(err); }
};

// ─── EDIT SUPPLIER INVOICE MODAL ──────────────────────────────────────────────
window.editSupplierInvoice = (id) => {
    const inv = (window.allSupplierInvoices || []).find(x => (x.docId || x.id) === id);
    if (!inv) return window.showToast('Invoice not found', 'error');

    const total = parseFloat(inv.totalAmount || inv.grandTotal || 0);
    const paid  = parseFloat(inv.paidAmount  || inv.paid  || 0);
    const currentStatus = inv.status || (paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending'));

    // Build suppliers options
    const suppOptions = (window.allSuppliers || []).map(s =>
        `<option value="${s.docId}" ${s.docId === inv.supplierId ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    // Remove any previous modal
    document.getElementById('sinv-edit-modal-overlay')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'sinv-edit-modal-overlay';
    overlay.style = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:10000000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(10px);animation:fadeIn 0.2s ease;';
    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };

    overlay.innerHTML = `
    <div style="width:480px;background:#0f172a;border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:28px;box-shadow:0 30px 100px rgba(0,0,0,0.8);animation:slideUp 0.3s ease-out;">

        <!-- Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
            <div>
                <div style="font-size:1.3rem;font-weight:900;color:#fff;">✏️ Edit Invoice</div>
                <div style="font-size:0.75rem;color:#64748b;margin-top:3px;">Invoice #${inv.invoiceNo} &nbsp;•&nbsp; ${(inv.items||[]).length} items &nbsp;•&nbsp; Grand Total: <span style="color:#38bdf8;font-weight:800;">LKR ${total.toLocaleString()}</span></div>
            </div>
            <button onclick="document.getElementById('sinv-edit-modal-overlay').remove()" style="background:rgba(255,255,255,0.05);border:none;color:white;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.2rem;">✕</button>
        </div>

        <!-- Fields -->
        <div style="display:flex;flex-direction:column;gap:16px;">

            <!-- Invoice No -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">INVOICE REFERENCE</label>
                <input id="sinv-edit-invno" value="${inv.invoiceNo || ''}" 
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;font-weight:700;box-sizing:border-box;">
            </div>

            <!-- Date -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">POSTING DATE</label>
                <input id="sinv-edit-date" type="date" value="${inv.date || ''}" 
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
            </div>

            <!-- Supplier -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">SUPPLIER</label>
                <select id="sinv-edit-supplier" style="width:100%;margin-top:6px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
                    ${suppOptions}
                </select>
            </div>

            <!-- Payment Method -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">PAYMENT METHOD</label>
                <select id="sinv-edit-paymethod" style="width:100%;margin-top:6px;background:#1e293b;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:0.9rem;box-sizing:border-box;">
                    <option value="CASH" ${(inv.paymentMethod||'CASH')==='CASH'?'selected':''}>Cash</option>
                    <option value="CREDIT" ${(inv.paymentMethod||'')==='CREDIT'?'selected':''}>Credit</option>
                    <option value="BANK_TRANSFER" ${(inv.paymentMethod||'')==='BANK_TRANSFER'?'selected':''}>Bank Transfer</option>
                    <option value="CHEQUE" ${(inv.paymentMethod||'')==='CHEQUE'?'selected':''}>Cheque</option>
                </select>
            </div>

            <!-- Paid Amount -->
            <div>
                <label style="font-size:0.7rem;font-weight:700;color:#64748b;letter-spacing:0.5px;">CASH PAID (LKR)</label>
                <input id="sinv-edit-paid" type="number" min="0" step="0.01" value="${paid}" 
                    oninput="window.updateEditInvoiceStatus()"
                    style="width:100%;margin-top:6px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px 14px;color:#fff;font-size:1.1rem;font-weight:900;box-sizing:border-box;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;">
                    <div style="font-size:0.72rem;color:#64748b;">Grand Total: <span style="color:#38bdf8;font-weight:800;">LKR ${total.toLocaleString()}</span></div>
                    <div id="sinv-edit-status-preview" style="font-size:0.72rem;font-weight:800;padding:3px 10px;border-radius:6px;"></div>
                </div>
                <!-- Quick fill buttons -->
                <div style="display:flex;gap:8px;margin-top:8px;">
                    <button onclick="document.getElementById('sinv-edit-paid').value=${total};window.updateEditInvoiceStatus()" 
                        style="flex:1;background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#10b981;padding:7px;border-radius:8px;cursor:pointer;font-size:0.72rem;font-weight:800;">✅ FULL PAID (${total.toLocaleString()})</button>
                    <button onclick="document.getElementById('sinv-edit-paid').value=0;window.updateEditInvoiceStatus()" 
                        style="flex:1;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#ef4444;padding:7px;border-radius:8px;cursor:pointer;font-size:0.72rem;font-weight:800;">🔴 PENDING (0)</button>
                </div>
            </div>
        </div>

        <!-- Save Button -->
        <button onclick="window.saveEditedSupplierInvoice('${id}', ${total})" 
            style="width:100%;margin-top:24px;background:linear-gradient(135deg,#38bdf8,#6366f1);border:none;color:#fff;padding:14px;border-radius:14px;font-size:1rem;font-weight:900;cursor:pointer;letter-spacing:0.5px;transition:all 0.2s;"
            onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">
            💾 SAVE CHANGES
        </button>
    </div>`;

    document.body.appendChild(overlay);
    // Set initial status preview
    window.updateEditInvoiceStatus();
};

window.updateEditInvoiceStatus = () => {
    const paidEl = document.getElementById('sinv-edit-paid');
    const previewEl = document.getElementById('sinv-edit-status-preview');
    if (!paidEl || !previewEl) return;
    const paidVal = parseFloat(paidEl.value) || 0;
    // Get total from the nearby span (stored as text)
    const totalSpan = document.querySelector('#sinv-edit-modal-overlay [style*="Grand Total"] span');
    const totalText = totalSpan ? totalSpan.innerText.replace(/[^0-9.]/g, '') : '0';
    const totalVal = parseFloat(totalText) || 0;

    if (paidVal >= totalVal && totalVal > 0) {
        previewEl.innerText = '✅ PAID';
        previewEl.style.background = 'rgba(16,185,129,0.2)';
        previewEl.style.color = '#10b981';
    } else if (paidVal > 0) {
        previewEl.innerText = '🟡 PARTIALLY PAID';
        previewEl.style.background = 'rgba(245,158,11,0.2)';
        previewEl.style.color = '#f59e0b';
    } else {
        previewEl.innerText = '🔴 PENDING';
        previewEl.style.background = 'rgba(251,191,36,0.15)';
        previewEl.style.color = '#fbbf24';
    }
};

window.saveEditedSupplierInvoice = async (id, total) => {
    const invNo  = document.getElementById('sinv-edit-invno')?.value.trim();
    const date   = document.getElementById('sinv-edit-date')?.value;
    const suppEl = document.getElementById('sinv-edit-supplier');
    const suppId = suppEl?.value;
    const suppName = suppEl?.options[suppEl.selectedIndex]?.text || '';
    const payMethod = document.getElementById('sinv-edit-paymethod')?.value;
    const paid  = parseFloat(document.getElementById('sinv-edit-paid')?.value) || 0;

    if (!invNo) return window.showToast('Invoice number required', 'warning');

    const newStatus = paid >= total ? 'Paid' : (paid > 0 ? 'Partially Paid' : 'Pending');

    try {
        await updateDoc(doc(db, 'supplierInvoices', id), {
            invoiceNo: invNo,
            date: date,
            supplierId: suppId,
            supplierName: suppName,
            paymentMethod: payMethod,
            paid: paid,
            paidAmount: paid,
            status: newStatus,
            lastEditedAt: serverTimestamp()
        });
        document.getElementById('sinv-edit-modal-overlay')?.remove();
        window.showToast(`✅ Invoice updated! Status: ${newStatus}`, 'success');
        // Refresh the list
        if (typeof window.loadSupplierInvoices === 'function') window.loadSupplierInvoices();
        else if (typeof window.renderSupplierInvoicesList === 'function') window.renderSupplierInvoicesList();
    } catch(err) {
        console.error(err);
        window.showToast('Failed to update invoice: ' + err.message, 'error');
    }
};

// --- PROFESSIONAL CHARTERED ACCOUNTING MODULES ---
// window.switchReportView (REMOVED)

    // 1. UI Toggling
    // const views = ['summary', 'ledger', 'recon', 'aging', 'forecast', 'tax'];

/*
    views.forEach(v => {

        const el = document.getElementById(`report-view-${v}`);
        const nav = document.getElementById(`rep-nav-${v}`);
        if (el) el.style.display = (v === view) ? 'block' : 'none';
        if (nav) {
            if (v === view) nav.classList.add('active');
            else nav.classList.remove('active');
        }
    });

    // 2. Data Rendering

*/
// };



// [MIGRATED TO reports.js]

window.renderSupplierOverview = () => {
    const body = document.getElementById('sup-overview-recent-body');
    const monthlyTotalEl = document.getElementById('sup-stat-monthly-total');
    const pendingEl = document.getElementById('sup-stat-pending');
    const countEl = document.getElementById('sup-stat-count');
    if (!body) return;

    const invoices = window.allSupplierInvoices || [];
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    let monthlyTotal = 0;
    let pendingPayables = 0;

    invoices.forEach(inv => {
        const date = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000) : new Date(inv.date);
        if (date.getMonth() === currentMonth && date.getFullYear() === currentYear) {
            monthlyTotal += (inv.totalAmount || inv.grandTotal || 0);
        }
        
        const autoStatus = resolvePurchaseInvoiceStatus(inv);
        if (autoStatus === 'Pending' || autoStatus === 'Partially Paid') {
            const total = (inv.totalAmount || inv.grandTotal || 0);
            const paid = (inv.paidAmount || inv.paid || 0);
            pendingPayables += (total - paid);
        }
    });

    if (monthlyTotalEl) monthlyTotalEl.innerText = `LKR ${monthlyTotal.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    if (pendingEl) pendingEl.innerText = `LKR ${pendingPayables.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    if (countEl) countEl.innerText = (window.allSuppliers || []).length.toString();

    // Show latest 10
    const latest = [...invoices].sort((a,b) => {
        const da = a.timestamp?.seconds ? a.timestamp.seconds : new Date(a.date).getTime() / 1000;
        const db = b.timestamp?.seconds ? b.timestamp.seconds : new Date(b.date).getTime() / 1000;
        return db - da;
    }).slice(0, 10);

    body.innerHTML = latest.map(inv => {
        const dateStr = inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000).toLocaleDateString() : new Date(inv.date).toLocaleDateString();
        const total = inv.totalAmount || inv.grandTotal || 0;
        const status = resolvePurchaseInvoiceStatus(inv);
        const isPaid = status === 'Paid';
        const badgeColor = isPaid ? '#10b981' : (status === 'Partially Paid' ? '#f59e0b' : '#ef4444');
        return `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="font-size: 0.7rem; opacity: 0.7;">${dateStr}</td>
                <td style="font-weight: 700;">${inv.invoiceNo}</td>
                <td>${inv.supplierName}</td>
                <td style="text-align: right; font-weight: 800; color: #7dd3fc;">LKR ${total.toLocaleString()}</td>
                <td><span class="status-badge" style="background: ${badgeColor}22; color: ${badgeColor}; border: 1px solid ${badgeColor}44; padding: 4px 10px; border-radius: 8px; font-size: 0.65rem; font-weight: 800;">${status}</span></td>
            </tr>
        `;
    }).join('');
};

window.searchProductForComparison = () => {
    const query = document.getElementById('comp-search-product').value.toLowerCase();
    const dropdown = document.getElementById('comp-results-dropdown');
    if (!query || query.length < 2) { dropdown.style.display = 'none'; return; }

    const results = (window.allProducts || []).filter(p => 
        (p.name || '').toLowerCase().includes(query) || 
        (p.barcode && p.barcode.toLowerCase().includes(query))
    ).slice(0, 8);

    if (results.length === 0) { dropdown.style.display = 'none'; return; }

    dropdown.style.display = 'block';
    dropdown.innerHTML = results.map(p => `
        <div class="result-item" style="padding: 12px; border-bottom: 1px solid rgba(0,0,0,0.05); cursor: pointer;" onclick="window.selectProductForComparison('${p.docId}')">
            <div style="font-weight: 700; font-size: 0.85rem;">${p.name}</div>
            <div style="font-size: 0.7rem; opacity: 0.7;">Barcode: ${p.barcode || 'N/A'}</div>
        </div>
    `).join('');
};

window.selectProductForComparison = (pid) => {
    const dropdown = document.getElementById('comp-results-dropdown');
    const area = document.getElementById('comparison-analysis-area');
    const input = document.getElementById('comp-search-product');
    if (!dropdown || !area || !input) return;
    dropdown.style.display = 'none';

    const product = (window.allProducts || []).find(p => p.docId === pid);
    if (!product) return;
    input.value = product.name;

    // Search historical invoices for this product
    let history = [];
    (window.allSupplierInvoices || []).forEach(inv => {
        const item = (inv.items || []).find(it => it.docId === pid);
        if (item) {
            history.push({
                date: inv.timestamp?.seconds ? new Date(inv.timestamp.seconds * 1000) : new Date(inv.date),
                supplier: inv.supplierName,
                cost: item.buying || item.unitCost,
                qty: item.qty
            });
        }
    });

    if (history.length === 0) {
        area.innerHTML = `<p style="text-align: center; color: #ef4444; padding: 2rem;">⚠️ No purchase history found for this product.</p>`;
        return;
    }

    // Sort by cost (Cheapest first)
    const sorted = [...history].sort((a,b) => a.cost - b.cost);
    const cheapest = sorted[0];

    area.innerHTML = `
        <div style="margin-bottom: 2rem; padding: 2rem; background: rgba(16, 185, 129, 0.1); border-radius: 20px; border: 1px solid rgba(16, 185, 129, 0.3);">
            <div style="font-size: 0.7rem; font-weight: 800; color: #10b981; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 5px;">✨ Procurement Insight: Cheapest Source</div>
            <div style="font-size: 1.8rem; font-weight: 900; color: white;">${cheapest.supplier}</div>
            <div style="font-size: 1.2rem; margin-top: 5px; color: #10b981; font-weight: 800;">LKR ${cheapest.cost.toFixed(2)} <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: 400;">per unit</span></div>
        </div>

        <h4 style="margin: 0 0 1rem; opacity: 0.7; font-weight: 800; font-size: 0.8rem;">FULL SUPPLIER PRICE HISTORY</h4>
        <div class="table-container">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Supplier</th>
                        <th style="text-align: right;">Unit Cost</th>
                        <th style="text-align: right;">Diff vs Best</th>
                    </tr>
                </thead>
                <tbody>
                    ${history.sort((a,b) => b.date - a.date).map(h => {
                        const diff = h.cost - cheapest.cost;
                        return `
                            <tr>
                                <td style="font-size: 0.75rem; opacity: 0.6;">${h.date.toLocaleDateString()}</td>
                                <td style="font-weight: 700;">${h.supplier}</td>
                                <td style="text-align: right; font-weight: 800; color: #7dd3fc;">LKR ${h.cost.toFixed(2)}</td>
                                <td style="text-align: right; color: ${diff === 0 ? '#10b981' : '#ef4444'}; font-weight: 800;">
                                    ${diff === 0 ? '<span style="font-size: 0.65rem;">★ BEST PRIZE</span>' : `+LKR ${diff.toFixed(2)}`}
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
};


// --- Professional Procurement & PO System ---
window.currentPOItems = [];
window.selectedPOProduct = null;

window.initPOForm = function() {
    const supSelect = document.getElementById('po-supplier-id');
    if (supSelect) {
        const optionsHtml = (window.allSuppliers || []).map(s => `<option value="${s.docId || s.id}">${s.name}</option>`).join('');
        supSelect.innerHTML = '<option value="">-- Choose Supplier --</option>' + optionsHtml;
    }
    
    const currentDateEl = document.getElementById('po-current-date');
    if (currentDateEl) {
        currentDateEl.innerText = new Date().toLocaleDateString(undefined, {
            day: '2-digit', month: 'short', year: 'numeric'
        });
    }

    const postingDateInput = document.getElementById('po-posting-date');
    if (postingDateInput) {
        postingDateInput.value = new Date().toISOString().split('T')[0];
    }
    
    window.renderPOItems();
};
window.handlePOSelection = (name, docId) => {
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim().toLowerCase() === name.toLowerCase());
    if (variants.length > 1) {
        window.openVariantPickerForPO(name);
    } else {
        window.selectPOProduct(docId);
    }
};

window.openVariantPickerForPO = (name) => {
    const variants = (window.allProducts || []).filter(p => (p.name || '').trim().toLowerCase() === name.toLowerCase());
    if (variants.length === 0) return;

    const overlay = document.createElement('div');
    overlay.id = "po-variant-picker-overlay";
    overlay.style = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:10000000; display:flex; align-items:center; justify-content:center; backdrop-filter: blur(8px); animation: fadeIn 0.2s ease;";
    overlay.onclick = (e) => { if(e.target === overlay) overlay.remove(); };
    
    const content = document.createElement('div');
    content.style = "width: 500px; max-height: 80vh; overflow-y: auto; padding: 25px; border-radius: 28px; background: #0f172a; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 25px 100px rgba(0,0,0,0.8); position: relative; animation: slideUp 0.3s ease-out;";
    
    content.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; position: sticky; top: 0; background: #0f172a; padding: 10px 0; z-index: 10;">
            <div>
                <h3 style="margin: 0; font-size: 1.4rem; font-weight: 900; color: #fff; letter-spacing: -0.5px;">${name}</h3>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">SELECT VARIANT FOR STOCK ENTRY</div>
            </div>
            <button onclick="this.closest('#po-variant-picker-overlay').remove()" style="background: rgba(255,255,255,0.05); border: none; color: white; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">✕</button>
        </div>
        <div style="display: flex; flex-direction: column; gap: 12px;">
            ${variants.map(v => `
                <div class="variant-item-pick-po" onclick="window.confirmPOVariant('${v.docId}')" 
                    style="padding: 18px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 16px; cursor: pointer; transition: all 0.2s; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 40px; height: 40px; border-radius: 10px; overflow: hidden; background: #000; border: 1px solid rgba(255,255,255,0.1);">
                            <img src="${v.image || '/logo.png'}" style="width: 100%; height: 100%; object-fit: cover;">
                        </div>
                        <div>
                            <div style="font-weight: 800; color: #38bdf8; font-size: 1rem;">${v.size || 'Standard'} ${v.color ? ` / ${v.color}` : ''}</div>
                            <div style="font-size: 0.7rem; color: #64748b; margin-top: 4px;">SKU: ${v.sku || '-'}</div>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: 900; color: #fff; font-size: 1.1rem;">LKR ${(v.price || 0).toLocaleString()}</div>
                        <div style="font-size: 0.7rem; color: ${(v.stock || 0) < 5 ? '#ef4444' : '#10b981'}; font-weight: 800; margin-top: 4px;">STOCK: ${v.stock || 0}</div>
                    </div>
                </div>
            `).join('')}
        </div>
        <style>
            .variant-item-pick-po:hover {
                background: rgba(56, 189, 248, 0.1) !important;
                border-color: #38bdf8 !important;
                transform: translateX(5px);
            }
        </style>
    `;
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
};

window.confirmPOVariant = (docId) => {
    document.getElementById('po-variant-picker-overlay')?.remove();
    window.selectPOProduct(docId);
};

window.searchPOProducts = function(query) {
    const resultsContainer = document.getElementById('po-search-results');
    const supplierSelect = document.getElementById('po-supplier-id');
    const supplierId = supplierSelect?.value;
    const supplierName = supplierSelect?.options[supplierSelect.selectedIndex]?.text;
    
    window.poSelectedIndex = -1;
    
    if (!query || query.length < 2) {
        if(resultsContainer) resultsContainer.style.display = 'none';
        return;
    }
    
    const invoices = window.allSupplierInvoices || [];
    const supplierItemsNames = new Set();
    if (supplierId && supplierId !== "") {
        invoices.forEach(inv => {
            if (inv.supplierId === supplierId || inv.supplierName === supplierName) {
                (inv.items || []).forEach(item => {
                    if (item.name) supplierItemsNames.add(item.name.toLowerCase().trim());
                });
            }
        });
    }

    const products = window.allProducts || [];
    const filtered = products.filter(p => {
        if (!p.name) return false;
        const q = query.toLowerCase();
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return p.name.toLowerCase().includes(q) || 
               window.matchProductSku(p.sku, q) ||
               matchesVariantSku;
    });

    const grouped = {};
    filtered.forEach(p => {
        const key = p.name.trim().toLowerCase();
        if (!grouped[key]) grouped[key] = { ...p, variantCount: 0, variants: [] };
        grouped[key].variants.push(p);
        grouped[key].variantCount++;
    });

    const results = Object.values(grouped);
    results.sort((a, b) => {
        const aHas = supplierItemsNames.has(a.name.toLowerCase().trim()) ? 1 : 0;
        const bHas = supplierItemsNames.has(b.name.toLowerCase().trim()) ? 1 : 0;
        if (aHas !== bHas) return bHas - aHas;
        return a.name.localeCompare(b.name);
    });
    
    const finalResults = results.slice(0, 15);
    console.log(`PO Search for "${query}": found ${finalResults.length} results`);

    if (finalResults.length > 0) {
        resultsContainer.innerHTML = finalResults.map(p => {
            const isFromSupplier = supplierItemsNames.has(p.name.toLowerCase().trim());
            return `
                <div class="result-item po-search-item" onclick="window.handlePOSelection('${p.name.replace(/'/g, "\\'")}', '${p.docId}')" style="padding: 12px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05); color: white; display: flex; justify-content: space-between; align-items: center; border-left: 4px solid transparent; transition: all 0.2s;">
                    <div>
                        <div style="font-weight: 800;">${p.name}</div>
                        <div style="font-size: 0.85rem; color: #38bdf8; margin-top: 4px;">
                            ${p.variantCount > 1 ? `<span style="color: #fbbf24; font-weight: 900;">${p.variantCount} VARIANTS AVAILABLE</span>` : `<span style="color: #10b981; font-weight: 900; background: rgba(16, 185, 129, 0.1); padding: 2px 6px; border-radius: 4px;">Stock: ${p.stock || 0}</span> | <span style="color: #fff; font-weight: 900; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px;">LKR ${p.price || 0}</span>`} 
                        </div>
                    </div>
                    ${isFromSupplier ? `
                        <span style="font-size: 0.6rem; background: #10b98133; color: #10b981; padding: 4px 8px; border-radius: 6px; font-weight: 900; letter-spacing: 0.5px;">YOUR BRAND</span>
                    ` : `
                    `}
                </div>
            `;
        }).join('');
        resultsContainer.style.display = 'block';

        const items = resultsContainer.querySelectorAll('.po-search-item');
        items.forEach((item, idx) => {
            item.onmouseover = () => {
                window.poSelectedIndex = idx;
                window.highlightPOSearchItem(items);
            };
            item.onmouseout = () => {
                if (window.poSelectedIndex !== idx) {
                    item.style.background = 'transparent';
                    item.style.borderLeft = '4px solid transparent';
                }
            };
        });
    } else {
        resultsContainer.innerHTML = '<div style="padding: 20px; text-align: center; color: #64748b; font-size: 0.8rem;">No matching products found.</div>';
        resultsContainer.style.display = 'block';
    }

    const searchInput = document.getElementById('po-product-search');
    if (searchInput) {
        searchInput.onkeydown = (e) => {
            const items = resultsContainer.querySelectorAll('.po-search-item');
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (items.length > 0) {
                    window.poSelectedIndex = (window.poSelectedIndex + 1) % items.length;
                    window.highlightPOSearchItem(items);
                }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (items.length > 0) {
                    window.poSelectedIndex = (window.poSelectedIndex - 1 + items.length) % items.length;
                    window.highlightPOSearchItem(items);
                }
            } else if (e.key === 'Enter') {
                if (window.poSelectedIndex >= 0 && window.poSelectedIndex < items.length) {
                    e.preventDefault();
                    items[window.poSelectedIndex].click();
                } else if (items.length > 0) {
                    e.preventDefault();
                    items[0].click();
                }
            }
        };
    }
};

window.selectPOProduct = async function(docId) {
    const products = window.allProducts || [];
    const product = products.find(p => p.docId === docId);
    if (!product) return;
    
    window.poSelectedIndex = -1;
    window.selectedPOProduct = product;
    const displayName = product.name + (product.size ? ` (${product.size})` : '') + (product.color ? ` (${product.color})` : '');
    document.getElementById('po-product-search').value = displayName;
    document.getElementById('po-search-results').style.display = 'none';
    document.getElementById('po-item-price').value = product.cost || 0;
    document.getElementById('po-item-retail').value = product.price || 0;
    
    // Set editable new fields defaulting to current pricing
    document.getElementById('po-item-new-buying').value = product.cost || 0;
    document.getElementById('po-item-new-retail').value = product.price || 0;
    
    // Show Price Comparison
    const comparisonBox = document.getElementById('po-price-comparison-box');
    const priceList = document.getElementById('po-price-list');
    if (!comparisonBox || !priceList) return;
    
    comparisonBox.style.display = 'block';
    window.checkPOPriceMatch();
    
    // Get historical prices from other suppliers (using supplier invoices)
    const invoices = window.allSupplierInvoices || [];
    const history = [];
    
    invoices.forEach(inv => {
        const item = inv.items.find(i => (i.docId === docId || i.id === docId));
        if (item) {
            history.push({
                supplierName: inv.supplierName,
                cost: parseFloat(item.buyingPrice || item.netCost || 0),
                date: inv.date
            });
        }
    });
    
    // Consolidate best price per supplier
    const bestPrices = {};
    history.forEach(h => {
        if (!bestPrices[h.supplierName] || h.cost < bestPrices[h.supplierName]) {
            bestPrices[h.supplierName] = h.cost;
        }
    });

    const comparisonItems = Object.entries(bestPrices).map(([name, price]) => `
        <div onclick="document.getElementById('po-item-new-buying').value = ${price}; window.checkPOPriceMatch();" style="display: flex; justify-content: space-between; padding: 8px 12px; background: rgba(0,0,0,0.2); border-radius: 8px; cursor: pointer;">
            <span style="font-size: 0.8rem; color: #94a3b8;">${name}</span>
            <span style="font-weight: 800; color: ${price <= (product.cost || 0) ? '#10b981' : '#f59e0b'}">LKR ${price.toFixed(2)}</span>
        </div>
    `);
    
    if (comparisonItems.length > 0) {
        priceList.innerHTML = comparisonItems.join('');
    } else {
        priceList.innerHTML = '<div style="color: #64748b; font-size: 0.8rem; text-align: center;">No history found</div>';
    }
};

// Checks if entered prices in Procure Terminal match existing records
window.checkPOPriceMatch = () => {
    const badge = document.getElementById('po-price-match-badge');
    const buyingInput = document.getElementById('po-item-new-buying');
    const retailInput = document.getElementById('po-item-new-retail');
    if (!badge || !buyingInput || !retailInput) return;

    const refBuying = parseFloat(document.getElementById('po-item-price').value) || 0;
    const refRetail = parseFloat(document.getElementById('po-item-retail').value) || 0;
    const newBuying = parseFloat(buyingInput.value) || 0;
    const newRetail = parseFloat(retailInput.value) || 0;

    const buyingChanged = Math.abs(newBuying - refBuying) >= 0.01;
    const retailChanged = Math.abs(newRetail - refRetail) >= 0.01;

    badge.style.display = 'block';
    if (buyingChanged || retailChanged) {
        badge.innerText = '⚠️ NEW PRICE — New Variant Batch will be created';
        badge.style.background = 'rgba(251,191,36,0.15)';
        badge.style.color = '#fbbf24';
        badge.style.borderColor = 'rgba(251,191,36,0.4)';
        buyingInput.style.borderColor = buyingChanged ? 'rgba(251,191,36,0.6)' : '';
        retailInput.style.borderColor = retailChanged ? 'rgba(251,191,36,0.6)' : '';
    } else {
        badge.innerText = '✓ SAME PRICE — Stock will be added to existing';
        badge.style.background = 'rgba(16,185,129,0.15)';
        badge.style.color = '#10b981';
        badge.style.borderColor = 'rgba(16,185,129,0.3)';
        buyingInput.style.borderColor = '';
        retailInput.style.borderColor = '';
    }
};

window.addItemToPO = function() {
    if (!window.selectedPOProduct) {
        alert("Please select a product first.");
        return;
    }
    
    const price = parseFloat(document.getElementById('po-item-new-buying').value);
    const retail = parseFloat(document.getElementById('po-item-new-retail').value);
    const qty = parseFloat(document.getElementById('po-item-qty').value);
    
    if (isNaN(price) || price < 0 || isNaN(qty) || qty <= 0) {
        alert("Enter valid price and quantity.");
        return;
    }
    
    if (window.poSelectedIndex !== undefined && window.poSelectedIndex > -1) {
        // Updating existing selected item from list
        const item = window.currentPOItems[window.poSelectedIndex];
        if (item) {
            item.price = price;
            item.retail = retail;
            item.qty = qty;
            item.total = price * qty;
        }
        window.poSelectedIndex = -1;
    } else {
        const existing = window.currentPOItems.find(item => 
            item.id === window.selectedPOProduct.docId && 
            Math.abs(item.price - price) < 0.01 && 
            Math.abs(item.retail - retail) < 0.01
        );
        if (existing) {
            existing.qty += qty;
            existing.total = existing.qty * existing.price;
        } else {
            window.currentPOItems.push({
                id: window.selectedPOProduct.docId,
                name: window.selectedPOProduct.name,
                price: price,
                retail: retail,
                qty: qty,
                total: price * qty,
                baseMetadata: { ...window.selectedPOProduct } // Store metadata for new variant creation
            });
        }
    }
    
    // Clear item inputs but NOT supplier
    window.selectedPOProduct = null;
    document.getElementById('po-product-search').value = '';
    document.getElementById('po-item-price').value = '0';
    document.getElementById('po-item-retail').value = '0';
    document.getElementById('po-item-new-buying').value = '0';
    document.getElementById('po-item-new-retail').value = '0';
    document.getElementById('po-item-qty').value = '1';
    
    const badge = document.getElementById('po-price-match-badge');
    if (badge) badge.style.display = 'none';
    
    document.getElementById('po-price-comparison-box').style.display = 'none';
    
    window.renderPOItems();
};

window.renderPOItems = function() {
    const body = document.getElementById('po-items-body');
    const grandTotalEl = document.getElementById('po-grand-total');
    const totalSkusEl = document.getElementById('po-total-skus');
    
    if (!body) return;
    
    let total = 0;
    body.innerHTML = window.currentPOItems.map((item, idx) => {
        total += item.total;
        return `
            <tr onclick="window.editPOItem(${idx})" style="border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.02)'" onmouseout="this.style.background='transparent'">
                <td style="padding: 15px 10px; font-weight: 600;">${item.name}</td>
                <td style="text-align: right; padding: 15px 10px; color: #94a3b8;">${item.price.toFixed(2)}</td>
                <td style="text-align: center; padding: 15px 10px; font-weight: 800; color: #38bdf8;">${item.qty}</td>
                <td style="text-align: right; padding: 15px 10px; font-weight: 800; color: #10b981;">${item.total.toFixed(2)}</td>
                <td style="text-align: center; padding: 15px 10px;" onclick="event.stopPropagation()">
                    <button onclick="window.removeItemFromPO(${idx})" style="background: rgba(220, 38, 38, 0.1); border: 1px solid rgba(220, 38, 38, 0.2); color: #ef4444; font-size: 1rem; cursor: pointer; border-radius: 6px; width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; transition: all 0.2s;" onmouseover="this.style.background='rgba(220, 38, 38, 0.2)'" onmouseout="this.style.background='rgba(220, 38, 38, 0.1)'">🗑️</button>
                </td>
            </tr>
        `;
    }).join('');
    
    if (window.currentPOItems.length === 0) {
        body.innerHTML = '<tr><td colspan="5" style="text-align: center; color: #64748b; padding: 3rem; font-weight: 600;">No items added to this order.</td></tr>';
    }
    
    grandTotalEl.innerText = total.toFixed(2);
    if (totalSkusEl) totalSkusEl.innerText = window.currentPOItems.length;
};

window.editPOItem = function(index) {
    const item = window.currentPOItems[index];
    if (!item) return;
    
    window.poSelectedIndex = index;
    window.selectedPOProduct = item.baseMetadata || { docId: item.id, name: item.name };
    
    document.getElementById('po-product-search').value = item.name;
    document.getElementById('po-item-price').value = item.baseMetadata?.cost || item.price;
    document.getElementById('po-item-retail').value = item.baseMetadata?.price || item.retail;
    
    document.getElementById('po-item-new-buying').value = item.price;
    document.getElementById('po-item-new-retail').value = item.retail;
    document.getElementById('po-item-qty').value = item.qty;
    
    const comparisonBox = document.getElementById('po-price-comparison-box');
    if (comparisonBox) {
        comparisonBox.style.display = 'block';
        window.checkPOPriceMatch();
    }
};

window.removeItemFromPO = function(index) {
    window.currentPOItems.splice(index, 1);
    window.renderPOItems();
};

window.clearPOForm = function() {
    if (confirm("Reset current order?")) {
        window.currentPOItems = [];
        window.selectedPOProduct = null;
        window.poSelectedIndex = -1;
        document.getElementById('po-product-search').value = '';
        document.getElementById('po-item-price').value = '0';
        document.getElementById('po-item-retail').value = '0';
        document.getElementById('po-item-new-buying').value = '0';
        document.getElementById('po-item-new-retail').value = '0';
        document.getElementById('po-item-qty').value = '1';
        if(document.getElementById('po-invoice-ref')) document.getElementById('po-invoice-ref').value = '';
        if(document.getElementById('po-cash-paid')) document.getElementById('po-cash-paid').value = '0';
        
        const badge = document.getElementById('po-price-match-badge');
        if (badge) badge.style.display = 'none';
        
        document.getElementById('po-price-comparison-box').style.display = 'none';
        window.renderPOItems();
    }
};

window.savePurchaseOrder = async function() {
    if (window.currentPOItems.length === 0) {
        alert("Add some items to the order first.");
        return;
    }
    
    const supplierId = document.getElementById('po-supplier-id').value;
    const supplier = (window.allSuppliers || []).find(s => s.docId === supplierId);
    if (!supplier) return alert("Invalid Supplier (" + supplierId + ")");
    
    const invoiceRef = document.getElementById('po-invoice-ref')?.value || '';
    const postingDate = document.getElementById('po-posting-date')?.value || new Date().toISOString().split('T')[0];
    const settlementType = document.getElementById('po-settlement-type')?.value || 'cash';
    const cashPaid = parseFloat(document.getElementById('po-cash-paid')?.value) || 0;
    
    const totalAmount = window.currentPOItems.reduce((acc, item) => acc + item.total, 0);
    
    if (!confirm(`Finalize this order from ${supplier.name} for LKR ${totalAmount.toFixed(2)}? Stock will be updated.`)) return;
    
    try {
        const batch = writeBatch(db); // Use imported writeBatch
        
        // 1. Create Supplier Invoice record (uses supplierInvoices collection)
        const invRef = doc(collection(db, "supplierInvoices"));
        batch.set(invRef, {
            supplierId: supplierId,
            supplierName: supplier.name,
            invoiceNo: invoiceRef || `PO-${Date.now()}`,
            date: postingDate,
            totalAmount: totalAmount,
            grandTotal: totalAmount,
            paidAmount: totalAmount,
            cashPaid: totalAmount,
            paid: totalAmount,
            settlementType: settlementType,
            storeId: window.getStoreId() || 'master',
            items: window.currentPOItems.map(item => ({
                id: item.id || 'N/A',
                docId: item.id || 'N/A',
                name: item.name,
                buyingPrice: item.price,
                netCost: item.price,
                buying: item.price,
                qty: item.qty
            })),
            status: 'Paid',
            paymentStatus: 'Paid',
            timestamp: serverTimestamp()
        });
        
        // 2. Update Product Stocks (Auto-Variant Logic)
        for (const item of window.currentPOItems) {
            // Find existing product by ID (since item.id holds the docId) or name fallback
            let existingProduct = (window.allProducts || []).find(p => p.docId === item.id);
            if (!existingProduct) {
                existingProduct = (window.allProducts || []).find(p => 
                    p.name.trim().toLowerCase() === item.name.trim().toLowerCase()
                );
            }

            if (existingProduct) {
                // UPDATE EXISTING VARIANT WITH VARIANT-AWARE LOGIC
                const pRef = doc(db, "products", existingProduct.docId);
                let variants = [...(existingProduct.variants || [])];
                const incomingBuyingPrice = Number(item.price);
                const incomingRetailPrice = Number(item.retail);

                // If variants is empty and the product has existing stock, convert the base stock to a variant first!
                if (variants.length === 0 && (parseFloat(existingProduct.stock) || 0) > 0) {
                    const origPrice = parseFloat(existingProduct.price) || 0;
                    variants.push({
                        variantId: 'base-' + existingProduct.docId + '-' + Date.now().toString() + Math.random().toString(36).substr(2, 5),
                        supplierId: existingProduct.supplierId || supplierId,
                        supplierName: existingProduct.supplierName || supplier.name,
                        variantLabel: existingProduct.size || existingProduct.color || `Batch @ LKR ${origPrice.toFixed(2)}`,
                        buyingPrice: parseFloat(existingProduct.cost) || 0,
                        cost: parseFloat(existingProduct.cost) || 0,
                        sellingPrice: origPrice,
                        wholesalePrice: parseFloat(existingProduct.wholesalePrice) || origPrice,
                        loyaltyPrice: parseFloat(existingProduct.loyaltyPrice) || origPrice,
                        stock: parseFloat(existingProduct.stock) || 0,
                        sku: existingProduct.sku || '',
                        expiry: existingProduct.expiryDate || '',
                        warranty: existingProduct.warranty || '',
                        addedDate: existingProduct.addedDate || new Date().toISOString(),
                        lastUpdated: Date.now()
                    });
                }

                // Match existing variant strictly if retail price AND buying price match
                const existingVariantIndex = variants.findIndex(v =>
                    Math.abs(Number(v.buyingPrice || v.cost) - incomingBuyingPrice) < 0.01 &&
                    Math.abs(Number(v.sellingPrice || v.price) - incomingRetailPrice) < 0.01
                );

                if (existingVariantIndex !== -1) {
                    // Exact price match: add stock to existing variant batch
                    const oldStock = parseFloat(variants[existingVariantIndex].stock) || 0;
                    const oldCost = parseFloat(variants[existingVariantIndex].buyingPrice || variants[existingVariantIndex].cost) || 0;
                    const newTotalStock = oldStock + item.qty;
                    const wacCost = newTotalStock > 0
                        ? ((oldStock * oldCost) + (item.qty * incomingBuyingPrice)) / newTotalStock
                        : incomingBuyingPrice;
                    variants[existingVariantIndex].stock = newTotalStock;
                    variants[existingVariantIndex].buyingPrice = parseFloat(wacCost.toFixed(4));
                    variants[existingVariantIndex].cost = parseFloat(wacCost.toFixed(4));
                    variants[existingVariantIndex].sellingPrice = incomingRetailPrice;
                    variants[existingVariantIndex].supplierId = supplierId;
                    variants[existingVariantIndex].supplierName = supplier.name;
                    variants[existingVariantIndex].lastUpdated = Date.now();
                } else {
                    // Different price or new batch: create a separate variant batch so older stock keeps its original price!
                    const batchLabel = `Batch @ LKR ${incomingRetailPrice.toFixed(2)}`;
                    const variantSku = existingProduct.sku ? `${existingProduct.sku}-V${Math.floor(incomingRetailPrice)}` : '';
                    variants.push({
                        variantId: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                        supplierId: supplierId,
                        supplierName: supplier.name,
                        variantLabel: batchLabel,
                        buyingPrice: incomingBuyingPrice,
                        cost: incomingBuyingPrice,
                        sellingPrice: incomingRetailPrice,
                        wholesalePrice: incomingRetailPrice,
                        loyaltyPrice: incomingRetailPrice,
                        stock: item.qty,
                        sku: variantSku || existingProduct.sku || '',
                        expiry: '',
                        warranty: '',
                        addedDate: new Date().toISOString(),
                        lastUpdated: Date.now()
                    });
                }

                const totalCalculatedStock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                const wacBaseCost = totalCalculatedStock > 0
                    ? variants.reduce((sum, v) => sum + ((parseFloat(v.cost || v.buyingPrice) || 0) * (parseFloat(v.stock) || 0)), 0) / totalCalculatedStock
                    : incomingBuyingPrice;

                batch.update(pRef, {
                    variants: variants,
                    stock: totalCalculatedStock,
                    totalStock: totalCalculatedStock,
                    cost: parseFloat(wacBaseCost.toFixed(4)),
                    price: incomingRetailPrice,
                    lastStockUpdate: serverTimestamp()
                });
            } else {
                // CREATE NEW VARIANT
                const newProductRef = doc(collection(db, "products"));
                const meta = item.baseMetadata || {};
                
                // Construct new SKU for variant if base exists
                const baseSku = meta.sku || `MEC-${Date.now()}`;
                const variantSku = `${baseSku}-V${Math.floor(item.retail)}`;

                batch.set(newProductRef, {
                    name: item.name,
                    sku: variantSku,
                    category: meta.category || 'General',
                    mode: meta.mode || 'Inventory',
                    image: meta.image || '/logo.png',
                    barcode: meta.barcode || '',
                    unit: meta.unit || 'pcs',
                    cost: item.price,
                    price: item.retail,
                    stock: item.qty,
                    wStock: 0,
                    totalStock: item.qty,
                    storeId: window.getStoreId(),
                    timestamp: serverTimestamp(),
                    salesToday: 0,
                    wholesalePrice: meta.wholesalePrice || item.retail,
                    loyaltyPrice: meta.loyaltyPrice || item.retail
                });
            }
        }
        
        // 3. Log as Expense (Inventory Purchase)
        const expRef = doc(collection(db, "expenses"));
        batch.set(expRef, {
            title: `Inventory Purchase: ${supplier.name}`,
            amount: totalAmount,
            date: postingDate,
            category: 'Inventory',
            timestamp: serverTimestamp()
        });

        await batch.commit();
        window.showToast("🚀 Stock Inbound Successful!", "success");
        window.currentPOItems = [];
        window.renderPOItems();
        window.showTab('supplier-invoices');
        if (window.showSubTab) window.showSubTab('supplier-invoices', 'list');
        
    } catch (e) {
        console.error("PO Error:", e);
        alert("Error saving order: " + e.message);
    }
};



// --- System Update & Cache Clearing (Renamed to prevent collisions) ---
window.systemUpgradeInternal = async () => {
    window.showToast("🔄 Fetching latest system updates...", "info");
    
    const btn = document.getElementById('system-upgrade-btn');
    if (btn) {
        btn.classList.add('updating');
        const icon = btn.querySelector('.icon');
        if (icon) icon.style.animationPlayState = 'running';
    }

    try {
        if ('caches' in window) {
            try {
                const keys = await caches.keys();
                await Promise.all(keys.map(k => caches.delete(k)));
                console.log("Caches cleared success.");
            } catch (cacheErr) {
                console.warn("Failed to clear caches:", cacheErr);
            }
        }
        
        if ('serviceWorker' in navigator) {
            try {
                const registrations = await navigator.serviceWorker.getRegistrations();
                for (const registration of registrations) {
                   await registration.unregister();
                }
                console.log("SW Unregistered.");
            } catch (swErr) {
                console.warn("Failed to unregister SW:", swErr);
            }
        }

        if (window.chrome && window.chrome.webview) {
            try {
                window.chrome.webview.postMessage({ type: 'checkExeUpdates' });
            } catch (exeErr) {
                console.warn("Failed to check WebView2 exe updates:", exeErr);
            }
        }
        if (window.electronAPI && window.electronAPI.checkExeUpdates) {
            try {
                window.electronAPI.checkExeUpdates();
            } catch (exeErr) {
                console.warn("Failed to check exe updates:", exeErr);
            }
        }

        window.showToast("✅ System updated. Refreshing...", "success");
        setTimeout(() => {
            // Add a cache-busting timestamp and reload
            const url = new URL(window.location.href);
            url.searchParams.set('v', Date.now());
            window.location.href = url.href;
        }, 1500);

    } catch (err) {
        console.error("Update fail:", err);
        window.showToast("Update failed. Please check connection.", "error");
        if (btn) {
            btn.classList.remove('updating');
            const icon = btn.querySelector('.icon');
            if (icon) icon.style.animationPlayState = 'paused';
        }
    }
};

// --- Modern Graphic Invoice & Sharing Logic ---
window.openModernInvoice = (orderId) => {
    // Priority 1: Check if this is the immediate POS sale we just made
    let order = null;
    if (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId)) {
        order = window.lastSavedPOSOrder;
    }
    
    // Priority 2: If not found, look in allOrders (historical)
    if (!order) {
        order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId);
    }
    
    // Priority 3: Repair job fallback
    if (!order && orderId) {
        order = (window.allOrders || []).find(o => o.repairJobId === orderId);
    }

    if (!order) {
        window.showToast("Invoice data not found. Please wait 1-2 seconds and try again.", "info");
        return;
    }
    window._currentViewingInvoiceId = order.docId || order.orderId;

    console.log("Generating Premium Graphic Invoice for:", orderId);
    
    // Populate Modal Fields
    const modal = document.getElementById('modern-invoice-modal');
    if (!modal) return;

    // Store & Branch Info
    const orderBranchKey = order.branchId || order.branch || localStorage.getItem('mec_terminal_branch') || sessionStorage.getItem('userBranchId') || 'main';
    const activeBranchInfo = (typeof window.getBranchInfo === 'function') 
        ? window.getBranchInfo(orderBranchKey) 
        : {
            name: window.storeInfo?.name || window.STORE_CONFIG?.name || 'MEC BOOK SHOP',
            branchName: 'Main Branch - Horana',
            address: window.storeInfo?.address || window.storeInfo?.location || window.STORE_CONFIG?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana',
            phone: window.storeInfo?.phone || window.STORE_CONFIG?.phone || '071 923 3388',
            email: window.storeInfo?.ownerEmail || window.STORE_CONFIG?.email || 'mecbookshop@gmail.com'
        };

    const branchDisplayName = activeBranchInfo.branchName || activeBranchInfo.name || 'MEC Book Shop';
    document.getElementById('mi-store-name').innerText = branchDisplayName;
    document.getElementById('mi-store-tagline').innerText = window.storeInfo?.tagline || window.STORE_CONFIG?.tagline || 'Premium Book Shop & Stationery Hub';
    document.getElementById('mi-auth-store').innerText = branchDisplayName;
    
    const storePhoneEl = document.getElementById('mi-store-phone');
    if (storePhoneEl) storePhoneEl.innerText = activeBranchInfo.phone || window.storeInfo?.phone || window.STORE_CONFIG?.phone || '071 923 3388';
    const storeAddressEl = document.getElementById('mi-store-address');
    if (storeAddressEl) storeAddressEl.innerText = activeBranchInfo.address || activeBranchInfo.location || window.storeInfo?.address || window.STORE_CONFIG?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana';
    const storeEmailEl = document.getElementById('mi-store-email');
    if (storeEmailEl) storeEmailEl.innerText = activeBranchInfo.email || window.storeInfo?.ownerEmail || window.STORE_CONFIG?.email || 'mecbookshop@gmail.com';
    
    // Customer Info
    document.getElementById('mi-cust-name').innerText = order.userName || 'Walk-in Customer';
    document.getElementById('mi-cust-phone').innerText = order.phone || order.customerPhone || 'N/A';
    
    // Bill Info
    let displayId = order.orderId || order.docId;
    if (displayId && !displayId.startsWith('#')) displayId = '#' + displayId;
    document.getElementById('mi-inv-no').innerText = displayId;

    document.getElementById('mi-rep').innerText = order.staffName || 'Admin';
    document.getElementById('mi-date').innerText = order.date || new Date().toLocaleDateString();
    
    // Table Body
    const tbody = document.getElementById('mi-table-body');
    let itemsMarkup = '';

    // If it's a repair, show a summary row first
    if (order.type === 'RepairBill') {
        itemsMarkup += `
            <tr style="background: rgba(0, 32, 96, 0.03); border-bottom: 2px solid #002060;">
                <td colspan="4" style="padding: 15px 20px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Repair Job ID</div>
                            <div style="font-weight: 900; color: #002060; font-size: 1.1rem;">${order.repairJobId || 'N/A'}</div>
                        </div>
                        <div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Device / Item</div>
                            <div style="font-weight: 700; color: #334155;">${(order.itemDescription || 'Electronic Item').toUpperCase()}</div>
                        </div>
                        <div style="grid-column: span 2;">
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 800; text-transform: uppercase;">Reported Problem / Service</div>
                            <div style="font-weight: 600; color: #475569;">${order.problem || 'General Technical Service'}</div>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }

    let itemDiscountsSum = 0;
    let originalSubtotal = 0;

    itemsMarkup += (order.items || []).map(item => {
        const itemDiscount = parseFloat(item.discount || 0);
        const itemPrice = parseFloat(item.price || 0);
        const qty = parseFloat(item.quantity || item.qty || 1);
        const lineTotal = (itemPrice - itemDiscount) * qty;
        
        itemDiscountsSum += (itemDiscount * qty);
        originalSubtotal += (itemPrice * qty);
        
        return `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 8px 12px; font-weight: 700; color: #333;">${item.name}</td>
                <td style="padding: 8px 12px; text-align: center; color: #555;">${qty}</td>
                <td style="padding: 8px 12px; text-align: center; color: #555;">Rs. ${itemPrice.toLocaleString()}</td>
                <td style="padding: 8px 12px; text-align: center; color: #e30030; font-weight: 600;">${itemDiscount > 0 ? 'Rs. ' + itemDiscount.toLocaleString() : '-'}</td>
                <td style="padding: 8px 12px; text-align: right; font-weight: 800; color: #000;">Rs. ${lineTotal.toLocaleString()}</td>
            </tr>
        `;
    }).join('');

    tbody.innerHTML = itemsMarkup;

    // Totals Breakdown
    const billDiscount = parseFloat(order.discount || 0);
    const totalDiscount = itemDiscountsSum + billDiscount;
    
    document.getElementById('mi-subtotal').innerText = `Rs. ${originalSubtotal.toLocaleString()}`;
    document.getElementById('mi-discount').innerText = `Rs. ${totalDiscount.toLocaleString()}`;
    
    // Summary logic for Modern Invoice
    const miSummaryBody = document.getElementById('mi-summary-extra');
    if (miSummaryBody) {
        let extraHtml = '';
        
        // Show Settled Outstanding if any
        if (order.outstandingIncluded && order.outstandingAmount > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #b91c1c; font-weight: 600;">Settled Debt (Debt Paid)</td><td style="font-weight: 800; color: #b91c1c;">Rs. ${order.outstandingAmount.toLocaleString()}</td></tr>`;
        }
        
        // Show Redeemed Points (Discount)
        const redeemed = order.redeemedAmount || 0;
        if (redeemed > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #0369a1; font-weight: 600;">Points Redeemed (Used)</td><td style="font-weight: 800; color: #0369a1;">- Rs. ${redeemed.toLocaleString()}</td></tr>`;
        }

        // Show Amount Paid (Tendered)
        const tendered = order.tenderedAmount || (order.total + (order.cashBalance || 0));
        if (tendered > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #555; border-top: 1px dashed #ddd;">Cash Paid (Tendered)</td><td style="font-weight: 800; color: #222; border-top: 1px dashed #ddd;">Rs. ${tendered.toLocaleString()}</td></tr>`;
        }

        // Show Cash Balance (Change Given)
        const cashBal = order.cashBalance || 0;
        if (cashBal > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #16a34a; font-weight: 600;">Cash Balance (Change)</td><td style="font-weight: 800; color: #16a34a;">Rs. ${cashBal.toLocaleString()}</td></tr>`;
        }

        // Show Repair Advance if any
        if (order.advancePaid > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #10b981; font-weight: 600;">Advance Payment (-)</td><td style="font-weight: 800; color: #10b981;">Rs. ${order.advancePaid.toLocaleString()}</td></tr>`;
        }

        // Show Points Added from Change
        const pointsAdded = order.isPOS ? (order.changeAmount || 0) : 0;
        if (pointsAdded > 0) {
            extraHtml += `<tr><td style="padding: 6px 10px; color: #0ea5e9; font-weight: 600;">Loyalty Points Saved</td><td style="font-weight: 800; color: #0ea5e9;">+ 💎 ${pointsAdded.toLocaleString()}</td></tr>`;
        }

        miSummaryBody.innerHTML = extraHtml;
    }

    document.getElementById('mi-grandtotal').innerText = `Rs. ${order.total.toLocaleString()}`;
    const payMethod = order.paymentMethod || 'Cash';
    const chequeSuffix = (payMethod.toLowerCase() === 'cheque' && order.chequeDate) ? ` (Due: ${order.chequeDate})` : '';
    document.getElementById('mi-paymethod').innerText = payMethod + chequeSuffix;

    // Toggle PAID stamp
    const paidStamp = document.getElementById('mi-paid-stamp');
    if (paidStamp) {
        const isCredit = (
            payMethod.toLowerCase().includes('credit') || 
            payMethod.toLowerCase().includes('unpaid') || 
            payMethod.toLowerCase().includes('debt') || 
            payMethod.toLowerCase().includes('due')
        ) && !payMethod.toLowerCase().includes('settled');
        const isVoid = (order.status || '').toLowerCase() === 'void';
        const isPaid = !isCredit && !isVoid;
        paidStamp.style.display = isPaid ? 'flex' : 'none';
    }

    modal.style.display = 'flex';
};

window.downloadModernInvoice = async (format) => {
    const area = document.getElementById('modern-invoice-capture-area');
    const orderId = document.getElementById('mi-inv-no').innerText;

    if (!area) return;
    
    const btn = event?.target || null;
    const originalText = btn ? btn.innerText : "";
    if (btn) {
        btn.disabled = true;
        btn.innerText = "Processing...";
    }

    window.showToast(`📸 Generating ${format}... Please wait.`, "info");

    try {
        if (format === 'JPG') {
            const canvas = await html2canvas(area, { 
                scale: 2, // Optimized from 3 to 2 for better speed
                useCORS: true, 
                backgroundColor: '#ffffff',
                logging: false
            });
            const link = document.createElement('a');
            link.download = `MEC_INVOICE_${orderId}.jpg`;
            link.href = canvas.toDataURL('image/jpeg', 0.9);
            link.click();
            window.showToast("✅ JPG downloaded!", "success");
        } else {
            // PDF
            const opt = {
                margin:       0,
                filename:     `MEC_INVOICE_${orderId}.pdf`,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true }, // Optimized scale
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            if (window.html2pdf) {
                await window.html2pdf().set(opt).from(area).save();
                window.showToast("✅ PDF generated!", "success");
            }
        }
    } catch (err) {
        console.error(err);
        window.showToast("Error generating document.", "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = originalText;
        }
    }
};

window.shareOnWhatsApp = async (passedOrder) => {
    const order = passedOrder || window.currentPendingPOSSale || window.lastSavedPOSOrder;
    if (!order) return window.showToast("No active order to share.", "warning");

    const phone = order.customerPhone || order.phone || "";
    if (!phone) {
        window.showToast("Customer phone required for WhatsApp.", "warning");
        return;
    }

    const billId = order.orderId || order.id || "INVOICE";
    const bizName = window.systemConfig?.bizName || 'MEC BOOK SHOP & COMMUNICATION';
    const total = parseFloat(order.total || order.grandTotal || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const date = order.date || (order.createdAt?.seconds ? new Date(order.createdAt.seconds * 1000).toLocaleDateString('en-GB') : new Date().toLocaleDateString('en-GB'));
    const paymentMethod = order.paymentMethod || order.method || 'Cash';
    const contactPhone = window.systemConfig?.invPhone || window.systemConfig?.phone || '0712809615';
    const message = `*${bizName.toUpperCase()}* 📚✨\nThank you for your purchase!\n\n📄 *Invoice No:* ${billId}\n📅 *Date:* ${date}\n💰 *Total Amount:* LKR ${total}\n💳 *Payment Method:* ${paymentMethod}\n\n🔗 *View & Download PDF Invoice:*\n${invoiceLink}\n\nFor any inquiries, contact: ${contactPhone}. Have a wonderful day! 🙏`;

    const templatePayload = {
        name: "pos_invoice_bill",
        language: { code: "en" },
        components: [
            {
                type: "body",
                parameters: [
                    { type: "text", text: String(bizName) },
                    { type: "text", text: String(billId) },
                    { type: "text", text: String(total) },
                    { type: "text", text: String(paymentMethod) },
                    { type: "text", text: String(invoiceLink) }
                ]
            }
        ]
    };

    await window.dispatchWhatsApp(phone, message, { template: templatePayload });
};

window.showSettingsSubTab = (tabId) => {
    document.querySelectorAll('.settings-view').forEach(view => {
        view.style.setProperty('display', 'none', 'important');
    });
    document.querySelectorAll('.settings-nav-btn').forEach(btn => btn.classList.remove('active'));
    
    const target = document.getElementById(`set-sub-${tabId}`);
    if (target) {
        target.style.setProperty('display', 'block', 'important');
    }
    
    const targetBtn = document.getElementById(`btn-set-${tabId}`);
    if (targetBtn) targetBtn.classList.add('active');

    // Auto-refresh printers and device info when hardware tab is opened
    if (tabId === 'hardware') {
        window.refreshSystemPrinters();
        if (typeof window.fetchNativeDeviceInfo === 'function') {
            window.fetchNativeDeviceInfo();
        }
    }
};

window.__onPrintersReceived = (printers) => {
    const printerSelect = document.getElementById('set-printer-name');
    if (!printerSelect) return;

    const savedPrinter = localStorage.getItem('mecpos_selected_printer') || (window.systemConfig?.printerName || '');
    printerSelect.innerHTML = '';

    if (!printers || printers.length === 0) {
        printerSelect.innerHTML = '<option value="">No printers detected on this PC</option>';
        if (savedPrinter) {
            const opt = document.createElement('option');
            opt.value = savedPrinter;
            opt.innerText = `${savedPrinter} (Saved)`;
            opt.selected = true;
            printerSelect.appendChild(opt);
        }
        return;
    }

    // Default option placeholder
    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.innerText = '-- Select Printer Driver --';
    printerSelect.appendChild(defaultOpt);

    let matchFound = false;
    printers.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.name;
        opt.innerText = `${p.displayName || p.name}${p.isDefault ? ' (Default)' : ''}`;
        if (savedPrinter && p.name.toLowerCase() === savedPrinter.toLowerCase()) {
            opt.selected = true;
            matchFound = true;
        } else if (!savedPrinter && p.isDefault) {
            opt.selected = true;
        }
        printerSelect.appendChild(opt);
    });

    if (savedPrinter && !matchFound) {
        const opt = document.createElement('option');
        opt.value = savedPrinter;
        opt.innerText = `${savedPrinter} (Saved)`;
        opt.selected = true;
        printerSelect.appendChild(opt);
    }
};

window.refreshSystemPrinters = async (userTriggered = false) => {
    const printerSelect = document.getElementById('set-printer-name');
    if (!printerSelect) return;
    
    const currentVal = localStorage.getItem('mecpos_selected_printer') || printerSelect.value || (window.systemConfig?.printerName || '');
    printerSelect.innerHTML = '<option value="">Searching installed Windows printers...</option>';

    if (userTriggered && typeof window.showToast === 'function') {
        window.showToast('🔍 Refreshing printer drivers...', 'info');
    }
    
    try {
        // 1. C# WebView2 Wrapper Check
        if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage(JSON.stringify({ action: 'getPrinters' }));
                window.chrome.webview.postMessage('get-printers');
            } catch (postErr) {
                console.warn('[Printers] Failed to postMessage to WebView2:', postErr);
            }
            return;
        }

        // 2. Electron Check
        if (window.electron && typeof window.electron.getPrinters === 'function') {
            const printers = await window.electron.getPrinters();
            window.__onPrintersReceived(printers);
            return;
        }

        // 3. Web Browser Fallback
        printerSelect.innerHTML = '<option value="">(Browser Mode - Default System Dialog)</option>';
        if (currentVal) {
            const opt = document.createElement('option');
            opt.value = currentVal;
            opt.innerText = `${currentVal} (Manual)`;
            opt.selected = true;
            printerSelect.appendChild(opt);
        }
    } catch (err) {
        console.error('refreshSystemPrinters error:', err);
        printerSelect.innerHTML = '<option value="">Error detecting printers</option>';
    }
};


// ─────────────────────────────────────────────
// WHOLESALE DYNAMIC PRICING & CATEGORY RULES ENGINE
// ─────────────────────────────────────────────
window.updateWholesaleModeUI = () => {
    const mode = document.getElementById('set-wholesale-mode')?.value || 'cost_markup';
    const label = document.getElementById('set-wholesale-val-label');
    const hint = document.getElementById('set-wholesale-val-hint');
    if (mode === 'cost_markup') {
        if (label) label.innerText = 'Auto-Wholesale Markup (%) from COST';
        if (hint) hint.innerText = 'Default fallback wholesale markup added on top of cost (e.g. 8% means Cost × 1.08).';
    } else {
        if (label) label.innerText = 'Auto-Wholesale Discount (%) from MRP';
        if (hint) hint.innerText = 'Default fallback wholesale discount deducted from MRP (e.g. 15% means MRP × 0.85).';
    }
};

window.calculateDynamicWholesalePrice = (cost, price, category = '') => {
    cost = parseFloat(cost) || 0;
    price = parseFloat(price) || 0;
    const catRules = window.systemConfig?.categoryWholesaleRules || window.categoryWholesaleRules || [];
    const catNorm = (category || '').trim().toLowerCase();
    const specificRule = catRules.find(r => {
        if (!r) return false;
        const rCat = (typeof r.category === 'string' ? r.category : (r.category?.name || r.category?.category || '')).trim().toLowerCase();
        return rCat && rCat === catNorm;
    });

    let mode = specificRule ? specificRule.mode : (window.systemConfig?.wholesalePricingMode || 'cost_markup');
    let val = specificRule ? parseFloat(specificRule.value) : (parseFloat(window.systemConfig?.wholesaleDiscount) || (mode === 'cost_markup' ? 8 : 15));
    if (isNaN(val)) val = 0;

    let calculated = 0;
    if (mode === 'cost_markup') {
        if (cost > 0) {
            calculated = cost * (1 + val / 100);
        } else if (price > 0) {
            calculated = price * 0.9;
        }
    } else {
        // mrp_discount mode
        if (price > 0) {
            calculated = price * (1 - val / 100);
        } else if (cost > 0) {
            calculated = cost * 1.1;
        }
    }

    // Profit protection check: ensure wholesale price is never below cost + minimum profit margin
    const minMargin = parseFloat(window.systemConfig?.profitMargin) || 0;
    if (cost > 0 && minMargin > 0) {
        const minSafePrice = cost * (1 + minMargin / 100);
        if (calculated < minSafePrice) {
            calculated = minSafePrice;
        }
    }

    return Math.round(calculated * 100) / 100;
};

window.categoryWholesaleRules = [];

window.getCategoryNamesList = () => {
    const raw = window.allCategories || [];
    const names = [];
    raw.forEach(c => {
        if (!c) return;
        const name = typeof c === 'string' ? c.trim() : (c.name || c.category || c.title || '').trim();
        if (name && name !== '[object Object]' && !names.includes(name)) {
            names.push(name);
        }
    });

    // Fallback: extract distinct categories from inventory if allCategories is empty
    if (names.length === 0 && Array.isArray(window.allProducts)) {
        window.allProducts.forEach(p => {
            const pCat = (p?.category || '').trim();
            if (pCat && pCat !== '[object Object]' && !names.includes(pCat)) {
                names.push(pCat);
            }
        });
    }

    return names;
};

window.renderCategoryWholesaleRules = () => {
    const container = document.getElementById('cat-wholesale-rules-list');
    if (!container) return;

    if (!window.categoryWholesaleRules || window.categoryWholesaleRules.length === 0) {
        container.innerHTML = '<div style="color: #94a3b8; font-size: 0.8rem; font-style: italic; padding: 6px 0;">No category-specific rules added yet. All products will use the default wholesale setting above.</div>';
        return;
    }

    const categories = window.getCategoryNamesList();

    container.innerHTML = window.categoryWholesaleRules.map((rule, idx) => {
        let selectedCat = '';
        if (rule) {
            if (typeof rule.category === 'string') {
                selectedCat = rule.category.trim();
            } else if (rule.category && typeof rule.category === 'object') {
                selectedCat = (rule.category.name || rule.category.category || rule.category.title || '').trim();
            }
        }
        if (selectedCat === '[object Object]') selectedCat = '';

        // If rule has no valid category or corrupted [object Object], default to first available category
        if (!selectedCat && categories.length > 0) {
            selectedCat = categories[0];
            rule.category = selectedCat;
        }

        const catOptions = categories.map(c => `<option value="${c}" ${c === selectedCat ? 'selected' : ''}>${c}</option>`).join('');
        const isCustom = selectedCat && !categories.includes(selectedCat);
        const customOption = isCustom ? `<option value="${selectedCat}" selected>${selectedCat}</option>` : '';

        return `
            <div style="display: grid; grid-template-columns: 2fr 1.5fr 1fr 40px; gap: 8px; align-items: center; background: rgba(0,0,0,0.25); padding: 8px 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08);">
                <select class="cat-rule-category" style="background: #1e293b; color: white; border: 1px solid rgba(255,255,255,0.2); padding: 6px 8px; border-radius: 6px; font-size: 0.82rem;" onchange="window.updateCategoryRule(${idx}, 'category', this.value)">
                    <option value="">-- Select Category --</option>
                    ${catOptions}
                    ${customOption}
                </select>
                <select class="cat-rule-mode" style="background: #1e293b; color: white; border: 1px solid rgba(255,255,255,0.2); padding: 6px 8px; border-radius: 6px; font-size: 0.82rem;" onchange="window.updateCategoryRule(${idx}, 'mode', this.value)">
                    <option value="cost_markup" ${rule.mode === 'cost_markup' ? 'selected' : ''}>Cost Markup (%)</option>
                    <option value="mrp_discount" ${rule.mode === 'mrp_discount' ? 'selected' : ''}>MRP Discount (%)</option>
                </select>
                <input type="number" class="cat-rule-val" value="${rule.value !== undefined ? rule.value : 8}" step="0.1" min="0" max="100" style="background: #1e293b; color: white; border: 1px solid rgba(255,255,255,0.2); padding: 6px 8px; border-radius: 6px; font-size: 0.82rem; width: 100%; box-sizing: border-box;" placeholder="%" oninput="window.updateCategoryRule(${idx}, 'value', parseFloat(this.value) || 0)">
                <button type="button" onclick="window.removeCategoryWholesaleRule(${idx})" title="Remove Rule" style="background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); color: #ef4444; border-radius: 6px; cursor: pointer; padding: 6px; font-size: 0.85rem; display: flex; align-items: center; justify-content: center;">🗑️</button>
            </div>
        `;
    }).join('');
};

window.addCategoryWholesaleRuleRow = (cat = '', mode = 'cost_markup', val = 8) => {
    const cats = window.getCategoryNamesList();
    const existingRules = window.categoryWholesaleRules || [];
    const availableCat = cats.find(c => !existingRules.some(r => {
        const rCat = typeof r.category === 'string' ? r.category : (r.category?.name || '');
        return rCat === c;
    })) || cats[0] || '';

    let targetCat = cat;
    if (typeof targetCat === 'object' && targetCat !== null) {
        targetCat = targetCat.name || targetCat.category || '';
    }
    targetCat = (targetCat || availableCat || '').trim();
    if (targetCat === '[object Object]') targetCat = availableCat;

    window.categoryWholesaleRules.push({
        category: targetCat,
        mode: mode,
        value: val
    });
    window.renderCategoryWholesaleRules();
};

window.updateCategoryRule = (idx, field, value) => {
    if (window.categoryWholesaleRules[idx]) {
        if (field === 'category') {
            let cat = value;
            if (typeof cat === 'object' && cat !== null) cat = cat.name || cat.category || '';
            window.categoryWholesaleRules[idx].category = (cat || '').trim();
        } else {
            window.categoryWholesaleRules[idx][field] = value;
        }
    }
};

window.removeCategoryWholesaleRule = (idx) => {
    window.categoryWholesaleRules.splice(idx, 1);
    window.renderCategoryWholesaleRules();
};

window.collectCategoryWholesaleRules = () => {
    return (window.categoryWholesaleRules || [])
        .map(r => {
            let cat = '';
            if (typeof r.category === 'string') {
                cat = r.category.trim();
            } else if (r.category && typeof r.category === 'object') {
                cat = (r.category.name || r.category.category || '').trim();
            }
            return {
                category: cat,
                mode: r.mode || 'cost_markup',
                value: parseFloat(r.value) || 0
            };
        })
        .filter(r => r.category && r.category !== '[object Object]');
};


window.saveGlobalSettings = async () => {
    try {
        window.showToast("Saving system configuration...", "info");
        const storeId = (typeof window.getStoreId === 'function' ? window.getStoreId() : (window.currentStoreId || 'global'));

        const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';

        const getVal = (id, def = "") => document.getElementById(id)?.value?.trim() ?? def;
        const getNum = (id, def = 0) => {
            const v = parseFloat(document.getElementById(id)?.value);
            return isNaN(v) ? def : v;
        };
        const getChecked = (id, def = true) => {
            const el = document.getElementById(id);
            return el ? el.checked : def;
        };

        const storeLogoUrl = getVal('set-store-logo-url', "");

        const rules = window.collectCategoryWholesaleRules();

        const rawConfig = {
            bizName: getVal('set-biz-name', '') || (window.systemConfig?.bizName) || (isMec ? 'MEC BOOK SHOP & COMMUNICATION' : 'My Store'),
            storeLogoUrl: storeLogoUrl,
            logoUrl: storeLogoUrl,
            currency: getVal('set-currency', 'LKR'),
            taxRate: getNum('set-tax', 0),
            wholesalePricingMode: getVal('set-wholesale-mode', 'cost_markup'),
            wholesaleDiscount: getNum('set-wholesale-discount', 8),
            categoryWholesaleRules: rules,
            loyaltyDiscount: getNum('set-loyalty-discount', 0),
            loyaltyRate: getNum('set-loyalty-rate', 0),
            profitMargin: getNum('set-profit-margin', 0),
            storeLatitude: getNum('set-store-latitude', 0),
            storeLongitude: getNum('set-store-longitude', 0),
            aiLanguage: getVal('set-ai-language', 'english'),
            printerType: getVal('set-printer-type', 'thermal-80'),
            printerName: getVal('set-printer-name', ''),
            autoPrint: getVal('set-auto-print', 'yes'),
            invTemplate: getVal('set-inv-template', 'classic'),
            invAddress: getVal('set-inv-address', ''),
            invPhone: getVal('set-inv-phone', ''),
            invFooter: getVal('set-inv-footer', ''),
            showLogo: getChecked('set-show-logo', true),
            modules: {
                mrp: getChecked('toggle-mrp', true),
                hrm: getChecked('toggle-hrm', true),
                web: getChecked('toggle-web', true)
            },
            favorites: Array.from(document.querySelectorAll('.favorite-checkbox:checked')).map(cb => cb.value),
            smsConfig: {
                apiBase: getVal('set-sms-api-base', '') || (window.systemConfig?.smsConfig?.apiBase) || (isMec ? "https://www.smslenz.lk/api/send-sms" : ""),
                apiKey: getVal('set-sms-api-key', '') || (window.systemConfig?.smsConfig?.apiKey) || (isMec ? "40b621ec-69ba-48c4-869b-cf30f3f58791" : ""),
                userId: getVal('set-sms-user-id', '') || (window.systemConfig?.smsConfig?.userId) || (isMec ? "981" : ""),
                senderId: getVal('set-sms-sender-id', '') || (window.systemConfig?.smsConfig?.senderId) || (isMec ? "MECBookShop" : "")
            },
            metaWhatsappConfig: {
                phoneNumberId: getVal('set-whatsapp-phone-id', '') || (window.systemConfig?.metaWhatsappConfig?.phoneNumberId) || (isMec ? "1299065503300070" : ""),
                accessToken: getVal('set-whatsapp-access-token', '') || (window.systemConfig?.metaWhatsappConfig?.accessToken) || (isMec ? "EAAaRKVpmPacBS9gsj3D2KqW06sk06ml3mukfIbmIUcw4ShnYNbCMRQsHClUjr6dZB9lN3fIg0wV5QrC7p2U5tgVbf0mzA8nLG3n5FCfOZA5CrjaBH5MBuDGI1Q7X4TWn6IYKi05ZABbnrUbXOpXShLsh2cwLTBCzPk93V3ZAyoxLfcYLC7XNWDgnW8SYZBszlWwZDZD" : ""),
                defaultPhone: getVal('set-whatsapp-default-phone', '') || (window.systemConfig?.metaWhatsappConfig?.defaultPhone) || (isMec ? "0770658356" : "")
            },
            payhereConfig: {
                merchantId: getVal('set-payhere-merchant-id', ''),
                merchantSecret: getVal('set-payhere-merchant-secret', ''),
                mode: getVal('set-payhere-mode', 'sandbox')
            },
            dialogQrUrl: getVal('set-dialog-qr-url', '')
        };

        // Deep clone to ensure no undefined values
        const config = JSON.parse(JSON.stringify(rawConfig));
        config.lastUpdated = serverTimestamp();

        const customDevName = getVal('set-device-name', '');
        if (customDevName) {
            localStorage.setItem('mecpos_device_custom_name', customDevName);
            localStorage.setItem(`mecpos_device_name_${storeId}`, customDevName);
            if (typeof window.registerDeviceToFirebase === 'function') {
                window.registerDeviceToFirebase(customDevName);
            }
        }

        const selectedPrinter = getVal('set-printer-name', '');
        if (selectedPrinter) {
            localStorage.setItem('mecpos_selected_printer', selectedPrinter);
        }

        // Update local in-memory config and localStorage immediately
        window.systemConfig = { ...window.systemConfig, ...rawConfig };
        window.categoryWholesaleRules = rules;
        const storeCacheKey = `mecpos_system_config_${storeId}`;
        try {
            localStorage.setItem(storeCacheKey, JSON.stringify(rawConfig));
            localStorage.setItem('mecpos_system_config_cache', JSON.stringify(rawConfig));
            if (storeLogoUrl) localStorage.setItem('mecpos_store_logo', storeLogoUrl);
        } catch(cErr) {}

        // Save to Firestore with merge: true
        try {
            await setDoc(doc(db, 'config', storeId), config, { merge: true });
        } catch (dbErr) {
            console.error("setDoc config error:", dbErr);
            await updateDoc(doc(db, 'config', storeId), config);
        }

        try {
            if (storeId) {
                await setDoc(doc(db, 'stores', storeId), { logoUrl: storeLogoUrl, name: config.bizName }, { merge: true });
            }
        } catch(stErr) {
            console.warn("stores doc sync warning:", stErr);
        }

        window.showToast("✅ Settings Saved Successfully!", "success");
    } catch (err) {
        console.error("Save global settings error:", err);
        window.showToast("Error saving settings: " + (err.message || err), "error");
    }
};

window.loadSystemSettings = async () => {
    const storeId = window.getStoreId();
    
    // safe helper utilities for rendering
    const safeSetVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val !== undefined && val !== null ? val : "";
    };
    const safeSetChecked = (id, checked) => {
        const el = document.getElementById(id);
        if (el) el.checked = !!checked;
    };

    // --- Synchronously load from store-isolated local cache first for instant offline/errored rendering ---
    try {
        const storeCacheKey = `mecpos_system_config_${storeId}`;
        const cachedDataStr = localStorage.getItem(storeCacheKey) || localStorage.getItem('mecpos_system_config_cache');
        if (cachedDataStr) {
            const localData = JSON.parse(cachedDataStr);
            window.systemConfig = localData;
            const localFavs = localData.favorites || [];
            window.renderFavoritesSidebar(localFavs);
            if (localData.modules) {
                window.applyModuleVisibility(localData.modules);
            }
            if (document.getElementById('set-biz-name')) {
                safeSetVal('set-biz-name', localData.bizName);
                safeSetVal('set-store-logo-url', localData.storeLogoUrl || localData.logoUrl || "");
                const localLogoPreview = document.getElementById('set-store-logo-preview');
                const defaultLogo = '/logo.png';
                if (localLogoPreview) localLogoPreview.src = localData.storeLogoUrl || localData.logoUrl || defaultLogo;
                safeSetVal('set-currency', localData.currency || "LKR");
                safeSetVal('set-tax', localData.taxRate || 0);
                safeSetVal('set-wholesale-mode', localData.wholesalePricingMode || 'cost_markup');
                if (window.updateWholesaleModeUI) window.updateWholesaleModeUI();
                const rawLocalCatRules = Array.isArray(localData.categoryWholesaleRules) ? localData.categoryWholesaleRules : [];
                window.categoryWholesaleRules = rawLocalCatRules.map(r => {
                    let cat = typeof r.category === 'string' ? r.category.trim() : (r.category?.name || r.category?.category || '');
                    if (cat === '[object Object]') cat = '';
                    return {
                        category: cat,
                        mode: r.mode || 'cost_markup',
                        value: r.value !== undefined ? r.value : 8
                    };
                });
                if (window.renderCategoryWholesaleRules) window.renderCategoryWholesaleRules();
                safeSetVal('set-loyalty-discount', localData.loyaltyDiscount || 0);
                safeSetVal('set-loyalty-rate', localData.loyaltyRate || 0);
                safeSetVal('set-profit-margin', localData.profitMargin !== undefined ? localData.profitMargin : 0);
                safeSetVal('set-store-latitude', localData.storeLatitude);
                safeSetVal('set-store-longitude', localData.storeLongitude);
                safeSetVal('set-ai-language', localData.aiLanguage || "english");
                const currentDevName = localStorage.getItem('mecpos_device_custom_name') || localStorage.getItem(`mecpos_device_name_${storeId}`) || localStorage.getItem('mecpos_machine_name') || 'MEC PC 1';
                safeSetVal('set-device-name', currentDevName);
                const detectedHost = localStorage.getItem('mecpos_machine_name');
                const mHostEl = document.getElementById('set-detected-machine-name');
                if (mHostEl && detectedHost) mHostEl.innerText = detectedHost;

                safeSetVal('set-printer-type', localData.printerType || "thermal-80");
                const pSelect = document.getElementById('set-printer-name');
                if (pSelect) pSelect.value = localData.printerName || "";
                safeSetVal('set-inv-address', localData.invAddress);
                safeSetVal('set-inv-phone', localData.invPhone);
                safeSetVal('set-inv-footer', localData.invFooter);
                safeSetVal('set-auto-print', localData.autoPrint || "yes");
                safeSetChecked('set-show-logo', localData.showLogo !== false);
                const tplValue = localData.invTemplate || "classic";
                safeSetVal('set-inv-template', tplValue);
                if (window.selectInvoiceTemplate) window.selectInvoiceTemplate(tplValue, true);
                const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';
                const smsConf = localData.smsConfig || {};
                safeSetVal('set-sms-api-base', smsConf.apiBase || (isMec ? "https://www.smslenz.lk/api/send-sms" : ""));
                safeSetVal('set-sms-api-key', smsConf.apiKey || (isMec ? "40b621ec-69ba-48c4-869b-cf30f3f58791" : ""));
                safeSetVal('set-sms-user-id', smsConf.userId || (isMec ? "981" : ""));
                safeSetVal('set-sms-sender-id', smsConf.senderId || (isMec ? "MECBookShop" : ""));
                const whatsappConf = localData.metaWhatsappConfig || {};
                safeSetVal('set-whatsapp-phone-id', whatsappConf.phoneNumberId || (isMec ? "1299065503300070" : ""));
                safeSetVal('set-whatsapp-access-token', whatsappConf.accessToken || (isMec ? "EAAaRKVpmPacBS9gsj3D2KqW06sk06ml3mukfIbmIUcw4ShnYNbCMRQsHClUjr6dZB9lN3fIg0wV5QrC7p2U5tgVbf0mzA8nLG3n5FCfOZA5CrjaBH5MBuDGI1Q7X4TWn6IYKi05ZABbnrUbXOpXShLsh2cwLTBCzPk93V3ZAyoxLfcYLC7XNWDgnW8SYZBszlWwZDZD" : ""));
                safeSetVal('set-whatsapp-default-phone', whatsappConf.defaultPhone || (isMec ? "0770658356" : ""));
                const payhereConf = localData.payhereConfig || {};
                safeSetVal('set-payhere-merchant-id', payhereConf.merchantId);
                safeSetVal('set-payhere-merchant-secret', payhereConf.merchantSecret);
                safeSetVal('set-payhere-mode', payhereConf.mode || "sandbox");
                safeSetVal('set-dialog-qr-url', localData.dialogQrUrl || "");
                window._configuredDialogQrUrl = localData.dialogQrUrl || "";
                window.renderFavoritesSettings(localFavs);
                if (localData.modules) {
                    safeSetChecked('toggle-mrp', localData.modules.mrp !== false);
                    safeSetChecked('toggle-hrm', localData.modules.hrm !== false);
                    safeSetChecked('toggle-web', localData.modules.web !== false);
                }
            }
        } else {
            // Render basic defaults immediately if no cache
            const defaultFavs = [];
            window.renderFavoritesSidebar(defaultFavs);
            window.renderFavoritesSettings(defaultFavs);
        }
    } catch (cacheErr) {
        console.warn("Failed to load settings from local storage cache", cacheErr);
    }

    onSnapshot(doc(db, 'config', storeId), (snapshot) => {
        try {
            if (snapshot.exists()) {
                const data = snapshot.data();
                window.systemConfig = data;
                
                // Cache system config isolated per merchant locally
                try {
                    const storeCacheKey = `mecpos_system_config_${storeId}`;
                    localStorage.setItem(storeCacheKey, JSON.stringify(data));
                    localStorage.setItem('mecpos_system_config_cache', JSON.stringify(data));
                    if (window.chrome?.webview) {
                        const unifiedCache = {
                            storeId: storeId,
                            storeInfo: window.storeInfo || {},
                            systemConfig: data
                        };
                        window.chrome.webview.postMessage({ type: 'savePlanConfig', data: JSON.stringify(unifiedCache) });
                    }
                } catch (e) {
                    console.warn("Failed to cache system config", e);
                }
                
                // Render favorites and modules globally first
                const favs = data.favorites || [];
                window.renderFavoritesSidebar(favs);
                if (data.modules) {
                    window.applyModuleVisibility(data.modules);
                }

                // If cloud has an active theme configured, apply it (unless local has explicit preference)
                if (data.activeTheme && typeof window.setAdminTheme === 'function') {
                    const localTheme = localStorage.getItem('mec_active_theme');
                    const targetTheme = localTheme || data.activeTheme;
                    window.setAdminTheme(targetTheme, true, true);
                }
                
                // Helper functions to safely update DOM values
                const safeSetVal = (id, val) => {
                    const el = document.getElementById(id);
                    if (el) el.value = val !== undefined && val !== null ? val : "";
                };
                const safeSetChecked = (id, checked) => {
                    const el = document.getElementById(id);
                    if (el) el.checked = !!checked;
                };

                // Populate UI if in settings tab
                if (document.getElementById('set-biz-name')) {
                    safeSetVal('set-biz-name', data.bizName);
                    safeSetVal('set-store-logo-url', data.storeLogoUrl || data.logoUrl || "");
                    const logoPreview = document.getElementById('set-store-logo-preview');
                    const defaultLogo = '/logo.png';
                    if (logoPreview) logoPreview.src = data.storeLogoUrl || data.logoUrl || defaultLogo;
                    if (data.storeLogoUrl || data.logoUrl) {
                        const activeLogoUrl = data.storeLogoUrl || data.logoUrl;
                        document.querySelectorAll('.login-header img, #mi-logo-actual').forEach(img => {
                            img.src = activeLogoUrl;
                        });
                    }
                    safeSetVal('set-currency', data.currency || "LKR");
                    safeSetVal('set-tax', data.taxRate || 0);
                    safeSetVal('set-wholesale-mode', data.wholesalePricingMode || 'cost_markup');
                    if (window.updateWholesaleModeUI) window.updateWholesaleModeUI();
                    safeSetVal('set-wholesale-discount', data.wholesaleDiscount !== undefined ? data.wholesaleDiscount : 8);
                    const rawCloudCatRules = Array.isArray(data.categoryWholesaleRules) ? data.categoryWholesaleRules : [];
                    window.categoryWholesaleRules = rawCloudCatRules.map(r => {
                        let cat = typeof r.category === 'string' ? r.category.trim() : (r.category?.name || r.category?.category || '');
                        if (cat === '[object Object]') cat = '';
                        return {
                            category: cat,
                            mode: r.mode || 'cost_markup',
                            value: r.value !== undefined ? r.value : 8
                        };
                    });
                    if (window.renderCategoryWholesaleRules) window.renderCategoryWholesaleRules();
                    safeSetVal('set-loyalty-discount', data.loyaltyDiscount || 0);
                    safeSetVal('set-loyalty-rate', data.loyaltyRate || 0);
                    safeSetVal('set-profit-margin', data.profitMargin !== undefined ? data.profitMargin : 0);
                    safeSetVal('set-store-latitude', data.storeLatitude);
                    safeSetVal('set-store-longitude', data.storeLongitude);
                    safeSetVal('set-ai-language', data.aiLanguage || "english");
                    const currentDevName = localStorage.getItem('mecpos_device_custom_name') || localStorage.getItem(`mecpos_device_name_${storeId}`) || localStorage.getItem('mecpos_machine_name') || 'MEC PC 1';
                    safeSetVal('set-device-name', currentDevName);
                    const detectedHost = localStorage.getItem('mecpos_machine_name');
                    const mHostEl = document.getElementById('set-detected-machine-name');
                    if (mHostEl && detectedHost) mHostEl.innerText = detectedHost;

                    safeSetVal('set-printer-type', data.printerType || "thermal-80");
                    
                    const pSelect = document.getElementById('set-printer-name');
                    if (pSelect) {
                        pSelect.value = data.printerName || "";
                    }
                    safeSetVal('set-inv-address', data.invAddress);
                    safeSetVal('set-inv-phone', data.invPhone);
                    safeSetVal('set-inv-footer', data.invFooter);
                    safeSetVal('set-auto-print', data.autoPrint || "yes");
                    safeSetChecked('set-show-logo', data.showLogo !== false);
                    
                    const tplValue = data.invTemplate || "classic";
                    safeSetVal('set-inv-template', tplValue);
                    if (window.selectInvoiceTemplate) {
                        window.selectInvoiceTemplate(tplValue, true);
                    }

                    const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';

                    // Populate SMS Config
                    const smsConf = data.smsConfig || {};
                    safeSetVal('set-sms-api-base', smsConf.apiBase || (isMec ? "https://www.smslenz.lk/api/send-sms" : ""));
                    safeSetVal('set-sms-api-key', smsConf.apiKey || (isMec ? "40b621ec-69ba-48c4-869b-cf30f3f58791" : ""));
                    safeSetVal('set-sms-user-id', smsConf.userId || (isMec ? "981" : ""));
                    safeSetVal('set-sms-sender-id', smsConf.senderId || (isMec ? "MECBookShop" : ""));

                    // Populate WhatsApp API Config
                    const whatsappConf = data.metaWhatsappConfig || {};
                    safeSetVal('set-whatsapp-phone-id', whatsappConf.phoneNumberId || (isMec ? "1299065503300070" : ""));
                    safeSetVal('set-whatsapp-access-token', whatsappConf.accessToken || (isMec ? "EAAaRKVpmPacBS9gsj3D2KqW06sk06ml3mukfIbmIUcw4ShnYNbCMRQsHClUjr6dZB9lN3fIg0wV5QrC7p2U5tgVbf0mzA8nLG3n5FCfOZA5CrjaBH5MBuDGI1Q7X4TWn6IYKi05ZABbnrUbXOpXShLsh2cwLTBCzPk93V3ZAyoxLfcYLC7XNWDgnW8SYZBszlWwZDZD" : ""));
                    safeSetVal('set-whatsapp-default-phone', whatsappConf.defaultPhone || (isMec ? "0770658356" : ""));

                    // Populate Payhere Config
                    const payhereConf = data.payhereConfig || {};
                    safeSetVal('set-payhere-merchant-id', payhereConf.merchantId);
                    safeSetVal('set-payhere-merchant-secret', payhereConf.merchantSecret);
                    safeSetVal('set-payhere-mode', payhereConf.mode || "sandbox");

                    // Populate Dialog QR Reload URL
                    safeSetVal('set-dialog-qr-url', data.dialogQrUrl || "");
                    // Also cache it globally so openDialogPortalPopup can read it instantly
                    window._configuredDialogQrUrl = data.dialogQrUrl || "";

                    window.renderFavoritesSettings(favs);

                    // Apply Module Toggles in settings inputs
                    if (data.modules) {
                        safeSetChecked('toggle-mrp', data.modules.mrp !== false);
                        safeSetChecked('toggle-hrm', data.modules.hrm !== false);
                        safeSetChecked('toggle-web', data.modules.web !== false);
                    }

                    if (document.getElementById('set-low-end-mode')) {
                        const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
                        document.getElementById('set-low-end-mode').checked = isLowEnd;
                        if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                        setTimeout(() => {
                            if (window.isLowEndModeEnabled === true) {
                                safeSetChecked('set-low-end-mode', true);
                                localStorage.setItem('mec_low_end_mode', 'true');
                                if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                            }
                        }, 1000);
                    }

                    if (document.getElementById('set-pos-auto-scan')) {
                        document.getElementById('set-pos-auto-scan').checked = localStorage.getItem('mec_pos_auto_scan') === 'true';
                    }
                }
            } else {
                // No config yet, render default favorites
                const defaultFavs = [];
                window.renderFavoritesSettings(defaultFavs);
                window.renderFavoritesSidebar(defaultFavs);
                
                const isLowEnd = window.isLowEndModeEnabled === true || localStorage.getItem('mec_low_end_mode') === 'true';
                const lem = document.getElementById('set-low-end-mode');
                if (lem) lem.checked = isLowEnd;
                if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                setTimeout(() => {
                    if (window.isLowEndModeEnabled === true) {
                        const lem2 = document.getElementById('set-low-end-mode');
                        if (lem2) lem2.checked = true;
                        localStorage.setItem('mec_low_end_mode', 'true');
                        if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();
                    }
                }, 1000);

                const pas = document.getElementById('set-pos-auto-scan');
                if (pas) pas.checked = localStorage.getItem('mec_pos_auto_scan') === 'true';
            }
        } catch (err) {
            console.error("Error in loadSystemSettings snapshot listener:", err);
            if (window.showToast) window.showToast("Settings Load Error: " + err.message, "error");
        }
    });
};

window.toggleLowEndMode = async (enabled) => {
    localStorage.setItem('mec_low_end_mode', enabled ? 'true' : 'false');
    if (window.applyLowEndOptimizations) window.applyLowEndOptimizations();

    // ── Permanently save to Firebase so fresh installs auto-apply this setting ──
    try {
        await setDoc(doc(db, 'appConfig', 'performance'), {
            lowPerformanceMode: enabled,
            updatedAt: new Date().toISOString(),
            updatedBy: sessionStorage.getItem('userName') || 'Admin'
        }, { merge: true });
        console.log('[PerfSettings] Firebase updated: lowPerformanceMode =', enabled);
    } catch (e) {
        console.warn('[PerfSettings] Firebase save failed:', e.message);
    }

    if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage({ type: 'toggleLowEndMode', disableGpu: enabled });
        window.showToast(
            enabled
                ? "⚡ Low-End Mode Saved to Firebase! Please restart MEC POS to apply."
                : "✅ Low-End Mode Disabled & Saved! Please restart MEC POS.",
            "success"
        );
    } else {
        window.showToast("This feature is only available in the MEC POS Desktop App.", "error");
        document.getElementById('set-low-end-mode').checked = !enabled;
    }
};

window.renderFavoritesSettings = (favorites = []) => {
    const grid = document.getElementById('favorites-selection-grid');
    if (!grid) return;

    const modules = [
        { id: 'pos', name: 'POS Terminal', icon: '💻' },
        { id: 'orders', name: 'Sales & Orders', icon: '📦' },
        { id: 'web-orders', name: 'Web Store Orders', icon: '🛒' },
        { id: 'reload', name: 'Reload Terminal', icon: '📱' },
        { id: 'products', name: 'Product Master', icon: '📚' },
        { id: 'stock', name: 'Smart Procurement', icon: '📥' },
        { id: 'stocks-view', name: 'Current Stocks', icon: '📦' },
        { id: 'categories', name: 'Categories', icon: '🏷️' },
        { id: 'mrp', name: 'MRP Hub', icon: '🏭' },
        { id: 'reports', name: 'Final Reports', icon: '📊' },
        { id: 'expenses', name: 'Expenditure', icon: '💸' },
        { id: 'income', name: 'Misc Income', icon: '💰' },
        { id: 'credit', name: 'Credit Ledger', icon: '⏳' },
        { id: 'suppliers', name: 'Supplier Database', icon: '🤝' },
        { id: 'supplier-invoices', name: 'Supplier Invoices', icon: '📑' },
        { id: 'purchases', name: 'Purchase Logs', icon: '🛍️' },
        { id: 'promotions', name: 'Promotions', icon: '🎁' },
        { id: 'customers', name: 'Customer Database', icon: '👥' },
        { id: 'repairs', name: 'Service Center', icon: '🔧' },
        { id: 'hrm', name: 'HRM & Payroll', icon: '👔' },
        { id: 'branches', name: 'Branch Network', icon: '🏢' },
        { id: 'it-system', name: 'IT & Security', icon: '🛡️' },
        { id: 'appearance', name: 'Appearance', icon: '✨' },
        { id: 'web-dev', name: 'Website Studio', icon: '🌐' }
    ];

    grid.innerHTML = modules.map(m => `
        <label class="module-toggle-card" style="cursor: pointer; transition: 0.2s; color: #fff; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 12px; display: flex; justify-content: space-between; align-items: center; ${favorites.includes(m.id) ? 'border-color: #38bdf8; background: rgba(56, 189, 248, 0.05);' : ''}">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 1.5rem;">${m.icon}</span>
                <div>
                    <div style="font-weight: 700; font-size: 0.85rem; color: #fff;">${m.name}</div>
                    <div style="font-size: 0.65rem; color: #94a3b8;">Tab ID: ${m.id}</div>
                </div>
            </div>
            <input type="checkbox" class="favorite-checkbox toggle-switch" value="${m.id}" ${favorites.includes(m.id) ? 'checked' : ''} 
                   onchange="this.closest('.module-toggle-card').style.borderColor = this.checked ? '#38bdf8' : 'rgba(255,255,255,0.1)'; this.closest('.module-toggle-card').style.background = this.checked ? 'rgba(56, 189, 248, 0.05)' : 'rgba(255,255,255,0.03)';">
        </label>
    `).join('');
}

window.renderFavoritesSidebar = (favorites = []) => {
    const container = document.getElementById('favorite-apps-container');
    const list = document.getElementById('favorite-apps-list');
    if (!container || !list) return;

    const modules = {
        'pos': ['POS Terminal', '💻'],
        'orders': ['Sales & Orders', '📦'],
        'web-orders': ['Web Store Orders', '🛒'],
        'reload': ['Reload Terminal', '📱'],
        'products': ['Product Master', '📚'],
        'stock': ['Smart Procurement', '📥'],
        'stocks-view': ['Current Stocks', '📦'],
        'categories': ['Categories', '🏷️'],
        'mrp': ['MRP Hub', '🏭'],
        'reports': ['Final Reports', '📊'],
        'report-hub': ['Report Download', '📥'],
        'analytics': ['Advanced Analytics', '📈'],
        'expenses': ['Expenditure', '💸'],
        'income': ['Misc Income', '💰'],
        'credit': ['Credit Ledger', '⏳'],
        'suppliers': ['Supplier Database', '🤝'],
        'supplier-invoices': ['Supplier Invoices', '📑'],
        'purchase-orders': ['Purchase Orders', '📝'],
        'po-saved': ['Saved POs', '📁'],
        'purchases': ['Purchase Logs', '🛍️'],
        'promotions': ['Promotions', '🎁'],
        'customers': ['Customer Database', '👥'],
        'repairs': ['Service Center', '🔧'],
        'hrm': ['HRM & Payroll', '👔'],
        'bank': ['Bank Manager', '🏦'],
        'branches': ['Branch Network', '🏢'],
        'it-system': ['IT & Security', '🛡️'],
        'appearance': ['Appearance', '✨'],
        'web-dev': ['Website Studio', '🌐'],
        'settings': ['System Settings', '⚙️'],
        'ai-copilot': ['AI Business Copilot', '🤖']
    };

    let targetFavs = (favorites && favorites.length > 0) ? favorites : [];
    
    // If no favorites configured or allowed, fallback to role allowed primary tabs
    if (window.allowedTabs && window.allowedTabs.length > 0) {
        const allowedInFavs = targetFavs.filter(id => window.allowedTabs.includes(id));
        if (allowedInFavs.length === 0) {
            // Take the first 7 primary allowed tabs for this user's role
            targetFavs = window.allowedTabs.slice(0, 7);
        }
    } else if (targetFavs.length === 0) {
        targetFavs = ['pos', 'orders', 'web-orders', 'reload', 'products', 'stock', 'stocks-view'];
    }

    const validFavs = targetFavs.filter(id => modules[id] && (!window.allowedTabs || window.allowedTabs.includes(id)));

    if (validFavs.length === 0) {
        container.style.display = 'none';
        list.innerHTML = '';
        return;
    }

    container.style.display = 'flex';
    container.style.flexDirection = 'column';

    list.innerHTML = validFavs.map(id => {
        const mod = modules[id];
        const isActive = (window.currentActiveTab === id) ? ' active' : '';
        return `
            <button class="nav-tab favorite-pin${isActive}" id="fav-tab-${id}" data-tab="${id}" onclick="showTab('${id}')">
                <span class="icon">${mod[1]}</span> <span>${mod[0]}</span>
                <span style="font-size:0.65rem; color:#eab308; margin-left:auto; opacity:0.9;">★</span>
            </button>
        `;
    }).join('');

    const cyberShortcuts = document.getElementById('dash-cyber-quick-shortcuts');
    if (cyberShortcuts) {
        cyberShortcuts.innerHTML = validFavs.map((id, index) => {
            const mod = modules[id];
            const isPrimary = index === 0;
            return `
                <button onclick="showTab('${id}')" class="action-btn ${isPrimary ? 'primary' : ''}" style="width: 100%; border-radius: 10px; display: flex; align-items: center; justify-content: flex-start; gap: 8px; padding: 10px 14px; ${!isPrimary ? 'background: rgba(255,255,255,0.05); color: #f8fafc;' : ''}">
                    <span style="font-size: 1.1rem;">${mod[1]}</span>
                    <span style="font-weight: 700;">${mod[0]}</span>
                </button>
            `;
        }).join('');
    }
};

// --- Global UI Render Exports ---
window.renderBranchesUI = renderBranchesUI;
window.renderCategoriesUI = renderCategoriesUI;
window.renderStoresUI = renderStoresUI;
window.renderExpensesUI = renderExpensesUI;
window.renderPurchasesUI = renderPurchasesUI;
window.renderSuppliersUI = renderSuppliersUI;
window.renderIncomeUI = renderIncomeUI;
window.renderCustomersUI = renderCustomersUI;
window.renderAdminEmployeesUI = renderAdminEmployeesUI;
window.renderAdminPayrollUI = renderAdminPayrollUI;
window.syncAttendanceUI = syncAttendanceUI;


window.selectInvoiceTemplate = async (tpl, isLoad = false) => {
    const input = document.getElementById('set-inv-template');
    if (input) input.value = tpl;
    document.querySelectorAll('.template-card').forEach(card => {
        card.classList.remove('active');
        card.style.borderColor = 'transparent';
        card.style.background = 'rgba(255,255,255,0.02)';
    });
    const activeCard = document.getElementById('tpl-card-' + tpl);
    if (activeCard) {
        activeCard.classList.add('active');
        activeCard.style.borderColor = '#38bdf8';
        activeCard.style.background = 'rgba(56, 189, 248, 0.05)';
    }

    let targetPrinterType = 'a4';
    if (tpl === 'thermal') {
        targetPrinterType = 'thermal-80';
    } else if (tpl === 'a5') {
        targetPrinterType = 'a5';
    } else {
        targetPrinterType = 'a4';
    }

    const printerSelect = document.getElementById('set-printer-type');
    if (printerSelect && printerSelect.value !== targetPrinterType) {
        printerSelect.value = targetPrinterType;
    }

    window.systemConfig = {
        ...(window.systemConfig || {}),
        invTemplate: tpl,
        printerType: targetPrinterType
    };

    if (!isLoad) {
        window.showToast(`✨ Invoice Template set to ${tpl.toUpperCase()} (${targetPrinterType.toUpperCase()})`, "info");
        try {
            const storeId = (typeof window.getStoreId === 'function' ? window.getStoreId() : (window.currentStoreId || 'global'));
            const storeCacheKey = `mecpos_system_config_${storeId}`;
            const currentCacheStr = localStorage.getItem(storeCacheKey) || localStorage.getItem('mecpos_system_config_cache');
            let currentCached = {};
            if (currentCacheStr) {
                try { currentCached = JSON.parse(currentCacheStr); } catch(e) {}
            }
            const updatedConfig = {
                ...currentCached,
                invTemplate: tpl,
                printerType: targetPrinterType,
                lastUpdated: serverTimestamp()
            };
            localStorage.setItem(storeCacheKey, JSON.stringify(updatedConfig));
            localStorage.setItem('mecpos_system_config_cache', JSON.stringify(updatedConfig));
            await setDoc(doc(db, 'config', storeId), {
                invTemplate: tpl,
                printerType: targetPrinterType,
                lastUpdated: serverTimestamp()
            }, { merge: true });
        } catch (err) {
            console.warn("Auto-save template config warning:", err);
        }
    }
};

window.viewTemplateJPG = (src, title) => {
    const modal = document.getElementById('modal-template-view');
    const img = document.getElementById('tpl-view-img');
    const titleEl = document.getElementById('tpl-view-title');
    if (modal && img && titleEl) {
        img.src = src;
        titleEl.innerText = title;
        modal.style.display = 'flex';
    }
};

window.previewInvoiceTemplate = (tpl) => {
    const dummyItems = [
        { name: "Executive Ballpoint Pen (Blue)", quantity: 2, price: 150, discount: 10 },
        { name: "CR Single Ruled 120 Pages", quantity: 4, price: 280, discount: 0 },
        { name: "Atlas Pastel Colour Pencils 12Pk", quantity: 1, price: 650, discount: 50 }
    ];
    let testPrinterType = 'a4';
    if (tpl === 'thermal') testPrinterType = 'thermal-80';
    else if (tpl === 'a5') testPrinterType = 'a5';

    window.showToast('🚀 Printing ' + tpl.toUpperCase() + ' Template Sample...', "info");
    const originalConfig = { ...(window.systemConfig || {}) };
    window.systemConfig = { 
        ...originalConfig, 
        invTemplate: tpl, 
        printerType: testPrinterType 
    };
    try {
        const dummySaleSnapshot = {
            orderId: "SAMPLE-" + Math.floor(1000 + Math.random() * 9000),
            items: dummyItems,
            baseAmount: 1950,
            billDiscountAmount: 0,
            totalDiscount: 70, // 20 (pen) + 50 (pencils)
            tenderedAmount: 2000,
            cashBalance: 50,
            earnedLoyaltyPoints: 3,
            branchId: 'main'
        };
        window.printPOSReceipt(dummySaleSnapshot);
    } finally {
        window.systemConfig = originalConfig;
    }
};

window.toggleModule = (mod, enabled) => {
    // Check package permissions first
    const permKey = mod === 'web' ? 'web-orders' : mod;
    if (enabled && window.allowedTabs && !window.allowedTabs.includes(permKey)) {
        // Find the toggle and revert it to unchecked
        const toggleEl = document.getElementById(`toggle-${mod}`);
        if (toggleEl) toggleEl.checked = false;
        
        // Let the user know they need to upgrade
        window.showToast(`To enable this feature, please upgrade to the package that supports it.`, 'error');
        return;
    }

    const modules = window.systemConfig?.modules || { mrp: true, hrm: true, repairs: true };
    modules[mod] = enabled;
    window.applyModuleVisibility(modules);
    window.saveGlobalSettings();
};

window.applyModuleVisibility = (modules) => {
    if (!modules) return;

    // MRP Visibility
    const mrpTab = document.getElementById('tab-mrp');
    if (mrpTab) mrpTab.style.display = modules.mrp === false ? 'none' : 'flex';

    // HRM Visibility
    const hrmTab = document.getElementById('tab-hrm');
    if (hrmTab) hrmTab.style.display = modules.hrm === false ? 'none' : 'flex';

    // Repairs Visibility
    const repairsTab = document.getElementById('tab-repairs');
    if (repairsTab) repairsTab.style.display = modules.repairs === false ? 'none' : 'flex';

    // Web Store Visibility
    const webTab = document.getElementById('tab-web-orders');
    if (webTab) {
        const isAllowed = !window.allowedTabs || window.allowedTabs.includes('web-orders');
        webTab.style.display = (modules.web !== false && isAllowed) ? 'flex' : 'none';
    }

    // After changing individual tab visibility, hide any nav-group that has no visible tabs
    if (typeof window.updateNavLabelsVisibility === 'function') {
        window.updateNavLabelsVisibility();
    }
};


window.clearSINVBatch = () => {
    if (!window.currentInvoiceItems || window.currentInvoiceItems.length === 0) return;
    if (confirm("Are you sure you want to CLEAR the entire batch? All added items will be removed.")) {
        window.currentInvoiceItems = [];
        if (typeof window.clearSinvDraft === 'function') window.clearSinvDraft();
        window.renderInvoiceItemsTable(false);
        window.showToast("Batch Cleared", "info");
    }
};

window.updateSidebarSubscription = (storeInfo) => {
    const planEl = document.getElementById('sidebar-sub-plan');
    const expiryEl = document.getElementById('sidebar-sub-expiry');
    const statusEl = document.getElementById('sidebar-sub-status');
    const dotEl = document.getElementById('sidebar-sub-dot');

    if (!planEl || !expiryEl || !statusEl || !dotEl) return;

    // Cache the store info for fast future renders
    try {
        if (storeInfo && storeInfo.slug) {
            saveOfflineCache(`storeInfo_${storeInfo.slug}`, storeInfo);
        }
    } catch(e) {}

    // Plan Display
    const planName = storeInfo.plan || 'Ultimate Package';
    planEl.innerText = planName;

    // Status & Color Dot mapping
    let status = (storeInfo.status || 'Ultimate').toUpperCase();

    // Check expiration locally
    let isExpired = false;
    if (storeInfo.expiryDate) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const localToday = `${year}-${month}-${day}`;
        if (storeInfo.expiryDate < localToday) {
            isExpired = true;
            status = 'EXPIRED';
        }
    }
    statusEl.innerText = status;

    // Reset dot classes
    dotEl.className = 'status-dot';
    if (status === 'ACTIVE') {
        dotEl.classList.add('green');
    } else if (status === 'TRIAL') {
        statusIndicator.style.background = '#3b82f6';
        statusIndicator.style.boxShadow = '0 0 10px rgba(59, 130, 246, 0.4)';
    } else if (status === 'ULTIMATE') {
        dotEl.classList.add('blue');
    } else if (status === 'SUSPENDED' || status === 'EXPIRED') {
        dotEl.classList.add('red');
    } else {
        dotEl.classList.add('yellow');
    }

    // Expiration date formatting
    if (storeInfo.expiryDate) {
        try {
            const date = new Date(storeInfo.expiryDate);
            const formatted = date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
            expiryEl.innerText = formatted;
        } catch (e) {
            expiryEl.innerText = storeInfo.expiryDate;
        }
    } else {
        expiryEl.innerText = 'Never';
    }

    // Manage Fullscreen Blocker Overlay
    const overlay = document.getElementById('subscription-blocker-overlay');
    if (overlay) {
        if (isExpired || status === 'SUSPENDED') {
            overlay.style.display = 'flex';
        } else {
            overlay.style.display = 'none';
        }
    }

    // Trigger tab filtering dynamically based on the updated storeInfo plan
    if (typeof window.showAdminActions === 'function') {
        window.showAdminActions();
    }
};

window.openUpgradeModal = () => {
    const modal = document.getElementById('modal-upgrade');
    if (modal) {
        modal.style.display = 'flex';
        // Prefill current store info plan if available
        if (window.storeInfo) {
            const planStr = window.storeInfo.plan || 'Ultimate Package';
            let tier = 'Starter';
            if (planStr.toLowerCase().includes('ultimate') || planStr.toLowerCase().includes('enterprise')) tier = 'Enterprise';
            else if (planStr.toLowerCase().includes('professional') || planStr.toLowerCase().includes('business')) tier = 'Business';
            else if (planStr.toLowerCase().includes('trial')) tier = 'Trial';
            else if (planStr.toLowerCase().includes('ultimate')) tier = 'Ultimate';

            let billing = window.storeInfo.billing || 'monthly';
            
            const tierEl = document.getElementById('upgrade-plan-tier');
            const billingEl = document.getElementById('upgrade-plan-billing');
            if (tierEl) tierEl.value = tier;
            if (billingEl) billingEl.value = billing;
            if (typeof window.updateUpgradePriceDisplay === 'function') {
                window.updateUpgradePriceDisplay();
            }
        }
    }
};

window.closeUpgradeModal = () => {
    const modal = document.getElementById('modal-upgrade');
    if (modal) modal.style.display = 'none';
};

window.updateUpgradePriceDisplay = () => {
    const tier = document.getElementById('upgrade-plan-tier').value;
    const billing = document.getElementById('upgrade-plan-billing').value;
    const priceEl = document.getElementById('upgrade-price-display');
    if (!priceEl) return;

    let priceText = 'Price: LKR 0';
    if (tier === 'Starter') {
        if (billing === 'monthly') priceText = 'Price: LKR 4,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 4,083/mo (LKR 49,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 99,000 one-time';
    } else if (tier === 'Business') {
        if (billing === 'monthly') priceText = 'Price: LKR 9,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 8,250/mo (LKR 99,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 149,900 one-time';
    } else if (tier === 'Enterprise') {
        if (billing === 'monthly') priceText = 'Price: LKR 24,900/mo';
        else if (billing === 'annual') priceText = 'Price: LKR 20,750/mo (LKR 249,000/yr)';
        else if (billing === 'lifetime') priceText = 'Price: LKR 299,000 one-time';
    } else if (tier === 'Trial') {
        priceText = 'Price: LKR 0 (Free Trial)';
    } else if (tier === 'Ultimate') {
        priceText = 'One-time Payment';
    }
    priceEl.innerText = priceText;
};

window.confirmUpgradePlan = async () => {
    const btn = document.getElementById('btn-confirm-upgrade');
    if (btn) {
        btn.disabled = true;
        btn.innerText = 'Updating Package...';
    }
    try {
        const tier = document.getElementById('upgrade-plan-tier').value;
        const billing = document.getElementById('upgrade-plan-billing').value;
        const storeId = window.getStoreId();

        let tierPrefix = 'Starter Plan';
        if (tier === 'Business') tierPrefix = 'Professional Plan';
        else if (tier === 'Enterprise') tierPrefix = 'Ultimate Plan';
        else if (tier === 'Trial') tierPrefix = 'Trial Plan';
        else if (tier === 'Ultimate') tierPrefix = 'Ultimate Package';

        let billingSuffix = '(Month)';
        if (billing === 'annual') billingSuffix = '(Year)';
        else if (billing === 'lifetime') billingSuffix = '(Full)';

        const plan = `${tierPrefix} ${billingSuffix}`;

        let expiryDate = '';
        const expDateObj = new Date();
        if (billing === 'monthly') {
            expDateObj.setDate(expDateObj.getDate() + 30);
            expiryDate = expDateObj.toISOString().split('T')[0];
        } else if (billing === 'annual') {
            expDateObj.setDate(expDateObj.getDate() + 365);
            expiryDate = expDateObj.toISOString().split('T')[0];
        } else if (billing === 'lifetime') {
            expiryDate = '';
        }

        const q = query(collection(db, "stores"), where("slug", "==", storeId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            await updateDoc(doc(db, "stores", snap.docs[0].id), {
                plan,
                billing,
                expiryDate,
                status: 'Active',
                updatedAt: serverTimestamp()
            });
            window.showToast("⚡ Package updated successfully!", "success");
            window.closeUpgradeModal();
        } else {
            window.showToast("❌ Store profile not found.", "error");
        }
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error upgrading package: " + err.message, "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerText = 'Upgrade Now ⚡';
        }
    }
};

// ─── Realtime System Broadcast Banner ────────────────────────
function initSystemBroadcastListener() {
    const broadcastDoc = doc(db, 'system', 'broadcast');
    onSnapshot(broadcastDoc, (docSnap) => {
        if (!docSnap.exists()) return;
        const data = docSnap.data();
        const msg = data.message ? data.message.trim() : "";
        const active = data.active === true;
        const type = data.type || "info"; // info, warning, critical, success
        
        let banner = document.getElementById('system-broadcast-banner');
        
        if (!active || !msg) {
            if (banner) banner.style.display = 'none';
            return;
        }
        
        // Dynamic banner creation if not exists
        if (!banner) {
            banner = document.createElement('div');
            banner.id = 'system-broadcast-banner';
            // Insert it at the very top of the admin-main container
            const adminMain = document.querySelector('.admin-main');
            if (adminMain) {
                adminMain.insertBefore(banner, adminMain.firstChild);
            } else {
                document.body.insertBefore(banner, document.body.firstChild);
            }
        }
        
        // Styling based on notice status/banner type
        let bg = 'rgba(0, 245, 255, 0.15)';
        let border = '1px solid rgba(0, 245, 255, 0.3)';
        let color = '#00F5FF';
        let icon = 'ℹ️';
        
        if (type === 'warning' || type.includes('warning') || type.includes('Yellow')) {
            bg = 'rgba(234, 179, 8, 0.15)';
            border = '1px solid rgba(234, 179, 8, 0.3)';
            color = '#fbbf24';
            icon = '⚠️';
        } else if (type === 'critical' || type.includes('critical') || type.includes('Red')) {
            bg = 'rgba(239, 68, 68, 0.15)';
            border = '1px solid rgba(239, 68, 68, 0.3)';
            color = '#f87171';
            icon = '🚨';
        } else if (type === 'success' || type.includes('success') || type.includes('Green')) {
            bg = 'rgba(16, 185, 129, 0.15)';
            border = '1px solid rgba(16, 185, 129, 0.3)';
            color = '#34d399';
            icon = '✅';
        }
        
        banner.style.cssText = `
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            padding: 12px 24px;
            background: ${bg};
            border-bottom: ${border};
            color: ${color};
            font-weight: 700;
            font-size: 0.9rem;
            z-index: 1000;
            position: sticky;
            top: 0;
            backdrop-filter: blur(12px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            font-family: 'Outfit', sans-serif;
        `;
        
        banner.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.2rem;">${icon}</span>
                <span>${msg}</span>
            </div>
            <button onclick="this.parentElement.style.display='none'" style="background: none; border: none; color: inherit; font-size: 1.2rem; cursor: pointer; padding: 4px; line-height: 1; opacity: 0.7; transition: opacity 0.2s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.7">&times;</button>
        `;
        
        // Ensure displayed
        banner.style.display = 'flex';
    }, (err) => {
        console.error("System broadcast listener error:", err);
    });
}


// Auto update wholesale on Add Product input changes
['p-cost', 'p-price', 'p-category'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', () => {
        if (window.autoCalculateProductPrices) window.autoCalculateProductPrices('add');
    });
    document.getElementById(id)?.addEventListener('change', () => {
        if (window.autoCalculateProductPrices) window.autoCalculateProductPrices('add');
    });
});

window.autoCalculateProductPrices = (type) => {
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    if (type === 'add') {
        const cost = parseFloat(document.getElementById('p-cost')?.value) || 0;
        const price = parseFloat(document.getElementById('p-price')?.value) || 0;
        const category = document.getElementById('p-category')?.value || '';
        document.getElementById('p-wholesale-price').value = window.calculateDynamicWholesalePrice(cost, price, category).toFixed(2);
        if (price > 0 && loyaltyPct > 0) {
            document.getElementById('p-loyalty-price').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
        }
    } else if (type === 'edit') {
        const cost = parseFloat(document.getElementById('edit-p-cost')?.value) || 0;
        const price = parseFloat(document.getElementById('edit-p-price')?.value) || 0;
        const category = document.getElementById('edit-p-category')?.value || '';
        document.getElementById('edit-p-wholesale-price').value = window.calculateDynamicWholesalePrice(cost, price, category).toFixed(2);
        if (price > 0 && loyaltyPct > 0) {
            document.getElementById('edit-p-loyalty-price').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
        }
    }
};

window.autoCalculateVariantPrices = (inputEl) => {
    const row = inputEl.closest('.variant-row');
    if (!row) return;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const cost = parseFloat(row.querySelector('.v-cost')?.value) || parseFloat(document.getElementById('p-cost')?.value) || 0;
    const price = parseFloat(row.querySelector('.v-price')?.value || inputEl.value) || 0;
    const category = document.getElementById('p-category')?.value || document.getElementById('edit-p-category')?.value || '';
    
    const wsInput = row.querySelector('.v-wholesale');
    if (wsInput) wsInput.value = window.calculateDynamicWholesalePrice(cost, price, category).toFixed(2);
    const loyInput = row.querySelector('.v-loyalty');
    if (loyInput && price > 0 && loyaltyPct > 0) loyInput.value = (price * (1 - loyaltyPct / 100)).toFixed(2);
};

window.autoCalculateSinvPrices = () => {
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const cost = parseFloat(document.getElementById('sinv-item-cost')?.value) || 0;
    const price = parseFloat(document.getElementById('sinv-item-new-retail')?.value) || 0;
    const category = document.getElementById('sinv-item-category')?.value || '';
    document.getElementById('sinv-item-wholesale').value = window.calculateDynamicWholesalePrice(cost, price, category).toFixed(2);
    if (price > 0 && loyaltyPct > 0) {
        document.getElementById('sinv-item-loyalty').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
    }
};

window.autoCalculateBatchPrices = () => {
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const cost = parseFloat(document.getElementById('be-cost')?.value) || 0;
    const price = parseFloat(document.getElementById('be-retail')?.value) || 0;
    document.getElementById('be-wholesale').value = window.calculateDynamicWholesalePrice(cost, price).toFixed(2);
    if (price > 0 && loyaltyPct > 0) {
        document.getElementById('be-loyalty').value = (price * (1 - loyaltyPct / 100)).toFixed(2);
    }
};


// ─────────────────────────────────────────────
// CHEQUE PAYMENT HANDLING
// ─────────────────────────────────────────────
window._chequeModalSource = null;
window._confirmedChequeDate = null;

window.onSettlementChange = (value, source) => {
    const v = value.toLowerCase();
    if (v === 'cheque') {
        window._chequeModalSource = source;
        window._confirmedChequeDate = null;
        const today = new Date().toISOString().split('T')[0];
        const inp = document.getElementById('cheque-date-input');
        if (inp) inp.value = today;
        const modal = document.getElementById('cheque-date-modal');
        if (modal) modal.style.display = 'flex';
    } else {
        window._confirmedChequeDate = null;
    }
};

window.closeChequeModal = () => {
    const modal = document.getElementById('cheque-date-modal');
    if (modal) modal.style.display = 'none';
    if (!window._confirmedChequeDate) {
        const src = window._chequeModalSource;
        if (src === 'pos') {
            const posPayModal = document.getElementById('pos-payment-modal');
            if (posPayModal) posPayModal.style.display = 'flex';
        } else {
            const sel = document.getElementById(src === 'po' ? 'po-settlement-type' : 'sinv-pay-method');
            if (sel) sel.value = src === 'po' ? 'cash' : 'Cash';
        }
    }
};

window.confirmChequeDate = () => {
    const inp = document.getElementById('cheque-date-input');
    const dateVal = inp ? inp.value : '';
    if (!dateVal) { window.showToast('Please pick a cheque date.', 'warning'); return; }
    window._confirmedChequeDate = dateVal;
    const modal = document.getElementById('cheque-date-modal');
    if (modal) modal.style.display = 'none';
    window.showToast('Cheque date set: ' + dateVal + '. Invoice will auto-clear on that date.', 'info');
    if (window._chequeModalSource === 'pos') {
        window.processPOSSale('Cheque');
    }
};

window.markChequeAsPaid = async (docId) => {
    if (!confirm('Mark this cheque invoice as PAID?')) return;
    try {
        await updateDoc(doc(db, 'supplierInvoices', docId), {
            status: 'Paid',
            chequeStatus: 'cleared',
            paidAt: serverTimestamp()
        });
        window.showToast('Invoice marked as Paid!', 'success');
    } catch (err) {
        window.showToast('Error: ' + err.message, 'error');
    }
};

window.syncAllProductWholesalePrices = async (forceAll = false) => {
    try {
        const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;

        const confirmMsg = forceAll
            ? "⚠️ RECALCULATE ALL WHOLESALE PRICES:\nThis will scan and OVERWRITE the wholesale price for ALL products and variants in your inventory based on their Cost/MRP and Category rules.\n\nProceed?"
            : "⚠️ SYNC MISSING WHOLESALE PRICES:\nThis will scan your inventory and calculate wholesale/loyalty prices ONLY for products where they are currently 0 or empty.\n\nProceed?";

        if (!confirm(confirmMsg)) return;

        window.showToast("🚀 Calculating and updating wholesale prices across database, please wait...", "info");

        const products = window.allProducts || [];
        if (products.length === 0) {
            window.showToast("❌ No products loaded in memory. Try reloading.", "error");
            return;
        }

        let updateCount = 0;
        let batch = writeBatch(db);
        let batchCount = 0;

        for (const p of products) {
            let needsUpdate = false;
            const updates = {};

            const baseCost = parseFloat(p.cost) || 0;
            const basePrice = parseFloat(p.price) || 0;
            const baseCategory = p.category || '';
            const currentWS = parseFloat(p.wholesalePrice) || 0;
            const currentLoy = parseFloat(p.loyaltyPrice) || 0;

            if (baseCost > 0 || basePrice > 0) {
                if (forceAll || currentWS <= 0) {
                    const newWS = window.calculateDynamicWholesalePrice(baseCost, basePrice, baseCategory);
                    if (newWS > 0 && (forceAll || currentWS <= 0)) {
                        updates.wholesalePrice = newWS;
                        needsUpdate = true;
                    }
                }
                if (currentLoy <= 0 && basePrice > 0 && loyaltyPct > 0) {
                    updates.loyaltyPrice = Math.round((basePrice * (1 - loyaltyPct / 100)) * 100) / 100;
                    needsUpdate = true;
                }
            }

            // Variants
            if (p.variants && p.variants.length > 0) {
                const updatedVariants = p.variants.map(v => {
                    let vChanged = false;
                    const vCost = parseFloat(v.costPrice || v.cost || baseCost) || 0;
                    const vPrice = parseFloat(v.sellingPrice || v.price || basePrice) || 0;
                    const vWS = parseFloat(v.wholesalePrice) || 0;
                    const vLoy = parseFloat(v.loyaltyPrice) || 0;

                    const newV = { ...v };

                    if (vCost > 0 || vPrice > 0) {
                        if (forceAll || vWS <= 0) {
                            const newV_WS = window.calculateDynamicWholesalePrice(vCost, vPrice, baseCategory);
                            if (newV_WS > 0) {
                                newV.wholesalePrice = newV_WS;
                                vChanged = true;
                            }
                        }
                        if (vLoy <= 0 && vPrice > 0 && loyaltyPct > 0) {
                            newV.loyaltyPrice = Math.round((vPrice * (1 - loyaltyPct / 100)) * 100) / 100;
                            vChanged = true;
                        }
                    }

                    if (vChanged) needsUpdate = true;
                    return newV;
                });

                if (needsUpdate) {
                    updates.variants = updatedVariants;
                    if (updatedVariants.length > 0) {
                        updates.wholesalePrice = updatedVariants[0].wholesalePrice;
                        if (updatedVariants[0].loyaltyPrice) updates.loyaltyPrice = updatedVariants[0].loyaltyPrice;
                    }
                }
            }

            if (needsUpdate) {
                const docRef = doc(db, 'products', p.docId);
                batch.update(docRef, updates);
                updateCount++;
                batchCount++;

                if (batchCount >= 400) {
                    await batch.commit();
                    batch = writeBatch(db);
                    batchCount = 0;
                }
            }
        }

        if (batchCount > 0) {
            await batch.commit();
        }

        window.showToast(`✅ Successfully updated wholesale prices for ${updateCount} products/variants!`, "success");
    } catch (err) {
        console.error("Error syncing wholesale prices:", err);
        window.showToast("❌ Error: " + err.message, "error");
    }
};

window.syncAllMissingProductDiscounts = () => window.syncAllProductWholesalePrices(false);

// Register Service Worker for Offline Administration capability
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then(reg => {
            console.log('Admin SW Registered', reg.scope);
        }).catch(err => {
            console.log('Admin SW Registration Failed', err);
        });
    });
}

window.shareModernInvoiceWhatsApp = async () => {
    const orderId = window._currentViewingInvoiceId;
    if (!orderId) {
        window.showToast("No active invoice to share.", "warning");
        return;
    }
    const order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId) 
                  || (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId) ? window.lastSavedPOSOrder : null)
                  || window.currentPendingRepairOrder;
                  
    if (!order) return window.showToast("Invoice not found in memory.", "warning");

    let phone = order.phone || order.customerPhone || "";
    let formattedPhone = phone.replace(/\D/g, '');
    if (formattedPhone.startsWith('0')) formattedPhone = '94' + formattedPhone.substring(1);

    if (!formattedPhone) {
        window.showToast("Customer phone required for WhatsApp.", "warning");
        return;
    }

    const itemLines = (order.items || []).map(i => `• ${i.name} (x${i.quantity || 1}) - LKR ${((i.price || 0) * (i.quantity || 1)).toLocaleString()}`).join('\n');
    
    let message = `*INVOICE: #${order.orderId}*\n*MEC BOOK SHOP*\n----------------------------------\n*Customer:* ${order.userName || 'Valued Customer'}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${itemLines}\n----------------------------------\n*TOTAL: LKR ${order.total.toLocaleString()}*\n*Method:* ${order.paymentMethod || 'Cash'}\n\nThank you for shopping @ MEC! 📚✨`;
    
    if (order.type === 'RepairBill') {
        message = `*REPAIR BILL: #${order.orderId}*\n*MEC BOOK SHOP SERVICE*\n----------------------------------\n*Customer:* ${order.userName || 'Valued Customer'}\n*Device:* ${order.itemDescription || 'Device'}\n*Issue:* ${order.problem || 'Repair'}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${itemLines}\n----------------------------------\n*TOTAL: LKR ${order.total.toLocaleString()}*\n*Method:* ${order.paymentMethod || 'Cash'}\n\nThank you for trusting MEC Book Shop Repairs! 🛠️✨`;
    }

    await window.dispatchWhatsApp(phone, message);
};

window.shareModernInvoiceSMS = async () => {
    const orderId = window._currentViewingInvoiceId;
    if (!orderId) {
        window.showToast("No active invoice to share.", "warning");
        return;
    }
    const order = (window.allOrders || []).find(o => o.orderId === orderId || o.docId === orderId) 
                  || (window.lastSavedPOSOrder && (window.lastSavedPOSOrder.orderId === orderId || window.lastSavedPOSOrder.docId === orderId) ? window.lastSavedPOSOrder : null)
                  || window.currentPendingRepairOrder;
                  
    if (!order) return window.showToast("Invoice not found in memory.", "warning");

    let phone = order.phone || order.customerPhone || "";
    if (!phone) {
        window.showToast("Customer phone required for SMS.", "warning");
        return;
    }

    const billId = order.orderId;
    const total = parseFloat(order.total || 0).toFixed(2);
    const date = order.date || new Date().toLocaleDateString();

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    let message = `Thank you for shopping at ${bizName}!\nInvoice: ${billId}\nDate: ${date}\nTotal: LKR ${total}\nTrack: mecbookshop.com.lk/track.html?id=${billId}\nDownload App: mecbookshop.web.lk/download`;
    if (order.type === 'RepairBill') {
        message = `Thank you for using ${bizName} Repairs!\nRepair Invoice: ${billId}\nDevice: ${order.itemDescription || 'Device'}\nTotal: LKR ${total}\nTrack: mecbookshop.com.lk/track.html?id=${billId}\nDownload App: mecbookshop.web.lk/download`;
    }

    await window.dispatchSMS(phone, message);
};

window.testSMSGateway = async () => {
    const defaultTestPhone = (window.systemConfig?.invPhone || "0770658356").replace(/\D/g, '');
    const testPhone = await window.asyncPrompt("Enter mobile number to send a Test SMS via SMSLenz:", "Test SMS Gateway", "text", defaultTestPhone || "0770658356");
    if (!testPhone) return;
    
    const norm = window.normalizePhone(testPhone);
    if (!norm.formatted || norm.formatted.length < 10) {
        return window.showToast("Invalid phone number format. Must be 10 or 11 digits.", "error");
    }

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';

    const smsConf = window.systemConfig?.smsConfig || {};
    const apiBase = (document.getElementById('set-sms-api-base')?.value?.trim() || smsConf.apiBase?.trim() || (isMec ? "https://www.smslenz.lk/api/send-sms" : ""));
    const apiKey = (document.getElementById('set-sms-api-key')?.value?.trim() || smsConf.apiKey?.trim() || (isMec ? "40b621ec-69ba-48c4-869b-cf30f3f58791" : ""));
    const userId = (document.getElementById('set-sms-user-id')?.value?.trim() || smsConf.userId?.trim() || (isMec ? "981" : ""));
    const senderId = (document.getElementById('set-sms-sender-id')?.value?.trim() || smsConf.senderId?.trim() || (isMec ? "MECBookShop" : ""));

    if (!apiKey || !userId) {
        return window.showToast("⚠️ SMS Gateway not configured. Please enter API credentials.", "warning");
    }

    try {
        const url = new URL(apiBase);
        url.searchParams.set("user_id", userId);
        url.searchParams.set("api_key", apiKey);
        url.searchParams.set("sender_id", senderId);
        url.searchParams.set("contact", norm.withPlus || ('+' + norm.formatted));
        url.searchParams.set("message", `MEC POS Test SMS: SMSLenz Gateway is active & working properly! [Sender: ${senderId}]`);

        let data = null;
        try {
            const resp = await fetch(url.toString(), { method: 'GET' });
            data = await resp.json().catch(() => null);
        } catch (fetchErr) {
            console.warn("[SMSLenz] Test fetch error, falling back to no-cors:", fetchErr);
            await fetch(url.toString(), { method: 'GET', mode: 'no-cors' }).catch(() => {});
            data = { success: true, message: "Dispatched via backup pipeline" };
        }

        if (data && (data.success || data.status === 'success')) {
            window.showToast(`✅ Test SMS sent to ${norm.formatted} via SMSLenz [${senderId}]!`, "success");
        } else {
            window.showToast(`⚠️ SMS Gateway: ${data?.message || "Failed to dispatch test SMS"}`, "error");
        }
    } catch (err) {
        console.error("Test SMS Error:", err);
        window.showToast("Failed to dispatch test SMS.", "error");
    }
};

window.testWhatsAppGateway = async () => {
    const defaultTestPhone = (window.systemConfig?.metaWhatsappConfig?.defaultPhone || window.systemConfig?.invPhone || "0712809615").replace(/\D/g, '');
    const testPhone = await window.asyncPrompt("Enter mobile number to send a Test WhatsApp message:", "Test WhatsApp Gateway", "text", defaultTestPhone || "0712809615");
    if (!testPhone) return;

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const msg = `*${bizName} WhatsApp Test*\nHello! The WhatsApp Gateway is functioning properly. 🚀✨`;
    await window.dispatchWhatsApp(testPhone, msg);
};

window.fetchCurrentStoreGPS = () => {
    if (!navigator.geolocation) {
        return window.showToast("Geolocation is not supported by your browser.", "error");
    }
    window.showToast("📍 Fetching GPS location...", "info");
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude.toFixed(6);
            const lng = position.coords.longitude.toFixed(6);
            document.getElementById('set-store-latitude').value = lat;
            document.getElementById('set-store-longitude').value = lng;
            window.showToast("✅ GPS Location Captured Successfully!", "success");
        },
        (error) => {
            console.error("GPS Error:", error);
            window.showToast("Failed to fetch GPS coordinates. Please enter manually.", "error");
        },
        { enableHighAccuracy: true, timeout: 5000 }
    );
};

window.showStoreAttendanceQRCode = () => {
    const lat = parseFloat(document.getElementById('set-store-latitude')?.value) || 0;
    const lng = parseFloat(document.getElementById('set-store-longitude')?.value) || 0;
    if (lat === 0 || lng === 0) {
        return window.showToast("❌ Please set and save GPS Coordinates first!", "warning");
    }
    const storeId = window.getStoreId();
    const qrData = encodeURIComponent(`MEC-POS-ATTENDANCE-QR:${storeId}:${lat}:${lng}`);
    const qrImg = document.getElementById('attendance-qr-img');
    if (qrImg) {
        // Use high resolution 500x500 so both modal & print use the exact same cached resource
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${qrData}`;
        window.openModal('attendance-qr-modal');
    }
};

window.printAttendanceQR = async () => {
    const rawQrSrc = document.getElementById('attendance-qr-img')?.src || '';
    const lat = parseFloat(document.getElementById('set-store-latitude')?.value) || 0;
    const lng = parseFloat(document.getElementById('set-store-longitude')?.value) || 0;
    const storeId = window.getStoreId();
    const qrData = encodeURIComponent(`MEC-POS-ATTENDANCE-QR:${storeId}:${lat}:${lng}`);
    
    // Ensure we have a high-res QR src
    const qrSrc = (rawQrSrc && rawQrSrc.startsWith('http'))
        ? rawQrSrc 
        : `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${qrData}`;

    // Merchant details
    const bizName = window.systemConfig?.bizName 
        || window.storeInfo?.name 
        || window.STORE_CONFIG?.name 
        || 'MEC BOOK SHOP';

    // Branch Resolution
    const orderBranchKey = localStorage.getItem('mec_terminal_branch') 
        || sessionStorage.getItem('userBranchId') 
        || window.activeBranchFilter 
        || 'main';
    const activeBranchInfo = (typeof window.getBranchInfo === 'function') 
        ? window.getBranchInfo(orderBranchKey) 
        : null;
    const branchDisplayName = activeBranchInfo?.branchName 
        || activeBranchInfo?.name 
        || (orderBranchKey === 'main' ? 'Horana (Main Branch)' : (orderBranchKey === 'All' ? 'Main Branch - Horana' : orderBranchKey));
    const branchAddress = activeBranchInfo?.address 
        || activeBranchInfo?.location 
        || window.storeInfo?.address 
        || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana';
    const branchPhone = activeBranchInfo?.phone 
        || window.systemConfig?.invPhone 
        || window.storeInfo?.phone 
        || '071 923 3388';

    // Merchant Logo Resolution (Ihala)
    const customMerchantLogo = window.systemConfig?.storeLogoUrl 
        || window.systemConfig?.logoUrl 
        || window.storeInfo?.logoUrl 
        || window.currentStoreData?.logoUrl
        || localStorage.getItem('mecpos_store_logo')
        || (typeof window.getMerchantDefaultLogo === 'function' ? window.getMerchantDefaultLogo() : '')
        || '/mec-logo.png';

    // POS / Zenith ERP Logo (Pahala)
    const posLogo = '/zenith_logo.png';

    if (typeof window.showToast === 'function') {
        window.showToast("🖨️ Preparing attendance poster...", "info");
    }

    // Preload images into browser memory before printing to avoid blank printouts
    const preloadImage = (src) => new Promise((resolve) => {
        if (!src) return resolve(null);
        const img = new Image();
        img.onload = () => resolve(src);
        img.onerror = () => resolve(src);
        img.src = src;
        if (img.complete) resolve(src);
    });

    await Promise.all([
        preloadImage(qrSrc),
        preloadImage(customMerchantLogo),
        preloadImage(posLogo)
    ]);

    // Create temporary print container
    const printContainer = document.createElement('div');
    printContainer.id = 'print-qr-temp-container';
    printContainer.innerHTML = `
        <!-- TOP HEADER: Merchant Branding & Official Attendance Terminal Badge -->
        <div style="width: 100%; display: flex; flex-direction: column; align-items: center; text-align: center;">
            
            <!-- Brand Logos Bar & Official Terminal Pill -->
            <div style="width: 100%; display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 8px;">
                <div style="display: flex; align-items: center; gap: 12px; text-align: left;">
                    <img src="${customMerchantLogo}" 
                         style="height: 55px; max-width: 180px; object-fit: contain; display: block;" 
                         onerror="this.style.display='none'">
                    <div>
                        <div style="font-size: 0.72rem; font-weight: 800; color: #0284c7; text-transform: uppercase; letter-spacing: 1px;">Official Store Terminal</div>
                        <div style="font-size: 1.05rem; font-weight: 900; color: #0f172a; line-height: 1.2;">${bizName}</div>
                    </div>
                </div>
                
                <div style="display: inline-flex; align-items: center; gap: 8px; background: #0f172a; color: #38bdf8; padding: 7px 18px; border-radius: 50px; font-size: 0.75rem; font-weight: 800; letter-spacing: 1.2px; text-transform: uppercase; box-shadow: 0 4px 12px rgba(15,23,42,0.12);">
                    <span>🏢</span> ATTENDANCE TERMINAL
                </div>
            </div>

            <!-- Merchant Store Name & Branch Showcase -->
            <div style="margin: 2px 0 4px 0;">
                <h1 style="font-size: 2.2rem; margin: 0 0 4px 0; color: #0f172a; font-weight: 900; letter-spacing: -0.5px; text-transform: uppercase; font-family: 'Segoe UI', -apple-system, Roboto, sans-serif; line-height: 1.15;">
                    ${bizName}
                </h1>
                
                <!-- Branch Highlight Badge -->
                <div style="display: inline-flex; align-items: center; gap: 8px; background: #f0fdf4; border: 1.5px solid #10b981; padding: 5px 22px; border-radius: 50px; font-size: 0.95rem; font-weight: 800; color: #065f46; margin: 2px 0;">
                    <span style="font-size: 1.1rem;">📍</span> <span style="letter-spacing: 0.5px;">BRANCH: ${branchDisplayName.toUpperCase()}</span>
                </div>
                
                <div style="font-size: 0.8rem; color: #475569; font-weight: 600; margin-top: 3px;">
                    ${branchAddress} • Tel: ${branchPhone}
                </div>
                
                <p style="font-size: 0.95rem; color: #334155; font-weight: 700; margin: 4px 0 0 0; line-height: 1.3;">
                    Employee Dynamic Clock-In & Clock-Out Scanner
                </p>
            </div>
        </div>

        <!-- CENTER: QR Code Container Card -->
        <div style="background: #ffffff; border: 3px solid #10b981; border-radius: 20px; padding: 14px 20px; box-shadow: 0 10px 25px rgba(16,185,129,0.1); display: flex; flex-direction: column; align-items: center; text-align: center; margin: 4px auto;">
            <div style="background: white; padding: 10px; border-radius: 14px; border: 1.5px solid #e2e8f0;">
                <img src="${qrSrc}" style="width: 250px; height: 250px; display: block; object-fit: contain;">
            </div>
            <div style="margin-top: 8px; display: inline-flex; align-items: center; gap: 6px; background: #ecfdf5; border: 1px solid #10b981; padding: 4px 16px; border-radius: 50px; font-size: 0.75rem; font-weight: 800; color: #047857; text-transform: uppercase; letter-spacing: 0.5px;">
                <span>🔒</span> REAL-TIME GPS VERIFIED TERMINAL • 100M RADIUS
            </div>
        </div>

        <!-- INSTRUCTIONS: 3 Step Cards -->
        <div style="width: 100%; max-width: 180mm; background: #f8fafc; border: 1.5px solid #e2e8f0; border-radius: 14px; padding: 8px 14px; box-sizing: border-box;">
            <div style="font-size: 0.72rem; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; text-align: center;">
                HOW TO MARK YOUR ATTENDANCE
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center;">
                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 10px; padding: 8px 6px;">
                    <div style="font-size: 1.2rem; margin-bottom: 2px;">📱</div>
                    <div style="font-weight: 800; font-size: 0.75rem; color: #0f172a;">1. Open Portal</div>
                    <div style="font-size: 0.65rem; color: #64748b; margin-top: 2px;">Open Staff Portal on mobile</div>
                </div>
                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 10px; padding: 8px 6px;">
                    <div style="font-size: 1.2rem; margin-bottom: 2px;">📷</div>
                    <div style="font-weight: 800; font-size: 0.75rem; color: #0f172a;">2. Tap Scan QR</div>
                    <div style="font-size: 0.65rem; color: #64748b; margin-top: 2px;">Allow GPS location access</div>
                </div>
                <div style="background: white; border: 1px solid #e2e8f0; border-radius: 10px; padding: 8px 6px;">
                    <div style="font-size: 1.2rem; margin-bottom: 2px;">✅</div>
                    <div style="font-weight: 800; font-size: 0.75rem; color: #0f172a;">3. Clock-In / Out</div>
                    <div style="font-size: 0.65rem; color: #64748b; margin-top: 2px;">Marked instantly on system</div>
                </div>
            </div>
        </div>

        <!-- FOOTER: POS Logo (Pahala) & System Accreditation -->
        <div style="width: 100%; border-top: 2px solid #e2e8f0; padding-top: 8px; display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 10px; text-align: left;">
                <img src="${posLogo}" 
                     style="height: 40px; max-width: 150px; object-fit: contain; display: block;" 
                     onerror="this.src='/pos-logo.png'; this.onerror=null;">
                <div>
                    <div style="font-size: 0.75rem; font-weight: 900; color: #0f172a; letter-spacing: 0.3px;">MEC POS ZENITH ERP</div>
                    <div style="font-size: 0.65rem; color: #64748b; font-weight: 600;">Automated Human Resource & Attendance Suite</div>
                </div>
            </div>
            
            <div style="text-align: right;">
                <div style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.72rem; color: #0f172a; font-weight: 800;">
                    <span>📍</span> Geofencing: <span style="color: #10b981;">Active (Radius: 100m)</span>
                </div>
                <div style="font-size: 0.65rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">
                    GPS: ${lat ? lat.toFixed(5) : '0.00000'}, ${lng ? lng.toFixed(5) : '0.00000'} • Cloud Synced
                </div>
            </div>
        </div>
    `;
    
    // Add print styles strictly calibrated for single-page A4 without black border
    const style = document.createElement('style');
    style.id = 'print-qr-temp-style';
    style.innerHTML = `
        @page {
            size: A4 portrait;
            margin: 6mm;
        }
        @media print {
            html, body {
                width: 100% !important;
                height: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                background: #ffffff !important;
                color: #0f172a !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                overflow: hidden !important;
            }
            body > *:not(#print-qr-temp-container) {
                display: none !important;
            }
            #print-qr-temp-container {
                display: flex !important;
                flex-direction: column !important;
                justify-content: space-between !important;
                align-items: center !important;
                box-sizing: border-box !important;
                width: 100% !important;
                max-width: 196mm !important;
                height: 275mm !important;
                max-height: 275mm !important;
                margin: 0 auto !important;
                padding: 6mm 8mm 6mm 8mm !important;
                background: #ffffff !important;
                border: none !important;
                border-radius: 0 !important;
                box-shadow: none !important;
                outline: none !important;
                page-break-inside: avoid !important;
                page-break-after: avoid !important;
                break-inside: avoid !important;
                overflow: hidden !important;
            }
        }
        @media screen {
            #print-qr-temp-container {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                z-index: 999999;
                background: white;
                box-shadow: 0 25px 60px rgba(0,0,0,0.5);
                width: 196mm;
                height: 275mm;
                box-sizing: border-box;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                align-items: center;
                padding: 6mm 8mm 6mm 8mm;
                border: none;
                border-radius: 16px;
            }
        }
    `;
    
    document.body.appendChild(printContainer);
    document.head.appendChild(style);
    
    // Allow DOM to settle before opening print dialog
    setTimeout(() => {
        window.print();
    }, 150);
    
    // Clean up cleanly
    const cleanup = () => {
        try {
            printContainer.remove();
            style.remove();
        } catch (e) {}
    };

    window.addEventListener('afterprint', cleanup, { once: true });
    setTimeout(cleanup, 4000);
};

window.addEventListener('beforeunload', function (e) {
  // Do not prompt inside desktop apps (WebView2 / Electron)
  if (window.chrome?.webview || window.electron || window.electronAPI) return;
  if (!navigator.onLine) {
    e.preventDefault();
    e.returnValue = 'You are currently offline. Unsaved data will be lost if you close the app.';
  }
});

window.handleStoreLogoFileUpload = async (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;
    if (typeof window.showToast === 'function') window.showToast("⚡ Compressing & preparing store logo...", "info");
    try {
        const compressedBase64 = typeof window.resizeImageToBase64 === 'function' ? await window.resizeImageToBase64(file, 800) : await new Promise(r => {
            const rd = new FileReader();
            rd.onload = e => r(e.target.result);
            rd.readAsDataURL(file);
        });
        const urlInput = document.getElementById('set-store-logo-url');
        const previewImg = document.getElementById('set-store-logo-preview');
        if (urlInput) urlInput.value = compressedBase64;
        if (previewImg) previewImg.src = compressedBase64;
        if (typeof window.showToast === 'function') window.showToast("✅ Store logo ready! Click 'Save Global Config' to save.", "success");
    } catch (e) {
        console.error("Logo upload error:", e);
        if (typeof window.showToast === 'function') window.showToast("❌ Failed to process logo image.", "error");
    }
};

window.clearStoreLogo = () => {
    const urlInput = document.getElementById('set-store-logo-url');
    const previewImg = document.getElementById('set-store-logo-preview');
    if (urlInput) urlInput.value = "";
    if (previewImg) previewImg.src = "/logo.png";
    if (typeof window.showToast === 'function') window.showToast("Cleared store logo field. Save config to apply.", "info");
};

// --- DYNAMIC MULTI-THEME ENGINE (VISUAL APPEARANCE) ---
const THEME_CLASS_MAP = {
    'classic-zenith': 'theme-classic-zenith',
    'eproduct-curved': 'theme-eproduct-curved',
    'ultraleads-clean': 'theme-ultraleads-clean',
    'cyber-neon': 'theme-cyber-neon',
    'helios-lilac': 'theme-helios-lilac',
    'finnova-duo': 'theme-finnova-duo',
    // Fallback aliases
    'pearl-light': 'theme-ultraleads-clean',
    'corporate-royal': 'theme-eproduct-curved',
    'emerald-pro': 'theme-classic-zenith',
    'crimson-lux': 'theme-helios-lilac',
    'obsidian-midnight': 'theme-classic-zenith'
};

window.setAdminTheme = async (themeKey, skipToast = false, skipCloudSync = false) => {
    try {
        const canonicalKey = THEME_CLASS_MAP[themeKey] ? (THEME_CLASS_MAP[themeKey].replace('theme-', '')) : 'classic-zenith';
        const targetClass = THEME_CLASS_MAP[canonicalKey] || 'theme-classic-zenith';

        // 1. Remove all existing theme classes from body
        Object.values(THEME_CLASS_MAP).forEach(cls => {
            document.body.classList.remove(cls);
        });

        // 2. Add new target theme class
        document.body.classList.add(targetClass);

        // 3. Save to localStorage
        localStorage.setItem('mec_active_theme', canonicalKey);
        localStorage.setItem('admin-theme-choice', canonicalKey);

        // 4. Update UI active badges and card highlight rings
        document.querySelectorAll('.theme-active-badge').forEach(b => b.style.display = 'none');
        document.querySelectorAll('.theme-card').forEach(c => {
            c.style.boxShadow = '0 10px 30px rgba(0,0,0,0.3)';
            c.style.transform = 'scale(1)';
        });

        const activeBadge = document.getElementById(`badge-theme-${canonicalKey}`);
        if (activeBadge) activeBadge.style.display = 'inline-block';

        const activeCard = document.getElementById(`card-theme-${canonicalKey}`);
        if (activeCard) {
            activeCard.style.boxShadow = '0 0 0 3px var(--primary-blue), 0 20px 40px rgba(0,0,0,0.4)';
            activeCard.style.transform = 'scale(1.02)';
        }

        // 5. Sync to Firebase Cloud if user explicitly selected
        if (!skipCloudSync) {
            try {
                const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
                updateDoc(doc(db, 'config', storeId), {
                    activeTheme: canonicalKey,
                    lastUpdated: serverTimestamp()
                }).catch(e => console.warn("Cloud theme sync fallback:", e));
            } catch(cloudErr) {
                console.warn("Could not push theme to cloud:", cloudErr);
            }
        }

        if (!skipToast && typeof window.showToast === 'function') {
            const themeNames = {
                'classic-zenith': '🛡️ MEC Classic Zenith (Default)',
                'eproduct-curved': '🔷 eProduct Curved SaaS',
                'ultraleads-clean': '📊 Ultraleads Clean Analytics',
                'cyber-neon': '🌌 Cyber Neon Matrix',
                'helios-lilac': '🔮 Helios Lilac Luxury',
                'finnova-duo': '🎛️ Finnova Duo Hybrid'
            };
            window.showToast(`✨ Layout applied: ${themeNames[canonicalKey] || canonicalKey}`, 'success');
        }
    } catch (e) {
        console.error("Theme switch error:", e);
    }
};

// Bootstrap active theme on load
(function() {
    const savedTheme = localStorage.getItem('mec_active_theme') || 'classic-zenith';
    window.setAdminTheme(savedTheme, true, true);
})();

// --- EXECUTIVE MULTI-ARCHETYPE DASHBOARD ENGINE ---
window.renderExecutiveDashboard = () => {
    try {
        const allOrders = window.allOrders || [];
        const products = window.allProducts || [];
        const customers = window.allCustomers || [];

        const activeBranch = window.activeBranchFilter || localStorage.getItem('mec_terminal_branch') || 'All';
        const orders = allOrders.filter(o => {
            if (!o || o.status === 'Void' || o.status === 'Cancelled') return false;
            if (activeBranch === 'All') return true;

            const bQuery = activeBranch.toLowerCase();
            const oBranchId = (o.branchId || '').toLowerCase();
            const oBranch = (o.branch || o.branchName || o.pickupShopName || '').toLowerCase();
            const isHorana = bQuery === 'main' || bQuery.includes('horana');

            if (isHorana) {
                const isPanadura = oBranchId.includes('panadura') || oBranchId === 'j8lsw5vrjwmssc630dh0' || oBranch.includes('panadura');
                return !isPanadura;
            } else {
                return oBranchId === bQuery || oBranch.includes(bQuery);
            }
        });

        const now = new Date();
        const curYear = now.getFullYear();
        const curMonth = now.getMonth(); // 0-indexed (0=Jan, 3=Apr, 8=Sep)

        // Financial Year: April 01 of Start Year to March 31 of End Year
        const fyStartYear = curMonth >= 3 ? curYear : curYear - 1;
        const fyEndYear = fyStartYear + 1;
        const fyStartDate = new Date(fyStartYear, 3, 1, 0, 0, 0); // April 1
        const fyEndDate = new Date(fyEndYear, 2, 31, 23, 59, 59, 999); // March 31

        // Current Month range
        const monthStartDate = new Date(curYear, curMonth, 1, 0, 0, 0);
        const monthEndDate = new Date(curYear, curMonth + 1, 0, 23, 59, 59, 999);

        // Same Month Last Year range (for exact comparison)
        const lastYearSameMonthStart = new Date(curYear - 1, curMonth, 1, 0, 0, 0);
        const lastYearSameMonthEnd = new Date(curYear - 1, curMonth + 1, 0, 23, 59, 59, 999);

        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        const curMonthName = monthNames[curMonth];

        let fyRevenue = 0;
        let fyCost = 0;
        let fyOrdersCount = 0;

        let thisMonthRevenue = 0;
        let thisMonthCost = 0;
        let thisMonthOrdersCount = 0;

        let lastYearMonthRevenue = 0;

        let posRetailTotal = 0;
        let webOrdersTotal = 0;

        // Helper to parse order date
        const getOrderDate = (o) => {
            if (o.timestamp?.seconds) return new Date(o.timestamp.seconds * 1000);
            if (o.timestamp?.toDate) return o.timestamp.toDate();
            if (o.createdAt?.seconds) return new Date(o.createdAt.seconds * 1000);
            if (o.date) {
                const d = new Date(o.date + (o.date.includes('T') ? '' : 'T12:00:00'));
                if (!isNaN(d.getTime())) return d;
            }
            return null;
        };

        // Helper to calculate exact order cost from items
        const getOrderCost = (o) => {
            if (!Array.isArray(o.items) || o.items.length === 0) {
                return Number(o.grandTotal || o.total || 0) * 0.75; // Safe estimate ONLY if items array is completely missing
            }
            let cost = 0;
            o.items.forEach(it => {
                const qty = Number(it.quantity || it.qty || 1);
                const itemCost = Number(it.costPrice ?? it.buyingPrice ?? it.cost ?? 0);
                if (itemCost > 0) {
                    cost += (itemCost * qty);
                } else {
                    const price = Number(it.price || it.unitPrice || 0);
                    cost += (price * 0.75 * qty);
                }
            });
            return cost;
        };

        orders.forEach(o => {
            const grandTotal = Number(o.grandTotal || o.total || 0);
            const oDate = getOrderDate(o);
            if (!oDate) return;

            const oCost = getOrderCost(o);

            // Check Financial Year (Apr 01 - Mar 31)
            if (oDate >= fyStartDate && oDate <= fyEndDate) {
                fyRevenue += grandTotal;
                fyCost += oCost;
                fyOrdersCount++;

                if (o.type === 'POS' || o.source === 'POS' || !o.type) {
                    posRetailTotal += grandTotal;
                } else {
                    webOrdersTotal += grandTotal;
                }
            }

            // Check This Month
            if (oDate >= monthStartDate && oDate <= monthEndDate) {
                thisMonthRevenue += grandTotal;
                thisMonthCost += oCost;
                thisMonthOrdersCount++;
            }

            // Check Last Year Same Month
            if (oDate >= lastYearSameMonthStart && oDate <= lastYearSameMonthEnd) {
                lastYearMonthRevenue += grandTotal;
            }
        });

        const fyGrossProfit = Math.max(0, fyRevenue - fyCost);
        const thisMonthGrossProfit = Math.max(0, thisMonthRevenue - thisMonthCost);

        // Real growth percentage vs last year same month
        let growthPercent = 0;
        let growthSign = '+';
        if (lastYearMonthRevenue > 0) {
            growthPercent = Math.round(((thisMonthRevenue - lastYearMonthRevenue) / lastYearMonthRevenue) * 100);
            growthSign = growthPercent >= 0 ? '+' : '';
        } else if (thisMonthRevenue > 0) {
            growthPercent = 100;
            growthSign = '+';
        }

        // 1. Update Cyber Neon Matrix Elements (100% Real Data)
        const monthLabel = document.getElementById('dash-cyber-month-label');
        if (monthLabel) monthLabel.textContent = `${curMonthName} Revenue`;

        const cyberRev = document.getElementById('dash-cyber-revenue');
        if (cyberRev) cyberRev.textContent = `Rs. ${thisMonthRevenue.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        const growthBadge = document.getElementById('dash-cyber-growth-badge');
        if (growthBadge) {
            growthBadge.textContent = lastYearMonthRevenue > 0 
                ? `${growthSign}${growthPercent}% vs ${curMonthName} ${curYear - 1}` 
                : `📅 ${curMonthName} ${curYear}`;
        }

        const fyLabel = document.getElementById('dash-cyber-fy-label');
        if (fyLabel) fyLabel.textContent = `FY ${fyStartYear}/${fyEndYear} Revenue`;

        const cyberArr = document.getElementById('dash-cyber-arr');
        if (cyberArr) cyberArr.textContent = `Rs. ${fyRevenue.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        const cyberFyRange = document.getElementById('dash-cyber-fy-range');
        if (cyberFyRange) cyberFyRange.textContent = `🌐 Apr 01, ${fyStartYear} - Mar 31, ${fyEndYear}`;

        const cyberGoal = document.getElementById('dash-cyber-goal');
        if (cyberGoal) cyberGoal.textContent = `${growthSign}${growthPercent}%`;

        const cyberCompSub = document.getElementById('dash-cyber-comp-subtitle');
        if (cyberCompSub) {
            cyberCompSub.textContent = lastYearMonthRevenue > 0 
                ? `Last year: Rs. ${lastYearMonthRevenue.toLocaleString('en-LK', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`
                : `vs ${curMonthName} ${curYear - 1} (No data)`;
        }

        const cyberOrders = document.getElementById('dash-cyber-orders');
        if (cyberOrders) cyberOrders.textContent = fyOrdersCount.toLocaleString();

        const ordersBadge = document.getElementById('dash-cyber-orders-badge');
        if (ordersBadge) ordersBadge.textContent = `📦 FY Orders (${thisMonthOrdersCount} this mo)`;

        const cyberProfit = document.getElementById('dash-cyber-profit');
        if (cyberProfit) cyberProfit.textContent = `Rs. ${fyGrossProfit.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        const cyberRetail = document.getElementById('dash-cyber-retail-amt');
        if (cyberRetail) cyberRetail.textContent = `Rs. ${posRetailTotal.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;

        const cyberWeb = document.getElementById('dash-cyber-web-amt');
        if (cyberWeb) cyberWeb.textContent = `Rs. ${webOrdersTotal.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;

        const donutVisits = document.getElementById('dash-donut-visits');
        if (donutVisits) {
            const posPct = fyRevenue > 0 ? Math.round((posRetailTotal / fyRevenue) * 100) : 100;
            donutVisits.textContent = `${posPct}%`;
        }

        // Populate Visual Charts in Cyber Matrix Dashboard
        const ctxCyberTimeline = document.getElementById('dash-cyber-timeline-chart');
        if (ctxCyberTimeline && typeof Chart !== 'undefined') {
            const monthShortNames = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];
            const fyMonths = [];
            for (let m = 3; m <= 11; m++) {
                fyMonths.push({
                    key: `${fyStartYear}-${String(m + 1).padStart(2, '0')}`,
                    label: `${monthShortNames[m - 3]}`
                });
            }
            for (let m = 0; m <= 2; m++) {
                fyMonths.push({
                    key: `${fyEndYear}-${String(m + 1).padStart(2, '0')}`,
                    label: `${monthShortNames[m + 9]}`
                });
            }

            const fySalesMap = {}, fyCostMap = {}, fyProfitMap = {};
            fyMonths.forEach(fm => {
                fySalesMap[fm.key] = 0;
                fyCostMap[fm.key] = 0;
                fyProfitMap[fm.key] = 0;
            });

            orders.forEach(o => {
                const oDate = getOrderDate(o);
                if (!oDate) return;
                const y = oDate.getFullYear();
                const m = oDate.getMonth();
                const k = `${y}-${String(m + 1).padStart(2, '0')}`;
                if (fySalesMap[k] !== undefined) {
                    const tot = Number(o.grandTotal || o.total || 0);
                    const cost = getOrderCost(o);
                    fySalesMap[k] += tot;
                    fyCostMap[k] += cost;
                    fyProfitMap[k] += Math.max(0, tot - cost);
                }
            });

            const labels = fyMonths.map(fm => fm.label);
            const salesData = fyMonths.map(fm => Math.round(fySalesMap[fm.key]));
            const profitData = fyMonths.map(fm => Math.round(fyProfitMap[fm.key]));

            if (window._cyberTimelineChart) window._cyberTimelineChart.destroy();
            window._cyberTimelineChart = new Chart(ctxCyberTimeline, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Sales (LKR)',
                            data: salesData,
                            borderColor: '#38bdf8',
                            backgroundColor: 'rgba(56, 189, 248, 0.12)',
                            borderWidth: 2.5,
                            fill: true,
                            tension: 0.35,
                            pointRadius: 2.5,
                            pointHoverRadius: 5
                        },
                        {
                            label: 'Net Margin (LKR)',
                            data: profitData,
                            borderColor: '#a3e635',
                            backgroundColor: 'rgba(163, 230, 53, 0.12)',
                            borderWidth: 2.5,
                            fill: true,
                            tension: 0.35,
                            pointRadius: 2.5,
                            pointHoverRadius: 5
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            display: true,
                            position: 'top',
                            labels: { color: '#cbd5e1', font: { size: 10, weight: '700' }, boxWidth: 12 }
                        },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => ` ${ctx.dataset.label}: Rs. ${Number(ctx.parsed.y).toLocaleString()}`
                            }
                        }
                    },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#94a3b8', font: { size: 9, weight: '600' } } },
                        y: { 
                            grid: { color: 'rgba(255,255,255,0.04)' }, 
                            ticks: { 
                                color: '#94a3b8',
                                font: { size: 9 },
                                callback: (v) => v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v
                            } 
                        }
                    }
                }
            });
        }

        const ctxCyberCompare = document.getElementById('dash-cyber-compare-chart');
        if (ctxCyberCompare && typeof Chart !== 'undefined') {
            const prevMonthDate = new Date(curYear, curMonth - 1, 1);
            let lastMonthRevenue = 0;
            let lastMonthCost = 0;
            orders.forEach(o => {
                const oDate = getOrderDate(o);
                if (!oDate) return;
                if (oDate.getFullYear() === prevMonthDate.getFullYear() && oDate.getMonth() === prevMonthDate.getMonth()) {
                    lastMonthRevenue += Number(o.grandTotal || o.total || 0);
                    lastMonthCost += getOrderCost(o);
                }
            });
            const lastMonthGrossProfit = Math.max(0, lastMonthRevenue - lastMonthCost);

            if (window._cyberCompareChart) window._cyberCompareChart.destroy();
            window._cyberCompareChart = new Chart(ctxCyberCompare, {
                type: 'bar',
                data: {
                    labels: [`${curMonthName.slice(0,3)} '${(curYear-1).toString().slice(-2)}`, 'Last Mo', 'This Mo'],
                    datasets: [
                        {
                            label: 'Revenue',
                            data: [Math.round(lastYearMonthRevenue), Math.round(lastMonthRevenue), Math.round(thisMonthRevenue)],
                            backgroundColor: 'rgba(56, 189, 248, 0.85)',
                            borderColor: '#38bdf8',
                            borderWidth: 1.5,
                            borderRadius: 6
                        },
                        {
                            label: 'Profit',
                            data: [Math.round(lastYearMonthRevenue * 0.25), Math.round(lastMonthGrossProfit), Math.round(thisMonthGrossProfit)],
                            backgroundColor: 'rgba(163, 230, 53, 0.85)',
                            borderColor: '#a3e635',
                            borderWidth: 1.5,
                            borderRadius: 6
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            display: true,
                            position: 'top',
                            labels: { color: '#cbd5e1', font: { size: 10, weight: '700' }, boxWidth: 12 }
                        },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => ` ${ctx.dataset.label}: Rs. ${Number(ctx.parsed.y).toLocaleString()}`
                            }
                        }
                    },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#94a3b8', font: { size: 9, weight: '700' } } },
                        y: { 
                            grid: { color: 'rgba(255,255,255,0.04)' }, 
                            ticks: { 
                                color: '#94a3b8', 
                                font: { size: 9 },
                                callback: (v) => v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v 
                            } 
                        }
                    }
                }
            });
        }

        // Gross Margin Trend Area Chart
        const ctxCyberMarginTrend = document.getElementById('dash-cyber-margin-trend-chart');
        if (ctxCyberMarginTrend && typeof Chart !== 'undefined') {
            const marginPctBadge = document.getElementById('dash-cyber-margin-pct-badge');
            if (marginPctBadge) {
                const marginPct = fyRevenue > 0 ? Math.round((fyGrossProfit / fyRevenue) * 100) : 0;
                marginPctBadge.textContent = `${marginPct}% Margin`;
            }

            const monthShortNames = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];
            const fyMonths = [];
            for (let m = 3; m <= 11; m++) {
                fyMonths.push({
                    key: `${fyStartYear}-${String(m + 1).padStart(2, '0')}`,
                    label: `${monthShortNames[m - 3]}`
                });
            }
            for (let m = 0; m <= 2; m++) {
                fyMonths.push({
                    key: `${fyEndYear}-${String(m + 1).padStart(2, '0')}`,
                    label: `${monthShortNames[m + 9]}`
                });
            }

            const fyProfitTrendMap = {};
            fyMonths.forEach(fm => { fyProfitTrendMap[fm.key] = 0; });

            orders.forEach(o => {
                const oDate = getOrderDate(o);
                if (!oDate) return;
                const y = oDate.getFullYear();
                const m = oDate.getMonth();
                const k = `${y}-${String(m + 1).padStart(2, '0')}`;
                if (fyProfitTrendMap[k] !== undefined) {
                    const tot = Number(o.grandTotal || o.total || 0);
                    const cost = getOrderCost(o);
                    fyProfitTrendMap[k] += Math.max(0, tot - cost);
                }
            });

            const marginLabels = fyMonths.map(fm => fm.label);
            const marginData = fyMonths.map(fm => Math.round(fyProfitTrendMap[fm.key]));

            if (window._cyberMarginTrendChart) window._cyberMarginTrendChart.destroy();
            window._cyberMarginTrendChart = new Chart(ctxCyberMarginTrend, {
                type: 'line',
                data: {
                    labels: marginLabels,
                    datasets: [
                        {
                            label: 'Margin (LKR)',
                            data: marginData,
                            borderColor: '#a3e635',
                            backgroundColor: 'rgba(163, 230, 53, 0.15)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 2,
                            pointHoverRadius: 4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => ` Profit: Rs. ${Number(ctx.parsed.y).toLocaleString()}`
                            }
                        }
                    },
                    scales: {
                        x: { 
                            grid: { color: 'rgba(255,255,255,0.04)' }, 
                            ticks: { color: '#94a3b8', font: { size: 8, weight: '600' } } 
                        },
                        y: { 
                            grid: { color: 'rgba(255,255,255,0.04)' }, 
                            ticks: { 
                                color: '#94a3b8', 
                                font: { size: 8 },
                                callback: (v) => v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v
                            } 
                        }
                    }
                }
            });
        }

        // 2. Update Ultraleads Clean Elements
        const ultraSales = document.getElementById('dash-ultra-sales');
        if (ultraSales) ultraSales.textContent = `Rs. ${fyRevenue.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;
        const ultraPurch = document.getElementById('dash-ultra-purchase');
        if (ultraPurch) ultraPurch.textContent = `Rs. ${fyCost.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;
        const ultraGrowth = document.getElementById('dash-ultra-growth');
        if (ultraGrowth) ultraGrowth.textContent = `Rs. ${fyGrossProfit.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;
        const ultraCust = document.getElementById('dash-ultra-cust-count');
        if (ultraCust) ultraCust.textContent = Math.max(customers.length, fyOrdersCount).toString();

        // 3. Update Classic Elements
        const classicSales = document.getElementById('dash-classic-sales');
        if (classicSales) classicSales.textContent = `Rs. ${fyRevenue.toLocaleString('en-LK', { minimumFractionDigits: 2 })}`;
        const classicOrders = document.getElementById('dash-classic-orders');
        if (classicOrders) classicOrders.textContent = fyOrdersCount.toLocaleString();
        const classicProd = document.getElementById('dash-classic-products');
        if (classicProd) classicProd.textContent = (products.length || 0).toLocaleString();

    } catch (e) {
        console.error("Dashboard render error:", e);
    }
};

// --- SWITCH DASHBOARD ARCHETYPE (Cyber Neon, Ultraleads, Classic) ---
window.switchDashboardArchetype = (archetype) => {
    const cyberView = document.querySelector('.dash-view-cyber-matrix');
    const ultraView = document.querySelector('.dash-view-ultraleads');
    const classicView = document.querySelector('.dash-view-classic');

    const btnCyber = document.getElementById('btn-dash-archetype-cyber');
    const btnUltra = document.getElementById('btn-dash-archetype-ultraleads');
    const btnClassic = document.getElementById('btn-dash-archetype-classic');

    if (cyberView) cyberView.style.display = archetype === 'cyber' ? 'block' : 'none';
    if (ultraView) ultraView.style.display = archetype === 'ultraleads' ? 'block' : 'none';
    if (classicView) classicView.style.display = archetype === 'classic' ? 'flex' : 'none';

    // Style buttons
    if (btnCyber) {
        btnCyber.style.background = archetype === 'cyber' ? '#a3e635' : 'transparent';
        btnCyber.style.color = archetype === 'cyber' ? '#000' : '#94a3b8';
        btnCyber.style.boxShadow = archetype === 'cyber' ? '0 0 15px rgba(163, 230, 53, 0.4)' : 'none';
    }
    if (btnUltra) {
        btnUltra.style.background = archetype === 'ultraleads' ? '#0ea5e9' : 'transparent';
        btnUltra.style.color = archetype === 'ultraleads' ? '#fff' : '#94a3b8';
        btnUltra.style.boxShadow = archetype === 'ultraleads' ? '0 0 15px rgba(14, 165, 233, 0.4)' : 'none';
    }
    if (btnClassic) {
        btnClassic.style.background = archetype === 'classic' ? 'var(--primary-blue, #38bdf8)' : 'transparent';
        btnClassic.style.color = archetype === 'classic' ? '#020617' : '#94a3b8';
        btnClassic.style.boxShadow = archetype === 'classic' ? '0 0 15px rgba(56, 189, 248, 0.4)' : 'none';
    }

    localStorage.setItem('mecpos_dashboard_archetype', archetype);
    if (typeof window.renderExecutiveDashboard === 'function') {
        window.renderExecutiveDashboard();
    }
};

// Floating Drawer Sidebar Toggle (Slides over screen without resizing layout)
window.toggleDashboardSidebar = () => {
    const isOpen = document.body.classList.toggle('sidebar-open');
    const toggleBtn = document.getElementById('btn-toggle-sidebar');
    if (toggleBtn) {
        toggleBtn.innerHTML = isOpen ? '✕' : '☰';
        toggleBtn.title = isOpen ? 'Close Sidebar' : 'Open Sidebar';
        toggleBtn.style.background = isOpen ? 'rgba(56,189,248,0.2)' : 'rgba(255,255,255,0.06)';
        toggleBtn.style.color = isOpen ? '#38bdf8' : '#cbd5e1';
    }
};

window.closeDashboardSidebar = () => {
    document.body.classList.remove('sidebar-open');
    const toggleBtn = document.getElementById('btn-toggle-sidebar');
    if (toggleBtn) {
        toggleBtn.innerHTML = '☰';
        toggleBtn.title = 'Open Sidebar';
        toggleBtn.style.background = 'rgba(255,255,255,0.06)';
        toggleBtn.style.color = '#cbd5e1';
    }
};

window.openDashboardSidebar = () => {
    document.body.classList.add('sidebar-open');
    const toggleBtn = document.getElementById('btn-toggle-sidebar');
    if (toggleBtn) {
        toggleBtn.innerHTML = '✕';
        toggleBtn.title = 'Close Sidebar';
        toggleBtn.style.background = 'rgba(56,189,248,0.2)';
        toggleBtn.style.color = '#38bdf8';
    }
};

// Initial trigger
setTimeout(() => {
    const savedArchetype = localStorage.getItem('mecpos_dashboard_archetype') || 'cyber';
    if (typeof window.switchDashboardArchetype === 'function') {
        window.switchDashboardArchetype(savedArchetype);
    }
    if (typeof window.renderExecutiveDashboard === 'function') {
        window.renderExecutiveDashboard();
    }
}, 1000);

// Enable nav group auto-expand after initial load settles (so initial showTab calls don't expand groups)
setTimeout(() => { window._navAutoExpand = true; }, 2000);


