// ============================================================================
// MEC POS ARCHIVE & BIGQUERY AGGREGATOR MODULE
// ============================================================================
// Zero-cost historical archiving and querying strategy.
// Live active data remains in Firestore (e.g. current year / recent bills).
// Historical data (> 365 days) is archived to Google Cloud Storage / Cold Storage,
// while remaining seamlessly queryable via BigQuery / Archive Fallback API.
// ============================================================================

import { db } from '../firebase.js';
import { collection, query, where, getDocs, doc, deleteDoc, writeBatch } from 'firebase/firestore';

const ARCHIVE_RETENTION_DAYS = 365;

/**
 * Checks if a date timestamp is older than the retention threshold.
 * @param {Date|Object|number} dateVal 
 * @returns {boolean}
 */
export function isOlderThanRetention(dateVal) {
    if (!dateVal) return false;
    let targetTime = 0;
    if (dateVal instanceof Date) {
        targetTime = dateVal.getTime();
    } else if (dateVal.seconds) {
        targetTime = dateVal.seconds * 1000;
    } else if (typeof dateVal === 'number') {
        targetTime = dateVal;
    } else {
        const d = new Date(dateVal);
        targetTime = isNaN(d.getTime()) ? 0 : d.getTime();
    }
    if (!targetTime) return false;

    const diffDays = (Date.now() - targetTime) / (1000 * 60 * 60 * 24);
    return diffDays > ARCHIVE_RETENTION_DAYS;
}

/**
 * Seamlessly searches for historical orders/bills.
 * First checks active live state. If date range extends beyond 365 days,
 * transparently queries the Cloud Cold Archive without breaking UI.
 * 
 * @param {string} storeId 
 * @param {Date} startDate 
 * @param {Date} endDate 
 * @param {Array} activeLiveOrders 
 * @returns {Promise<Array>} Combined active + archived records
 */
export async function fetchSeamlessHistoricalOrders(storeId, startDate, endDate, activeLiveOrders = []) {
    let results = [...activeLiveOrders];

    const isStartOld = startDate && isOlderThanRetention(startDate);
    
    if (isStartOld) {
        console.log(`[ArchiveManager] Date range includes historical archived data (>365 days). Fetching cold archives for store: ${storeId}...`);
        try {
            const archivedRecords = await fetchFromColdArchive(storeId, startDate, endDate);
            if (archivedRecords && archivedRecords.length > 0) {
                // Deduplicate by id
                const activeIds = new Set(results.map(o => o.id));
                const uniqueArchived = archivedRecords.filter(a => !activeIds.has(a.id));
                results = [...results, ...uniqueArchived];
            }
        } catch (err) {
            console.warn('[ArchiveManager] Cloud Cold Archive fetch warning (falling back to live data):', err);
        }
    }

    return results;
}

/**
 * Fetch archived records from Google Cloud Storage / BigQuery REST Endpoint
 * Zero-cost cold storage query fallback.
 */
async function fetchFromColdArchive(storeId, startDate, endDate) {
    const archiveEndpoint = `https://mecpos.web.lk/api/archive/query`;
    try {
        const resp = await fetch(archiveEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                storeId: storeId,
                startDate: startDate ? startDate.toISOString() : null,
                endDate: endDate ? endDate.toISOString() : null
            })
        });

        if (resp.ok) {
            const data = await resp.json();
            return data.records || [];
        }
    } catch (e) {
        // Fallback gracefully if network/offline
    }
    return [];
}

/**
 * Local helper to export historical records (>365 days) into JSON payload for cold archiving.
 */
export async function exportStoreHistoricalDataJSON(storeId) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - ARCHIVE_RETENTION_DAYS);

    const ordersRef = collection(db, 'orders');
    const q = query(ordersRef, where('storeId', '==', storeId));
    
    const snap = await getDocs(q);
    const toArchive = [];
    
    snap.forEach(docSnap => {
        const data = docSnap.data();
        const created = data.createdAt?.toDate ? data.createdAt.toDate() : new Date(data.date || 0);
        if (created < cutoffDate) {
            toArchive.push({ id: docSnap.id, ...data });
        }
    });

    return {
        storeId,
        exportedAt: new Date().toISOString(),
        count: toArchive.length,
        records: toArchive
    };
}

window.ArchiveManager = {
    isOlderThanRetention,
    fetchSeamlessHistoricalOrders,
    exportStoreHistoricalDataJSON
};
