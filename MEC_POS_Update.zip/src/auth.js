import './style.css';
import { auth } from './firebase.js';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    updateProfile,
    sendPasswordResetEmail
} from "firebase/auth";
import { 
    collection, 
    addDoc, 
    serverTimestamp,
    query,
    where,
    getDocs
} from "firebase/firestore";
import { db } from './firebase.js';

// ─── SaaS Store & Merchant Logo Resolution ───────────────────
const urlParams = new URLSearchParams(window.location.search);
const pathParts = window.location.pathname.split('/').filter(p => p !== '');
const slugFromPath = (pathParts[0] && !['index.html', 'track', 'admin', 'login.html', 'merchant-login.html'].includes(pathParts[0])) ? pathParts[0] : null;
const currentStoreId = urlParams.get('store') || slugFromPath || localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';
window.currentStoreId = currentStoreId;

async function syncMerchantBranding() {
    try {
        const hostname = window.location.hostname;
        let matchedStore = null;

        if (currentStoreId) {
            const q = query(collection(db, 'stores'), where('slug', '==', currentStoreId));
            const snap = await getDocs(q);
            if (!snap.empty) {
                matchedStore = snap.docs[0].data();
            }
        }

        if (!matchedStore) {
            const cleanHostname = hostname.replace(/^www\./, '');
            const qDom = query(collection(db, 'stores'), where('domain', '==', cleanHostname));
            const snapDom = await getDocs(qDom);
            if (!snapDom.empty) {
                matchedStore = snapDom.docs[0].data();
            } else {
                const qDefault = query(collection(db, 'stores'), where('slug', '==', 'mec-book-shop'));
                const snapDefault = await getDocs(qDefault);
                if (!snapDefault.empty) matchedStore = snapDefault.docs[0].data();
            }
        }

        if (matchedStore) {
            const merchantLogo = (matchedStore.logoUrl && matchedStore.logoUrl.length > 10) 
                ? matchedStore.logoUrl 
                : '/logo.png';

            document.querySelectorAll('#merchant-logo-img, .logo-ring img, .logo-3d-img').forEach(img => {
                img.src = merchantLogo;
            });

            const storeName = matchedStore.name || matchedStore.storeName || matchedStore.title;
            if (storeName) {
                document.querySelectorAll('#merchant-store-name, .brand-title').forEach(el => {
                    el.textContent = storeName;
                });
                document.title = `${storeName} — Login / Register`;
            }

            if (matchedStore.primaryColor) {
                document.documentElement.style.setProperty('--primary', matchedStore.primaryColor);
                document.documentElement.style.setProperty('--primary-color', matchedStore.primaryColor);
            }
        }
    } catch (e) {
        console.error("[Merchant Branding Sync] Error:", e);
    }
}

syncMerchantBranding();

// ─── Interactive Family MP4 Video Controller ─────────────────
const bgVideo = document.getElementById('bg-video');

function syncVideoToState(mode) {
    if (!bgVideo) return;
    if (mode === 'register') {
        // Register mode: Car arrival (0s) -> Door waiting pause (3.8s)
        bgVideo.currentTime = 0;
        bgVideo.play().catch(() => {});
    } else {
        // Login mode: Start inside shop (6s) & loop aisle shopping (6s - 9s)
        bgVideo.currentTime = 6.0;
        bgVideo.play().catch(() => {});
    }
}

if (bgVideo) {
    bgVideo.loop = false;
    bgVideo.addEventListener('timeupdate', () => {
        const isReg = document.getElementById('storefront-auth-container')?.classList.contains('is-register');
        if (isReg) {
            // Pause at 3.8s so family stands waiting outside glass entrance door
            if (bgVideo.currentTime >= 3.8 && bgVideo.currentTime < 4.0) {
                bgVideo.pause();
            }
        } else {
            // Loop inside shop aisle shopping section (6.0s - 9.0s)
            if (bgVideo.currentTime >= 9.0) {
                bgVideo.currentTime = 6.0;
            }
        }
    });
    
    // Default to Login mode (starts inside shop at 6.0s)
    const initialReg = document.getElementById('storefront-auth-container')?.classList.contains('is-register');
    syncVideoToState(initialReg ? 'register' : 'login');
}

// ─── Sliding Overlay Panel Controls ───────────────────────────
const storefrontContainer = document.getElementById('storefront-auth-container');
const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const tabLoginMobile = document.getElementById('tab-login-mobile');
const tabRegisterMobile = document.getElementById('tab-register-mobile');

function switchToRegister() {
    if (storefrontContainer) {
        storefrontContainer.classList.add('is-register');
        syncVideoToState('register');
    }
}

function switchToLogin() {
    if (storefrontContainer) {
        storefrontContainer.classList.remove('is-register');
        syncVideoToState('login');
    }
}

tabRegister?.addEventListener('click', switchToRegister);
tabLogin?.addEventListener('click', switchToLogin);
tabRegisterMobile?.addEventListener('click', (e) => { e.preventDefault(); switchToRegister(); });
tabLoginMobile?.addEventListener('click', (e) => { e.preventDefault(); switchToLogin(); });

const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const resetForm = document.getElementById('reset-form');
const authMsg = document.getElementById('auth-msg');

// ─── Password Visibility Toggle ──────────────────────────────
const setupPasswordToggle = (toggleId, inputId) => {
    const toggle = document.getElementById(toggleId);
    const input = document.getElementById(inputId);
    if (toggle && input) {
        toggle.addEventListener('click', () => {
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            toggle.innerText = type === 'password' ? '🔒' : '👁️';
        });
    }
};

setupPasswordToggle('toggle-login-pass', 'login-pass');
setupPasswordToggle('toggle-reg-pass', 'reg-pass');

// ─── Remember Me Logic ───────────────────────────────────────
const rememberMeCheckbox = document.getElementById('remember-me');
const loginEmailInput = document.getElementById('login-email');

if (loginEmailInput) {
    const savedEmail = localStorage.getItem('mec_remembered_email');
    if (savedEmail) {
        loginEmailInput.value = savedEmail;
        if (rememberMeCheckbox) rememberMeCheckbox.checked = true;
    }
}

// ─── Registration Handler ────────────────────────────────────
registerForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('reg-name')?.value?.trim() || '';
    const email = document.getElementById('reg-email')?.value?.trim() || '';
    const phone = document.getElementById('reg-phone')?.value?.trim() || '';
    const pass = document.getElementById('reg-pass')?.value || '';

    const regMsg = document.getElementById('reg-auth-msg') || authMsg;
    const btnRegister = registerForm.querySelector('.btn-register') || registerForm.querySelector('button[type="submit"]');

    function showRegError(msgText) {
        if (regMsg) {
            regMsg.textContent = '❌ ' + msgText;
            regMsg.classList.add('show');
            setTimeout(() => regMsg.classList.remove('show'), 5000);
        } else {
            alert(msgText);
        }
    }

    if (!name || !email || !pass) {
        showRegError('කරුණාකර නම, Email සහ මුරපදය ඇතුළත් කරන්න. (Please fill out all required fields)');
        return;
    }

    if (pass.length < 6) {
        showRegError('මුරපදය අවම වශයෙන් අක්ෂර 6ක් විය යුතුය. (Password must be at least 6 characters)');
        return;
    }

    const origBtnText = btnRegister ? btnRegister.innerHTML : 'Create My Account';
    if (btnRegister) {
        btnRegister.disabled = true;
        btnRegister.innerHTML = '⌛ Creating Account...';
    }

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
        const user = userCredential.user;

        try {
            await updateProfile(user, { displayName: name });
        } catch (pErr) {
            console.warn("Profile name update warning:", pErr);
        }

        try {
            const customersCol = collection(db, 'customers');
            const loyaltyCardNo = 'LO-' + Math.floor(100000 + Math.random() * 900000);
            await addDoc(customersCol, {
                name: name,
                email: email,
                phone: phone || '',
                loyaltyCardNo: loyaltyCardNo,
                customerType: 'loyalty',
                storeId: currentStoreId,
                timestamp: serverTimestamp(),
                source: 'web_registration'
            });
        } catch (dbError) {
            console.error("Firestore customer sync failed (non-fatal):", dbError);
        }

        sessionStorage.setItem('mec_user', JSON.stringify({
            name: name || user.email,
            email: user.email,
            id: user.uid
        }));

        // Show Success Overlay
        const successOverlay = document.getElementById('success-overlay');
        const sName = document.getElementById('s-name');
        const sRole = document.getElementById('s-role');
        if (sName) sName.textContent = `Welcome, ${name}!`;
        if (sRole) sRole.textContent = `Account Created Successfully! Entering store...`;
        if (successOverlay) successOverlay.classList.add('show');

        // Resume Entrance Video: Glass doors open and family walks inside!
        if (bgVideo) {
            bgVideo.currentTime = 3.9;
            bgVideo.play().catch(() => {});
        }

        setTimeout(() => window.location.href = '/', 1800);
    } catch (error) {
        console.error("Registration error:", error);
        if (btnRegister) {
            btnRegister.disabled = false;
            btnRegister.innerHTML = origBtnText;
        }

        let readableError = error.message;
        if (error.code === 'auth/email-already-in-use') {
            readableError = 'මෙම Email ලිපිනය දැනටමත් ලියාපදිංචි වී ඇත. (Email is already registered. Please Sign In)';
        } else if (error.code === 'auth/invalid-email') {
            readableError = 'අවලංගු Email ලිපිනයකි. (Invalid email address)';
        } else if (error.code === 'auth/weak-password') {
            readableError = 'මුරපදය අවම වශයෙන් අක්ෂර 6ක් විය යුතුය. (Password must be at least 6 characters)';
        } else if (error.code === 'auth/network-request-failed') {
            readableError = 'ජාල සබඳතා දෝෂයකි. (Network connection error)';
        }

        showRegError(readableError);
    }
});

// ─── Login Handler ───────────────────────────────────────────
loginForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-pass').value;

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, pass);
        const user = userCredential.user;

        if (document.getElementById('remember-me')?.checked) {
            localStorage.setItem('mec_remembered_email', email);
        } else {
            localStorage.removeItem('mec_remembered_email');
        }

        sessionStorage.setItem('mec_user', JSON.stringify({
            name: user.displayName || user.email,
            email: user.email,
            id: user.uid
        }));

        // Show Success Overlay & Play Entrance Video
        const successOverlay = document.getElementById('success-overlay');
        const sName = document.getElementById('s-name');
        const sRole = document.getElementById('s-role');
        if (sName) sName.textContent = `Welcome Back!`;
        if (sRole) sRole.textContent = `Access Granted! Entering store...`;
        if (successOverlay) successOverlay.classList.add('show');

        if (bgVideo) {
            bgVideo.currentTime = 3.9;
            bgVideo.play().catch(() => {});
        }

        setTimeout(() => window.location.href = '/', 1800);
    } catch (error) {
        if (authMsg) {
            authMsg.textContent = '❌ Invalid email or password!';
            authMsg.classList.add('show');
            setTimeout(() => authMsg.classList.remove('show'), 4000);
        }
    }
});

// ─── Password Reset Logic ────────────────────────────────────
const forgotPassLink = document.getElementById('forgot-pass-link');
const backToLogin = document.getElementById('back-to-login');

forgotPassLink?.addEventListener('click', (e) => {
    e.preventDefault();
    if (loginForm) loginForm.style.display = 'none';
    if (resetForm) resetForm.style.display = 'block';
});

backToLogin?.addEventListener('click', (e) => {
    e.preventDefault();
    if (resetForm) resetForm.style.display = 'none';
    if (loginForm) loginForm.style.display = 'block';
});

resetForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('reset-email').value;
    const submitBtn = resetForm.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn ? submitBtn.innerText : 'Send Reset Link';

    try {
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerText = 'Sending...';
        }

        await sendPasswordResetEmail(auth, email);

        if (authMsg) {
            authMsg.style.color = '#16a34a';
            authMsg.textContent = '✅ Reset link sent to ' + email + '. Check your inbox!';
            authMsg.classList.add('show');
        }

        resetForm.reset();
        if (submitBtn) submitBtn.innerText = 'Email Sent';

        setTimeout(() => {
            backToLogin.click();
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerText = originalBtnText;
            }
        }, 4000);

    } catch (error) {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = originalBtnText;
        }
        if (authMsg) {
            authMsg.style.color = '#ef4444';
            authMsg.textContent = '❌ ' + (error.code === 'auth/user-not-found' ? 'Email not registered.' : error.message);
            authMsg.classList.add('show');
            setTimeout(() => authMsg.classList.remove('show'), 4000);
        }
    }
});
