import { db, auth } from '../firebase.js';
import { 
    collection, 
    doc, 
    setDoc,
    addDoc, 
    updateDoc, 
    deleteDoc, 
    getDoc,
    getDocs,
    query,
    where,
    writeBatch, 
    serverTimestamp 
} from "firebase/firestore";

// Collections (Shared with admin.js)
const productsCol = collection(db, 'products');
const ordersCol = collection(db, 'orders');
const customersCol = collection(db, 'customers');

// --- POS Terminal & Customer Logic ---

window.handlePOSCustKeydown = (e) => {
    const phoneEl = document.getElementById('pos-cust-phone');
    const dropdown = document.getElementById('pos-cust-search-dropdown');
    const matches = window.currentPOSCustSearchMatches || [];
    
    if (['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(e.key)) {
        e.stopPropagation();
        e.stopImmediatePropagation();
    }
    
    if (dropdown && dropdown.style.display !== 'none' && matches.length > 0) {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            e.stopPropagation();
            if (window.activePOSCustSearchIndex === -1) {
                window.activePOSCustSearchIndex = 0;
            } else {
                window.activePOSCustSearchIndex = (window.activePOSCustSearchIndex + 1) % matches.length;
            }
            window.updatePOSCustSearchHighlight();
            return false;
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            e.stopPropagation();
            if (window.activePOSCustSearchIndex <= 0) {
                window.activePOSCustSearchIndex = matches.length - 1;
            } else {
                window.activePOSCustSearchIndex = window.activePOSCustSearchIndex - 1;
            }
            window.updatePOSCustSearchHighlight();
            return false;
        } else if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            const idx = window.activePOSCustSearchIndex >= 0 ? window.activePOSCustSearchIndex : 0;
            if (idx >= 0 && idx < matches.length) {
                const selected = matches[idx];
                window.selectPOSSearchCustomer(selected.phone || selected.loyaltyCardNo || selected.name, selected.name);
            } else {
                const val = phoneEl ? phoneEl.value.trim() : '';
                if (val) window.lookupPOSCustomer(val, true);
            }
            return false;
        } else if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            dropdown.style.display = 'none';
            return false;
        }
    } else if (e.key === 'Enter') {
        e.preventDefault();
        const val = phoneEl ? phoneEl.value.trim() : '';
        if (val && !window.currentPOSCustomer) {
            window.lookupPOSCustomer(val, true);
        }
        if (window.highlightPOSSearchItem) window.highlightPOSSearchItem();
        setTimeout(() => {
            const searchEl = document.getElementById('pos-search');
            if (searchEl) {
                searchEl.focus();
                searchEl.select();
            }
        }, 50);
    }
};

window.initPOS = () => {
    // Focus phone input immediately
    const phoneEl = document.getElementById('pos-cust-phone');
    if (phoneEl) {
        setTimeout(() => {
            phoneEl.focus();
            phoneEl.select();
        }, 500);

        phoneEl.addEventListener('keydown', (e) => window.handlePOSCustKeydown(e));
    }

    // [MOD] POS Qty Modal Keyboard Flow (Requirement Part 3)
    const qtyInput = document.getElementById('qty-modal-input');
    const discInput = document.getElementById('qty-modal-discount');
    const qtyModal = document.getElementById('pos-item-qty-modal');

    qtyInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            discInput?.focus();
            discInput?.select();
        }
        if (e.key === 'Escape') { e.stopPropagation(); qtyModal.style.display = 'none'; }
    });

    discInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            if (typeof window.confirmPOSItemAdd === 'function') window.confirmPOSItemAdd();
        }
        if (e.key === 'Escape') { e.stopPropagation(); qtyModal.style.display = 'none'; }
    });

    // [MOD] POS Search Keyboard Navigation & Visual Highlight
    window.highlightPOSSearchItem = function() {
        const listDiv = document.getElementById('pos-product-list');
        if (!listDiv) return;
        const items = listDiv.querySelectorAll('.pos-v2-item');
        items.forEach((item, idx) => {
            if (posSelectedSearchIndex >= 0 && idx === posSelectedSearchIndex) {
                item.classList.add('selected');
                item.style.outline = '2px solid #38bdf8';
                item.style.boxShadow = '0 0 18px rgba(56, 189, 248, 0.6)';
                item.style.zIndex = '10';
                item.scrollIntoView({ behavior: 'auto', block: 'nearest' });
            } else {
                item.classList.remove('selected');
                item.style.outline = 'none';
                item.style.boxShadow = 'none';
                item.style.zIndex = '1';
            }
        });
    };

    const posSearchInput = document.getElementById('pos-search');
    posSearchInput?.addEventListener('keydown', (e) => {
        // If variant selection modal is open, ignore key events here so window key listener handles it
        const varModal = document.getElementById('pos-variant-selection-modal');
        if (varModal && varModal.style.display === 'flex') {
            return;
        }

        if (!currentPOSSearchResults || currentPOSSearchResults.length === 0) return;
        
        const listDiv = document.getElementById('pos-product-list');
        const cols = listDiv ? (getComputedStyle(listDiv).gridTemplateColumns.split(' ').length || 1) : 1;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            e.stopPropagation();
            if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
            else posSelectedSearchIndex = Math.min(posSelectedSearchIndex + cols, currentPOSSearchResults.length - 1);
            window.highlightPOSSearchItem();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            e.stopPropagation();
            if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
            else posSelectedSearchIndex = Math.max(0, posSelectedSearchIndex - cols);
            window.highlightPOSSearchItem();
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            e.stopPropagation();
            if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
            else posSelectedSearchIndex = Math.min(posSelectedSearchIndex + 1, currentPOSSearchResults.length - 1);
            window.highlightPOSSearchItem();
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            e.stopPropagation();
            if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
            else posSelectedSearchIndex = Math.max(0, posSelectedSearchIndex - 1);
            window.highlightPOSSearchItem();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            // Cancel any pending search debounce so it doesn't overwrite UI after adding
            if (posSearchDebounceTimer) {
                clearTimeout(posSearchDebounceTimer);
                posSearchDebounceTimer = null;
            }
            // If user explicitly selected with Arrow keys → add that item
            if (posSelectedSearchIndex >= 0 && currentPOSSearchResults && posSelectedSearchIndex < currentPOSSearchResults.length) {
                const idxToUse = posSelectedSearchIndex;
                posSelectedSearchIndex = -1;
                window.highlightPOSSearchItem();
                window.addToPOSBillByIndex(idxToUse);
            } else if (currentPOSSearchResults && currentPOSSearchResults.length === 1) {
                // Short code / barcode mode: exactly 1 result → auto-add directly
                const searchVal = (document.getElementById('pos-search')?.value || '').trim().toLowerCase();
                const singleProduct = currentPOSSearchResults[0];
                const skuMatch = singleProduct && window.matchProductSku && window.matchProductSku(singleProduct.sku, searchVal);
                if (skuMatch || searchVal.length >= 1) {
                    // Direct add — clear search after
                    posSelectedSearchIndex = -1;
                    window.highlightPOSSearchItem();
                    window.addToPOSBillByIndex(0);
                }
            } else if (currentPOSSearchResults && currentPOSSearchResults.length > 1) {
                // If exact SKU or barcode match exists among results, prioritize and add it immediately
                const searchVal = (document.getElementById('pos-search')?.value || '').trim().toLowerCase();
                if (searchVal) {
                    const exactIdx = currentPOSSearchResults.findIndex(p => 
                        (p.sku && p.sku.toLowerCase() === searchVal) ||
                        (p.searchSkuTokens && p.searchSkuTokens.includes(searchVal))
                    );
                    if (exactIdx !== -1) {
                        posSelectedSearchIndex = -1;
                        window.highlightPOSSearchItem();
                        window.addToPOSBillByIndex(exactIdx);
                    }
                }
            }
        }
    });

    // Restore any pending draft bills on POS initialization
    if (typeof window.restorePOSDraftsUI === 'function') {
        window.restorePOSDraftsUI();
    }

    // Instantly render products catalog on POS initialization
    if (typeof window.handlePOSSearch === 'function') {
        window.handlePOSSearch('');
    }
};

// Toggle customer pill: show input while typing, show name when customer found/idle
window.posCustPillUpdate = () => {
    const input = document.getElementById('pos-cust-phone');
    const nameDisplay = document.getElementById('pos-cust-name-display');
    const pill = document.getElementById('pos-cust-pill');
    if (!input || !nameDisplay || !pill) return;

    const isFocused = document.activeElement === input;
    const customer = window.currentPOSCustomer;

    if (customer && customer.name) {
        // Customer selected: display customer's NAME in the input box!
        input.value = customer.name;
        input.style.opacity = '1';
        input.style.color = '#38bdf8'; // Sky blue text for selected customer name
        nameDisplay.style.display = 'none';
        pill.style.borderColor = 'rgba(56,189,248,0.5)';
    } else if (isFocused) {
        // Typing/searching mode: clear text color
        input.style.opacity = '1';
        input.style.color = '#ffffff';
        nameDisplay.style.display = 'none';
        pill.style.borderColor = 'rgba(56, 189, 248, 0.6)';
    } else {
        // Default / Walk-in mode
        if (!input.value.trim()) {
            input.style.opacity = '0';
            nameDisplay.style.display = 'block';
            nameDisplay.innerText = 'Walk-in Customer';
            nameDisplay.style.opacity = '1';
        } else {
            input.style.opacity = '1';
            input.style.color = '#ffffff';
            nameDisplay.style.display = 'none';
        }
        pill.style.borderColor = 'rgba(255,255,255,0.15)';
    }
};

window.lookupPOSCustomer = (val, shouldRegister = true) => {

    const pointsBadge = document.getElementById('pos-cust-points-badge');
    const pointsVal = document.getElementById('pos-cust-points-val');
    const nameDisplay = document.getElementById('pos-cust-name-display');
    const input = document.getElementById('pos-cust-phone');
    
    if(pointsBadge) pointsBadge.style.display = 'none';

    if (!val || val.trim() === "") {
        if(nameDisplay) nameDisplay.innerText = 'Walk-in Customer';
        window.currentPOSCustomer = null; // Clear stored customer
        if (input) input.value = '';
        const activeBill = getActiveBill();
        if (activeBill) {
            activeBill.pricingMode = 'retail';
            activeBill.customer = null;
        }
        const pricingSelect = document.getElementById('pos-pricing-mode');
        if (pricingSelect) {
            pricingSelect.value = 'retail';
            updatePOSPricingMode();
        }
        window.posCustPillUpdate();
        return;
    }
    
    const q = val.trim().toLowerCase();
    // Improved matching: Exact match or partial match (if searching)
    const customer = (window.allCustomers || []).find(c => {
        const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
        const qClean = q.replace(/\s/g, '');
        
        // Normalize both (remove leading zero for comparison)
        const cPhoneNormalized = cPhone.replace(/^0/, '');
        const qCleanNormalized = qClean.replace(/^0/, '');

        // Match exact phone (10 digits/normalized), exact loyalty card, or exact name
        const phoneMatch = (cPhone === qClean) || (cPhoneNormalized === qCleanNormalized);
        const cardMatch = (c.loyaltyCardNo && c.loyaltyCardNo.toLowerCase() === q);
        const cName = (c.name || "").toLowerCase();
        const nameMatch = (cName === q);

        return phoneMatch || cardMatch || nameMatch;
    });

    if (customer) {
        window.currentPOSCustomer = customer; // Store found customer globally
        if (shouldRegister) window.showToast(`✨ Customer Found: ${customer.name}`, "success");
        if (nameDisplay) nameDisplay.innerText = customer.name;
        if (input) input.value = customer.name; // Display customer NAME in input
        
        setTimeout(() => window.posCustPillUpdate?.(), 20); // Update pill to display mode
        
        if(pointsBadge && pointsVal) {
            const pts = customer.loyaltyPoints || 0;
            pointsVal.innerText = pts.toLocaleString(); 
            pointsBadge.style.display = 'flex';
            
            const modalPointsWrap = document.getElementById('pay-modal-points-redeem-wrap');
            const modalPointsVal = document.getElementById('pay-modal-available-points');
            if (modalPointsWrap) modalPointsWrap.style.display = 'block';
            if (modalPointsVal) modalPointsVal.innerText = Math.floor(pts);
        }
        
        const pricingSelect = document.getElementById('pos-pricing-mode');
        if (pricingSelect) {
            if (customer.customerType === 'wholesale') {
                pricingSelect.value = 'wholesale';
            } else if (customer.customerType === 'loyalty' || customer.loyaltyCardNo) {
                pricingSelect.value = 'loyalty';
            } else {
                pricingSelect.value = 'retail';
            }
            updatePOSPricingMode();
        }
    } else {
        window.currentPOSCustomer = null; // Clear stored customer
        if(nameDisplay) nameDisplay.innerText = 'Walk-in Customer';
        setTimeout(() => window.posCustPillUpdate?.(), 20); // Update pill to default mode

        // Clear the points display in the payment modal
        const modalPointsWrap = document.getElementById('pay-modal-points-redeem-wrap');
        const modalPointsVal = document.getElementById('pay-modal-available-points');
        const redeemInput = document.getElementById('pay-modal-redeem-input');
        if (modalPointsWrap) modalPointsWrap.style.display = 'none';
        if (modalPointsVal) modalPointsVal.innerText = '0';
        if (redeemInput) redeemInput.value = '0';
        window.appliedLoyaltyPoints = 0;
        window.appliedLoyaltyPointsOnThisBill = 0;
        
        // Only open Quick Registration if explicitly asked (e.g. on blur/Enter)
        if (shouldRegister && q.length >= 2) {
            const modal = document.getElementById('quick-cust-modal');
            const phoneInput = document.getElementById('quick-cust-phone');
            const nameInput = document.getElementById('quick-cust-name');
            if (modal && phoneInput && nameInput) {
                const isPhone = /^\+?[0-9\s-]+$/.test(val) && val.replace(/[\s-]/g, '').length >= 9;
                if (isPhone) {
                    phoneInput.value = val;
                    nameInput.value = '';
                    modal.style.display = 'flex';
                    setTimeout(() => nameInput.focus(), 100);
                } else {
                    nameInput.value = val;
                    phoneInput.value = '';
                    modal.style.display = 'flex';
                    setTimeout(() => phoneInput.focus(), 100);
                }
            }
        }
        
        const ptBadge = document.getElementById('pos-cust-points-badge');
        const mptWrap = document.getElementById('pay-modal-points-redeem-wrap');
        if (ptBadge) ptBadge.style.display = 'none';
        if (mptWrap) mptWrap.style.display = 'none';
        
        window.appliedLoyaltyPoints = 0;
        calculatePOSTotals();
    }
};

window.handlePOSCustSearch = (val) => {
    window.posCustPillUpdate();
    const dropdown = document.getElementById('pos-cust-search-dropdown');
    if (!dropdown) return;

    if (!val || val.trim().length < 2) {
        dropdown.style.display = 'none';
        window.currentPOSCustSearchMatches = [];
        window.activePOSCustSearchIndex = -1;
        return;
    }

    const q = val.trim().toLowerCase();
    const qTokens = q.split(/\s+/).filter(t => t.length > 0);
    const matches = (window.allCustomers || []).filter(c => {
        const cName = (c.name || "").toLowerCase();
        const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
        const qClean = q.replace(/\s/g, '');
        const cPhoneNormalized = cPhone.replace(/^0/, '');
        const qCleanNormalized = qClean.replace(/^0/, '');

        // 1. Direct match on phone or loyalty card
        const phoneMatch = cPhone.includes(qClean) || cPhoneNormalized.includes(qCleanNormalized);
        const cardMatch = c.loyaltyCardNo && c.loyaltyCardNo.toLowerCase().includes(q);
        if (phoneMatch || cardMatch) return true;

        // 2. Token-based matching on customer name (highly spelling/typo tolerant)
        if (qTokens.length === 0) return false;
        return qTokens.every(token => {
            if (cName.includes(token)) return true;
            
            const prefix = token.substring(0, 2);
            const words = cName.split(/\s+/);
            if (token.length >= 2 && words.some(w => w.startsWith(prefix))) return true;
            
            // Fallback to first character initial match (only if query token is 1 char to prevent search pollution)
            return token.length === 1 && words.some(w => w.startsWith(token[0]));
        });
    }).slice(0, 15); // limit to 15 matches

    window.currentPOSCustSearchMatches = matches;
    window.activePOSCustSearchIndex = -1;

    if (matches.length === 0) {
        dropdown.innerHTML = `<div style="padding: 10px 15px; color: #64748b; font-size: 0.85rem; text-align: center;">No customers found</div>`;
        dropdown.style.display = 'block';
        return;
    }

    dropdown.innerHTML = matches.map((c, index) => `
        <div class="pos-cust-search-item" id="pos-cust-item-${index}" 
             onclick="window.selectPOSSearchCustomer('${c.phone || c.loyaltyCardNo || c.name}', '${c.name.replace(/'/g, "\\'")}')" 
             style="padding: 10px 15px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.12s, border-left 0.12s;">
            <div style="font-weight: 700; color: white; font-size: 0.9rem;">${c.name}</div>
            <div style="font-size: 0.8rem; color: #38bdf8; display: flex; justify-content: space-between; margin-top: 2px;">
                <span>📞 ${c.phone || 'No Phone'}</span>
                <span style="opacity: 0.7;">💳 ${c.loyaltyCardNo || 'Loyalty'}</span>
            </div>
        </div>
    `).join('');
    dropdown.style.display = 'block';
    window.updatePOSCustSearchHighlight();
};

window.updatePOSCustSearchHighlight = () => {
    const matches = window.currentPOSCustSearchMatches || [];
    const dropdown = document.getElementById('pos-cust-search-dropdown');
    for (let i = 0; i < matches.length; i++) {
        const item = document.getElementById(`pos-cust-item-${i}`);
        if (item) {
            if (i === window.activePOSCustSearchIndex) {
                item.style.background = '#0284c7';
                item.style.borderLeft = '6px solid #f59e0b';
                item.style.boxShadow = '0 0 15px rgba(2, 132, 199, 0.8)';
                
                // Scroll container cleanly
                if (dropdown) {
                    const itemTop = item.offsetTop;
                    const itemBottom = itemTop + item.offsetHeight;
                    const containerTop = dropdown.scrollTop;
                    const containerBottom = containerTop + dropdown.clientHeight;

                    if (itemTop < containerTop) {
                        dropdown.scrollTop = itemTop;
                    } else if (itemBottom > containerBottom) {
                        dropdown.scrollTop = itemBottom - dropdown.clientHeight;
                    }
                }
            } else {
                item.style.background = 'transparent';
                item.style.borderLeft = '6px solid transparent';
                item.style.boxShadow = 'none';
            }
        }
    }
};

window.selectPOSSearchCustomer = (phoneOrId, name) => {
    const input = document.getElementById('pos-cust-phone');
    window.lookupPOSCustomer(phoneOrId, true);
    if (input) {
        if (window.currentPOSCustomer && window.currentPOSCustomer.name) {
            input.value = window.currentPOSCustomer.name;
        } else if (name) {
            input.value = name;
        }
    }
    window.posCustPillUpdate();
    const dropdown = document.getElementById('pos-cust-search-dropdown');
    if (dropdown) dropdown.style.display = 'none';

    // Auto-update pricing mode & item discounts according to customer type
    if (window.currentPOSCustomer) {
        const custType = (window.currentPOSCustomer.customerType || window.currentPOSCustomer.type || '').toLowerCase();
        const modeSelect = document.getElementById('pos-pricing-mode');
        if (modeSelect) {
            if (custType.includes('wholesale')) {
                modeSelect.value = 'wholesale';
            } else {
                modeSelect.value = 'loyalty';
            }
        }
        window.updatePOSPricingMode();
    }

    // Focus product search field
    setTimeout(() => {
        const searchEl = document.getElementById('pos-search');
        if (searchEl) {
            searchEl.focus();
            searchEl.select();
        }
    }, 100);
};

// Close dropdown on click outside
document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('pos-cust-search-dropdown');
    const pill = document.getElementById('pos-cust-pill');
    if (dropdown && pill && !pill.contains(e.target)) {
        dropdown.style.display = 'none';
    }
});



window.saveQuickPOSCustomer = async (e) => {
    e.preventDefault();
    const name = document.getElementById('quick-cust-name').value;
    const phone = document.getElementById('quick-cust-phone').value;
    const address = document.getElementById('quick-cust-address').value;
    const type = document.getElementById('quick-cust-type').value;

    if (!name || !phone) {
        window.showToast("⚠️ Name and Phone are required!", "error");
        return;
    }

    const cleanedPhone = phone.trim().replace(/\D/g, '');
    const currentStoreId = window.getStoreId();
    const phoneExists = (window.allCustomers || []).some(c => {
        const cPhone = (c.phone || '').trim().replace(/\D/g, '');
        return cPhone === cleanedPhone && c.storeId === currentStoreId;
    });

    if (phoneExists) {
        window.showToast("⚠️ A customer with this phone number already exists!", "error");
        return;
    }
    
    // Auto-generate Customer ID based on type
    const custs = window.allCustomers || [];
    let generatedId = '';
    if (type === 'wholesale') {
        const cCount = custs.filter(c => c.customerType === 'wholesale').length;
        generatedId = 'WHO-' + String(cCount + 1).padStart(3, '0');
    } else {
        const cCount = custs.filter(c => c.customerType !== 'wholesale').length;
        generatedId = 'LO-' + String(cCount + 1).padStart(3, '0');
    }
    
    const loyaltyCardNo = generatedId;

    try {
        const docRef = await addDoc(customersCol, { 
            name, phone, address, 
            loyaltyCardNo,
            customerType: type,
            storeId: window.getStoreId(), 
            timestamp: serverTimestamp() 
        });
        document.getElementById('quick-cust-modal').style.display = 'none';
        
        // Clear quick-cust inputs
        document.getElementById('quick-cust-name').value = '';
        document.getElementById('quick-cust-phone').value = '';
        document.getElementById('quick-cust-address').value = '';
        
        window.showToast(`✅ Registered! Loyalty ID: ${loyaltyCardNo}`, "success");

        // Automatically push to local array to avoid Firestore sync delay
        const newCustomerObj = {
            docId: docRef.id,
            name, phone, address,
            loyaltyCardNo,
            customerType: type,
            storeId: window.getStoreId(),
            outstanding: 0,
            loyaltyPoints: 0
        };
        if (!window.allCustomers) window.allCustomers = [];
        window.allCustomers.push(newCustomerObj);

        // Update POS customer search input and select customer
        const posCustPhoneInput = document.getElementById('pos-cust-phone');
        if (posCustPhoneInput) {
            posCustPhoneInput.value = loyaltyCardNo || phone;
        }
        window.lookupPOSCustomer(loyaltyCardNo || phone, false);
        window.posCustPillUpdate?.();
        
        const pricingSelect = document.getElementById('pos-pricing-mode');
        if (pricingSelect) {
            pricingSelect.value = type;
            updatePOSPricingMode();
        }

        // Focus product search field
        setTimeout(() => {
            const searchEl = document.getElementById('pos-search');
            if (searchEl) {
                searchEl.focus();
                searchEl.select();
            }
        }, 150);
    } catch (err) { console.error(err); }
};

// --- POS Terminal State ---
let posBills = [{ items: [], pricingMode: 'retail', timestamp: Date.now() }];
let activeBillIndex = 0;

window.getPOSBillsDraftKey = () => {
    let storeId = 'default';
    if (typeof window.getStoreId === 'function') {
        const s = window.getStoreId();
        if (s && s !== 'default') storeId = s;
    }
    if (storeId === 'default') {
        const sessStore = sessionStorage.getItem('userStoreId') || sessionStorage.getItem('storeId') || localStorage.getItem('mec_last_store_id');
        if (sessStore) storeId = sessStore;
    }
    return `mec_pos_bills_draft_${storeId}`;
};

let _posDraftSaveTimer = null;
let _inMemoryPosUsageStats = null;
let _posUsageStatsSaveTimer = null;
function recordPOSDocUsage(docId) {
    if (!docId) return;
    if (!_inMemoryPosUsageStats) {
        try {
            _inMemoryPosUsageStats = JSON.parse(localStorage.getItem('posUsageStats') || '{}');
        } catch(e) {
            _inMemoryPosUsageStats = {};
        }
    }
    _inMemoryPosUsageStats[docId] = (_inMemoryPosUsageStats[docId] || 0) + 1;
    if (_posUsageStatsSaveTimer) clearTimeout(_posUsageStatsSaveTimer);
    _posUsageStatsSaveTimer = setTimeout(() => {
        _posUsageStatsSaveTimer = null;
        try {
            localStorage.setItem('posUsageStats', JSON.stringify(_inMemoryPosUsageStats || {}));
        } catch(e) {}
    }, 1000);
}

window.savePOSBillsDraft = (immediate = false) => {
    const doSave = () => {
        try {
            const key = window.getPOSBillsDraftKey();
            const hasData = Array.isArray(posBills) && posBills.some(b => (b.items && b.items.length > 0) || b.customer);
            if (hasData) {
                const payload = JSON.stringify({
                    posBills: posBills,
                    activeBillIndex: activeBillIndex,
                    updatedAt: Date.now()
                });
                localStorage.setItem(key, payload);
                localStorage.setItem('mec_pos_bills_draft_latest', payload);
            } else {
                localStorage.removeItem(key);
                localStorage.removeItem('mec_pos_bills_draft_latest');
            }
        } catch (e) {
            console.warn("[POS] Failed to persist bills draft:", e);
        }
    };

    if (immediate) {
        if (_posDraftSaveTimer) {
            clearTimeout(_posDraftSaveTimer);
            _posDraftSaveTimer = null;
        }
        doSave();
    } else {
        if (_posDraftSaveTimer) clearTimeout(_posDraftSaveTimer);
        _posDraftSaveTimer = setTimeout(() => {
            _posDraftSaveTimer = null;
            doSave();
        }, 300);
    }
};

window.loadPOSBillsDraft = () => {
    try {
        const key = window.getPOSBillsDraftKey();
        let saved = localStorage.getItem(key);
        if (!saved) {
            // Fallback to latest saved draft or default/legacy key
            saved = localStorage.getItem('mec_pos_bills_draft_latest') || localStorage.getItem('mec_pos_bills_draft_default');
        }
        if (!saved) return false;
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.posBills) && parsed.posBills.length > 0) {
            posBills = parsed.posBills;
            activeBillIndex = typeof parsed.activeBillIndex === 'number' && parsed.activeBillIndex < posBills.length ? parsed.activeBillIndex : 0;
            console.log(`[POS] Restored ${posBills.length} drafts from localStorage.`);
            return true;
        }
    } catch (e) {
        console.warn("[POS] Failed to load bills draft:", e);
    }
    return false;
};

window.restorePOSDraftsUI = () => {
    try {
        window.loadPOSBillsDraft();
        const activeBill = posBills[activeBillIndex] || posBills[0];
        if (activeBill) {
            const modeSelect = document.getElementById('pos-pricing-mode');
            if (modeSelect) modeSelect.value = activeBill.pricingMode || 'retail';
        }
        if (typeof renderPOSBill === 'function') {
            renderPOSBill();
        }
        if (typeof window.posCustPillUpdate === 'function') {
            window.posCustPillUpdate();
        }
    } catch (e) {
        console.warn("[POS] Error restoring POS drafts UI:", e);
    }
};

// Initial hydration of POS drafts
window.loadPOSBillsDraft();

Object.defineProperty(window, 'currentPOSCustomer', {
    get() {
        return posBills[activeBillIndex]?.customer || null;
    },
    set(val) {
        if (posBills[activeBillIndex]) {
            posBills[activeBillIndex].customer = val;
            window.savePOSBillsDraft?.();
        }
    },
    configurable: true
});

let currentPendingPOSSale = null;
let currentQtyModalProdId = null;
let posSelectedSearchIndex = -1;
let currentPOSSearchResults = [];

function getActiveBill() {
    return posBills[activeBillIndex];
}

window.addNewPOSBill = () => {
    if (posBills.length >= 5) {
        window.showToast("⚠️ Maximum 5 active bills allowed", "warning");
        return;
    }
    posBills.push({ items: [], pricingMode: 'retail', timestamp: Date.now() });
    activeBillIndex = posBills.length - 1;
    
    // Clear product search input
    const pSearch = document.getElementById('pos-search');
    if (pSearch) pSearch.value = '';
    
    renderPOSBill();
    window.savePOSBillsDraft?.();
    
    // Refresh search results
    if (window.handlePOSSearch) {
        window.handlePOSSearch('');
    }
};

window.switchPOSBill = (idx) => {
    activeBillIndex = idx;
    const modeSelect = document.getElementById('pos-pricing-mode');
    if (modeSelect) modeSelect.value = posBills[activeBillIndex].pricingMode;
    renderPOSBill();
    window.savePOSBillsDraft?.();
    
    // Refresh product catalog search results to reflect the switched bill's pricing mode
    const pSearch = document.getElementById('pos-search');
    if (window.handlePOSSearch) {
        window.handlePOSSearch(pSearch ? pSearch.value : '');
    }
};

window.removePOSBill = (idx, event) => {
    if (event) event.stopPropagation();
    if (posBills.length === 1) {
        posBills[0] = { items: [], pricingMode: 'retail', timestamp: Date.now() };
    } else {
        posBills.splice(idx, 1);
        if (activeBillIndex >= posBills.length) activeBillIndex = posBills.length - 1;
    }
    const modeSelect = document.getElementById('pos-pricing-mode');
    if (modeSelect) modeSelect.value = posBills[activeBillIndex].pricingMode;
    renderPOSBill();
    window.savePOSBillsDraft?.();
};

window.updatePOSPricingMode = () => {
    const modeSelect = document.getElementById('pos-pricing-mode');
    if (!modeSelect) return;
    const requestedMode = modeSelect.value;
    const cust = window.currentPOSCustomer;
    const hasCustomer = cust !== null && cust !== undefined;
    const custType = cust ? (cust.customerType || cust.type || '').toLowerCase() : '';

    let allowedMode = requestedMode;

    if (!hasCustomer) {
        // Rule 1: No customer selected -> cannot change to loyalty or wholesale
        if (requestedMode === 'loyalty' || requestedMode === 'wholesale') {
            window.showToast("⚠️ Select a Customer first to change Pricing Mode!", "warning");
            allowedMode = 'retail';
        }
    } else if (custType.includes('wholesale')) {
        // Rule 3: Wholesale customer -> cannot change to retail or loyalty
        if (requestedMode !== 'wholesale') {
            window.showToast("⚠️ Wholesale customers must remain in Wholesale pricing mode!", "warning");
            allowedMode = 'wholesale';
        }
    } else {
        // Rule 2: Loyalty / Regular customer -> cannot change to wholesale, retail/loyalty allowed
        if (requestedMode === 'wholesale') {
            window.showToast("⚠️ Select a Wholesale Customer to apply Wholesale pricing!", "warning");
            allowedMode = posBills[activeBillIndex].pricingMode === 'wholesale' ? 'loyalty' : posBills[activeBillIndex].pricingMode;
        }
    }

    modeSelect.value = allowedMode;
    posBills[activeBillIndex].pricingMode = allowedMode;
    
    const finalMode = posBills[activeBillIndex].pricingMode;
    posBills[activeBillIndex].items.forEach(item => {
        const product = window.allProducts.find(p => p.docId === item.docId);
        if (product) {
            const { basePrice, discVal, discType } = getPriceByMode(product, finalMode, item.variantIndex);
            item.price = basePrice;
            item.discountVal = discVal;
            item.discountType = discType;
            if (discType === '%') {
                item.discount = Math.round(((basePrice * discVal) / 100) * 100) / 100;
            } else {
                item.discount = discVal;
            }
        }
    });
    renderPOSBill();
    window.savePOSBillsDraft?.();
    // Immediate real-time refresh of product cards grid on POS screen
    const searchVal = document.getElementById('pos-search')?.value || '';
    if (typeof window.handlePOSSearch === 'function') {
        window.handlePOSSearch(searchVal);
    }
};

function getPriceByMode(product, mode, variantIndex) {
    const wholesalePct = parseFloat(window.systemConfig?.wholesaleDiscount) || 0;
    const loyaltyPct = parseFloat(window.systemConfig?.loyaltyDiscount) || 0;
    const minMarginPct = window.systemConfig?.profitMargin !== undefined ? parseFloat(window.systemConfig.profitMargin) : 5;

    let basePrice = 0;
    let wholesalePrice = 0;
    let loyaltyPrice = 0;
    let itemCost = 0;

    if (product.variants && variantIndex !== undefined && product.variants[variantIndex]) {
        const v = product.variants[variantIndex];
        basePrice = parseFloat(v.price || v.sellingPrice) || 0;
        wholesalePrice = parseFloat(v.wholesalePrice) || 0;
        loyaltyPrice = parseFloat(v.loyaltyPrice) || 0;
        itemCost = parseFloat(v.buyingPrice) || parseFloat(v.cost) || 0;
    } else {
        basePrice = parseFloat(product.price || product.sellingPrice) || 0;
        wholesalePrice = parseFloat(product.wholesalePrice) || 0;
        loyaltyPrice = parseFloat(product.loyaltyPrice) || 0;
        itemCost = parseFloat(product.cost || product.buyingPrice) || 0;
    }

    let discVal = 0;
    let discType = 'Rs';

    const cust = window.currentPOSCustomer;
    const custDiscountRate = cust ? parseFloat(cust.discountRate || cust.discount || 0) : 0;
    const custType = cust ? (cust.customerType || cust.type || '').toLowerCase() : '';

    if (mode === 'wholesale') {
        if (wholesalePrice <= 0 && typeof window.calculateDynamicWholesalePrice === 'function') {
            wholesalePrice = window.calculateDynamicWholesalePrice(itemCost, basePrice, product.category);
        }
        if (wholesalePrice > 0 && wholesalePrice < basePrice) {
            discVal = Math.round((basePrice - wholesalePrice) * 100) / 100;
            discType = 'Rs';
        } else if (custDiscountRate > 0) {
            discVal = custDiscountRate;
            discType = '%';
        } else if (wholesalePct > 0) {
            discVal = wholesalePct;
            discType = '%';
        } else {
            discVal = 5;
            discType = '%';
        }
    } else if (mode === 'loyalty') {
        if (loyaltyPrice > 0 && loyaltyPrice < basePrice) {
            discVal = Math.round((basePrice - loyaltyPrice) * 100) / 100;
            discType = 'Rs';
        } else if (custDiscountRate > 0) {
            discVal = custDiscountRate;
            discType = '%';
        } else if (loyaltyPct > 0) {
            discVal = loyaltyPct;
            discType = '%';
        } else {
            discVal = 5;
            discType = '%';
        }
    }

    return { basePrice, discVal, discType };
}

// High-performance POS Catalog Cache
let cachedPOSGroupedItems = null;
let cachedPOSProductsRef = null;
let posSearchDebounceTimer = null;

function getCachedPOSGroupedItems() {
    if (cachedPOSGroupedItems && cachedPOSProductsRef === window.allProducts) {
        return cachedPOSGroupedItems;
    }
    if (!window.allProducts || window.allProducts.length === 0) {
        return [];
    }
    cachedPOSProductsRef = window.allProducts;

    const groupedMap = new Map();
    for (let i = 0; i < window.allProducts.length; i++) {
        const p = window.allProducts[i];
        if (!p || !p.name || !p.name.trim()) continue;
        if (p.mode === 'Warehouse' || p.mode === 'Technical') continue;

        const key = p.name.trim().toLowerCase();
        const docIdentifier = p.docId || p.id;
        const isServiceItem = p.mode === 'Service' || p.mode === 'Technical' || p.mode === 'POS' || p.category === 'Service' ||
            /photocopy|photo copy|print|laminat|binding|typing|repair|service|copy|cv|scan|type|seting/i.test(p.name);

        const variants = p.variants || [];
        const activeVariants = [];
        let totalStock = 0;

        for (let vIdx = 0; vIdx < variants.length; vIdx++) {
            const v = variants[vIdx];
            const stockNum = parseFloat(v.stock || 0);
            if (isServiceItem || stockNum > 0) {
                activeVariants.push({
                    ...v,
                    originalVariantIndex: vIdx,
                    sourceDocId: docIdentifier
                });
                totalStock += stockNum;
            }
        }

        if (activeVariants.length === 0) {
            const baseStock = parseFloat(p.stock || 0);
            if (isServiceItem || baseStock > 0) {
                activeVariants.push({
                    variantId: 'base-' + docIdentifier,
                    variantLabel: 'Base Stock',
                    sellingPrice: p.price || p.sellingPrice || 0,
                    stock: p.stock || 0,
                    sourceDocId: docIdentifier,
                    supplierName: p.supplierName || '',
                    size: p.size || '',
                    color: p.color || '',
                    sku: p.sku || ''
                });
                totalStock += baseStock;
            }
        }

        if (activeVariants.length === 0) continue;

        if (!groupedMap.has(key)) {
            // Pre-calculate searchable tokens once
            const skuTokens = new Set();
            if (p.sku) {
                const s = String(p.sku).toLowerCase().trim();
                skuTokens.add(s);
                if (s.startsWith('sku-')) {
                    const clean = s.replace(/^sku-/, '');
                    if (clean) skuTokens.add(clean);
                }
            }
            for (let v = 0; v < activeVariants.length; v++) {
                if (activeVariants[v].sku) {
                    const vs = String(activeVariants[v].sku).toLowerCase().trim();
                    skuTokens.add(vs);
                    if (vs.startsWith('sku-')) {
                        const clean = vs.replace(/^sku-/, '');
                        if (clean) skuTokens.add(clean);
                    }
                }
            }

            groupedMap.set(key, {
                ...p,
                searchKeyName: key,
                searchSkuTokens: Array.from(skuTokens),
                isServiceItem,
                totalStock,
                allVariants: activeVariants
            });
        } else {
            const existing = groupedMap.get(key);
            existing.totalStock += totalStock;
            existing.allVariants.push(...activeVariants);
            for (let v = 0; v < activeVariants.length; v++) {
                if (activeVariants[v].sku) {
                    const vs = String(activeVariants[v].sku).toLowerCase().trim();
                    if (!existing.searchSkuTokens.includes(vs)) {
                        existing.searchSkuTokens.push(vs);
                    }
                }
            }
        }
    }

    if (!_inMemoryPosUsageStats) {
        try {
            _inMemoryPosUsageStats = JSON.parse(localStorage.getItem('posUsageStats') || '{}');
        } catch(e) {
            _inMemoryPosUsageStats = {};
        }
    }
    const usageStats = _inMemoryPosUsageStats || {};

    cachedPOSGroupedItems = Array.from(groupedMap.values()).sort((a, b) => {
        const usageA = usageStats[a.docId || a.id] || 0;
        const usageB = usageStats[b.docId || b.id] || 0;
        if (usageB !== usageA) return usageB - usageA;
        return a.searchKeyName.localeCompare(b.searchKeyName);
    });

    return cachedPOSGroupedItems;
}

window.handlePOSSearch = (val) => {
    if (posSearchDebounceTimer) {
        clearTimeout(posSearchDebounceTimer);
    }
    const qRaw = typeof val === 'string' ? val : '';
    if (qRaw === '') {
        executePOSSearchRender('');
    } else {
        // 60ms debounce: ultra smooth typing, no main-thread stuttering
        posSearchDebounceTimer = setTimeout(() => {
            requestAnimationFrame(() => {
                executePOSSearchRender(qRaw);
            });
        }, 60);
    }
};

function executePOSSearchRender(val) {
    posSelectedSearchIndex = -1;
    if (window.highlightPOSSearchItem) window.highlightPOSSearchItem();
    const listDiv = document.getElementById('pos-product-list');
    if (!listDiv) return;

    if (!window.allProducts || window.allProducts.length === 0) {
        listDiv.innerHTML = '<div style="color: #64748b; text-align: center; padding: 20px;">Loading catalog...</div>';
        return;
    }

    const q = val.toLowerCase().trim();
    // Only run toSinhala if query is not empty and has characters that can be transliterated
    let sq = "";
    if (q.length >= 2 && window.toSinhala && /[a-z]/i.test(q)) {
        sq = window.toSinhala(val);
    }
    const activeBill = getActiveBill();
    const mode = activeBill ? activeBill.pricingMode : 'retail';

    const catalog = getCachedPOSGroupedItems();
    let displayItems = [];

    // Max 24 items: fits 2-4 rows on screen, avoids DOM rendering freeze
    const MAX_ITEMS = 24;

    if (q === '') {
        displayItems = catalog.slice(0, MAX_ITEMS);
    } else {
        for (let i = 0; i < catalog.length; i++) {
            const p = catalog[i];
            const nameMatch = p.searchKeyName.includes(q) || (sq && p.searchKeyName.includes(sq));
            if (nameMatch) {
                displayItems.push(p);
                if (displayItems.length >= MAX_ITEMS) break;
                continue;
            }
            // Ultra-fast SKU match against pre-indexed tokens
            let skuMatch = false;
            const tokens = p.searchSkuTokens;
            for (let s = 0; s < tokens.length; s++) {
                const tok = tokens[s];
                if (tok === q || tok.includes(q)) {
                    skuMatch = true;
                    break;
                }
            }
            if (skuMatch) {
                displayItems.push(p);
                if (displayItems.length >= MAX_ITEMS) break;
            }
        }
    }

    const itemsToRender = displayItems;
    currentPOSSearchResults = itemsToRender;
    posSelectedSearchIndex = -1;

    const defaultImg = (typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png';

    listDiv.innerHTML = itemsToRender.map((p, idx) => {
        const totalStock = p.totalStock;
        const modePricing = getPriceByMode(p, mode);

        const baseMRP = modePricing.basePrice || 0;
        const discountVal = modePricing.discVal || 0;
        const discountType = modePricing.discType || 'Rs';

        let finalPrice = baseMRP;
        if (discountVal > 0) {
            if (discountType === '%') {
                finalPrice = baseMRP * (1 - discountVal / 100);
            } else {
                finalPrice = Math.max(0, baseMRP - discountVal);
            }
        }

        const displayName = (p.name && p.name.trim()) ? p.name : `[No Name - SKU: ${p.sku || p.docId || '?'}]`;

        let priceHTML = `<div class="price" style="font-weight: 800; font-size: 1.1rem; color: #10b981;">LKR ${finalPrice.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>`;
        if (mode !== 'retail' && discountVal > 0) {
            priceHTML = `
                <div class="price" style="display: flex; flex-direction: column; align-items: flex-start; line-height: 1.2;">
                    <span style="font-size: 0.75rem; color: #94a3b8; text-decoration: line-through;">LKR ${baseMRP.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                    <span style="font-size: 1.15rem; color: #38bdf8; font-weight: 900;">LKR ${finalPrice.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
            `;
        }

        const imgSrc = (p.image && !p.image.includes('/logo.png') && !p.image.includes('zenith_logo')) ? p.image : defaultImg;

        return `
            <div class="pos-v2-item" id="pos-item-${idx}" onclick="window.addToPOSBillByIndex(${idx})">
                <div class="img-box">
                    <img src="${imgSrc}" loading="lazy" decoding="async" onerror="this.src='${defaultImg}';">
                </div>
                <div class="info-box">
                    <span class="name" title="${displayName}">${displayName}</span>
                    ${priceHTML}
                    <div class="stock-badge" style="color:${(p.mode === 'Service' || p.mode === 'Technical' || p.mode === 'POS') ? '#10b981' : (totalStock < 5 ? '#ef4444' : '#94a3b8')}; margin-top: 4px;">
                        ${(p.mode === 'Service' || p.mode === 'Technical' || p.mode === 'POS') ? 'INF' : `Stock: ${totalStock}`}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

window.addToPOSBillByIndex = (idx) => {
    console.log(`[POS Debug] addToPOSBillByIndex triggered for index: ${idx}`);
    const product = (currentPOSSearchResults || [])[idx];
    if (!product) {
        console.error(`[POS Debug] No product found in search results at index ${idx}`);
        return;
    }

    const variants = product.allVariants || [];
    const activeBill = getActiveBill();
    const mode = activeBill.pricingMode;

    if (variants.length > 1) {
        // Show Multi-Variant Selection Modal
        const modal = document.getElementById('pos-variant-selection-modal');
        const nameEl = document.getElementById('variant-selection-product-name');
        const listEl = document.getElementById('variant-options-list');

        if (modal && nameEl && listEl) {
            nameEl.innerText = product.name;
            window.activeVariantIndex = 0; // Reset active index to 0

            const colorMap = {
                'red':'#ef4444','blue':'#3b82f6','black':'#1e293b','green':'#22c55e',
                'yellow':'#eab308','orange':'#f97316','purple':'#a855f7','pink':'#ec4899',
                'white':'#f1f5f9','grey':'#64748b','gray':'#64748b','brown':'#92400e'
            };

            listEl.innerHTML = variants.map((v, vIdx) => {
                const sourceProd = (window.allProducts || []).find(p => (p.docId === v.sourceDocId || p.id === v.sourceDocId)) || product;
                const vOrigIdx = (v.variantId && v.variantId.startsWith('base-')) ? undefined : v.originalVariantIndex;
                const variantPrice = getPriceByMode(sourceProd, mode, vOrigIdx);
                const baseMRP = (typeof variantPrice === 'object' ? (variantPrice.basePrice || 0) : (variantPrice || 0));
                const discVal = (typeof variantPrice === 'object' ? (variantPrice.discVal || 0) : 0);
                const discType = (typeof variantPrice === 'object' ? (variantPrice.discType || 'Rs') : 'Rs');

                let finalPrice = baseMRP;
                if (discVal > 0) {
                    if (discType === '%') {
                        finalPrice = baseMRP * (1 - discVal / 100);
                    } else {
                        finalPrice = Math.max(0, baseMRP - discVal);
                    }
                }

                const colorHex = v.color ? (colorMap[v.color.toLowerCase()] || '#38bdf8') : null;
                const vImg = v.image || sourceProd.image || product.image || '/logo.png';
                
                return `
                    <div class="variant-select-btn" onclick="window.selectVariantAndProceedByIndex(${idx}, ${vIdx})" 
                         style="display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, rgba(30,41,59,0.9), rgba(15,23,42,0.85)); border: 1.5px solid rgba(56,189,248,0.18); border-radius: 14px; padding: 12px 16px; cursor: pointer; transition: all 0.2s; gap: 12px;">
                        
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div style="width: 42px; height: 42px; border-radius: 10px; overflow: hidden; background: #000; border: 1px solid rgba(255,255,255,0.1); flex-shrink: 0;">
                                <img src="${vImg}" onerror="this.src='/logo.png'" style="width:100%; height:100%; object-fit:cover;">
                            </div>
                            <div>
                                <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                                    ${colorHex ? `<span style="display:inline-block; width:12px; height:12px; border-radius:50%; background:${colorHex}; border:1.5px solid white;"></span>` : ''}
                                    <span style="font-weight: 800; color: #f8fafc; font-size: 1rem;">
                                        ${(v.color || v.size) ? `${v.color ? v.color : ''} ${v.size ? `• ${v.size}` : ''}`.trim() : (v.variantLabel || 'Standard')}
                                    </span>
                                </div>
                                <div style="font-size: 0.68rem; color: #64748b; margin-top: 3px; font-family: monospace;">
                                    ${v.sku ? `SKU: ${v.sku}` : ''} ${v.supplierName ? `• ${v.supplierName}` : ''}
                                </div>
                            </div>
                        </div>

                        <div style="text-align: right; flex-shrink: 0;">
                            <div style="color: #38bdf8; font-weight: 900; font-size: 1.15rem; letter-spacing: -0.5px;">
                                LKR ${finalPrice.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                            </div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: ${v.stock > 0 ? '#10b981' : '#ef4444'}; margin-top: 2px;">
                                ${v.stock > 0 ? `Stock: ${v.stock}` : 'Out of stock'}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            
            modal.style.display = 'flex';

            // Blur product search input so typing doesn't enter text into search while selecting variant
            const sInput = document.getElementById('pos-search');
            if (sInput) sInput.blur();

            window.updateVariantHighlight = () => {
                const list = document.getElementById('variant-options-list');
                if (!list) return;
                const items = list.getElementsByClassName('variant-select-btn');
                for (let i = 0; i < items.length; i++) {
                    if (i === window.activeVariantIndex) {
                        items[i].style.background = 'rgba(56, 189, 248, 0.15)';
                        items[i].style.borderColor = '#38bdf8';
                        items[i].style.boxShadow = '0 0 12px rgba(56, 189, 248, 0.3)';
                        items[i].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    } else {
                        items[i].style.background = 'rgba(255, 255, 255, 0.03)';
                        items[i].style.borderColor = 'rgba(255, 255, 255, 0.1)';
                        items[i].style.boxShadow = 'none';
                    }
                }
            };

            window.updateVariantHighlight(); // Run initial highlight
        }
    } else {
        const activeV = (product.allVariants || [])[0];
        const vIdx = (activeV && activeV.variantId && activeV.variantId.startsWith('base-')) ? undefined : (activeV ? activeV.originalVariantIndex : undefined);
        const sourceDocId = (activeV && activeV.sourceDocId) ? activeV.sourceDocId : (product.docId || product.id);
        performAddToPOSBill(sourceDocId, 1, 0, vIdx, 'LKR');
        const sInput = document.getElementById('pos-search');
        if (sInput) {
            sInput.value = '';
            if (window.handlePOSSearch) window.handlePOSSearch('');
        }
    }
};

window.selectVariantAndProceedByIndex = (prodIdx, vIdx) => {
    console.log(`[POS Debug] selectVariantAndProceedByIndex triggered for prodIdx: ${prodIdx}, vIdx: ${vIdx}`);
    const groupedProduct = currentPOSSearchResults[prodIdx];
    const variant = groupedProduct.allVariants[vIdx];
    const sourceDocId = variant.sourceDocId;
    
    console.log(`[POS Debug] variant sourceDocId: ${sourceDocId}, variant:`, JSON.stringify(variant));
    
    if (!sourceDocId) {
        // Fallback: use the grouped product's own docId
        const fallbackId = groupedProduct.docId || groupedProduct.id;
        console.warn(`[POS Debug] sourceDocId missing, falling back to groupedProduct id: ${fallbackId}`);
        const modal = document.getElementById('pos-variant-selection-modal');
        if (modal) modal.style.display = 'none';
        window.openQtyModalForPOS(fallbackId, undefined);
        return;
    }
    
    // Find the original product document
    const originalProduct = window.allProducts.find(p => (p.docId === sourceDocId || p.id === sourceDocId));
    
    // Find the index of this variant in the original product's variants array
    let originalVIdx = (variant.variantId && variant.variantId.startsWith('base-')) ? undefined : variant.originalVariantIndex;
    if (originalVIdx === undefined && originalProduct && originalProduct.variants && variant.variantId && !variant.variantId.startsWith('base-')) {
        originalVIdx = originalProduct.variants.findIndex(v => v.variantId === variant.variantId);
        if (originalVIdx === -1) originalVIdx = undefined;
    }
    
    const modal = document.getElementById('pos-variant-selection-modal');
    if (modal) modal.style.display = 'none';
    
    performAddToPOSBill(sourceDocId, 1, 0, originalVIdx, 'LKR');
    const sInput = document.getElementById('pos-search');
    if (sInput) {
        sInput.value = '';
        if (window.handlePOSSearch) window.handlePOSSearch('');
    }
};

window.addToPOSBill = (docId) => {
    console.log(`[POS Debug] addToPOSBill triggered for docId: ${docId}`);
    const product = (window.allProducts || []).find(p => (p.docId === docId || p.id === docId));
    if (!product) {
        console.error(`[POS Debug] Product not found for docId: ${docId}`);
        return;
    }
    window.openQtyModalForPOS(docId);
};

window.directAddToPOSBill = (docId) => {
    console.log(`[POS Debug] directAddToPOSBill triggered for docId: ${docId}`);
    const product = (window.allProducts || []).find(p => (p.docId === docId || p.id === docId));
    if (!product) {
        console.error(`[POS Debug] Product not found for docId: ${docId}`);
        return;
    }
    
    // Auto-select variant with stock, or fall back to base stock
    let vIdx = undefined;
    if (product.variants && product.variants.length > 0) {
        const firstActiveIdx = product.variants.findIndex(v => parseFloat(v.stock || 0) > 0);
        if (firstActiveIdx !== -1) {
            vIdx = firstActiveIdx;
        } else if (parseFloat(product.stock || 0) > 0) {
            vIdx = undefined;
        } else {
            vIdx = 0;
        }
    }
    
    performAddToPOSBill(docId, 1, 0, vIdx, 'LKR');
};

window.openQtyModalForPOS = (docId, vIdx) => {
    console.log(`[POS Debug] openQtyModalForPOS triggered for docId: ${docId}, vIdx: ${vIdx}`);
    if (!docId) {
        console.error('[POS Debug] openQtyModalForPOS called with no docId!');
        window.showToast('Cannot add item - missing ID. Try searching again.', 'error');
        return;
    }
    const product = (window.allProducts || []).find(p => (p.docId === docId || p.id === docId));
    if (!product) {
        console.error(`[POS Debug] Product not found in openQtyModalForPOS for docId: ${docId}. allProducts count: ${(window.allProducts||[]).length}`);
        window.showToast('Product not found in catalog. Refreshing...', 'warning');
        return;
    }

    currentQtyModalProdId = docId;
    window.currentQtyModalVariantIndex = vIdx; // Store globally for the confirm function
    
    const nameEl = document.getElementById('qty-modal-product-name');
    const qtyInput = document.getElementById('qty-modal-input');
    const discInput = document.getElementById('qty-modal-discount');
    const modal = document.getElementById('pos-item-qty-modal');

    // Display variant name if available
    let displayName = product.name;
    if (vIdx !== undefined && product.variants && product.variants[vIdx]) {
        const v = product.variants[vIdx];
        if (v.variantLabel) displayName += ` [${v.variantLabel}]`;
        else displayName += ` (Batch ${vIdx + 1})`;
    }

    if (nameEl) nameEl.innerText = displayName;
    if (qtyInput) qtyInput.value = 1;
    if (discInput) discInput.value = product.discount || 0;
    
    // Custom Price override for 'Other' product
    const isOther = product.name && product.name.trim().toLowerCase() === 'other';
    const priceWrap = document.getElementById('qty-modal-price-wrap');
    const priceInput = document.getElementById('qty-modal-price-input');
    const qtyWrap = document.getElementById('qty-modal-qty-wrap');
    const discountWrap = document.getElementById('qty-modal-discount-wrap');

    if (qtyWrap) qtyWrap.style.display = isOther ? 'none' : 'block';
    if (discountWrap) discountWrap.style.display = isOther ? 'none' : 'block';

    if (priceWrap && priceInput) {
        if (isOther) {
            priceWrap.style.display = 'block';
            priceInput.value = product.price || 1;
        } else {
            priceWrap.style.display = 'none';
        }
    }

    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => {
            if (isOther && priceInput) {
                priceInput.focus();
                priceInput.select();
            } else {
                const qi = document.getElementById('qty-modal-input');
                if (qi) {
                    qi.focus();
                    qi.select();
                }
            }
        }, 100);
    } else {
        performAddToPOSBill(docId, isOther ? 1 : 1, isOther ? 0 : (product.discount || 0), vIdx);
    }
};


window.confirmPOSItemAdd = () => {
    try {
        console.log(`[POS Debug] confirmPOSItemAdd triggered for docId: ${currentQtyModalProdId}`);
        if (!currentQtyModalProdId) {
            console.warn("[POS Debug] currentQtyModalProdId is missing.");
            window.showToast("System error: Item ID missing. Please search again.", "error");
            return;
        }
        
        const product = (window.allProducts || []).find(p => p.docId === currentQtyModalProdId);
        const isOther = product && product.name && product.name.trim().toLowerCase() === 'other';
        const qty = isOther ? 1 : (parseFloat(document.getElementById('qty-modal-input').value) || 1);
        const discountVal = isOther ? 0 : (parseFloat(document.getElementById('qty-modal-discount').value) || 0);
        const discountTypeEl = document.getElementById('qty-modal-discount-type');
        const discountType = discountTypeEl ? discountTypeEl.value : 'LKR';
        const vIdx = window.currentQtyModalVariantIndex;
        
        const priceInput = document.getElementById('qty-modal-price-input');
        const overridePrice = isOther && priceInput ? parseFloat(priceInput.value) : undefined;
        
        performAddToPOSBill(currentQtyModalProdId, qty, discountVal, vIdx, discountType, overridePrice);
        
        document.getElementById('pos-item-qty-modal').style.display = 'none';
        currentQtyModalProdId = null;
        window.currentQtyModalVariantIndex = undefined;
        
        const sInput = document.getElementById('pos-search');
        if (sInput) {
            sInput.value = '';
            sInput.focus();
            if (window.handlePOSSearch) window.handlePOSSearch('');
        }
    } catch (err) {
        console.error("[POS Debug] Error in confirmPOSItemAdd:", err);
        window.showToast("Error adding item: " + err.message, "error");
    }
};

function performAddToPOSBill(docId, qty, discountVal, variantIndex, discountType = 'LKR', overridePrice = undefined) {
    try {
        console.log(`[POS Debug] performAddToPOSBill started for docId: ${docId}, qty: ${qty}, variantIndex: ${variantIndex}`);
        if (!window.allProducts || window.allProducts.length === 0) {
            console.warn("[POS Debug] window.allProducts is empty or undefined!");
            window.showToast("Catalog is loading, please wait...", "warning");
            return;
        }

        const product = window.allProducts.find(p => p.docId === docId);
        if (!product) {
            console.error(`[POS Debug] Product not found in catalog for docId: ${docId}`);
            return;
        }
        
        recordPOSDocUsage(docId);
        
        const activeBill = getActiveBill();
        const mode = activeBill.pricingMode;
        const isService = product.mode === 'Service' || product.mode === 'Technical';
        let existingItemIdx = -1;
        if (isService) {
            if (activeBill.items.length > 0) {
                const lastItem = activeBill.items[activeBill.items.length - 1];
                if (lastItem.docId === docId && lastItem.variantIndex === variantIndex) {
                    existingItemIdx = activeBill.items.length - 1;
                }
            }
        } else {
            existingItemIdx = activeBill.items.findIndex(i => i.docId === docId && i.variantIndex === variantIndex);
        }
        let requestedQty = qty;
        if (existingItemIdx !== -1) {
            requestedQty += activeBill.items[existingItemIdx].quantity;
        }

        if (product.mode !== 'Service' && product.mode !== 'Technical') {
            let currentStock = 0;
            if (product.variants && variantIndex !== undefined && product.variants[variantIndex]) {
                currentStock = parseFloat(product.variants[variantIndex].stock) || 0;
            } else {
                currentStock = parseFloat(product.stock) || 0;
            }

            if (requestedQty > currentStock) {
                window.showToast(`⚠️ Out of Stock! Only ${currentStock} available.`, "error");
                return;
            }
        }

        let price = 0;
        let autoDiscVal = discountVal;
        let autoDiscType = discountType;

        if (overridePrice !== undefined) {
            price = Math.round((parseFloat(overridePrice) || 0) * 1000) / 1000;
        } else {
            const modePricing = getPriceByMode(product, mode, variantIndex);
            price = modePricing.basePrice;
            if (discountVal === 0 && modePricing.discVal > 0) {
                autoDiscVal = modePricing.discVal;
                autoDiscType = modePricing.discType;
            }
        }

        discountVal = autoDiscVal;
        discountType = autoDiscType;

        let discount = discountVal;
        if (discountType === '%') {
            discount = Math.round(((price * discountVal) / 100) * 1000) / 1000;
        } else {
            discount = Math.round(discountVal * 100) / 100;
        }

        const finalPriceAfterDiscount = Math.round((price - discount) * 1000) / 1000;
        const isOther = product.name && product.name.trim().toLowerCase() === 'other';
        const itemCost = isOther ? 0 : ((product.variants && variantIndex !== undefined && product.variants[variantIndex]) ? 
                        (parseFloat(product.variants[variantIndex].buyingPrice) || parseFloat(product.variants[variantIndex].cost) || 0) : 
                        (parseFloat(product.cost) || 0));
        const itemCostRounded = Math.round(itemCost  * 100) / 100;

        const minMarginPct = window.systemConfig?.profitMargin !== undefined ? parseFloat(window.systemConfig.profitMargin) : 5;
        const minMarginFactor = 1 + (minMarginPct / 100);
        const minPriceAllowed = Math.round((itemCostRounded * minMarginFactor) * 1000) / 1000;

        if (itemCostRounded > 0 && finalPriceAfterDiscount < minPriceAllowed) {
            price = minPriceAllowed;
            discount = 0;
            discountVal = 0;
            window.showToast(`🛡️ PROFIT PROTECTION: Price auto-set to min allowed LKR ${minPriceAllowed.toFixed(2)} (Cost + ${minMarginPct}%)`, "info");
        }

        let existing = -1;
        if (isService) {
            if (activeBill.items.length > 0) {
                const lastItem = activeBill.items[activeBill.items.length - 1];
                if (lastItem.docId === docId && lastItem.variantIndex === variantIndex) {
                    existing = activeBill.items.length - 1;
                }
            }
        } else {
            existing = activeBill.items.findIndex(i => i.docId === docId && i.variantIndex === variantIndex);
        }
        let targetIdx = 0;
        if (existing !== -1) {
            activeBill.items[existing].quantity += qty;
            activeBill.items[existing].discount = discount;
            activeBill.items[existing].discountVal = discountVal;
            activeBill.items[existing].discountType = discountType === 'LKR' ? 'Rs' : discountType;
            activeBill.items[existing].price = price;
            activeBill.items[existing].costPrice = itemCost;
            targetIdx = existing;
        } else {
            activeBill.items.push({ 
                ...product, 
                price: price, 
                quantity: qty, 
                discount: discount,
                discountVal: discountVal,
                discountType: discountType === 'LKR' ? 'Rs' : discountType,
                variantIndex: variantIndex,
                costPrice: itemCost
            });
            targetIdx = activeBill.items.length - 1;
        }
        console.log(`[POS Debug] performAddToPOSBill completed successfully for docId: ${docId}`);
        renderPOSBill();

        // Focus quantity input of newly added/updated item in the bill grid
        setTimeout(() => {
            const qtyInput = document.getElementById(`pos-item-qty-${targetIdx}`);
            if (qtyInput) {
                qtyInput.focus();
                qtyInput.select();
            }
        }, 50);
    } catch (err) {
        console.error("[POS Debug] Error in performAddToPOSBill:", err);
        window.showToast("Error processing item: " + err.message, "error");
    }
}

let isRenderingPOSBill = false;

function renderPOSBill() {
    if (isRenderingPOSBill) return;
    isRenderingPOSBill = true;
    try {
        // Preserve focus and selection range
        const activeEl = document.activeElement;
        const activeId = activeEl ? activeEl.id : null;
        const selectionStart = activeEl ? activeEl.selectionStart : null;
        const selectionEnd = activeEl ? activeEl.selectionEnd : null;

        const tbody = document.getElementById('pos-bill-items');
        if (!tbody) return;

        const activeBill = getActiveBill();
        const currentPOSBill = activeBill.items;

        // Sync customer UI to the current bill's customer
        const phoneEl = document.getElementById('pos-cust-phone');
        const nameDisplay = document.getElementById('pos-cust-name-display');
        const pointsBadge = document.getElementById('pos-cust-points-badge');
        const pointsVal = document.getElementById('pos-cust-points-val');
        if (phoneEl) {
            const customer = activeBill.customer || null;
            if (customer) {
                phoneEl.value = customer.name || customer.phone || '';
                if (nameDisplay) nameDisplay.innerText = customer.name;
                if (pointsBadge && pointsVal) {
                    const pts = customer.loyaltyPoints || 0;
                    pointsVal.innerText = pts.toLocaleString(); 
                    pointsBadge.style.display = 'flex';
                }
            } else {
                phoneEl.value = '';
                if (nameDisplay) nameDisplay.innerText = 'Walk-in Customer';
                if (pointsBadge) pointsBadge.style.display = 'none';
            }
            setTimeout(() => window.posCustPillUpdate?.(), 10);
        }

        // Sync main bill discount inputs based on active bill state
        const discInputField = document.getElementById('pos-bill-discount');
        const discTypeField = document.getElementById('pos-discount-type');
        if (discInputField) {
            discInputField.value = activeBill.billDiscount !== undefined ? activeBill.billDiscount : '0';
        }
        if (discTypeField) {
            discTypeField.value = activeBill.discountType || 'LKR';
        }

        const tabsContainer = document.getElementById('pos-bill-tabs');
        if (tabsContainer) {
            tabsContainer.innerHTML = posBills.map((b, i) => `
                <div class="bill-tab ${i === activeBillIndex ? 'active' : ''}" onclick="switchPOSBill(${i})">
                    <span>Bill ${i + 1} (${b.items.length})</span>
                    <span class="close-tab" onclick="removePOSBill(${i}, event)">&times;</span>
                </div>
            `).join('');
        }

        tbody.innerHTML = currentPOSBill.map((item, idx) => `
            <tr>
                <td style="word-break: break-word;">
                    <div style="font-weight: 800; color: #f8fafc;">${item.name}</div>
                    ${(item.variantIndex !== undefined && item.variants && item.variants[item.variantIndex]) ? 
                        (() => {
                            const v = item.variants[item.variantIndex];
                            const labels = [];
                            if (v.variantLabel) labels.push(v.variantLabel);
                            if (v.size) labels.push(`Size: ${v.size}`);
                            if (v.color) labels.push(`Color: ${v.color}`);
                            return labels.length > 0 ? `<div style="font-size: 0.65rem; color: #38bdf8; font-weight: 800; text-transform: uppercase;">${labels.join(' | ')}</div>` : '';
                        })() : (item.size || item.color) ? 
                        `<div style="font-size: 0.65rem; color: #38bdf8; font-weight: 800; text-transform: uppercase;">${item.size ? `Size: ${item.size}` : ''} ${item.size && item.color ? '|' : ''} ${item.color ? `Color: ${item.color}` : ''}</div>`
                        : ''}
                </td>

                <td style="width: 100px; min-width: 100px; max-width: 100px; text-align:right; font-weight: 800; color: #f8fafc;">${parseFloat(item.price).toFixed(2)}</td>

                <td style="width: 135px; min-width: 135px; max-width: 135px; text-align: center; white-space: nowrap;">
                    <div style="display:inline-flex; align-items:center; gap:5px; background: rgba(0,0,0,0.2); padding: 2px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);">
                        <button class="qty-btn" onclick="updatePOSQty(${idx},-1)" style="width: 28px; height: 28px; border-radius: 8px; border: none; background: rgba(255,255,255,0.05); color: white; cursor: pointer; font-weight: 900; transition: all 0.2s;">-</button>
                        <input type="number" id="pos-item-qty-${idx}" value="${item.quantity}" min="1" 
                               onchange="window.setPOSQty(${idx}, this.value)"
                               onkeydown="if(event.key==='Enter') { event.preventDefault(); window.setPOSQty(${idx}, this.value); setTimeout(() => { const discIn = document.getElementById('pos-item-disc-${idx}'); if(discIn) { discIn.focus(); discIn.select(); } }, 50); }"
                               style="width: 45px; background: transparent; border: none; color: white; text-align: center; font-weight: 900; font-size: 1rem; outline: none; -moz-appearance: textfield;">
                        <button class="qty-btn" onclick="updatePOSQty(${idx},1)" style="width: 28px; height: 28px; border-radius: 8px; border: none; background: rgba(255,255,255,0.05); color: white; cursor: pointer; font-weight: 900; transition: all 0.2s;">+</button>
                    </div>
                </td>
                <td style="width: 110px; min-width: 110px; max-width: 110px; text-align:right; white-space: nowrap;">
                    <div style="display: inline-flex; align-items: center; gap: 4px; background: rgba(0,0,0,0.25); padding: 3px 6px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15);">
                        <input type="number" id="pos-item-disc-${idx}" value="${item.discountVal !== undefined && item.discountVal !== 0 ? item.discountVal : ''}" 
                               onchange="window.setPOSItemDiscount(${idx}, this.value)"
                               onkeydown="if(event.key==='Enter') { event.preventDefault(); setTimeout(() => { const sInput = document.getElementById('pos-search'); if (sInput) { sInput.value = ''; sInput.focus(); if (window.handlePOSSearch) window.handlePOSSearch(''); } }, 50); }"
                               style="width: 40px; background: transparent; border: none; color: white; text-align: center; font-weight: 800; font-size: 0.9rem; outline: none; -moz-appearance: textfield;"
                               placeholder="0">
                        <button onclick="window.togglePOSItemDiscountType(${idx})" 
                                style="background: #38bdf8; border: none; color: #0f172a; font-weight: 900; padding: 2px 5px; border-radius: 4px; font-size: 0.7rem; cursor: pointer; transition: all 0.2s; min-width: 24px; text-transform: uppercase;">
                            ${item.discountType || 'Rs'}
                        </button>
                    </div>
                </td>
                <td style="width: 100px; min-width: 100px; max-width: 100px; text-align:right; font-weight: 900; color: #38bdf8;">${((item.price - (item.discount || 0)) * item.quantity).toFixed(2)}</td>
                <td style="width: 35px; min-width: 35px; max-width: 35px; text-align: center;"><button onclick="removeFromPOSBill(${idx})">×</button></td>
            </tr>
        `).join('');
        calculatePOSTotals();

        const scrollWrap = document.querySelector('.bill-items-table-wrap');
        if (scrollWrap) {
            scrollWrap.scrollTop = scrollWrap.scrollHeight;
        }

        // Restore focus and selection range
        if (activeId) {
            const el = document.getElementById(activeId);
            if (el) {
                el.focus();
                if (selectionStart !== null && selectionEnd !== null && typeof el.setSelectionRange === 'function') {
                    try {
                        el.setSelectionRange(selectionStart, selectionEnd);
                    } catch (e) {}
                }
            }
        }
    } finally {
        isRenderingPOSBill = false;
    }
}
window.renderPOSBill = renderPOSBill;

window.updatePOSQty = (idx, delta) => {
    const activeBill = getActiveBill();
    const item = activeBill.items[idx];

    if (delta > 0 && item.mode !== 'Service' && item.mode !== 'Technical') {
        let currentStock = 0;
        if (item.variants && item.variantIndex !== undefined && item.variants[item.variantIndex]) {
            currentStock = parseFloat(item.variants[item.variantIndex].stock) || 0;
        } else {
            currentStock = parseFloat(item.stock) || 0;
        }
        
        if (item.quantity + delta > currentStock) {
            window.showToast(`⚠️ Out of Stock! Only ${currentStock} available.`, "error");
            return;
        }
    }

    activeBill.items[idx].quantity += delta;
    if (activeBill.items[idx].quantity <= 0) activeBill.items.splice(idx, 1);
    renderPOSBill();
};

window.removeFromPOSBill = (idx) => {
    const activeBill = getActiveBill();
    activeBill.items.splice(idx, 1);
    renderPOSBill();
};

window.setPOSQty = (idx, val) => {
    const activeBill = getActiveBill();
    const item = activeBill.items[idx];
    const newQty = parseFloat(val) || 0.01;

    if (newQty <= 0) {
        removeFromPOSBill(idx);
        return;
    }

    if (item.mode !== 'Service' && item.mode !== 'Technical') {
        let currentStock = 0;
        const product = window.allProducts.find(p => p.docId === item.docId);
        if (product) {
            if (item.variantIndex !== undefined && product.variants && product.variants[item.variantIndex]) {
                currentStock = parseFloat(product.variants[item.variantIndex].stock) || 0;
            } else {
                currentStock = parseFloat(product.stock) || 0;
            }
        }
        
        if (newQty > currentStock) {
            window.showToast(`Out of stock! (Only ${currentStock} available)`, "error");
            renderPOSBill();
            return;
        }
    }

    item.quantity = newQty;
    renderPOSBill();
};

window.setPOSItemDiscount = (idx, val) => {
    const activeBill = getActiveBill();
    const item = activeBill.items[idx];
    if (!item) return;

    const rawVal = parseFloat(val) || 0;
    const type = item.discountType || 'Rs';

    let calculatedDiscount = 0;
    if (type === '%') {
        calculatedDiscount = Math.round(((item.price * rawVal) / 100) * 1000) / 1000;
    } else {
        calculatedDiscount = Math.round(rawVal * 100) / 100;
    }

    // Profit margin check
    const productRef = (window.allProducts || []).find(p => p.docId === item.docId);
    let baseCost = 0;
    if (productRef) {
        if (productRef.variants && item.variantIndex !== undefined && productRef.variants[item.variantIndex]) {
            baseCost = parseFloat(productRef.variants[item.variantIndex].buyingPrice) || parseFloat(productRef.variants[item.variantIndex].cost) || 0;
        } else {
            baseCost = parseFloat(productRef.cost) || 0;
        }
    }
    const baseCostRounded = Math.round(baseCost * 100) / 100;
    const minMarginPct = window.systemConfig?.profitMargin !== undefined ? parseFloat(window.systemConfig.profitMargin) : 5;
    const minMarginFactor = 1 + (minMarginPct / 100);
    const minSafePrice = Math.round((baseCostRounded * minMarginFactor) * 1000) / 1000;

    const finalPrice = Math.round((item.price - calculatedDiscount) * 1000) / 1000;
    if (finalPrice < minSafePrice) {
        window.showToast(`⚠️ Profit Protection Alert! Minimum price for this item is LKR ${minSafePrice.toFixed(2)} (Cost + ${minMarginPct}%). Action Blocked.`, "error");
        renderPOSBill();
        return;
    }

    item.discountVal = rawVal;
    item.discount = calculatedDiscount;
    renderPOSBill();
};

window.togglePOSItemDiscountType = (idx) => {
    const activeBill = getActiveBill();
    const item = activeBill.items[idx];
    if (!item) return;

    const currentType = item.discountType || 'Rs';
    const newType = currentType === 'Rs' ? '%' : 'Rs';
    item.discountType = newType;

    const rawVal = item.discountVal || 0;
    let calculatedDiscount = 0;
    if (newType === '%') {
        calculatedDiscount = Math.round(((item.price * rawVal) / 100) * 1000) / 1000;
    } else {
        calculatedDiscount = Math.round(rawVal * 100) / 100;
    }

    // Profit margin check
    const productRef = (window.allProducts || []).find(p => p.docId === item.docId);
    let baseCost = 0;
    if (productRef) {
        if (productRef.variants && item.variantIndex !== undefined && productRef.variants[item.variantIndex]) {
            baseCost = parseFloat(productRef.variants[item.variantIndex].buyingPrice) || parseFloat(productRef.variants[item.variantIndex].cost) || 0;
        } else {
            baseCost = parseFloat(productRef.cost) || 0;
        }
    }
    const baseCostRounded = Math.round(baseCost * 100) / 100;
    const minMarginPct = window.systemConfig?.profitMargin !== undefined ? parseFloat(window.systemConfig.profitMargin) : 5;
    const minMarginFactor = 1 + (minMarginPct / 100);
    const minSafePrice = Math.round((baseCostRounded * minMarginFactor) * 1000) / 1000;

    const finalPrice = Math.round((item.price - calculatedDiscount) * 1000) / 1000;
    if (finalPrice < minSafePrice) {
        window.showToast(`⚠️ Profit Protection Alert! Minimum price for this item is LKR ${minSafePrice.toFixed(2)} (Cost + ${minMarginPct}%). Action Blocked.`, "error");
        item.discountType = currentType; // revert
        return;
    }

    item.discount = calculatedDiscount;
    renderPOSBill();
};

window.updatePOSItemDiscount = (idx, val) => {
    window.setPOSItemDiscount(idx, val);
};

window.calculatePOSTotals = () => {
    const activeBill = getActiveBill();
    const currentPOSBill = activeBill.items;
    const sub = Math.round(currentPOSBill.reduce((s, i) => s + ((i.price - (i.discount || 0)) * i.quantity), 0) * 1000) / 1000;
    const discInputField = document.getElementById('pos-bill-discount');
    const discInput = discInputField ? parseFloat(discInputField.value) || 0 : 0;
    const discTypeField = document.getElementById('pos-discount-type');
    const discType = discTypeField ? discTypeField.value : 'LKR';

    // Store in active bill state
    activeBill.billDiscount = discInput;
    activeBill.discountType = discType;

    let disc = Math.round(discInput  * 100) / 100;
    if (discType === '%') {
        disc = Math.round(((sub * discInput) / 100) * 1000) / 1000;
    }

    let payable = Math.round(Math.max(0, sub - disc) * 1000) / 1000;



    const subEl = document.getElementById('pos-subtotal');
    const payEl = document.getElementById('pos-payable');
    if (subEl) subEl.innerText = sub.toFixed(2);
    if (payEl) payEl.innerText = payable.toFixed(2);
    
    const itemCountEl = document.getElementById('pos-item-count');
    if (itemCountEl) itemCountEl.innerText = currentPOSBill.length;

    if (typeof window.savePOSBillsDraft === 'function') {
        window.savePOSBillsDraft();
    }
};

window.openPaymentModal = () => {
    try {
        window.isProcessingPOSSale = false;
        window.isSavingPOSSale = false;

        // ── STEP 1: Reset ALL transient state FIRST ──────────────────────────
        // (Must happen before any DOM value changes that could trigger onchange)
        window.appliedLoyaltyPoints = 0;
        window.appliedLoyaltyPointsOnThisBill = 0;
        const redeemInputEarly = document.getElementById('pay-modal-redeem-input');
        if (redeemInputEarly) redeemInputEarly.value = '';
        const tenderElEarly = document.getElementById('pay-modal-tendered');
        if (tenderElEarly) tenderElEarly.value = '';
        const changeElEarly = document.getElementById('pay-modal-change');
        if (changeElEarly) changeElEarly.innerText = '0.00';
        const cashBalElEarly = document.getElementById('pay-modal-cash-balance');
        if (cashBalElEarly) cashBalElEarly.innerText = '0.00';
        const outstandingCheckEarly = document.getElementById('add-outstanding-to-bill');
        if (outstandingCheckEarly) outstandingCheckEarly.checked = false;
        const pointsOptEarly = document.getElementById('pay-modal-points-option-wrap');
        if (pointsOptEarly) pointsOptEarly.style.display = 'block';
        const pointsCheckEarly = document.getElementById('add-balance-to-points');
        if (pointsCheckEarly) pointsCheckEarly.checked = false;
        const pointsValEarly = document.getElementById('points-to-add-val');
        if (pointsValEarly) pointsValEarly.value = '';

        // ── STEP 2: Validate bill has items ──────────────────────────────────
        const activeBill = getActiveBill();
        window.activePOSItems = activeBill.items;
        if (activeBill.items.length === 0) {
            window.showToast("Cannot pay an empty bill!", "error");
            return;
        }

        // ── STEP 3: Sync discount fields (redeemInput is already '0' so safe) 
        const modalType = document.getElementById('pay-modal-discount-type');
        const modalVal = document.getElementById('pay-modal-discount-input');
        const mainType = document.getElementById('pos-discount-type');
        const mainVal = document.getElementById('pos-bill-discount');
        if (modalType && mainType) modalType.value = mainType.value;
        if (modalVal && mainVal) {
            modalVal.value = mainVal.value && parseFloat(mainVal.value) !== 0 ? mainVal.value : '';
        }

        // ── STEP 4: Force-recalculate POS totals (guarantees pos-payable is fresh)
        if (window.calculatePOSTotals) window.calculatePOSTotals();

        // ── STEP 5: Set modal payable display ────────────────────────────────
        const payable = (document.getElementById('pos-payable')?.innerText || '0.00').trim();
        const payModEl = document.getElementById('pay-modal-payable');
        if (payModEl) payModEl.innerText = payable || '0.00';

        // ── STEP 6: Customer-specific UI (outstanding, loyalty points) ───────
        const customer = window.currentPOSCustomer || null;
        const outstandingWrap = document.getElementById('pay-modal-outstanding-wrap');
        const outstandingValEl = document.getElementById('pay-modal-outstanding');
        const mptVal = document.getElementById('pay-modal-available-points');

        if (outstandingWrap) outstandingWrap.style.display = 'block';
        if (customer) {
            const rawOutstanding = window.calculateCustomerOutstanding
                ? window.calculateCustomerOutstanding(customer.docId) : 0;
            const outstanding = parseFloat(rawOutstanding) || 0;
            if (outstandingValEl) outstandingValEl.innerText = outstanding.toFixed(2);
            const pts = parseFloat(customer.loyaltyPoints) || 0;
            if (mptVal) mptVal.innerText = pts.toFixed(2);
        } else {
            if (outstandingValEl) outstandingValEl.innerText = '0.00';
            if (mptVal) mptVal.innerText = '0.00';
        }

        // ── STEP 7: Show modal and run final calculation ──────────────────────
        const posPayModal = document.getElementById('pos-payment-modal');
        if (posPayModal) {
            posPayModal.style.display = 'flex';
            window.calculateModalChange();
            const tenderEl = document.getElementById('pay-modal-tendered');
            setTimeout(() => { if (tenderEl) tenderEl.focus(); }, 100);
        }
    } catch (err) {
        console.error("Error in openPaymentModal:", err);
        alert("openPaymentModal Error: " + err.message + "\n" + err.stack);
    }
};

window.getActiveBill = getActiveBill;

window.calculateModalChange = () => {
    try {
        const tenderEl = document.getElementById('pay-modal-tendered');
        const changeEl = document.getElementById('pay-modal-change');
        const cashBalanceEl = document.getElementById('pay-modal-cash-balance');
        const payEl = document.getElementById('pay-modal-payable');
        const pointsOpt = document.getElementById('pay-modal-points-option-wrap');
        const pointsValEl = document.getElementById('points-to-add-val');
        const pointsCheck = document.getElementById('add-balance-to-points');
        const outstandingCheck = document.getElementById('add-outstanding-to-bill');
        const outstandingValText = document.getElementById('pay-modal-outstanding')?.innerText || "0";
        const outstandingVal = Math.round((parseFloat(outstandingValText) || 0) * 1000) / 1000;

        const redeemInput = document.getElementById('pay-modal-redeem-input');
        const redeemed = Math.round((redeemInput ? parseFloat(redeemInput.value) || 0 : 0) * 1000) / 1000;

        // Base payable from the main POS bill
        const billPayableText = document.getElementById('pos-payable')?.innerText || "0";
        let basePayable = Math.round((parseFloat(billPayableText) || 0) * 1000) / 1000;
        
        // Add outstanding if checked
        if (outstandingCheck && outstandingCheck.checked) {
            basePayable = Math.round((basePayable + outstandingVal) * 1000) / 1000;
        }
        
        // Update the displayed payable in modal
        if (payEl) payEl.innerText = basePayable.toFixed(2);

        const currentPayableAfterRedeem = Math.round(Math.max(0, basePayable - redeemed) * 1000) / 1000;
        
        // UI color update for redemption
        if (redeemed > 0 && payEl) payEl.style.color = '#38bdf8';
        else if (payEl) payEl.style.color = '#4ade80';

        const tendered = Math.round((tenderEl ? parseFloat(tenderEl.value) || 0 : 0) * 1000) / 1000;
        const totalBalance = Math.round(Math.max(0, tendered - currentPayableAfterRedeem) * 1000) / 1000;
        
        if (changeEl) changeEl.innerText = totalBalance.toFixed(2);

        // Check customer selection
        const isCustomerSelected = (document.getElementById('pos-cust-phone')?.value || "").trim() !== "" || !!(window.currentPOSCustomer);
        
        // Redeem Input editable only if customer is selected
        if (redeemInput) {
            redeemInput.disabled = !isCustomerSelected;
            if (!isCustomerSelected) redeemInput.value = '';
        }

        // Deposit to Loyalty Account (Add Change Box) active whenever customer is selected
        if (pointsCheck) {
            pointsCheck.disabled = !isCustomerSelected;
            if (!isCustomerSelected) {
                pointsCheck.checked = false;
            }
        }
        
        if (pointsValEl) {
            pointsValEl.disabled = !isCustomerSelected;
            if (!isCustomerSelected) {
                pointsValEl.value = '';
            }
        }

        // Calculate Cash Balance (Total Balance - Points to Add)
        let pointsToAdd = 0;
        if (isCustomerSelected && (pointsCheck?.checked || (pointsValEl && parseFloat(pointsValEl.value) > 0))) {
            if (pointsCheck) pointsCheck.checked = true;
            pointsToAdd = Math.round((parseFloat(pointsValEl?.value) || 0) * 1000) / 1000;
            if (totalBalance > 0 && pointsToAdd > totalBalance) {
                pointsToAdd = totalBalance;
                if (pointsValEl) pointsValEl.value = pointsToAdd.toFixed(2);
            }
        }
        
        const cashToGive = Math.round(Math.max(0, totalBalance - pointsToAdd) * 1000) / 1000;
        if (cashBalanceEl) cashBalanceEl.innerText = cashToGive.toFixed(2);

        // Calculate Credit/Due Balance
        const creditBalance = Math.round(Math.max(0, currentPayableAfterRedeem - tendered) * 1000) / 1000;
        const creditWrap = document.getElementById('pay-modal-credit-wrap');
        const creditBalanceEl = document.getElementById('pay-modal-credit-balance');
        if (creditWrap && creditBalanceEl) {
            creditBalanceEl.innerText = creditBalance.toFixed(2);
            creditWrap.style.display = 'block';
            if (creditBalance === 0) {
                creditWrap.style.opacity = '0.6';
            } else {
                creditWrap.style.opacity = '1';
            }
        }
    } catch (err) {
        console.error("Error in calculateModalChange:", err);
        alert("calculateModalChange Error: " + err.message + "\n" + err.stack);
    }
};

window.syncPayModalDiscount = () => {
    const modalType = document.getElementById('pay-modal-discount-type');
    const modalVal = document.getElementById('pay-modal-discount-input');
    const mainType = document.getElementById('pos-discount-type');
    const mainVal = document.getElementById('pos-bill-discount');

    if (modalType && mainType) {
        mainType.value = modalType.value;
    }
    if (modalVal && mainVal) {
        mainVal.value = modalVal.value || 0;
    }

    // Recalculate main total
    if (window.calculatePOSTotals) {
        window.calculatePOSTotals();
    }
    // Update payment modal payable & cash balance
    if (window.calculateModalChange) {
        window.calculateModalChange();
    }
};

window.applyModalPoints = () => {
    const redeemInput = document.getElementById('pay-modal-redeem-input');
    const amount = redeemInput ? parseFloat(redeemInput.value) || 0 : 0;
    const available = parseFloat(document.getElementById('pay-modal-available-points').innerText) || 0;

    if (amount > available) {
        alert("You don't have enough points!");
        redeemInput.value = Math.floor(available);
    }
    
    // Set global applied points
    window.appliedLoyaltyPoints = amount;
    window.appliedLoyaltyPointsOnThisBill = amount; // Separate for summary tracking
    
    // Update main POS totals first
    calculatePOSTotals();
    
    // Re-open/Update modal values
    const mainPayable = parseFloat(document.getElementById('pos-payable').innerText) || 0;
    document.getElementById('pay-modal-payable').innerText = mainPayable.toFixed(2);
    
    // Reset redeem input in modal to avoid double application
    redeemInput.value = amount;
    
    window.calculateModalChange();
};

// [v3.12.40] Global POS Receipt ID Sync Function
window.updatePOSReceiptBadge = () => {
    const receiptBadge = document.getElementById('pos-receipt-no');
    if (!receiptBadge) return "";

    const posPrefix = "POS-";
    const currentYear = new Date().getFullYear().toString();
    const yearPrefix = `${posPrefix}${currentYear}-`;
    let nextNum = 1;

    const orders = window.allOrders || [];
    const posOrders = orders.filter(o => {
        const oid = (o.orderId || "").toString().toUpperCase();
        return oid.includes("POS-") || oid.startsWith("R-") || o.isPOS === true;
    });
    
    if (posOrders.length > 0) {
        const numericIds = posOrders
            .map(o => {
                const idStr = (o.orderId || "").toString();
                const parts = idStr.split('-');
                const lastPart = parts[parts.length - 1];
                return parseInt(lastPart) || 0;
            })
            .filter(n => n > 0);
        if (numericIds.length > 0) nextNum = Math.max(...numericIds) + 1;
    }
    
    try {
        const lastUsed = localStorage.getItem('pos_last_used_invoice_num');
        if (lastUsed) {
            const lastUsedNum = parseInt(lastUsed) || 0;
            if (nextNum <= lastUsedNum) {
                nextNum = lastUsedNum + 1;
            }
        }
    } catch (e) {
        console.error("[POS] Error reading last used invoice number:", e);
    }
    
    const nextId = `#${posPrefix}${currentYear}-${nextNum.toString().padStart(6, '0')}`;
    receiptBadge.innerText = nextId;
    return nextId;
};

window.clearPOSBill = () => {
    const activeBill = getActiveBill();
    activeBill.items = [];
    activeBill.pricingMode = 'retail';
    
    const pricingSelect = document.getElementById('pos-pricing-mode');
    if (pricingSelect) {
        pricingSelect.value = 'retail';
    }
    
    renderPOSBill();
    window.savePOSBillsDraft?.();
};

window.showCustomConfirm = (message, title = "Confirm Transaction", icon = "⏳", confirmText = "Confirm", cancelText = "Cancel") => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.7); backdrop-filter:blur(8px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#0f172a; border:1px solid rgba(255,255,255,0.12); border-radius:24px; padding:2.5rem; width:450px; box-shadow:0 30px 60px rgba(0,0,0,0.8); position:relative; transform:scale(0.9); transition:transform 0.2s ease-out; box-sizing:border-box; text-align:center;`;

        let iconBg = "linear-gradient(135deg, #f43f5e, #e11d48)";
        if (icon === "💳") {
            iconBg = "linear-gradient(135deg, #0ea5e9, #0284c7)";
        } else if (icon === "💵") {
            iconBg = "linear-gradient(135deg, #10b981, #059669)";
        } else if (icon === "⏳") {
            iconBg = "linear-gradient(135deg, #f59e0b, #d97706)";
        }

        box.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; gap:16px; margin-bottom:1.5rem;">
                <div style="width:68px; height:68px; background:${iconBg}; border-radius:20px; display:flex; align-items:center; justify-content:center; font-size:2.2rem; box-shadow:0 8px 24px rgba(0,0,0,0.4); animation: pulseSlow 2s infinite;">
                    ${icon}
                </div>
                <div style="font-weight:900; color:white; font-size:1.45rem; margin-top:5px; letter-spacing:0.5px;">${title}</div>
            </div>
            <div style="font-size:1.25rem; color:#e2e8f0; margin-bottom:2.2rem; line-height:1.6; font-weight:600; word-break:break-word; padding: 0 10px;">
                ${message.replace(/\\n/g, '<br>')}
            </div>
            <div style="display:flex; gap:14px;">
                <button id="cust-conf-cancel" style="flex:1; padding:14px; border-radius:14px; background:rgba(255,255,255,0.05); border:2px solid rgba(255,255,255,0.1); color:#94a3b8; font-weight:800; cursor:pointer; font-size:1rem; transition:all 0.2s; outline:none;" onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.color='white';" onmouseout="if(!this.classList.contains('focused-btn')){this.style.background='rgba(255,255,255,0.05)'; this.style.color='#94a3b8';}">${cancelText}</button>
                <button id="cust-conf-ok" style="flex:1.5; padding:14px; border-radius:14px; background:${iconBg}; border:2px solid transparent; color:white; font-weight:900; cursor:pointer; font-size:1.05rem; transition:all 0.2s; box-shadow:0 4px 12px rgba(0,0,0,0.2); outline:none;" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 18px rgba(0,0,0,0.3)';" onmouseout="if(!this.classList.contains('focused-btn')){this.style.transform='none'; this.style.boxShadow='0 4px 12px rgba(0,0,0,0.2)';}">${confirmText}</button>
            </div>
            <style>
                @keyframes pulseSlow {
                    0%, 100% { transform: scale(1); }
                    50% { transform: scale(1.05); }
                }
            </style>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        const btnCancel = box.querySelector('#cust-conf-cancel');
        const btnOk = box.querySelector('#cust-conf-ok');

        let selectedIndex = 1; // 0 for Cancel, 1 for Confirm (Default)

        const updateButtonSelection = () => {
            if (selectedIndex === 1) {
                btnOk.classList.add('focused-btn');
                btnCancel.classList.remove('focused-btn');
                btnOk.style.borderColor = '#ffffff';
                btnOk.style.boxShadow = '0 0 0 3px rgba(255,255,255,0.5), 0 8px 24px rgba(0,0,0,0.4)';
                btnOk.style.transform = 'scale(1.04)';
                btnCancel.style.borderColor = 'rgba(255,255,255,0.1)';
                btnCancel.style.boxShadow = 'none';
                btnCancel.style.background = 'rgba(255,255,255,0.05)';
                btnCancel.style.color = '#94a3b8';
                btnCancel.style.transform = 'scale(1)';
                btnOk.focus();
            } else {
                btnCancel.classList.add('focused-btn');
                btnOk.classList.remove('focused-btn');
                btnCancel.style.borderColor = '#ef4444';
                btnCancel.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.5), 0 8px 24px rgba(0,0,0,0.4)';
                btnCancel.style.background = 'rgba(239, 68, 68, 0.2)';
                btnCancel.style.color = '#ffffff';
                btnCancel.style.transform = 'scale(1.04)';
                btnOk.style.borderColor = 'transparent';
                btnOk.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
                btnOk.style.transform = 'scale(1)';
                btnCancel.focus();
            }
        };

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
            updateButtonSelection();
        });

        btnCancel.addEventListener('click', () => finish(false));
        btnOk.addEventListener('click', () => finish(true));

        btnCancel.addEventListener('focus', () => { selectedIndex = 0; updateButtonSelection(); });
        btnOk.addEventListener('focus', () => { selectedIndex = 1; updateButtonSelection(); });

        const handleKeyDown = (e) => {
            if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                e.stopPropagation();
                selectedIndex = 0; // Cancel
                updateButtonSelection();
            } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                e.stopPropagation();
                selectedIndex = 1; // Confirm
                updateButtonSelection();
            } else if (e.key === 'Tab') {
                e.preventDefault();
                e.stopPropagation();
                selectedIndex = selectedIndex === 1 ? 0 : 1;
                updateButtonSelection();
            } else if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                finish(selectedIndex === 1);
            } else if (e.key === 'Escape') {
                e.preventDefault();
                e.stopPropagation();
                finish(false);
            }
        };
        window.addEventListener('keydown', handleKeyDown, true);

        const finish = (val) => {
            window.removeEventListener('keydown', handleKeyDown, true);
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => {
                overlay.remove();
                resolve(val);
            }, 200);
        };
    });
};

window.processPOSSale = async (method) => {
    if (window.isProcessingPOSSale) {
        console.warn("Already processing a POS sale. Ignoring duplicate trigger.");
        return;
    }
    const activeBill = getActiveBill();
    const currentPOSBill = activeBill.items;
    if (currentPOSBill.length === 0) return;
    
    window.isProcessingPOSSale = true;
    
    if (method === 'Cheque' && !window._confirmedChequeDate) {
        window._chequeModalSource = 'pos';
        window._confirmedChequeDate = null;
        const today = new Date().toISOString().split('T')[0];
        const inp = document.getElementById('cheque-date-input');
        if (inp) inp.value = today;
        
        const posPayModal = document.getElementById('pos-payment-modal');
        if (posPayModal) posPayModal.style.display = 'none';

        const modal = document.getElementById('cheque-date-modal');
        if (modal) modal.style.display = 'flex';
        window.isProcessingPOSSale = false;
        return;
    }
    
    // Use the payable from the MODAL (which might include outstanding)
    const modalPayableEl = document.getElementById('pay-modal-payable');
    let payable = modalPayableEl ? parseFloat(modalPayableEl.innerText) : 0;

    const tenderedInput = document.getElementById('pay-modal-tendered');
    let tenderedAmount = tenderedInput ? (parseFloat(tenderedInput.value) || 0) : 0;

    let surcharge = 0;
    if (method === 'Card') {
        const addSurcharge = await window.showCustomConfirm(
            "Add 2.5% Bank Card Surcharge to this bill?",
            "Card Surcharge",
            "💳",
            "Add Surcharge",
            "Skip Surcharge"
        );
        if (addSurcharge) {
            surcharge = payable * 0.025;
        } else {
            surcharge = 0;
        }
    }
    
    const finalTotal = payable + surcharge;
    const redeemInput = document.getElementById('pay-modal-redeem-input');
    const redeemedAmount = redeemInput ? (parseFloat(redeemInput.value) || 0) : 0;
    const finalTotalAfterRedeem = Math.max(0, finalTotal - redeemedAmount);

    // Auto-set tendered amount for Card, Cheque, Bank Transfer to be fully paid
    if (method === 'Card' || method === 'Cheque' || method === 'Bank Transfer') {
        tenderedAmount = finalTotalAfterRedeem;
        if (tenderedInput) {
            tenderedInput.value = finalTotalAfterRedeem.toFixed(2);
        }
    }

    // Payment validation logic
    let effectiveMethod = method;
    if (tenderedAmount >= finalTotalAfterRedeem) {
        // Full/over payment: Credit is not allowed
        if (method === 'Credit') {
            window.showToast("⚠️ Credit payment is not allowed since the full payment has been paid!", "error");
            window.isProcessingPOSSale = false;
            return;
        }
    } else {
        // Under payment or 0: Only Credit and COD are allowed
        if (method !== 'Credit' && method !== 'COD') {
            window.showToast("⚠️ Less payment amount entered. Only Credit and COD are allowed!", "error");
            window.isProcessingPOSSale = false;
            return;
        }
        effectiveMethod = method;
    }

    // Confirmation for Credit bills
    if (effectiveMethod === 'Credit') {
        const confirmed = await window.showCustomConfirm(
            "Are you sure you want to process this transaction as a Credit bill?",
            "Credit Bill Confirmation",
            "⏳",
            "Confirm Credit Bill",
            "Cancel"
        );
        if (!confirmed) {
            window.isProcessingPOSSale = false;
            return;
        }
    }

    // Retrieve staff identity for transaction logging
    const staffId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Master';
    const staffName = sessionStorage.getItem('userName') || 'Master Admin';

    const invoiceId = window.updatePOSReceiptBadge ? window.updatePOSReceiptBadge().replace('#', '') : `POS-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    
    try {
        const parts = invoiceId.split('-');
        const lastPart = parts[parts.length - 1];
        const num = parseInt(lastPart);
        if (num > 0) {
            localStorage.setItem('pos_last_used_invoice_num', num.toString());
        }
    } catch (e) {
        console.error("[POS] Error saving last used invoice number:", e);
    }
    
    const receiptBadge = document.getElementById('pos-receipt-no');

    // Use the globally stored customer (supports lookup by name, phone, or loyalty card)
    const customer = window.currentPOSCustomer || null;

    if (effectiveMethod === 'Credit' && !customer) {
        window.showToast("⚠️ Customer details required for Credit/Partial bills!", "error");
        document.getElementById('pay-modal-tendered')?.blur();
        document.getElementById('pos-payment-modal').style.display = 'none';
        document.getElementById('pos-cust-phone')?.focus();
        window.isProcessingPOSSale = false;
        return;
    }

    const cashBalanceEl = document.getElementById('pay-modal-cash-balance');
    const finalCashBalance = cashBalanceEl ? cashBalanceEl.innerText : "0.00";
    const balanceBox = document.getElementById('invoice-final-balance');
    if(balanceBox) balanceBox.innerText = finalCashBalance;

    const pointsCheck = document.getElementById('add-balance-to-points');
    const pointsValEl = document.getElementById('points-to-add-val');
    const manualPointsAmount = pointsValEl ? parseFloat(pointsValEl.value) || 0 : 0;
    const addBalanceToPointsFlag = manualPointsAmount > 0 || (pointsCheck ? pointsCheck.checked : false);

    const outstandingCheck = document.getElementById('add-outstanding-to-bill');
    const outstandingIncluded = outstandingCheck ? outstandingCheck.checked : false;
    const outstandingAmount = parseFloat(document.getElementById('pay-modal-outstanding')?.innerText) || 0;

    // Sanitizing items with extra care for undefined values to prevent Firestore crashes

    // Sanitize items with extra care for undefined values
    const cleanedItems = currentPOSBill.map(item => ({
        docId: item.docId || "N/A",
        name: item.name || "Unknown Item",
        price: parseFloat(item.price) || 0,
        costPrice: parseFloat(item.costPrice) || 0,
        quantity: parseFloat(item.quantity) || 0,
        discount: parseFloat(item.discount) || 0,
        variantIndex: item.variantIndex ?? null,
        sku: item.sku || "",
        mode: item.mode || "Retail",
        isReload: item.isReload ?? null,
        reloadDetails: item.reloadDetails ?? null
    }));

    const grossAmount = cleanedItems.reduce((sum, it) => sum + (it.price * it.quantity), 0);
    const itemDiscTotal = cleanedItems.reduce((sum, it) => sum + ((it.discount || 0) * it.quantity), 0);
    const billDiscAmount = Math.max(0, (grossAmount - itemDiscTotal) - payable);
    const combinedTotalDiscount = itemDiscTotal + billDiscAmount;

    // Calculate loyalty points earned on this transaction
    let calculatedEarnedPoints = 0;
    if (customer) {
        const lRate = parseFloat(window.systemConfig?.loyaltyRate) || 500;
        calculatedEarnedPoints = lRate > 0 ? Math.floor((finalTotal || 0) / lRate) : 0;
        if (addBalanceToPointsFlag) calculatedEarnedPoints += (manualPointsAmount || 0);
    }

    currentPendingPOSSale = {
        orderId: invoiceId,
        userName: customer ? customer.name : "Walk-in Customer",
        customerPhone: customer ? customer.phone : "",
        customerId: customer ? customer.docId : null,
        items: cleanedItems,
        total: isNaN(finalTotal) ? 0 : finalTotal,
        baseAmount: payable,
        grossTotal: grossAmount,
        totalDiscount: combinedTotalDiscount,
        itemDiscountTotal: itemDiscTotal,
        billDiscountAmount: billDiscAmount,
        earnedLoyaltyPoints: calculatedEarnedPoints,
        surcharge: surcharge,
        status: (method === 'COD' || method === 'Bank Transfer' || method === 'Cheque') ? "Pending" : "Delivered",
        paymentMethod: effectiveMethod,
        chequeDate: effectiveMethod === 'Cheque' ? window._confirmedChequeDate : null,
        chequeStatus: effectiveMethod === 'Cheque' ? 'pending' : null,
        staffId: staffId,
        staffName: staffName,
        branchId: (() => {
            const tBranch = localStorage.getItem('mec_terminal_branch');
            const uBranch = sessionStorage.getItem('userBranchId');
            if (tBranch && tBranch !== 'All' && tBranch !== 'Global') return tBranch;
            if (uBranch && uBranch !== 'Global' && uBranch !== 'All') return uBranch;
            return 'main';
        })(),
        branch: (() => {
            const bKey = (localStorage.getItem('mec_terminal_branch') && localStorage.getItem('mec_terminal_branch') !== 'All' && localStorage.getItem('mec_terminal_branch') !== 'Global') 
                ? localStorage.getItem('mec_terminal_branch') 
                : (sessionStorage.getItem('userBranchId') && sessionStorage.getItem('userBranchId') !== 'Global' ? sessionStorage.getItem('userBranchId') : 'main');
            const bInfo = typeof window.getBranchInfo === 'function' ? window.getBranchInfo(bKey) : null;
            return bInfo?.branchName || bInfo?.name || 'Main Branch - Horana';
        })(),
        branchName: (() => {
            const bKey = (localStorage.getItem('mec_terminal_branch') && localStorage.getItem('mec_terminal_branch') !== 'All' && localStorage.getItem('mec_terminal_branch') !== 'Global') 
                ? localStorage.getItem('mec_terminal_branch') 
                : (sessionStorage.getItem('userBranchId') && sessionStorage.getItem('userBranchId') !== 'Global' ? sessionStorage.getItem('userBranchId') : 'main');
            const bInfo = typeof window.getBranchInfo === 'function' ? window.getBranchInfo(bKey) : null;
            return bInfo?.branchName || bInfo?.name || 'Main Branch - Horana';
        })(),
        branchAddress: (() => {
            const bKey = (localStorage.getItem('mec_terminal_branch') && localStorage.getItem('mec_terminal_branch') !== 'All' && localStorage.getItem('mec_terminal_branch') !== 'Global') 
                ? localStorage.getItem('mec_terminal_branch') 
                : (sessionStorage.getItem('userBranchId') && sessionStorage.getItem('userBranchId') !== 'Global' ? sessionStorage.getItem('userBranchId') : 'main');
            const bInfo = typeof window.getBranchInfo === 'function' ? window.getBranchInfo(bKey) : null;
            return bInfo?.address || 'No.97, Victoria Park, Rathnapura Road, Munagama, Horana';
        })(),
        branchPhone: (() => {
            const bKey = (localStorage.getItem('mec_terminal_branch') && localStorage.getItem('mec_terminal_branch') !== 'All' && localStorage.getItem('mec_terminal_branch') !== 'Global') 
                ? localStorage.getItem('mec_terminal_branch') 
                : (sessionStorage.getItem('userBranchId') && sessionStorage.getItem('userBranchId') !== 'Global' ? sessionStorage.getItem('userBranchId') : 'main');
            const bInfo = typeof window.getBranchInfo === 'function' ? window.getBranchInfo(bKey) : null;
            return bInfo?.phone || '071 923 3388';
        })(),
        deviceId: (typeof window.getDeviceId === 'function' ? window.getDeviceId() : (localStorage.getItem('mecpos_device_id') || 'default-terminal')),
        deviceName: (typeof window.getCustomDeviceName === 'function' ? window.getCustomDeviceName() : (localStorage.getItem('mecpos_device_custom_name') || 'MEC PC 1')),
        storeId: window.getStoreId(),
        timestamp: serverTimestamp(),
        date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        sourceOrderId: window.posActiveSourceOrderId || null,
        stockDeducted: true,
        isPOS: true,
        outstandingIncluded: outstandingIncluded,
        outstandingAmount: outstandingAmount,
        balanceToPoints: addBalanceToPointsFlag,
        changeAmount: isNaN(manualPointsAmount) ? 0 : manualPointsAmount,
        redeemedAmount: parseFloat(document.getElementById('pay-modal-redeem-input')?.value) || 0,
        tenderedAmount: tenderedAmount,
        cashBalance: parseFloat(document.getElementById('pay-modal-cash-balance')?.innerText) || 0,
        sourceOrderId: window.posActiveSourceOrderId || null
    };
    window.currentPendingPOSSale = currentPendingPOSSale;
    window._confirmedChequeDate = null;
    window._chequeModalSource = null;
    // [v2.5.0] DO NOT clear window.posActiveSourceOrderId here. 
    // It must persist until completeAndSharePOSSale successfully commits the database.

    document.getElementById('pos-payment-modal').style.display = 'none';
    
    if (method === 'COD') {
        const codModal = document.getElementById('pos-cod-modal');
        if (codModal) {
            codModal.style.display = 'flex';
            const input = document.getElementById('pos-cod-charge-input');
            if (input) {
                input.value = '0';
                input.onkeydown = (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        window.confirmPOSCODSale();
                    }
                };
                setTimeout(() => {
                    input.focus();
                    input.select();
                }, 100);
            }
            return;
        }
    }

    if (window.systemConfig?.autoPrint === 'yes') {
        window.completeAndSharePOSSale('Print');
    } else {
        document.getElementById('pos-invoice-modal').style.display = 'flex';
        // [v3.12.35] Keyboard Workflow: Auto-focus skip button
        setTimeout(() => {
            document.getElementById('share-btn-skip')?.focus();
        }, 150);
    }
};

window.confirmPOSCODSale = () => {
    const charge = parseFloat(document.getElementById('pos-cod-charge-input').value) || 0;
    if (window.currentPendingPOSSale) {
        window.currentPendingPOSSale.deliveryPrice = charge;
        window.currentPendingPOSSale.total += charge;
        
        // Update the change/balance display in the invoice modal if needed
        // Since it's COD, change is typically 0 anyway
    }
    document.getElementById('pos-cod-modal').style.display = 'none';
    if (window.systemConfig?.autoPrint === 'yes') {
        window.completeAndSharePOSSale('Print');
    } else {
        document.getElementById('pos-invoice-modal').style.display = 'flex';
        // [v3.12.35] Keyboard Workflow: Auto-focus skip button
        setTimeout(() => {
            document.getElementById('share-btn-skip')?.focus();
        }, 150);
    }
};

window.calculateCustomerOutstanding = (customerId) => {
    if (!window.allOrders || !customerId) return 0;
    const customer = window.allCustomers?.find(c => c.docId === customerId);
    const storeId = window.getStoreId();
    const isMaster = storeId === 'master';
    const cleanCustPhone = (customer && customer.phone) ? customer.phone.replace(/[\s-]/g, "") : "";
    
    let outstandingSum = 0;
    for (let i = 0; i < window.allOrders.length; i++) {
        const o = window.allOrders[i];
        
        if (o.paymentMethod !== 'Credit') continue;
        if (o.status === 'Void' || o.status === 'Cancelled') continue;
        if (!isMaster && o.storeId !== storeId) continue;
        
        let isMatch = false;
        if (o.customerId) {
            isMatch = (o.customerId === customerId);
        } else if (cleanCustPhone !== "") {
            const cleanOrderPhone = (o.phone || "").replace(/[\s-]/g, "");
            isMatch = (cleanCustPhone === cleanOrderPhone);
        }
        
        if (isMatch) {
            outstandingSum += ((o.total || 0) - (o.tenderedAmount || 0));
        }
    }
    
    return outstandingSum;
};

window.currentCreditTab = 'all';

window.setCreditTab = (tab) => {
    window.currentCreditTab = tab;
    document.querySelectorAll('#section-credit .sub-tab').forEach(b => b.classList.remove('active'));
    const activeBtn = document.getElementById(`btn-credit-${tab}`);
    if (activeBtn) activeBtn.classList.add('active');
    
    if (tab === 'reload' && typeof window.loadReloadHistory === 'function') {
        window.loadReloadHistory(); 
    }
    
    window.renderCreditLedgerUI();
};

window.renderCreditLedgerUI = () => {
    const list = document.getElementById('credit-ledger-body');
    const thead = document.getElementById('credit-ledger-head');
    const totalEl = document.getElementById('credit-total-outstanding');
    const totalTitle = document.getElementById('credit-total-title');
    const totalIcon = document.getElementById('credit-total-icon');
    const statBox = document.getElementById('credit-stat-box');
    if (!list || !window.allCustomers) return;

    const searchField = document.getElementById('credit-search-input');
    const searchTerm = searchField ? searchField.value.toLowerCase().trim() : "";
    const storeId = window.getStoreId();

    // ==========================================
    // CASE 1: SETTLED BILLS SUMMARY TAB
    // ==========================================
    if (window.currentCreditTab === 'settled') {
        if (totalTitle) totalTitle.innerText = "Total Settled Credit Collected";
        if (totalIcon) totalIcon.innerText = "💰";
        if (statBox) {
            statBox.className = "stat-box success";
        }

        if (thead) {
            thead.innerHTML = `
                <tr>
                    <th>Invoice / ID</th>
                    <th>Customer Info</th>
                    <th>Items Purchased (Details)</th>
                    <th>Settled Date & Time</th>
                    <th>Method</th>
                    <th style="text-align: right;">Amount Settled</th>
                    <th style="text-align: right;">Action</th>
                </tr>
            `;
        }

        const settledOrders = (window.allOrders || []).filter(o => {
            const isStoreMatch = (o.storeId === storeId || storeId === 'master');
            if (!isStoreMatch) return false;
            if (o.status === 'Void' || o.status === 'Cancelled') return false;
            const isSettled = (o.paymentMethod && o.paymentMethod.includes('Settled')) || o.settledAt || o.partialSettledAt;
            return isSettled;
        });

        const settledReloads = (window.allReloads || []).filter(o => {
            const isStoreMatch = (o.storeId === storeId || storeId === 'master');
            if (!isStoreMatch) return false;
            if (o.status === 'Void') return false;
            return (o.payMode && o.payMode.includes('Settled')) || o.settledAt;
        });

        const customerMap = new Map((window.allCustomers || []).map(c => [c.docId, c]));

        const unifiedSettled = [
            ...settledOrders.map(o => {
                const linkedCust = o.customerId ? customerMap.get(o.customerId) : null;
                const custName = o.customerName || o.userName || linkedCust?.name || 'Walking Customer';
                const custPhone = o.phone || o.customerPhone || linkedCust?.phone || '';
                return {
                    ...o,
                    _type: 'order',
                    _inv: String(o.orderId || o.docId || ''),
                    _custName: custName,
                    _custPhone: custPhone,
                    _amount: (o.tenderedAmount && o.tenderedAmount > 0) ? o.tenderedAmount : (o.total || 0),
                    _method: o.paymentMethod || 'Settled',
                    _settledTime: o.settledTime || (o.settledAt ? (o.settledAt.toDate ? o.settledAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '') : (o.time || '')),
                    _settledDate: o.settledDate || (o.settledAt ? (o.settledAt.toDate ? o.settledAt.toDate().toLocaleDateString('sv-SE') : '') : (o.date || ''))
                };
            }),
            ...settledReloads.map(r => {
                const linkedCust = r.customerId ? customerMap.get(r.customerId) : null;
                const custName = r.customerName || linkedCust?.name || 'Customer';
                const custPhone = r.phone || r.mobile || linkedCust?.phone || '';
                return {
                    ...r,
                    _type: 'reload',
                    _inv: 'REL-' + (r.docId?.substring(0, 7) || 'TXN'),
                    _custName: custName,
                    _custPhone: custPhone,
                    _amount: r.amount || 0,
                    _method: r.payMode || 'Settled',
                    _settledTime: r.settledTime || (r.settledAt ? (r.settledAt.toDate ? r.settledAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '') : (r.time || '')),
                    _settledDate: r.settledDate || (r.settledAt ? (r.settledAt.toDate ? r.settledAt.toDate().toLocaleDateString('sv-SE') : '') : (r.date || ''))
                };
            })
        ];

        // Sort latest settled first
        unifiedSettled.sort((a, b) => {
            const tA = a.settledAt?.seconds || 0;
            const tB = b.settledAt?.seconds || 0;
            if (tA && tB) return tB - tA;
            return (b._settledDate + ' ' + b._settledTime).localeCompare(a._settledDate + ' ' + a._settledTime);
        });

        const cleanSearch = searchTerm.replace(/[\s-]/g, "");
        const filteredSettled = unifiedSettled.filter(item => {
            if (!searchTerm) return true;
            const nameMatch = item._custName && item._custName.toLowerCase().includes(searchTerm);
            const invMatch = item._inv && item._inv.toLowerCase().includes(searchTerm);
            
            // Raw and normalized phone match
            const phoneStr = String(item._custPhone || '');
            const rawPhoneMatch = phoneStr.toLowerCase().includes(searchTerm);
            const cleanPhone = phoneStr.replace(/[\s-]/g, "");
            const normalizedPhoneMatch = cleanSearch && cleanPhone.includes(cleanSearch);

            // Also check if any item name in order matches
            const itemMatch = Array.isArray(item.items) && item.items.some(i => i.name && i.name.toLowerCase().includes(searchTerm));

            return nameMatch || invMatch || rawPhoneMatch || normalizedPhoneMatch || itemMatch;
        });

        const totalSettledSum = filteredSettled.reduce((sum, item) => sum + (Number(item._amount) || 0), 0);
        if (totalEl) totalEl.innerText = `LKR ${totalSettledSum.toFixed(2)}`;

        if (filteredSettled.length === 0) {
            list.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 3rem; color: #94a3b8; font-weight: 600;">No settled credit records found.</td></tr>`;
            return;
        }

        list.innerHTML = filteredSettled.map(item => {
            let itemsPreviewHtml = '';
            if (item._type === 'reload') {
                itemsPreviewHtml = `
                    <div style="font-size: 0.85rem; color: #38bdf8; font-weight: 700;">
                        📱 Mobile Reload / Top-up: <span style="color: #fff;">${item.network || 'Mobile'}</span> (${item.mobile || item.phone || ''})
                    </div>
                `;
            } else if (item.items && item.items.length > 0) {
                const previewRows = item.items.map(i => `
                    <div style="display: flex; justify-content: space-between; gap: 10px; font-size: 0.8rem; border-bottom: 1px dashed rgba(255,255,255,0.06); padding: 2px 0;">
                        <span style="color: #e2e8f0; font-weight: 600;">${i.name || 'Item'} ${i.variant ? '(' + i.variant + ')' : ''}</span>
                        <span style="color: #94a3b8; font-family: monospace; white-space: nowrap;">${i.quantity || 1} x LKR ${(i.price || 0).toFixed(2)} = <strong style="color:#38bdf8;">LKR ${((i.quantity || 1) * (i.price || 0)).toFixed(2)}</strong></span>
                    </div>
                `).join('');
                itemsPreviewHtml = `
                    <div style="max-height: 120px; overflow-y: auto; padding-right: 5px;" class="custom-dark-scrollbar">
                        ${previewRows}
                    </div>
                `;
            } else {
                itemsPreviewHtml = `<span style="color: #64748b; font-size: 0.8rem;">Repair Job / Custom Bill (LKR ${(item.total || 0).toFixed(2)})</span>`;
            }

            const cleanMethod = (item._method || 'Settled').replace(' (Settled)', '');
            const methodBadge = cleanMethod.includes('Cash') 
                ? '<span style="background: rgba(16,185,129,0.15); color: #10b981; padding: 4px 10px; border-radius: 8px; font-size: 0.75rem; font-weight: 800;">💵 Cash</span>'
                : '<span style="background: rgba(14,165,233,0.15); color: #0ea5e9; padding: 4px 10px; border-radius: 8px; font-size: 0.75rem; font-weight: 800;">💳 Bank / Card</span>';

            const dateTimeDisplay = item._settledDate ? `
                <div style="font-weight: 700; color: #f1f5f9; font-size: 0.85rem;">${item._settledDate}</div>
                <div style="font-size: 0.75rem; color: #94a3b8;">${item._settledTime || ''}</div>
            ` : '<span style="color:#64748b;">N/A</span>';

            return `
                <tr>
                    <td>
                        <strong style="color: #38bdf8; font-size: 0.95rem;">#${item._inv}</strong>
                        <div style="font-size: 0.7rem; color: #10b981; font-weight: 700;">✅ Fully Settled</div>
                    </td>
                    <td>
                        <div style="font-weight: 700; color: #fff;">${item._custName}</div>
                        <div style="font-family: monospace; font-size: 0.8rem; color: #94a3b8;">${item._custPhone}</div>
                    </td>
                    <td style="min-width: 250px; max-width: 380px;">
                        ${itemsPreviewHtml}
                    </td>
                    <td>
                        ${dateTimeDisplay}
                    </td>
                    <td>
                        ${methodBadge}
                    </td>
                    <td style="text-align: right; font-weight: 900; color: #10b981; font-size: 1.05rem;">
                        LKR ${Number(item._amount).toFixed(2)}
                    </td>
                    <td style="text-align: right;">
                        ${item._type === 'order' ? `
                            <button onclick="window.viewOrderManagementDetails('${item.docId}')" 
                                class="action-btn" 
                                style="background: rgba(56,189,248,0.15); color: #38bdf8; border: 1px solid rgba(56,189,248,0.3); padding: 7px 12px; border-radius: 10px; font-size: 0.8rem; cursor: pointer; font-weight: 700;">
                                📄 View Bill
                            </button>
                        ` : `
                            <span style="font-size: 0.75rem; color: #64748b;">Reload TXN</span>
                        `}
                    </td>
                </tr>
            `;
        }).join('');
        return;
    }

    // ==========================================
    // CASE 2: ACTIVE CREDIT LEDGER TABS (All / Shop / Repairs / Reloads)
    // ==========================================
    if (totalTitle) totalTitle.innerText = "Total Outstanding (All Customers)";
    if (totalIcon) totalIcon.innerText = "⏳";
    if (statBox) {
        statBox.className = "stat-box warning";
    }

    if (thead) {
        thead.innerHTML = `
            <tr>
                <th>Customer</th>
                <th>Phone</th>
                <th>Total Credit Bills</th>
                <th>Total Outstanding</th>
                <th style="text-align: right;">Actions</th>
            </tr>
        `;
    }

    let targetRecords = [];
    
    if (window.currentCreditTab === 'all') {
        const shopRecs = (window.allOrders || []).filter(o => 
            o.paymentMethod === 'Credit' && 
            !o.repairJobId && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
        const repairRecs = (window.allOrders || []).filter(o => 
            o.paymentMethod === 'Credit' && 
            o.repairJobId && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
        const reloadRecs = (window.allReloads || []).filter(o => 
            o.payMode === 'Credit' && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
        targetRecords = [...shopRecs, ...repairRecs, ...reloadRecs];
    }
    else if (window.currentCreditTab === 'shop') {
        if (!window.allOrders) return;
        targetRecords = window.allOrders.filter(o => 
            o.paymentMethod === 'Credit' && 
            !o.repairJobId && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
    } 
    else if (window.currentCreditTab === 'repair') {
        if (!window.allOrders) return;
        targetRecords = window.allOrders.filter(o => 
            o.paymentMethod === 'Credit' && 
            o.repairJobId && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
    }
    else if (window.currentCreditTab === 'reload') {
        if (!window.allReloads) {
            list.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:2rem; opacity:0.5;">📡 Synchronizing reload data... Please wait</td></tr>`;
            return;
        }
        targetRecords = window.allReloads.filter(o => 
            o.payMode === 'Credit' && 
            o.status !== 'Void' && 
            o.status !== 'Cancelled' &&
            (o.storeId === storeId || storeId === 'master')
        );
    }

    // Pre-calculate target records by Customer ID and Phone for O(1) lookup
    const recordsByCustomerId = new Map();
    const recordsByPhone = new Map();

    targetRecords.forEach(o => {
        if (o.customerId) {
            if (!recordsByCustomerId.has(o.customerId)) recordsByCustomerId.set(o.customerId, []);
            recordsByCustomerId.get(o.customerId).push(o);
        }
        
        // [v3.9.60] Fallback for legacy records: Match by phone number
        if (o.phone) {
            const cleanOrderPhone = o.phone.replace(/[\s-]/g, "");
            if (cleanOrderPhone) {
                if (!recordsByPhone.has(cleanOrderPhone)) recordsByPhone.set(cleanOrderPhone, []);
                recordsByPhone.get(cleanOrderPhone).push(o);
            }
        }
    });

    const customersWithCredit = window.allCustomers.map(c => {
        const myRecords = [];
        
        if (c.docId && recordsByCustomerId.has(c.docId)) {
            myRecords.push(...recordsByCustomerId.get(c.docId));
        }
        
        if (c.phone) {
            const cleanCustPhone = c.phone.replace(/[\s-]/g, "");
            if (cleanCustPhone && recordsByPhone.has(cleanCustPhone)) {
                const existingOrderIds = new Set(myRecords.map(o => o.docId));
                const phoneRecords = recordsByPhone.get(cleanCustPhone);
                for (const pr of phoneRecords) {
                    if (!existingOrderIds.has(pr.docId)) {
                        myRecords.push(pr);
                    }
                }
            }
        }

        // Note: For orders it's o.total, for reloads it's o.amount
        const outstanding = myRecords.reduce((sum, o) => {
            const billTotal = o.total || o.amount || 0;
            const paid = (o.paymentMethod === 'Credit' || o.payMode === 'Credit') ? (o.tenderedAmount || 0) : 0;
            return sum + Math.max(0, billTotal - paid);
        }, 0);
        return { ...c, creditCount: myRecords.length, outstanding };
    }).filter(c => c.outstanding > 0);

    const cleanSearch = searchTerm.replace(/[\s-]/g, "");
    const filtered = customersWithCredit.filter(c => {
        if (!searchTerm) return true;
        const nameMatch = c.name && c.name.toLowerCase().includes(searchTerm);
        const phoneStr = String(c.phone || '');
        const phoneMatch = phoneStr.toLowerCase().includes(searchTerm);
        const cleanPhone = phoneStr.replace(/[\s-]/g, "");
        const normPhoneMatch = cleanSearch && cleanPhone.includes(cleanSearch);
        return nameMatch || phoneMatch || normPhoneMatch;
    });

    let totalAll = filtered.reduce((sum, c) => sum + c.outstanding, 0);
    if (totalEl) totalEl.innerText = `LKR ${totalAll.toFixed(2)}`;

    if (filtered.length === 0) {
        list.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 2.5rem; color: #94a3b8; font-weight: 600;">No active credit customers found.</td></tr>`;
        return;
    }

    list.innerHTML = filtered.map(c => `
        <tr>
            <td style="font-weight:bold;">${c.name}</td>
            <td style="font-family: monospace;">${c.phone}</td>
            <td>${c.creditCount} Bills</td>
            <td style="font-weight:900; color:#e11d48;">LKR ${c.outstanding.toFixed(2)}</td>
            <td style="text-align:right; display: flex; gap: 8px; justify-content: flex-end;">
                <button onclick="window.sendCreditReminder('${c.phone}', '${c.name.replace(/'/g, "\\'")}', ${c.outstanding})" 
                    class="action-btn" 
                    style="background:#10b981; color:white; border:none; padding:8px 15px; border-radius:10px; font-size:0.8rem; cursor:pointer; display: flex; align-items: center; gap: 4px; font-weight: 700;">
                    💬 Remind
                </button>
                <button onclick="window.settleCustomerCredit('${c.docId}', '${c.name.replace(/'/g, "\\'")}', ${c.outstanding})" 
                    class="action-btn" 
                    style="background:#f59e0b; color:white; border:none; padding:8px 15px; border-radius:10px; font-size:0.8rem; cursor:pointer; font-weight: 700;">
                    💰 Settle
                </button>
                <button onclick="window.viewCustomerCreditDetail('${c.docId}')" 
                    class="action-btn" 
                    style="background:#0ea5e9; color:white; border:none; padding:8px 15px; border-radius:10px; font-size:0.8rem; cursor:pointer; font-weight: 700;">
                    📂 Items
                </button>
                <button onclick="window.deleteCustomerCreditRecords('${c.docId}', '${c.name.replace(/'/g, "\\'")}')" 
                    class="action-btn" 
                    style="background:rgba(239, 68, 68, 0.1); color:#ef4444; border:1px solid rgba(239, 68, 68, 0.2); padding:8px 12px; border-radius:10px; font-size:0.8rem; cursor:pointer;"
                    title="Void All Credit Records">
                    🗑️
                </button>
            </td>
        </tr>
    `).join('');
};

window.deleteCustomerCreditRecords = async (cid, name) => {
    const pass = await window.asyncPrompt(`Enter Manager Password to VOID all credit records for ${name}. This action is permanent.`, "Authorization Required");
    if (!pass) return;

    const isMaster = (pass === 'mec123' || pass === 'mecpos123' || pass === 'malindu123');
    const isStaff = (window.allEmployees || []).some(e => e.password === pass && ['Admin', 'Manager', 'SuperAdmin', 'CEO_Admin'].includes(e.role_access));

    if (!isMaster && !isStaff) {
        window.showToast("❌ Unauthorized Access!", "error");
        return;
    }
    
    try {
        window.showToast("🚀 Voiding Credit Records...", "info");
        const batch = writeBatch(db);
        const storeId = window.getStoreId();

        const customer = (window.allCustomers || []).find(c => c.docId === cid);
        const custPhone = customer ? customer.cleanPhone || "" : "";

        const orders = (window.allOrders || []).filter(o => {
            const isStoreMatch = o.storeId === storeId || storeId === 'master';
            if (!isStoreMatch || o.paymentMethod !== 'Credit') return false;
            if (o.customerId) return o.customerId === cid;
            return custPhone !== "" && custPhone === (o.cleanPhone || "");
        });

        const reloads = (window.allReloads || []).filter(o => {
            const isStoreMatch = o.storeId === storeId || storeId === 'master';
            if (!isStoreMatch || o.payMode !== 'Credit') return false;
            if (o.customerId) return o.customerId === cid;
            const cleanOrderPhone = (o.phone || "").replace(/[\s-]/g, ""); // fallback if reloads not cached
            return custPhone !== "" && custPhone === cleanOrderPhone;
        });

        if (orders.length === 0 && reloads.length === 0) {
            window.showToast("No active credit records found to void.", "warning");
            return;
        }

        orders.forEach(o => {
            batch.update(doc(db, 'orders', o.docId), { 
                status: 'Void',
                voidReason: 'Manual Credit Clear (Deleted from Ledger)',
                updatedAt: serverTimestamp()
            });
        });

        reloads.forEach(o => {
            batch.update(doc(db, 'reloads', o.docId), { 
                status: 'Void',
                updatedAt: serverTimestamp()
            });
        });

        batch.update(doc(db, 'customers', cid), { outstanding: 0 });

        await batch.commit();
        window.showToast(`✅ Successfully voided all records for ${name}`, "success");
        if (window.renderCreditLedgerUI) window.renderCreditLedgerUI();
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error voiding records.", "error");
    }
};

// Settlement Summary Modal Helper
window.showSettlementReceiptSummary = (details) => {
    const modalId = 'credit-settlement-receipt-modal';
    let modal = document.getElementById(modalId);
    if (!modal) {
        modal = document.createElement('div');
        modal.id = modalId;
        modal.className = 'admin-modal';
        modal.style.cssText = 'display: none; z-index: 10090; background: rgba(2, 6, 23, 0.85); backdrop-filter: blur(12px); justify-content: center; align-items: center; position: fixed; inset: 0; font-family: "Outfit", sans-serif;';
        document.body.appendChild(modal);
    }

    const billsListHtml = (details.orders || []).map(o => {
        const itemRows = (o.items || []).map(i => `
            <div style="display: flex; justify-content: space-between; font-size: 0.8rem; padding: 2px 0; color: #cbd5e1;">
                <span>• ${i.name || 'Product'} ${i.variant ? '(' + i.variant + ')' : ''} (x${i.quantity || 1})</span>
                <span style="font-family: monospace; font-weight: 600;">LKR ${((i.quantity || 1) * (i.price || 0)).toFixed(2)}</span>
            </div>
        `).join('');

        return `
            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 12px; margin-bottom: 10px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 6px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 6px;">
                    <span style="font-weight: 800; color: #38bdf8;">Invoice #${o.orderId || o.docId}</span>
                    <span style="font-weight: 800; color: #10b981;">LKR ${(o.total || 0).toFixed(2)}</span>
                </div>
                ${itemRows || '<div style="font-size:0.75rem; color:#64748b;">No itemized products (Repair/Direct Charge)</div>'}
            </div>
        `;
    }).join('');

    modal.innerHTML = `
        <div class="modal-content glass-premium" style="max-width: 520px; width: 92%; padding: 25px; border-radius: 24px; background: #0f172a; border: 1px solid rgba(255,255,255,0.12); box-shadow: 0 25px 50px -12px rgba(0,0,0,0.8);">
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 15px; margin-bottom: 18px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 44px; height: 44px; border-radius: 14px; background: rgba(16,185,129,0.15); color: #10b981; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">
                        ✅
                    </div>
                    <div>
                        <h3 style="color: white; margin: 0; font-size: 1.25rem; font-weight: 800;">Settlement Summary</h3>
                        <div style="font-size: 0.8rem; color: #94a3b8;">Credit Account Cleared Successfully</div>
                    </div>
                </div>
                <button onclick="document.getElementById('${modalId}').style.display='none'" style="background: none; border: none; color: white; font-size: 1.8rem; cursor: pointer; opacity: 0.6;">&times;</button>
            </div>

            <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 16px; padding: 14px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Customer</div>
                    <div style="font-weight: 800; color: white; font-size: 1.05rem;">${details.name}</div>
                    <div style="font-size: 0.8rem; color: #38bdf8; font-family: monospace;">${details.phone || 'N/A'}</div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 700;">Amount Settled</div>
                    <div style="font-weight: 900; color: #10b981; font-size: 1.35rem;">LKR ${Number(details.amount).toFixed(2)}</div>
                    <div style="font-size: 0.75rem; color: #e2e8f0; font-weight: 700;">Mode: ${details.method}</div>
                </div>
            </div>

            <div style="font-size: 0.8rem; color: #94a3b8; margin-bottom: 8px; font-weight: 700; display: flex; justify-content: space-between;">
                <span>Settled Invoices & Items:</span>
                <span>${details.date} ${details.time}</span>
            </div>

            <div style="max-height: 240px; overflow-y: auto; padding-right: 4px; margin-bottom: 20px;" class="custom-dark-scrollbar">
                ${billsListHtml || '<div style="text-align:center; color:#64748b; padding:15px;">No detailed shop order records.</div>'}
            </div>

            <div style="display: flex; gap: 10px;">
                <button onclick="document.getElementById('${modalId}').style.display='none'; if (typeof window.exitPOSFullscreen === 'function') window.exitPOSFullscreen(); if (typeof window.showTab === 'function') window.showTab('credit'); if (typeof window.setCreditTab === 'function') window.setCreditTab('settled');" 
                    style="flex: 1; padding: 12px; border-radius: 12px; background: linear-gradient(135deg, #10b981, #059669); color: white; border: none; font-weight: 800; cursor: pointer; font-size: 0.95rem;">
                    📋 View All Settled Bills
                </button>
                <button onclick="document.getElementById('${modalId}').style.display='none';" 
                    style="padding: 12px 20px; border-radius: 12px; background: rgba(255,255,255,0.08); color: #94a3b8; border: 1px solid rgba(255,255,255,0.12); font-weight: 700; cursor: pointer;">
                    Close
                </button>
            </div>
        </div>
    `;

    modal.style.display = 'flex';
};

window.settleCustomerCredit = async (cid, name, amount) => {
    // Select payment method
    const isCash = await window.showCustomConfirm(
        `Settling LKR ${amount.toLocaleString()} for ${name}.\n\nChoose the settlement payment method:`,
        "Settle Credit",
        "💵",
        "💵 Cash Payment",
        "💳 Card/Bank Payment"
    );
    const method = isCash ? "Cash" : "Card/Bank";

    if (method === null) return;

    try {
        window.showToast("🚀 Settling Credit...", "info");
        const batch = writeBatch(db);
        const storeId = window.getStoreId();

        const customer = (window.allCustomers || []).find(c => c.docId === cid);
        const custPhone = customer ? customer.cleanPhone || "" : "";

        const orders = (window.allOrders || []).filter(o => {
            const isStoreMatch = o.storeId === storeId || storeId === 'master';
            if (!isStoreMatch || o.paymentMethod !== 'Credit') return false;
            if (o.customerId) return o.customerId === cid;
            return custPhone !== "" && custPhone === (o.cleanPhone || "");
        });

        const reloads = (window.allReloads || []).filter(o => {
            const isStoreMatch = o.storeId === storeId || storeId === 'master';
            if (!isStoreMatch || o.payMode !== 'Credit') return false;
            if (o.customerId) return o.customerId === cid;
            const cleanOrderPhone = (o.phone || "").replace(/[\s-]/g, "");
            return custPhone !== "" && custPhone === cleanOrderPhone;
        });

        const now = new Date();
        const settledDateStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : now.toLocaleDateString('sv-SE');
        const settledTimeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

        orders.forEach(o => {
            batch.update(doc(db, 'orders', o.docId), { 
                paymentMethod: `${method} (Settled)`,
                status: 'Completed',
                settledAt: serverTimestamp(),
                settledDate: settledDateStr,
                settledTime: settledTimeStr,
                settledMethod: method
            });
            // Also update local object for immediate UI reflection
            o.paymentMethod = `${method} (Settled)`;
            o.status = 'Completed';
            o.settledDate = settledDateStr;
            o.settledTime = settledTimeStr;
            o.settledMethod = method;
        });

        reloads.forEach(o => {
            batch.update(doc(db, 'reloads', o.docId), { 
                payMode: `${method} (Settled)`,
                settledAt: serverTimestamp(),
                settledDate: settledDateStr,
                settledTime: settledTimeStr,
                settledMethod: method
            });
            o.payMode = `${method} (Settled)`;
            o.settledDate = settledDateStr;
            o.settledTime = settledTimeStr;
            o.settledMethod = method;
        });

        batch.update(doc(db, 'customers', cid), { outstanding: 0 });
        if (customer) customer.outstanding = 0;

        await addDoc(collection(db, 'income'), {
            title: `Credit Settlement: ${name}`,
            amount: amount,
            date: settledDateStr,
            branchId: sessionStorage.getItem('userBranchId') || 'Global',
            storeId: storeId,
            method: method,
            timestamp: serverTimestamp()
        });

        await batch.commit();
        window.showToast(`✅ Successfully settled LKR ${amount.toLocaleString()}`, "success");
        if (window.renderCreditLedgerUI) window.renderCreditLedgerUI();

        // Show settlement receipt summary modal
        window.showSettlementReceiptSummary({
            name: name,
            phone: customer?.phone || custPhone || 'N/A',
            amount: amount,
            method: method,
            date: settledDateStr,
            time: settledTimeStr,
            orders: orders
        });
    } catch (err) {
        console.error(err);
        window.showToast("❌ Error settling credit.", "error");
    }
};

window.getRandomReminderMessage = (name, storeName, amount) => {
    const templates = [
        `Halo ${name},\n\nThis is a friendly payment reminder from *${storeName}*.\n\nYour current outstanding balance is *LKR ${amount.toLocaleString()}*.\n\nWe kindly request you to settle this amount. Thank you!`,
        
        `Dear ${name},\n\nWe would like to gently remind you about your outstanding balance of *LKR ${amount.toLocaleString()}* at *${storeName}*.\n\nYour early settlement would be highly appreciated. Thank you!`,
        
        `Hi ${name}!\n\nJust a quick note regarding your outstanding credit balance of *LKR ${amount.toLocaleString()}* with *${storeName}*.\n\nWe kindly request your attention to settle this. Thank you so much!`,
        
        `Respectful reminder from *${storeName}* to ${name}:\n\nYour current outstanding balance stands at *LKR ${amount.toLocaleString()}*.\n\nWe kindly request your cooperation to settle this amount. Thank you!`,
        
        `Hello ${name},\n\nYour outstanding account balance at *${storeName}* is *LKR ${amount.toLocaleString()}*.\n\nPlease arrange to settle this at your earliest convenience. Thank you for your support!`
    ];
    const randomIndex = Math.floor(Math.random() * templates.length);
    return templates[randomIndex];
};

window.sendCreditReminder = async (phone, name, amount) => {
    if (!phone) return window.showToast("No phone number found for this customer.", "error");
    
    let cleanPhone = phone.replace(/\s+/g, '').replace(/-/g, '');
    if (cleanPhone.startsWith('0')) cleanPhone = '94' + cleanPhone.substring(1);
    
    const storeId = window.getStoreId();
    const currentStore = (window.allStores || []).find(s => s.docId === storeId);
    let storeName = currentStore?.name || document.querySelector('.main')?.innerText || "MEC Book Shop";
    
    const message = window.getRandomReminderMessage(name, storeName, amount);
    
    // Custom Choices dialog
    const choice = await new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.7); backdrop-filter:blur(8px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#0f172a; border:1px solid rgba(255,255,255,0.12); border-radius:24px; padding:2.5rem; width:450px; box-shadow:0 30px 60px rgba(0,0,0,0.8); position:relative; transform:scale(0.9); transition:transform 0.2s ease-out; box-sizing:border-box; text-align:center;`;

        box.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; gap:16px; margin-bottom:1.5rem;">
                <div style="width:68px; height:68px; background:linear-gradient(135deg, #0ea5e9, #0284c7); border-radius:20px; display:flex; align-items:center; justify-content:center; font-size:2.2rem; box-shadow:0 8px 24px rgba(0,0,0,0.4);">
                    📲
                </div>
                <div style="font-weight:900; color:white; font-size:1.45rem; margin-top:5px; letter-spacing:0.5px;">Send Debt Reminder</div>
            </div>
            <div style="font-size:1.05rem; color:#e2e8f0; margin-bottom:2.2rem; line-height:1.6; font-weight:600; text-align:left; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.05); padding:15px; border-radius:14px; word-break:break-word; max-height:150px; overflow-y:auto;">
                ${message.replace(/\n/g, '<br>')}
            </div>
            <div style="display:flex; flex-direction:column; gap:10px;">
                <button id="remind-choice-sms" style="padding:14px; border-radius:14px; background:linear-gradient(135deg, #10b981, #059669); border:none; color:white; font-weight:900; cursor:pointer; font-size:1.05rem; transition:all 0.2s; display:flex; align-items:center; justify-content:center; gap:8px;">
                    💬 Send Direct Branded SMS
                </button>
                <button id="remind-choice-wa" style="padding:14px; border-radius:14px; background:linear-gradient(135deg, #25d366, #128c7e); border:none; color:white; font-weight:900; cursor:pointer; font-size:1.05rem; transition:all 0.2s; display:flex; align-items:center; justify-content:center; gap:8px;">
                    🟢 Open in WhatsApp
                </button>
                <button id="remind-choice-cancel" style="padding:12px; border-radius:14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#94a3b8; font-weight:800; cursor:pointer; font-size:1rem; transition:all 0.2s; margin-top:5px;">
                    Cancel
                </button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        setTimeout(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
        }, 10);

        const closeWithResult = (result) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => {
                document.body.removeChild(overlay);
                resolve(result);
            }, 200);
        };

        overlay.querySelector('#remind-choice-sms').onclick = () => closeWithResult('sms');
        overlay.querySelector('#remind-choice-wa').onclick = () => closeWithResult('wa');
        overlay.querySelector('#remind-choice-cancel').onclick = () => closeWithResult(null);
    });

    if (choice === 'sms') {
        if (window.sendDirectSMS) {
            window.showToast("📡 Dispatching Direct SMS reminder...", "info");
            await window.sendDirectSMS(cleanPhone, message);
            window.showToast("✅ SMS reminder sent successfully!", "success");
        } else {
            window.showToast("SMS Service not loaded.", "error");
        }
    } else if (choice === 'wa') {
        if (typeof window.dispatchWhatsApp === 'function') {
            await window.dispatchWhatsApp(cleanPhone, message);
        } else {
            const encodedMsg = encodeURIComponent(message);
            window.open(`https://wa.me/${cleanPhone}/?text=${encodedMsg}`, '_blank');
        }
    }
};

window.viewCustomerCreditDetail = (cid) => {
    const cust = window.allCustomers?.find(c => c.docId === cid);
    if (!cust) return;

    const cleanCustPhone = (cust.phone || "").replace(/[\s-]/g, "").toLowerCase();
    const storeId = window.getStoreId();
    const orders = (window.allOrders || []).filter(o => {
        if (o.status === 'Void') return false;
        if (o.paymentMethod !== 'Credit') return false;
        if (o.storeId !== storeId && storeId !== 'master') return false;
        if (o.customerId === cid) return true;
        const cleanOrderPhone = (o.customerPhone || o.phone || "").replace(/[\s-]/g, "").toLowerCase();
        return cleanCustPhone !== "" && cleanCustPhone === cleanOrderPhone;
    });

    if (orders.length === 0) {
        window.showToast(`No active credit bills found for ${cust.name}`, "warning");
        return;
    }

    if (orders.length === 1) {
        // If only 1 bill, directly show its item details modal
        if (window.viewOrderManagementDetails) {
            window.viewOrderManagementDetails(orders[0].docId);
        }
        return;
    }

    // If multiple credit bills, show a list popup
    const modalId = 'credit-bills-list-modal';
    let modal = document.getElementById(modalId);
    if (!modal) {
        modal = document.createElement('div');
        modal.id = modalId;
        modal.className = 'admin-modal';
        modal.style.cssText = 'display: none; z-index: 10080; background: rgba(2, 6, 23, 0.9); backdrop-filter: blur(10px); justify-content: center; align-items: center; position: fixed; inset: 0;';
        document.body.appendChild(modal);
    }

    const itemsHtml = orders.map(o => {
        const unpaid = Math.max(0, (o.total || 0) - (o.tenderedAmount || 0));
        return `
            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); padding: 16px; border-radius: 16px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: 0.2s;" 
                 onmouseover="this.style.background='rgba(255,255,255,0.06)'" 
                 onmouseout="this.style.background='rgba(255,255,255,0.03)'"
                 onclick="document.getElementById('${modalId}').style.display='none'; window.viewOrderManagementDetails('${o.docId}')">
                <div>
                    <div style="font-weight: 800; color: #38bdf8; font-size: 1rem;">#${o.orderId}</div>
                    <div style="font-size: 0.75rem; color: rgba(255,255,255,0.4); margin-top: 4px;">${o.date || ''} | ${o.time || ''}</div>
                </div>
                <div style="text-align: right;">
                    <div style="font-weight: 800; color: #ef4444; font-size: 1.1rem;">LKR ${unpaid.toFixed(2)}</div>
                    <div style="font-size: 0.7rem; color: rgba(255,255,255,0.5);">Total: LKR ${(o.total || 0).toFixed(2)}</div>
                </div>
            </div>
        `;
    }).join('');

    modal.innerHTML = `
        <div class="modal-content glass-premium" style="max-width: 500px; padding: 25px; border: 1px solid rgba(255,255,255,0.1); border-radius: 24px; position: relative; background: #0f172a; width: 90%;">
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 15px; margin-bottom: 20px;">
                <div>
                    <h3 style="color: white; margin: 0; font-size: 1.25rem; font-weight: 800;">Credit Invoices</h3>
                    <span style="font-size: 0.75rem; color: #38bdf8; font-weight: 800; text-transform: uppercase;">${cust.name}</span>
                </div>
                <button onclick="document.getElementById('${modalId}').style.display='none'" style="background: none; border: none; color: white; font-size: 1.8rem; cursor: pointer; opacity: 0.6; transition: 0.2s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.6'">&times;</button>
            </div>
            <div style="display: flex; flex-direction: column; gap: 10px; max-height: 400px; overflow-y: auto; padding-right: 5px;" class="custom-dark-scrollbar">
                ${itemsHtml}
            </div>
        </div>
    `;

    modal.style.display = 'flex';
};

window.completeAndSharePOSSale = async (shareType) => {
    if (window.isSavingPOSSale) {
        console.warn("Save POS sale already in progress. Ignoring duplicate call.");
        return;
    }
    if (!window.currentPendingPOSSale) {
        window.showToast("No pending sale found to save!", "error");
        return;
    }
    window.isSavingPOSSale = true;
    
    const sale = window.currentPendingPOSSale;
    const invoiceModal = document.getElementById('pos-invoice-modal');

    // [v3.9.48] High-Performance Optimization: Parallel Execution
    if (invoiceModal) invoiceModal.style.display = 'none';
    window.showToast("🚀 Finalizing Sale...", "info");

    try {
        // --- STEP 1: PREPARE DATA ---
        const syncBatch = writeBatch(db);
        let syncReady = false;

        // A. Stock Deduction (Optimized Loop)
        for (const item of sale.items) {
            if (item.docId && item.docId !== 'N/A' && !['Service', 'Technical'].includes(item.mode)) {
                const prodRef = doc(db, 'products', item.docId);
                const latestProd = window.allProducts?.find(p => p.docId === item.docId);
                if (latestProd) {
                    let updateData = {};
                    let variants = latestProd.variants || [];
                    if (variants.length > 0 && item.variantIndex !== undefined && variants[item.variantIndex]) {
                        variants[item.variantIndex].stock = Math.max(0, (parseFloat(variants[item.variantIndex].stock) || 0) - item.quantity);
                        updateData.variants = variants;
                        updateData.stock = variants.reduce((sum, v) => sum + (parseFloat(v.stock) || 0), 0);
                    } else {
                        updateData.stock = Math.max(0, (parseFloat(latestProd.stock) || 0) - item.quantity);
                    }
                    updateData.totalStock = updateData.stock;
                    syncBatch.update(prodRef, updateData);
                    syncReady = true;
                }
            }
        }

        // B. Loyalty & Credit Update
        if (sale.customerId) {
            const customerRef = doc(db, 'customers', sale.customerId);
            const customer = window.allCustomers?.find(c => c.docId === sale.customerId);
            if (customer) {
                let updatePayload = {};
                let newPoints = (customer.loyaltyPoints || 0) - (sale.redeemedAmount || 0);
                const rate = parseFloat(window.systemConfig?.loyaltyRate) || 500;
                let earnedPoints = 0;
                if (sale.earnedLoyaltyPoints !== undefined && sale.earnedLoyaltyPoints !== null) {
                    earnedPoints = sale.earnedLoyaltyPoints;
                } else {
                    earnedPoints = rate > 0 ? Math.floor((sale.total || 0) / rate) : 0;
                    if (sale.balanceToPoints || (sale.changeAmount || 0) > 0) {
                        earnedPoints += (sale.changeAmount || 0);
                    }
                }
                const updatedLoyaltyPoints = Math.max(0, newPoints + earnedPoints);
                updatePayload.loyaltyPoints = updatedLoyaltyPoints;
                customer.loyaltyPoints = updatedLoyaltyPoints;
                
                if (sale.paymentMethod === 'Credit') {
                    // Only add the UNPAID balance to outstanding
                    const unpaidBalance = Math.max(0, (sale.total || 0) - (sale.tenderedAmount || 0));
                    updatePayload.outstanding = (customer.outstanding || 0) + unpaidBalance;
                } else if (sale.outstandingIncluded) {
                    updatePayload.outstanding = Math.max(0, (customer.outstanding || 0) - sale.outstandingAmount);
                    customer.outstanding = updatePayload.outstanding;

                    // Automatically settle prior credit orders in database & local cache
                    const currentStoreId = sale.storeId || window.getStoreId();
                    const custPhone = (customer.phone || sale.customerPhone || "").replace(/[\s-]/g, "");
                    const priorCreditOrders = (window.allOrders || []).filter(o => {
                        const isStoreMatch = o.storeId === currentStoreId || currentStoreId === 'master';
                        if (!isStoreMatch || o.paymentMethod !== 'Credit' || o.repairJobId || o.status === 'Void' || o.status === 'Cancelled') return false;
                        if (o.customerId && o.customerId === sale.customerId) return true;
                        if (custPhone && o.phone) {
                            return o.phone.replace(/[\s-]/g, "") === custPhone;
                        }
                        return false;
                    });

                    priorCreditOrders.sort((a, b) => {
                        const timeA = a.timestamp?.seconds || 0;
                        const timeB = b.timestamp?.seconds || 0;
                        return timeA - timeB;
                    });

                    const now = new Date();
                    const settledDateStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : now.toLocaleDateString('sv-SE');
                    const settledTimeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    let remainingSettle = sale.outstandingAmount || 0;

                    priorCreditOrders.forEach(o => {
                        if (remainingSettle <= 0) return;
                        const orderOwed = Math.max(0, (o.total || 0) - (o.tenderedAmount || 0));
                        if (orderOwed <= 0) return;

                        if (remainingSettle >= orderOwed) {
                            syncBatch.update(doc(db, 'orders', o.docId), {
                                paymentMethod: `${sale.paymentMethod} (Settled)`,
                                tenderedAmount: o.total || 0,
                                status: 'Completed',
                                settledAt: serverTimestamp(),
                                settledDate: settledDateStr,
                                settledTime: settledTimeStr,
                                settledMethod: sale.paymentMethod,
                                settledViaInvoice: sale.orderId
                            });
                            o.paymentMethod = `${sale.paymentMethod} (Settled)`;
                            o.tenderedAmount = o.total || 0;
                            o.status = 'Completed';
                            o.settledDate = settledDateStr;
                            o.settledTime = settledTimeStr;
                            o.settledMethod = sale.paymentMethod;
                            o.settledViaInvoice = sale.orderId;
                            remainingSettle -= orderOwed;
                        } else {
                            const newTendered = (o.tenderedAmount || 0) + remainingSettle;
                            syncBatch.update(doc(db, 'orders', o.docId), {
                                tenderedAmount: newTendered,
                                partialSettledAt: serverTimestamp(),
                                settledDate: settledDateStr,
                                settledTime: settledTimeStr,
                                settledMethod: sale.paymentMethod,
                                settledViaInvoice: sale.orderId
                            });
                            o.tenderedAmount = newTendered;
                            o.settledDate = settledDateStr;
                            o.settledTime = settledTimeStr;
                            o.settledMethod = sale.paymentMethod;
                            o.settledViaInvoice = sale.orderId;
                            remainingSettle = 0;
                        }
                    });
                }
                syncBatch.update(customerRef, updatePayload);
                syncReady = true;
            }
        }

        // C. Web Order Closing
        if (sale.sourceOrderId) {
            const sourceOrder = (window.allOrders || []).find(order => order.docId === sale.sourceOrderId);
            // Once billed and paid at POS, the order is fully Completed
            syncBatch.update(doc(db, 'orders', sale.sourceOrderId), { 
                status: 'Completed', 
                isShopPending: false, 
                processedAtPOS: true,
                processedByPOSInvoice: sale.orderId, 
                processedAt: serverTimestamp()
            });
            syncReady = true;

            // Immediately mutate local cache so renderPOSPendingShopOrders drops it instantly
            if (sourceOrder) {
                sourceOrder.status = 'Completed';
                sourceOrder.isShopPending = false;
                sourceOrder.processedAtPOS = true;
                sourceOrder.processedByPOSInvoice = sale.orderId;
            }
        }

        // --- STEP 2: PARALLEL DISPATCH ---
        const orderDocRef = doc(ordersCol);
        const orderDocId = orderDocRef.id;
        
        const orderData = { ...sale, docId: orderDocId, timestamp: serverTimestamp() };
        sale.docId = orderDocId;
        window.lastSavedPOSOrder = sale;

        setDoc(orderDocRef, orderData).catch(err => {
            console.error("Firestore order save error:", err);
            window.showToast("❌ Order sync failed: " + err.message, "error");
        });
        
        // Sync reloads to Firestore reloads collection if any reload items exist in the sale
        for (const item of sale.items) {
            if (item.isReload && item.reloadDetails) {
                const reloadData = {
                    network: item.reloadDetails.network,
                    phone: item.reloadDetails.phone,
                    amount: item.reloadDetails.amount,
                    baseAmount: item.reloadDetails.amount,
                    surcharge: 0,
                    commission: item.reloadDetails.commission,
                    payMode: sale.paymentMethod === 'Credit' ? 'Credit' : (sale.paymentMethod === 'Card' ? 'Card' : 'Cash'),
                    storeId: sale.storeId || window.getStoreId(),
                    status: 'Completed',
                    timestamp: serverTimestamp(),
                    date: window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE'),
                    staffId: sessionStorage.getItem('userId') || 'Master',
                    staffName: sessionStorage.getItem('userName') || 'Master Admin',
                    customerId: sale.customerId || null,
                    customerName: sale.customerName || "Walk-in Customer",
                    isPOS: true
                };
                const reloadDocRef = doc(collection(db, 'reloads'));
                setDoc(reloadDocRef, reloadData).catch(err => {
                    console.error("Firestore reload save error:", err);
                    window.showToast("❌ Reload sync failed: " + err.message, "error");
                });
            }
        }

        if (syncReady) {
            syncBatch.commit().catch(err => {
                console.error("Sync batch commit error:", err);
                window.showToast("❌ Client sync failed: " + err.message, "error");
            });
        }

        // Fire and forget sound/print while waiting for DB
        setTimeout(() => {
            const posSaveSound = document.getElementById('sound-pos-save');
            if (posSaveSound) { posSaveSound.currentTime = 0; posSaveSound.play().catch(()=>{}); }
            
            if (shareType === 'Print') window.printPOSReceipt?.(sale);
            else if (shareType === 'WhatsApp') window.shareOnWhatsApp?.(sale);
            else if (shareType === 'Graphic') window.openModernInvoice?.(sale.orderId);
            else if (shareType === 'SMS') window.sendSMSBilling?.(sale);
        }, 0);

        window.showToast("✅ Sale Recorded Successfully!", "success");
        window.logAction("POS SALE", `Invoice ${sale.orderId} - LKR ${sale.total}`);
        window.resetPOS();
        window.isSavingPOSSale = false;
    } catch (err) {
        window.isSavingPOSSale = false;
        console.error("Critical POS Save Error:", err);
        window.showToast(`❌ System Error while saving: ${err.message || err}`, "error");
    }
};

window.resetPOS = () => {
    const idxToRemove = activeBillIndex;
    if (posBills.length === 1) {
        posBills[0] = { items: [], pricingMode: 'retail', customer: null, timestamp: Date.now() };
        window.currentPOSCustomer = null;
    } else {
        posBills.splice(idxToRemove, 1);
        if (activeBillIndex >= posBills.length) activeBillIndex = posBills.length - 1;
    }
    
    const activeBill = getActiveBill();
    
    const pricingSelect = document.getElementById('pos-pricing-mode');
    if (pricingSelect) {
        pricingSelect.value = activeBill ? (activeBill.pricingMode || 'retail') : 'retail';
    }

    const cashPaidEl = document.getElementById('pos-cash-paid');
    if(cashPaidEl) cashPaidEl.value = '';
    
    const discEl = document.getElementById('pos-bill-discount');
    if(discEl) discEl.value = '0';
    
    const phoneEl = document.getElementById('pos-cust-phone');
    if(phoneEl) phoneEl.value = '';

    const nameDisplay = document.getElementById('pos-cust-name-display');
    if(nameDisplay) nameDisplay.innerText = 'Walk-in Customer';
    
    const pointsBadge = document.getElementById('pos-cust-points-badge');
    const applyBtn = document.getElementById('pos-apply-points-btn');
    if (pointsBadge) pointsBadge.style.display = 'none';
    window.appliedLoyaltyPoints = 0;
    window.posActiveSourceOrderId = null;
    window.currentPendingPOSSale = null;
    window.isSavingPOSSale = false;
    window.isProcessingPOSSale = false;
    
    // Clear Redemption Fields
    const redeemInput = document.getElementById('pay-modal-redeem-input');
    const mptWrap = document.getElementById('pay-modal-points-redeem-wrap');
    if (redeemInput) redeemInput.value = '';
    if (mptWrap) mptWrap.style.display = 'none';

    const pointsCheck = document.getElementById('add-balance-to-points');
    const pointsValEl = document.getElementById('points-to-add-val');
    if (pointsCheck) pointsCheck.checked = false;
    if (pointsValEl) {
        pointsValEl.value = '0';
        pointsValEl.disabled = true;
    }

    renderPOSBill();
    window.savePOSBillsDraft?.();
    window.handlePOSSearch('');
    window.posCustPillUpdate?.(); // Update customer pill UI state
    
    // [MOD] Focus phone input after reset
    setTimeout(() => {
        const phoneEl = document.getElementById('pos-cust-phone');
        if (phoneEl) {
            phoneEl.focus();
            phoneEl.select();
        }
    }, 500);

    // Refresh web orders panel so completed order card disappears immediately
    setTimeout(() => {
        if (typeof window.renderPOSPendingShopOrders === 'function' && window.allOrders) {
            window.renderPOSPendingShopOrders(window.allOrders);
        }
    }, 600);
};

window.sendSMSBilling = async (passedSale) => {
    const sale = passedSale || window.currentPendingPOSSale || window.lastSavedPOSOrder;
    const phone = sale?.customerPhone || sale?.phone || "";
    if (!sale || !phone) {
        window.showToast("No customer phone number for SMS.", "error");
        return false;
    }

    const billId = sale.orderId || sale.id || "";
    const total = parseFloat(sale.total || sale.grandTotal || 0).toFixed(2);
    const date = sale.date || (sale.createdAt?.seconds ? new Date(sale.createdAt.seconds * 1000).toLocaleDateString('en-GB') : new Date().toLocaleDateString('en-GB'));
    
    const bizName = window.systemConfig?.bizName || 'MEC BOOK SHOP & COMMUNICATION';
    const message = `Thank you for shopping at ${bizName}!\nInvoice: ${billId}\nDate: ${date}\nTotal: LKR ${total}\nView Invoice: mecbookshop.com.lk/invoice.html?id=${billId}\nDownload our Mobile App: mecbookshop.web.lk/download`;

    if (typeof window.dispatchSMS === 'function') {
        const res = await window.dispatchSMS(phone, message);
        return res?.success;
    } else {
        window.showToast("SMS engine not initialized.", "error");
        return false;
    }
};

// Keyboard Shortcuts Listener
window.addEventListener('keydown', (e) => {
    const posSection = document.getElementById('section-pos');
    const isPosMode = document.body.classList.contains('pos-fullscreen-mode') || 
                      (posSection && posSection.style.display !== 'none');
    if (!isPosMode) return;

    // --- ALWAYS Process Function Keys (F1 - F12, End) FIRST, even if focused in an input field! ---
    const shortcuts = {
        'F1': () => window.openQuickCreditSettle(),
        'F2': () => window.showRepairIntake?.(),
        'F3': () => (window.openTodaySalesModal ? window.openTodaySalesModal() : window.showTab('reports')),
        'F4': () => window.showCashierShiftSummary(),
        'F5': () => window.openScanner?.(),
        'F6': () => document.getElementById('pos-search')?.focus(),
        'F7': () => document.getElementById('pos-cust-phone')?.focus(),
        'F8': () => window.openPaymentModal(),
        'F9': () => window.holdCurrentBill(),
        'F10': () => window.openQuickReloadModal?.(),
        'F11': () => window.showHeldBills(),
        'F12': () => window.openQuickExpenseModal?.(),
        'End': () => window.exitPOSFullscreen?.()
    };

    if (shortcuts[e.key]) {
        e.preventDefault();
        e.stopPropagation();
        shortcuts[e.key]();
        return;
    }

    if (e.altKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        e.stopPropagation();
        window.addNewPOSBill?.();
        return;
    }

    if (e.ctrlKey && e.key === 'F11') {
        e.preventDefault();
        e.stopPropagation();
        window.showCashierShiftSummary();
        return;
    }

    // --- If Quick Reload Modal is open, let its dedicated handler in reload.js manage all key events! ---
    const reloadModal = document.getElementById('pos-quick-reload-modal');
    if (reloadModal && reloadModal.style.display !== 'none') {
        return;
    }

    // --- If customer search input is active or customer dropdown is visible, let customer search keydown handle it cleanly! ---
    const activeEl = document.activeElement;
    const custDropdown = document.getElementById('pos-cust-search-dropdown');
    const isCustInput = activeEl && activeEl.id === 'pos-cust-phone';
    const isCustDropdownOpen = custDropdown && custDropdown.style.display !== 'none';
    if (isCustInput || isCustDropdownOpen) {
        return; // Allow direct input keydown listener to execute without interference
    }

    // --- ABSOLUTE ARROW KEY LOCK FOR POS MODE ---
    // Under no circumstances should Arrow keys ever switch sidebar tabs or exit POS!
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.stopPropagation(); // Stop event from reaching system keyboard navigation listener
    }

    // --- Global Escape key handler to close ALL open popup modals & dropdowns ---
    if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        
        // Hide all modal types (admin-modal, modal, modal-overlay, pos-cust-search-dropdown)
        document.querySelectorAll('.admin-modal, .modal, .modal-overlay, [id$="-modal"]').forEach(modal => {
            if (modal.style) modal.style.display = 'none';
        });
        
        const custDropdown = document.getElementById('pos-cust-search-dropdown');
        if (custDropdown) custDropdown.style.display = 'none';

        // Blur active inputs
        if (document.activeElement && document.activeElement.blur) {
            document.activeElement.blur();
        }

        // Reset flags cleanly
        window.isProcessingPOSSale = false;
        window.isSavingPOSSale = false;
        
        currentQtyModalProdId = null;
        window.currentQtyModalVariantIndex = undefined;
        
        // Refocus product search input cleanly
        const sInput = document.getElementById('pos-search');
        if (sInput) { sInput.focus(); }
        return;
    }

    // --- Block all main terminal keyboard navigation when Variant Selection Modal, Quick Reload, or Quick Expense modal is open ---
    const variantModalCheck = document.getElementById('pos-variant-selection-modal');
    if (variantModalCheck && (variantModalCheck.style.display === 'flex' || variantModalCheck.style.display === 'block')) {
        // If variant selection modal is open, let its dedicated handler below process keys and block everything else
    } else {
        const reloadModal = document.getElementById('pos-quick-reload-modal');
        if (reloadModal && reloadModal.style.display !== 'none') {
            return;
        }
        const expenseModal = document.getElementById('pos-quick-expense-modal');
        if (expenseModal && expenseModal.style.display !== 'none') {
            return;
        }
    }

    // --- Block all shortcuts when the Qty/Discount modal is open ---
    const qtyModal = document.getElementById('pos-item-qty-modal');
    if (qtyModal && qtyModal.style.display !== 'none') {
        if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
            e.stopPropagation();
        }
        return; // Block ALL other keys when qty modal is open
    }

    // --- Block all shortcuts and handle keys when the Variant Selection modal is open ---
    const variantModal = document.getElementById('pos-variant-selection-modal');
    if (variantModal && variantModal.style.display === 'flex') {
        const list = document.getElementById('variant-options-list');
        if (list) {
            const items = list.getElementsByClassName('variant-select-btn');
            if (items.length > 0) {
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    e.stopPropagation();
                    window.activeVariantIndex = (window.activeVariantIndex + 1) % items.length;
                    if (typeof window.updateVariantHighlight === 'function') window.updateVariantHighlight();
                    return;
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    e.stopPropagation();
                    window.activeVariantIndex = (window.activeVariantIndex - 1 + items.length) % items.length;
                    if (typeof window.updateVariantHighlight === 'function') window.updateVariantHighlight();
                    return;
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    e.stopPropagation();
                    const activeItem = items[window.activeVariantIndex];
                    if (activeItem) {
                        activeItem.click();
                    }
                    return;
                }
            }
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            variantModal.style.display = 'none';
            const sInput = document.getElementById('pos-search');
            if (sInput) { sInput.value = ''; sInput.focus(); if (window.handlePOSSearch) window.handlePOSSearch(''); }
            return;
        }
        return; // Block ALL other keys when variant selection modal is open
    }

    // --- POS Payment Modal Keyboard Logic ---
    const payModal = document.getElementById('pos-payment-modal');
    if (payModal && payModal.style.display !== 'none') {
        const tenderedInput = document.getElementById('pay-modal-tendered');
        
        // 1. Enter on Tendered Amount -> Focus Cash or Credit Button depending on value
        if (e.key === 'Enter' && document.activeElement === tenderedInput) {
            e.preventDefault();
            e.stopPropagation();
            const val = parseFloat(tenderedInput.value) || 0;
            const modalPayableEl = document.getElementById('pay-modal-payable');
            let payable = modalPayableEl ? parseFloat(modalPayableEl.innerText) : 0;
            if (val >= payable && val > 0) {
                document.getElementById('pay-method-cash')?.focus();
            } else {
                document.getElementById('pay-method-credit')?.focus();
            }
            return;
        }

        // 2. Arrow Navigation between Payment Methods
        const payMethods = ['pay-method-cash', 'pay-method-card', 'pay-method-cheque', 'pay-method-credit', 'pay-method-cod', 'pay-method-bank'];
        const currentPayIdx = payMethods.indexOf(document.activeElement.id);
        
        if (currentPayIdx !== -1) {
            if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                e.stopPropagation();
                let nextIdx = currentPayIdx;
                if (e.key === 'ArrowRight') nextIdx = (currentPayIdx + 1) % payMethods.length;
                if (e.key === 'ArrowLeft') nextIdx = (currentPayIdx - 1 + payMethods.length) % payMethods.length;
                if (e.key === 'ArrowDown') nextIdx = (currentPayIdx + 2) % payMethods.length;
                if (e.key === 'ArrowUp') nextIdx = (currentPayIdx - 2 + payMethods.length) % payMethods.length;
                document.getElementById(payMethods[nextIdx])?.focus();
            }
        }
        
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            payModal.style.display = 'none';
            window.isProcessingPOSSale = false;
            window.isSavingPOSSale = false;
        }
        return; // Prevent global shortcuts while modal is open
    }

    // --- POS Invoice Modal Keyboard Logic ---
    const invoiceModal = document.getElementById('pos-invoice-modal');
    if (invoiceModal && invoiceModal.style.display !== 'none') {
        const shareButtons = ['share-btn-print', 'share-btn-skip', 'share-btn-whatsapp', 'share-btn-sms', 'share-btn-graphic', 'share-btn-jpg', 'share-btn-pdf', 'share-btn-waybill', 'share-btn-reset'];
        const currentShareIdx = shareButtons.indexOf(document.activeElement.id);

        if (currentShareIdx === -1) {
            document.getElementById('share-btn-skip')?.focus();
        } else {
            if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                e.stopPropagation();
                let nextIdx = currentShareIdx;
                if (e.key === 'ArrowRight') nextIdx = (currentShareIdx + 1) % shareButtons.length;
                if (e.key === 'ArrowLeft') nextIdx = (currentShareIdx - 1 + shareButtons.length) % shareButtons.length;
                if (e.key === 'ArrowDown') nextIdx = (currentShareIdx + 3) % shareButtons.length;
                if (e.key === 'ArrowUp') nextIdx = (currentShareIdx - 3 + shareButtons.length) % shareButtons.length;
                document.getElementById(shareButtons[nextIdx])?.focus();
            }
        }
        return;
    }

    // --- Handle Arrow Keys on main POS terminal screen ---
    const isInputActive = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT');
    const searchInput = document.getElementById('pos-search');

    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        
        // If customer search input is active or customer dropdown is visible, let customer search keydown handle it!
        const custDropdown = document.getElementById('pos-cust-search-dropdown');
        const isCustInput = activeEl && activeEl.id === 'pos-cust-phone';
        const isCustDropdownOpen = custDropdown && custDropdown.style.display !== 'none';

        if (isCustInput || isCustDropdownOpen) {
            return;
        }

        // If not in quantity/discount inputs, focus search input and navigate product cards
        if (activeEl && activeEl.id && activeEl.id.startsWith('pos-item-qty-')) {
            // Let cart item qty input handle its internal keydown
            return;
        }
        if (activeEl && activeEl.id && activeEl.id.startsWith('pos-item-disc-')) {
            // Let cart item disc input handle its internal keydown
            return;
        }

        if (searchInput && activeEl !== searchInput) {
            searchInput.focus();
        }

        if (currentPOSSearchResults && currentPOSSearchResults.length > 0) {
            const listDiv = document.getElementById('pos-product-list');
            const cols = listDiv ? (getComputedStyle(listDiv).gridTemplateColumns.split(' ').length || 1) : 1;
            if (e.key === 'ArrowDown') {
                if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
                else posSelectedSearchIndex = Math.min(posSelectedSearchIndex + cols, currentPOSSearchResults.length - 1);
            } else if (e.key === 'ArrowUp') {
                if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
                else posSelectedSearchIndex = Math.max(0, posSelectedSearchIndex - cols);
            } else if (e.key === 'ArrowRight') {
                if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
                else posSelectedSearchIndex = Math.min(posSelectedSearchIndex + 1, currentPOSSearchResults.length - 1);
            } else if (e.key === 'ArrowLeft') {
                if (posSelectedSearchIndex === -1) posSelectedSearchIndex = 0;
                else posSelectedSearchIndex = Math.max(0, posSelectedSearchIndex - 1);
            }
            if (window.highlightPOSSearchItem) window.highlightPOSSearchItem();
        }
        return;
    }

}, true);

// Quick Credit Settle Helper Functions
window.openQuickCreditSettle = () => {
    if (!window.allCustomers || !window.allOrders) {
        window.showToast("Loading customer and order records...", "warning");
        return;
    }

    const storeId = window.getStoreId();
    
    // Filter active shop credit records (only shop, NO repairs)
    const targetRecords = window.allOrders.filter(o => 
        o.paymentMethod === 'Credit' && 
        !o.repairJobId && 
        o.status !== 'Void' && 
        o.status !== 'Cancelled' &&
        (o.storeId === storeId || storeId === 'master')
    );

    // Pre-calculate target records by Customer ID and Phone for O(1) lookup
    const recordsByCustomerId = new Map();
    const recordsByPhone = new Map();

    targetRecords.forEach(o => {
        if (o.customerId) {
            if (!recordsByCustomerId.has(o.customerId)) recordsByCustomerId.set(o.customerId, []);
            recordsByCustomerId.get(o.customerId).push(o);
        }
        
        if (o.phone) {
            const cleanOrderPhone = o.phone.replace(/[\s-]/g, "");
            if (cleanOrderPhone) {
                if (!recordsByPhone.has(cleanOrderPhone)) recordsByPhone.set(cleanOrderPhone, []);
                recordsByPhone.get(cleanOrderPhone).push(o);
            }
        }
    });

    // Compute credit outstanding for each customer dynamically (ONLY shop orders of current store)
    window.qcsCustomers = window.allCustomers.map(c => {
        const myOrders = [];
        
        if (c.docId && recordsByCustomerId.has(c.docId)) {
            myOrders.push(...recordsByCustomerId.get(c.docId));
        }
        
        if (c.phone) {
            const cleanCustPhone = c.phone.replace(/[\s-]/g, "");
            if (cleanCustPhone && recordsByPhone.has(cleanCustPhone)) {
                // Prevent duplicate additions
                const existingOrderIds = new Set(myOrders.map(o => o.docId));
                const phoneRecords = recordsByPhone.get(cleanCustPhone);
                for (const pr of phoneRecords) {
                    if (!existingOrderIds.has(pr.docId)) {
                        myOrders.push(pr);
                    }
                }
            }
        }

        const outstanding = myOrders.reduce((sum, o) => sum + Math.max(0, (o.total || 0) - (o.tenderedAmount || 0)), 0);

        return { ...c, outstanding };
    }).filter(c => c.outstanding > 0);

    // Populate dropdown
    window.renderQcsDropdown(window.qcsCustomers);

    const cashInput = document.getElementById('qcs-cash-received');
    if (cashInput) cashInput.value = '';
    const qcsSearch = document.getElementById('qcs-search');
    if (qcsSearch) qcsSearch.value = '';
    if (typeof window.qcsCalculateChange === 'function') window.qcsCalculateChange();

    // Show modal
    document.getElementById('quick-credit-settle-modal').style.display = 'flex';
};

window.renderQcsDropdown = (customers) => {
    const select = document.getElementById('qcs-customer-select');
    if (!select) return;

    if (customers.length === 0) {
        select.innerHTML = `<option value="">No customers with outstanding credit</option>`;
        document.getElementById('qcs-balance-display').innerText = "LKR 0.00";
        document.getElementById('qcs-cust-phone-display').innerText = "N/A";
        return;
    }

    select.innerHTML = customers.map(c => 
        `<option value="${c.docId}" data-phone="${c.phone}" data-balance="${c.outstanding}">${c.name} (${c.phone})</option>`
    ).join('');

    window.qcsOnSelectCustomer();
};

window.qcsFilterCustomers = (queryText) => {
    const q = queryText.toLowerCase().trim();
    const filtered = window.qcsCustomers.filter(c => 
        c.name.toLowerCase().includes(q) || 
        c.phone.toLowerCase().includes(q)
    );
    window.renderQcsDropdown(filtered);
};

window.qcsOnSelectCustomer = () => {
    const select = document.getElementById('qcs-customer-select');
    if (!select || select.value === "") return;

    const opt = select.options[select.selectedIndex];
    const cid = select.value;
    const phone = opt.getAttribute('data-phone') || 'No Phone';
    const balance = parseFloat(opt.getAttribute('data-balance')) || 0;

    document.getElementById('qcs-cust-phone-display').innerText = phone;
    document.getElementById('qcs-balance-display').innerText = `LKR ${balance.toFixed(2)}`;

    // Calculate earliest bill date and due date for selected customer
    const custPhone = phone.replace(/[\s-]/g, "");
    const storeId = window.getStoreId();
    const customerCreditOrders = (window.allOrders || []).filter(o => {
        const isStoreMatch = o.storeId === storeId || storeId === 'master';
        if (!isStoreMatch || o.paymentMethod !== 'Credit' || o.repairJobId || o.status === 'Void' || o.status === 'Cancelled') return false;
        const unpaid = Math.max(0, (o.total || 0) - (o.tenderedAmount || 0));
        if (unpaid <= 0) return false;
        if (o.customerId && o.customerId === cid) return true;
        if (custPhone && o.phone) {
            return o.phone.replace(/[\s-]/g, "") === custPhone;
        }
        return false;
    });

    // Sort to find the oldest unpaid bill
    customerCreditOrders.sort((a, b) => {
        const tA = a.timestamp?.seconds ? a.timestamp.seconds : (a.date ? new Date(a.date).getTime() / 1000 : 0);
        const tB = b.timestamp?.seconds ? b.timestamp.seconds : (b.date ? new Date(b.date).getTime() / 1000 : 0);
        return tA - tB;
    });

    const billDateEl = document.getElementById('qcs-bill-date-display');
    const dueDateEl = document.getElementById('qcs-due-date-display');

    if (customerCreditOrders.length > 0) {
        const oldestOrder = customerCreditOrders[0];
        let billDateObj = null;
        if (oldestOrder.date) {
            billDateObj = new Date(oldestOrder.date + 'T12:00:00');
        } else if (oldestOrder.timestamp?.seconds) {
            billDateObj = new Date(oldestOrder.timestamp.seconds * 1000);
        }

        if (billDateObj && !isNaN(billDateObj.getTime())) {
            const formattedBillDate = billDateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
            
            // Calculate exact days elapsed since bill date
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const billDay = new Date(billDateObj);
            billDay.setHours(0, 0, 0, 0);

            const diffTime = today.getTime() - billDay.getTime();
            const diffDays = Math.max(0, Math.floor(diffTime / (1000 * 60 * 60 * 24)));

            const daysText = diffDays === 0 ? "Today (0 Days)" : (diffDays === 1 ? "1 Day Ago" : `${diffDays} Days Ago`);

            if (billDateEl) billDateEl.innerText = formattedBillDate;
            if (dueDateEl) {
                dueDateEl.innerText = daysText;
                // Color coding: Green (< 14 days), Yellow (14-30 days), Red (> 30 days)
                if (diffDays > 30) {
                    dueDateEl.style.color = "#ef4444"; // Red for > 30 days
                    dueDateEl.innerText += " ⚠️ (Overdue)";
                } else if (diffDays >= 14) {
                    dueDateEl.style.color = "#fbbf24"; // Yellow
                } else {
                    dueDateEl.style.color = "#10b981"; // Green
                }
            }
        } else {
            if (billDateEl) billDateEl.innerText = oldestOrder.date || "-";
            if (dueDateEl) dueDateEl.innerText = "-";
        }
    } else {
        if (billDateEl) billDateEl.innerText = "-";
        if (dueDateEl) dueDateEl.innerText = "-";
    }
    
    // Set default payment amount to full outstanding balance
    const amountInput = document.getElementById('qcs-amount-input');
    if (amountInput) {
        amountInput.value = balance.toFixed(2);
    }

    const cashInput = document.getElementById('qcs-cash-received');
    if (cashInput) cashInput.value = '';
    window.qcsCalculateChange();
};

window.qcsCalculateChange = () => {
    const amountInput = document.getElementById('qcs-amount-input');
    const cashInput = document.getElementById('qcs-cash-received');
    const changeDisplay = document.getElementById('qcs-change-display');
    
    if (!amountInput || !cashInput || !changeDisplay) return;
    
    const settleAmt = parseFloat(amountInput.value) || 0;
    const cashRec = parseFloat(cashInput.value) || 0;
    
    if (cashRec <= 0) {
        changeDisplay.innerText = "LKR 0.00";
        changeDisplay.style.color = "#f59e0b"; // Default yellow-ish
        return;
    }
    
    const change = cashRec - settleAmt;
    changeDisplay.innerText = `LKR ${Math.max(0, change).toFixed(2)}`;
    
    if (change < 0) {
        changeDisplay.style.color = "#ef4444"; // Red for insufficient
    } else {
        changeDisplay.style.color = "#10b981"; // Green for sufficient
    }
};

window.qcsSetMethod = (method) => {
    document.getElementById('qcs-payment-method').value = method;
    
    const cashBtn = document.getElementById('qcs-method-cash');
    const cardBtn = document.getElementById('qcs-method-card');
    
    if (method === 'Cash') {
        cashBtn.style.border = '1px solid #10b981';
        cashBtn.style.background = 'rgba(16, 185, 129, 0.1)';
        cashBtn.style.color = '#10b981';
        
        cardBtn.style.border = '1px solid rgba(255,255,255,0.1)';
        cardBtn.style.background = 'rgba(0,0,0,0.2)';
        cardBtn.style.color = '#94a3b8';
    } else {
        cardBtn.style.border = '1px solid #0ea5e9';
        cardBtn.style.background = 'rgba(14, 165, 233, 0.1)';
        cardBtn.style.color = '#0ea5e9';
        
        cashBtn.style.border = '1px solid rgba(255,255,255,0.1)';
        cashBtn.style.background = 'rgba(0,0,0,0.2)';
        cashBtn.style.color = '#94a3b8';
    }
};

window.qcsSubmitSettlement = async () => {
    const submitBtn = document.getElementById('qcs-submit-btn');
    if (submitBtn && submitBtn.disabled) return;

    const select = document.getElementById('qcs-customer-select');
    if (!select || select.value === "") {
        window.showToast("Please select a customer.", "warning");
        return;
    }

    const cid = select.value;
    const opt = select.options[select.selectedIndex];
    const name = opt.text.split(' (')[0];
    const balance = parseFloat(opt.getAttribute('data-balance')) || 0;
    const method = document.getElementById('qcs-payment-method').value;

    const payAmountInput = document.getElementById('qcs-amount-input');
    const payAmount = payAmountInput ? parseFloat(payAmountInput.value) : balance;

    if (isNaN(payAmount) || payAmount <= 0) {
        window.showToast("Please enter a valid payment amount.", "warning");
        return;
    }

    // Cap the actual settled amount at the outstanding balance (excess is returned as change)
    const settledAmount = Math.min(payAmount, balance);

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.dataset.origText = submitBtn.innerText;
        submitBtn.innerText = "⏳ Processing...";
        submitBtn.style.opacity = "0.7";
        submitBtn.style.cursor = "not-allowed";
    }

    try {
        window.showToast("🚀 Settling Credit...", "info");
        const batch = writeBatch(db);
        const storeId = window.getStoreId();

        const customer = (window.allCustomers || []).find(c => c.docId === cid);
        const custPhone = (customer?.phone || opt.getAttribute('data-phone') || "").replace(/[\s-]/g, "");

        // Standard shop orders only (NO repairs, current store)
        const orders = (window.allOrders || []).filter(o => {
            const isStoreMatch = o.storeId === storeId || storeId === 'master';
            if (!isStoreMatch || o.paymentMethod !== 'Credit' || o.repairJobId || o.status === 'Void' || o.status === 'Cancelled') return false;
            if (o.customerId && o.customerId === cid) return true;
            if (custPhone && o.phone) {
                const cleanOrderPhone = o.phone.replace(/[\s-]/g, "");
                return cleanOrderPhone === custPhone;
            }
            return false;
        });

        // Sort orders by date (FIFO - oldest first) to allocate partial payment
        orders.sort((a, b) => {
            const timeA = a.timestamp?.seconds || 0;
            const timeB = b.timestamp?.seconds || 0;
            return timeA - timeB;
        });

        const now = new Date();
        const settledDateStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : now.toLocaleDateString('sv-SE');
        const settledTimeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const affectedOrders = [];
        let remainingPayment = settledAmount; // Amount left to allocate across orders (FIFO)

        for (const o of orders) {
            if (remainingPayment <= 0) break;

            const orderOwed = Math.max(0, (o.total || 0) - (o.tenderedAmount || 0));
            if (orderOwed <= 0) continue;

            if (remainingPayment >= orderOwed) {
                // Fully settle this order
                batch.update(doc(db, 'orders', o.docId), { 
                    paymentMethod: `${method} (Settled)`,
                    tenderedAmount: o.total || 0,
                    status: 'Completed',
                    settledAt: serverTimestamp(),
                    settledDate: settledDateStr,
                    settledTime: settledTimeStr,
                    settledMethod: method
                });
                o.paymentMethod = `${method} (Settled)`;
                o.tenderedAmount = o.total || 0;
                o.status = 'Completed';
                o.settledDate = settledDateStr;
                o.settledTime = settledTimeStr;
                o.settledMethod = method;
                remainingPayment -= orderOwed;
                affectedOrders.push(o);
            } else {
                // Partially settle this order
                const newTendered = (o.tenderedAmount || 0) + remainingPayment;
                batch.update(doc(db, 'orders', o.docId), { 
                    tenderedAmount: newTendered,
                    partialSettledAt: serverTimestamp(),
                    settledDate: settledDateStr,
                    settledTime: settledTimeStr,
                    settledMethod: method
                });
                o.tenderedAmount = newTendered;
                o.settledDate = settledDateStr;
                o.settledTime = settledTimeStr;
                o.settledMethod = method;
                remainingPayment = 0;
                affectedOrders.push(o);
            }
        }

        // Compute remaining overall outstanding balance across all categories/branches
        const overallOrders = (window.allOrders || []).filter(o => {
            if (o.paymentMethod !== 'Credit' || o.status === 'Void' || o.status === 'Cancelled') return false;
            if (o.customerId && o.customerId === cid) return true;
            if (custPhone && o.phone) {
                return o.phone.replace(/[\s-]/g, "") === custPhone;
            }
            return false;
        });

        const overallReloads = (window.allReloads || []).filter(o => {
            if (o.payMode !== 'Credit' || o.status === 'Void') return false;
            if (o.customerId && o.customerId === cid) return true;
            if (custPhone && o.phone) {
                return o.phone.replace(/[\s-]/g, "") === custPhone;
            }
            return false;
        });

        const totalOrdersOutstanding = overallOrders.reduce((sum, o) => sum + Math.max(0, (o.total || 0) - (o.tenderedAmount || 0)), 0);
        const totalReloadsOutstanding = overallReloads.reduce((sum, o) => sum + Math.max(0, (o.amount || 0) - (o.tenderedAmount || 0)), 0);
        const totalOutstandingBefore = totalOrdersOutstanding + totalReloadsOutstanding;
        
        const remainingOutstanding = Math.max(0, totalOutstandingBefore - settledAmount);

        if (cid) {
            batch.update(doc(db, 'customers', cid), { outstanding: remainingOutstanding });
        }
        const targetCust = customer || (window.allCustomers || []).find(c => c.docId === cid);
        if (targetCust) targetCust.outstanding = remainingOutstanding;

        // Commit batch first to ensure primary database update is saved
        await batch.commit();

        // Create income entry asynchronously in background
        addDoc(collection(db, 'income'), {
            title: `Credit Settlement: ${name}`,
            amount: settledAmount,
            date: settledDateStr,
            branchId: sessionStorage.getItem('userBranchId') || 'Global',
            storeId: storeId,
            method: method,
            timestamp: serverTimestamp()
        }).catch(incErr => console.warn("Income record creation failed:", incErr));

        const changeBack = payAmount - settledAmount;
        const changeStr = changeBack > 0 ? ` | Change: LKR ${changeBack.toLocaleString()}` : '';
        window.showToast(`✅ Successfully settled LKR ${settledAmount.toLocaleString()}${changeStr}`, "success");
        document.getElementById('quick-credit-settle-modal').style.display = 'none';
        
        if (window.renderCreditLedgerUI) window.renderCreditLedgerUI();

        // Show settlement summary popup
        if (typeof window.showSettlementReceiptSummary === 'function') {
            window.showSettlementReceiptSummary({
                name: name,
                phone: targetCust?.phone || custPhone || 'N/A',
                amount: settledAmount,
                method: method,
                date: settledDateStr,
                time: settledTimeStr,
                orders: affectedOrders
            });
        }
    } catch (err) {
        console.error("Credit settlement error:", err);
        window.showToast(`❌ Error settling credit: ${err.message || 'Unknown error'}`, "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = submitBtn.dataset.origText || "💰 Settle Credit Now";
            submitBtn.style.opacity = "1";
            submitBtn.style.cursor = "pointer";
        }
    }
};

// Web Orders Tab Management (Deprecated but kept for safety)
window.posWebOrdersActiveTab = 'shop';
window.switchPOSWebOrders = (tab) => {
    window.renderPOSPendingShopOrders(window.allOrders || []);
};

// Web Order Handlers
// Unified Global Branch Switcher Handler
window.setTerminalBranch = (branchVal) => {
    localStorage.setItem('mec_terminal_branch', branchVal);
    window.activeBranchFilter = branchVal;
    
    // Sync all dropdowns
    const posSelect = document.getElementById('pos-terminal-branch-select');
    const globalSelect = document.getElementById('global-branch-selector');
    if (posSelect && posSelect.value !== branchVal) posSelect.value = branchVal;
    if (globalSelect && globalSelect.value !== branchVal) globalSelect.value = branchVal;

    const summaryBranch = document.getElementById('summary-branch');
    if (summaryBranch) {
        summaryBranch.innerText = branchVal === 'All' ? 'All Branches' : (branchVal === 'main' ? 'Horana (Main Branch)' : (window.allBranches?.find(b => b.docId === branchVal)?.name || branchVal));
    }

    // Refresh ALL modules in real-time
    if (typeof window.renderAdminOrdersUI === 'function') {
        window.renderAdminOrdersUI(window.allOrders || []);
    }
    if (typeof window.renderPOSPendingShopOrders === 'function') {
        window.renderPOSPendingShopOrders(window.allOrders || []);
    }
    if (typeof window.renderWebOrdersPage === 'function') {
        window.renderWebOrdersPage();
    }
    if (typeof window.renderAdminEmployeesUI === 'function') {
        window.renderAdminEmployeesUI(window.allEmployees || []);
    }
    if (typeof window.renderExpensesUI === 'function') {
        window.renderExpensesUI(window.allExpenses || []);
    }
    if (typeof window.renderIncomeUI === 'function') {
        window.renderIncomeUI(window.allIncome || []);
    }
    if (typeof window.renderExecutiveDashboard === 'function') {
        window.renderExecutiveDashboard();
    }
    if (typeof window.generateReports === 'function') {
        window.generateReports(window.allOrders || []);
    }
    if (typeof window.renderRepairJobsUI === 'function') {
        window.renderRepairJobsUI(window.allRepairJobs || []);
    }
    if (typeof window.handlePOSSearch === 'function') {
        window.handlePOSSearch(document.getElementById('pos-search')?.value || '');
    }

    const bName = branchVal === 'All' ? 'All Branches (Global)' : (branchVal === 'main' || branchVal === 'Horana' ? 'Horana (Main Branch)' : (window.allBranches?.find(b => b.docId === branchVal)?.name || branchVal));
    if (typeof window.showToast === 'function') {
        window.showToast(`📍 Branch switched to: ${bName}`, "info");
    }
};
window.switchBranchFilter = window.setTerminalBranch;

window.populateTerminalBranchSelectors = () => {
    const posSelect = document.getElementById('pos-terminal-branch-select');
    const globalSelect = document.getElementById('global-branch-selector');
    const globalWrapper = document.getElementById('branch-selector-wrapper');

    const userRole = (sessionStorage.getItem('userRole') || '').toLowerCase();
    const userEmail = (sessionStorage.getItem('userEmail') || '').toLowerCase();
    const userBranchId = sessionStorage.getItem('userBranchId') || 'main';

    const isMasterAdmin = userEmail === 'mecbookshop@gmail.com' || 
                          userEmail === 'malinduec@gmail.com' || 
                          userEmail === 'mecposadmin@gmail.com';

    const isHighLevelRole = isMasterAdmin || 
                            userRole.includes('ceo') || 
                            userRole.includes('owner') || 
                            userRole.includes('proprietor') || 
                            userRole.includes('director') || 
                            userRole.includes('superadmin') || 
                            userRole.includes('admin') || 
                            userRole.includes('hr') || 
                            userRole.includes('manager') || 
                            userRole.includes('general_manager') || 
                            userRole === 'all_access';

    const branches = window.allBranches || [];

    if (isHighLevelRole) {
        // High Level Management (CEO / HR Manager / SuperAdmin / Owner)
        // Can view and switch between All Branches and any individual branch
        if (globalWrapper) globalWrapper.style.display = 'block';
        const savedBranch = localStorage.getItem('mec_terminal_branch') || 'All';
        window.activeBranchFilter = savedBranch;

        let optionsHtml = `<option value="All">All Branches (Global)</option>`;
        optionsHtml += `<option value="main">Horana (Main Branch)</option>`;
        
        branches.forEach(b => {
            const bDocId = b.docId || b.id;
            const bName = (b.name || b.shopName || b.location || 'Branch').trim();
            const bLoc = (b.location || b.city || '').trim();
            const label = bLoc && !bName.toLowerCase().includes(bLoc.toLowerCase()) ? `${bName} (${bLoc})` : bName;
            if (bDocId !== 'main' && !bName.toLowerCase().includes('horana') && !bLoc.toLowerCase().includes('horana')) {
                optionsHtml += `<option value="${bDocId}">${label}</option>`;
            }
        });

        if (posSelect) {
            posSelect.disabled = false;
            posSelect.style.pointerEvents = 'auto';
            posSelect.style.opacity = '1';
            posSelect.innerHTML = optionsHtml;
            posSelect.value = savedBranch;
            posSelect.onchange = (e) => window.switchBranchFilter(e.target.value);
        }

        if (globalSelect) {
            globalSelect.disabled = false;
            globalSelect.style.pointerEvents = 'auto';
            globalSelect.style.opacity = '1';
            globalSelect.innerHTML = optionsHtml;
            globalSelect.value = savedBranch;
            globalSelect.onchange = (e) => window.switchBranchFilter(e.target.value);
        }

        const summaryBranch = document.getElementById('summary-branch');
        if (summaryBranch) {
            summaryBranch.innerText = savedBranch === 'All' ? 'All Branches' : savedBranch;
        }
    } else {
        // Regular Staff / Cashiers / Branch Users: Strictly LOCKED to assigned branch ONLY
        let assignedId = userBranchId;
        if (!assignedId || assignedId === 'Global') assignedId = 'main';

        let assignedName = 'Horana (Main Branch)';
        if (assignedId !== 'main') {
            const matchBranch = branches.find(b => (b.docId === assignedId || b.id === assignedId));
            if (matchBranch) {
                const bLoc = (matchBranch.location || matchBranch.city || '').trim();
                assignedName = bLoc && !matchBranch.name.toLowerCase().includes(bLoc.toLowerCase()) ? `${matchBranch.name} (${bLoc})` : matchBranch.name;
            }
        }

        localStorage.setItem('mec_terminal_branch', assignedId);
        window.activeBranchFilter = assignedId;

        const lockedHtml = `<option value="${assignedId}">${assignedName}</option>`;

        if (posSelect) {
            posSelect.innerHTML = lockedHtml;
            posSelect.value = assignedId;
            posSelect.disabled = true; // Lock dropdown
            posSelect.style.pointerEvents = 'none';
            posSelect.style.opacity = '0.85';
            posSelect.style.borderColor = 'rgba(255,255,255,0.15)';
        }

        if (globalSelect) {
            globalSelect.innerHTML = lockedHtml;
            globalSelect.value = assignedId;
            globalSelect.disabled = true; // Lock dropdown
            globalSelect.style.pointerEvents = 'none';
            globalSelect.style.opacity = '0.85';
        }
        if (globalWrapper) globalWrapper.style.display = 'block';

        const summaryBranch = document.getElementById('summary-branch');
        if (summaryBranch) {
            summaryBranch.innerText = assignedName;
        }
    }
};

window.renderPOSPendingShopOrders = (orders = []) => {
    const list = document.getElementById('pos-web-orders-list'); 
    const badge = document.getElementById('pos-web-orders-count-badge');
    if (!list) return;

    const storeId = window.getStoreId();
    
    // Filter out completed/delivered/processed orders
    const pendingOrders = orders.filter(o => 
        o && 
        !o.processedAtPOS &&
        o.status !== 'Completed' && 
        o.status !== 'Delivered' &&
        o.status !== 'Cancelled' &&
        o.status !== 'Void' &&
        (o.storeId === storeId || storeId === 'master')
    );

    const userBranch = sessionStorage.getItem('userBranchId') || 'main';
    const savedTerminalBranch = localStorage.getItem('mec_terminal_branch') || window.activeBranchFilter || (userBranch !== 'Global' ? userBranch : 'All');

    // Filter for Shop Pickup Orders ONLY for this specific terminal's branch (Strict branch isolation)
    const webOrders = pendingOrders.filter(o => {
        const isShop = o.isShopPending === true || 
                       (o.method || o.paymentMethod || '').toLowerCase().includes('shop') || 
                       (o.method || o.paymentMethod || '').toLowerCase().includes('pick') ||
                       (o.deliveryMethod || '').toLowerCase().includes('shop');
        if (!isShop) return false;

        // If terminal is assigned to a specific branch (e.g. Panadura or Horana)
        if (savedTerminalBranch && savedTerminalBranch !== 'All' && savedTerminalBranch !== 'Global') {
            const branchQuery = savedTerminalBranch.toLowerCase();
            const orderBranchId = (o.branchId || '').toLowerCase();
            const orderPickupShopId = (o.pickupShopId || '').toLowerCase();
            const orderShopName = (o.pickupShopName || '').toLowerCase();
            const orderTown = (o.pickupTown || '').toLowerCase();
            const orderCity = (o.city || '').toLowerCase();
            const orderAddress = (o.address || '').toLowerCase();

            const isHorana = branchQuery.includes('horana') || branchQuery === 'main';
            const isPanadura = branchQuery.includes('panadura') || branchQuery === 'j8lsw5vrjwmssc630dh0';

            if (isHorana) {
                const matchesPanadura = orderBranchId.includes('panadura') ||
                                        orderBranchId === 'j8lsw5vrjwmssc630dh0' ||
                                        orderPickupShopId.includes('panadura') ||
                                        orderShopName.includes('panadura') ||
                                        orderTown.includes('panadura');
                if (matchesPanadura) return false;
                return true; // All general/Horana orders belong to Horana
            } else if (isPanadura) {
                const matchesPanadura = orderBranchId.includes('panadura') ||
                                        orderBranchId === 'j8lsw5vrjwmssc630dh0' ||
                                        orderPickupShopId.includes('panadura') ||
                                        orderShopName.includes('panadura') ||
                                        orderTown.includes('panadura') ||
                                        orderAddress.includes('panadura');
                if (!matchesPanadura) return false;
            } else {
                const matches = orderBranchId === branchQuery ||
                                orderPickupShopId === branchQuery ||
                                orderShopName.includes(branchQuery) ||
                                orderTown.includes(branchQuery) ||
                                orderCity.includes(branchQuery) ||
                                orderAddress.includes(branchQuery);
                if (!matches) return false;
            }
        }
        return true;
    });

    if (badge) badge.innerText = webOrders.length;

    if (webOrders.length === 0) {
        list.innerHTML = `<div style="padding:10px; opacity:0.5; font-size:0.7rem; color: #94a3b8; font-style: italic;">No web orders waiting.</div>`;
        return;
    }

    list.innerHTML = webOrders.map(o => {
        const methodLabel = o.method || o.paymentMethod || 'Web';
        const methodColor = methodLabel.toLowerCase().includes('bank') ? '#8b5cf6' : 
                           methodLabel.toLowerCase().includes('cod') ? '#f59e0b' : '#38bdf8';

        return `
            <div onclick="window.loadShopOrderToPOS('${o.docId}')" 
                 style="min-width: 190px; max-width: 190px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 10px; cursor: pointer; transition: all 0.2s; flex-shrink: 0; display: flex; flex-direction: column; gap: 4px;"
                 onmouseover="this.style.background='rgba(56, 189, 248, 0.08)'; this.style.borderColor='rgba(56, 189, 248, 0.3)';"
                 onmouseout="this.style.background='rgba(255,255,255,0.03)'; this.style.borderColor='rgba(255,255,255,0.08)';"
            >
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="font-weight:900; color:${methodColor}; font-size:0.6rem; background: ${methodColor}15; padding: 1px 5px; border-radius: 4px;">#${o.orderId?.substring(o.orderId.length - 6).toUpperCase() || 'WEB'}</span>
                    <span style="font-size:0.55rem; color:#64748b; font-weight: 600;">${o.date?.split(',')[0]}</span>
                </div>
                <div style="font-weight:800; color:#f1f5f9; font-size:0.75rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${o.userName}</div>
                <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-top: auto; padding-top: 5px; border-top: 1px solid rgba(255,255,255,0.03);">
                    <div style="display: flex; flex-direction: column;">
                        <span style="font-size: 0.55rem; color: #64748b; font-weight: 800;">${methodLabel}</span>
                        <span style="font-size: 0.75rem; color: #fff; font-weight: 700;">${o.items?.length || 0} Items</span>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight:900; color:#10b981; font-size:0.85rem;">Rs.${o.total?.toLocaleString()}</div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
};

// --- HELD BILLS (SUSPEND & RESUME) LOGIC ---
const heldBillsCol = collection(db, 'held-bills');

window.isHoldingBill = window.isHoldingBill || false;
window.holdCurrentBill = async () => {
    if (window.isHoldingBill) {
        return;
    }
    
    const bill = getActiveBill();
    if (!bill || (bill.items || []).length === 0) {
        return window.showToast("Cannot hold an empty bill!", "warning");
    }

    window.isHoldingBill = true;

    // Capture all state BEFORE any UI or state resetting
    const savedItems = [...bill.items];
    const savedPricingMode = bill.pricingMode || document.getElementById('pos-pricing-mode')?.value || 'retail';
    const savedCustomer = bill.customer || window.currentPOSCustomer || null;
    const custPhone = document.getElementById('pos-cust-phone')?.value || savedCustomer?.phone || "Walk-in";
    const custName = document.getElementById('pos-cust-name-display')?.innerText || savedCustomer?.name || "";
    const discInputField = document.getElementById('pos-bill-discount');
    const discTypeField = document.getElementById('pos-discount-type');
    const savedBillDiscount = bill.billDiscount !== undefined ? parseFloat(bill.billDiscount) || 0 : (discInputField ? parseFloat(discInputField.value) || 0 : 0);
    const savedDiscountType = bill.discountType || (discTypeField ? discTypeField.value : 'LKR');
    const storeId = window.getStoreId();
    const staffName = document.getElementById('pos-user-name')?.innerText || 'Staff';

    window.showToast("⏳ Holding bill...", "info");

    try {
        const cleanItems = savedItems.map(item => {
            const cleanItem = {
                ...item,
                docId: item.docId || item.id || '',
                name: item.name || '',
                price: parseFloat(item.price) || 0,
                quantity: parseFloat(item.quantity) || 1,
                discount: parseFloat(item.discount) || 0,
                discountVal: item.discountVal !== undefined ? parseFloat(item.discountVal) || 0 : (parseFloat(item.discount) || 0),
                discountType: item.discountType || 'Rs'
            };
            Object.keys(cleanItem).forEach(key => {
                if (cleanItem[key] === undefined) {
                    delete cleanItem[key];
                }
            });
            return cleanItem;
        });

        // Clear current bill IMMEDIATELY to prevent double submissions from slow UI
        bill.items = [];
        bill.pricingMode = 'retail';
        bill.customer = null;
        bill.billDiscount = 0;
        bill.discountType = 'LKR';
        window.currentPOSCustomer = null;
        
        const phoneInput = document.getElementById('pos-cust-phone');
        if (phoneInput) phoneInput.value = "";
        const nameDisplay = document.getElementById('pos-cust-name-display');
        if (nameDisplay) nameDisplay.innerText = "Walk-in Customer";
        const pointsBadge = document.getElementById('pos-cust-points-badge');
        if (pointsBadge) pointsBadge.style.display = 'none';
        
        const modeSelect = document.getElementById('pos-pricing-mode');
        if (modeSelect) modeSelect.value = 'retail';
        
        if (discInputField) discInputField.value = '0';
        if (discTypeField) discTypeField.value = 'LKR';

        // Clear product search input and refresh search list
        const pSearch = document.getElementById('pos-search');
        if (pSearch) pSearch.value = '';
        
        renderPOSBill();
        window.posCustPillUpdate?.();
        
        if (window.handlePOSSearch) {
            window.handlePOSSearch('');
        }
        
        // NOW run the cloud function in the background
        const heldDocPayload = {
            items: cleanItems,
            customerPhone: custPhone,
            customerName: custName,
            pricingMode: savedPricingMode,
            billDiscount: savedBillDiscount,
            discountType: savedDiscountType,
            timestamp: serverTimestamp(),
            storeId: storeId,
            staffName: staffName
        };

        if (savedCustomer) {
            heldDocPayload.customer = {
                docId: savedCustomer.docId || savedCustomer.id || '',
                name: savedCustomer.name || '',
                phone: savedCustomer.phone || '',
                customerType: savedCustomer.customerType || savedCustomer.type || '',
                loyaltyPoints: parseFloat(savedCustomer.loyaltyPoints) || 0,
                loyaltyCardNo: savedCustomer.loyaltyCardNo || ''
            };
        }

        await addDoc(heldBillsCol, heldDocPayload);
        
        window.showToast("📥 Bill held successfully!", "success");
        window.logAction("POS HOLD", `Bill held for ${custPhone}`);
        
    } catch (e) {
        console.error(e);
        window.showToast("❌ Failed to hold bill.", "error");
    } finally {
        window.isHoldingBill = false;
    }
};

window.showHeldBills = async () => {
    const modal = document.getElementById('held-bills-modal');
    const list = document.getElementById('held-bills-list');
    const counter = document.getElementById('held-bills-count');
    
    if (!modal || !list) return;

    modal.style.display = 'flex';
    list.innerHTML = '<div style="text-align: center; padding: 2rem; opacity: 0.5; color: white;">🔍 Synchronizing with cloud...</div>';
    
    try {
        const storeId = window.getStoreId();
        console.log("Fetching held bills for store:", storeId);
        
        const q = query(heldBillsCol, where("storeId", "==", storeId));
        const snap = await getDocs(q);
        
        const bills = [];
        snap.forEach(doc => bills.push({ id: doc.id, ...doc.data() }));
        
        console.log(`Found ${bills.length} held bills.`);

        // Sort by timestamp (desc)
        bills.sort((a,b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
        
        if (counter) counter.innerText = bills.length;

        if (bills.length === 0) {
            list.innerHTML = `
                <div style="text-align: center; padding: 3rem; color: white; border: 1px dashed rgba(255,255,255,0.1); border-radius: 24px; background: rgba(255,255,20,0.02);">
                    <div style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.3;">📋</div>
                    <div style="font-weight: 700; font-size: 1.1rem; margin-bottom: 5px;">No Saved Bills Found</div>
                    <div style="font-size: 0.85rem; opacity: 0.5;">Transactions you "Hold" will appear here for later retrieval.</div>
                </div>
            `;
            return;
        }

        list.innerHTML = bills.map(b => {
            const subVal = (b.items || []).reduce((sum, item) => {
                const price = parseFloat(item.price) || 0;
                const qty = parseFloat(item.quantity) || 1;
                const disc = parseFloat(item.discount) || 0;
                return sum + ((price - disc) * qty);
            }, 0);

            const bDisc = parseFloat(b.billDiscount) || 0;
            const bDiscType = b.discountType || 'LKR';
            let totalVal = subVal;
            if (bDisc > 0) {
                if (bDiscType === '%') {
                    totalVal = Math.max(0, subVal - ((subVal * bDisc) / 100));
                } else {
                    totalVal = Math.max(0, subVal - bDisc);
                }
            }
            
            return `
            <div class="held-bill-item" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 16px; display: flex; justify-content: space-between; align-items: center; transition: all 0.2s; cursor: default;">
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px;">
                        <span style="font-weight: 800; color: #f59e0b; font-size: 0.75rem; background: rgba(245,158,11,0.1); padding: 2px 8px; border-radius: 4px;">#${b.id.substring(0,6).toUpperCase()}</span>
                        <span style="color: rgba(255,255,255,0.5); font-size: 0.7rem;">${b.timestamp?.toDate ? b.timestamp.toDate().toLocaleString() : 'Recent'}</span>
                    </div>
                    <div style="font-weight: 800; color: white; font-size: 1rem; margin-bottom: 2px;">${b.customerName || b.customerPhone || 'Walk-in Customer'}</div>
                    <div style="font-size: 0.75rem; color: #38bdf8; font-weight: 700;">
                        ${b.items.length} items | <span style="color: #10b981; font-weight: 800;">LKR ${totalVal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span> | <span style="color: #64748b;">By ${b.staffName || 'Staff'}</span>
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button onclick="window.loadHeldBill('${b.id}')" style="background: #10b981; color: white; border: none; padding: 8px 15px; border-radius: 8px; font-weight: 800; cursor: pointer; font-size: 0.8rem;">📥 Restore</button>
                    <button onclick="window.deleteHeldBill('${b.id}')" style="background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); padding: 8px 10px; border-radius: 8px; cursor: pointer;">🗑️</button>
                </div>
            </div>
            `;
        }).join('');

    } catch (e) {
        console.error(e);
        list.innerHTML = '<div style="color: #ef4444; text-align: center; padding: 1rem;">Failed to load bills.</div>';
    }
};

window.loadHeldBill = async (docId) => {
    try {
        const snap = await getDoc(doc(heldBillsCol, docId));
        if (!snap.exists()) {
            return window.showToast("Saved bill not found!", "error");
        }
        
        const data = snap.data();
        const activeBill = getActiveBill();
        
        // 1. Restore items with exact product info, price, qty, and ALL discounts preserved
        activeBill.items = (data.items || []).map(i => {
            const p = (window.allProducts || []).find(x => x.docId === (i.docId || i.id));
            const baseObj = p ? { ...p } : {};
            const savedPrice = i.price !== undefined ? parseFloat(i.price) : (p ? parseFloat(p.price) || 0 : 0);
            const savedQty = parseFloat(i.quantity) || 1;
            const savedDisc = parseFloat(i.discount) || 0;
            const savedDiscVal = i.discountVal !== undefined ? parseFloat(i.discountVal) : savedDisc;
            const savedDiscType = i.discountType || 'Rs';

            return {
                ...baseObj,
                ...i,
                price: savedPrice,
                quantity: savedQty,
                discount: savedDisc,
                discountVal: savedDiscVal,
                discountType: savedDiscType
            };
        });

        // 2. Restore Bill-level discount
        const billDisc = data.billDiscount !== undefined ? parseFloat(data.billDiscount) || 0 : 0;
        const billDiscType = data.discountType || 'LKR';
        activeBill.billDiscount = billDisc;
        activeBill.discountType = billDiscType;

        const discInputField = document.getElementById('pos-bill-discount');
        if (discInputField) {
            discInputField.value = billDisc !== 0 ? billDisc : '0';
        }
        const discTypeField = document.getElementById('pos-discount-type');
        if (discTypeField) {
            discTypeField.value = billDiscType;
        }

        // 3. Restore Pricing Mode directly without wiping out restored items discounts
        const targetMode = data.pricingMode || 'retail';
        activeBill.pricingMode = targetMode;
        const modeEl = document.getElementById('pos-pricing-mode');
        if (modeEl) {
            modeEl.value = targetMode;
        }

        // 4. Restore Customer directly (avoid lookupPOSCustomer which triggers updatePOSPricingMode)
        let customer = data.customer || null;
        const custPhone = (data.customerPhone === "Walk-in") ? "" : (data.customerPhone || "");
        
        if (!customer && custPhone) {
            customer = (window.allCustomers || []).find(c => {
                const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
                const qClean = custPhone.trim().toLowerCase().replace(/\s/g, '');
                return (cPhone === qClean) || (cPhone.replace(/^0/, '') === qClean.replace(/^0/, ''));
            });
        }

        activeBill.customer = customer;
        window.currentPOSCustomer = customer;

        const phoneInput = document.getElementById('pos-cust-phone');
        const nameDisplay = document.getElementById('pos-cust-name-display');
        const pointsBadge = document.getElementById('pos-cust-points-badge');
        const pointsVal = document.getElementById('pos-cust-points-val');

        if (customer) {
            if (phoneInput) phoneInput.value = customer.name || customer.phone || custPhone;
            if (nameDisplay) nameDisplay.innerText = customer.name || data.customerName || 'Customer';
            if (pointsBadge && pointsVal) {
                const pts = customer.loyaltyPoints || 0;
                pointsVal.innerText = pts.toLocaleString();
                pointsBadge.style.display = 'flex';
            }
        } else if (custPhone || (data.customerName && data.customerName !== 'Walk-in Customer')) {
            if (phoneInput) phoneInput.value = custPhone || data.customerName;
            if (nameDisplay) nameDisplay.innerText = data.customerName || 'Walk-in Customer';
            if (pointsBadge) pointsBadge.style.display = 'none';
        } else {
            if (phoneInput) phoneInput.value = "";
            if (nameDisplay) nameDisplay.innerText = "Walk-in Customer";
            if (pointsBadge) pointsBadge.style.display = 'none';
        }
        window.posCustPillUpdate?.();

        // 5. Render bill & save draft
        renderPOSBill();
        if (typeof window.savePOSBillsDraft === 'function') {
            window.savePOSBillsDraft(true);
        }
        
        // 6. Close modal and delete held doc
        document.getElementById('held-bills-modal').style.display = 'none';
        await deleteDoc(doc(heldBillsCol, docId));
        
        window.showToast("✅ Saved bill restored!", "success");
        window.logAction("POS RESUME", `Restored held bill for ${data.customerPhone || 'Walk-in'}`);

    } catch (e) {
        console.error(e);
        window.showToast("❌ Failed to restore bill.", "error");
    }
};

window.deleteHeldBill = async (id) => {
    const docRef = doc(heldBillsCol, id);
    if(!await window.verifyDeletePermission(docRef, { status: 'Void', isVoid: true })) return;
    try {
        await deleteDoc(docRef);
        window.showHeldBills(); // Refresh list
        window.showToast("🗑️ Saved bill removed.", "info");
    } catch (e) {
        window.showToast("❌ Delete failed", "error");
    }
};

window.loadShopOrderToPOS = (docId) => {
    const o = (window.allOrders || []).find(x => x.docId === docId);
    if (o) {
        const activeBill = getActiveBill();
        activeBill.items = o.items.map(i => {
            const p = window.allProducts?.find(p => p.docId === i.docId);
            // Web order stores discount as a % and finalPrice as the post-discount price.
            // POS bill expects discount as an LKR amount. Normalize here.
            const webPrice = i.price || i.unitPrice || i.unit_price || (p ? p.price : 0);
            const webFinalPrice = i.finalPrice != null ? i.finalPrice : webPrice;
            const lkrDiscount = Math.round((webPrice - webFinalPrice) * 100) / 100;
            return {
                ...p,
                ...i,
                price: webPrice,
                discount: lkrDiscount,
                discountVal: lkrDiscount,
                discountType: 'Rs',
                quantity: i.quantity || i.qty || 1
            };
        });

        // Temporarily store customer without letting lookupPOSCustomer trigger automatic pricing mode changes
        const custPhone = o.phone || '';
        const custPhoneEl = document.getElementById('pos-cust-phone');
        if (custPhoneEl) {
            custPhoneEl.value = custPhone;
        }

        if (custPhone) {
            // Find customer directly to avoid updatePOSPricingMode wiping out web order item prices
            const customer = (window.allCustomers || []).find(c => {
                const cPhone = (c.phone || "").toLowerCase().replace(/\s/g, '');
                const qClean = custPhone.trim().toLowerCase().replace(/\s/g, '');
                return (cPhone === qClean) || (cPhone.replace(/^0/, '') === qClean.replace(/^0/, ''));
            });

            if (customer) {
                window.currentPOSCustomer = customer;
                const nameDisplay = document.getElementById('pos-cust-name-display');
                if (nameDisplay) nameDisplay.innerText = customer.name;
                if (custPhoneEl) custPhoneEl.value = customer.name;
                window.posCustPillUpdate?.();
            } else {
                const nameDisplay = document.getElementById('pos-cust-name-display');
                if (nameDisplay) nameDisplay.innerText = o.userName || 'Web Customer';
                window.posCustPillUpdate?.();
            }
        }

        // Keep pricing mode as 'retail' for web orders so it matches online prices
        const pricingSelect = document.getElementById('pos-pricing-mode');
        if (pricingSelect) {
            pricingSelect.value = 'retail';
        }
        activeBill.pricingMode = 'retail';

        // Store the source order ID globally so it can be updated after payment
        window.posActiveSourceOrderId = o.docId;

        renderPOSBill();
        window.showToast("⚡ Website order loaded!", "success");
    }
};

export { 
    posBills, 
    activeBillIndex, 
    currentPendingPOSSale, 
    renderPOSBill, 
    getActiveBill 
};

// Expose to window for global access (admin.js)
window.currentPendingPOSSale = currentPendingPOSSale;
window.getActiveBill = getActiveBill;
window.renderPOSBill = renderPOSBill;
window.posBills = posBills;
window.activeBillIndex = activeBillIndex;
window.processPOSSale = window.processPOSSale || window.processPOSSale; 
window.holdCurrentBill = window.holdCurrentBill || window.holdCurrentBill;
window.showHeldBills = window.showHeldBills || window.showHeldBills;
window.loadHeldBill = window.loadHeldBill || window.loadHeldBill;
window.deleteHeldBill = window.deleteHeldBill || window.deleteHeldBill;
window.calculateModalChange = window.calculateModalChange || window.calculateModalChange;
window.applyModalPoints = window.applyModalPoints || window.applyModalPoints;
window.confirmPOSCODSale = window.confirmPOSCODSale || window.confirmPOSCODSale;

// If saved bills were restored from localStorage, render them now
if (posBills.some(b => (b.items && b.items.length > 0) || b.customer)) {
    setTimeout(() => {
        try {
            renderPOSBill();
        } catch (e) {
            console.warn("[POS] Initial render of draft bills deferred:", e);
        }
    }, 100);
}


// [v3.12.47] Cashier Daily Shift Summary Logic
window.showCashierShiftSummary = async () => {
    const staffId = sessionStorage.getItem('userId') || sessionStorage.getItem('userEmail') || 'Master';
    const staffName = sessionStorage.getItem('userName') || 'Master Admin';
    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    const branchId = sessionStorage.getItem('userBranchId') || 'Global';
    const storeId = window.getStoreId();

    document.getElementById('summary-staff-name').innerText = staffName;
    document.getElementById('summary-date').innerText = today;
    document.getElementById('summary-branch').innerText = branchId;
    document.getElementById('cashier-summary-modal').style.display = 'flex';
    
    const detailsContainer = document.getElementById('shift-summary-details');
    detailsContainer.innerHTML = '<div class="loader-report"></div>';

    try {
        let orders = window.allOrders || [];
        const staffOrders = orders.filter(o => 
            o.date === today && 
            o.staffId === staffId && 
            (o.storeId === storeId || storeId === 'master') &&
            o.status !== 'Void'
        );

        const totals = {
            'Cash': 0,
            'Card': 0,
            'Credit': 0,
            'Bank Transfer': 0,
            'COD': 0,
            'Other': 0
        };

        staffOrders.forEach(o => {
            const method = o.paymentMethod || 'Other';
            let key = 'Other';
            if (method.includes('Cash')) key = 'Cash';
            else if (method.includes('Card')) key = 'Card';
            else if (method.includes('Credit')) key = 'Credit';
            else if (method.includes('Bank Transfer')) key = 'Bank Transfer';
            else if (method.includes('COD')) key = 'COD';
            
            const total = parseFloat(o.total) || 0;
            
            if (key === 'Credit') {
                const tendered = parseFloat(o.tenderedAmount) || 0;
                const creditPortion = Math.max(0, total - tendered);
                totals['Credit'] += creditPortion;
                totals['Cash'] += tendered;
            } else {
                totals[key] += total;
            }
        });

        let grandTotal = 0;
        let html = '';
        
        const icons = {
            'Cash': '💵',
            'Card': '💳',
            'Credit': '📝',
            'Bank Transfer': '🏦',
            'COD': '🚚',
            'Other': '🔹'
        };

        Object.keys(totals).forEach(key => {
            const amount = totals[key];
            grandTotal += amount;
            if (amount > 0 || key === 'Cash') {
                html += `
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 18px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 12px;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <span style="font-size: 1.2rem;">${icons[key]}</span>
                            <span style="color: #f8fafc; font-weight: 700;">${key}</span>
                        </div>
                        <div style="color: white; font-weight: 800;">LKR ${amount.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                    </div>
                `;
            }
        });

        detailsContainer.innerHTML = html;
        document.getElementById('summary-grand-total').innerText = `LKR ${grandTotal.toLocaleString(undefined, {minimumFractionDigits: 2})}`;

    } catch (err) {
        console.error(err);
        detailsContainer.innerHTML = '<p style="color: #ef4444; text-align: center;">Error loading summary data.</p>';
    }
};

window.printCashierSummary = () => {
    const staffName = document.getElementById('summary-staff-name').innerText;
    const date = document.getElementById('summary-date').innerText;
    const details = document.getElementById('shift-summary-details').innerHTML;
    const grandTotal = document.getElementById('summary-grand-total').innerText;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>Shift Summary - ${staffName}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    body { font-family: 'Outfit', 'Inter', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', sans-serif; padding: 40px; color: #333; }
                    .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
                    .row { display: flex; justify-content: space-between; padding: 15px 0; border-bottom: 1px solid #eee; align-items: center; }
                    .total { font-size: 1.5rem; font-weight: bold; margin-top: 30px; text-align: right; border-top: 2px solid #333; padding-top: 15px; }
                    .icon { display: none; }
                </style>
            </head>
            <body onload="window.print(); window.close();">
                <div class="header">
                    <h1>MEC POS - Shift Summary</h1>
                    <p>Staff: <strong>${staffName}</strong></p>
                    <p>Date: <strong>${date}</strong></p>
                </div>
                <div class="details-list">${details}</div>
                <div class="total">Grand Total: ${grandTotal}</div>
                <p style="text-align: center; margin-top: 50px; font-size: 0.8rem; color: #777;">Printed at: ${new Date().toLocaleString()}</p>
            </body>
        </html>
    `);
    printWindow.document.close();
};

window.downloadODM_PDF = () => {
    const order = window.currentPendingPOSSale || window.lastSavedPOSOrder;
    if (!order) {
        window.showToast("No order found to export!", "error");
        return;
    }
    window.currentODMOrder = order;
    if (typeof window.exportODM_PDF === 'function') {
        window.exportODM_PDF();
    } else {
        window.showToast("PDF exporter not initialized!", "error");
    }
};

window.downloadODM_JPG = () => {
    const order = window.currentPendingPOSSale || window.lastSavedPOSOrder;
    if (!order) {
        window.showToast("No order found to export!", "error");
        return;
    }
    window.currentODMOrder = order;
    if (typeof window.exportODM_JPG === 'function') {
        window.exportODM_JPG();
    } else {
        window.showToast("JPG exporter not initialized!", "error");
    }
};

window.downloadODM_Waybill = () => {
    const order = window.currentPendingPOSSale || window.lastSavedPOSOrder;
    if (!order) {
        window.showToast("No order found to export!", "error");
        return;
    }
    window.currentODMOrder = order;
    if (typeof window.exportODM_Waybill === 'function') {
        window.exportODM_Waybill();
    } else {
        window.showToast("Waybill exporter not initialized!", "error");
    }
};

