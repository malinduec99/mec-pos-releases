// --- Global Shop Configuration ---

export const STORE_CONFIG = {
    name: "MEC Book Shop",
    phone: "071 923 3388",
    whatsapp: "071 923 3388",
    address: "No.97, Victoria Park, Rathnapura Road, Munagama, Horana",
    tagline: "Premium Book Shop & Stationery Hub",
    email: "mecbookshop@gmail.com",
    logo: "/mec-logo.png"
};

window.STORE_CONFIG = STORE_CONFIG;
