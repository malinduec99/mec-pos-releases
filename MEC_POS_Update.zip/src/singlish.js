/**
 * Singlish to Sinhala Transliteration Helper
 * Optimized for phonetic search matching.
 */
window.toSinhala = (text) => {
    if (!text) return "";
    let s = text.toLowerCase();
    
    const map = {
        'th': 'ත', 'dh': 'ද', 'sh': 'ශ', 'ch': 'ච', 'kh': 'ඛ', 'gh': 'ඝ',
        'ph': 'ඵ', 'bh': 'භ', 'jh': 'ඣ', 'ng': 'ඟ', 'kn': 'ඥ'
    };
    
    Object.keys(map).forEach(k => { s = s.replace(new RegExp(k, 'g'), map[k]); });
    
    const vowelMap = {
        'aa': 'ා', 'ae': 'ැ', 'ii': 'ී', 'uu': 'ූ', 'ee': 'ේ', 'oo': 'ෝ', 'au': 'ෞ',
        'a': '', 'e': 'ෙ', 'i': 'ි', 'o': 'ො', 'u': 'ු'
    };
    
    const consMap = {
        'k': 'ක', 'g': 'ග', 'c': 'ච', 'j': 'ජ', 'T': 'ඨ', 'D': 'ඪ', 't': 'ට', 'd': 'ඩ',
        'n': 'න', 'p': 'ප', 'b': 'බ', 'm': 'ම', 'y': 'ය', 'r': 'ර', 'l': 'ල', 'v': 'ව', 'w': 'ව',
        's': 'ස', 'h': 'හ', 'f': 'ෆ'
    };

    let res = "";
    let i = 0;
    while(i < s.length) {
        let found = false;
        if (i + 1 < s.length) {
            let chunk2 = s.substr(i, 2);
            if (vowelMap[chunk2]) { res += vowelMap[chunk2]; i += 2; found = true; }
        }
        if (found) continue;
        
        let char = s[i];
        if (vowelMap[char] !== undefined) { res += vowelMap[char]; }
        else if (consMap[char]) { res += consMap[char]; }
        else { res += char; }
        i++;
    }
    
    return res;
};

window.matchProductSku = (pSku, q) => {
    if (!pSku || !q) return false;
    const cleanQ = q.toLowerCase().trim();
    const cleanSku = pSku.toLowerCase();
    if (cleanSku === cleanQ) return true;
    
    let skuToMatch = cleanSku;
    if (skuToMatch.startsWith('sku-')) {
        const parts = skuToMatch.split('-');
        if (parts.length > 1) {
            parts.pop();
            skuToMatch = parts.join('-');
        }
    }
    return skuToMatch.includes(cleanQ);
};
