import { db } from './firebase.js';
import {
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc
} from "firebase/firestore";

const urlParams = new URLSearchParams(window.location.search);
const invoiceId = urlParams.get('id') || urlParams.get('order') || urlParams.get('invoice');

let loadedOrder = null;

async function initInvoiceViewer() {
    const loadingEl = document.getElementById('loading-state');
    const errorEl = document.getElementById('error-state');
    const invoiceWrapper = document.getElementById('invoice-card-wrapper');
    const actionBar = document.getElementById('action-bar');

    if (!invoiceId) {
        if (loadingEl) loadingEl.style.display = 'none';
        if (errorEl) {
            errorEl.style.display = 'block';
            document.getElementById('err-title').innerText = "Missing Invoice ID";
            document.getElementById('err-desc').innerText = "Please provide an Invoice ID in the URL to view your receipt (e.g. ?id=POS-2026-000001).";
        }
        return;
    }

    try {
        let orderData = null;

        // 1. Try querying orders collection by orderId field
        const ordersCol = collection(db, 'orders');
        const q = query(ordersCol, where("orderId", "==", invoiceId.trim()));
        const snap = await getDocs(q);

        if (!snap.empty) {
            orderData = { ...snap.docs[0].data(), docId: snap.docs[0].id };
        } else {
            // 2. Fallback: try checking if the ID passed is directly the docId
            try {
                const docSnap = await getDoc(doc(db, 'orders', invoiceId.trim()));
                if (docSnap.exists()) {
                    orderData = { ...docSnap.data(), docId: docSnap.id };
                }
            } catch (e) {}
        }

        if (!orderData) {
            if (loadingEl) loadingEl.style.display = 'none';
            if (errorEl) {
                errorEl.style.display = 'block';
                document.getElementById('err-title').innerText = "Invoice Not Found";
                document.getElementById('err-desc').innerText = `No active invoice found matching "${invoiceId}". Please verify the receipt ID.`;
            }
            return;
        }

        loadedOrder = orderData;

        // 3. Retrieve Store Info for Branding
        const storeId = orderData.storeId || 'mec-book-shop';
        let storeConfig = null;
        try {
            const cfgSnap = await getDoc(doc(db, 'config', storeId));
            if (cfgSnap.exists()) storeConfig = cfgSnap.data();
        } catch(e) {}

        const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';
        const bizName = storeConfig?.bizName || (isMec ? 'MEC BOOK SHOP & COMMUNICATION' : (orderData.storeName || 'Digital Store'));
        const bizAddress = storeConfig?.invAddress || (isMec ? 'No 97, Victoria Estate, Panadura Road, Munagama, Horana.' : '');
        const rawBizLogo = storeConfig?.storeLogoUrl || storeConfig?.logoUrl;
        const bizLogo = (rawBizLogo && !rawBizLogo.includes('zenith_logo') && !rawBizLogo.includes('/logo.png'))
            ? rawBizLogo
            : (isMec ? '/mec-logo.png' : '');

        // 4. Populate Document Header
        document.title = `Invoice #${orderData.orderId} - ${bizName}`;
        const logoEl = document.getElementById('inv-logo');
        if (logoEl) {
            if (bizLogo) {
                logoEl.src = bizLogo;
                logoEl.style.display = 'block';
            } else {
                logoEl.style.display = 'none';
            }
        }
        document.getElementById('inv-biz-name').innerText = bizName;
        document.getElementById('inv-footer-biz').innerText = bizName;
        document.getElementById('inv-biz-address').innerText = bizAddress;
        document.getElementById('inv-biz-phone').innerText = bizPhone ? `📞 ${bizPhone}` : '';

        // 5. Populate Metadata
        document.getElementById('inv-number').innerText = `#${orderData.orderId}`;
        const dateStr = orderData.date || (orderData.createdAt?.seconds ? new Date(orderData.createdAt.seconds * 1000).toLocaleDateString() : new Date().toLocaleDateString());
        document.getElementById('inv-date').innerText = `Date: ${dateStr}`;

        const statusBadge = document.getElementById('inv-status-badge');
        if (orderData.status === 'Cancelled' || orderData.status === 'Void') {
            statusBadge.innerText = "VOID / CANCELLED";
            statusBadge.style.background = "#fee2e2";
            statusBadge.style.color = "#ef4444";
        } else {
            statusBadge.innerText = (orderData.paymentMethod === 'Credit') ? "CREDIT INVOICE" : "PAID INVOICE";
        }

        // 6. Populate Customer & Payment Details
        const custName = orderData.customerName || orderData.userName || 'Walk-in Customer';
        const custPhone = orderData.customerPhone || orderData.phone || '';
        document.getElementById('inv-cust-name').innerText = custName;
        const phoneEl = document.getElementById('inv-cust-phone');
        if (custPhone) {
            phoneEl.innerText = `Mobile: ${custPhone}`;
            phoneEl.style.display = 'block';
        } else {
            phoneEl.style.display = 'none';
        }

        document.getElementById('inv-pay-method').innerText = orderData.paymentMethod || orderData.method || 'Cash';
        const cashierEl = document.getElementById('inv-cashier');
        if (cashierEl) {
            cashierEl.innerText = orderData.cashierName ? `Cashier: ${orderData.cashierName}` : (orderData.staffName ? `Cashier: ${orderData.staffName}` : 'Cashier: Terminal 01');
        }

        // 7. Populate Items Table
        const items = orderData.items || [];
        const itemsBody = document.getElementById('inv-items-body');
        let computedSubtotal = 0;
        let computedItemDisc = 0;

        itemsBody.innerHTML = items.map(item => {
            const qty = item.quantity || 1;
            const price = parseFloat(item.price || 0);
            const disc = parseFloat(item.discount || 0);
            const lineTotal = (price - disc) * qty;

            computedSubtotal += (price * qty);
            computedItemDisc += (disc * qty);

            return `
                <tr>
                    <td class="td-name">
                        ${escapeHTML(item.name || 'Item')}
                        ${disc > 0 ? `<div style="font-size: 0.72rem; color: #ef4444; font-weight: 700;">(Discount: -LKR ${disc.toFixed(2)}/item)</div>` : ''}
                    </td>
                    <td class="td-center">${qty}</td>
                    <td class="td-right">LKR ${price.toFixed(2)}</td>
                    <td class="td-right">LKR ${lineTotal.toFixed(2)}</td>
                </tr>
            `;
        }).join('');

        // 8. Populate Totals
        const totalDiscount = (orderData.discount || 0) + computedItemDisc;
        const subtotal = (orderData.subtotal !== undefined && orderData.subtotal !== null) ? parseFloat(orderData.subtotal) : (computedSubtotal || parseFloat(orderData.total || 0));
        const grandTotal = parseFloat(orderData.total || 0);
        const codCharge = parseFloat(orderData.codCharge || 0);

        document.getElementById('inv-subtotal').innerText = `LKR ${subtotal.toFixed(2)}`;
        
        const discRow = document.getElementById('inv-row-discount');
        if (totalDiscount > 0) {
            document.getElementById('inv-discount').innerText = `- LKR ${totalDiscount.toFixed(2)}`;
            discRow.style.display = 'flex';
        } else {
            discRow.style.display = 'none';
        }

        const delRow = document.getElementById('inv-row-delivery');
        if (codCharge > 0) {
            document.getElementById('inv-delivery').innerText = `LKR ${codCharge.toFixed(2)}`;
            delRow.style.display = 'flex';
        } else {
            delRow.style.display = 'none';
        }

        document.getElementById('inv-grand-total').innerText = `LKR ${grandTotal.toFixed(2)}`;

        // 9. Configure WhatsApp Support Button
        const supportPhone = (storeConfig?.metaWhatsappConfig?.defaultPhone || (isMec ? '0770658356' : '')).replace(/\D/g, '');
        const supportWaBtn = document.getElementById('btn-support-wa');
        if (supportWaBtn && supportPhone) {
            const cleanSupportPhone = supportPhone.startsWith('0') ? '94' + supportPhone.substring(1) : (supportPhone.startsWith('94') ? supportPhone : '94' + supportPhone);
            const waHelpText = encodeURIComponent(`Hello ${bizName}, I have an inquiry regarding Invoice #${orderData.orderId}`);
            supportWaBtn.href = `https://wa.me/${cleanSupportPhone}?text=${waHelpText}`;
            supportWaBtn.style.display = 'inline-flex';
        }

        // Show Invoice & Action Bar
        if (loadingEl) loadingEl.style.display = 'none';
        if (actionBar) actionBar.style.display = 'flex';
        if (invoiceWrapper) invoiceWrapper.style.display = 'block';

    } catch (err) {
        console.error("Error loading invoice:", err);
        if (loadingEl) loadingEl.style.display = 'none';
        if (errorEl) {
            errorEl.style.display = 'block';
            document.getElementById('err-title').innerText = "System Error";
            document.getElementById('err-desc').innerText = "Could not load invoice due to a network or database issue: " + err.message;
        }
    }
}

function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

window.downloadPDFInvoice = async () => {
    const cardEl = document.getElementById('invoice-card');
    if (!cardEl) return;

    const btn = document.getElementById('btn-download-pdf');
    const origText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerHTML = '<span>⏳</span> Generating PDF...';
        btn.disabled = true;
    }

    const orderId = loadedOrder?.orderId || 'receipt';
    const opt = {
        margin: [8, 8, 8, 8],
        filename: `Invoice_${orderId}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, letterRendering: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    try {
        if (typeof window.html2pdf === 'function') {
            await window.html2pdf().set(opt).from(cardEl).save();
        } else {
            window.print();
        }
    } catch (err) {
        console.warn("html2pdf generation error, falling back to print:", err);
        window.print();
    } finally {
        if (btn) {
            btn.innerHTML = origText;
            btn.disabled = false;
        }
    }
};

window.addEventListener('DOMContentLoaded', initInvoiceViewer);
