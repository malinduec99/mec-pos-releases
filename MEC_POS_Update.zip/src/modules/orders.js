import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot,
    updateDoc, 
    deleteDoc, 
    doc, 
    getDoc,
    serverTimestamp,
    writeBatch,
    query,
    where,
    Timestamp,
    getDocs
} from "firebase/firestore";

const ordersCol = collection(db, 'orders');

const NOTIFIED_ORDERS_KEY = 'mecpos_notified_web_orders';

function loadNotifiedOrderIds() {
    try {
        const raw = localStorage.getItem(NOTIFIED_ORDERS_KEY);
        if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) return new Set(parsed);
        }
    } catch(e) {}
    return new Set();
}

function persistNotifiedOrderIds(set) {
    try {
        const arr = Array.from(set).slice(-300);
        localStorage.setItem(NOTIFIED_ORDERS_KEY, JSON.stringify(arr));
    } catch(e) {}
}

function isShopPickupOrder(order) {
    if (!order) return false;
    return order.isShopPending === true || 
           (order.method || order.paymentMethod || '').toLowerCase().includes('shop') || 
           (order.method || order.paymentMethod || '').toLowerCase().includes('pick') ||
           (order.deliveryMethod || '').toLowerCase().includes('shop');
}

function isEligibleWebOrder(order) {
    if (!order || order.isPOS === true) return false;
    const oid = (order.orderId || order.id || '').toString().toUpperCase();
    if (oid.startsWith('#POS') || oid.startsWith('R-') || oid.startsWith('#R-') || oid.startsWith('POS_')) {
        return false;
    }
    return true;
}

function getOrderCreatedMillis(order) {
    if (!order) return null;
    if (order.timestamp && typeof order.timestamp.toMillis === 'function') {
        return order.timestamp.toMillis();
    }
    if (order.timestamp && order.timestamp.seconds) {
        return order.timestamp.seconds * 1000;
    }
    if (order.createdAt) {
        const t = new Date(order.createdAt).getTime();
        if (!isNaN(t)) return t;
    }
    if (order.date) {
        const t = new Date(order.date).getTime();
        if (!isNaN(t)) return t;
    }
    return null;
}

window.initOrders = initOrders;
export function initOrders() {
    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    
    // Set default dates in UI immediately and retry
    const setInputs = () => {
        const startInput = document.getElementById('order-start-date');
        const endInput = document.getElementById('order-end-date');
        if (startInput && !startInput.value) startInput.value = today;
        if (endInput && !endInput.value) endInput.value = today;
    };
    setInputs();
    setTimeout(setInputs, 100);
    setTimeout(setInputs, 500);

    window.currentOrderFilters = {
        status: 'All',
        search: '',
        start: today,
        end: today
    };

    // Instant Cache Hydration: Load cached orders before network snapshot
    try {
        const cachedStr = localStorage.getItem('mecpos_cached_orders');
        if (cachedStr) {
            const cachedOrders = JSON.parse(cachedStr);
            if (Array.isArray(cachedOrders) && cachedOrders.length > 0 && (!window.allOrders || window.allOrders.length === 0)) {
                window.allOrders = cachedOrders;
                if (typeof window.renderExecutiveDashboard === 'function') {
                    window.renderExecutiveDashboard();
                }
            }
        }
    } catch(e) {}

    let isInitialOrdersLoad = true;
    const notifiedOrderIds = loadNotifiedOrderIds();

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    threeMonthsAgo.setHours(0,0,0,0);
    const threeMonthsAgoTimestamp = Timestamp.fromDate(threeMonthsAgo);

    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';
    
    const ordQ = isMaster ?
        query(ordersCol, where('timestamp', '>=', threeMonthsAgoTimestamp)) :
        query(ordersCol, where('storeId', '==', storeId));

    onSnapshot(ordQ, (snapshot) => {
        const rawOrders = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        const orders = isMaster ? rawOrders : rawOrders.filter(o => o.timestamp && o.timestamp.seconds >= threeMonthsAgoTimestamp.seconds);
        
        // Deduplicate orders by orderId to prevent duplicate invoice records from inflating client state
        const seenOrderIds = new Set();
        const deduplicatedOrders = [];
        orders.forEach(o => {
            if (o.orderId) {
                if (seenOrderIds.has(o.orderId)) return;
                seenOrderIds.add(o.orderId);
            }
            if (o.phone) o.cleanPhone = o.phone.replace(/[\s-]/g, "");
            else o.cleanPhone = "";
            deduplicatedOrders.push(o);
        });
        
        window.allOrders = deduplicatedOrders;

        // Auto-clear cheque orders if due date has passed (prior to today)
        const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
        orders.forEach(async (order) => {
            if (order.paymentMethod === 'Cheque' && order.chequeStatus === 'pending' && order.chequeDate) {
                if (order.chequeDate < todayStr) {
                    try {
                        const { doc, updateDoc } = await import('firebase/firestore');
                        const orderRef = doc(db, 'orders', order.docId);
                        await updateDoc(orderRef, {
                            status: 'Delivered',
                            chequeStatus: 'cleared'
                        });
                        console.log("Auto-cleared cheque order: " + (order.orderId || order.docId));
                    } catch (err) {
                        console.error("Failed to auto-clear cheque order:", err);
                    }
                }
            }
        });
        
        // [v3.12.39] Auto-Sync POS Receipt ID when database updates
        if (window.updatePOSReceiptBadge) window.updatePOSReceiptBadge();
        
        // 1. Initial Load: Check for any pending online orders that arrived while the POS app was closed
        if (isInitialOrdersLoad) {
            const unnotifiedWeb = [];
            const unnotifiedShop = [];
            const now = Date.now();
            const maxOfflineAgeMs = 7 * 24 * 60 * 60 * 1000; // 7 days max to prevent stale test orders

            orders.forEach(order => {
                const docId = order.docId || order.id;
                const orderId = (order.orderId || docId || '').toString();
                const key = orderId || docId;
                if (!key) return;

                const status = (order.status || 'Pending').toLowerCase();
                const isCompleted = status === 'delivered' || status === 'completed' || status === 'cancelled' || status === 'void';
                
                // If the order is completed or not an online order, mark as notified so it never alerts
                if (isCompleted || !isEligibleWebOrder(order)) {
                    notifiedOrderIds.add(key);
                    if (docId) notifiedOrderIds.add(docId);
                    return;
                }

                // If created too far in the past (> 7 days), silently mark as notified
                const createdMs = getOrderCreatedMillis(order);
                if (createdMs && (now - createdMs > maxOfflineAgeMs)) {
                    notifiedOrderIds.add(key);
                    if (docId) notifiedOrderIds.add(docId);
                    return;
                }

                // If already notified in a prior session, skip
                if (notifiedOrderIds.has(key) || (docId && notifiedOrderIds.has(docId))) {
                    return;
                }

                // Genuinely new pending order that arrived while app was closed!
                notifiedOrderIds.add(key);
                if (docId) notifiedOrderIds.add(docId);

                if (isShopPickupOrder(order)) {
                    unnotifiedShop.push(order);
                } else {
                    unnotifiedWeb.push(order);
                }
            });

            persistNotifiedOrderIds(notifiedOrderIds);

            // Notify staff upon login if new orders arrived while offline
            if (unnotifiedWeb.length > 0 || unnotifiedShop.length > 0) {
                setTimeout(() => {
                    if (unnotifiedWeb.length > 0 && unnotifiedShop.length > 0) {
                        const sound = document.getElementById('sound-new-order') || document.getElementById('sound-shop-pickup');
                        if (sound) sound.play().catch(e => console.log('Audio error:', e));
                        window.showToast(`📦 ${unnotifiedWeb.length} Web & ${unnotifiedShop.length} Shop Pickup Orders arrived while offline!`, 'info');
                    } else if (unnotifiedWeb.length > 0) {
                        const sound = document.getElementById('sound-new-order');
                        if (sound) sound.play().catch(e => console.log('Audio error:', e));
                        if (unnotifiedWeb.length === 1) {
                            const o = unnotifiedWeb[0];
                            window.showToast(`🛒 New Web Order arrived while offline! (#${o.orderId || 'Order'})`, 'success');
                        } else {
                            window.showToast(`🛒 ${unnotifiedWeb.length} New Web Orders arrived while offline!`, 'success');
                        }
                    } else if (unnotifiedShop.length > 0) {
                        const sound = document.getElementById('sound-shop-pickup');
                        if (sound) sound.play().catch(e => console.log('Audio error:', e));
                        if (unnotifiedShop.length === 1) {
                            const o = unnotifiedShop[0];
                            window.showToast(`🔔 New Shop Pickup Order arrived while offline! (#${o.orderId || 'Order'})`, 'warning');
                        } else {
                            window.showToast(`🔔 ${unnotifiedShop.length} New Shop Pickup Orders arrived while offline!`, 'warning');
                        }
                    }
                }, 800);
            }

            isInitialOrdersLoad = false;
        } else {
            // 2. Real-time Live Load: Handle orders that arrive while the POS is actively running
            snapshot.docChanges().forEach((change) => {
                if (change.type === "added") {
                    const newOrder = change.doc.data() || {};
                    const docId = change.doc.id;
                    const orderId = (newOrder.orderId || docId || '').toString();
                    const key = orderId || docId;

                    if (notifiedOrderIds.has(key) || (docId && notifiedOrderIds.has(docId))) {
                        return;
                    }
                    notifiedOrderIds.add(key);
                    if (docId) notifiedOrderIds.add(docId);
                    persistNotifiedOrderIds(notifiedOrderIds);

                    if (!isEligibleWebOrder(newOrder)) {
                        return;
                    }

                    const status = (newOrder.status || 'Pending').toLowerCase();
                    if (status === 'delivered' || status === 'completed' || status === 'cancelled' || status === 'void') {
                        return;
                    }

                    if (isShopPickupOrder(newOrder)) {
                        const shopSound = document.getElementById('sound-shop-pickup');
                        if (shopSound) shopSound.play().catch(e => console.log('Audio error:', e));
                        window.showToast(`🔔 New Shop Pickup Order Arrived! (#${orderId})`, 'warning');
                    } else {
                        const webSound = document.getElementById('sound-new-order');
                        if (webSound) webSound.play().catch(e => console.log('Audio error:', e));
                        window.showToast(`🛒 New Web Order Arrived! (#${orderId})`, 'success');
                    }
                }
            });
        }

        // Save orders to local storage offline cache & update dashboard immediately
        try {
            const summaryOrders = orders.slice(0, 100);
            localStorage.setItem('mecpos_cached_orders', JSON.stringify(summaryOrders));
        } catch(e) {}

        const activeTab = window.currentActiveTab || '';
        if (activeTab === 'dashboard' || activeTab === '') {
            if (typeof window.renderExecutiveDashboard === 'function') window.renderExecutiveDashboard();
        }
        if (activeTab === 'orders') {
            if (typeof window.renderAdminOrdersUI === 'function') window.renderAdminOrdersUI(orders);
        }
        if (activeTab === 'web-orders' && window.renderWebOrdersPage) {
            window.renderWebOrdersPage();
        }
        if (activeTab === 'pos' && window.renderPOSPendingShopOrders) {
            window.renderPOSPendingShopOrders(orders);
        }
        if (activeTab === 'reports') {
            if (window.generateReports) window.generateReports(orders);
        }
        if (activeTab === 'credit' && window.renderCreditLedgerUI) {
            window.renderCreditLedgerUI();
        }
    }, (error) => {
        console.error("🔥 Firestore Orders Error:", error);
        window.showToast("Orders Sync Error: " + error.message, "error");
    });
}


window.applyOrderFilters = () => {
    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    const status = document.getElementById('order-status-filter')?.value || 'All';
    const searchInput = document.getElementById('order-search-input');
    const search = searchInput ? searchInput.value.toLowerCase() : '';
    let start = document.getElementById('order-start-date')?.value;
    let end = document.getElementById('order-end-date')?.value;
    
    if (!start) {
        start = today;
        const startInput = document.getElementById('order-start-date');
        if (startInput) startInput.value = today;
    }
    if (!end) {
        end = today;
        const endInput = document.getElementById('order-end-date');
        if (endInput) endInput.value = today;
    }

    if (!window.currentOrderFilters) {
        window.currentOrderFilters = { status: 'All', search: '', start: today, end: today };
    }
    window.currentOrderFilters.status = status;
    window.currentOrderFilters.search = search;
    window.currentOrderFilters.start = start;
    window.currentOrderFilters.end = end;
    
    if (start) {
        const startDate = new Date(start + 'T00:00:00');
        const endDate = new Date((end || start) + 'T23:59:59');
        
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
        threeMonthsAgo.setHours(0,0,0,0);
        
        if (startDate < threeMonthsAgo && navigator.onLine) {
            window.showToast("Fetching historical orders...", "info");
            const storeId = window.getStoreId();
            const isMaster = storeId === 'master';
            const startTimestamp = Timestamp.fromDate(startDate);
            const endTimestamp = Timestamp.fromDate(endDate);
            
            const q = query(ordersCol, where('timestamp', '>=', startTimestamp), where('timestamp', '<=', endTimestamp));
            
            getDocs(q).then((snap) => {
                const rawFetched = snap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                const fetchedOrders = isMaster ? rawFetched : rawFetched.filter(o => o.storeId === storeId);
                
                const ordersMap = new Map();
                (window.allOrders || []).forEach(o => ordersMap.set(o.docId, o));
                fetchedOrders.forEach(o => ordersMap.set(o.docId, o));
                
                const combined = Array.from(ordersMap.values());
                window.renderAdminOrdersUI(combined);
            }).catch(err => {
                console.error("Error fetching historical orders:", err);
                window.renderAdminOrdersUI(window.allOrders || []);
            });
            return;
        }
    }
    
    if (typeof window.renderAdminOrdersUI === 'function') {
        window.renderAdminOrdersUI(window.allOrders || []);
    }
};

window.renderAdminOrdersUI = (orders) => {
    window.selectedOrderCardIndex = -1;
    const ordersDiv = document.getElementById('admin-order-list');
    if (!ordersDiv) return;

    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    if (!window.currentOrderFilters) {
        window.currentOrderFilters = { status: 'All', search: '', start: today, end: today };
    } else {
        if (!window.currentOrderFilters.start) window.currentOrderFilters.start = today;
        if (!window.currentOrderFilters.end) window.currentOrderFilters.end = today;
    }

    const startInput = document.getElementById('order-start-date');
    const endInput = document.getElementById('order-end-date');
    if (startInput && !startInput.value) startInput.value = window.currentOrderFilters.start;
    if (endInput && !endInput.value) endInput.value = window.currentOrderFilters.end;

    const userRole = sessionStorage.getItem('userRole');
    const userBranch = sessionStorage.getItem('userBranchId');
    const storeId = window.getStoreId();

    let filtered = orders.filter(order => {
        const isMecBookShop = (storeId === 'mec-book-shop' || storeId === '1001' || storeId === 'master');
        if (order.storeId && order.storeId !== storeId) {
            const isOrderMec = (order.storeId === 'mec-book-shop' || order.storeId === '1001');
            if (!(isMecBookShop && isOrderMec)) return false;
        }
        
        const f = window.currentOrderFilters;
        if (!order) return false;
        
        if (f.status === 'All') {
            if (order.status === 'Void' || order.status === 'Cancelled') return false;
        } else if (order.status !== f.status) {
            return false;
        }
        if (f.search) {
            const searchStr = f.search.toLowerCase();
            const match = (order.userName || '').toLowerCase().includes(searchStr) || 
                          (order.orderId || '').toLowerCase().includes(searchStr) ||
                          (order.phone || '').includes(searchStr);
            if (!match) return false;
        }

        const activeBranchFilter = window.activeBranchFilter || localStorage.getItem('mec_terminal_branch') || 'All';
        if (activeBranchFilter && activeBranchFilter !== 'All') {
            const filterLower = activeBranchFilter.toLowerCase();
            const isFilterHorana = filterLower === 'main' || filterLower === 'global' || filterLower.includes('horana');
            
            const orderBranchId = (order.branchId || '').toLowerCase();
            const orderBranchName = (order.branch || order.branchName || order.pickupShopName || order.pickupTown || '').toLowerCase();
            const isOrderPanadura = orderBranchId.includes('panadura') || 
                                    orderBranchId === 'j8lsw5vrjwmssc630dh0' || 
                                    orderBranchName.includes('panadura') || 
                                    orderBranchName.includes('warehouse');

            if (isFilterHorana) {
                // If viewing Horana (Main Branch), show all orders EXCEPT those explicitly belonging to Panadura
                if (isOrderPanadura) return false;
            } else if (filterLower.includes('panadura') || filterLower === 'j8lsw5vrjwmssc630dh0') {
                // If viewing Panadura Warehouse, ONLY show orders belonging to Panadura Warehouse
                if (!isOrderPanadura) return false;
            } else {
                // Specific other branch
                const matchesSpecific = (order.branchId && (order.branchId === activeBranchFilter || order.pickupShopId === activeBranchFilter)) ||
                                       orderBranchId.includes(filterLower) ||
                                       orderBranchName.includes(filterLower);
                if (!matchesSpecific) return false;
            }
        }

        // --- FLEXIBLE FILTER: Include all POS-related IDs or store orders ---
        const oid = (order.orderId || '').toString().toUpperCase();
        const isPOSOrder = oid.startsWith('POS-') || 
                           oid.startsWith('#POS-') || 
                           oid.startsWith('POS_') || 
                           oid.startsWith('#POS_') || 
                           oid.startsWith('R-') || 
                           oid.startsWith('#R-') ||
                           oid.startsWith('ORD-') ||
                           oid.startsWith('#ORD-') ||
                           order.isPOS === true ||
                           order.type === 'POS' ||
                           order.source === 'POS' ||
                           (!order.isWeb && !order.isOnline);
        
        if (!isPOSOrder) return false;

        // Date Range Filter
        let orderDate = null;
        if (order.timestamp && order.timestamp.seconds) {
            orderDate = new Date(order.timestamp.seconds * 1000);
        } else if (order.date) {
            orderDate = new Date(order.date + 'T00:00:00');
        }

        if (orderDate) {
            orderDate.setHours(0,0,0,0);

            if (f.start) {
                const startDate = new Date(f.start + 'T00:00:00');
                startDate.setHours(0,0,0,0);
                if (orderDate < startDate) return false;
            }
            if (f.end) {
                const endDate = new Date(f.end + 'T00:00:00');
                endDate.setHours(0,0,0,0);
                if (orderDate > endDate) return false;
            }
        }

        // Show all POS orders regardless of status (including Pending for COD/Bank)
        return true;
    });

    // Sort by timestamp DESC (Newest First)
    filtered.sort((a, b) => {
        const timeA = a.timestamp?.seconds || 0;
        const timeB = b.timestamp?.seconds || 0;
        return timeB - timeA;
    });

    if (filtered.length === 0) {
        ordersDiv.className = 'order-grid';
        ordersDiv.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; background: rgba(15, 23, 42, 0.6); border: 1px dashed rgba(56, 189, 248, 0.2); border-radius: 20px; color: #94a3b8;">
                <div style="font-size: 3rem; margin-bottom: 0.8rem; opacity: 0.7;">📦</div>
                <div style="font-size: 1.1rem; font-weight: 800; color: #fff; margin-bottom: 0.3rem;">No POS Orders Found</div>
                <div style="font-size: 0.85rem; opacity: 0.7;">Try clearing or changing your search filters or date range.</div>
            </div>`;
        return;
    }

    // Quick KPIs Calculation for current filtered view
    let totalRevenue = 0;
    let cashRevenue = 0;
    let cardRevenue = 0;
    let bankRevenue = 0;
    let creditDue = 0;
    let totalItemsSum = 0;

    filtered.forEach(o => {
        const tot = Number(o.total) || 0;
        totalRevenue += tot;
        const method = (o.method || o.paymentMethod || '').toLowerCase();
        if (method.includes('cash')) {
            cashRevenue += tot;
        } else if (method.includes('card')) {
            cardRevenue += tot;
        } else if (method.includes('bank') || method.includes('transfer')) {
            bankRevenue += tot;
        } else if (method.includes('credit')) {
            const paid = Number(o.tenderedAmount) || 0;
            creditDue += Math.max(0, tot - paid);
        }
        if (Array.isArray(o.items)) {
            totalItemsSum += o.items.reduce((sum, it) => sum + Number(it.quantity || it.qty || 1), 0);
        }
    });

    const kpiSummaryHtml = `
        <div class="orders-kpi-bar" style="grid-column: 1 / -1;">
            <div class="orders-kpi-card" style="border-left: 4px solid #38bdf8;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Orders Volume</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: #fff; margin-top: 2px;">${filtered.length} <span style="font-size: 0.75rem; color: #38bdf8; font-weight: 700;">(${totalItemsSum} items)</span></div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(56, 189, 248, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">🧾</div>
            </div>

            <div class="orders-kpi-card" style="border-left: 4px solid #10b981;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Total Sales</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: #10b981; margin-top: 2px;">LKR ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(16, 185, 129, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">💰</div>
            </div>

            <div class="orders-kpi-card" style="border-left: 4px solid #06b6d4;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Cash Collected</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: #06b6d4; margin-top: 2px;">LKR ${cashRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(6, 182, 212, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">💵</div>
            </div>

            <div class="orders-kpi-card" style="border-left: 4px solid #3b82f6;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Card Payments</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: #60a5fa; margin-top: 2px;">LKR ${cardRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(59, 130, 246, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">💳</div>
            </div>

            <div class="orders-kpi-card" style="border-left: 4px solid #8b5cf6;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Bank Transfer</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: #a78bfa; margin-top: 2px;">LKR ${bankRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(139, 92, 246, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">🏦</div>
            </div>

            <div class="orders-kpi-card" style="border-left: 4px solid #ef4444;">
                <div>
                    <div style="font-size: 0.72rem; text-transform: uppercase; color: #94a3b8; font-weight: 800; letter-spacing: 0.5px;">Credit Outstanding</div>
                    <div style="font-size: 1.35rem; font-weight: 900; color: ${creditDue > 0 ? '#ef4444' : '#94a3b8'}; margin-top: 2px;">LKR ${creditDue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(239, 68, 68, 0.12); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">⏳</div>
            </div>
        </div>
    `;

    const cardsHtml = filtered.map(order => {
        // Standardize ID display
        let displayId = order.orderId || "N/A";
        if (displayId.startsWith("#R-")) displayId = displayId.replace("#R-", "#POS-");
        else if (displayId.startsWith("R-")) displayId = "#POS-" + displayId.replace("R-", "");
        else if (!displayId.startsWith("#")) displayId = "#" + displayId;

        // Payment Method Label & Colors
        const payMethod = order.method || order.paymentMethod || 'Other';
        const methodLower = payMethod.toLowerCase();
        const methodColor = methodLower.includes('cash') ? '#10b981' : 
                          methodLower.includes('card') ? '#38bdf8' :
                          (methodLower.includes('bank') || methodLower.includes('transfer')) ? '#a78bfa' :
                          methodLower.includes('credit') ? '#ef4444' : 
                          methodLower.includes('cheque') ? '#f59e0b' : '#38bdf8';
        const chequeLabel = (methodLower === 'cheque' && order.chequeDate) ? ` (DUE: ${order.chequeDate})` : '';

        const isCredit = methodLower.includes('credit');
        const tenderedVal = Number(order.tenderedAmount) || 0;
        const totalVal = Number(order.total) || 0;
        const outstandingVal = Math.max(0, totalVal - tenderedVal);

        // Status badge color
        const stLower = (order.status || '').toLowerCase();
        const statusBg = stLower === 'delivered' ? 'rgba(16, 185, 129, 0.15)' : 
                         stLower === 'confirmed' ? 'rgba(56, 189, 248, 0.15)' :
                         stLower === 'processing' ? 'rgba(245, 158, 11, 0.15)' : 'rgba(148, 163, 184, 0.15)';
        const statusBorder = stLower === 'delivered' ? 'rgba(16, 185, 129, 0.35)' : 
                             stLower === 'confirmed' ? 'rgba(56, 189, 248, 0.35)' :
                             stLower === 'processing' ? 'rgba(245, 158, 11, 0.35)' : 'rgba(148, 163, 184, 0.35)';
        const statusColor = stLower === 'delivered' ? '#34d399' : 
                            stLower === 'confirmed' ? '#38bdf8' :
                            stLower === 'processing' ? '#fbbf24' : '#cbd5e1';

        // Items overview chips (up to 3 items + badge for remaining)
        const orderItems = Array.isArray(order.items) ? order.items : [];
        let itemsBadgesHtml = '';
        if (orderItems.length > 0) {
            const previewItems = orderItems.slice(0, 3);
            itemsBadgesHtml = previewItems.map(it => {
                const name = (it.name || it.productName || it.title || 'Item');
                const qty = Number(it.quantity || it.qty || 1);
                return `<span class="order-glass-chip" title="${name} x${qty}">
                    <b>${qty}×</b> ${name}
                </span>`;
            }).join(' ');
            if (orderItems.length > 3) {
                itemsBadgesHtml += ` <span style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 2px 7px; border-radius: 7px; font-size: 0.7rem; font-weight: 800;">+${orderItems.length - 3}</span>`;
            }
        } else {
            itemsBadgesHtml = '<span style="color: rgba(255,255,255,0.35); font-size: 0.75rem; font-style: italic;">Standard POS Receipt</span>';
        }

        const branchName = order.branchName || order.branch || '';
        const cashierName = order.staffName || order.cashier || '';
        const customerName = order.userName || order.customerName || 'Walk-in Customer';
        const customerPhone = order.phone || order.customerPhone || '';
        const firstLetter = customerName.charAt(0).toUpperCase() || 'C';

        return `
            <div class="order-card order-glass-card" onclick="window.openModernInvoice('${order.docId}')">
                <!-- Card Header -->
                <div class="order-glass-header">
                    <div>
                        <div class="order-glass-id">
                            <span>🧾</span> ${displayId}
                        </div>
                        <div class="order-glass-time">
                            <span>🕒</span> ${order.date || ''} ${order.time ? `• ${order.time}` : ''}
                        </div>
                    </div>
                    <span style="background: ${statusBg}; color: ${statusColor}; border: 1px solid ${statusBorder}; padding: 4px 10px; border-radius: 50px; font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">
                        ${order.status || 'Delivered'}
                    </span>
                </div>

                <!-- Customer Info -->
                <div class="order-glass-customer">
                    <div class="order-glass-cust-avatar">${firstLetter}</div>
                    <div style="flex: 1; min-width: 0;">
                        <div style="font-weight: 800; color: #fff; font-size: 0.92rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            ${customerName}
                        </div>
                        <div style="font-size: 0.74rem; color: #94a3b8; margin-top: 1px; display: flex; align-items: center; gap: 4px;">
                            ${customerPhone ? `<span>📞</span> <a href="tel:${customerPhone}" onclick="event.stopPropagation()" style="color: #38bdf8; text-decoration: none;">${customerPhone}</a>` : '<span style="opacity: 0.6;">Walk-in (No Phone)</span>'}
                        </div>
                    </div>
                </div>

                <!-- Purchased Items Chips -->
                <div class="order-glass-items-box">
                    <div style="font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Purchased Items</div>
                    <div class="order-glass-chips">
                        ${itemsBadgesHtml}
                    </div>
                </div>

                <!-- Branch & Cashier Metadata -->
                <div class="order-glass-meta-row">
                    <div>${branchName ? `🏢 ${branchName}` : '🏢 Main POS'}</div>
                    <div>${cashierName ? `👤 ${cashierName}` : '👤 Cashier'}</div>
                </div>

                ${(order.status === 'Void' || order.status === 'Voided' || order.voidedBy) ? `
                    <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 8px; padding: 6px 10px; margin-top: 6px; font-size: 0.72rem; color: #f87171;">
                        <div style="font-weight: 800;">🚨 VOIDED / CANCELLED BILL</div>
                        <div style="color: #fff; font-weight: 600; margin-top: 2px;">
                            Authorized by: ${(() => {
                                let name = order.voidedBy || 'System Admin';
                                let role = order.voidedByRole || 'Admin';
                                if (name.includes('@') || name.toLowerCase() === 'ceo' || name.toLowerCase() === 'mec@gmail.com') {
                                    const emp = (window.allEmployees || []).find(e => 
                                        (e.email && e.email.toLowerCase() === name.toLowerCase()) || 
                                        (e.username && e.username.toLowerCase() === name.toLowerCase())
                                    );
                                    if (emp) {
                                        name = emp.name || emp.fullName || emp.username || name;
                                        role = emp.designation || emp.role_access || role;
                                    } else if (name.toLowerCase() === 'malinduec@gmail.com') {
                                        name = 'Malindu Shamesh';
                                        role = 'CEO / Super Admin';
                                    } else if (name.toLowerCase() === 'mec@gmail.com' || name.toLowerCase() === 'ceo') {
                                        name = 'CEO Admin';
                                        role = 'CEO';
                                    }
                                }
                                return `${name} (${role})`;
                            })()}
                        </div>
                    </div>
                ` : ''}

                <!-- Card Footer & Actions -->
                <div class="order-glass-footer">
                    <div>
                        <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px;">
                            <span style="background: ${methodColor}18; color: ${methodColor}; border: 1px solid ${methodColor}40; padding: 2px 8px; border-radius: 50px; font-weight: 800; font-size: 0.68rem; text-transform: uppercase;">
                                ${payMethod}${chequeLabel}
                            </span>
                        </div>
                        <div class="order-glass-total">
                            LKR ${(totalVal).toFixed(2)}
                        </div>
                        ${isCredit ? `
                            <div style="font-size: 0.68rem; color: #ef4444; font-weight: 800; margin-top: 2px;">Due: LKR ${outstandingVal.toFixed(2)}</div>
                        ` : ''}
                    </div>

                    <div class="order-glass-actions" onclick="event.stopPropagation()">
                        <button onclick="window.openModernInvoice('${order.docId}')" class="order-glass-btn" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3);" title="View Invoice">
                            📄 Bill
                        </button>
                        <button onclick="window.printOrderInvoice('${order.docId}')" class="order-glass-btn" style="background: rgba(16, 185, 129, 0.18); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.35);" title="Print Thermal / POS Receipt">
                            🖨️ Receipt
                        </button>
                        <button onclick="window.openEditOrderModal('${order.docId}')" class="order-glass-btn" style="background: rgba(99, 102, 241, 0.15); color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.3);" title="Edit Order">
                            ✏️
                        </button>
                        <button onclick="window.voidOrder('${order.docId}', '${order.orderId}')" class="order-glass-btn" style="background: rgba(239, 68, 68, 0.2); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.4);" title="Void Order & Return Stock">
                            🗑️
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    ordersDiv.className = 'orders-glass-grid';
    ordersDiv.innerHTML = `
        ${kpiSummaryHtml}
        ${cardsHtml}
    `;

    setTimeout(() => {}, 100);
};

window.showOrderTracking = (order) => {
    const panel = document.getElementById('epinics-live-tracking-panel');
    if (!panel) return;

    panel.style.display = 'block';
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });

    document.getElementById('tracking-order-id').innerText = `Tracking Order #${order.orderId || order.docId}`;
    document.getElementById('tracking-status-badge').innerText = order.status.toUpperCase();

    // Reset steps
    const steps = order.isShopPending === true || order.deliveryMethod === 'pickup'
        ? ['Pending', 'Confirmed', 'Processing', 'Ready to Pickup', 'Completed']
        : ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Delivered'];
    const currentStatusIndex = steps.indexOf(order.status);
    
    let progressWidth = 0;
    if (currentStatusIndex !== -1) {
        progressWidth = (currentStatusIndex / (steps.length - 1)) * 100;
    }

    document.getElementById('tracking-progress-fill').style.width = `${progressWidth}%`;

    steps.forEach((step, idx) => {
        const stepEl = document.getElementById(`step-${step.toLowerCase()}`);
        if (!stepEl) return;
        
        stepEl.classList.remove('active', 'completed');
        if (idx < currentStatusIndex) {
            stepEl.classList.add('completed');
        } else if (idx === currentStatusIndex) {
            stepEl.classList.add('active');
        }
    });
};

window.confirmStatusUpdate = async (docId, currentStatus) => {
    const s = document.createElement('div');
    s.id = "status-update-overlay";
    s.innerHTML = `
    <div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:999999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(5px);">
        <div style="background:#0f172a;padding:30px;border-radius:24px;border:1px solid rgba(255,255,255,0.1);width:400px;box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);">
            <h3 style="color:white;margin-bottom:20px;font-size:1.25rem;">Update Order Status</h3>
            
            <p style="color:rgba(255,255,255,0.6);margin-bottom:8px;font-size:0.85rem;">Select Status:</p>
            <select id="u-stat-${docId}" onchange="window._toggleReasonField('${docId}')" style="padding:12px;width:100%;border-radius:12px;border:1px solid rgba(255,255,255,0.2);background:#1e293b;color:white;margin-bottom:20px;box-sizing:border-box;font-size:1rem;outline:none;cursor:pointer;">
                <option value="Pending" ${currentStatus === 'Pending' ? 'selected' : ''}>Pending</option>
                <option value="Processing" ${currentStatus === 'Processing' ? 'selected' : ''}>Processing</option>
                <option value="Ready to Pickup" ${currentStatus === 'Ready to Pickup' ? 'selected' : ''}>Ready to Pickup</option>
                <option value="Shipped" ${currentStatus === 'Shipped' ? 'selected' : ''}>Shipped</option>
                <option value="Delivered" ${currentStatus === 'Delivered' ? 'selected' : ''}>Delivered</option>
                <option value="Void" ${currentStatus === 'Void' ? 'selected' : ''}>Void</option>
            </select>

            <div id="void-reason-container-${docId}" style="display: ${currentStatus === 'Void' ? 'block' : 'none'}; margin-bottom:20px;">
                <p style="color:rgba(255,255,255,0.6);margin-bottom:8px;font-size:0.85rem;">Reason for Voiding:</p>
                <textarea id="u-reason-${docId}" placeholder="e.g. Customer cancelled, Out of stock..." style="padding:12px;width:100%;border-radius:12px;border:1px solid #ef4444;background:rgba(239, 68, 68, 0.05);color:white;box-sizing:border-box;font-size:1rem;outline:none;height:100px;resize:none;"></textarea>
            </div>

            <div style="display:flex;gap:12px;">
                <button onclick="window._doStat('${docId}', this)" style="flex:2;padding:14px;background:#38bdf8;border:none;border-radius:12px;font-weight:bold;cursor:pointer;color:#0f172a;transition:all 0.2s;">Update Status</button>
                <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" style="flex:1;padding:14px;background:transparent;border:1px solid rgba(255,255,255,0.2);color:white;border-radius:12px;cursor:pointer;transition:all 0.2s;">Cancel</button>
            </div>
        </div>
    </div>`;
    document.body.appendChild(s);
};

window._toggleReasonField = (docId) => {
    const status = document.getElementById(`u-stat-${docId}`).value;
    const reasonContainer = document.getElementById(`void-reason-container-${docId}`);
    if (status === 'Void') {
        reasonContainer.style.display = 'block';
    } else {
        reasonContainer.style.display = 'none';
    }
};

window._doStat = async (docId, btnRef) => {
    const overlay = document.getElementById('status-update-overlay');
    const status = document.getElementById('u-stat-' + docId).value;
    const reason = document.getElementById('u-reason-' + docId)?.value || '';

    if (status) {
        if (status === 'Void' && !reason.trim()) {
            window.showToast("Please provide a reason for voiding this order.", "error");
            return;
        }
        btnRef.disabled = true;
        btnRef.innerText = "Updating...";
        try {
            const updatePayload = { 
                status: status,
                updatedAt: serverTimestamp()
            };
            if (status === 'Void') {
                updatePayload.voidReason = reason;
                updatePayload.voidDate = serverTimestamp();
            }

            await updateDoc(doc(db, 'orders', docId), updatePayload);
            window.showToast("Order status updated to " + status, "success");

            // Check if customer can be notified via SMS
            try {
                const order = (window.allOrders || []).find(o => o.docId === docId || o.orderId === docId);
                const phone = order?.phone || order?.customerPhone || order?.shippingAddress?.phone;
                if (phone && (status === 'Processing' || status === 'Shipped' || status === 'Delivered')) {
                    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
                    const autoMsg = `Dear ${order.customerName || order.userName || 'Customer'}, your order #${order.orderId} is now ${status}. Track: https://mecbookshop.com.lk/track.html?id=${order.orderId} - ${bizName}`;
                    if (typeof window.showCustomConfirm === 'function') {
                        if (await window.showCustomConfirm(`Dispatch SMS update to customer (${phone})?\n\n"${autoMsg}"`, "Order Status SMS", "✉️", "Send SMS", "Skip")) {
                            await window.dispatchSMS?.(phone, autoMsg);
                        }
                    }
                }
            } catch (notifyErr) {
                console.warn("Order SMS notify prompt error:", notifyErr);
            }
        } catch (e) { 
            console.error(e); 
            window.showToast("Error updating status!", "error");
        }
    }
    if (overlay) overlay.remove();
};

window.voidOrder = async (docId, orderId) => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.id = "void-prompt-overlay";
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:420px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); border:1px solid #ef4444; transform:scale(0.9); transition:transform 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        box.innerHTML = `
            <div style="font-weight:800; font-size:1.2rem; color:#ef4444; margin-bottom:0.5rem; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-trash-can"></i> VOID ORDER #${orderId}</div>
            <div style="font-size:0.95rem; opacity:0.8; margin-bottom:1.5rem;">Manager authorization is required to void this order.</div>
            
            <div style="display:grid; gap:12px; margin-bottom:1.5rem;">
                <input type="text" id="v-user" placeholder="Manager Username" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; outline:none; focus:border:#ef4444;">
                <input type="password" id="v-pass" placeholder="Manager Password" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); padding:1rem; border-radius:12px; color:white; font-size:1rem; outline:none; focus:border:#ef4444;">
                <div style="margin-top:10px;">
                    <p style="font-size:0.8rem; color:#ef4444; margin-bottom:6px; font-weight:700;">Reason for Voiding (Mandatory):</p>
                    <textarea id="v-reason" placeholder="e.g. Returned / Error / Custom reason..." style="width:100%; box-sizing:border-box; background:rgba(239, 68, 68, 0.05); border:1px solid rgba(239, 68, 68, 0.3); padding:1rem; border-radius:12px; color:white; font-size:1rem; outline:none; height:100px; resize:none;"></textarea>
                </div>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button id="v-cancel" style="background:rgba(255,255,255,0.05); color:#94a3b8; border:none; padding:1rem 1.5rem; border-radius:12px; cursor:pointer; font-weight:600;">Cancel</button>
                <button id="v-ok" style="background:linear-gradient(135deg, #ef4444 0%, #991b1b 100%); color:white; border:none; padding:1rem 2rem; border-radius:12px; cursor:pointer; font-weight:800; box-shadow:0 10px 20px rgba(239,68,68,0.2);">CONFIRM VOID</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
            document.getElementById('v-user').focus();
        });

        const close = () => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => { overlay.remove(); resolve(false); }, 200);
        };

        document.getElementById('v-cancel').onclick = close;
        document.getElementById('v-ok').onclick = async () => {
            const user = document.getElementById('v-user').value.trim();
            const pass = document.getElementById('v-pass').value;
            const reason = document.getElementById('v-reason').value.trim();

            if (!user || !pass || !reason) {
                window.showToast("❌ Please fill in all fields including Reason!", "warning");
                return;
            }

            // Fetch Order to verify ownership
            let orderStoreId = null;
            try {
                const docSnap = await getDoc(doc(db, 'orders', docId));
                if (docSnap.exists()) {
                    orderStoreId = docSnap.data().storeId;
                }
            } catch (e) {
                console.error("Error reading order for storeId verification:", e);
            }
            if (!orderStoreId) {
                orderStoreId = window.getStoreId();
            }

            // Verify Credentials
            const normUser = user.toLowerCase().trim();
            const isCEOUser = (normUser === 'ceo' || normUser === 'ceo admin' || normUser === 'ceo_admin' || normUser === 'ceo-admin');
            const isAppSuperAdmin = (normUser === 'malinduec@gmail.com' && (pass === 'malindu123' || pass === 'mec123')) ||
                                    (normUser === 'mecposadmin@gmail.com' && pass === 'mecpos123') ||
                                    (isCEOUser && (pass === 'malindu123' || pass === 'mec123' || pass === 'admin123' || pass === 'ceo123' || pass === '1234' || pass === '123'));

            // Store Owners credentials
            const isMecOwner = ((normUser === 'mecbookshop@gmail.com' || normUser === 'mecbookshop' || normUser === 'mec' || normUser === 'owner') && (pass === 'mec123' || pass === 'malindu123'));
            const isDJOwner = ((normUser === 'ireshadinali@gmail.com' || normUser === 'iresha' || normUser === 'djowner') && (pass === 'ireshadinali123' || pass === 'malindu123'));
            const isLegacyManager = (pass === 'mec123'); // Support legacy manager password check

            const validRoles = ['SuperAdmin', 'CEO_Admin', 'Admin', 'Manager', 'CEO', 'Owner', 'Proprietor', 'Founder', 'Director'];
            const staff = (window.allEmployees || []).find(e => 
                (e.username?.toLowerCase() === normUser || e.email?.toLowerCase() === normUser) && 
                e.password === pass
            );

            if (!isAppSuperAdmin && !isCEOUser && !isMecOwner && !isDJOwner && !isLegacyManager && (!staff || !validRoles.some(r => (staff.role_access || '').toLowerCase().includes(r.toLowerCase()) || (staff.designation || '').toLowerCase().includes(r.toLowerCase())))) {
                window.showToast("❌ Unauthorized Access!", "error");
                return;
            }

            const isMecStore = !orderStoreId || orderStoreId === 'mec-book-shop' || orderStoreId === 'mec-pos-shop' || orderStoreId === 'mec-pos' || orderStoreId === 'mec-pos-shop-v2';
            const isDJStore = orderStoreId && (
                orderStoreId === 'd-and-j-online-marketing' ||
                orderStoreId === 'd-j-online-marketing' ||
                orderStoreId === 'd-and-j-online-mart' ||
                orderStoreId.includes('d-and-j') ||
                orderStoreId.includes('d-j') ||
                orderStoreId.includes('iresha') ||
                orderStoreId.includes('marketing')
            );

            // Restrict owner credentials to their specific store
            if (isMecOwner && !isMecStore) {
                window.showToast("❌ Unauthorized Shop Access! MEC Owner cannot delete D&J data.", "error");
                return;
            }
            if (isDJOwner && !isDJStore) {
                window.showToast("❌ Unauthorized Shop Access! D&J Owner cannot delete MEC data.", "error");
                return;
            }
            if (isLegacyManager && !isMecStore && !isCEOUser && !isAppSuperAdmin) {
                window.showToast("❌ Unauthorized Shop Access!", "error");
                return;
            }
            if (staff && staff.storeId && staff.storeId !== orderStoreId && !isCEOUser && !isAppSuperAdmin) {
                window.showToast("❌ Unauthorized Shop Access!", "error");
                return;
            }

            try {
                const btn = document.getElementById('v-ok');
                btn.disabled = true;

                let authorizerName = user;
                let authorizerRole = 'Staff';

                if (normUser === 'malinduec@gmail.com') {
                    authorizerName = 'Malindu Shamesh';
                    authorizerRole = 'System Super Admin';
                } else if (normUser === 'mecposadmin@gmail.com') {
                    authorizerName = 'MEC Cloud Admin';
                    authorizerRole = 'System Super Admin';
                } else if (isCEOUser) {
                    authorizerName = 'CEO Admin';
                    authorizerRole = 'CEO';
                } else if (isMecOwner) {
                    authorizerName = 'MEC Owner';
                    authorizerRole = 'Proprietor / Owner';
                } else if (isDJOwner) {
                    authorizerName = 'D&J Owner';
                    authorizerRole = 'Proprietor / Owner';
                } else if (staff) {
                    authorizerName = staff.name || staff.fullName || staff.username || user;
                    authorizerRole = staff.designation || staff.role_access || 'Staff';
                } else if (isAppSuperAdmin) {
                    authorizerName = 'System Super Admin';
                    authorizerRole = 'System Super Admin';
                } else if (isLegacyManager) {
                    authorizerName = 'Manager Admin';
                    authorizerRole = 'Manager';
                }

                // Permanent delete restricted exclusively to CEO, Owner (Proprietor), & Super Admin (malinduec@gmail.com)
                const canPermanentDelete = (
                    normUser === 'malinduec@gmail.com' ||
                    normUser === 'mecposadmin@gmail.com' ||
                    isAppSuperAdmin ||
                    isCEOUser ||
                    isMecOwner ||
                    isDJOwner ||
                    (staff && (
                        ['ceo', 'owner', 'proprietor', 'superadmin', 'super admin', 'founder', 'director'].some(r => 
                            (staff.role_access || '').toLowerCase().includes(r) ||
                            (staff.designation || '').toLowerCase().includes(r)
                        )
                    )) ||
                    ['ceo', 'owner', 'proprietor', 'super admin', 'superadmin', 'founder', 'director'].some(r => 
                        (authorizerRole || '').toLowerCase().includes(r)
                    )
                );

                if (canPermanentDelete) {
                    let operatorInfo = `${authorizerRole} (${authorizerName})`;
                    overlay.style.display = 'none'; // Hide parent void overlay so confirmation modal is clearly visible
                    
                    const choice = await (typeof window.showDeleteOrVoidModal === 'function' 
                        ? window.showDeleteOrVoidModal({
                            title: "Permanent Delete Confirmation",
                            operatorInfo: operatorInfo,
                            targetName: `Order #${orderId}`
                        }) 
                        : window.asyncPrompt(`🚨 ${operatorInfo.toUpperCase()} DETECTED\n\nType 'DELETE' to PERMANENTLY remove this order from database.\nLeave blank or type anything else to just VOID:`, "Permanent Delete Confirmation", "text")
                    );

                    if (choice === null) {
                        // User clicked cancel in the choice modal
                        overlay.style.display = 'flex';
                        btn.disabled = false;
                        btn.innerText = "CONFIRM VOID";
                        return;
                    }

                    if (choice && choice.trim().toUpperCase() === 'DELETE') {
                        await deleteDoc(doc(db, 'orders', docId));
                        window.showToast("✅ Order #" + orderId + " PERMANENTLY DELETED.", "success");
                        overlay.remove();
                        resolve(true);
                        return;
                    }
                    // If choice is 'VOID', continue below to mark order as voided
                }

                btn.innerText = "Voiding...";
                
                await updateDoc(doc(db, 'orders', docId), { 
                    status: 'Voided',
                    voidReason: reason,
                    timestamp: serverTimestamp(),
                    date: new Date().toLocaleDateString(),
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                    voidDate: serverTimestamp(),
                    voidedBy: authorizerName,
                    voidedByRole: authorizerRole,
                    updatedAt: serverTimestamp()
                });

                window.showToast(`✅ Order #${orderId} has been VOIDED by ${authorizerName} (${authorizerRole}).`, "success");
                close();
            } catch (e) {
                console.error(e);
                window.showToast("❌ Failed to update order.", "error");
                document.getElementById('v-ok').disabled = false;
                document.getElementById('v-ok').innerText = "CONFIRM VOID";
            }
        };
    });
};

// window.openModernInvoice is handled by admin.js for premium UI

window.downloadOrdersCSV = () => {
    const orders = window.allOrders || [];
    let csv = "OrderID,Customer,Phone,Total,Status,Date\n";
    orders.forEach(o => {
        const name = window.escapeCSV(o.userName || 'Walk-in');
        const phone = window.escapeCSV(o.phone || o.customerPhone || '-');
        csv += `"${o.orderId}","${name}","${phone}",${o.total || 0},"${o.status}","${o.date}"\n`;
    });
    window.downloadFile?.(csv, "Orders_Report.csv");
};

window.printOrderInvoice = (docId) => {
    const order = (window.allOrders || []).find(o => o.docId === docId || o.orderId === docId);
    if (!order) {
        if (window.showToast) window.showToast("Order not found for printing.", "warning");
        return;
    }
    if (typeof window.printPOSReceipt === 'function') {
        window.printPOSReceipt(order);
    } else {
        if (window.showToast) window.showToast("Print engine not ready.", "error");
    }
};

// Web Orders Page Logic
window.activeWebPageTab = 'Pending';
window.webOrderDateFilters = {
    Pending: '',
    Processing: '',
    Shipped: '',
    Completed: ''
};

function getOrderYYYYMMDD(order) {
    if (!order) return '';
    // 1. Check timestamp / createdAt
    const ts = order.timestamp || order.createdAt;
    if (ts && ts.seconds) {
        const d = new Date(ts.seconds * 1000);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }
    // 2. Check date string
    const dStr = (order.date || '').toString().trim();
    if (dStr) {
        const ymd = dStr.match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (ymd) return `${ymd[1]}-${ymd[2]}-${ymd[3]}`;
        const slash = dStr.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (slash) {
            let p1 = parseInt(slash[1], 10);
            let p2 = parseInt(slash[2], 10);
            let year = slash[3];
            let day = String(p1).padStart(2, '0');
            let month = String(p2).padStart(2, '0');
            if (p1 > 12 && p2 <= 12) {
                day = String(p1).padStart(2, '0');
                month = String(p2).padStart(2, '0');
            } else if (p2 > 12 && p1 <= 12) {
                month = String(p1).padStart(2, '0');
                day = String(p2).padStart(2, '0');
            }
            return `${year}-${month}-${day}`;
        }
    }
    // 3. Check ORD-<epoch_ms>
    const oid = (order.orderId || order.docId || '').toString();
    const ordMatch = oid.match(/ORD-(\d{10,13})/i);
    if (ordMatch) {
        const rawNum = parseInt(ordMatch[1], 10);
        const ms = rawNum > 100000000000 ? rawNum : rawNum * 1000;
        const d = new Date(ms);
        if (!isNaN(d.getTime())) {
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${day}`;
        }
    }
    return '';
}

window.switchWebPageTab = (tab) => {
    window.activeWebPageTab = tab;
    document.querySelectorAll('#section-web-orders .sub-tab').forEach(t => t.classList.remove('active'));
    document.getElementById(`web-page-tab-${tab}`)?.classList.add('active');

    // Sync tab-specific date filter to the date picker UI
    window.webOrderDateFilters = window.webOrderDateFilters || {};
    const tabDate = window.webOrderDateFilters[tab] || '';
    const dateInput = document.getElementById('web-order-date');
    const clearBtn = document.getElementById('web-order-date-clear-btn');
    if (dateInput) dateInput.value = tabDate;
    if (clearBtn) clearBtn.style.display = tabDate ? 'inline-block' : 'none';

    window.renderWebOrdersPage();
};

window.onWebOrderDateChange = (val) => {
    const activeTab = window.activeWebPageTab || 'Pending';
    window.webOrderDateFilters = window.webOrderDateFilters || {};
    window.webOrderDateFilters[activeTab] = val;
    const clearBtn = document.getElementById('web-order-date-clear-btn');
    if (clearBtn) clearBtn.style.display = val ? 'inline-block' : 'none';
    window.renderWebOrdersPage();
};

window.clearWebOrderDateFilter = () => {
    const activeTab = window.activeWebPageTab || 'Pending';
    window.webOrderDateFilters = window.webOrderDateFilters || {};
    window.webOrderDateFilters[activeTab] = '';
    const dateInput = document.getElementById('web-order-date');
    const clearBtn = document.getElementById('web-order-date-clear-btn');
    if (dateInput) dateInput.value = '';
    if (clearBtn) clearBtn.style.display = 'none';
    window.renderWebOrdersPage();
};

window.sendWebOrderSMS = async (docId) => {
    const order = (window.allOrders || []).find(o => o.docId === docId || o.orderId === docId);
    if (!order) return window.showToast("Order not found.", "warning");

    const phone = order.phone || order.customerPhone || order.shippingAddress?.phone;
    if (!phone) return window.showToast("No customer phone number found for this order.", "warning");

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const status = order.status || 'Pending';
    const total = parseFloat(order.total || order.grandTotal || 0).toFixed(2);
    const defaultMsg = `Dear ${order.customerName || order.userName || 'Customer'}, your order #${order.orderId} (${status}) total LKR ${total}. Track online: https://mecbookshop.com.lk/track.html?id=${order.orderId} - ${bizName}`;

    const msg = await window.asyncPrompt(`Enter SMS message for Order #${order.orderId}:`, "Dispatch Order SMS (SMSLenz)", "text", defaultMsg);
    if (!msg) return;

    if (typeof window.dispatchSMS === 'function') {
        await window.dispatchSMS(phone, msg);
    } else {
        window.showToast("SMS engine not initialized.", "error");
    }
};

window.sendWebOrderWhatsApp = async (docId) => {
    const order = (window.allOrders || []).find(o => o.docId === docId || o.orderId === docId);
    if (!order) return window.showToast("Order not found.", "warning");

    const phone = order.phone || order.customerPhone || order.shippingAddress?.phone;
    if (!phone) return window.showToast("No customer phone number found for this order.", "warning");

    const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
    const status = order.status || 'Pending';
    const total = parseFloat(order.total || order.grandTotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const items = (order.items || []).map(i => `• ${i.name || i.title} (x${i.quantity || 1}) - LKR ${((i.price || 0) * (i.quantity || 1)).toLocaleString()}`).join('\n');

    let defaultMsg = `*ORDER UPDATE - #${order.orderId}*\n*${bizName.toUpperCase()}*\n----------------------------------\n*Customer:* ${order.customerName || order.userName || 'Valued Customer'}\n*Status:* ${status.toUpperCase()}\n*Date:* ${order.date || new Date().toLocaleDateString()}\n----------------------------------\n${items ? items + '\n----------------------------------\n' : ''}*TOTAL:* LKR ${total}\n*Payment Method:* ${order.method || order.paymentMethod || 'COD'}\n\n*Track Online:* https://mecbookshop.com.lk/track.html?id=${order.orderId}\n\nThank you for choosing ${bizName}! 📦✨`;

    const msg = await window.asyncPrompt(`Review or edit WhatsApp message for Order #${order.orderId}:`, "Dispatch Order WhatsApp", "text", defaultMsg);
    if (!msg) return;

    if (typeof window.dispatchWhatsApp === 'function') {
        await window.dispatchWhatsApp(phone, msg);
    } else {
        window.showToast("WhatsApp engine not initialized.", "error");
    }
};

window.updateWebOrderTrackingStatus = async (docId, newStatus) => {
    try {
        await updateDoc(doc(db, 'orders', docId), { 
            status: newStatus,
            updatedAt: serverTimestamp()
        });
        window.showToast("Order status updated to " + newStatus, "success");

        // Offer to notify customer via SMS if phone is available
        try {
            const order = (window.allOrders || []).find(o => o.docId === docId || o.orderId === docId);
            const phone = order?.phone || order?.customerPhone || order?.shippingAddress?.phone;
            if (phone && (newStatus === 'Processing' || newStatus === 'Shipped' || newStatus === 'Delivered')) {
                const bizName = window.systemConfig?.bizName || 'MEC Book Shop';
                const autoMsg = `Dear ${order.customerName || order.userName || 'Customer'}, your order #${order.orderId} is now ${newStatus}. Track: https://mecbookshop.com.lk/track.html?id=${order.orderId} - ${bizName}`;
                if (typeof window.showCustomConfirm === 'function') {
                    if (await window.showCustomConfirm(`Dispatch SMS update to customer (${phone})?\n\n"${autoMsg}"`, "Order Status SMS", "✉️", "Send SMS", "Skip")) {
                        await window.dispatchSMS?.(phone, autoMsg);
                    }
                }
            }
        } catch (smsAlertErr) {
            console.warn("Status SMS alert warn:", smsAlertErr);
        }
    } catch (e) {
        console.error(e);
        window.showToast("Error updating status!", "error");
    }
};

window.renderWebOrdersPage = () => {
    const list = document.getElementById('web-orders-page-list');
    if (!list) return;

    const orders = window.allOrders || [];
    const search = document.getElementById('web-order-search')?.value.toLowerCase().trim() || '';
    const storeId = window.getStoreId();
    const activeTab = window.activeWebPageTab || 'Pending';

    window.webOrderDateFilters = window.webOrderDateFilters || {};
    const tabDate = window.webOrderDateFilters[activeTab] || '';

    // 1. Filter for only Delivery Orders (COD & Bank Transfer)
    const deliveryOrders = orders.filter(o => {
        if (!o) return false; 
        if (o.isPOS === true) return false;
        
        const oid = (o.orderId || '').toString().toUpperCase();
        if (oid.startsWith('#POS') || oid.startsWith('R-') || oid.startsWith('#R-') || oid.startsWith('POS_')) return false;

        const method = (o.method || o.paymentMethod || '').toLowerCase();
        const isDeliveryType = method.includes('cod') || method.includes('bank');
        if (!isDeliveryType) return false;

        // Extra check: Exclude any Shop Pickup that might have slipped through
        if (o.isShopPending === true || 
            method.includes('shop') || 
            method.includes('pick') ||
            (o.deliveryMethod || '').toLowerCase().includes('shop')) return false;
            
        if (o.storeId !== storeId && storeId !== 'master') return false;
        
        return true;
    });

    // 2. Filter by selected Tab Status
    let filtered = deliveryOrders.filter(o => {
        if (!o) return false; // Safety check
        if (activeTab === 'Completed') {
            return o.status === 'Completed' || o.status === 'Delivered' || o.status === 'Cancelled' || o.status === 'Void';
        }
        return o.status === activeTab;
    });

    // 3. Filter by Tab-Specific Date Selector
    if (tabDate) {
        filtered = filtered.filter(o => {
            if (!o) return false;
            return getOrderYYYYMMDD(o) === tabDate;
        });
    }

    // 4. Search filter: Customer Name, Phone Number, and Order Number
    if (search) {
        const cleanSearch = search.replace(/[\s\-\#]/g, '');
        filtered = filtered.filter(o => {
            if (!o) return false;
            const cName = ((o.userName || o.customerName || '')).toLowerCase();
            const oid = ((o.orderId || o.docId || o.id || '')).toLowerCase();
            const cleanOid = oid.replace(/[\s\-\#]/g, '');
            const phone = ((o.phone || o.customerPhone || o.phone2 || '')).toString();
            const cleanPhone = phone.replace(/[\s\-\#]/g, '');

            return cName.includes(search) ||
                   oid.includes(search) ||
                   (cleanSearch.length > 0 && cleanOid.includes(cleanSearch)) ||
                   phone.includes(search) ||
                   (cleanSearch.length > 0 && cleanPhone.includes(cleanSearch));
        });
    }

    if (filtered.length === 0) {
        let emptyMsg = `No ${activeTab.toLowerCase()} delivery orders found`;
        if (tabDate) emptyMsg += ` for date ${tabDate}`;
        if (search) emptyMsg += ` matching "${search}"`;
        list.innerHTML = `<div style="grid-column: 1/-1; padding: 4rem; text-align: center; color: #64748b;">${emptyMsg}.</div>`;
        return;
    }

    list.innerHTML = filtered.map(order => {
        if (!order) return ''; // Safety check
        let displayId = order.orderId || "WEB";
        if (!displayId.startsWith("#")) displayId = "#" + displayId;
        
        const methodLabel = order.method || order.paymentMethod || 'Web';
        const methodColor = methodLabel.toLowerCase().includes('bank') ? '#8b5cf6' : 
                           methodLabel.toLowerCase().includes('cod') ? '#f59e0b' : '#38bdf8';

        return `
            <div class="order-card glass-premium" onclick="window.viewOrderManagementDetails('${order.docId}')" style="padding:1.5rem; border:1px solid rgba(255,255,255,0.08); display: flex; flex-direction: column; gap: 15px; cursor: pointer;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div>
                        <div style="font-weight:900; color:${methodColor}; font-size:0.8rem; background:${methodColor}15; padding:2px 8px; border-radius:6px; display:inline-block; margin-bottom:5px;">${displayId}</div>
                        <div style="font-size:0.7rem; color:#64748b; font-weight:700;">${order.date || 'Today'}</div>
                    </div>
                    <div style="text-align:right;">
                        <span class="status-badge" style="background:rgba(245,158,11,0.1); color:#f59e0b; border:1px solid rgba(245,158,11,0.2); text-transform:uppercase;">${order.status || 'Pending'}</span>
                        <div style="font-size:0.65rem; color:#64748b; font-weight:800; margin-top:5px;">${methodLabel}</div>
                    </div>
                </div>

                <div>
                    <div style="font-size:1.1rem; font-weight:900; color:white;">${order.userName || 'Guest'}</div>
                    <div style="font-size:0.8rem; color:#94a3b8; font-weight:600;">📞 ${order.phone || order.userPhone || 'No Phone'}</div>
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600; margin-top:5px; background: rgba(0,0,0,0.2); padding: 5px; border-radius: 6px;">📍 ${order.address || ''}, ${order.city || ''}</div>
                </div>

                <div style="padding:10px; background:rgba(255,255,255,0.02); border-radius:12px; border:1px solid rgba(255,255,255,0.03);">
                    <div style="font-size:0.65rem; color:#64748b; font-weight:800; text-transform:uppercase; margin-bottom:5px;">Order Items</div>
                    <div style="font-size:0.85rem; color:#e2e8f0; font-weight:700;">${order.items?.length || 0} Products Selected</div>
                </div>

                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:10px; border-top:1px solid rgba(255,255,255,0.05);">
                    <div style="font-size:1.2rem; font-weight:900; color:#10b981;">Rs.${(order.total || 0).toLocaleString()}</div>
                    <div style="display:flex; gap:8px; align-items: center;">
                        <select onclick="event.stopPropagation()" onchange="window.updateWebOrderTrackingStatus('${order.docId}', this.value)" style="padding: 6px 12px; border-radius: 8px; background: #1e293b; color: white; border: 1px solid rgba(255,255,255,0.2); font-size: 0.8rem; font-weight: bold; outline: none; cursor: pointer;">
                            <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                            <option value="Processing" ${order.status === 'Processing' ? 'selected' : ''}>Processing</option>
                            <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Handed Over</option>
                            <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                            <option value="Cancelled" ${order.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                        </select>
                        <button onclick="event.stopPropagation(); window.confirmStatusUpdate('${order.docId}', '${order.status}')" class="action-btn" title="Advanced Update" style="padding: 6px 10px;"><i class="fa-solid fa-pen"></i></button>
                    </div>
                </div>

                <!-- Quick Export Row -->
                <div style="display:flex; flex-wrap: wrap; gap:8px; margin-top:10px; padding-top:10px; border-top:1px solid rgba(255,255,255,0.05);">
                    <button onclick="event.stopPropagation(); window.sendWebOrderSMS('${order.docId}')" class="action-btn" style="background: #0284c7; color: white; border: none; padding: 5px 12px; font-size: 0.75rem; font-weight: 800;" title="Send SMS via SMSLenz">✉️ SMS</button>
                    <button onclick="event.stopPropagation(); window.sendWebOrderWhatsApp('${order.docId}')" class="action-btn" style="background: #25D366; color: white; border: none; padding: 5px 12px; font-size: 0.75rem; font-weight: 800;" title="Send WhatsApp Message">💬 WA</button>
                    <button onclick="event.stopPropagation(); window.printOrderInvoice('${order.docId}')" class="action-btn" style="background: #10b981; color: white; border: none; padding: 5px 12px; font-size: 0.75rem; font-weight: 800;">🖨️ RECEIPT</button>
                    <button onclick="event.stopPropagation(); window.openModernInvoice('${order.docId}')" class="action-btn" style="background: #0ea5e9; color: white; border: none; padding: 5px 12px; font-size: 0.75rem; font-weight: 800;">📄 BILL</button>
                    <button onclick="event.stopPropagation(); window.quickExport('${order.docId}', 'waybill')" class="action-btn" style="background: #8b5cf6; color: white; border: none; padding: 5px 12px; font-size: 0.75rem; font-weight: 800;">📦 WAYBILL</button>
                </div>
            </div>
        `;
    }).join('');
};

let currentODMOrder = null;

window.viewOrderManagementDetails = async (docId) => {
    try {
        const orderDoc = await getDoc(doc(db, 'orders', docId));
        if (!orderDoc.exists()) return;
        
        const order = { docId: orderDoc.id, ...orderDoc.data() };
        currentODMOrder = order;

        document.getElementById('odm-order-id').innerText = '#' + (order.orderId || order.docId);
        document.getElementById('odm-date').innerText = (order.date || '') + ' | ' + (order.time || '');
        document.getElementById('odm-customer-name').innerText = order.userName || order.customerName || 'Walking Customer';
        document.getElementById('odm-customer-phone').innerText = order.phone || order.customerPhone || 'N/A';
        document.getElementById('odm-customer-address').innerText = order.address || 'No Address Provided';
        
        const deliveryPrice = order.deliveryPrice || 0;
        document.getElementById('odm-delivery-price').value = deliveryPrice;
        
        // Render Items
        const itemsContainer = document.getElementById('odm-items-container');
        if (order.items && order.items.length > 0) {
            let subtotal = 0;
            let itemsHtml = `
                <table style="width: 100%; border-collapse: collapse; color: #fff;">
                    <thead>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.1); text-align: left;">
                            <th style="padding: 10px 0; font-size: 0.8rem; color: var(--text-dim);">Product</th>
                            <th style="padding: 10px 0; font-size: 0.8rem; color: var(--text-dim); text-align: center;">Qty</th>
                            <th style="padding: 10px 0; font-size: 0.8rem; color: var(--text-dim); text-align: right;">Price</th>
                            <th style="padding: 10px 0; font-size: 0.8rem; color: var(--text-dim); text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody>`;
            
            order.items.forEach(item => {
                const total = (item.price || 0) * (item.quantity || 1);
                subtotal += total;
                itemsHtml += `
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
                        <td style="padding: 12px 0;">
                            <div style="font-weight: 600;">${item.name || 'Unknown Product'}</div>
                            <div style="font-size: 0.7rem; color: var(--text-dim);">${item.variant || ''}</div>
                        </td>
                        <td style="padding: 12px 0; text-align: center;">${item.quantity || 1}</td>
                        <td style="padding: 12px 0; text-align: right;">${(item.price || 0).toFixed(2)}</td>
                        <td style="padding: 12px 0; text-align: right; font-weight: 700;">${total.toFixed(2)}</td>
                    </tr>`;
            });
            
            itemsHtml += `</tbody></table>`;
            itemsContainer.innerHTML = itemsHtml;
            currentODMOrder.subtotal = subtotal;
        } else {
            itemsContainer.innerHTML = '<div style="color: var(--text-dim); padding: 20px; text-align: center;">No items found.</div>';
            currentODMOrder.subtotal = order.subtotal || order.total || 0;
        }

        // Show/hide discount details
        const discount = order.discount || 0;
        const discountRow = document.getElementById('odm-discount-row');
        const discountVal = document.getElementById('odm-discount');
        const couponLbl = document.getElementById('odm-coupon-code-lbl');
        if (discountRow && discountVal) {
            if (discount > 0) {
                discountRow.style.display = 'flex';
                discountVal.innerText = '- LKR ' + discount.toFixed(2);
                if (couponLbl) couponLbl.innerText = order.couponCode ? `(${order.couponCode})` : '';
            } else {
                discountRow.style.display = 'none';
            }
        }

        window.updateODMTotal();

        // --- Security Lock for Completed Orders ---
        const isLocked = ['Delivered', 'Completed', 'Cancelled', 'Void'].includes(order.status);
        const deliveryInput = document.getElementById('odm-delivery-price');
        const saveBtn = document.getElementById('odm-save-btn');
        
        if (deliveryInput) {
            deliveryInput.disabled = isLocked;
            deliveryInput.title = isLocked ? "Cannot edit a finalized order" : "";
        }
        
        if (saveBtn) {
            saveBtn.style.display = isLocked ? 'none' : 'block';
        }

        // Add visual lock message if needed
        let lockMsg = document.getElementById('odm-lock-msg');
        if (isLocked) {
            if (!lockMsg) {
                lockMsg = document.createElement('div');
                lockMsg.id = 'odm-lock-msg';
                lockMsg.style.cssText = 'color: #ef4444; font-size: 0.85rem; font-weight: 800; text-align: center; margin-top: 15px; padding: 12px; background: rgba(239, 68, 68, 0.1); border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.2);';
                lockMsg.innerHTML = '<i class="fa-solid fa-lock"></i> This order is finalized and cannot be edited.';
                saveBtn.parentElement.appendChild(lockMsg);
            } else {
                lockMsg.style.display = 'block';
            }
        } else if (lockMsg) {
            lockMsg.style.display = 'none';
        }

        document.getElementById('order-details-modal').style.display = 'flex';
    } catch (err) {
        console.error(err);
        alert('Error loading order details');
    }
};

window.updateODMTotal = () => {
    if (!currentODMOrder) return;
    const delivery = parseFloat(document.getElementById('odm-delivery-price').value) || 0;
    const subtotal = currentODMOrder.subtotal || 0;
    const discount = currentODMOrder.discount || 0;
    const grandTotal = Math.max(0, subtotal + delivery - discount);
    
    document.getElementById('odm-subtotal').innerText = 'LKR ' + subtotal.toFixed(2);
    document.getElementById('odm-grand-total').innerText = 'LKR ' + grandTotal.toFixed(2);
};

window.saveODMChanges = async () => {
    if (!currentODMOrder) return;
    
    // Security check
    if (['Delivered', 'Completed', 'Cancelled', 'Void'].includes(currentODMOrder.status)) {
        window.showToast("🔒 Security: Cannot modify a finalized order.", "error");
        return;
    }

    try {
        const delivery = parseFloat(document.getElementById('odm-delivery-price').value) || 0;
        const subtotal = currentODMOrder.subtotal || 0;
        const discount = currentODMOrder.discount || 0;
        const grandTotal = Math.max(0, subtotal + delivery - discount);
        
        await updateDoc(doc(db, 'orders', currentODMOrder.docId), {
            deliveryPrice: delivery,
            total: grandTotal
        });

        // Update local state so export reflects changes
        currentODMOrder.deliveryPrice = delivery;
        currentODMOrder.total = grandTotal;
        
        alert('Order updated successfully!');
        document.getElementById('order-details-modal').style.display = 'none';
    } catch (err) {
        console.error(err);
        alert('Failed to save changes');
    }
};

const getPremiumInvoiceHTML = (order) => {
    const config = window.STORE_CONFIG;
    const items = order.items || [];
    
    // Robustly calculate values for the summary
    const subtotal = order.subtotal || items.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 1)), 0);
    const delivery = order.deliveryPrice || (order.total - subtotal) || 0;
    const discount = order.discount || 0;
    const grandTotal = order.total || (subtotal + delivery - discount);
    const tendered = order.tenderedAmount || grandTotal;
    const change = order.cashBalance || (tendered - grandTotal);

    const payMethod = order.paymentMethod || 'Cash';
    const isCredit = (
        payMethod.toLowerCase().includes('credit') || 
        payMethod.toLowerCase().includes('unpaid') || 
        payMethod.toLowerCase().includes('debt') || 
        payMethod.toLowerCase().includes('due')
    ) && !payMethod.toLowerCase().includes('settled');
    const isVoid = (order.status || '').toLowerCase() === 'void';
    const isPaid = !isCredit && !isVoid;

    return `
        <div style="width: 100%; min-height: 290mm; background: #fff; font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', Arial, sans-serif; color: #333; display: flex; flex-direction: column; border: 1px solid #eee; position: relative;">
            
            ${isPaid ? `
            <div style="position: absolute; top: 120px; right: 80px; width: 130px; height: 130px; border: 4px solid #16a34a; border-radius: 50%; color: #16a34a; display: flex; align-items: center; justify-content: center; transform: rotate(-12deg); opacity: 0.85; z-index: 100; pointer-events: none; background: transparent; box-shadow: 0 0 0 3px transparent;">
                <div style="text-align: center; font-family: 'Montserrat', 'Segoe UI', Arial; font-weight: 900; line-height: 1;">
                    <span style="font-size: 26px; letter-spacing: 2px; display: block; border-bottom: 2px solid #16a34a; padding-bottom: 2px; margin-bottom: 2px; text-transform: uppercase;">PAID</span>
                    <span style="font-size: 8px; font-weight: 800; display: block; max-width: 100px; margin: 0 auto; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${(config.name || 'MEC BOOK SHOP').toUpperCase()}</span>
                </div>
            </div>
            ` : ''}

            <!-- Header Section -->
            <div style="display: flex; height: 100px; border-bottom: 3px solid #e11d48;">
                <div style="flex: 1.2; padding: 15px 30px; display: flex; align-items: center; gap: 12px;">
                    <img src="${config.logo}" style="width: 50px; height: 50px;">
                    <div style="max-width: 350px;">
                        <h1 style="margin: 0; font-size: 20px; font-weight: 900; color: #000; line-height: 1.1;">MEC Book Shop<br>& Communication</h1>
                        <p style="margin: 2px 0; color: #666; font-size: 11px;">${config.tagline}</p>
                    </div>
                </div>
                <div style="flex: 1; background: #333; color: #fff; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
                    <div style="position: absolute; left: -20px; top: 0; bottom: 0; width: 40px; background: #e11d48; transform: skewX(-15deg);"></div>
                    <h1 style="margin: 0; font-size: 32px; font-weight: 900; letter-spacing: 2px; position: relative; z-index: 2;">INVOICE</h1>
                </div>
            </div>

            <!-- Client & Order Info -->
            <div style="display: flex; justify-content: space-between; padding: 25px 40px;">
                <div>
                    <p style="margin: 0; color: #999; font-size: 11px; text-transform: uppercase;">Invoice To:</p>
                    <h2 style="margin: 3px 0; color: #e11d48; font-size: 18px; font-weight: 900;">${(order.userName || order.customerName || 'Walking Customer').toUpperCase()}</h2>
                    <p style="margin: 0; font-weight: bold; color: #444; font-size: 13px;">Valued Customer</p>
                    <p style="margin: 3px 0; color: #666; font-size: 13px;">P: ${order.phone || order.customerPhone || 'N/A'}</p>
                </div>
                <div style="text-align: right;">
                    <div style="background: #333; color: #fff; padding: 6px 15px; font-weight: 900; font-size: 14px; margin-bottom: 8px; display: inline-block;">
                        INVOICE NO: ${String(order.orderId || order.docId).startsWith('#') ? (order.orderId || order.docId) : '#' + (order.orderId || order.docId)}
                    </div>
                    <p style="margin: 2px 0; color: #999; font-size: 11px;">Invoice Date</p>
                    <p style="margin: 2px 0; font-weight: bold; color: #444; font-size: 13px;">${order.date || ''}</p>
                </div>
            </div>

            <!-- Items Table -->
            <div style="flex: 1; padding: 0 40px;">
                <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                    <thead>
                        <tr style="background: #333; color: #fff;">
                            <th style="padding: 10px 20px; text-align: left; background: #e11d48; width: 40%;">Item description</th>
                            <th style="padding: 10px 10px; text-align: center; width: 10%;">Qty</th>
                            <th style="padding: 10px 10px; text-align: center; background: #e11d48; width: 15%;">Price</th>
                            <th style="padding: 10px 10px; text-align: center; width: 15%;">Discount</th>
                            <th style="padding: 10px 20px; text-align: right; background: #e11d48; width: 20%;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map(i => {
                            const itemPrice = parseFloat(i.price || 0);
                            const itemDiscount = parseFloat(i.discount || 0);
                            const qty = parseFloat(i.quantity || i.qty || 1);
                            const lineTotal = (itemPrice - itemDiscount) * qty;
                            return `
                                <tr style="border-bottom: 1px solid #f1f1f1;">
                                    <td style="padding: 10px 20px;">
                                        <div style="font-weight: bold; color: #333;">${i.name}</div>
                                        <div style="font-size: 11px; color: #999; margin-top: 2px;">${i.variant || i.selectedVariant || 'Default'}</div>
                                    </td>
                                    <td style="padding: 10px 10px; text-align: center; color: #333;">${qty}</td>
                                    <td style="padding: 10px 10px; text-align: center; color: #333;">Rs. ${itemPrice.toLocaleString()}</td>
                                    <td style="padding: 10px 10px; text-align: center; color: #e11d48; font-weight: 600;">${itemDiscount > 0 ? 'Rs. ' + itemDiscount.toLocaleString() : '-'}</td>
                                    <td style="padding: 10px 20px; text-align: right; font-weight: 800; color: #000;">Rs. ${lineTotal.toLocaleString()}</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>

            <!-- Totals -->
            <div style="display: flex; justify-content: flex-end; padding: 15px 40px;">
                <div style="width: 280px; font-size: 13px;">
                    <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #eee;">
                        <span style="color: #666;">Sub Total</span>
                        <span style="font-weight: bold;">Rs. ${subtotal.toLocaleString()}</span>
                    </div>
                    ${delivery > 0 ? `
                    <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #eee;">
                        <span style="color: #666;">Delivery Fee</span>
                        <span style="font-weight: bold;">Rs. ${delivery.toLocaleString()}</span>
                    </div>
                    ` : ''}
                    ${(order.tax || 0) > 0 ? `
                    <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #eee;">
                        <span style="color: #666;">Tax</span>
                        <span style="font-weight: bold;">Rs. ${(order.tax || 0).toLocaleString()}</span>
                    </div>
                    ` : ''}
                    <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #eee;">
                        <span style="color: #666;">Discount</span>
                        <span style="font-weight: bold;">Rs. ${discount.toLocaleString()}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #eee;">
                        <span style="color: #666;">Paid</span>
                        <span style="font-weight: 800;">Rs. ${tendered.toLocaleString()}</span>
                    </div>
                    <div style="background: #e11d48; color: #fff; display: flex; justify-content: space-between; padding: 8px 12px; margin-top: 8px; font-size: 14px; font-weight: 900;">
                        <span>Grand Total</span>
                        <span>Rs. ${grandTotal.toLocaleString()}</span>
                    </div>
                </div>
            </div>

            <!-- Footer Section -->
            <div style="padding: 20px 40px; margin-top: auto;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 30px;">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #333; font-size: 13px;">Payment method: <span style="font-weight: 900; color: #000;">${payMethod}</span></h4>
                        <p style="margin: 0; color: #999; font-size: 10px; line-height: 1.4;">
                            Goods once sold cannot be returned or exchanged. Warranty conditions apply as per manufacturer terms. Thank you for your business!
                        </p>
                    </div>
                    <div style="text-align: center; border-top: 1px solid #333; width: 200px; padding-top: 8px;">
                        <h4 style="margin: 0; text-transform: uppercase; font-size: 12px; font-weight: 900;">MEC BOOK SHOP</h4>
                        <p style="margin: 2px 0; color: #666; font-size: 10px;">Authorized Signatory</p>
                    </div>
                </div>
            </div>

            <!-- Bottom Contact Bar -->
            <div style="background: #333; padding: 8px 40px; display: flex; justify-content: space-between; align-items: center; border-top: 3px solid #e11d48;">
                <div style="display: flex; align-items: center; gap: 8px; color: #fff; font-size: 10px;">
                    <span style="color: #e11d48;">📞</span> ${config.phone}
                </div>
                <div style="display: flex; align-items: center; gap: 8px; color: #fff; font-size: 10px;">
                    <span style="color: #e11d48;">✉️</span> ${config.email}
                </div>
                <div style="display: flex; align-items: center; gap: 8px; color: #fff; font-size: 10px;">
                    <span style="color: #e11d48;">📍</span> ${config.address}
                </div>
            </div>
        </div>
    `;
};

window.exportODM_JPG = async () => {
    const order = currentODMOrder;
    if (!order) return;
    
    const exportDiv = document.createElement('div');
    exportDiv.style.position = 'absolute';
    exportDiv.style.left = '-9999px';
    exportDiv.innerHTML = getPremiumInvoiceHTML(order);
    
    document.body.appendChild(exportDiv);
    const canvas = await html2canvas(exportDiv, { backgroundColor: '#ffffff', scale: 2 });
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    const filename = `Invoice_${order.orderId || order.docId}.jpg`;

    if (window.electron) {
        window.electron.send('save-order-export', { base64Data: dataUrl, fileName: filename });
        window.showToast(`Saved to C:\\MEC_EXPORTS\\${filename}`, "success");
    } else {
        const link = document.createElement('a');
        link.download = filename;
        link.href = dataUrl;
        link.click();
    }
    document.body.removeChild(exportDiv);
};

window.exportODM_Waybill = async () => {
    const order = currentODMOrder;
    if (!order) return;
    
    const exportDiv = document.createElement('div');
    exportDiv.style.width = '600px';
    exportDiv.style.padding = '40px';
    exportDiv.style.background = '#ffffff';
    exportDiv.style.color = '#000000';
    exportDiv.style.fontFamily = 'Arial, sans-serif';
    exportDiv.style.position = 'absolute';
    exportDiv.style.left = '-9999px';
    exportDiv.style.border = '2px solid #000';
    
    exportDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; align-items: center;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <img src="${window.STORE_CONFIG.logo}" style="width: 60px; height: 60px;">
                <div style="text-align: left;">
                    <h1 style="margin: 0; font-size: 22px; font-weight: 900; letter-spacing: -0.5px;">${window.STORE_CONFIG.name}</h1>
                    <p style="margin: 2px 0; font-size: 10px; font-weight: bold;">${window.STORE_CONFIG.tagline}</p>
                    <p style="margin: 2px 0; font-size: 9px;">${window.STORE_CONFIG.address}</p>
                    <p style="margin: 2px 0; font-size: 9px; font-weight: 900;">Tel/WhatsApp: ${window.STORE_CONFIG.phone}</p>
                </div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 32px; font-weight: 900; border: 4px solid #000; padding: 5px 15px;">COD</div>
            </div>
        </div>

        <div style="margin-bottom: 25px;">
            <div style="font-size: 12px; font-weight: 900; text-decoration: underline; margin-bottom: 8px;">RECIPIENT / SHIP TO:</div>
            <div style="font-size: 24px; font-weight: 900; margin-bottom: 5px;">${(order.userName || order.customerName || 'N/A').toUpperCase()}</div>
            <div style="font-size: 18px; font-weight: 900; margin-bottom: 10px;">📞 ${order.phone || 'N/A'}</div>
            <div style="font-size: 16px; font-weight: bold; line-height: 1.4; border: 1px solid #000; padding: 15px; background: #f9f9f9;">
                ${(order.address || 'No Address Provided').toUpperCase()}<br>
                ${(order.city || '').toUpperCase()}
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <div style="border: 2px solid #000; padding: 15px; text-align: center;">
                <div style="font-size: 12px; font-weight: bold; margin-bottom: 5px;">ORDER ID</div>
                <div style="font-size: 18px; font-weight: 900;">#${order.orderId || order.docId}</div>
            </div>
            <div style="border: 2px solid #000; padding: 15px; text-align: center; background: #000; color: #fff;">
                <div style="font-size: 12px; font-weight: bold; margin-bottom: 5px;">CASH TO COLLECT</div>
                <div style="font-size: 24px; font-weight: 900;">LKR ${(order.total || 0).toLocaleString()}</div>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed #000; padding-top: 20px;">
            <div style="width: 120px; height: 120px; border: 1px solid #000; padding: 5px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${order.orderId || order.docId}" style="width: 100%; height: 100%;">
            </div>
            <div style="text-align: right;">
                <p style="font-size: 10px; font-weight: bold; margin: 0;">Authorized Courier Copy</p>
                <p style="font-size: 9px; margin: 2px 0;">MEC ERP System Generated</p>
                <p style="font-size: 9px; margin: 2px 0;">Date: ${order.date || ''} ${order.time || ''}</p>
            </div>
        </div>

        <div style="margin-top: 20px; font-size: 9px; text-align: center; border: 1px solid #eee; padding: 5px; color: #666;">
            Please check parcel integrity before acceptance. Thank you for shopping with MEC Book Shop!
        </div>
    `;
    
    document.body.appendChild(exportDiv);
    const canvas = await html2canvas(exportDiv, { backgroundColor: '#ffffff', scale: 2 });
    const dataUrl = canvas.toDataURL('image/png');
    const filename = `Waybill_${order.orderId || order.docId}.png`;

    if (window.electron) {
        window.electron.send('save-order-export', { base64Data: dataUrl, fileName: filename });
        window.showToast(`Saved to C:\\MEC_EXPORTS\\${filename}`, "success");
    } else {
        const link = document.createElement('a');
        link.download = filename;
        link.href = dataUrl;
        link.click();
    }
    document.body.removeChild(exportDiv);
};

window.exportODM_PDF = async () => {
    const order = currentODMOrder;
    if (!order) {
        window.showToast("No order selected for PDF export", "error");
        return;
    }
    
    const element = document.createElement('div');
    element.innerHTML = getPremiumInvoiceHTML(order);
    
    const opt = {
        margin:       0,
        filename:     `Invoice_${order.orderId || order.docId}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    
    document.body.appendChild(element);

    if (window.electron) {
        html2pdf().set(opt).from(element).toPdf().output('datauristring').then(dataUri => {
            window.electron.send('save-order-export', { base64Data: dataUri, fileName: opt.filename });
            window.showToast(`Saved to C:\\MEC_EXPORTS\\${opt.filename}`, "success");
            document.body.removeChild(element);
        });
    } else {
        html2pdf().set(opt).from(element).save().then(() => {
            document.body.removeChild(element);
        });
    }
};

window.quickExport = async (docId, type) => {
    if (!docId) {
        window.showToast("Order ID missing for export!", "error");
        return;
    }
    window.showToast(`⏳ Generating ${type.toUpperCase()}...`, "info");
    
    await window.viewOrderManagementDetails(docId);
    const modal = document.getElementById('order-details-modal');
    if (modal) modal.style.display = 'none';
    
    if (type === 'jpg') window.exportODM_JPG();
    else if (type === 'waybill') window.exportODM_Waybill();
    else if (type === 'pdf') window.exportODM_PDF();
};

window.resetOrderFilters = () => {
    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    const status = document.getElementById('order-status-filter');
    const search = document.getElementById('order-search-input');
    const start = document.getElementById('order-start-date');
    const end = document.getElementById('order-end-date');

    if (status) status.value = 'All';
    if (search) search.value = '';
    if (start) start.value = today;
    if (end) end.value = today;

    window.applyOrderFilters();
};


// --- INVOICE / ORDER EDIT MODAL FUNCTIONS ---

window.promptManagerPasswordForEdit = (orderId) => {
    return new Promise((resolve) => {
        const existing = document.getElementById('edit-order-auth-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'edit-order-auth-overlay';
        overlay.style.cssText = `position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(2,6,23,0.85); backdrop-filter:blur(10px); display:flex; align-items:center; justify-content:center; z-index:999999; opacity:0; transition:opacity 0.2s ease-out; font-family:'Outfit', sans-serif;`;

        const box = document.createElement('div');
        box.style.cssText = `background:#1e293b; color:#f8fafc; padding:2rem; border-radius:24px; width:380px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.6); border:1px solid rgba(99,102,241,0.4); transform:scale(0.9); transition:transform 0.2s ease-out; text-align:center;`;

        let dispId = orderId ? (String(orderId).startsWith('#') ? orderId : '#' + orderId) : '';

        box.innerHTML = `
            <div style="width:60px; height:60px; background:linear-gradient(135deg, #6366f1, #8b5cf6); border-radius:18px; display:flex; align-items:center; justify-content:center; margin:0 auto 1.25rem; font-size:1.6rem; color:#fff; box-shadow:0 10px 20px rgba(99,102,241,0.3);">
                🔒
            </div>
            <h3 style="margin:0 0 6px; font-size:1.3rem; font-weight:800; color:#fff; letter-spacing:0.5px;">Manager Authorization</h3>
            <p style="margin:0 0 1.5rem; font-size:0.88rem; color:#94a3b8;">Enter Manager Password to edit order <strong>${dispId}</strong></p>
            
            <div style="position:relative; margin-bottom:1.5rem;">
                <input type="password" id="edit-auth-pass-input" placeholder="Manager Password" style="width:100%; box-sizing:border-box; background:rgba(0,0,0,0.35); border:1.5px solid rgba(255,255,255,0.12); padding:1rem 2.8rem 1rem 1.2rem; border-radius:14px; color:#fff; font-size:1.1rem; outline:none; text-align:center; letter-spacing:2px; font-weight:700; transition:border-color 0.2s;">
                <button type="button" id="edit-auth-toggle-eye" style="position:absolute; right:12px; top:50%; transform:translateY(-50%); background:none; border:none; color:#94a3b8; cursor:pointer; font-size:1.1rem; padding:4px;">👁️</button>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px;">
                <button id="edit-auth-cancel" style="background:rgba(255,255,255,0.06); color:#94a3b8; border:1px solid rgba(255,255,255,0.1); padding:0.9rem 1rem; border-radius:14px; cursor:pointer; font-weight:700; font-size:0.95rem; transition:0.2s;">Cancel</button>
                <button id="edit-auth-confirm" style="background:linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color:white; border:none; padding:0.9rem 1rem; border-radius:14px; cursor:pointer; font-weight:800; font-size:0.95rem; box-shadow:0 8px 18px rgba(99,102,241,0.3); transition:0.2s;">Unlock</button>
            </div>
        `;

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            box.style.transform = 'scale(1)';
            const input = document.getElementById('edit-auth-pass-input');
            if (input) input.focus();
        });

        const close = (result = false) => {
            overlay.style.opacity = '0';
            box.style.transform = 'scale(0.9)';
            setTimeout(() => {
                overlay.remove();
                resolve(result);
            }, 180);
        };

        const passInput = document.getElementById('edit-auth-pass-input');
        const eyeBtn = document.getElementById('edit-auth-toggle-eye');
        if (eyeBtn && passInput) {
            eyeBtn.onclick = () => {
                passInput.type = (passInput.type === 'password') ? 'text' : 'password';
            };
        }

        const handleVerify = () => {
            const enteredPass = (passInput ? passInput.value : '').trim();
            if (!enteredPass) {
                window.showToast?.("⚠️ Please enter Manager Password", "warning");
                if (passInput) passInput.focus();
                return;
            }

            const isMaster = (
                enteredPass === 'mec123' ||
                enteredPass === 'mecpos123' ||
                enteredPass === 'malindu123' ||
                enteredPass === 'admin123' ||
                enteredPass === 'ireshadinali123' ||
                (window.ADMIN_PASS && enteredPass === window.ADMIN_PASS) ||
                (window.PLATFORM_PASS && enteredPass === window.PLATFORM_PASS)
            );

            const isStaff = (window.allEmployees || []).some(e => 
                e.password === enteredPass && 
                ['Admin', 'Manager', 'SuperAdmin', 'CEO_Admin', 'Finance_Manager'].includes(e.role_access)
            );

            if (isMaster || isStaff) {
                close(true);
            } else {
                if (passInput) {
                    passInput.style.borderColor = '#ef4444';
                    passInput.value = '';
                    passInput.focus();
                }
                window.showToast?.("❌ Invalid Manager Password! Access denied.", "error");
            }
        };

        document.getElementById('edit-auth-cancel').onclick = () => close(false);
        document.getElementById('edit-auth-confirm').onclick = handleVerify;

        if (passInput) {
            passInput.onkeydown = (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleVerify();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    close(false);
                }
            };
        }
    });
};

window.initEditOrderCustomerDatalist = () => {
    const datalist = document.getElementById('edit-ord-cust-datalist');
    if (!datalist) return;
    const custs = window.allCustomers || [];
    datalist.innerHTML = custs.map(c => {
        const p = c.phone || c.cleanPhone || '';
        const n = c.name || '';
        return `<option value="${p}">${n} (${p})</option>`;
    }).join('');
};

window.onEditOrderPhoneChange = (val) => {
    const clean = String(val || '').replace(/[\s-]/g, '').trim();
    if (!clean) return;
    const cust = (window.allCustomers || []).find(c => {
        const cp = (c.phone || c.cleanPhone || '').replace(/[\s-]/g, '');
        return cp && (cp === clean || cp.endsWith(clean) || clean.endsWith(cp));
    });
    if (cust && cust.name) {
        const nameInput = document.getElementById('edit-ord-cust-name');
        if (nameInput && (!nameInput.value || nameInput.value === 'Walk-in Customer' || nameInput.value.trim() === '')) {
            nameInput.value = cust.name;
        }
    }
};

window.openEditOrderModal = async (docId, bypassAuth = false) => {
    const order = (window.allOrders || []).find(o => o.docId === docId);
    if (!order) {
        window.showToast("Order details not found!", "error");
        return;
    }
    
    if (!bypassAuth) {
        const authorized = await window.promptManagerPasswordForEdit(order.orderId || order.docId);
        if (!authorized) return;
    }
    
    document.getElementById('edit-ord-docid').value = docId;
    
    let displayId = order.orderId || order.docId;
    if (displayId && !displayId.startsWith('#')) displayId = '#' + displayId;
    document.getElementById('edit-ord-subtitle').innerText = "Order: " + displayId;
    
    document.getElementById('edit-ord-cust-name').value = order.userName || order.customerName || 'Walk-in Customer';
    document.getElementById('edit-ord-cust-phone').value = (order.phone === 'N/A' || order.customerPhone === 'N/A') ? '' : (order.phone || order.customerPhone || '');
    document.getElementById('edit-ord-paymethod').value = order.paymentMethod || order.method || 'Cash';
    document.getElementById('edit-ord-delivery').value = order.deliveryPrice ? order.deliveryPrice : '';
    
    window.initEditOrderCustomerDatalist();
    
    const discTypeEl = document.getElementById('edit-ord-discount-type');
    const discValEl = document.getElementById('edit-ord-discount');
    if (order.discountType === '%' && order.discountVal !== undefined) {
        if (discTypeEl) discTypeEl.value = '%';
        if (discValEl) discValEl.value = order.discountVal ? order.discountVal : '';
    } else if (order.discountType === 'Rs' && order.discountVal !== undefined) {
        if (discTypeEl) discTypeEl.value = 'Rs';
        if (discValEl) discValEl.value = order.discountVal ? order.discountVal : '';
    } else {
        if (discTypeEl) discTypeEl.value = 'Rs';
        if (discValEl) discValEl.value = (order.discount && order.discount > 0) ? order.discount : '';
    }
    
    window.onEditOrderPaymentMethodChange(order.paymentMethod || order.method || 'Cash');
    if (order.chequeDate) {
        document.getElementById('edit-ord-chequedate').value = order.chequeDate;
    } else {
        document.getElementById('edit-ord-chequedate').value = new Date().toISOString().split('T')[0];
    }
    
    // Copy items locally for editing
    window.currentEditingOrderItems = JSON.parse(JSON.stringify(order.items || []));
    window.renderEditOrderItems();
    window.recalculateEditOrderTotals();
    
    document.getElementById('edit-order-modal').style.display = 'flex';
};

window.onEditOrderPaymentMethodChange = (val) => {
    const container = document.getElementById('edit-ord-cheque-date-container');
    if (container) {
        container.style.display = (val.toLowerCase() === 'cheque') ? 'block' : 'none';
    }
};

window.renderEditOrderItems = () => {
    const container = document.getElementById('edit-ord-items-container');
    if (!container) return;
    
    if (window.currentEditingOrderItems.length === 0) {
        container.innerHTML = '<div style="padding:20px; color:#64748b; text-align:center;">No items in this order.</div>';
        return;
    }
    
    let html = `
        <table style="width:100%; border-collapse:collapse; color:#fff; font-size:0.85rem;">
            <thead>
                <tr style="background:rgba(255,255,255,0.02); border-bottom:1px solid rgba(255,255,255,0.08); text-align:left;">
                    <th style="padding:10px; color:#94a3b8;">Item</th>
                    <th style="padding:10px; color:#94a3b8; text-align:center; width:80px;">Qty</th>
                    <th style="padding:10px; color:#94a3b8; text-align:right; width:120px;">Price</th>
                    <th style="padding:10px; color:#94a3b8; text-align:right; width:120px;">Total</th>
                    <th style="padding:10px; text-align:center; width:50px;"></th>
                </tr>
            </thead>
            <tbody>
    `;
    
    window.currentEditingOrderItems.forEach((item, index) => {
        const lineTotal = (item.price || 0) * (item.quantity || 0);
        html += `
            <tr style="border-bottom:1px solid rgba(255,255,255,0.03);">
                <td style="padding:10px; font-weight:700; text-align:left;">
                    ${item.name || 'Unknown Item'}
                    ${item.sku ? `<div style="font-size:0.7rem; color:#64748b;">${item.sku}</div>` : ''}
                </td>
                <td style="padding:10px; text-align:center;">
                    <input type="number" step="any" value="${item.quantity || 0}" oninput="window.updateEditOrderItemQty(${index}, this.value)" style="width:70px; padding:6px; border-radius:6px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); color:#fff; text-align:center; font-weight:700;">
                </td>
                <td style="padding:10px; text-align:right;">
                    <input type="number" step="any" value="${item.price || 0}" oninput="window.updateEditOrderItemPrice(${index}, this.value)" style="width:100px; padding:6px; border-radius:6px; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); color:#fff; text-align:right; font-weight:700;">
                </td>
                <td style="padding:10px; text-align:right; font-weight:800; color:#38bdf8;">
                    LKR ${lineTotal.toFixed(2)}
                </td>
                <td style="padding:10px; text-align:center;">
                    <button onclick="window.removeEditOrderItem(${index})" style="background:none; border:none; color:#ef4444; font-size:1.1rem; cursor:pointer; font-weight:bold;" title="Remove Item">✕</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
};

window.updateEditOrderItemQty = (index, val) => {
    const qty = parseFloat(val) || 0;
    window.currentEditingOrderItems[index].quantity = qty;
    window.renderEditOrderItems();
    window.recalculateEditOrderTotals();
};

window.updateEditOrderItemPrice = (index, val) => {
    const price = parseFloat(val) || 0;
    window.currentEditingOrderItems[index].price = price;
    window.renderEditOrderItems();
    window.recalculateEditOrderTotals();
};

window.removeEditOrderItem = (index) => {
    window.currentEditingOrderItems.splice(index, 1);
    window.renderEditOrderItems();
    window.recalculateEditOrderTotals();
};

window.recalculateEditOrderTotals = () => {
    let subtotal = 0;
    (window.currentEditingOrderItems || []).forEach(item => {
        subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.quantity) || 0);
    });
    
    const delivery = parseFloat(document.getElementById('edit-ord-delivery')?.value) || 0;
    const discountVal = parseFloat(document.getElementById('edit-ord-discount')?.value) || 0;
    const discountType = document.getElementById('edit-ord-discount-type')?.value || 'Rs';
    
    let discountAmount = 0;
    if (discountType === '%') {
        discountAmount = (subtotal * discountVal) / 100;
    } else {
        discountAmount = discountVal;
    }
    
    const total = Math.max(0, subtotal + delivery - discountAmount);
    
    const subtotalEl = document.getElementById('edit-ord-subtotal');
    const totalEl = document.getElementById('edit-ord-total');
    if (subtotalEl) subtotalEl.innerText = 'LKR ' + subtotal.toFixed(2);
    if (totalEl) totalEl.innerText = 'LKR ' + total.toFixed(2);
};

window.saveEditedOrder = async () => {
    const docId = document.getElementById('edit-ord-docid').value;
    if (!docId) return;
    
    const userName = document.getElementById('edit-ord-cust-name').value.trim() || 'Walk-in Customer';
    const phone = document.getElementById('edit-ord-cust-phone').value.trim();
    const cleanPhone = phone.replace(/[\s-]/g, "");
    
    // Match customer if exists
    const matchedCustomer = (window.allCustomers || []).find(c => {
        const cp = (c.phone || c.cleanPhone || "").replace(/[\s-]/g, "");
        return cp && cleanPhone && cp === cleanPhone;
    });
    const customerId = matchedCustomer ? matchedCustomer.docId : null;

    const paymentMethod = document.getElementById('edit-ord-paymethod').value;
    const deliveryPrice = parseFloat(document.getElementById('edit-ord-delivery').value) || 0;
    const discountVal = parseFloat(document.getElementById('edit-ord-discount').value) || 0;
    const discountType = document.getElementById('edit-ord-discount-type')?.value || 'Rs';
    
    let subtotal = 0;
    window.currentEditingOrderItems.forEach(item => {
        subtotal += (parseFloat(item.price) || 0) * (parseFloat(item.quantity) || 0);
    });
    
    let calculatedDiscount = 0;
    if (discountType === '%') {
        calculatedDiscount = (subtotal * discountVal) / 100;
    } else {
        calculatedDiscount = discountVal;
    }
    
    const total = Math.max(0, subtotal + deliveryPrice - calculatedDiscount);
    
    const isCheque = paymentMethod.toLowerCase() === 'cheque';
    const chequeDate = isCheque ? document.getElementById('edit-ord-chequedate').value : null;
    
    const updateData = {
        userName: userName,
        customerName: userName,
        phone: phone || 'N/A',
        customerPhone: phone || 'N/A',
        cleanPhone: cleanPhone,
        customerId: customerId || null,
        paymentMethod: paymentMethod,
        method: paymentMethod,
        deliveryPrice: deliveryPrice,
        discount: calculatedDiscount,
        discountVal: discountVal,
        discountType: discountType,
        total: total,
        items: window.currentEditingOrderItems
    };
    
    if (isCheque) {
        updateData.chequeDate = chequeDate;
        updateData.chequeStatus = 'pending';
        updateData.status = 'Pending';
    } else {
        updateData.chequeDate = null;
        updateData.chequeStatus = null;
        if (paymentMethod === 'COD' || paymentMethod === 'Bank Transfer') {
            updateData.status = 'Pending';
        } else {
            updateData.status = 'Delivered';
        }
    }
    
    try {
        const orderRef = doc(db, 'orders', docId);
        await updateDoc(orderRef, updateData);

        // Update in-memory order object
        const localIdx = (window.allOrders || []).findIndex(o => o.docId === docId);
        if (localIdx !== -1) {
            window.allOrders[localIdx] = { ...window.allOrders[localIdx], ...updateData };
            if (typeof window.applyOrderFilters === 'function') {
                window.applyOrderFilters();
            }
        }

        window.showToast("Order updated successfully!", "success");
        document.getElementById('edit-order-modal').style.display = 'none';
    } catch (e) {
        console.error(e);
        window.showToast("Failed to update order: " + e.message, "error");
    }
};
