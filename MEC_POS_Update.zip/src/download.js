import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";
import { db } from './firebase.js';

// ─── Instant Prefill from Cache (Zero-delay render) ───────────────
try {
    const cachedLogo = localStorage.getItem('mecpos_store_logo');
    if (cachedLogo && !cachedLogo.includes('/logo.png') && !cachedLogo.includes('zenith_logo')) {
        const navLogo = document.getElementById('nav-brand-logo');
        const cardLogo = document.getElementById('app-card-logo');
        if (navLogo) navLogo.src = cachedLogo;
        if (cardLogo) cardLogo.src = cachedLogo;
    }
} catch (e) {
    // Ignore cache error
}

// ─── Dynamic Merchant Branding Resolution ─────────────────────────
async function syncDownloadBranding() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const storeParam = urlParams.get('store');
        const hostname = window.location.hostname;
        const cleanHostname = hostname.replace(/^www\./, '');
        
        let matchedStore = null;
        let storeId = storeParam;

        // 1. Resolve by explicit ?store= parameter
        if (storeParam) {
            try {
                const qSlug = query(collection(db, 'stores'), where('slug', '==', storeParam));
                const snap = await getDocs(qSlug);
                if (!snap.empty) {
                    matchedStore = snap.docs[0].data();
                } else {
                    const snapDoc = await getDoc(doc(db, 'stores', storeParam));
                    if (snapDoc.exists()) matchedStore = snapDoc.data();
                }
            } catch (e) {
                console.warn('Error resolving store by param:', e);
            }
        }

        // 2. Resolve by Domain
        if (!matchedStore) {
            const isBookShopDomain = ['mecbookshop.web.lk', 'mecbookshop.com.lk', 'mec-book-shop.web.app', 'localhost', '127.0.0.1'].includes(cleanHostname);
            if (isBookShopDomain) {
                storeId = 'mec-book-shop';
            } else {
                try {
                    const qDom = query(collection(db, 'stores'), where('domain', '==', cleanHostname));
                    const snapDom = await getDocs(qDom);
                    if (!snapDom.empty) matchedStore = snapDom.docs[0].data();
                } catch (e) {
                    console.warn('Error resolving store by domain:', e);
                }
            }
        }

        // 3. Fallback to slug or default 'mec-book-shop'
        if (!matchedStore) {
            const targetSlug = storeId || localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';
            try {
                const qDefault = query(collection(db, 'stores'), where('slug', '==', targetSlug));
                const snapDef = await getDocs(qDefault);
                if (!snapDef.empty) {
                    matchedStore = snapDef.docs[0].data();
                } else {
                    const snapDocDef = await getDoc(doc(db, 'stores', targetSlug));
                    if (snapDocDef.exists()) matchedStore = snapDocDef.data();
                }
            } catch (e) {
                console.warn('Error resolving store fallback:', e);
            }
        }

        // 4. Check config collection for store details (bizName, invAddress, invPhone, storeLogoUrl)
        let storeConfig = null;
        const resolvedStoreSlug = matchedStore?.slug || storeId || 'mec-book-shop';
        if (resolvedStoreSlug) {
            try {
                const cfgSnap = await getDoc(doc(db, 'config', resolvedStoreSlug));
                if (cfgSnap.exists()) storeConfig = cfgSnap.data();
            } catch (e) {}
        }

        // 5. Merchant Logo Resolution (Avoid POS Zenith software logo)
        const rawLogo = storeConfig?.storeLogoUrl || storeConfig?.logoUrl || matchedStore?.logoUrl || matchedStore?.storeLogoUrl || localStorage.getItem('mecpos_store_logo');
        const merchantLogo = (rawLogo && rawLogo.trim() !== '' && !rawLogo.includes('zenith_logo') && !rawLogo.includes('/logo.png'))
            ? rawLogo
            : '/mec-logo.png';

        const navLogo = document.getElementById('nav-brand-logo');
        if (navLogo) {
            navLogo.src = merchantLogo;
            navLogo.alt = matchedStore?.name || 'Merchant Logo';
        }

        const cardLogo = document.getElementById('app-card-logo');
        if (cardLogo) {
            cardLogo.src = merchantLogo;
            cardLogo.alt = matchedStore?.name || 'Merchant Logo';
        }

        const faviconLink = document.getElementById('favicon-link');
        if (faviconLink) {
            faviconLink.href = merchantLogo;
        }

        // Store Name
        const storeName = storeConfig?.bizName || matchedStore?.name || matchedStore?.bizName || 'MEC Book Shop';
        const navTitle = document.getElementById('nav-brand-title');
        if (navTitle) navTitle.textContent = storeName;

        const heroStore = document.getElementById('hero-store-name');
        if (heroStore) heroStore.textContent = storeName;

        const cardName = document.getElementById('app-card-name');
        if (cardName) cardName.textContent = storeName;

        document.title = `Download ${storeName} Android App — Official Mobile Store`;

        // Tagline / Category
        const tagline = matchedStore?.tagline || matchedStore?.category || 'Mobile Ordering & POS System';
        const cardTagline = document.getElementById('app-card-tagline');
        if (cardTagline) cardTagline.textContent = tagline;

        // Custom APK Download URL if configured
        if (matchedStore?.apkUrl) {
            const btnDownload = document.getElementById('btn-download');
            if (btnDownload) btnDownload.href = matchedStore.apkUrl;
        }
        const btnLabel = document.getElementById('btn-download-label');
        if (btnLabel) {
            btnLabel.textContent = `Download ${storeName} APK (Latest)`;
        }

        // Poster button query preservation
        const posterBtn = document.getElementById('btn-goto-poster');
        if (posterBtn && storeParam) {
            posterBtn.href = `/poster?store=${encodeURIComponent(storeParam)}`;
        }

        // Back to Store link
        const backStore = document.getElementById('nav-back-store');
        const brandLink = document.getElementById('nav-brand-link');
        const storeHomeUrl = storeParam ? `/?store=${encodeURIComponent(storeParam)}` : '/';
        if (backStore) backStore.href = storeHomeUrl;
        if (brandLink) brandLink.href = storeHomeUrl;

        // QR Code
        const cleanHost = (cleanHostname === 'localhost' || cleanHostname === '127.0.0.1') ? 'mecbookshop.web.lk' : cleanHostname;
        const downloadUrl = (matchedStore?.downloadUrl)
            ? matchedStore.downloadUrl
            : `https://${cleanHost}/download${storeParam ? '?store=' + encodeURIComponent(storeParam) : ''}`;

        const qrImg = document.getElementById('qr-img');
        if (qrImg) {
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(downloadUrl)}`;
            qrImg.alt = `${storeName} QR Code`;
        }

    } catch (err) {
        console.error('Error syncing download branding:', err);
    }
}

syncDownloadBranding();
