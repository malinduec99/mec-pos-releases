import './style.css';
import { db, auth } from './firebase.js';
import {
    collection,
    query,
    where,
    getDocs,
    orderBy,
    onSnapshot,
    doc,
    updateDoc,
    addDoc,
    serverTimestamp
} from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

// --- SaaS Store Detection ---
const urlParams = new URLSearchParams(window.location.search);
const pathParts = window.location.pathname.split('/').filter(p => p !== '');
const slugFromPath = (pathParts[0] && !['index.html', 'track', 'admin', 'login.html'].includes(pathParts[0])) ? pathParts[0] : null;
const currentStoreId = urlParams.get('store') || slugFromPath || 'mec-book-shop';

window.storeInfo = null;
getDocs(query(collection(db, 'stores'), where('slug', '==', currentStoreId))).then(snap => {
    if (!snap.empty) {
        window.storeInfo = snap.docs[0].data();
    }
});

const resultDiv = document.getElementById('tracking-result');
const listView = document.getElementById('list-view');
const historyList = document.getElementById('history-list');

const resOrderId = document.getElementById('res-order-id');
const resStatusBadge = document.getElementById('res-status-badge');
const resDate = document.getElementById('res-date');
const resTotal = document.getElementById('res-total');
const resItemsCount = document.getElementById('res-items-count');
const resItemsList = document.getElementById('res-items-list');
const resCodRow = document.getElementById('res-cod-row');
const resCod = document.getElementById('res-cod');

const confirmSection = document.getElementById('confirm-section');
const reviewSection = document.getElementById('review-section');

let selectedRating = 5;
let currentViewingOrder = null;

const steps = {
    'Pending': document.getElementById('step-pending'),
    'Processing': document.getElementById('step-processing'),
    'Shipped': document.getElementById('step-shipped'),
    'Delivered': document.getElementById('step-delivered')
};

let currentOrders = [];

async function loadSingleOrderDirectly(orderId) {
    if (historyList) historyList.innerHTML = `<p class="loading-text">Loading invoice details...</p>`;
    try {
        const ordersCol = collection(db, 'orders');
        const q = query(ordersCol, where("orderId", "==", orderId));
        const snap = await getDocs(q);
        if (!snap.empty) {
            const orderData = { ...snap.docs[0].data(), docId: snap.docs[0].id };
            currentOrders = [orderData];
            viewOrderDetails(orderData.orderId);
            const backBtn = document.getElementById('back-btn');
            if (backBtn) backBtn.style.display = 'none';
        } else {
            if (historyList) {
                historyList.innerHTML = `
                    <div style="padding: 2.5rem; text-align: center; color: #ef4444; border: 1px dashed rgba(239, 68, 68, 0.4); border-radius: 16px; background: rgba(239, 68, 68, 0.05);">
                        <p style="font-size: 1.5rem; margin-bottom: 0.5rem;">⚠️</p>
                        <p style="font-weight: 800; font-size: 1.1rem; margin: 0;">Invoice Not Found</p>
                        <p style="font-size: 0.85rem; opacity: 0.8; margin-top: 5px;">No record found for Invoice ID: <strong>${orderId}</strong></p>
                    </div>
                `;
            }
        }
    } catch (err) {
        console.error(err);
        if (historyList) historyList.innerHTML = "Error loading invoice: " + err.message;
    }
}

// Listen for Auth State or Load Direct ID
const orderIdParam = urlParams.get('id');
if (orderIdParam) {
    loadSingleOrderDirectly(orderIdParam);
} else {
    onAuthStateChanged(auth, (user) => {
        if (user) {
            loadUserOrders(user.uid);
        } else {
            historyList.innerHTML = `
                <div style="padding: 2rem; border: 2px dashed #eee; border-radius: 12px;">
                    <p>Please log in to your account to view your orders.</p>
                    <a href="/login.html" class="add-to-cart-btn" style="display: inline-block; text-decoration: none; margin-top: 1rem;">Login Now</a>
                </div>
            `;
        }
    });
}

async function loadUserOrders(userId) {
    const ordersCol = collection(db, 'orders');
    const q = query(ordersCol, where("userId", "==", userId));

    onSnapshot(q, (snapshot) => {
        currentOrders = snapshot.docs
            .map(doc => ({ ...doc.data(), docId: doc.id }))
            .sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
        renderOrderList();

        // Update detail view if open
        if (currentViewingOrder) {
            const updated = currentOrders.find(o => o.orderId === currentViewingOrder.orderId);
            if (updated) viewOrderDetails(updated.orderId);
        }
    }, (err) => {
        console.error(err);
        historyList.innerHTML = "Error: " + err.message;
    });
}

function renderOrderList() {
    if (currentOrders.length === 0) {
        historyList.innerHTML = `
            <div class="empty-orders">
                <div style="font-size: 4rem; opacity: 0.2; margin-bottom: 1rem;">📦</div>
                <p>You haven't placed any orders yet.</p>
                <button class="category-btn active" onclick="window.location.href='/#products'" style="margin-top: 1rem;">Start Shopping</button>
            </div>
        `;
        return;
    }

    historyList.innerHTML = currentOrders.map(order => {
        const displayStatus = order.status === 'Shipped' ? 'Handed Over' : order.status;
        return `
            <div class="order-card" onclick="viewOrderDetails('${order.orderId}')" style="cursor: pointer; position: relative;">
                <div class="order-info">
                    <div class="order-id">${order.orderId}</div>
                    <div class="order-meta">${order.date} • ${order.items?.length || 0} Items</div>
                    <div class="order-total">LKR ${(order.total + (order.codCharge || 0)).toFixed(2)}</div>
                </div>
                <div class="order-status-col" style="display: flex; flex-direction: column; align-items: flex-end; gap: 10px;">
                    <span class="status-badge" data-status="${order.status}">
                        ${displayStatus}
                    </span>
                    ${order.status === 'Shipped' ? `
                        <button onclick="event.stopPropagation(); window.confirmOrderReceivedOnCard('${order.docId}')" 
                            style="background: #22c55e; color: white; border: none; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; cursor: pointer;">
                            Confirm Received ✅
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }).join('');
}

window.confirmOrderReceivedOnCard = async (docId) => {
    if (!confirm("Have you received this package?")) return;
    try {
        const orderRef = doc(db, 'orders', docId);
        await updateDoc(orderRef, { status: 'Delivered' });
        alert('📦 Thank you for confirming! You can now leave a review.');
    } catch (err) {
        alert('Error: ' + err.message);
    }
};

window.viewOrderDetails = (orderId) => {
    const order = currentOrders.find(o => o.orderId === orderId);
    if (!order) return;
    currentViewingOrder = order;

    resOrderId.innerText = order.orderId;
    resDate.innerText = order.date;
    const displayStatus = order.status === 'Shipped' ? 'Handed Over' : order.status;
    resStatusBadge.innerText = displayStatus;
    resStatusBadge.setAttribute('data-status', order.status);

    const itemsCount = order.items ? order.items.length : 0;
    if (resItemsCount) resItemsCount.innerText = `${itemsCount} Items`;
    const nameEl = document.getElementById('res-name');
    if (nameEl) nameEl.innerText = order.userName || 'Customer';

    const total = order.total || 0;
    const codCharge = order.codCharge || 0;
    const grandTotal = total + codCharge;

    if (resTotal) resTotal.innerText = grandTotal.toFixed(2);

    // Calculate subtotal, items discount, and grand total
    const items = order.items || [];
    const itemSubtotal = items.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 1)), 0);
    const itemDiscount = items.reduce((sum, item) => sum + ((item.discount || 0) * (item.quantity || 1)), 0);
    const billDiscount = order.discount || 0;
    const totalDiscount = itemDiscount + billDiscount;

    const subtotalEl = document.getElementById('res-invoice-subtotal');
    const discountEl = document.getElementById('res-invoice-discount');
    const discountRow = document.getElementById('res-invoice-discount-row');
    const deliveryEl = document.getElementById('res-invoice-delivery');
    const deliveryRow = document.getElementById('res-invoice-delivery-row');
    const paymethodEl = document.getElementById('res-invoice-paymethod');
    const itemsBody = document.getElementById('res-invoice-items-body');

    if (subtotalEl) subtotalEl.innerText = itemSubtotal.toFixed(2);
    if (discountEl) discountEl.innerText = totalDiscount.toFixed(2);
    if (discountRow) {
        discountRow.style.display = totalDiscount > 0 ? 'flex' : 'none';
    }
    if (deliveryEl) deliveryEl.innerText = codCharge.toFixed(2);
    if (deliveryRow) {
        deliveryRow.style.display = codCharge > 0 ? 'flex' : 'none';
    }
    if (paymethodEl) {
        paymethodEl.innerText = order.paymentMethod || order.method || 'Cash';
    }

    if (itemsBody) {
        itemsBody.innerHTML = items.map(item => {
            const qty = item.quantity || 1;
            const price = item.price || 0;
            const disc = item.discount || 0;
            const totalItemPrice = (price - disc) * qty;
            return `
                <tr style="border-bottom: 1px solid #f1f5f9; font-weight: 500;">
                    <td style="padding: 12px 8px; font-weight: 700; color: #0f172a;">${item.name}</td>
                    <td style="padding: 12px 8px; text-align: center;">${qty}</td>
                    <td style="padding: 12px 8px; text-align: right;">LKR ${price.toFixed(2)}</td>
                    <td style="padding: 12px 8px; text-align: right; color: #ef4444;">${disc > 0 ? `-LKR ${disc.toFixed(2)}` : '-'}</td>
                    <td style="padding: 12px 8px; text-align: right; font-weight: 700; color: #1e293b;">LKR ${totalItemPrice.toFixed(2)}</td>
                </tr>
            `;
        }).join('');
    }

    // Timeline logic
    Object.keys(steps).forEach(key => {
        if (steps[key]) steps[key].classList.remove('active', 'completed');
    });

    const statusOrder = ['Pending', 'Processing', 'Shipped', 'Delivered'];
    const currentIndex = statusOrder.indexOf(order.status);
    statusOrder.forEach((status, index) => {
        if (steps[status]) {
            if (index < currentIndex) steps[status].classList.add('completed');
            else if (index === currentIndex) steps[status].classList.add('active');
        }
    });

    // Confirm/Review Visibility
    confirmSection.style.display = (order.status === 'Shipped') ? 'block' : 'none';
    reviewSection.style.display = (order.status === 'Delivered' && !order.reviewed) ? 'block' : 'none';

    listView.style.display = 'none';
    resultDiv.style.display = 'block';
};

window.hideOrderDetails = () => {
    resultDiv.style.display = 'none';
    listView.style.display = 'block';
    currentViewingOrder = null;
};

// Confirm Received Logic
window.confirmOrderReceived = async () => {
    if (!currentViewingOrder) return;

    try {
        const orderRef = doc(db, 'orders', currentViewingOrder.docId);
        await updateDoc(orderRef, { status: 'Delivered' });
        alert('📦 Thank you for confirming! You can now leave a review.');
    } catch (err) {
        alert('Error: ' + err.message);
    }
};

// Star Rating Logic
window.setRating = (rating) => {
    selectedRating = rating;
    const stars = document.querySelectorAll('.star-rating span');
    stars.forEach((star, i) => {
        star.style.color = i < rating ? '#fbbf24' : '#ddd';
    });
};

// Submit Review Logic
window.submitReview = async () => {
    if (!currentViewingOrder) return;
    const comment = document.getElementById('review-comment').value.trim();

    try {
        const reviewsCol = collection(db, 'reviews');
        await addDoc(reviewsCol, {
            orderId: currentViewingOrder.orderId,
            userId: auth.currentUser.uid,
            userName: auth.currentUser.displayName || 'Customer',
            rating: selectedRating,
            comment: comment,
            timestamp: serverTimestamp(),
            date: new Date().toLocaleDateString()
        });

        // Mark order as reviewed
        const orderRef = doc(db, 'orders', currentViewingOrder.docId);
        await updateDoc(orderRef, { reviewed: true });

        document.getElementById('review-status').style.display = 'block';
        setTimeout(() => reviewSection.style.display = 'none', 3000);
    } catch (err) {
        alert('Error: ' + err.message);
    }
};

window.printFromTrack = () => {
    const orderId = resOrderId.innerText.replace('Order ID: ', '');
    const order = currentOrders.find(o => o.orderId === orderId);
    if (!order) return;

    // Calculate subtotal and discounts for the print invoice
    const items = order.items || [];
    const itemSubtotal = items.reduce((sum, item) => sum + ((item.price || 0) * (item.quantity || 1)), 0);
    const itemDiscount = items.reduce((sum, item) => sum + ((item.discount || 0) * (item.quantity || 1)), 0);
    const billDiscount = order.discount || 0;
    const totalDiscount = itemDiscount + billDiscount;
    const codCharge = order.codCharge || 0;
    const grandTotal = order.total + codCharge;

    const printArea = document.getElementById('printable-area');
    printArea.innerHTML = `
        <div style="padding: 40px; font-family: 'Segoe UI', sans-serif; color: #1e293b;">
            <div style="text-align: center; border-bottom: 2px solid #002060; padding-bottom: 20px;">
                ${window.storeInfo?.logoUrl ? `<img src="${window.storeInfo.logoUrl}" style="width: 100px; height: 100px; object-fit: contain; margin-bottom: 10px;">` : ''}
                <h1 style="margin: 5px 0; color: #002060; font-size: 1.8rem;">${window.storeInfo?.name || 'MEC BOOK SHOP'}</h1>
                <p style="margin: 2px 0; font-size: 0.85rem; color: #64748b;">${window.storeInfo?.location || 'No 97, Victoria Estate, Panadura Road, Munagama, Horana.'}</p>
                <h2 style="margin: 15px 0 5px; color: #002060; font-weight: 800; letter-spacing: 1px;">OFFICIAL INVOICE</h2>
            </div>
            <div style="margin: 30px 0; display: flex; justify-content: space-between; font-size: 0.9rem;">
                <div>
                    <h4 style="margin: 0 0 8px; color: #64748b; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">BILL TO:</h4>
                    <p style="margin: 2px 0;"><strong>${order.userName || 'Customer'}</strong></p>
                    <p style="margin: 2px 0; color: #475569;">${order.address || ''}, ${order.city || ''}</p>
                    <p style="margin: 2px 0; color: #475569;">Tel: ${order.phone || ''}${order.phone2 ? ' / ' + order.phone2 : ''}</p>
                </div>
                <div style="text-align: right;">
                    <p style="margin: 4px 0;"><strong>Order ID:</strong> ${order.orderId}</p>
                    <p style="margin: 4px 0;"><strong>Date:</strong> ${order.date}</p>
                    <p style="margin: 4px 0;"><strong>Method:</strong> <span style="text-transform: uppercase;">${order.paymentMethod || order.method || 'Cash'}</span></p>
                </div>
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-top: 20px; border: 1px solid #e2e8f0;">
                <thead>
                    <tr style="background: #002060; color: white;">
                        <th style="padding: 10px; text-align: left; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Item Description</th>
                        <th style="padding: 10px; text-align: center; width: 60px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Qty</th>
                        <th style="padding: 10px; text-align: right; width: 100px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Price</th>
                        <th style="padding: 10px; text-align: right; width: 80px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Disc</th>
                        <th style="padding: 10px; text-align: right; width: 110px; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 0.5px;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${items.map(item => {
                        const qty = item.quantity || 1;
                        const price = item.price || 0;
                        const disc = item.discount || 0;
                        const totalItemPrice = (price - disc) * qty;
                        return `
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 10px; font-weight: bold; color: #1e293b;">${item.name}</td>
                                <td style="padding: 10px; text-align: center; color: #475569;">${qty}</td>
                                <td style="padding: 10px; text-align: right; color: #475569;">LKR ${price.toFixed(2)}</td>
                                <td style="padding: 10px; text-align: right; color: #ef4444;">${disc > 0 ? `-LKR ${disc.toFixed(2)}` : '-'}</td>
                                <td style="padding: 10px; text-align: right; font-weight: 700; color: #1e293b;">LKR ${totalItemPrice.toFixed(2)}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
            
            <div style="margin-top: 20px; border-top: 2px dashed #002060; padding-top: 15px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; font-size: 0.85rem; color: #475569;">
                <div style="display: flex; justify-content: space-between; width: 240px;">
                    <span style="font-weight: 600;">Subtotal:</span>
                    <span style="font-weight: 700; color: #1e293b;">LKR ${itemSubtotal.toFixed(2)}</span>
                </div>
                ${totalDiscount > 0 ? `
                <div style="display: flex; justify-content: space-between; width: 240px; color: #ef4444;">
                    <span style="font-weight: 600;">Discount Given:</span>
                    <span style="font-weight: 700;">- LKR ${totalDiscount.toFixed(2)}</span>
                </div>
                ` : ''}
                ${codCharge > 0 ? `
                <div style="display: flex; justify-content: space-between; width: 240px;">
                    <span style="font-weight: 600;">Delivery/COD:</span>
                    <span style="font-weight: 700; color: #1e293b;">LKR ${codCharge.toFixed(2)}</span>
                </div>
                ` : ''}
                <div style="display: flex; justify-content: space-between; width: 240px; font-weight: bold; font-size: 1.1rem; color: #002060; border-top: 2px solid #002060; padding-top: 8px; margin-top: 4px;">
                    <span>Grand Total:</span>
                    <span>LKR ${grandTotal.toFixed(2)}</span>
                </div>
            </div>
        </div>
    `;

    // Temporary style for print
    const style = document.createElement('style');
    style.innerHTML = `
        @media print {
            body * { visibility: hidden; }
            #printable-area, #printable-area * { visibility: visible; }
            #printable-area { display: block !important; position: absolute; left: 0; top: 0; width: 100%; }
        }
    `;
    document.head.appendChild(style);
    window.print();
    document.head.removeChild(style);
};

// Handle Back Button
document.getElementById('back-btn').addEventListener('click', () => {
    window.hideOrderDetails();
});
