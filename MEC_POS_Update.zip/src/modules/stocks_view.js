import { db } from '../firebase.js';
import { doc, updateDoc, deleteDoc } from "firebase/firestore";

window.renderStocksUI = () => {
    const body = document.getElementById('stocks-view-body');
    if (!body) return;

    const searchTerm = (document.getElementById('stocks-search-input')?.value || '').toLowerCase();
    const products = window.allProducts || [];

    let rows = [];

    products.forEach(p => {
        const variants = p.variants || [];
        
        if (variants.length === 0) {
            // Show base product as a single stock entry if no variants exist
            if (p.name.toLowerCase().includes(searchTerm) || window.matchProductSku(p.sku, searchTerm)) {
                rows.push({
                    id: p.docId,
                    sku: (p.sku && p.sku.startsWith('SKU-')) ? p.sku : (window.generateStructuredSKU ? window.generateStructuredSKU(p) : (p.sku || 'N/A')),
                    image: p.image || '',
                    name: p.name + (p.size ? ` (Size: ${p.size})` : '') + (p.color ? ` (Color: ${p.color})` : '') + (p.supplierName ? ` [${p.supplierName}]` : ''),
                    qty: p.stock || 0,
                    unit: 'pcs',
                    price: p.price || 0,
                    created: p.timestamp ? new Date(p.timestamp.seconds * 1000).toLocaleDateString() : 'N/A',
                    expiry: p.expiryDate || 'N/A',
                    isBase: true
                });
            }
        } else {
            // Show each variant as a separate batch row
            variants.forEach(v => {
                if (p.name.toLowerCase().includes(searchTerm) || window.matchProductSku(v.sku || p.sku, searchTerm)) {
                    rows.push({
                        id: p.docId,
                        variantId: v.variantId,
                        sku: (v.sku && v.sku.startsWith('SKU-')) ? v.sku : (window.generateStructuredSKU ? window.generateStructuredSKU({ ...p, ...v, variantLabel: v.variantLabel || v.name }) : (v.sku || p.sku || 'N/A')),
                        image: v.image || p.image || '',
                        name: p.name + (v.variantLabel ? ` [${v.variantLabel}]` : '') + (v.size ? ` (Size: ${v.size})` : '') + (v.color ? ` (Color: ${v.color})` : '') + (v.supplierName ? ` (${v.supplierName})` : ''),
                        qty: v.stock || 0,
                        unit: 'pcs',
                        price: v.sellingPrice || 0,
                        created: v.addedDate ? new Date(v.addedDate).toLocaleDateString() : 'N/A',
                        expiry: v.expiry || 'N/A',
                        isBase: false
                    });
                }
            });
        }
    });

    // Sort by created date descending
    rows.sort((a, b) => new Date(b.created) - new Date(a.created));

    if (rows.length === 0) {
        body.innerHTML = `<tr><td colspan="9" style="text-align:center; padding: 3rem; color: var(--text-muted);">No stock entries found matching your search.</td></tr>`;
        return;
    }

    body.innerHTML = rows.map(r => `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
            <td>
                <div style="width: 45px; height: 45px; border-radius: 12px; overflow: hidden; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);">
                    <img src="${(r.image && !r.image.includes('/logo.png') && !r.image.includes('zenith_logo')) ? r.image : ((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png')}" style="width: 100%; height: 100%; object-fit: cover; cursor: pointer;" onclick="window.viewFullImage('${r.image}')" onerror="this.src=((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png')">
                </div>
            </td>
            <td style="min-width: 280px;">
                <div style="font-weight: 700; color: white; white-space: normal; word-break: break-word; line-height: 1.3;" title="${r.name}">${r.name}</div>
                <div style="font-size: 0.75rem; color: #38bdf8; margin-top: 4px; font-family: monospace; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${r.sku}">${r.sku}</div>
                ${r.isBase ? '' : '<span style="font-size: 0.7rem; color: #facc15; font-weight: bold; margin-top: 4px; display: inline-block;">BATCH ENTRY</span>'}
            </td>
            <td style="text-align: center;">
                <div style="font-weight: 800; color: ${r.qty < 5 ? '#ef4444' : '#10b981'}; font-size: 1.1rem;">${r.qty}</div>
            </td>
            <td style="text-align: center; color: var(--text-muted); font-size: 0.85rem;">${r.unit}</td>
            <td style="text-align: center; font-weight: 700; color: #38bdf8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="LKR ${r.price.toLocaleString()}">LKR ${r.price.toLocaleString()}</td>
            <td style="text-align: center; color: var(--text-muted); font-size: 0.85rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${r.created}</td>
            <td style="text-align: center;">
                <span class="glass-tag" style="background: ${r.expiry === 'N/A' ? 'rgba(255,255,255,0.05)' : 'rgba(239, 68, 68, 0.1)'}; color: ${r.expiry === 'N/A' ? 'var(--text-muted)' : '#ef4444'}; font-size: 0.8rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;">
                    ${r.expiry}
                </span>
            </td>
            <td style="text-align: right; min-width: 130px;">
                <div style="display: inline-flex; gap: 4px; justify-content: flex-end; align-items: center;">
                    <button class="icon-btn edit" onclick="window.openQuickStockAdd('${r.id}', '${r.variantId || ''}')" title="Direct Stock Add" style="background: rgba(16, 185, 129, 0.2); border: 1px solid #10b981; color: #10b981;">➕</button>
                    ${r.isBase ? 
                        `<button class="icon-btn edit" onclick="window.openEditModal('${r.id}')" title="Edit Product">📝</button>` : 
                        `<button class="icon-btn edit" onclick="window.openBatchEditModal('${r.id}', '${r.variantId}')" title="Quick Edit Batch" style="background: rgba(56, 189, 248, 0.2); border: 1px solid #38bdf8;">✏️</button>`
                    }
                    <button class="icon-btn delete" onclick="${r.isBase ? `window.confirmDeleteProduct('${r.id}')` : `window.confirmDeleteVariant('${r.id}', '${r.variantId}')`}" title="Delete Stock Entry">🗑️</button>
                </div>
            </td>
        </tr>
    `).join('');
};

window.downloadStocksCSV = () => {
    const products = window.allProducts || [];
    let csv = "SKU,Product,Quantity,Price,Created,Expiry\n";
    
    products.forEach(p => {
        const variants = p.variants || [];
        if (variants.length === 0) {
            csv += `"${p.sku || ''}","${p.name}",${p.stock || 0},${p.price || 0},"${p.timestamp ? new Date(p.timestamp.seconds * 1000).toLocaleDateString() : ''}","${p.expiryDate || ''}"\n`;
        } else {
            variants.forEach(v => {
                const variantName = p.name + (v.variantLabel ? ` [${v.variantLabel}]` : '') + (v.supplierName ? ` (${v.supplierName})` : '');
                csv += `"${v.sku || p.sku || ''}","${variantName}",${v.stock || 0},${v.sellingPrice || 0},"${v.addedDate ? new Date(v.addedDate).toLocaleDateString() : ''}","${v.expiry || ''}"\n`;
            });
        }
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', 'Stock_Ledger.csv');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};


