/* empty css              */import{G as Ct}from"./index-D2360V5-.js";import{a as Ce,c as D,d as S,s as ne,o as ue,q as T,w as C,g as A,b as W,e as Ae,i as Ne,f as ze,h as Pt,u as wt,j as Et,l as bt,k as Lt,m as Bt,n as ct}from"./firebase-DdNKt47v.js";window.uploadLogToCloud=async(e,t="error")=>{try{const a=window.currentStoreId||"unknown",r=window.HostPCName||navigator.userAgent||"WebBrowser";await Ce(D(S,"systemLogs"),{message:e,level:t,storeId:a,pcName:r,timestamp:ne()})}catch(a){console.error("Failed to upload log:",a)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function $t(){try{const e=localStorage.getItem("mecThemeColors");if(e){const t=JSON.parse(e),a=document.documentElement;a.style.setProperty("--primary-blue",t.primary),a.style.setProperty("--accent-blue",t.accent),a.style.setProperty("--admin-bg",t.bg),a.style.setProperty("--glass-bg",t.glass),a.style.setProperty("--primary-color",t.primary),a.style.setProperty("--secondary-color",t.accent),a.style.setProperty("--deep-bg",t.bg),t.bg==="#0f172a"||t.bg==="#11011c"||t.bg==="#022c22"?(a.style.setProperty("--text-dark","#f8fafc"),a.style.setProperty("--text-muted","#94a3b8")):(a.style.setProperty("--text-dark","#0f172a"),a.style.setProperty("--text-muted","#64748b"))}}catch{}}$t();function Pe(){const e=document.querySelector("header");if(e){const a=e.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(a)}px`)}const t=document.getElementById("product-grid-header");if(t&&e){const a=e.getBoundingClientRect().height,o=t.getBoundingClientRect().top<=Math.round(a)+2;t.classList.toggle("is-stuck",o)}}window.addEventListener("resize",Pe);window.addEventListener("scroll",Pe,{passive:!0});document.addEventListener("DOMContentLoaded",Pe);setTimeout(Pe,200);setTimeout(Pe,800);const ht=new URLSearchParams(window.location.search),ce=window.location.pathname.split("/").filter(e=>e!=="");let Qe=null;ce[0]==="store"&&ce[1]?Qe=ce[1]:ce[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(ce[0])&&(Qe=ce[0]);const Tt=ht.get("store")||Qe,Dt=typeof window<"u"&&(window.location.hostname.includes("mecbookshop")||window.location.hostname.includes("mec-book-shop")||window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1");window.currentStoreId=Tt||(Dt?"mec-book-shop":null);window.currentStoreData=null;if(typeof document<"u"){const e=()=>{const t=document.getElementById("nav-auth-item");t&&window.currentStoreId&&!sessionStorage.getItem("mec_user")&&(t.innerHTML=`<a href="/login.html?store=${encodeURIComponent(window.currentStoreId)}">Login</a>`)};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",e):e()}try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const be=D(S,"stores"),De=window.location.hostname;async function At(){let e=null;try{if(window.currentStoreId){const t=T(be,C("slug","==",window.currentStoreId)),a=await A(t);if(!a.empty)e={...a.docs[0].data(),docId:a.docs[0].id};else try{const r=W(S,"stores",window.currentStoreId),o=await ze(r);o.exists()&&(e={...o.data(),docId:o.id})}catch{}}else if(De==="mecpos.web.lk"||De==="mec-pos-shop.web.app"||De==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const t=De.toLowerCase().replace(/^www\./,"").trim();try{const a=localStorage.getItem("mecpos_domain_store_"+t);if(a){const r=JSON.parse(a);r&&(r.slug||r.docId||r.storeSlug||r.name)&&(r.logoUrl||r.storeLogoUrl)&&(e=r)}}catch{}if(!e&&(t.includes("mecbookshop")||t.includes("mec-book-shop")))try{const a=await ze(W(S,"stores","mec-book-shop"));a.exists()&&(e={...a.data(),docId:a.id,slug:a.data().slug||a.id})}catch{}if(!e){const a=t.split(".")[0].toLowerCase();if(a&&a!=="localhost"&&a!=="127"&&a!=="mecpos")try{const r=await ze(W(S,"stores",a));r.exists()&&(e={...r.data(),docId:r.id})}catch{}}if(!e)try{const[a,r,o]=await Promise.all([A(T(be,C("domain","==",t))),A(T(be,C("customDomain","==",t))),A(T(be,C("domains","array-contains",t)))]);a.empty?r.empty?o.empty||(e={...o.docs[0].data(),docId:o.docs[0].id}):e={...r.docs[0].data(),docId:r.docs[0].id}:e={...a.docs[0].data(),docId:a.docs[0].id}}catch{}if(e)try{localStorage.setItem("mecpos_domain_store_"+t,JSON.stringify(e))}catch{}}}catch(t){console.error("Store resolution query failed:",t)}if(e){window.currentStoreData=e;const t=typeof window<"u"&&(window.location.hostname.toLowerCase().includes("mecbookshop")||window.location.hostname.toLowerCase().includes("mec-book-shop"));if(window.currentStoreId=e.slug||e.storeSlug||e.docId||(t?"mec-book-shop":""),console.log("Resolved Store ID:",window.currentStoreId),He(),pt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral(),window.currentStoreId)try{ue(W(S,"stores",window.currentStoreId),a=>{if(a.exists()){const r={...a.data(),docId:a.id,slug:a.data().slug||a.id};window.currentStoreData={...window.currentStoreData||{},...r},He();try{const o=window.location.hostname.toLowerCase().replace(/^www./,"").trim();localStorage.setItem("mecpos_domain_store_"+o,JSON.stringify(window.currentStoreData))}catch{}}},a=>console.warn("Store live listener notice:",a))}catch{}}else{const t=window.currentStoreId;if(t)try{const a=T(be,C("slug","==",t)),r=await A(a);r.empty||(window.currentStoreData=r.docs[0].data())}catch(a){console.error("Error loading store data:",a)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),He(),pt(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}At();function He(){var B,z,M,$,U,te,oe,V,$e,ge,fe,N,G,ye,we,h,_,F;let e=(B=window.currentStoreData)==null?void 0:B.name;e||(window.currentStoreId?e=window.currentStoreId.split("-").map(L=>L.charAt(0).toUpperCase()+L.slice(1)).join(" "):e="MEC BOOK SHOP"),document.title=`${e} | Official Store`;const t=(window.currentStoreId||"").replace(/[-_]/g,"").toLowerCase(),a=t==="mecbookshop"||t.includes("bookshop")||!t,r=(M=(z=window.currentStoreData)==null?void 0:z.webDesign)==null?void 0:M.primary,o=(U=($=window.currentStoreData)==null?void 0:$.webDesign)==null?void 0:U.accent,i=(oe=(te=window.currentStoreData)==null?void 0:te.webDesign)==null?void 0:oe.secondary;r&&document.documentElement.style.setProperty("--primary-color",r),o&&document.documentElement.style.setProperty("--secondary-color",o);let s,c,n;if(a||!r&&!o)s="linear-gradient(90deg, #00e5ff 0%, #0099ff 28%, #4f46e5 55%, #9333ea 75%, #ec4899 92%, #ff007f 100%)",c="#00e5ff",n="rgba(255, 255, 255, 0.95)";else{const L=i||"#00e5ff";s=`linear-gradient(90deg, ${L} 0%, ${r||"#0099ff"} 50%, ${o||"#ff007f"} 100%)`,c=L,n=L}document.documentElement.style.setProperty("--brand-title-gradient",s),document.documentElement.style.setProperty("--brand-divider-color",c),document.documentElement.style.setProperty("--brand-subtitle-color",n),document.querySelectorAll(".logo-text").forEach(L=>{L.innerText=e});const l=(($e=(V=window.currentStoreData)==null?void 0:V.webContent)==null?void 0:$e.tagline)||(a?"MODERN ENTERPRISE COLLECTIVE":(ge=window.currentStoreData)!=null&&ge.category?`${window.currentStoreData.category.toUpperCase()} • OFFICIAL STORE`:"OFFICIAL STORE");document.querySelectorAll("#store-subtitle-text, .brand-subtitle-text").forEach(L=>{L.innerText=l});const d=window.currentStoreId||"mec-book-shop",p=typeof localStorage<"u"?localStorage.getItem("mecpos_store_logo_"+d)||localStorage.getItem("mecpos_store_logo")||localStorage.getItem("set-store-logo-url"):null,m=((fe=window.currentStoreData)==null?void 0:fe.logoUrl)||((N=window.currentStoreData)==null?void 0:N.storeLogoUrl)||((G=window.currentStoreData)==null?void 0:G.webLogo)||p,g=m&&typeof m=="string"&&m.trim()!==""&&m.length>25&&!m.includes("/logo.png")&&!m.includes("zenith_logo")&&!m.includes("/pos-logo.png")&&!m.includes("/mec-logo.png")&&!m.includes("mecpos-default-logo");let u;g?u=m:u=a?"/mec_book_shop_logo.png":"data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='80' height='80' fill='none'%3E%3Crect width='80' height='80' rx='14' fill='%231e293b'/%3E%3Cpath d='M40 20L62 31.5V56.5L40 68L18 56.5V31.5L40 20Z' stroke='%2300e5ff' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M18 31.5L40 43L62 31.5' stroke='%2300e5ff' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M40 43V68' stroke='%2300e5ff' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E",document.querySelectorAll(".logo-img, .brand-logo-img, #store-logo-img").forEach(L=>{L.src=u,L.style.display="block"}),document.querySelectorAll(".bookshop-brand-banner").forEach(L=>L.style.display="none");const y=document.getElementById("pwa-install-banner");y&&(y.style.display=a?"":"none");const f=document.getElementById("hero");if(f){const L=(we=(ye=window.currentStoreData)==null?void 0:ye.webDesign)==null?void 0:we.bannerUrl;let O=L&&L.length>20&&!L.includes("neon_banner")?L:a?"/banner.png":null;O?(f.style.display="block",f.innerHTML=`
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${O}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `):(f.style.display="block",f.innerHTML=`
        <div class="dynamic-merchant-hero">
          <div class="hero-logo-wrap">
            <img src="${u}" alt="${e} Logo" loading="eager" fetchpriority="high">
          </div>
          <div class="hero-brand-text">
            <h1 class="hero-brand-title">${e}</h1>
            <div class="hero-brand-sub">
              <span class="dash"></span>
              <span>${l}</span>
              <span class="dash"></span>
            </div>
            <div class="hero-actions">
              <a href="#products-section" class="btn-hero-primary">
                <span>🛍️ Explore Products</span>
              </a>
              <a href="/track.html" class="btn-hero-secondary">
                <span>🚚 Track Order</span>
              </a>
            </div>
          </div>
        </div>
      `)}const b=document.getElementById("page-title");b&&(b.innerText=`${e} | Official Store`);const w=document.getElementById("footer-copy");w&&(w.innerText=`© 2026 ${e}. All rights reserved.`);const v=((h=window.currentStoreData)==null?void 0:h.webEpinics)||{},x=!!v.multiVendor,I=!!v.affiliate;(_=document.getElementById("nav-sell-with-us"))==null||_.remove(),(F=document.getElementById("nav-affiliate-program"))==null||F.remove();const P=document.getElementById("nav-menu");if(P){const L=document.getElementById("nav-auth-item");if(x){const O=document.createElement("li");O.id="nav-sell-with-us",O.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',L?P.insertBefore(O,L):P.appendChild(O)}if(I){const O=document.createElement("li");O.id="nav-affiliate-program",O.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',L?P.insertBefore(O,L):P.appendChild(O)}}document.documentElement.classList.remove("loading-merchant")}let he;const Z=document.createElement("div");Z.id="pwa-install-banner";Z.innerHTML=`

    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">

        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">

        <div>

            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>

            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>

        </div>

        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>

    </div>

    <style>

        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }

    </style>

`;Z.style.display="none";document.body.appendChild(Z);window.addEventListener("beforeinstallprompt",e=>{var a,r;e.preventDefault(),he=e,!!((a=window.currentStoreData)!=null&&a.downloadUrl||(r=window.currentStoreData)!=null&&r.appDownloadUrl)?Z.style.display="block":Z.style.display="none"});Z.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){Z.style.display="none";return}if(he){he.prompt();const{outcome:t}=await he.userChoice;t==="accepted"&&(Z.style.display="none"),he=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const Y=document.getElementById("menu-toggle"),X=document.getElementById("nav-menu"),H=document.getElementById("mobile-menu-overlay"),Re=()=>{X==null||X.classList.remove("active"),Y==null||Y.classList.remove("active"),H==null||H.classList.remove("active")};Y==null||Y.addEventListener("click",()=>{const e=X==null?void 0:X.classList.toggle("active");Y==null||Y.classList.toggle("active"),e?H==null||H.classList.add("active"):H==null||H.classList.remove("active")});const je=document.getElementById("close-menu");je==null||je.addEventListener("click",Re);H==null||H.addEventListener("click",Re);X==null||X.querySelectorAll("a").forEach(e=>{e.addEventListener("click",Re)});function Ee(e,t){var r;if(typeof e=="string"&&e.trim()!==""){const o=e.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const a=(r=window.currentStoreData)==null?void 0:r.logoUrl;return a&&a.trim()!==""&&!a.includes("zenith_logo.png")&&!a.includes("/logo.png")?a:"/mec-logo.png"}function Fe(e){let t=window.currentStoreId||window.sessionStorage&&(sessionStorage.getItem("userStoreId")||sessionStorage.getItem("tempStoreSlug"))||"";return(!t||t==="null"||t==="undefined")&&(t="default"),D(S,"stores",t,e)}const vt=Fe("products"),Nt=Fe("orders"),zt=Fe("promotions"),Mt=Fe("branches"),_t=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let dt=[];ue(Mt,e=>{dt=e.docs.map(t=>({...t.data(),docId:t.id})),window.allStoreBranches=dt,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function ve(){var a,r,o,i,s,c;let e=(window.allStoreBranches||[]).filter(n=>n.storeId===window.currentStoreId||!n.storeId);const t={docId:"main",name:(((a=window.currentStoreData)==null?void 0:a.name)||"Store")+" - Main Branch",location:((r=window.currentStoreData)==null?void 0:r.address)||"",address:((o=window.currentStoreData)==null?void 0:o.address)||"",city:((i=window.currentStoreData)==null?void 0:i.city)||"",district:((s=window.currentStoreData)==null?void 0:s.district)||"",phone:((c=window.currentStoreData)==null?void 0:c.phone)||""};return e.length===0&&(e=[t]),e}window.getAllAvailableShops=ve;function xt(){const t=ve().map(r=>(r.location||r.city||"").trim()).filter(r=>r.length>0);return Array.from(new Set([...t,..._t])).filter(Boolean).sort((r,o)=>r.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=xt;let E=[],Le=0,k=[],se="All",q=1,Ve=12,de="recommended",pe="",Ge=null;document.getElementById("cart-count");window.webStoreBankAccounts={slot1:null,slot2:null};window.selectedWebStoreBankSlot="slot1";window.selectWebStoreBankSlot=e=>{window.selectedWebStoreBankSlot=e;const t=document.getElementById("web-bank-card-1"),a=document.getElementById("web-bank-card-2"),r=document.getElementById("web-slot-1-radio"),o=document.getElementById("web-slot-2-radio"),i=document.getElementById("web-bank-1-badge"),s=document.getElementById("web-bank-2-badge");e==="slot1"?(r&&(r.checked=!0),o&&(o.checked=!1),t&&(t.style.background="#f0fdf4",t.style.borderColor="#16a34a",t.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),a&&(a.style.background="#ffffff",a.style.borderColor="#cbd5e1",a.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),i&&(i.style.background="#16a34a",i.style.color="#ffffff",i.innerText="✓ Selected"),s&&(s.style.background="#f1f5f9",s.style.color="#64748b",s.innerText="Click to select")):(r&&(r.checked=!1),o&&(o.checked=!0),a&&(a.style.background="#f0fdf4",a.style.borderColor="#16a34a",a.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),t&&(t.style.background="#ffffff",t.style.borderColor="#cbd5e1",t.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),s&&(s.style.background="#16a34a",s.style.color="#ffffff",s.innerText="✓ Selected"),i&&(i.style.background="#f1f5f9",i.style.color="#64748b",i.innerText="Click to select"))};window.copyBankDetails=(e,t)=>{const a=document.getElementById(e);if(!a)return;const r=a.innerText.trim();navigator.clipboard.writeText(r),alert(`${t} Copied: ${r}`)};window.updateWebStoreBankCardsUI=()=>{var a,r;const e=(a=window.webStoreBankAccounts)==null?void 0:a.slot1,t=(r=window.webStoreBankAccounts)==null?void 0:r.slot2;if(e){const o=document.getElementById("web-bank-1-title"),i=document.getElementById("web-bank-1-accname"),s=document.getElementById("web-bank-1-accno"),c=document.getElementById("web-bank-1-acctype"),n=document.getElementById("web-bank-1-code"),l=document.getElementById("web-bank-1-swift");o&&e.bankName&&(o.innerText=`🏦 ${e.bankName}`),i&&e.accountName&&(i.innerText=e.accountName),s&&e.accountNo&&(s.innerText=e.accountNo),c&&e.accountType&&(c.innerText=e.accountType),n&&e.bankCode&&(n.innerText=e.bankCode),l&&e.swiftCode&&(l.innerText=e.swiftCode)}if(t){const o=document.getElementById("web-bank-2-title"),i=document.getElementById("web-bank-2-accname"),s=document.getElementById("web-bank-2-accno"),c=document.getElementById("web-bank-2-branch");o&&t.bankName&&(o.innerText=`🏦 ${t.bankName}`),i&&t.accountName&&(i.innerText=t.accountName),s&&t.accountNo&&(s.innerText=t.accountNo),c&&t.branch&&(c.innerText=t.branch)}};function Rt(){try{const e=localStorage.getItem("mec_webstore_bank_config");if(e){const t=JSON.parse(e);t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data})}}catch{}try{ue(W(S,"config","webstore_bank_accounts"),e=>{if(e.exists()){const t=e.data();t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data}),window.updateWebStoreBankCardsUI()}},e=>console.warn("Web store banks config snapshot warning:",e))}catch(e){console.warn("Could not setup webstore banks listener:",e)}}Rt();function Ft(){let e=window.currentStoreId||(window.location.hostname.includes("mecbookshop")||window.location.hostname.includes("mec-book-shop")?"mec-book-shop":"");if(e){try{const t=localStorage.getItem(`mecpos_system_config_${e}`)||localStorage.getItem("mecpos_system_config_cache");t&&(window.systemConfig=JSON.parse(t))}catch{}try{ue(W(S,"config",e),t=>{if(t.exists()){const a=t.data();window.systemConfig=a;try{localStorage.setItem(`mecpos_system_config_${e}`,JSON.stringify(a)),localStorage.setItem("mecpos_system_config_cache",JSON.stringify(a))}catch{}typeof window.renderProducts=="function"&&Array.isArray(E)&&E.length>0&&window.renderProducts()}},t=>console.warn("System config snapshot warning:",t))}catch(t){console.warn("Could not setup system config listener:",t)}}}Ft();function Je(e,t){const a=(t||"").replace(/[-_]/g,"").toLowerCase();a==="mecbookshop"||a.includes("bookshop");const r=e.filter(o=>{if(o.mode==="Service"||o.mode==="Technical"||o.mode==="POS"||o.status==="pending"||o.status==="Void"||o.status==="void")return!1;const i=(o.name||"").toLowerCase();return!(i==="call"||i.includes("repair")||i.includes("repire")||i.includes("rapair")||i.includes("print out")||i.includes("photo print"))});return r.sort((o,i)=>{var s,c;return(((s=i.timestamp)==null?void 0:s.seconds)||0)-(((c=o.timestamp)==null?void 0:c.seconds)||0)}),r}function Ye(){const e=document.querySelector("#product-grid");!e||E&&E.length>0||(e.innerHTML=Array(12).fill(0).map(()=>`
    <div class="product-card skeleton-card" style="pointer-events:none; border-radius:14px; overflow:hidden; background:rgba(30,41,59,0.5); border:1px solid rgba(255,255,255,0.06); padding:12px;">
      <div style="height:210px; width:100%; border-radius:10px; background:linear-gradient(90deg, rgba(255,255,255,0.03) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.03) 75%); background-size:200% 100%; animation:shimmer 1.5s infinite;"></div>
      <div style="height:14px; width:40%; margin-top:14px; border-radius:4px; background:rgba(255,255,255,0.05);"></div>
      <div style="height:18px; width:80%; margin-top:8px; border-radius:4px; background:rgba(255,255,255,0.08);"></div>
      <div style="height:20px; width:50%; margin-top:12px; border-radius:4px; background:rgba(0,210,255,0.15);"></div>
    </div>
  `).join(""))}function pt(){let e=window.currentStoreId||"";if(!e){const o=typeof window<"u"&&window.location.hostname?window.location.hostname.toLowerCase():"";if(o.includes("mecbookshop")||o.includes("mec-book-shop"))e="mec-book-shop",window.currentStoreId="mec-book-shop";else return}const t=D(S,"stores",e,"products"),a="mecpos_products_cache_"+e;let r=!1;try{const o=localStorage.getItem(a);if(o){const i=JSON.parse(o);Array.isArray(i)&&i.length>0?(E=i,r=!0,window.productsLoadedFromFirestore=!0,R(),ie(),console.log(`⚡ [Instant Catalog] Loaded ${E.length} products in 0ms from local cache!`)):localStorage.removeItem(a)}}catch{}r||Ye(),A(T(t,bt(36))).then(o=>{if(!o.empty){const i=o.docs.map(c=>({...c.data(),id:c.id,docId:c.id,sku:c.data().sku||c.id})),s=Je(i,e);s.length>0&&(!E||E.length<=s.length)&&(E=s,window.productsLoadedFromFirestore=!0,R(),ie(),console.log(`⚡ [Fast Batch] Rendered ${E.length} products in <200ms!`))}}).catch(o=>{console.warn("Fast batch notice:",o)}),A(t).then(o=>{if(!o.empty){const i=o.docs.map(c=>({...c.data(),id:c.id,docId:c.id,sku:c.data().sku||c.id})),s=Je(i,e);if(s.length>0){E=s,window.productsLoadedFromFirestore=!0,R(),ie(),console.log(`⚡ [Full Catalog Direct] Loaded ${E.length} products!`);try{const c=s.slice(0,100).map(n=>{const l={...n};return l.image&&l.image.length>1e3&&(l.image=""),l});localStorage.setItem(a,JSON.stringify(c))}catch{}}}}).catch(o=>{console.warn("Direct getDocs notice:",o)});try{let o=T(t);ue(o,i=>{if(!i.empty){const s=i.docs.map(n=>({...n.data(),id:n.id,docId:n.id,sku:n.data().sku||n.id})),c=Je(s,e);if(c.length>0){E=c,window.productsLoadedFromFirestore=!0,R(),ie();try{const n=c.slice(0,100).map(l=>{const d={...l};return d.image&&d.image.length>1e3&&(d.image=""),d});localStorage.setItem(a,JSON.stringify(n))}catch{}}}},i=>{console.warn("Products onSnapshot stream notice:",i)})}catch(o){console.warn("onSnapshot init notice:",o)}}var ft;(ft=document.getElementById("product-sort"))==null||ft.addEventListener("change",e=>{de=e.target.value,q=1,R()});const Ot=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.addEventListener("input",t=>{pe=t.target.value.toLowerCase(),window.searchQuery=pe,document.querySelectorAll("#store-search, .store-search-input").forEach(a=>{a!==t.target&&(a.value=t.target.value)}),q=1,R()})})};Ot();window.renderProducts=R;window.clearSearch=()=>{pe="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.value=""}),q=1,R()};function ot(){localStorage.setItem("mec_cart",JSON.stringify(k))}function qt(){const e=localStorage.getItem("mec_cart");e&&(k=JSON.parse(e),Le=k.reduce((t,a)=>t+(a.quantity||1),0),qe())}const xe=document.createElement("div");xe.id="cart-modal";document.body.appendChild(xe);const ke=document.createElement("div");ke.id="cart-overlay";document.body.appendChild(ke);window.toggleCart=e=>{e?(xe.classList.add("active"),ke.classList.add("active"),Ue(),document.body.style.overflow="hidden"):(xe.classList.remove("active"),ke.classList.remove("active"),document.body.style.overflow="")};const Be=window.toggleCart;ke.onclick=()=>Be(!1);const Ut=document.querySelectorAll('a[href="#cart"]');Ut.forEach(e=>{e.onclick=t=>{t.preventDefault(),Re(),Be(!0)}});const ut=document.getElementById("shop-now-btn");ut&&ut.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const kt={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function Wt(){return["All",...new Set(E.map(t=>t.category))]}function ie(){const e=Wt(),t=document.getElementById("sidebar-category-list"),a=document.getElementById("mobile-category-bar");t&&(t.innerHTML=e.map(s=>`

      <li class="sidebar-cat-item ${s===se?"active":""}" data-category="${s}">

        <div class="cat-icon-text">

          <span class="cat-icon">${kt[s]||"📁"}</span>

          <span>${s}</span>

        </div>

        <span class="arrow">›</span>

      </li>

    `).join("")),a&&(a.innerHTML=e.map(s=>`

      <button class="mobile-cat-btn ${s===se?"active":""}" data-category="${s}">

        ${s}

      </button>

    `).join(""));const r=s=>{var n;se=s;const c=document.getElementById("featured-title");c&&(c.innerText=s==="All"?"Featured Collection":`${s} Collection`),R(),ie(),ee(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(s=>{s.addEventListener("click",c=>{c.stopPropagation(),r(c.currentTarget.dataset.category)}),s.addEventListener("mouseenter",c=>{const n=c.currentTarget.dataset.category;n!=="All"?Kt(n,c.currentTarget):ee()})}),document.querySelectorAll(".mobile-cat-btn").forEach(s=>{s.addEventListener("click",c=>r(c.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),i=document.getElementById("nav-category-btn");i&&o&&(i.onclick=s=>{s.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),ee()})}document.addEventListener("click",e=>{const t=document.querySelector(".category-menu-wrapper");t&&!t.contains(e.target)&&(t.classList.remove("active"),typeof ee=="function"&&ee())});const j=document.getElementById("mega-menu");let Oe;function Kt(e,t){if(!j)return;clearTimeout(Oe),document.querySelectorAll(".sidebar-cat-item").forEach(n=>n.classList.remove("active")),t==null||t.classList.add("active");const a=(E||[]).filter(n=>n.category===e),r={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`

      <div style="margin-bottom: 1.1rem;">

        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>

        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">

          <span>${kt[e]||"📁"}</span>

          <span>${e}</span>

        </div>

        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${a.length} Items Available</div>

      </div>

      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">

        <span>View All</span>

        <span>→</span>

      </button>

      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>

      <div style="display: flex; flex-direction: column; gap: 4px;">

        ${r.map(n=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${n}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${n}</a>`).join("")}

      </div>

    `);const i=document.getElementById("mega-products-heading");i&&(i.innerText=`${e} Products (${a.length})`);const s=document.getElementById("mega-products-list");s&&(s.innerHTML=a.length>0?a.map(n=>`

          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${n.docId}')">

            <img src="${Ee(n.image,n.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">

            <div class="mega-prod-info">

              <h5 title="${n.name}">${n.name}</h5>

              <div class="price">LKR ${Number(n.price||0).toFixed(2)}</div>

            </div>

          </a>

        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),j.style.top="calc(100% + 8px)",j.style.left="248px",j.classList.add("active");const c=j.getBoundingClientRect();if(c.right>window.innerWidth-16){const n=c.right-(window.innerWidth-16);j.style.left=`${Math.max(0,248-n)}px`}}function ee(){Oe=setTimeout(()=>{j==null||j.classList.remove("active")},400)}j==null||j.addEventListener("mouseenter",()=>clearTimeout(Oe));var yt;(yt=document.getElementById("sidebar-category-list"))==null||yt.addEventListener("mouseenter",()=>clearTimeout(Oe));window.filterByCategoryAndScroll=e=>{var a;se=e;const t=document.getElementById("featured-title");t&&(t.innerText=e==="All"?"Featured Collection":`${e} Collection`),R(),ie(),ee(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,t)=>{var r;se=t,R(),ie();const a=document.getElementById("featured-title");a&&(a.innerText=`${e} in ${t}`),(r=document.getElementById("shop-section"))==null||r.scrollIntoView({behavior:"smooth"}),ee()};window.scrollToProduct=e=>{const t=document.getElementById(`product-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"center"}),t.classList.add("highlight-pulse"),setTimeout(()=>t.classList.remove("highlight-pulse"),3e3),ee())};function Ht(e,t,a=""){var d,p,m,g;e=parseFloat(e)||0,t=parseFloat(t)||0;const r=((d=window.systemConfig)==null?void 0:d.categoryWholesaleRules)||window.categoryWholesaleRules||[],o=(a||"").trim().toLowerCase(),i=r.find(u=>{var f,b;if(!u)return!1;const y=(typeof u.category=="string"?u.category:((f=u.category)==null?void 0:f.name)||((b=u.category)==null?void 0:b.category)||"").trim().toLowerCase();return y&&y===o});let s=i?i.mode:((p=window.systemConfig)==null?void 0:p.wholesalePricingMode)||"cost_markup",c=i?parseFloat(i.value):parseFloat((m=window.systemConfig)==null?void 0:m.wholesaleDiscount)||(s==="cost_markup"?8:15);isNaN(c)&&(c=0);let n=0;s==="cost_markup"?e>0?n=e*(1+c/100):t>0&&(n=t*.9):t>0?n=t*(1-c/100):e>0&&(n=e*1.1);const l=parseFloat((g=window.systemConfig)==null?void 0:g.profitMargin)||0;if(e>0&&l>0){const u=e*(1+l/100);n<u&&(n=u)}return Math.round(n*100)/100}window.calculateDynamicWholesalePrice=Ht;function me(e,t=null,a=null){var y,f,b;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const r=(a||((y=window.currentUserProfile)==null?void 0:y.customerType)||"retail").toLowerCase(),o=Number(e.price||e.sellingPrice)||0,i=Number(e.wholesalePrice)||0,s=Number(e.loyaltyPrice)||0,c=Number(t?t.cost||t.buyingPrice:e.cost||e.buyingPrice)||0,n=Number(t?t.price||t.sellingPrice:o)||o;let l=0,d=0;if(t){const w=Number(t.wholesalePrice)||0,v=Number(t.loyaltyPrice)||0;i>0&&(w<=0||Math.abs(n-o)<.01)?l=i:w>0?l=w:i>0&&(l=o>0?Math.round(n*(i/o)*100)/100:i),s>0&&(v<=0||Math.abs(n-o)<.01)?d=s:v>0?d=v:s>0&&(d=o>0?Math.round(n*(s/o)*100)/100:s)}else l=i,d=s;if(r==="wholesale"){l<=0&&typeof window.calculateDynamicWholesalePrice=="function"&&(l=window.calculateDynamicWholesalePrice(c,n,e.category));const w=parseFloat((f=window.systemConfig)==null?void 0:f.wholesaleDiscount)||0;l<=0&&w>0&&(l=Math.round(n*(1-w/100)*100)/100)}else if(r==="loyalty"){const w=parseFloat((b=window.systemConfig)==null?void 0:b.loyaltyDiscount)||0;d<=0&&w>0&&(d=Math.round(n*(1-w/100)*100)/100)}isNaN(n)&&(n=0);let p=n,m=!1;r==="wholesale"&&l>0?(p=l,m=l!==n):r==="loyalty"&&d>0&&(p=d,m=d!==n);const g=Number(e.discount)||0;let u=p;return r==="retail"&&g>0&&(u=p*(1-g/100)),{retailPrice:isNaN(n)?0:n,effectivePrice:isNaN(p)?0:p,discountedPrice:isNaN(u)?0:u,isSpecial:m,userType:r}}window.getCustomerEffectivePrice=me;function Se(e,t=null){return nt(e,t,"web")}function nt(e,t=null,a="web"){if(!e)return 0;if(a==="ShopPay"||a==="shop"||a==="Shop"){if(t){const i=parseFloat(t.stock)||0;if(i>0)return i}const o=parseFloat(e.stock||0);return o>0?o:0}else{if(t){const n=parseFloat(t.stock)||0,l=parseFloat(t.wStock)||0,d=n+l;if(d>0)return d}if(e.variants&&e.variants.length>0){const n=e.variants.reduce((l,d)=>l+(parseFloat(d.stock)||0)+(parseFloat(d.wStock)||0),0);if(n>0)return n}const o=parseFloat(e.stock||0),i=parseFloat(e.wStock||0),s=parseFloat(e.totalStock||0),c=o+i;return c>0?c:s>0?s:0}}function at(e,t="",a=0){if(!e||!Array.isArray(e)||e.length===0)return[];const r=new Map;return e.forEach((o,i)=>{const s=Number(o.price||o.sellingPrice||a||0),c=(o.size||"").trim(),n=(o.color||"").trim();let l=(o.name||o.variantLabel||"").trim();const p=!l||l.toLowerCase()==="default"||l.toLowerCase()==="existing stock"||l.toLowerCase()==="option"||l.toLowerCase()===(t||"").trim().toLowerCase()?"":l,m=`${s}_${c.toLowerCase()}_${n.toLowerCase()}_${p.toLowerCase()}`,g=parseFloat(o.stock)||0,u=parseFloat(o.wStock)||0;if(!r.has(m))r.set(m,{...o,price:s,sellingPrice:s,size:c,color:n,variantLabel:p,name:p||(c||n?`${c} ${n}`.trim():`MRP LKR ${s.toLocaleString()}`),stock:g,wStock:u,totalStock:g+u,batchSources:[{sourceDocId:o.sourceDocId,origIndex:i,stock:g,wStock:u}]});else{const y=r.get(m);y.stock+=g,y.wStock+=u,y.totalStock+=g+u;const f=parseFloat(y.wholesalePrice)||0,b=parseFloat(o.wholesalePrice)||0;b>0&&(f<=0||g>0&&y.stock<=g)&&(y.wholesalePrice=b);const w=parseFloat(y.loyaltyPrice)||0,v=parseFloat(o.loyaltyPrice)||0;v>0&&(w<=0||g>0&&y.stock<=g)&&(y.loyaltyPrice=v),y.batchSources.push({sourceDocId:o.sourceDocId,origIndex:i,stock:g,wStock:u})}}),Array.from(r.values())}window.consolidateVariants=at;const Ie=document.getElementById("product-detail-modal"),rt=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const t=(window.groupedProducts||[]).find(u=>u.docId===e)||E.find(u=>u.docId===e);if(!t)return;t.variants=at(t.variants,t.name,t.price);const a=Number(t.discount)||0,r=t.variants&&t.variants.length>1,o=t.variants&&t.variants.length>0?t.variants[0]:null;let i=t.image;o&&(o.image?i=o.image:o.images&&o.images.length>0&&(i=o.images[0]));const s=me(t,o),c=s.userType,n=s.isSpecial,l=s.retailPrice,d=s.discountedPrice,p=Se(t,o),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let g="";if(r){const u=[...new Set(t.variants.map(f=>f.size).filter(Boolean))],y=[...new Set(t.variants.map(f=>f.color).filter(Boolean))];if(u.length>0||y.length>0){let f="";y.length>0&&(f=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Color</span>

              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||y[0]}</span>

            </div>

            <div class="variant-pill-container" id="color-pill-group">

              ${y.map(w=>{const v=m[w.toLowerCase()]||"#64748b";return`

                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||y[0])===w?"active":""}" 

                    style="background-color: ${v};" 

                    title="${w}" data-color="${w}"

                    onclick="window.selectVariantByAttribute('${t.docId}', 'color', '${w}')">

                  </button>

                `}).join("")}

            </div>

          </div>

        `);let b="";u.length>0&&(b=`

          <div class="variant-selector-group">

            <div class="variant-selector-label">

              <span>Style / Size</span>

              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>

            </div>

            <div class="variant-pill-container" id="size-pill-group">

              ${u.map(w=>`

                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===w?"active":""}" 

                    data-size="${w}"

                    onclick="window.selectVariantByAttribute('${t.docId}', 'size', '${w}')">

                    ${w}

                  </button>

                `).join("")}

            </div>

          </div>

        `),g=`${f}${b}`}else g=`

        <div class="variant-selector-group">

          <div class="variant-selector-label">

            <span>Choose Option / MRP</span>

          </div>

          <div class="variant-pill-container">

            ${t.variants.map((f,b)=>{const w=Se(t,f);return`

              <div class="variant-mrp-card ${b===0?"active":""}" id="v-card-${b}"

                   onclick="window.updateDetailDisplay('${t.docId}', ${b})">

                <div style="flex:1;">

                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${f.variantLabel&&f.variantLabel.toLowerCase()!==t.name.toLowerCase()&&f.variantLabel.toLowerCase()!=="default"?f.variantLabel:f.size||f.color?`${f.size||""} ${f.color||""}`.trim():`MRP LKR ${(f.price||t.price||0).toLocaleString()}`}</div>

                  <div style="font-size: 0.75rem; color: #64748b;">${w>0?`In Stock (${w})`:"Out of stock"}</div>

                </div>

                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">

                  LKR ${(f.price||t.price||0).toLocaleString()}

                </div>

              </div>

            `}).join("")}

          </div>

        </div>

      `}Ie.innerHTML=`

        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>

        <div class="detail-content">

            <div class="detail-image-sec">

                <img src="${Ee(i,t.name)}" id="detail-main-img" 

                    alt="${t.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') && !window.currentStoreData.logoUrl.includes('mec-logo') ? window.currentStoreData.logoUrl : 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='80' height='80' fill='none'%3E%3Crect width='80' height='80' rx='14' fill='%231e293b'/%3E%3Cpath d='M40 20L62 31.5V56.5L40 68L18 56.5V31.5L40 20Z' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M18 31.5L40 43L62 31.5' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M40 43V68' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E');">

            </div>



            <div class="detail-info-sec">

                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${t.category}</div>

                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${t.name}</h2>

                ${n?`<div style="font-size: 0.8rem; color: ${c==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${c.toUpperCase()} APPLIED</div>`:""}

                

                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">

                    ${a>0||n?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}

                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${d.toFixed(2)}</span>

                </div>

                

                ${g}



                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">

                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}

                </div>

                

                <div class="detail-actions-sec">

                    <button class="add-to-cart-btn detail-add-btn" 

                            onclick="window.handleDetailAddToCart('${t.docId}')">

                        🛒 Add to Cart

                    </button>

                </div>

            </div>

        </div>

    `,window.activeDetailVariantIndex=0,Ie.classList.add("active"),rt.classList.add("active"),document.body.style.overflow="hidden",ee(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,t,a)=>{const r=(window.groupedProducts||[]).find(s=>s.docId===e)||E.find(s=>s.docId===e);if(!r||!r.variants)return;const o=window.activeDetailVariantIndex||0;r.variants[o]||r.variants[0];let i=r.variants.findIndex(s=>t==="color"?s.color===a:t==="size"?s.size===a:!1);if(i===-1&&(i=0),t==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(c=>{c.classList.toggle("active",c.dataset.color===a)});const s=document.getElementById("detail-selected-color");s&&(s.innerText=a)}if(t==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(c=>{c.classList.toggle("active",c.dataset.size===a)});const s=document.getElementById("detail-selected-size");s&&(s.innerText=a)}window.updateDetailDisplay(e,i)};window.closeProductDetail=()=>{Ie.classList.remove("active"),rt.classList.remove("active"),document.body.style.overflow=""};rt.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,t)=>{window.activeDetailVariantIndex=Number(t);const a=(window.groupedProducts||[]).find(d=>d.docId===e)||E.find(d=>d.docId===e);if(!a)return;const r=a.variants&&a.variants.length>0?a.variants[t]:null,o=document.getElementById("detail-main-img"),i=document.getElementById("detail-stock"),s=Ie.querySelector(".detail-original-price"),c=Ie.querySelector(".detail-final-price");if(o){let d=a.image;r&&(r.image?d=r.image:r.images&&r.images.length>0&&(d=r.images[0])),o.src=Ee(d,a.name)}document.querySelectorAll(".variant-mrp-card").forEach((d,p)=>{d.classList.toggle("active",p===Number(t))}),Number(a.discount);const n=me(a,r);s&&(s.innerText=`LKR ${n.retailPrice.toFixed(2)}`),c&&(c.innerText=`LKR ${n.discountedPrice.toFixed(2)}`);const l=Se(a,r);if(i){const d=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";i.innerHTML=d,i.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const t=(window.groupedProducts||[]).find(p=>p.docId===e)||E.find(p=>p.docId===e);if(!t)return;const a=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let r="Default",o=null;t.variants&&t.variants.length>0&&(o=t.variants[a]||t.variants[0],r=o.name||o.variantLabel||o.color||o.size||"Default");const s=me(t,o).effectivePrice,c=o&&o.cost!==void 0?Number(o.cost):Number(t.cost)||0,n=Se(t,o),l=k.findIndex(p=>p.docId===t.docId&&p.selectedVariant===r),d=l!==-1?(k[l].quantity||1)+1:1;if(t.mode!=="Service"&&t.mode!=="Technical"&&d>n){alert(`Sorry, out of stock! Only ${n} available.`);return}jt(t,r,s,c),window.closeProductDetail(),Be(!0)};function jt(e,t,a,r){const o=k.findIndex(i=>i.docId===e.docId&&i.selectedVariant===t);o!==-1?k[o].quantity=(k[o].quantity||1)+1:k.push({...e,selectedVariant:t,price:a,cost:r,quantity:1}),Le=k.reduce((i,s)=>i+(s.quantity||1),0),ot(),qe()}window.changeCartQty=(e,t,a)=>{var o;const r=k.findIndex(i=>i.docId===e&&i.selectedVariant===t);if(r!==-1){if(a>0){const i=E.find(s=>s.docId===e);if(i&&i.mode!=="Service"&&i.mode!=="Technical"){let s=null;t!=="Default"&&i.variants&&(s=i.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===t));const c=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",n=nt(i,s,c);if((k[r].quantity||1)+a>n){alert(c==="ShopPay"?`Sorry! Only ${n} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${n} available.`);return}}}k[r].quantity=(k[r].quantity||1)+a,k[r].quantity<=0&&k.splice(r,1),Le=k.reduce((i,s)=>i+(s.quantity||1),0),ot(),qe(),Ue()}};function qe(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(t=>{t&&(t.innerText=Le,t.classList.add("bump"),setTimeout(()=>t.classList.remove("bump"),300))})}function it(e,t,a){if(!e||!t||t.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let r=t;if(e.targetType==="specific_products"){const s=(e.selectedProducts||[]).map(c=>(c||"").trim().toLowerCase());if(r=t.filter(c=>{const n=(c.name||"").trim().toLowerCase(),l=(c.docId||"").trim().toLowerCase();return s.includes(n)||s.includes(l)}),r.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const s=(e.selectedCategories||[]).map(c=>(c||"").trim().toLowerCase());if(r=t.filter(c=>{const n=(c.category||"").trim().toLowerCase();return s.includes(n)}),r.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const o=r.reduce((s,c)=>{const n=c.discount||0,l=c.price*(1-n/100),d=c.quantity||1;return s+l*d},0);let i=0;return e.type==="Percentage"?i=o*(Number(e.value)/100):i=Math.min(o,Number(e.value)||0),{discountAmount:i,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function Ue(){var r;const e=k.reduce((o,i)=>{const s=i.discount||0,c=i.price*(1-s/100),n=i.quantity||1;return o+c*n},0);let t=0;if(window.appliedCoupon){const o=it(window.appliedCoupon,k);o.isValidForCart?t=o.discountAmount:window.appliedCoupon=null}const a=Math.max(0,e-t);xe.innerHTML=`

        <div class="cart-header">

            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>

            <button class="close-cart" id="close-cart-btn">&times;</button>

        </div>

        

        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">

            <div class="cart-body">

                ${k.length===0?`

                    <div class="cart-empty-state">

                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>

                        <p>Your cart is empty</p>

                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>

                    </div>

                `:k.map(o=>{const i=o.discount||0,s=o.price*(1-i/100),c=o.quantity||1,n=s*c;return`

                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">

                            <div class="cart-item-info" style="flex: 1;">

                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>

                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>

                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">

                                    ${i>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}

                                    LKR ${s.toFixed(2)} ${c>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${c} = LKR ${n.toFixed(2)}</span>`:""}

                                </div>

                            </div>

                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 

                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">

                                    -

                                </button>

                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${c}</span>

                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 

                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">

                                    +

                                </button>

                            </div>

                        </div>

                    `}).join("")}

            </div>



            ${k.length>0?`

                <div class="cart-footer">

                    <div class="delivery-info-banner">

                        <span>🚚</span>

                        <span>COD LKR 400 | Bank Transfer LKR 250</span>

                    </div>



                    <!-- Promo / Coupon Code Section -->

                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">

                        <div style="display: flex; gap: 0.5rem;">

                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>

                            ${window.appliedCoupon?`

                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>

                            `:`

                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>

                            `}

                        </div>

                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">

                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}

                        </div>

                    </div>

                    

                    ${window.appliedCoupon?`

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">

                            <span>Subtotal</span>

                            <span>LKR ${e.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">

                            <span>Coupon Discount (${window.appliedCoupon.code})</span>

                            <span>- LKR ${t.toFixed(2)}</span>

                        </div>

                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">

                            <span>Total Payable</span>

                            <span>LKR ${a.toFixed(2)}</span>

                        </div>

                    `:`

                        <div class="cart-subtotal">

                            <span>Total Payable</span>

                            <span>LKR ${e.toFixed(2)}</span>

                        </div>

                    `}



                    <div class="checkout-form-section">

                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>

                        <div class="input-group">

                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">

                        </div>

                        <div class="input-group">

                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">

                        </div>

                        <div class="input-group" id="delivery-address-group">

                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">

                        </div>

                        <div class="input-group" id="delivery-city-group">

                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">

                        </div>



                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>

                        <div class="payment-method-selector">

                            ${k.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">

                                <span class="method-label">COD</span>

                            </label>

                            `:""}

                            ${k.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="Bank" ${k.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">

                                <span class="method-label">Transfer</span>

                            </label>

                            `:""}

                            ${k.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`

                            <label class="method-option">

                                <input type="radio" name="payment-method" value="ShopPay" ${!k.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!k.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">

                                <span class="method-label">Shop Cash</span>

                            </label>

                            `:""}

                        </div>

                        

                        <!-- Bank Transfer Info Box -->

                        <div id="bank-details-box" style="display: none;">

                            <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.75rem;">

                                <p style="color: #065f46; font-weight: 800; margin: 0; font-size: 0.82rem; display: flex; align-items: center; gap: 6px;">

                                    <span>✨</span> Lower delivery charge (LKR 250)

                                </p>

                                <p style="color: #047857; margin: 3px 0 0; font-size: 0.75rem; font-weight: 600;">

                                    👇 Select the Bank Account you transferred to (ඔබ මුදල් තැන්පත් කළ ගිණුම තෝරන්න):

                                </p>

                            </div>



                            <!-- Account 1: Slot 1 (e.g. NDB) -->

                            <div id="web-bank-card-1" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot1')" style="background: #f0fdf4 !important; color: #0f172a !important; border: 2px solid #16a34a !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.15); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-1-radio" value="slot1" checked style="accent-color: #16a34a; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-1-title" style="font-weight: 900; color: #b91c1c; font-size: 0.95rem;">🏦 National Development Bank (NDB)</span>

                                    </div>

                                    <span id="web-bank-1-badge" style="font-size: 0.72rem; background: #16a34a; color: #ffffff; padding: 3px 8px; border-radius: 6px; font-weight: 800;">✓ Selected</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-1-accname" style="color: #0f172a; font-weight: 700;">-</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div id="web-bank-1-type-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">

                                    Account Type: <span id="web-bank-1-acctype" style="color: #0f172a; font-weight: 700;">Regular Current</span>

                                </div>

                                <div id="web-bank-1-codes-row" style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Bank Code: <strong id="web-bank-1-code" style="color: #334155;">7214</strong></span>

                                    <span>Swift Code: <strong id="web-bank-1-swift" style="color: #334155;">NDBSLKLX</strong></span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; border: 1.5px dashed #16a34a; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-1-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accno', 'Account Number');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <!-- Account 2: Slot 2 (e.g. BOC) -->

                            <div id="web-bank-card-2" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot2')" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1 !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: all 0.2s; position: relative;">

                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">

                                    <div style="display: flex; align-items: center; gap: 8px;">

                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-2-radio" value="slot2" style="accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">

                                        <span id="web-bank-2-title" style="font-weight: 900; color: #0284c7; font-size: 0.95rem;">🏦 Bank of Ceylon (BOC)</span>

                                    </div>

                                    <span id="web-bank-2-badge" style="font-size: 0.72rem; background: #f1f5f9; color: #64748b; padding: 3px 8px; border-radius: 6px; font-weight: 700;">Click to select</span>

                                </div>

                                <div id="web-bank-2-branch-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600; padding-left: 26px;">

                                    Branch: <span id="web-bank-2-branch" style="color: #0f172a; font-weight: 700;">Main Branch</span>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">

                                    <span>Account Name: <span id="web-bank-2-accname" style="color: #0f172a; font-weight: 700;">Account Holder</span></span>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">

                                    <div>

                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>

                                        <span id="web-bank-2-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>

                                    </div>

                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accno', 'Account Number');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">

                                        <span>📋</span> Copy

                                    </button>

                                </div>

                            </div>



                            <div style="margin-top: 1rem;">

                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>

                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">

                            </div>

                        </div>



                        <!-- Shop Pickup / Branch Selection Box -->

                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">

                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">

                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch

                            </p>



                            <!-- City / Town Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>

                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>

                                  ${xt().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}

                                </select>

                            </div>



                            <!-- Shop / Branch List Dropdown -->

                            <div style="margin-bottom: 0.85rem;">

                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>

                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 

                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">

                                  <!-- Injected by populatePickupShops -->

                                </select>

                            </div>



                            <!-- Selected Shop Info Card -->

                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">

                            </div>

                        </div>

                    </div>



                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">

                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">

                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">

                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 

                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 

                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.

                        </label>

                    </div>



                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">

                        Confirm Order

                    </button>

                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->

                </div>

            `:""}

        </div>

    `,document.getElementById("close-cart-btn").onclick=()=>Be(!1),(r=document.getElementById("checkout-btn"))==null||r.addEventListener("click",Vt),setTimeout(()=>{typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI()},50),window.toggleBankDetails=o=>{const i=document.getElementById("bank-details-box");i&&(i.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const i=document.getElementById("bank-details-box"),s=document.getElementById("shop-pickup-box"),c=document.getElementById("delivery-address-group"),n=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(i&&(i.style.display="block"),typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI(),s&&(s.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(i&&(i.style.display="none"),s&&(s.style.display="block",window.populatePickupShops()),c&&(c.style.display="none"),n&&(n.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(i&&(i.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="block"),n&&(n.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var d,p,m,g;const o=document.getElementById("pickup-town-select"),i=document.getElementById("pickup-shop-select"),s=document.getElementById("selected-shop-info-card");if(!i)return;const c=o?o.value:"All",n=ve();let l=n;c&&c!=="All"&&(l=n.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(c.toLowerCase()))),l.length===0?(i.innerHTML=n.map((u,y)=>`

        <option value="${u.docId||u.id||y}" ${y===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),s&&(s.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${c}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((d=n[0])==null?void 0:d.docId)||((p=n[0])==null?void 0:p.id)||0)):(i.innerHTML=l.map((u,y)=>`

        <option value="${u.docId||u.id||y}" ${y===0?"selected":""} style="color:#0f172a; background:#ffffff;">

          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}

        </option>

      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((g=l[0])==null?void 0:g.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const i=document.getElementById("selected-shop-info-card");if(!i)return;const s=ve(),c=s.find(n=>n.docId===o||n.id===o)||s[0];c&&(i.innerHTML=`

        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${c.name||c.shopName||"Main Branch"}</div>

        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${c.location||c.address||"In-store Pickup Counter"}</div>

        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${c.phone?`Contact: <b>${c.phone}</b>`:"Store Pickup Active"}</div>

        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">

          <span>✓</span> Collect & Pay Cash at this shop counter

        </div>

      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),t=document.getElementById("promo-message");if(!e)return;const a=e.value.trim().toUpperCase();if(!a){t&&(t.innerText="❌ Please enter a promo code.",t.style.color="#ef4444");return}t&&(t.innerText="⏳ Validating coupon...",t.style.color="var(--primary-color)");try{const r=T(zt,C("code","==",a),C("storeId","==",window.currentStoreId)),o=await A(r);if(o.empty){t&&(t.innerText="❌ Invalid or expired coupon code.",t.style.color="#ef4444");return}const i=o.docs[0],s={...i.data(),id:i.id},c=new Date().toISOString().split("T")[0];if(s.expiryDate<c){t&&(t.innerText="❌ This coupon has expired.",t.style.color="#ef4444");return}if(s.status!=="Active"){t&&(t.innerText="❌ This coupon is inactive.",t.style.color="#ef4444");return}const n=k.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=it(s,k,n);if(!l.isValidForCart){t&&(t.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,t.style.color="#ef4444");return}window.appliedCoupon=s,Ue();const d=document.getElementById("promo-message");if(d){const p=s.targetType==="specific_products"?" (Selected Items)":s.targetType==="specific_categories"?" (Selected Categories)":"";d.innerText=`✅ Coupon applied: ${s.type==="Percentage"?`${s.value}% OFF`:`LKR ${s.value} OFF`}${p}`,d.style.color="#10b981"}}catch(r){console.error("Error validating coupon:",r),t&&(t.innerText="❌ Error validating coupon code.",t.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,Ue()};async function Vt(){var m,g,u,y,f,b,w,v;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!");const x=window.currentStoreId?`/login.html?store=${encodeURIComponent(window.currentStoreId)}`:"/login.html";window.location.href=x;return}if(k.length===0)return;const t=document.getElementById("terms-agree");if(t&&!t.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const a=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),r=(g=document.getElementById("delivery-phone-2"))==null?void 0:g.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),i=(y=document.getElementById("delivery-city"))==null?void 0:y.value.trim(),s=((f=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:f.value)||"COD",c=(b=document.getElementById("deposit-slip"))==null?void 0:b.files[0],n=s==="ShopPay";let l=null,d="All";if(n){d=((w=document.getElementById("pickup-town-select"))==null?void 0:w.value)||"All";const x=(v=document.getElementById("pickup-shop-select"))==null?void 0:v.value,I=ve();if(l=I.find(P=>P.docId===x||P.id===x)||I[0],!x&&(!I||I.length===0)){alert("Please select a pickup shop / branch!");return}}if(!a||!n&&(!o||!i)){alert(n?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",a),localStorage.setItem("mec_saved_phone2",r),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",i),s==="Bank"&&!c){alert("Please upload your bank deposit slip!");return}for(const x of k){const I=E.find(P=>P.docId===x.docId)||(window.groupedProducts||[]).find(P=>P.docId===x.docId);if(I&&I.mode!=="Service"&&I.mode!=="Technical"){let P=null;x.selectedVariant&&x.selectedVariant!=="Default"&&I.variants&&(P=I.variants.find(z=>(z.name||z.variantLabel||z.color||z.size||"Variant")===x.selectedVariant));const B=nt(I,P,s);if((x.quantity||1)>B){alert(s==="ShopPay"?`Sorry! "${x.name}" only has ${B} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${x.name}" only has ${B} available in stock.`);return}}}const p=async(x=null)=>{var I,P;try{const B=k.reduce((h,_)=>h+_.price*(1-(_.discount||0)/100)*(_.quantity||1),0);let z=0,M="";if(window.appliedCoupon){M=window.appliedCoupon.code;const h=it(window.appliedCoupon,k,B);h.isValidForCart&&(z=h.discountAmount)}const $=Math.max(0,B-z),U=sessionStorage.getItem("mec_ref_code");let te="",oe=0;if(U)try{const h=T(D(S,"affiliates"),C("code","==",U),C("storeId","==",window.currentStoreId));(await A(h)).empty||(te=U,oe=Number(($*.05).toFixed(2)))}catch(h){console.error("Error verifying affiliate referral code at checkout:",h)}const V=window.currentStoreId||"",$e=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),ge=e&&(e.name||e.email)?e.name||e.email:a||"Guest Customer",fe=window.selectedWebStoreBankSlot||"slot1",N=window.webStoreBankAccounts&&window.webStoreBankAccounts[fe]||((I=window.webStoreBankAccounts)==null?void 0:I.slot1),G={orderId:"ORD-"+Date.now(),userId:$e,userName:ge,userEmail:e&&e.email?e.email:"",phone:a||"",phone2:r||"",branchId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:n?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:n?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:n?d:"",pickupShopPhone:n&&(l==null?void 0:l.phone)||"",pickupShopAddress:n&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:n?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:n?d!=="All"?d:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":i||"",items:k.map(h=>({id:h.id||h.docId||"",docId:h.docId||h.id||"",name:h.name||"",price:Number(h.price)||0,cost:Number(h.cost)||0,quantity:Number(h.quantity)||1,discount:Number(h.discount)||0,finalPrice:Number(h.price)*(1-(Number(h.discount)||0)/100)})),subtotal:Number(B)||0,discount:Number(z)||0,couponCode:M||"",total:Number($)||0,status:"Pending",customerType:(((P=window.currentUserProfile)==null?void 0:P.customerType)||"retail").toLowerCase(),paymentMethod:s||"COD",targetBankSlot:s==="Bank"?fe:null,targetBankAccountId:s==="Bank"&&(N==null?void 0:N.docId)||null,targetBankName:s==="Bank"?(N==null?void 0:N.bankName)||"Bank":null,targetAccountNo:s==="Bank"?(N==null?void 0:N.accountNo)||"":null,targetAccountTitle:s==="Bank"?(N==null?void 0:N.accountName)||"":null,bankCredited:s==="Bank",slipImage:x||"",codCharge:s==="COD"?400:s==="Bank"?250:0,isShopPending:s==="ShopPay",storeId:V,numericStoreId:"1001",stockDeducted:!0,stockReturned:!1,timestamp:ne(),date:new Date().toLocaleString(),referredBy:te||"",referredCommission:Number(oe)||0},ye=W(D(S,"stores",V,"orders")),we=ye.id;G.docId=we,await Promise.all([Ae(ye,G),Ae(W(Nt,we),G)]);try{const h=Pt(S);let _=!1;for(const F of k){const L=F.docId||F.id;if(L&&L!=="N/A"){const O=W(S,"stores",V,"products",L),We=await ze(O);if(We.exists()){const le=We.data(),st=Number(F.quantity)||1;let ae={};if(le.variants&&Array.isArray(le.variants)&&le.variants.length>0){const Q=[...le.variants];let re=st;for(let J=0;J<Q.length&&!(re<=0);J++){const K=Q[J],Te=Number(K.price||K.sellingPrice||le.price||0),It=Number(F.price||0);if(!F.selectedVariant||F.selectedVariant==="Default"||K.name===F.selectedVariant||K.variantLabel===F.selectedVariant||Math.abs(Te-It)<.01){const Ke=parseFloat(K.stock)||0;if(Ke>0){const lt=Math.min(Ke,re);K.stock=Ke-lt,re-=lt}}}if(re>0)for(let J=0;J<Q.length&&!(re<=0);J++){const K=parseFloat(Q[J].stock)||0;if(K>0){const Te=Math.min(K,re);Q[J].stock=K-Te,re-=Te}}ae.variants=Q,ae.stock=Q.reduce((J,K)=>J+(parseFloat(K.stock)||0),0)}else{const Q=parseFloat(le.stock)||0;ae.stock=Math.max(0,Q-st)}ae.totalStock=ae.stock,ae.updatedAt=ne(),h.update(O,ae),_=!0}}}_&&(await h.commit(),console.log("[Web Store Checkout] Stock deducted successfully for Order #"+G.orderId))}catch(h){console.warn("[Web Store Checkout] Stock deduction error (order recorded):",h)}if(s==="Bank"&&N)try{let h=N.docId;if(!h||h==="ndb_default"||h==="boc_default"){const _=T(D(S,"stores",V,"bank_accounts"),C("accountNo","==",N.accountNo)),F=await A(_);F.empty||(h=F.docs[0].id)}if(h&&h!=="ndb_default"&&h!=="boc_default"){const _=W(S,"stores",V,"bank_accounts",h);await wt(_,{balance:Ne($),updatedAt:ne()}),await Ce(D(S,"stores",V,"bank_transactions"),{accountId:h,bankName:N.bankName||"Bank Transfer",accountNo:N.accountNo||"",amount:$,type:"Credit",description:`Web Store Bank Transfer: Order #${G.orderId} (${ge})`,referenceNo:G.orderId,orderId:G.orderId,source:"Web Store",date:new Date().toLocaleDateString("sv-SE"),timestamp:ne(),isReconciled:!1,storeId:V}),console.log(`[Web Store Checkout] Credited LKR ${$} to ${N.bankName} (${N.accountNo})`)}}catch(h){console.warn("Error crediting web store bank account:",h)}if(te)try{const h=T(D(S,"affiliates"),C("code","==",te),C("storeId","==",V)),_=await A(h);if(!_.empty){const F=_.docs[0].id;await Ae(W(S,"affiliates",F),{salesCount:Ne(1),totalCommission:Ne(oe)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(h){console.error("Error updating affiliate statistics post-order:",h)}k=[],Le=0,window.appliedCoupon=null,ot(),qe(),Be(!1),alert(s==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":n?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch(B){console.error("Order error:",B),alert("Error placing order: "+(B.message||"Please try again."))}};if(c){const x=new FileReader;x.onload=I=>{const P=new Image;P.onload=()=>{const B=document.createElement("canvas"),z=1e3,M=1e3;let $=P.width,U=P.height;$>U?$>z&&(U*=z/$,$=z):U>M&&($*=M/U,U=M),B.width=$,B.height=U,B.getContext("2d").drawImage(P,0,0,$,U);const oe=B.toDataURL("image/jpeg",.6);p(oe)},P.onerror=()=>{p(I.target.result)},P.src=I.target.result},x.onerror=I=>{console.error("FileReader Error:",I),alert("Error reading slip file. Please try selecting the image again.")},x.readAsDataURL(c)}else p()}function R(){const e=document.querySelector("#product-grid"),t=document.getElementById("pagination-controls");if(!e)return;if(!window.productsLoadedFromFirestore&&(!E||E.length===0)){Ye();return}let a=E.filter(n=>{if(n.mode==="Service"||n.mode==="Technical"||n.mode==="POS"||n.status==="pending"||n.status==="Void"||n.status==="void")return!1;const l=(n.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const d=se==="All"||n.category===se,p=(pe||"").toLowerCase().trim();if(!p)return d;const m=window.matchProductSearch?window.matchProductSearch(n,p):(n.name||"").toLowerCase().includes(p)||(n.category||"").toLowerCase().includes(p)||n.sku&&String(n.sku).toLowerCase().includes(p);return d&&m});de==="recommended"?((!Ge||Ge.length!==a.length)&&(Ge=a.map((n,l)=>({id:l,sort:Math.random()})).sort((n,l)=>n.sort-l.sort).map(n=>n.id)),a.sort(()=>Math.random()-.5)):a.sort((n,l)=>{if(de==="az")return n.name.localeCompare(l.name);if(de==="za")return l.name.localeCompare(n.name);if(de==="low"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return d-p}if(de==="high"){const d=n.variants&&n.variants.length>0?n.variants[0].price:n.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-d}return 0});const r=new Map;a.forEach(n=>{const l=n.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),d=l?l[1].trim():n.name.trim(),p=l?l[2].trim():(n.size||n.color)&&`${n.size?n.size:""} ${n.color?n.color:""}`.trim()||"Default",m=d.toLowerCase();if(r.has(m)){const g=r.get(m);g.totalStock+=n.totalStock!==void 0?n.totalStock:n.stock||0;const u=parseFloat(n.wholesalePrice)||0,y=parseFloat(n.stock)||0,f=parseFloat(g.wholesalePrice)||0;u>0&&(f<=0||y>0&&(g.stock||0)<=0)&&(g.wholesalePrice=u,parseFloat(n.loyaltyPrice)>0&&(g.loyaltyPrice=n.loyaltyPrice),parseFloat(n.price)>0&&(g.price=n.price),parseFloat(n.cost)>0&&(g.cost=n.cost));const b=(n.variants||[]).map(w=>({...w,sourceDocId:n.docId}));b.length===0&&b.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),g.variants=[...g.variants,...b]}else{const g=(n.variants||[]).map(u=>({...u,sourceDocId:n.docId}));g.length===0&&g.push({name:p,price:n.price,wholesalePrice:n.wholesalePrice,loyaltyPrice:n.loyaltyPrice,cost:n.cost,stock:n.stock||0,images:[n.image],sourceDocId:n.docId}),r.set(m,{...n,name:d,totalStock:n.totalStock!==void 0?n.totalStock:n.stock||0,variants:g})}}),r.forEach(n=>{if(n.variants=at(n.variants,n.name,n.price),n.variants&&n.variants.length>0){const d=n.variants.find(p=>parseFloat(p.wholesalePrice)>0&&parseFloat(p.stock)>0)||n.variants.find(p=>parseFloat(p.wholesalePrice)>0);d&&(parseFloat(d.wholesalePrice)>0&&(n.wholesalePrice=parseFloat(d.wholesalePrice)),parseFloat(d.loyaltyPrice)>0&&(n.loyaltyPrice=parseFloat(d.loyaltyPrice)))}const l=n.variants.reduce((d,p)=>d+(parseFloat(p.stock)||0)+(parseFloat(p.wStock)||0),0);l>0&&(n.stock=l,n.totalStock=l)}),window.groupedProducts=Array.from(r.values());const o=window.groupedProducts.length,i=Math.ceil(o/Ve);q>i&&i>0&&(q=i),q<1&&(q=1);const s=(q-1)*Ve,c=window.groupedProducts.slice(s,s+Ve);if(window.groupedProducts.length===0){if(!window.productsLoadedFromFirestore&&(!E||E.length===0)){Ye();return}e.innerHTML=`
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>

        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${pe}</strong>".<br>Try a different keyword or browse all categories.</p>

        <button onclick="window.clearSearch()" 

          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"

          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">

          Clear Search

        </button>

      </div>`,t&&(t.innerHTML="");return}if(e.innerHTML=c.map((n,l)=>{const d=n.variants&&n.variants.length>1,p=n.variants&&n.variants.length>0?n.variants[0]:null,m=me(n,p),g=m.retailPrice,u=m.discountedPrice,y=m.isSpecial,f=m.userType,b=Number(n.discount)||0;let w=Se(n,p);isNaN(w)&&(w=0);let v=n.image;(!v||v.trim()===""||v.includes("/logo.png"))&&p&&(p.images&&p.images.length>0?v=p.images[0]:p.image&&(v=p.image)),v=Ee(v,n.name);const x=n.timestamp?typeof n.timestamp.toMillis=="function"?n.timestamp.toMillis():typeof n.timestamp=="number"?n.timestamp:0:0,I=x>0&&Date.now()-x<10080*60*1e3;return`

    <div class="product-card" id="product-${n.docId}">

      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${n.docId}')">

        <div class="image-slider-container" style="height: 100%; width: 100%;">

            <img src="${v}" class="main-product-img" alt="${n.name}" ${l<4?'fetchpriority="high"':'loading="lazy"'} decoding="async"

                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') && !window.currentStoreData.logoUrl.includes('mec-logo') ? window.currentStoreData.logoUrl : 'data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80' width='80' height='80' fill='none'%3E%3Crect width='80' height='80' rx='14' fill='%231e293b'/%3E%3Cpath d='M40 20L62 31.5V56.5L40 68L18 56.5V31.5L40 20Z' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M18 31.5L40 43L62 31.5' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M40 43V68' stroke='%23475569' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E');" 

                style="width:100%; height:100%; object-fit:cover;">

        </div>

        ${w<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}

        ${b>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${b}% OFF</div>`:I?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}

        

        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">

            ${((p==null?void 0:p.images)||[n.image]).map((P,B)=>`<div class="dot ${B===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${B===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}

        </div>



        ${d?`

          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')">

            Select Options

          </button>

        `:`

          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${n.docId}')" ${w<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>

            ${w<=0?"Out of Stock":"Add to Cart"}

          </button>

        `}

      </div>

      <div class="product-info">

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">

          <div style="font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; letter-spacing: 0.3px;">${n.category||"General"}</div>

          <div class="stock-display" style="font-size: 0.72rem; font-weight:700;">

            ${w<=0?'<span style="color:#ef4444; background:rgba(239,68,68,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Out of Stock</span>':w<5?`<span style="color:#f59e0b; background:rgba(245,158,11,0.14); padding:2px 6px; border-radius:4px; font-weight:800; font-size:0.68rem;">Only ${w} left</span>`:`<span style="color:#10b981; font-weight:700;">Stock: ${w}</span>`}

          </div>

        </div>

        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${n.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">

          ${n.name}

        </div>

        





        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">

            ${b>0||y?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${g.toFixed(2)}</span>`:""}

            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${u.toFixed(2)}</span>

            ${y?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}

        </div>

      </div>

    </div>`}).join(""),t)if(i>1){let n=`<button class="pag-nav-btn" ${q===1?"disabled":""} onclick="window.changePage(${q-1})">‹ Previous</button>`;const l=5;let d=Math.max(1,q-2),p=Math.min(i,d+l-1);p===i&&(d=Math.max(1,p-l+1)),d>1&&(n+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',d>2&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=d;m<=p;m++)n+=`<button class="pag-page-btn ${m===q?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<i&&(p<i-1&&(n+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),n+=`<button class="pag-page-btn" onclick="window.changePage(${i})">${i}</button>`),n+=`<button class="pag-nav-btn" ${q===i?"disabled":""} onclick="window.changePage(${q+1})">Next ›</button>`,t.innerHTML=n}else t.innerHTML=""}window.changePage=e=>{var t;q=e,R(),(t=document.getElementById("shop-section"))==null||t.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,t)=>{const a=window.groupedProducts?window.groupedProducts.find(v=>v.docId===e):null,r=document.getElementById(`product-${e}`);if(!a||!r)return;const o=a.variants&&a.variants[t]?a.variants[t]:null,i=me(a,o),s=i.retailPrice,c=i.discountedPrice,n=i.isSpecial,l=Number(a.discount)||0,d=o&&o.stock!==void 0?o.stock:a.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:a.images&&a.images.length>0?p=a.images:p=[a.image];const m=p.map(v=>Ee(v,a.name)),g=r.querySelector(".original-price"),u=r.querySelector(".final-price");g&&(g.innerText=`LKR ${s.toFixed(2)}`,g.style.display=l>0||n?"inline":"none"),u&&(u.innerText=`LKR ${c.toFixed(2)}`);const y=r.querySelector(".stock-display");y.innerText=`Stock: ${d}`,y.style.color=d<5?"#ef4444":"#10b981";const f=r.querySelector(".add-to-cart-btn");d<=0?(f.disabled=!0,f.innerText="Out of Stock",f.style.background="#cbd5e1",f.style.cursor="not-allowed"):(f.disabled=!1,f.innerText="Add to Cart",f.style.background="",f.style.cursor="pointer");const b=r.querySelector(".main-product-img");b.src=m[0];const w=r.querySelector(".image-dots");if(w.innerHTML=m.map((v,x)=>`<div class="dot ${x===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${x===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let v=0;r.imageInterval&&clearInterval(r.imageInterval),r.imageInterval=setInterval(()=>{v=(v+1)%m.length,b.style.opacity="0.5",setTimeout(()=>{b.src=m[v],b.style.opacity="1",w.querySelectorAll(".dot").forEach((I,P)=>{I.style.background=P===v?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else r.imageInterval&&clearInterval(r.imageInterval)};function Gt(){const e=document.getElementById("nav-auth-item"),t=document.getElementById("user-profile");document.getElementById("user-display-name"),Et(ct,a=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),a){const r={name:a.displayName||a.email.split("@")[0],email:a.email,id:a.uid};sessionStorage.setItem("mec_user",JSON.stringify(r));const o=()=>{var x,I,P,B,z;if(!e)return;const d=(((x=window.currentUserProfile)==null?void 0:x.customerType)||"retail").toLowerCase(),p=((I=window.currentUserProfile)==null?void 0:I.phone)||((P=window.currentUserProfile)==null?void 0:P.contact)||"",m=a.photoURL||((B=window.currentUserProfile)==null?void 0:B.photoURL)||((z=window.currentUserProfile)==null?void 0:z.avatar)||"",u=(M=>{if(!M)return"U";const $=M.trim().split(" ");return $.length>=2?($[0][0]+$[1][0]).toUpperCase():M.slice(0,2).toUpperCase()})(r.name),y=d==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':d==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=d==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">

               <span>👑</span> Wholesale Customer (Wholesale Price Active)

             </div>`:d==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>💎</span> Loyalty Card Member Active

                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">

                   <span>🛍️</span> Standard Retail Customer

                 </div>`;e.innerHTML=`

          <div style="position: relative; display: inline-block;">

            <!-- Circular Avatar Only Trigger Button -->

            <button id="user-profile-trigger" style="

              background: transparent;

              border: none;

              padding: 2px;

              cursor: pointer;

              outline: none;

              display: flex;

              align-items: center;

              justify-content: center;

              position: relative;

            " title="${r.name}">

              

              <!-- Circular Avatar Photo / Initials -->

              <div style="

                width: 38px;

                height: 38px;

                border-radius: 50%;

                background: linear-gradient(135deg, #0284c7, #6366f1);

                display: flex;

                align-items: center;

                justify-content: center;

                font-weight: 800;

                font-size: 0.88rem;

                color: white;

                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);

                border: 2px solid ${d==="wholesale"?"#eab308":d==="loyalty"?"#10b981":"#38bdf8"};

                overflow: hidden;

                flex-shrink: 0;

                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;

              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 

                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">

                ${m?`<img src="${m}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:u}

              </div>



              <!-- Status Badge Dot -->

              ${d==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':d==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}

            </button>



            <!-- Modern Floating Profile Card Dropdown -->

            <div id="user-profile-dropdown" style="

              display: none;

              position: absolute;

              right: 0;

              top: calc(100% + 12px);

              width: 290px;

              background: #0f172a;

              border: 1px solid rgba(255, 255, 255, 0.15);

              border-radius: 16px;

              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);

              padding: 1.25rem;

              z-index: 10000;

              text-align: left;

            ">

              <!-- Profile Card Header -->

              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">

                <div style="

                  width: 46px;

                  height: 46px;

                  border-radius: 50%;

                  background: linear-gradient(135deg, #0284c7, #8b5cf6);

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  font-weight: 900;

                  font-size: 1.1rem;

                  color: white;

                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);

                  border: 2px solid rgba(255,255,255,0.6);

                  overflow: hidden;

                  flex-shrink: 0;

                ">

                  ${m?`<img src="${m}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:u}

                </div>

                <div style="overflow: hidden; flex: 1;">

                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">

                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">

                      ${r.name}

                    </span>

                    ${y}

                  </div>

                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">

                    ${r.email||"Registered Customer"}

                  </div>

                </div>

              </div>



              <!-- Account Details & Benefits -->

              <div style="margin: 12px 0;">

                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">

                  Account Membership

                </div>

                ${f}

                

                ${p?`

                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">

                    <span style="color:#38bdf8;">📞</span> <span>${p}</span>

                  </div>

                `:""}

              </div>



              <!-- Quick Actions -->

              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">

                <a href="/track.html" style="

                  display: flex;

                  align-items: center;

                  justify-content: space-between;

                  padding: 8px 12px;

                  background: rgba(255, 255, 255, 0.05);

                  border: 1px solid rgba(255, 255, 255, 0.08);

                  border-radius: 8px;

                  color: #f1f5f9;

                  text-decoration: none;

                  font-size: 0.82rem;

                  font-weight: 600;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"

                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">

                  <span style="display:flex; align-items:center; gap:8px;">

                    <span>📦</span> Track My Orders

                  </span>

                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>

                </a>

              </div>



              <!-- Divider & Logout Button -->

              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">

                <button id="nav-logout-btn" style="

                  width: 100%;

                  display: flex;

                  align-items: center;

                  justify-content: center;

                  gap: 8px;

                  background: rgba(239, 68, 68, 0.12);

                  border: 1px solid rgba(239, 68, 68, 0.3);

                  color: #f87171;

                  padding: 8px 12px;

                  border-radius: 8px;

                  font-size: 0.85rem;

                  font-weight: 700;

                  cursor: pointer;

                  transition: all 0.2s;

                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"

                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">

                  <span>🚪</span> Log Out

                </button>

              </div>

            </div>

          </div>

        `;const b=document.getElementById("user-profile-trigger"),w=document.getElementById("user-profile-dropdown");b&&w&&(b.onclick=M=>{M.stopPropagation();const $=w.style.display==="block";w.style.display=$?"none":"block"});const v=document.getElementById("nav-logout-btn");v&&(v.onclick=async M=>{if(M.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await Bt(ct),window.location.href="/"}catch($){console.error("Logout Error:",$),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",d=>{const p=document.getElementById("user-profile-trigger"),m=document.getElementById("user-profile-dropdown");m&&p&&!p.contains(d.target)&&!m.contains(d.target)&&(m.style.display="none")}),o();const i=(a.email||"").trim(),s=i.toLowerCase(),c=window.currentStoreId||(window.location.hostname.includes("mecbookshop")||window.location.hostname.includes("mec-book-shop")?"mec-book-shop":"");if(!c)return;const n=T(D(S,"stores",c,"customers"),C("email","==",i)),l=T(D(S,"stores",c,"customers"),C("email","==",s));Promise.all([A(n),A(l)]).then(([d,p])=>{let m=null;if(d.empty?p.empty||(m=p.docs[0].data()):m=d.docs[0].data(),m){const g=(m.customerType||m.type||(m.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...m,customerType:g},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),R()}else{const g=window.currentStoreId||"";A(T(D(S,"stores",g,"customers"))).then(u=>{const y=(a.displayName||a.email.split("@")[0]||"").trim().toLowerCase(),f=u.docs.find(b=>{const w=b.data(),v=(w.email||"").trim().toLowerCase(),x=(w.phone||"").trim(),I=(w.name||"").trim().toLowerCase(),P=v&&v===s,B=a.phoneNumber&&x&&(x===a.phoneNumber||a.phoneNumber.includes(x)),z=I&&y&&(I===y||y.includes(I)||I.includes(y)||y.split(" ")[0]===I);return P||B||z});if(f){const b=f.data(),w=(b.customerType||b.type||(b.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...b,customerType:w,docId:f.id},!b.email&&a.email&&wt(W(S,"stores",g,"customers",f.id),{email:a.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),R()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),R()})}}).catch(d=>{console.error("Error fetching user profile:",d),window.currentUserProfile={customerType:"retail"},o(),R()})}else{if(sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},Array.isArray(E)&&E.length>0&&R(),e){const r=window.currentStoreId?`/login.html?store=${encodeURIComponent(window.currentStoreId)}`:"/login.html";e.innerHTML=`<a href="${r}">Login</a>`}t&&(t.style.display="none")}})}function Jt(){const e=document.getElementById("reviews-container");if(!e)return;const t=D(S,"reviews"),a=T(t,Lt("timestamp","desc"),bt(15));ue(a,r=>{const o=r.docs.map(i=>i.data());if(o.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=o.map(i=>`

      <div class="review-card">

        <div class="review-stars">

          ${"★".repeat(i.rating)}${"☆".repeat(5-i.rating)}

        </div>

        <p class="review-comment">"${i.comment||"No comment provided."}"</p>

        <div class="review-footer">

          <span class="review-author">${i.userName}</span>

          <span class="review-date">${i.date}</span>

        </div>

      </div>

    `).join("")})}qt();Gt();Jt();const Ze="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let Xe=null;try{Ze&&(Xe=new Ct(Ze))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function mt(e,t){if(!E||E.length===0)return t?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const r=(e||"").toLowerCase().split(/\s+/).filter(i=>i.length>2),o=E.map(i=>{let s=0;const c=(i.name||"").toLowerCase(),n=(i.category||"").toLowerCase(),l=(i.description||"").toLowerCase();return r.forEach(d=>{c.includes(d)&&(s+=3),n.includes(d)&&(s+=2),l.includes(d)&&(s+=1)}),{product:i,score:s}}).filter(i=>i.score>0).sort((i,s)=>s.score-i.score);if(o.length>0){const i=o.slice(0,3).map(s=>s.product);return t?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${i.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=c.wholesalePrice?` | තොග මිල: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${i.map(c=>{const n=c.stock>0||c.variants&&c.variants.some(d=>d.stock>0)?"In Stock":"Out of Stock",l=c.wholesalePrice?` | Wholesale: LKR ${c.wholesalePrice}`:"";return`• ${c.name} - LKR ${c.price}${l} [${n}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return t?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function Qt(e,t){var r,o,i,s,c,n;const a=/[\u0D80-\u0DFF]/.test(e)||t==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((r=window.currentStoreData)==null?void 0:r.name)||"Official Store",d=(E||[]).slice(0,50).map(u=>{let y=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?y+=` [Variants: ${u.variants.map(f=>`${f.name||f.variantLabel||"Var"}-Stock:${f.stock||0}`).join(", ")}]`:y+=` [Stock: ${u.stock||0}]`,y}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.

Available Inventory & Prices:

${d}



CRITICAL RULES:

1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).

2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.

3. Keep answers concise, clear, and direct (max 2-3 short sentences).

4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(Xe)try{const b=(await(await Xe.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(b)return b}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Ze)}`,g=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(g.ok){const u=await g.json(),y=(n=(c=(s=(i=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:i.content)==null?void 0:s.parts)==null?void 0:c[0])==null?void 0:n.text;if(y&&y.trim())return y.trim()}return mt(e,a)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),mt(e,a)}}window.toggleGeminiChat=e=>{var o;const t=document.getElementById("gemini-chat-window"),a=document.getElementById("gemini-bubble");if(!t)return;(e!=null?!!e:!t.classList.contains("active"))?(t.classList.add("active"),a&&a.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):t.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),t=document.getElementById("gemini-chat-messages");if(!e||!t||!e.value.trim())return;const a=e.value.trim();e.value="";const r=document.createElement("div");r.className="user-msg",r.textContent=a,t.appendChild(r),t.scrollTop=t.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",t.appendChild(o),t.scrollTop=t.scrollHeight;const i=a.toLowerCase(),s=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let c=a,n=!1;if(s.forEach(m=>{i.includes(m)&&(n=!0)}),n&&(s.forEach(m=>{c=c.replace(new RegExp(m,"gi"),"")}),c=c.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),c.length>1)){window.searchQuery=c,pe=c;const m=document.getElementById("store-search");m&&(m.value=c),q=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(a)||["mata","thiyenawada","tiyenawada","poth"].some(m=>i.includes(m)),d=await Qt(a,l?"si":"en");o.textContent=d,t.scrollTop=t.scrollHeight};window.talkToAgentWhatsApp=()=>{var i,s,c;const e=document.getElementById("gemini-chat-messages");let t="";e&&(t=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let a=((i=window.currentStoreData)==null?void 0:i.phone)||((s=window.systemConfig)==null?void 0:s.invPhone)||"94770658356";a=a.replace(/[^0-9]/g,""),a.startsWith("0")&&(a="94"+a.substring(1));const r=`Hi ${((c=window.currentStoreData)==null?void 0:c.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(r+t);window.open(`https://wa.me/${a}?text=${o}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const gt=document.getElementById("gemini-orb-btn");gt&&gt.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=ht.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const t=T(D(S,"affiliates"),C("code","==",e),C("storeId","==",window.currentStoreId)),a=await A(t);if(!a.empty){const r=W(S,"affiliates",a.docs[0].id);await Ae(r,{clicks:Ne(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(t){console.error("Error incrementing referral click:",t)}}};function Yt(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="aff-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>

        

        <!-- Tab navigation inside modal -->

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>

        </div>



        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>

        </form>

      </div>



      <div id="aff-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>

        

        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">

          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>

          <div style="display:flex; gap:10px; align-items:center;">

            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">

            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>

          </div>

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">

            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>

            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>

          </div>

        </div>



        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(e)}function Zt(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`

    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">

      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>

      

      <div id="seller-auth-section">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>

        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>

        

        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">

          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>

          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>

        </div>



        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">

          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>

        </form>



        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">

          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">

          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>

        </form>

      </div>



      <div id="seller-dashboard-section" style="display:none;">

        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">

          <div>

            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>

            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>

          </div>

          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">

            Pending

          </div>

        </div>



        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">

          

          <!-- Add Product Form -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>

            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">

              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">

              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>

              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>

            </form>

          </div>



          <!-- Product List -->

          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">

            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>

            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">

              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>

            </div>

          </div>

        </div>



        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>

      </div>

    </div>

  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{Yt();const t=document.getElementById("affiliate-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const a=localStorage.getItem("mec_affiliate_user");if(a){const r=JSON.parse(a);try{const o=T(D(S,"affiliates"),C("email","==",r.email),C("storeId","==",window.currentStoreId)),i=await A(o);if(i.empty)localStorage.removeItem("mec_affiliate_user"),et();else{const s={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(s)),Me(s)}}catch(o){console.error(o),Me(r)}}else et()}};function et(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const t=document.getElementById("aff-login-form"),a=document.getElementById("aff-register-form"),r=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");e==="login"?(t&&(t.style.display="flex"),a&&(a.style.display="none"),r&&(r.style.color="#38bdf8",r.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),a&&(a.style.display="flex"),r&&(r.style.color="#94a3b8",r.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const t=document.getElementById("aff-login-email").value.trim(),a=document.getElementById("aff-login-pass").value;try{const r=T(D(S,"affiliates"),C("email","==",t),C("password","==",a),C("storeId","==",window.currentStoreId)),o=await A(r);if(o.empty)alert("Invalid email address or password.");else{const i={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(i)),Me(i)}}catch(r){console.error(r),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const t=document.getElementById("aff-reg-name").value.trim(),a=document.getElementById("aff-reg-email").value.trim(),r=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const i=T(D(S,"affiliates"),C("email","==",a),C("storeId","==",window.currentStoreId));if(!(await A(i)).empty){alert("An account with this email is already registered as a partner.");return}const c=t.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),n={name:t,email:a,phone:r,password:o,code:c,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:ne()},l=await Ce(D(S,"affiliates"),n);n.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(n)),Me(n)}catch(i){console.error(i),alert("Registration failed. Please try again.")}};function Me(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const t=window.location.protocol,a=window.location.host,r=window.location.pathname;let o=`${t}//${a}${r}`;window.currentStoreId?o+=`?store=${window.currentStoreId}&ref=${e.code}`:o+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),et()};window.toggleSellerPortal=async e=>{Zt();const t=document.getElementById("seller-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const a=localStorage.getItem("mec_seller_user");if(a){const r=JSON.parse(a);try{const o=T(D(S,"vendor_shops"),C("email","==",r.email),C("storeId","==",window.currentStoreId)),i=await A(o);if(i.empty)localStorage.removeItem("mec_seller_user"),tt();else{const s={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(s)),_e(s)}}catch(o){console.error(o),_e(r)}}else tt()}};function tt(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const t=document.getElementById("seller-login-form"),a=document.getElementById("seller-register-form"),r=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");e==="login"?(t&&(t.style.display="flex"),a&&(a.style.display="none"),r&&(r.style.color="#38bdf8",r.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),a&&(a.style.display="flex"),r&&(r.style.color="#94a3b8",r.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const t=document.getElementById("seller-login-email").value.trim(),a=document.getElementById("seller-login-pass").value;try{const r=T(D(S,"vendor_shops"),C("email","==",t),C("password","==",a),C("storeId","==",window.currentStoreId)),o=await A(r);if(o.empty)alert("Invalid email address or password.");else{const i={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(i)),_e(i)}}catch(r){console.error(r),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{var s;e.preventDefault();const t=document.getElementById("seller-reg-shopname").value.trim(),a=document.getElementById("seller-reg-owner").value.trim(),r=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),i=document.getElementById("seller-reg-pass").value;try{const c=T(D(S,"vendor_shops"),C("shopName","==",t),C("storeId","==",window.currentStoreId));if(!(await A(c)).empty){alert("This shop name is already registered.");return}const l=T(D(S,"vendor_shops"),C("email","==",r),C("storeId","==",window.currentStoreId));if(!(await A(l)).empty){alert("This email is already registered to a shop.");return}const p={shopName:t,ownerName:a,email:r,phone:o,password:i,status:"pending",storeId:window.currentStoreId,timestamp:ne()},m=await Ce(D(S,"vendor_shops"),p);p.docId=m.id,localStorage.setItem("mec_seller_user",JSON.stringify(p)),_e(p);try{const g=(s=window.systemConfig)==null?void 0:s.smsConfig;if(g!=null&&g.apiKey&&(g!=null&&g.userId)){const u="+94770658356",y=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${t}
Owner: ${a}
Phone: ${o}
Email: ${r}`,f=`${g.apiBase||"https://www.smslenz.lk/api/send-sms"}?user_id=${g.userId}&api_key=${g.apiKey}&sender_id=${g.senderId||"MECPOS"}&contact=${encodeURIComponent(u)}&message=${encodeURIComponent(y)}`;fetch(f,{method:"GET",mode:"no-cors"}).catch(()=>{})}}catch(g){console.warn("Vendor registration alert:",g)}}catch(c){console.error(c),alert("Shop registration failed. Please try again.")}};async function _e(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const t=document.getElementById("seller-dash-status-badge");t&&(t.innerText=e.status||"pending",e.status==="active"?(t.style.background="rgba(16, 185, 129, 0.2)",t.style.color="#10b981"):(t.style.background="rgba(251, 191, 36, 0.2)",t.style.color="#fbbf24")),await St(e.email)}async function St(e){const t=document.getElementById("seller-products-list");if(t){t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const a=T(vt,C("vendorId","==",e),C("storeId","==",window.currentStoreId)),r=await A(a);if(r.empty)t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";r.forEach(i=>{const s=i.data(),c=s.status==="active"?"#10b981":"#fbbf24";o+=`

          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">

            <div>

              <span style="font-weight:bold; font-size:0.85rem; display:block;">${s.name||""}</span>

              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${s.price||0}</span>

            </div>

            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${c};">${s.status||"pending"}</span>

          </div>

        `}),t.innerHTML=o}}catch(a){console.error(a),t.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const t=localStorage.getItem("mec_seller_user");if(!t)return;const a=JSON.parse(t),r=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),i=document.getElementById("seller-prod-category").value.trim(),s=document.getElementById("seller-prod-image").value.trim(),c=document.getElementById("seller-prod-desc").value.trim();try{const n={name:r,price:Number(o),category:i,image:s||"",description:c||"",status:"pending",vendorId:a.email,storeId:window.currentStoreId,timestamp:ne(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await Ce(vt,n),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await St(a.email)}catch(n){console.error(n),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),tt()};window.addEventListener("beforeunload",function(e){var t;(t=window.chrome)!=null&&t.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
