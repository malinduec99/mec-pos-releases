import{g as _,q as z,c as B,d as h,w as R,u as F,b as $,s as H,o as j,a as V,f as le,e as A}from"./firebase-CVcZ1MF3.js";/* empty css              */import{g as Q,a as ce}from"./sriLankaPayrollEngine-aKTHt9oj.js";window.staffLogin=async()=>{var s,d;const e=(((s=document.getElementById("staff-phone"))==null?void 0:s.value)||"").trim(),o=(((d=document.getElementById("staff-pin"))==null?void 0:d.value)||"").trim();if(!e||!o)return m("Please enter both Phone and PIN");const t=document.getElementById("section-login"),a=document.getElementById("login-loading");document.getElementById("section-dashboard");const n=document.getElementById("section-pin-setup");t&&(t.style.display="none"),a&&(a.style.display="block");try{const i=e.replace(/\D/g,"");let r=await _(z(B(h,"employees"),R("phone","==",e)));if(r.empty){const k=(await _(B(h,"employees"))).docs.find(w=>{const P=(w.data().phone||"").replace(/\D/g,"");return P&&i&&(P===i||P.endsWith(i.slice(-9))||i.endsWith(P.slice(-9)))});k&&(r={empty:!1,docs:[k]})}if(r.empty)throw new Error("Mobile number not registered.");const p=r.docs[0].data();p.docId=r.docs[0].id;const c=(p.pin||"").toString().trim(),l=(p.regno||"").toString().trim(),f=(p.password||"").toString().trim(),u=(p.username||"").toString().trim(),g=o.trim(),y=!!p.pinChanged,b=p.mustResetPin===!0||p.isTemporaryPin===!0||!y;let x=!1,v=!1;const S=c&&g===c,I=f&&g===f,L=l&&g.toLowerCase()===l.toLowerCase(),M=u&&g.toLowerCase()===u.toLowerCase();if(y&&!p.mustResetPin)if(S||I||M)x=!0;else throw L&&l!==c?new Error("Initial Temporary ID has expired! Please enter your personal 4-6 digit Security PIN."):new Error("Invalid Security PIN. (Check your 4-6 digit PIN or Password)");else if(S||L||I||M)x=!0,v=!0;else throw new Error(`Invalid Security PIN or Password. (Expected PIN: ${c||l||"PIN"} or Password: ${f||"password"})`);if(!x)throw new Error("Authentication failed.");if(window.pendingAuthStaff=p,v||b){if(a&&(a.style.display="none"),n){n.style.display="block";const T=document.getElementById("pin-setup-staff-name");T&&(T.innerText=p.name||"Staff Member");const k=document.getElementById("staff-new-pin");k&&(k.value="",k.focus());const w=document.getElementById("staff-confirm-pin");w&&(w.value="")}else q(p);return}q(p)}catch(i){m(i.message),a&&(a.style.display="none"),t&&(t.style.display="block")}};window.submitStaffPinSetup=async()=>{var n,s;const e=window.pendingAuthStaff;if(!e||!e.docId){m("Session expired, please try again."),window.location.reload();return}const o=(((n=document.getElementById("staff-new-pin"))==null?void 0:n.value)||"").trim(),t=(((s=document.getElementById("staff-confirm-pin"))==null?void 0:s.value)||"").trim();if(!o||!t)return m("Please enter and confirm your new PIN.");if(!/^\d{4,6}$/.test(o))return m("PIN must be 4 to 6 numeric digits (0-9).");if(o!==t)return m("New PIN and Confirm PIN do not match.");if(e.regno&&o.toLowerCase()===e.regno.toLowerCase())return m("New PIN cannot be your old Employee ID.");const a=document.getElementById("btn-save-new-pin");a&&(a.disabled=!0,a.innerText="Securing PIN...");try{await F($(h,"employees",e.docId),{pin:o,mustResetPin:!1,isTemporaryPin:!1,pinChanged:!0,pinUpdatedAt:H()}),e.pin=o,e.mustResetPin=!1,e.isTemporaryPin=!1,e.pinChanged=!0,m("✅ Personal PIN saved! Welcome to your Portal.");const d=document.getElementById("section-pin-setup");d&&(d.style.display="none"),q(e)}catch(d){console.error(d),m("Error updating PIN: "+d.message),a&&(a.disabled=!1,a.innerText="Save & Unlock Portal")}};window.toggleStaffPinVisibility=(e,o)=>{const t=document.getElementById(e);t&&(t.type==="password"?(t.type="text",o&&(o.innerText="🙈")):(t.type="password",o&&(o.innerText="👁️")))};window.openChangePinModal=()=>{const e=document.getElementById("staff-change-pin-modal");if(e){e.style.display="flex";const o=document.getElementById("change-pin-current");o&&(o.value="",o.focus());const t=document.getElementById("change-pin-new");t&&(t.value="");const a=document.getElementById("change-pin-confirm");a&&(a.value="")}};window.closeChangePinModal=()=>{const e=document.getElementById("staff-change-pin-modal");e&&(e.style.display="none")};window.submitChangePinInDashboard=async()=>{var s,d,i;const e=window.currentStaff;if(!e||!e.docId)return m("Session expired, please re-login.");const o=(((s=document.getElementById("change-pin-current"))==null?void 0:s.value)||"").trim(),t=(((d=document.getElementById("change-pin-new"))==null?void 0:d.value)||"").trim(),a=(((i=document.getElementById("change-pin-confirm"))==null?void 0:i.value)||"").trim();if(!o||!t||!a)return m("Please fill in all PIN fields.");if(o!==(e.pin||"").toString().trim()&&o!==(e.password||"").toString().trim())return m("Current PIN is incorrect.");if(!/^\d{4,6}$/.test(t))return m("New PIN must be 4 to 6 numeric digits.");if(t!==a)return m("New PIN and confirmation do not match.");const n=document.getElementById("btn-submit-change-pin");n&&(n.disabled=!0,n.innerText="Updating PIN...");try{await F($(h,"employees",e.docId),{pin:t,mustResetPin:!1,isTemporaryPin:!1,pinChanged:!0,pinUpdatedAt:H()}),e.pin=t,e.mustResetPin=!1,e.isTemporaryPin=!1,e.pinChanged=!0,window.currentStaff=e;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(e)),localStorage.setItem("mec_staff_session",JSON.stringify(e))}catch{}m("✅ PIN updated successfully!"),window.closeChangePinModal()}catch(r){m("Error updating PIN: "+r.message)}finally{n&&(n.disabled=!1,n.innerText="Update PIN")}};function q(e){window.currentStaff=e;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(e)),localStorage.setItem("mec_staff_session",JSON.stringify(e))}catch{}const o=document.getElementById("login-loading"),t=document.getElementById("section-dashboard"),a=document.getElementById("section-login"),n=document.getElementById("section-pin-setup");a&&a.remove(),n&&n.remove(),o&&(o.style.display="none"),t&&(t.style.display="block"),ee(e)}window.staffLogout=()=>{try{sessionStorage.removeItem("mec_staff_session"),localStorage.removeItem("mec_staff_session")}catch{}window.location.reload()};function Y(){try{const e=sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session");if(e){const o=JSON.parse(e);if(o&&(o.docId||o.phone)){window.currentStaff=o;const t=document.getElementById("section-login"),a=document.getElementById("login-loading"),n=document.getElementById("section-dashboard");t&&n&&(t.style.display="none",a&&(a.style.display="none"),n.style.display="block",ee(o))}}}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Y):Y();function ee(e){document.getElementById("disp-name").innerText=e.name,document.getElementById("disp-role").innerText=e.role,document.getElementById("disp-avatar").innerText=e.name.charAt(0).toUpperCase();const o=z(B(h,"payroll"),R("empId","==",e.docId));j(o,d=>{let i=d.docs.map(c=>({docId:c.id,...c.data()}));i.sort((c,l)=>{var x,v;const f=(c.month||"").toString(),g=(l.month||"").toString().compareTo(f);if(g!==0)return g;const y=(x=c.timestamp)!=null&&x.seconds?c.timestamp.seconds*1e3:new Date(c.date||c.timestamp||0).getTime()||0;return((v=l.timestamp)!=null&&v.seconds?l.timestamp.seconds*1e3:new Date(l.date||l.timestamp||0).getTime()||0)-y}),window.myPayrollRecords=i,window.lastPaySlip=i[0]||null;const r=document.getElementById("disp-salary");r&&(r.innerText=window.lastPaySlip?`LKR ${parseFloat(window.lastPaySlip.netSalary||window.lastPaySlip.amount||0).toLocaleString()}`:"LKR 0.00");const p=document.getElementById("staff-payslip-archive-modal");p&&p.style.display==="flex"&&window.populatePayslipArchiveModal()});const t=new Date,a=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}`,n=z(B(h,"attendance"),R("empId","==",e.docId));j(n,d=>{const i=d.docs.map(l=>({docId:l.id,...l.data()})),r=i.filter(l=>l.date&&l.date.startsWith(a)&&(l.status==="Present"||l.status==="Half Day"));document.getElementById("disp-attendance").innerText=`${r.length} Days`,window.myAttendanceRecords=i;const p=new Date().toLocaleDateString("sv-SE"),c=i.find(l=>(l.empId===e.docId||l.empId===e.regno)&&l.date===p);U(c)});const s=document.getElementById("admin-calibrate-gps-btn");s&&(s.style.display="none"),pe(e),me(e)}let X=!0;const G=new Set;function K(){try{const e=new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");e.volume=.8;const o=e.play();o!==void 0&&o.catch(()=>{try{const t=new(window.AudioContext||window.webkitAudioContext);t.state==="suspended"&&t.resume();const a=t.createOscillator(),n=t.createGain();a.type="sine",a.frequency.setValueAtTime(587.33,t.currentTime),a.frequency.setValueAtTime(880,t.currentTime+.1),n.gain.setValueAtTime(.25,t.currentTime),n.gain.exponentialRampToValueAtTime(.001,t.currentTime+.45),a.connect(n),n.connect(t.destination),a.start(),a.stop(t.currentTime+.5)}catch{}})}catch{}}function pe(e){const o=e.storeId||"mec-book-shop",t=e.docId||e.regno||e.email,a=e.role||"Staff",n=e.branchId||"Global",s=z(B(h,"internal_mails"),R("storeId","==",o));j(s,d=>{let i=d.docs.map(l=>({docId:l.id,...l.data()}));i.sort((l,f)=>{var y,b;const u=(y=l.timestamp)!=null&&y.seconds?l.timestamp.seconds*1e3:new Date(l.timestamp||0).getTime()||0;return((b=f.timestamp)!=null&&b.seconds?f.timestamp.seconds*1e3:new Date(f.timestamp||0).getTime()||0)-u});const r=i.filter(l=>{const f=l.recipientId||"ALL";return!!(f==="ALL"||f===t||f===e.regno||f===e.email||f===e.phone||f.startsWith("BRANCH_")&&(f.replace("BRANCH_","")===n||f.replace("BRANCH_","")===e.branchName)||f.startsWith("ROLE_")&&f.replace("ROLE_","").toLowerCase()===a.toLowerCase()||f==="CASHIERS"&&a.toLowerCase().includes("cashier")||f==="INVENTORY"&&(a.toLowerCase().includes("inventory")||a.toLowerCase().includes("stock"))||f==="TECH"&&(a.toLowerCase().includes("tech")||a.toLowerCase().includes("repair"))||f==="HR_ONLY"&&(a.toLowerCase().includes("hr")||a.toLowerCase().includes("admin")||a.toLowerCase().includes("manager")))});if(X)r.forEach(l=>G.add(l.docId)),X=!1;else{const l=r.filter(f=>!G.has(f.docId));l.length>0&&l.forEach(f=>{G.add(f.docId),K(),m(`📩 New Notice from ${f.senderName||"HR"}: ${f.subject||"Staff Message"}`)})}window.myStaffMails=r;const p=r.filter(l=>!l.isRead).length,c=document.getElementById("staff-unread-badge");c&&(p>0?(c.innerText=p,c.style.display="inline-block"):c.style.display="none"),te(r)},d=>{console.warn("Staff mail snapshot error:",d)})}function te(e){const o=document.getElementById("staff-inbox-list");if(o){if(!e||e.length===0){o.innerHTML='<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>';return}o.innerHTML=e.map(t=>{const a=t.timestamp?new Date(t.timestamp.seconds*1e3).toLocaleString([],{dateStyle:"short",timeStyle:"short"}):"Just now",n=t.priority==="urgent",s=!!(t.attachment&&t.attachment.url),d=t.isRead?"":'<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>',i=n?'<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>':"";return`
            <div onclick="window.readStaffMailDetail('${t.docId}')" style="background: ${t.isRead?"rgba(255,255,255,0.03)":"rgba(56,189,248,0.08)"}; border: 1px solid ${t.isRead?"rgba(255,255,255,0.06)":"rgba(56,189,248,0.3)"}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${d}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${t.senderName||"HR Management"}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${a}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${t.subject||"No Subject"}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${s?'<span title="Has Attachment" style="font-size:0.8rem;">📎</span>':""}
                        ${i}
                    </div>
                </div>
            </div>
        `}).join("")}}let Z=!0;const O=new Map;function me(e){if(!e||!e.docId)return;const o=z(B(h,"leave_requests"),R("empId","==",e.docId));j(o,t=>{let a=t.docs.map(n=>({docId:n.id,...n.data()}));a.sort((n,s)=>{var r,p,c,l;const d=(r=n.processedAt)!=null&&r.seconds?n.processedAt.seconds*1e3:(p=n.timestamp)!=null&&p.seconds?n.timestamp.seconds*1e3:new Date(n.date||0).getTime()||0;return((c=s.processedAt)!=null&&c.seconds?s.processedAt.seconds*1e3:(l=s.timestamp)!=null&&l.seconds?s.timestamp.seconds*1e3:new Date(s.date||0).getTime()||0)-d}),Z?(a.forEach(n=>O.set(n.docId,n.status)),Z=!1):a.forEach(n=>{const s=O.get(n.docId);s&&s!==n.status?(O.set(n.docId,n.status),n.status==="Approved"?(K(),m(`🎉 Leave Request Approved by ${n.processedBy||"Manager"}!`)):n.status==="Rejected"&&(K(),m(`⚠️ Leave Request Rejected by ${n.processedBy||"Manager"}. Remark: "${n.remark||""}"`))):s||O.set(n.docId,n.status)}),window.allStaffLeaveRequests=a,fe(a),window.currentStaffLeaveHistoryFilter&&oe(window.currentStaffLeaveHistoryFilter)},t=>{console.warn("Staff leave requests snapshot error:",t)})}function fe(e){const o=document.getElementById("staff-leave-status-container");if(!o)return;const t=new Date,a=(e||[]).filter(g=>{if(!g||!g.date)return!1;const y=String(g.date).trim();let b=y;if(y.includes("to")||y.includes(" - ")){const I=y.split(/\s+(?:to|-)\s+/);I.length>0&&(b=I[I.length-1].trim())}const x=b.split("-");if(x.length===3){const I=parseInt(x[0],10),L=parseInt(x[1],10)-1,M=parseInt(x[2],10),T=new Date(I,L,M,23,59,59,999);return t<=T}const v=new Date(b);if(isNaN(v.getTime()))return!1;const S=new Date(v.getFullYear(),v.getMonth(),v.getDate(),23,59,59,999);return t<=S});if(!a||a.length===0){o.style.display="none",o.innerHTML="";return}const n=a[0];o.style.display="block";const s=n.status==="Approved",d=n.status==="Rejected",i=s?"#10b981":d?"#f43f5e":"#f59e0b",r=s?"rgba(16, 185, 129, 0.1)":d?"rgba(244, 63, 94, 0.1)":"rgba(245, 158, 11, 0.08)",p=s?"rgba(16, 185, 129, 0.35)":d?"rgba(244, 63, 94, 0.35)":"rgba(245, 158, 11, 0.25)",c=s?"🟢 LEAVE APPROVED":d?"🔴 LEAVE REJECTED":"⏳ PENDING REVIEW";let l="";s||d?l=`
            <div style="background: rgba(0,0,0,0.3); border-radius: 10px; padding: 10px 12px; margin-top: 8px; border: 1px solid ${p};">
                <div style="font-size: 0.78rem; color: #f8fafc; font-weight: 600; display:flex; align-items:center; gap:6px;">
                    <span>${s?"🛡️":"⚠️"}</span>
                    <span>${s?"Approved by:":"Rejected by:"} <b style="color:${i}">${n.processedBy||"Store Management"}</b> ${n.processorRole?`<span style="color:#94a3b8; font-size:0.7rem;">(${n.processorRole})</span>`:""}</span>
                </div>
                <div style="font-size: 0.75rem; color: #cbd5e1; margin-top: 5px; display:flex; align-items:flex-start; gap:6px;">
                    <span>💬</span>
                    <span>Remark: <i style="color:#fff;">"${n.remark||"None"}"</i></span>
                </div>
                ${n.processedDate?`
                <div style="font-size: 0.68rem; color: #64748b; margin-top: 4px; display:flex; align-items:center; gap:6px;">
                    <span>🕒</span>
                    <span>${n.processedDate}</span>
                </div>`:""}
            </div>
        `:l=`
            <div style="font-size: 0.72rem; color: #f59e0b; margin-top: 6px; padding: 6px 10px; background: rgba(245, 158, 11, 0.08); border-radius: 8px; border: 1px solid rgba(245, 158, 11, 0.2);">
                ⏳ Awaiting authorization by Store Manager or HR.
            </div>
        `;let f="";n.medicalBill?f=`
            <div style="margin-top: 10px; padding: 10px; background: rgba(16,185,129,0.08); border-radius: 10px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <img src="${n.medicalBill}" style="width: 36px; height: 36px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981;" />
                    <div>
                        <div style="font-size: 0.75rem; color: #10b981; font-weight: 700;">Medical Bill Attached ✓</div>
                        <div style="font-size: 0.68rem; color: #94a3b8;">Document attached for review</div>
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button onclick="window.viewStaffMedicalBill('${n.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: none; padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">View</button>
                    <button onclick="window.triggerStaffBillUpload('${n.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: none; padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">Replace</button>
                </div>
            </div>
        `:f=`
            <div style="margin-top: 10px;">
                <button onclick="window.triggerStaffBillUpload('${n.docId}')" style="width: 100%; background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.4); border-radius: 10px; padding: 8px 12px; color: #38bdf8; font-size: 0.78rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span>📷</span> Upload Medical Bill / Document
                </button>
            </div>
        `;let u="";(n.allowanceProtected||s&&n.medicalBill)&&(u=`
            <div style="margin-top: 8px; padding: 6px 10px; background: rgba(16,185,129,0.12); border-radius: 8px; border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 1rem;">🛡️</span>
                <div>
                    <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                    <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Monthly attendance allowance will not be deducted.</div>
                </div>
            </div>
        `),o.innerHTML=`
        <div style="background: ${r}; border: 1px solid ${p}; border-radius: 16px; padding: 14px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <span style="font-size: 0.7rem; font-weight: 800; letter-spacing: 0.8px; color: ${i}; background: rgba(255,255,255,0.05); padding: 3px 8px; border-radius: 20px; border: 1px solid ${p};">
                    ${c}
                </span>
                <span style="font-size: 0.72rem; color: #38bdf8; font-weight: 700; background: rgba(56,189,248,0.1); padding: 2px 8px; border-radius: 6px;">
                    ${n.type||"Day Off"}
                </span>
            </div>
            <div style="font-size: 1rem; font-weight: 800; color: #f8fafc; margin-bottom: 3px;">
                📅 ${n.date}
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; line-height: 1.3;">
                Reason: ${n.reason||"-"}
            </div>
            ${u}
            ${l}
            ${f}
        </div>
    `}window.currentBillUploadReqId=null;window.triggerStaffBillUpload=e=>{window.currentBillUploadReqId=e;let o=document.getElementById("staff-bill-hidden-input");o||(o=document.createElement("input"),o.id="staff-bill-hidden-input",o.type="file",o.accept="image/*",o.style.display="none",o.onchange=async t=>{var s;const a=(s=t.target.files)==null?void 0:s[0];if(!a||!window.currentBillUploadReqId)return;const n=new FileReader;n.onload=async d=>{var r;const i=d.target.result;try{m("⏳ Uploading medical bill...","info"),await F($(h,"leave_requests",window.currentBillUploadReqId),{medicalBill:i,medicalBillAt:H(),medicalBillBy:((r=window.currentStaff)==null?void 0:r.name)||"Staff"}),m("✅ Medical bill uploaded successfully!","success")}catch(p){m("❌ Failed to upload bill: "+p.message)}},n.readAsDataURL(a)},document.body.appendChild(o)),o.value="",o.click()};window.viewStaffMedicalBill=e=>{const t=(window.allStaffLeaveRequests||[]).find(n=>n.docId===e);if(!t||!t.medicalBill)return m("No medical bill found.");let a=document.getElementById("staff-bill-lightbox-modal");a||(a=document.createElement("div"),a.id="staff-bill-lightbox-modal",a.style.cssText="position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); backdrop-filter:blur(6px); display:flex; align-items:center; justify-content:center; padding:20px;",a.onclick=n=>{n.target===a&&(a.style.display="none")},document.body.appendChild(a)),a.innerHTML=`
        <div style="background:#0f172a; border:1px solid rgba(56,189,248,0.3); border-radius:16px; max-width:600px; width:100%; max-height:90vh; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 20px 50px rgba(0,0,0,0.7);">
            <div style="padding:14px 18px; border-bottom:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center;">
                <div style="font-weight:700; color:#f8fafc; font-size:1rem;">🩺 Medical Bill / Document</div>
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:transparent; border:none; color:#94a3b8; font-size:1.6rem; cursor:pointer;">&times;</button>
            </div>
            <div style="padding:16px; overflow:auto; text-align:center; background:#020617; flex:1;">
                <img src="${t.medicalBill}" style="max-width:100%; max-height:70vh; border-radius:8px; object-fit:contain;" alt="Medical Bill" />
            </div>
            <div style="padding:12px 18px; border-top:1px solid rgba(255,255,255,0.1); display:flex; justify-content:flex-end;">
                <button onclick="document.getElementById('staff-bill-lightbox-modal').style.display='none'" style="background:rgba(255,255,255,0.1); color:white; border:none; padding:8px 18px; border-radius:8px; font-weight:600; cursor:pointer;">Close</button>
            </div>
        </div>
    `,a.style.display="flex"};window.currentStaffLeaveHistoryFilter="All";window.openLeaveHistoryModal=()=>{const e=document.getElementById("leave-history-modal");e&&(e.style.display="flex",window.filterStaffLeaveHistory("All"))};window.filterStaffLeaveHistory=e=>{window.currentStaffLeaveHistoryFilter=e,["All","Medical","Approved","Pending"].forEach(o=>{const t=document.getElementById(`filter-leave-${o.toLowerCase()}`);t&&(o===e?(t.style.background="#38bdf8",t.style.color="#020617",t.style.fontWeight="700"):(t.style.background="rgba(255,255,255,0.08)",t.style.color="#94a3b8",t.style.fontWeight="600"))}),oe(e)};function oe(e){const o=document.getElementById("staff-leave-history-list");if(!o)return;let t=window.allStaffLeaveRequests||[];if(e==="Medical"?t=t.filter(a=>(a.type||"").toLowerCase().includes("medical")||(a.type||"").toLowerCase().includes("sick")||!!a.medicalBill):e==="Approved"?t=t.filter(a=>(a.status||"").toLowerCase()==="approved"):e==="Pending"&&(t=t.filter(a=>(a.status||"").toLowerCase()==="pending")),t.length===0){o.innerHTML=`
            <div style="text-align: center; color: #64748b; padding: 2.5rem 1rem;">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📂</div>
                <div style="font-size: 0.9rem; font-weight: 700; color: #94a3b8;">No ${e==="All"?"":e} leave records found.</div>
                <div style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">Submit a new request or check other filters.</div>
            </div>
        `;return}o.innerHTML=t.map(a=>{const n=a.status==="Approved",s=a.status==="Rejected",d=n?"#10b981":s?"#ef4444":"#f59e0b",i=n?"rgba(16, 185, 129, 0.12)":s?"rgba(239, 68, 68, 0.12)":"rgba(245, 158, 11, 0.12)",r=n?"rgba(16, 185, 129, 0.35)":s?"rgba(239, 68, 68, 0.35)":"rgba(245, 158, 11, 0.35)",p=n?"APPROVED":s?"REJECTED":"PENDING REVIEW",c=a.allowanceProtected===!0||n&&!!a.medicalBill;return`
            <div style="background: rgba(15, 23, 42, 0.85); border: 1px solid ${r}; border-radius: 16px; padding: 14px 16px; display: flex; flex-direction: column; gap: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
                <!-- Top Row -->
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem; font-weight: 800; color: #f8fafc;">📅 ${a.date}</span>
                        <span style="background: rgba(56,189,248,0.12); color: #38bdf8; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 6px;">${a.type||"Leave"}</span>
                    </div>
                    <span style="background: ${i}; color: ${d}; border: 1px solid ${r}; font-size: 0.68rem; font-weight: 800; padding: 3px 8px; border-radius: 20px; letter-spacing: 0.5px;">
                        ${p}
                    </span>
                </div>

                <!-- Reason -->
                <div style="font-size: 0.8rem; color: #cbd5e1; line-height: 1.3;">
                    <strong style="color: #94a3b8;">Reason:</strong> ${a.reason||"-"}
                </div>

                <!-- Allowance Protection Banner (Shop & Office Act) -->
                ${c?`
                    <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 6px 10px; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1rem;">🛡️</span>
                        <div>
                            <div style="font-size: 0.72rem; color: #34d399; font-weight: 800;">Attendance Allowance Protected</div>
                            <div style="font-size: 0.65rem; color: #94a3b8;">Shop & Office Act: Validated by HR. No deduction from monthly attendance allowance.</div>
                        </div>
                    </div>
                `:""}

                <!-- Review & Remarks -->
                ${n||s?`
                    <div style="background: rgba(0,0,0,0.25); border-radius: 8px; padding: 8px 10px; border-left: 3px solid ${d}; font-size: 0.72rem; color: #cbd5e1;">
                        <div style="color: ${d}; font-weight: 700;">
                            ${n?"✓ Approved":"✕ Rejected"} by: ${a.processedBy||"Store Management"} ${a.processorRole?`(${a.processorRole})`:""}
                        </div>
                        ${a.remark?`<div style="margin-top: 2px; color: #94a3b8;">Remark: <i style="color:#fff;">"${a.remark}"</i></div>`:""}
                        ${a.processedDate?`<div style="margin-top: 2px; color: #64748b; font-size: 0.65rem;">🕒 ${a.processedDate}</div>`:""}
                    </div>
                `:`
                    <div style="font-size: 0.7rem; color: #f59e0b; font-style: italic;">
                        ⏳ Awaiting HR / Store Manager approval.
                    </div>
                `}

                <!-- Medical Bill / Document Section -->
                <div style="margin-top: 4px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    ${a.medicalBill?`
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <img src="${a.medicalBill}" style="width: 34px; height: 34px; border-radius: 6px; object-fit: cover; border: 1px solid #10b981; cursor: pointer;" onclick="window.viewStaffMedicalBill('${a.docId}')" />
                            <div>
                                <div style="font-size: 0.72rem; color: #10b981; font-weight: 700;">Medical Document Attached ✓</div>
                                <div style="font-size: 0.65rem; color: #94a3b8;">Prescription / Certificate verified</div>
                            </div>
                        </div>
                        <div style="display: flex; gap: 6px;">
                            <button type="button" onclick="window.viewStaffMedicalBill('${a.docId}')" style="background: rgba(16,185,129,0.2); color: #10b981; border: 1px solid rgba(16,185,129,0.4); padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 700; cursor: pointer;">
                                View
                            </button>
                            <button type="button" onclick="window.triggerStaffBillUpload('${a.docId}')" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: 1px solid rgba(255,255,255,0.15); padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; cursor: pointer;">
                                Replace
                            </button>
                        </div>
                    `:`
                        <div style="font-size: 0.72rem; color: #64748b;">
                            No medical document attached
                        </div>
                        <button type="button" onclick="window.triggerStaffBillUpload('${a.docId}')" style="background: rgba(56,189,248,0.12); border: 1px dashed rgba(56,189,248,0.5); color: #38bdf8; padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                            <span>📷</span> Upload Medical Bill
                        </button>
                    `}
                </div>
            </div>
        `}).join("")}window.openStaffInboxModal=()=>{document.getElementById("staff-inbox-modal").style.display="flex",window.myStaffMails&&te(window.myStaffMails)};window.readStaffMailDetail=async e=>{const o=(window.myStaffMails||[]).find(n=>n.docId===e);if(!o)return;if(!o.isRead)try{await F($(h,"internal_mails",e),{isRead:!0}),o.isRead=!0}catch{}document.getElementById("staff-mail-view-subject").innerText=o.subject||"No Subject",document.getElementById("staff-mail-view-sender").innerText=`${o.senderName||"HR Management"} (${o.senderEmail||"System"})`,document.getElementById("staff-mail-view-date").innerText=o.timestamp?new Date(o.timestamp.seconds*1e3).toLocaleString():"Just now",document.getElementById("staff-mail-view-body").innerText=o.body||"";const t=document.getElementById("staff-mail-view-badge");t&&(o.priority==="urgent"?(t.innerText="🚨 Urgent Notice",t.style.background="rgba(239,68,68,0.2)",t.style.color="#ef4444"):o.priority==="confidential"?(t.innerText="🔒 Confidential",t.style.background="rgba(168,85,247,0.2)",t.style.color="#c084fc"):(t.innerText="✉️ Staff Notice",t.style.background="rgba(56,189,248,0.15)",t.style.color="#38bdf8"));const a=document.getElementById("staff-mail-view-attachment");if(a)if(o.attachment&&o.attachment.url){const n=o.attachment.type&&o.attachment.type.startsWith("image/");let s=`
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${o.attachment.name||"File"}</span>
                        <a href="${o.attachment.url}" download="${o.attachment.name||"download"}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;n&&(s+=`<img src="${o.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`),s+="</div>",a.innerHTML=s,a.style.display="block"}else a.innerHTML="",a.style.display="none";document.getElementById("staff-read-mail-modal").style.display="flex"};function m(e){const o=document.getElementById("toast");o.innerText=e,o.style.display="block",setTimeout(()=>o.style.display="none",3e3)}function ne(){return{name:"MEC BOOK SHOP & POS",logoUrl:"./pos-logo.png",address:"No. 12, Main Street, Colombo, Sri Lanka",phone:"+94 77 123 4567",epfRegNo:"EPF/MEC/99812",storeId:(window.currentStaff||{}).storeId||"mec-book-shop"}}window.openPayslipArchiveModal=()=>{const e=document.getElementById("staff-payslip-archive-modal");e&&(e.style.display="flex",window.populatePayslipArchiveModal())};window.closePayslipArchiveModal=()=>{const e=document.getElementById("staff-payslip-archive-modal");e&&(e.style.display="none")};window.populatePayslipArchiveModal=()=>{const e=window.myPayrollRecords||[],o=document.getElementById("staff-payslip-month-select"),t=document.getElementById("staff-payslip-history-list"),a=document.getElementById("staff-payslip-detail-card");if(!o||!a||!t)return;if(e.length===0){o.innerHTML='<option value="">No recorded payslips found</option>',a.innerHTML=`
            <div style="text-align: center; color: #94a3b8; padding: 2rem 1rem;">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📑</div>
                <div style="font-weight: 700; color: #cbd5e1; margin-bottom: 4px;">No Salary Slips Issued Yet</div>
                <div style="font-size: 0.8rem; color: #64748b;">Your official statutory payslips will appear here once processed by HR.</div>
            </div>
        `,t.innerHTML='<div style="text-align: center; color: #64748b; padding: 1rem;">No prior records found</div>';return}const n=o.value;o.innerHTML=e.map((i,r)=>{const p=i.month||"Current",c=p.split("-");let l=p;if(c.length===2){const f=c[0],u=parseInt(c[1],10),g=["January","February","March","April","May","June","July","August","September","October","November","December"],y=["ජනවාරි","පෙබරවාරි","මාර්තු","අප්‍රේල්","මැයි","ජුනි","ජූලි","අගෝස්තු","සැප්තැම්බර්","ඔක්තෝබර්","නොවැම්බර්","දෙසැම්බර්"];u>=1&&u<=12&&(l=`${f} ${y[u-1]} (${g[u-1]}) — LKR ${parseFloat(i.netSalary||i.amount||0).toLocaleString()}`)}return`<option value="${i.month}" ${!n&&r===0||n===i.month?"selected":""}>${l}</option>`}).join("");const s=o.value||e[0].month,d=e.find(i=>i.month===s)||e[0];window.renderPayslipDetailCard(d),t.innerHTML=e.map(i=>{const r=parseFloat(i.netSalary||i.amount||0).toLocaleString(),p=!!i.pdfUrl;return`
            <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); border-radius: 12px; padding: 10px 14px;">
                <div>
                    <div style="font-weight: 800; font-size: 0.9rem; color: #38bdf8;">${i.month}</div>
                    <div style="font-size: 0.75rem; color: #94a3b8;">Net Pay: <b style="color: #34d399;">LKR ${r}</b></div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button onclick="window.viewPrintSelectedPayslip('${i.month}')" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 5px 10px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;" title="View & Print Bilingual Payslip">
                        🖨️ View
                    </button>
                    <button onclick="window.downloadSelectedPayslipPDF('${i.month}')" style="background: ${p?"linear-gradient(135deg, #059669, #10b981)":"rgba(255,255,255,0.08)"}; color: white; border: none; padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;" title="Download Official PDF">
                        ⬇️ PDF
                    </button>
                </div>
            </div>
        `}).join("")};window.onStaffPayslipMonthChanged=e=>{const o=window.myPayrollRecords||[],t=o.find(a=>a.month===e)||o[0];t&&window.renderPayslipDetailCard(t)};window.renderPayslipDetailCard=e=>{const o=document.getElementById("staff-payslip-detail-card");if(!o||!e)return;const t=window.currentStaff||{},a=e.empName||t.name||"Staff Member",n=e.empRegNo||e.empId||t.regno||t.docId||"-",s=e.epfNumber||t.epfNumber||n,d=parseFloat(e.basicSalary||e.amount||0),i=parseFloat(e.braAllowance||0),r=parseFloat(e.otPay||0),p=parseFloat(e.grossEarnings||d+i+r||e.amount||0),c=parseFloat(e.employeeEpf8||0),l=parseFloat(e.advanceDeductions||0),f=parseFloat(e.apitTax||0),u=parseFloat(e.totalEmployeeDeductions||c+l+f||0),g=parseFloat(e.netSalary||e.amount||0),y=parseFloat(e.employerEpf12||0),b=parseFloat(e.employerEtf3||0);e.pdfUrl,o.innerHTML=`
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-bottom: 12px;">
            <div>
                <span style="background: rgba(52, 211, 153, 0.15); color: #34d399; font-size: 0.7rem; font-weight: 800; padding: 2px 8px; border-radius: 6px; text-transform: uppercase;">
                    Period: ${e.month}
                </span>
                <h4 style="margin: 6px 0 2px; font-size: 1.05rem; color: white;">${a}</h4>
                <div style="font-size: 0.75rem; color: #94a3b8;">Staff No: <b>${n}</b> • EPF No: <b>${s}</b></div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 0.7rem; text-transform: uppercase; color: #94a3b8; letter-spacing: 1px;">Net Pay (ශුද්ධ වැටුප)</div>
                <div style="font-size: 1.3rem; font-weight: 900; color: #34d399;">LKR ${g.toLocaleString()}</div>
            </div>
        </div>

        <!-- Breakdown Grid -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 14px;">
            <!-- Earnings -->
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 10px;">
                <div style="font-size: 0.72rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; margin-bottom: 6px;">
                    ඒකාබද්ධ වැටුප / Earnings
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>මූලික වැටුප (Basic):</span> <span>LKR ${d.toLocaleString()}</span>
                </div>
                ${i>0?`
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>අයවැය සහන (BRA):</span> <span>LKR ${i.toLocaleString()}</span>
                </div>`:""}
                ${r>0?`
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>අතිකාල (OT):</span> <span>LKR ${r.toLocaleString()}</span>
                </div>`:""}
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; font-weight: 800; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 4px; margin-top: 4px; color: #38bdf8;">
                    <span>මුළු ඉපැයීම (Gross):</span> <span>LKR ${p.toLocaleString()}</span>
                </div>
            </div>

            <!-- Deductions -->
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 10px;">
                <div style="font-size: 0.72rem; font-weight: 800; color: #f87171; text-transform: uppercase; margin-bottom: 6px;">
                    අඩු කිරීම් / Deductions
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>සේ.අ.අ. 8% (EPF):</span> <span>LKR ${c.toLocaleString()}</span>
                </div>
                ${l>0?`
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>අත්තිකාරම් (Advance):</span> <span>LKR ${l.toLocaleString()}</span>
                </div>`:""}
                ${f>0?`
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; margin-bottom: 3px; color: #cbd5e1;">
                    <span>බදු (APIT Tax):</span> <span>LKR ${f.toLocaleString()}</span>
                </div>`:""}
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; font-weight: 800; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 4px; margin-top: 4px; color: #f87171;">
                    <span>මුළු අඩු කිරීම්:</span> <span>LKR ${u.toLocaleString()}</span>
                </div>
            </div>
        </div>

        <!-- Employer Statutory Contribution Note -->
        <div style="background: rgba(56, 189, 248, 0.06); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 12px; font-size: 0.72rem; color: #94a3b8; margin-bottom: 14px; display: flex; justify-content: space-between;">
            <span>🏛️ <b>Employer Statutory:</b> EPF 12%: LKR ${y.toLocaleString()} • ETF 3%: LKR ${b.toLocaleString()}</span>
            <span style="color: #38bdf8; font-weight: 700;">Act No. 19 of 1954</span>
        </div>

        <!-- Action Buttons -->
        <div style="display: flex; gap: 10px;">
            <button onclick="window.downloadSelectedPayslipPDF('${e.month}')" style="flex: 1; background: linear-gradient(135deg, #059669, #10b981); color: white; border: none; padding: 11px; border-radius: 12px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 14px rgba(16, 185, 129, 0.3);">
                <span>📥</span> Download Official Pay Slip (PDF)
            </button>
            <button onclick="window.viewPrintSelectedPayslip('${e.month}')" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1.5px solid rgba(56, 189, 248, 0.4); padding: 11px 16px; border-radius: 12px; font-weight: 800; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;">
                <span>🖨️</span> View / Print
            </button>
        </div>
    `};window.downloadSelectedPayslipPDF=async e=>{var d,i;const o=window.myPayrollRecords||[],t=document.getElementById("staff-payslip-month-select"),a=e||(t?t.value:"")||((d=o[0])==null?void 0:d.month),n=o.find(r=>r.month===a)||o[0];if(!n)return m("⚠️ No payslip record found to download.");if(n.pdfUrl){const r=document.createElement("a");r.href=n.pdfUrl,r.target="_blank",r.download=`Payslip_${n.month}_${(((i=window.currentStaff)==null?void 0:i.name)||"Employee").replace(/\s+/g,"_")}.pdf`,document.body.appendChild(r),r.click(),document.body.removeChild(r),m("📄 Opening official cloud PDF...");return}m("⚙️ Generating official statutory PDF...");const s=ne();try{if(typeof Q=="function"){const r=await Q(n,s);if(r){n.pdfUrl=r;const p=document.createElement("a");p.href=r,p.target="_blank",document.body.appendChild(p),p.click(),document.body.removeChild(p),m("✅ Official PDF generated & opened!");return}}}catch(r){console.warn("generateAndUploadPayslipPDF error:",r)}window.viewPrintSelectedPayslip(a)};window.viewPrintSelectedPayslip=e=>{var r;const o=window.myPayrollRecords||[],t=document.getElementById("staff-payslip-month-select"),a=e||(t?t.value:"")||((r=o[0])==null?void 0:r.month),n=o.find(p=>p.month===a)||o[0];if(!n)return m("⚠️ No payslip record found.");const s=ne(),d=ce(n,s,{pdfUrl:n.pdfUrl}),i=window.open("","_blank","width=800,height=900");i?(i.document.open(),i.document.write(d),i.document.close(),i.focus()):m("Popup blocked! Please allow popups to view the payslip.")};window.downloadMySlip=()=>{window.openPayslipArchiveModal()};window.viewMyAttendance=()=>{if(!window.myAttendanceRecords||window.myAttendanceRecords.length===0)return m("No attendance records found.");const e=window.currentStaff,o=[...window.myAttendanceRecords].sort((n,s)=>s.date.localeCompare(n.date)),t=`
        <html>
        <head>
            <title>Attendance Report - ${e.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${e.name}<br>
                    <strong>Role:</strong> ${e.role}<br>
                    <strong>Employee ID:</strong> ${e.regno||"-"}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${o.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>In Time</th>
                        <th>Out Time</th>
                        <th>Worked</th>
                        <th>OT</th>
                        <th>Status</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${o.map(n=>{const s=n.inTime||n.time||"--:--",d=n.outTime||"--:--",i=n.workedDuration||(n.inTime&&!n.outTime?"⏱️ In Shift":"--"),r=n.otMinutes??(n.otHours?Math.round(n.otHours*60):0),p=r>0?`+${r} mins`:"-";return`
                        <tr>
                            <td>${n.date}</td>
                            <td style="font-weight:bold; color:#0284c7;">${s}</td>
                            <td style="font-weight:bold; color:#d97706;">${d}</td>
                            <td style="font-weight:600;">${i}</td>
                            <td style="font-weight:bold; color:#059669;">${p}</td>
                            <td class="status-${(n.status||"").toLowerCase().replace(" ","")}">${n.status}</td>
                            <td style="font-size:0.8rem; color:#64748b;">${n.note||"-"}</td>
                        </tr>
                        `}).join("")}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            <\/script>
        </body>
        </html>
    `,a=window.open("","_blank");a.document.write(t),a.document.close(),m("📅 Generating PDF Report...")};window.openLeaveModal=()=>{document.getElementById("leave-modal").style.display="flex",document.getElementById("leave-date").value=new Date().toISOString().split("T")[0]};window.submitLeaveRequest=async()=>{var f,u;const e=document.getElementById("leave-date"),o=document.getElementById("leave-type"),t=document.getElementById("leave-reason"),a=e?e.value:"",n=o?o.value:"Half Day",s=t?t.value.trim():"";if(!a||!s)return m("⚠️ Please fill all fields (Date & Reason).");let d=window.currentStaff;if(!d)try{d=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{d={}}const i=d.docId||d.regno||d.id||"EMP-UNKNOWN",r=d.name||((f=document.getElementById("disp-name"))==null?void 0:f.innerText)||"Staff Member",p=d.role||((u=document.getElementById("disp-role"))==null?void 0:u.innerText)||"Staff",c=d.storeId||"mec-book-shop",l=document.querySelector("#leave-modal button.btn-login:last-child");l&&(l.disabled=!0,l.innerText="Submitting...");try{await V(B(h,"leave_requests"),{empId:i,empName:r,empRole:p,empPhone:d.phone||"",date:a,type:n,reason:s,status:"Pending",storeId:c,timestamp:H()}),m("✅ Leave request submitted successfully!");const g=document.getElementById("leave-modal");g&&(g.style.display="none"),t&&(t.value="")}catch(g){console.error("Leave request error:",g),m(`❌ Error: ${g.message||"Failed to submit request"}`)}finally{l&&(l.disabled=!1,l.innerText="Submit Request")}};let D=null,W="environment",C=null,N=null,ae=null;async function ie(e,o,t){var d;const a=parseFloat(o),n=parseFloat(t),s=e||((d=window.currentStaff)==null?void 0:d.storeId)||"mec-book-shop";try{await A($(h,"config",s),{storeLatitude:a,storeLongitude:n},{merge:!0})}catch(i){console.warn("Set config storeId error, attempting fallback:",i);try{await F($(h,"config",s),{storeLatitude:a,storeLongitude:n})}catch(r){console.error("Config update error:",r)}}try{await A($(h,"system","config"),{storeLatitude:a,storeLongitude:n},{merge:!0})}catch{}try{const i=localStorage.getItem(`mecpos_system_config_${s}`);if(i){const r=JSON.parse(i);r.storeLatitude=a,r.storeLongitude=n,localStorage.setItem(`mecpos_system_config_${s}`,JSON.stringify(r))}}catch{}}function U(e){const o=document.getElementById("staff-shift-status-pill");if(!o)return;if(!e||!e.inTime&&!e.time){o.innerHTML="⚪ <b>Not Clocked In Today</b> — Tap above to Clock In",o.style.background="rgba(255,255,255,0.04)",o.style.border="1px solid rgba(255,255,255,0.08)",o.style.color="#94a3b8";return}const t=e.inTime||e.time;if(!e.outTime){o.innerHTML=`🟢 <b>In Shift</b> (Clocked In: <b>${t}</b>)<br><span style="font-size:0.7rem; opacity:0.85;">Tap above to Clock-Out (15m Cooldown | 4h HD | 8h+ OT)</span>`,o.style.background="rgba(16, 185, 129, 0.12)",o.style.border="1px solid rgba(16, 185, 129, 0.4)",o.style.color="#10b981";return}const a=e.outTime,n=e.workedDuration||(e.workedMinutes?`${Math.floor(e.workedMinutes/60)}h ${e.workedMinutes%60}m`:"-"),s=e.otMinutes??(e.otHours?Math.round(e.otHours*60):0),d=s>0?`+${s} mins`:null;if(e.status==="Day Off")o.innerHTML=`🟣 <b>Day Off Recorded</b> (${n})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}</span>`,o.style.background="rgba(168, 85, 247, 0.12)",o.style.border="1px solid rgba(168, 85, 247, 0.35)",o.style.color="#c084fc";else if(e.status==="Half Day")o.innerHTML=`🟡 <b>Half Day Recorded</b> (${n})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}</span>`,o.style.background="rgba(245, 158, 11, 0.12)",o.style.border="1px solid rgba(245, 158, 11, 0.35)",o.style.color="#f59e0b";else{const i=d?` | <span style="color:#fde047; font-weight:800;">⚡ OT: ${d}</span>`:"";o.innerHTML=`🟢 <b>Shift Completed</b> (${n})<br><span style="font-size:0.7rem;">In: ${t} | Out: ${a}${i}</span>`,o.style.background="rgba(16, 185, 129, 0.15)",o.style.border="1px solid rgba(16, 185, 129, 0.4)",o.style.color="#34d399"}}window.updateStaffPortalShiftStatus=U;async function J(e=0,o=!1){let t=window.currentStaff;if(!t)try{t=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{t={}}if(!t||!t.docId&&!t.regno)throw new Error("Staff session not found. Please log in again.");const a=t.docId||t.regno||"EMP-UNKNOWN",n=t.name||"Staff Member",s=t.storeId||"mec-book-shop",d=new Date,i=d.toLocaleDateString("sv-SE"),r=d.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit"}),p=d.getTime();let c=(window.myAttendanceRecords||[]).find(w=>(w.empId===a||w.empId===t.regno)&&w.date===i);if(!c)try{const w=z(B(h,"attendance"),R("empId","==",a),R("date","==",i)),P=await _(w);P.empty||(c={docId:P.docs[0].id,...P.docs[0].data()})}catch(w){console.warn("Error querying existing attendance:",w)}const l=o?`GPS Calibrated to Store (${(C==null?void 0:C.toFixed(5))||0}, ${(N==null?void 0:N.toFixed(5))||0})`:`GPS+QR Verified (Distance: ${Number(e).toFixed(1)}m)`;if(!c||!c.inTime&&!c.time){const w={empId:a,empName:n,role:t.role||"Staff",date:i,inTime:r,time:r,inTimestamp:p,outTime:null,outTimestamp:null,workedMinutes:0,workedDuration:"",otHours:0,otMinutes:0,otDuration:"",status:"Present",note:`${l} | Shift Started`,storeId:s,timestamp:H()},P=B(h,"stores",s,"attendance"),E=await V(P,w);return await A($(h,"attendance",E.id),w).catch(()=>{}),m(`✅ Clocked In at ${r}! Have a great shift.`),U({...w,docId:E.id}),{type:"IN",record:{...w,docId:E.id}}}if(c.outTime)return m(`ℹ️ Shift already ended today (In: ${c.inTime}, Out: ${c.outTime} | Status: ${c.status}).`),{type:"ALREADY_COMPLETED",record:c};let f=c.inTimestamp;if(!f&&(c.inTime||c.time)){const w=c.inTime||c.time;if(w.includes(":")){const P=w.split(":").map(Number),E=new Date;E.setHours(P[0]||0,P[1]||0,0,0),f=E.getTime()}}f||(f=p);const u=Math.max(0,Math.floor((p-f)/6e4));if(u<15){const w=15-u;return m(`⚠️ Cooldown Active: Clocked in at ${c.inTime||c.time}. Minimum 15 mins required before Clock-Out (${w} mins left).`),{type:"COOLDOWN_BLOCKED",remainingMins:w}}const g=Math.floor(u/60),y=u%60,b=g>0?`${g} hrs ${y} mins`:`${y} mins`;let x="Present",v=0,S=0,I="0 mins",L="";u<240?(x="Day Off",v=0,S=0,I="0 mins",L=`Punched out after ${b} (< 4 hrs) — Recorded as Day Off`):u<480?(x="Half Day",v=0,S=0,I="0 mins",L=`Punched out after ${b} — Recorded as Half Day`):(x="Present",u>480?(S=u-480,v=+(S/60).toFixed(2),I=`${S} mins`,L=`Shift Completed (${b}) — Full Day + ${S} mins OT`):(v=0,S=0,I="0 mins",L="Shift Completed (8 hrs) — Full Day (0 OT)"));const M={outTime:r,outTimestamp:p,workedMinutes:u,workedDuration:b,otHours:v,otMinutes:S,otDuration:I,status:x,note:`${l} | ${L}`,updatedAt:H()},T=s;if(c.docId)await Promise.all([A($(h,"stores",T,"attendance",c.docId),M,{merge:!0}).catch(()=>{}),A($(h,"attendance",c.docId),M,{merge:!0}).catch(()=>{})]);else{const w=z(B(h,"attendance"),R("empId","==",a),R("date","==",i)),P=await _(w);if(P.empty){const E={empId:a,empName:n,role:t.role||"Staff",date:i,inTime:c.inTime||r,time:c.time||r,storeId:T,...M},re=B(h,"stores",T,"attendance"),de=await V(re,E);await A($(h,"attendance",de.id),E).catch(()=>{})}else{const E=P.docs[0].id;await Promise.all([A($(h,"stores",T,"attendance",E),M,{merge:!0}).catch(()=>{}),A($(h,"attendance",E),M,{merge:!0}).catch(()=>{})])}}U({...c,...M});let k=`✅ Clocked Out at ${r} (${b})! Status: ${x}`;return v>0&&(k+=` | ⚡ OT: +${I}`),m(k),{type:"OUT",status:x,workedDuration:b,otDuration:I}}window.processStaffAttendancePunch=J;window.calibrateStoreGPSFromPhone=async()=>{const e=prompt(`🔒 Admin Verification Required:
Enter Master Admin Security PIN or CEO Password to calibrate Shop GPS:`);if(!e)return;if(!["9556","1234","admin","mecpos","mec123","malindu123","mecpos123"].includes(e.trim().toLowerCase()))return m("❌ Access Denied: Invalid Admin Security PIN or Password!");if(!navigator.geolocation)return m("GPS Geolocation not supported on this device.");m("📍 Acquiring high-accuracy live GPS coordinates..."),navigator.geolocation.getCurrentPosition(async t=>{var i;const a=t.coords.latitude,n=t.coords.longitude,s=t.coords.accuracy?` (±${Math.round(t.coords.accuracy)}m)`:"",d=`Set current phone location as official Shop GPS?

📍 Latitude: ${a.toFixed(6)}
📍 Longitude: ${n.toFixed(6)}${s}

All employee clock-in scans will be verified against this exact store location.`;if(confirm(d))try{const r=((i=window.currentStaff)==null?void 0:i.storeId)||"mec-book-shop";await ie(r,a,n),m("✅ Store GPS coordinates successfully updated!")}catch(r){m("❌ Failed to update GPS coordinates: "+r.message)}},t=>{console.error("GPS Error:",t),m("❌ Unable to acquire GPS location. Please ensure Location is enabled.")},{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})};window.confirmCalibrateStoreGPS=async()=>{var a;const e=prompt(`🔒 Admin Security Check:
Enter Master Admin PIN to confirm Store GPS override:`);if(!e)return;if(!["9556","1234","admin","mecpos","mec123","malindu123","mecpos123"].includes(e.trim().toLowerCase()))return m("❌ Access Denied: Invalid Security PIN!");const t=document.getElementById("btn-calibrate-gps");t&&(t.disabled=!0,t.innerText="⏳ Saving Store GPS...");try{if(!C||!N)throw new Error("Phone GPS coordinates not found. Please re-scan.");const n=ae||((a=window.currentStaff)==null?void 0:a.storeId)||"mec-book-shop";await ie(n,C,N),document.getElementById("gps-mismatch-modal").style.display="none",m("📍 Shop GPS calibrated! Recording attendance..."),await J(0,!0)}catch(n){console.error("Calibration error:",n),m(`❌ Error: ${n.message||"Failed to calibrate"}`)}finally{t&&(t.disabled=!1,t.innerText="📍 Set Shop GPS to My Phone & Clock-In")}};window.startAttendanceClock=()=>{if(!navigator.geolocation)return m("GPS Geolocation not supported on this device.");m("📍 Accessing live GPS coordinates..."),navigator.geolocation.getCurrentPosition(e=>{C=e.coords.latitude,N=e.coords.longitude,e.coords.accuracy&&e.coords.accuracy>300&&(console.warn("Low GPS accuracy:",e.coords.accuracy),m(`⚠️ Low GPS signal accuracy (±${Math.round(e.coords.accuracy)}m). Please turn on High Accuracy Location.`)),document.getElementById("scanner-modal").style.display="flex",D||(D=new Html5Qrcode("scanner-reader")),se()},e=>{console.error("GPS Error:",e),m("❌ Unable to verify live location. Please turn on Location / GPS on your phone.")},{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})};const se=()=>{const e={fps:20,qrbox:(o,t)=>({width:Math.floor(o*.7),height:Math.floor(t*.7)})};D.start({facingMode:W},e,ue).catch(o=>{console.error("Camera access error:",o),m("Cannot open camera. Check permissions.")})};window.toggleCamera=()=>{W=W==="environment"?"user":"environment",D&&D.isScanning&&D.stop().then(()=>se())};window.closeScanner=()=>{D&&D.isScanning?D.stop().then(()=>{document.getElementById("scanner-modal").style.display="none"}):document.getElementById("scanner-modal").style.display="none"};const ue=async e=>{var g;const o=e.trim();if(!o.startsWith("MEC-POS-ATTENDANCE-QR:")){m("⚠️ Invalid QR Code. Scan the Shop QR Code.");return}window.closeScanner(),m("🔄 Verifying physical presence...");const t=o.split(":"),a=t[1]||((g=window.currentStaff)==null?void 0:g.storeId)||"mec-book-shop";let n=parseFloat(t[2]),s=parseFloat(t[3]);try{const y=await le($(h,"config",a));if(y.exists()){const b=y.data();b.storeLatitude&&b.storeLongitude&&(n=parseFloat(b.storeLatitude),s=parseFloat(b.storeLongitude))}}catch(y){console.warn("Could not fetch remote store config:",y)}const d=6371e3,i=C*Math.PI/180,r=n*Math.PI/180,p=(n-C)*Math.PI/180,c=(s-N)*Math.PI/180,l=Math.sin(p/2)*Math.sin(p/2)+Math.cos(i)*Math.cos(r)*Math.sin(c/2)*Math.sin(c/2),f=2*Math.atan2(Math.sqrt(l),Math.sqrt(1-l)),u=d*f;if(u>150){ae=a;const y=u>=1e3?`${(u/1e3).toFixed(1)} km`:`${u.toFixed(1)} m`,b=document.getElementById("mismatch-distance");b&&(b.innerText=y);const x=document.getElementById("mismatch-my-coords");x&&(x.innerText=`${C.toFixed(5)}, ${N.toFixed(5)}`);const v=document.getElementById("mismatch-qr-coords");v&&(v.innerText=`${n.toFixed(5)}, ${s.toFixed(5)}`);const S=document.getElementById("gps-mismatch-modal");S&&(S.style.display="flex");return}try{await J(u,!1)}catch(y){console.error(y),m("Error logging attendance to database: "+(y.message||""))}};
