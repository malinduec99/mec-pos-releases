import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot,
    query,
    where,
    getDocs,
    orderBy,
    limit,
    Timestamp
} from "firebase/firestore";

// --- GLOBAL STATE ---
window.currentSelectedReport = 'profit-margin';
window.currentReportFilters = {
    start: null,
    end: null,
    entity: 'All',
    user: 'All',
    category: 'All'
};

window.currentReportFiltersOld = {
    start: null,
    end: null
};

// --- DATE PARSING HELPERS ---
function parseLocalStart(dateStrOrObj) {
    if (!dateStrOrObj) return null;
    if (dateStrOrObj instanceof Date) {
        const d = new Date(dateStrOrObj);
        d.setHours(0, 0, 0, 0);
        return d;
    }
    const d = new Date(dateStrOrObj + 'T00:00:00');
    return isNaN(d.getTime()) ? null : d;
}

function parseLocalEnd(dateStrOrObj) {
    if (!dateStrOrObj) return null;
    if (dateStrOrObj instanceof Date) {
        const d = new Date(dateStrOrObj);
        d.setHours(23, 59, 59, 999);
        return d;
    }
    const d = new Date(dateStrOrObj + 'T23:59:59.999');
    return isNaN(d.getTime()) ? null : d;
}

// --- ACCOUNTING UTILITIES ---
const formatCurrency = (val) => {
    return (val || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};
window.formatCurrency = formatCurrency;

window.setFinancialYearFilter = () => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    let startYear = (currentMonth >= 3) ? currentYear : currentYear - 1;
    const startDateStr = `${startYear}-04-01`; // April 1st
    const endDateStr = `${startYear + 1}-03-31`; // March 31st next year

    const startInput = document.getElementById('report-start-date-old');
    const endInput = document.getElementById('report-end-date-old');
    
    if (startInput) startInput.value = startDateStr;
    if (endInput) endInput.value = endDateStr;

    window.currentReportFiltersOld.start = parseLocalStart(startDateStr);
    window.currentReportFiltersOld.end = parseLocalEnd(endDateStr);
    
    if (window.allOrders) window.generateReportsOld(window.allOrders);
    window.showToast(`Switched to Financial Year ${startYear}/${startYear+1}`, "info");
};

// --- INITIALIZATION ---
window.initReports = initReports;
export function initReports() {
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    
    // Setup New Filters
    const startInput = document.getElementById('report-start-date');
    const endInput = document.getElementById('report-end-date');
    if (startInput) startInput.value = todayStr;
    if (endInput) endInput.value = todayStr;
    
    window.currentReportFilters.start = parseLocalStart(todayStr);
    window.currentReportFilters.end = parseLocalEnd(todayStr);

    // Setup Old Filters (Financial Reports page)
    const startOld = document.getElementById('report-start-date-old');
    const endOld = document.getElementById('report-end-date-old');
    if (startOld) startOld.value = todayStr;
    if (endOld) endOld.value = todayStr;

    window.currentReportFiltersOld.start = parseLocalStart(todayStr);
    window.currentReportFiltersOld.end = parseLocalEnd(todayStr);

    populateReportFilters();

    // Sync AI Financial Analyst Toggle State from Storage
    const savedAIState = localStorage.getItem('mecpos_ai_analyst_enabled');
    const isAIEnabled = savedAIState !== null ? (savedAIState === 'true') : true;
    window.isAIAnalystEnabled = isAIEnabled;

    const toggleInput = document.getElementById('toggle-ai-financial-analyst');
    const label = document.getElementById('ai-analyst-status-label');
    const slider = document.querySelector('#ai-report-analyst-panel .slider');
    const refreshBtn = document.getElementById('btn-refresh-ai-analyst');
    const content = document.getElementById('ai-report-insights-content');

    const aiPanel = document.getElementById('ai-report-analyst-panel');
    if (aiPanel) {
        aiPanel.style.display = isAIEnabled ? 'block' : 'none';
    }

    if (toggleInput) toggleInput.checked = isAIEnabled;
    if (label) {
        label.innerText = isAIEnabled ? 'AI ON' : 'AI OFF';
        label.style.color = isAIEnabled ? '#10b981' : '#94a3b8';
    }
    if (slider) {
        slider.style.backgroundColor = isAIEnabled ? '#10b981' : '#475569';
    }
    if (refreshBtn) {
        refreshBtn.disabled = !isAIEnabled;
        refreshBtn.style.opacity = isAIEnabled ? '1' : '0.4';
        refreshBtn.style.pointerEvents = isAIEnabled ? 'auto' : 'none';
    }

    if (window.allOrders && window.allOrders.length > 0) {
        window.generateReportsOld(window.allOrders);
    }
}

/**
 * Populates New Dashboard Filter Dropdowns
 */
async function populateReportFilters() {
    const entitySelect = document.getElementById('report-filter-entity');
    const userSelect = document.getElementById('report-filter-user');
    const categorySelect = document.getElementById('report-filter-category');

    if (entitySelect) {
        const entities = new Set();
        (window.allOrders || []).forEach(o => { if (o.userName) entities.add(o.userName); });
        entitySelect.innerHTML = '<option value="All">All Customers/Suppliers</option>' + 
            Array.from(entities).sort().map(e => `<option value="${e}">${e}</option>`).join('');
    }

    if (userSelect) {
        const users = new Set();
        (window.allOrders || []).forEach(o => { if (o.cashier) users.add(o.cashier); });
        userSelect.innerHTML = '<option value="All">All Users</option>' + 
            Array.from(users).sort().map(u => `<option value="${u}">${u}</option>`).join('');
    }

    if (categorySelect) {
        const categories = new Set();
        (window.allProducts || []).forEach(p => { if (p.category) categories.add(p.category); });
        categorySelect.innerHTML = '<option value="All">All Categories</option>' + 
            Array.from(categories).sort().map(c => `<option value="${c}">${c}</option>`).join('');
    }
}

// ==========================================
// --- NEW ANALYTICS DASHBOARD LOGIC ---
// ==========================================

window.selectReport = (reportId, element) => {
    window.currentSelectedReport = reportId;
    document.querySelectorAll('#section-analytics .report-item').forEach(item => item.classList.remove('active'));
    if (element) {
        element.classList.add('active');
    } else {
        const item = document.querySelector(`#section-analytics .report-item[onclick*="${reportId}"]`);
        if (item) item.classList.add('active');
    }

    const titleEl = document.getElementById('analytics-view-title');
    if (titleEl) {
        let label = reportId.replace(/-/g, ' ').toUpperCase();
        if (reportId === 'profit-margin') label = "Sales / Profit & Margin Analysis";
        else if (reportId === 'products') label = "Products Performance Report";
        else if (reportId === 'customers') label = "Customer Purchasing Analytics";
        else if (reportId === 'users') label = "Staff / Cashier Performance";
        else if (reportId === 'daily-sales') label = "Daily Sales Breakdown";
        else if (reportId === 'hourly-sales') label = "Hourly Sales Heatmap";
        else if (reportId === 'refunds') label = "Returns & Refunds Report";
        else if (reportId === 'tax-rates') label = "Tax Liability Analytics";
        else if (reportId === 'stock-movement') label = "Stock Movement Analytics";
        else if (reportId === 'low-stock') label = "Low Stock Warning Report";
        else if (reportId === 'suppliers') label = "Supplier Analytics Report";
        titleEl.innerText = label;
    }

    window.generateCurrentReport();
};

window.generateCurrentReport = async () => {
    const startInput = document.getElementById('report-start-date');
    const endInput = document.getElementById('report-end-date');
    if (!startInput || !endInput) return;

    const now = new Date();
    if (!startInput.value) {
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        startInput.value = firstDay.toISOString().slice(0, 10);
    }
    if (!endInput.value) {
        endInput.value = now.toISOString().slice(0, 10);
    }
    
    window.currentReportFilters.start = parseLocalStart(startInput.value);
    window.currentReportFilters.end = parseLocalEnd(endInput.value);
    window.currentReportFilters.entity = document.getElementById('report-filter-entity')?.value || 'All';
    window.currentReportFilters.user = document.getElementById('report-filter-user')?.value || 'All';
    window.currentReportFilters.category = document.getElementById('report-filter-category')?.value || 'All';

    const renderingSpace = document.getElementById('report-rendering-space');
    if (!renderingSpace) return;

    renderingSpace.innerHTML = '<div style="text-align:center; padding: 40px; color: #38bdf8; font-weight:700;"><i class="fas fa-spinner fa-spin fa-2x"></i><br><br>Generating Analytics Report...</div>';
    renderingSpace.style.display = 'block';

    try {
        const data = filterDataByCurrentFilters();
        let html = '';

        const rep = window.currentSelectedReport || 'profit-margin';

        if (rep === 'profit-margin') html = renderProfitMarginReport(data);
        else if (rep === 'products') html = renderProductsReport(data);
        else if (rep === 'customers') html = renderCustomersReport(data);
        else if (rep === 'users') html = renderUsersReport(data);
        else if (rep === 'daily-sales') html = renderDailySalesReport(data);
        else if (rep === 'hourly-sales') html = renderHourlySalesReport(data);
        else if (rep === 'refunds') html = renderRefundsReport(data);
        else if (rep === 'tax-rates') html = renderTaxRatesReport(data);
        else if (rep === 'stock-movement') html = renderStockMovementReport(data);
        else if (rep === 'low-stock') html = renderLowStockReport(data);
        else if (rep === 'suppliers') html = renderSuppliersReport(data);
        else html = renderProfitMarginReport(data);

        renderingSpace.innerHTML = html;
    } catch (err) {
        console.error(err);
        renderingSpace.innerHTML = `<div style="padding: 2rem; text-align: center; color: #ef4444;">Failed to generate report. ${err.message || ''}</div>`;
    }
};

function filterDataByCurrentFilters() {
    const { start, end, entity, user } = window.currentReportFilters;
    return (window.allOrders || []).filter(o => {
        const orderDate = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        if (orderDate < start || orderDate > end) return false;
        if (entity !== 'All' && o.userName !== entity) return false;
        if (user !== 'All' && o.cashier !== user) return false;
        if (o.status === 'Void' || o.status === 'Cancelled') return false;
        return true;
    });
}

function renderProfitMarginReport(orders) {
    let totalRevenue = 0, totalCost = 0;
    const itemsMap = {};
    orders.forEach(o => {
        (o.items || []).forEach(item => {
            if (window.currentReportFilters.category !== 'All') {
                const product = (window.allProducts || []).find(p => p.name === item.name);
                if (!product || product.category !== window.currentReportFilters.category) return;
            }
            if (!itemsMap[item.name]) itemsMap[item.name] = { qty: 0, revenue: 0, cost: 0 };
            const qty = parseFloat(item.quantity || 1);
            itemsMap[item.name].qty += qty;
            itemsMap[item.name].revenue += ((parseFloat(item.price) || 0) * qty);
            itemsMap[item.name].cost += ((parseFloat(item.costPrice || item.buyingPrice || item.cost || 0)) * qty);
            totalRevenue += ((parseFloat(item.price) || 0) * qty);
            totalCost += ((parseFloat(item.costPrice || item.buyingPrice || item.cost || 0)) * qty);
        });
    });
    const profit = totalRevenue - totalCost;
    const margin = totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0;
    const rows = Object.entries(itemsMap).map(([name, s]) => {
        const p = s.revenue - s.cost;
        const m = s.revenue > 0 ? (p / s.revenue) * 100 : 0;
        return `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.06);">
                <td style="padding: 10px; color: #f1f5f9; font-weight: 700;">${name}</td>
                <td style="padding: 10px; text-align: center; color: #cbd5e1;">${s.qty}</td>
                <td style="padding: 10px; text-align: right; color: #f1f5f9;">LKR ${(s.revenue).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                <td style="padding: 10px; text-align: right; color: #ef4444;">LKR ${(s.cost).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                <td style="padding: 10px; text-align: right; color: #10b981; font-weight: 800;">LKR ${(p).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                <td style="padding: 10px; text-align: right; color: #fbbf24; font-weight: 800;">${m.toFixed(1)}%</td>
            </tr>
        `;
    }).join('');

    return `
        <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
            <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL REVENUE</span>
                <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); padding: 16px; border-radius: 14px;">
                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL ESTIMATED COST</span>
                <div style="color: #ef4444; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
            <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">NET GROSS PROFIT</span>
                <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${profit.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
            <div style="background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.2); padding: 16px; border-radius: 14px;">
                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">OVERALL MARGIN %</span>
                <div style="color: #fbbf24; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">${margin.toFixed(1)}%</div>
            </div>
        </div>

        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Product Name</th>
                        <th style="padding: 10px; text-align: center;">Qty Sold</th>
                        <th style="padding: 10px; text-align: right;">Total Revenue</th>
                        <th style="padding: 10px; text-align: right;">Total Cost</th>
                        <th style="padding: 10px; text-align: right;">Gross Profit</th>
                        <th style="padding: 10px; text-align: right;">Margin %</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows || '<tr><td colspan="6" style="text-align: center; padding: 25px; color: #64748b;">No product items found for period</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderProductsReport(orders) {
    const prodMap = {};
    orders.forEach(o => { 
        (o.items || []).forEach(item => { 
            if (!prodMap[item.name]) prodMap[item.name] = { qty: 0, total: 0 }; 
            const qty = parseFloat(item.quantity || 1);
            prodMap[item.name].qty += qty; 
            prodMap[item.name].total += ((parseFloat(item.price) || 0) * qty); 
        }); 
    });
    const sorted = Object.entries(prodMap).sort((a,b) => b[1].total - a[1].total);
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">#</th>
                        <th style="padding: 10px;">Product Name</th>
                        <th style="padding: 10px; text-align: center;">Units Sold</th>
                        <th style="padding: 10px; text-align: right;">Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${sorted.map(([n,s], idx) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 10px; font-weight: 700; color: #f1f5f9;">${n}</td>
                            <td style="padding: 10px; text-align: center; color: #cbd5e1;">${s.qty}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 25px; color: #64748b;">No product performance data found</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderCustomersReport(orders) {
    const custMap = {};
    orders.forEach(o => {
        const name = o.customerName || o.customer?.name || 'Walk-in Customer';
        if (!custMap[name]) custMap[name] = { count: 0, total: 0 };
        custMap[name].count += 1;
        custMap[name].total += (parseFloat(o.total) || 0);
    });
    const sorted = Object.entries(custMap).sort((a,b) => b[1].total - a[1].total);
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Customer Name</th>
                        <th style="padding: 10px; text-align: center;">Orders Count</th>
                        <th style="padding: 10px; text-align: right;">Total Spent (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${sorted.map(([n,s]) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #38bdf8;">${n}</td>
                            <td style="padding: 10px; text-align: center; color: #cbd5e1;">${s.count}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="3" style="text-align: center; padding: 25px; color: #64748b;">No customer data found</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderUsersReport(orders) {
    const userMap = {};
    orders.forEach(o => {
        const user = o.cashier || o.userName || 'System POS';
        if (!userMap[user]) userMap[user] = { count: 0, total: 0 };
        userMap[user].count += 1;
        userMap[user].total += (parseFloat(o.total) || 0);
    });
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Staff / Cashier</th>
                        <th style="padding: 10px; text-align: center;">Processed Orders</th>
                        <th style="padding: 10px; text-align: right;">Total Billed (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${Object.entries(userMap).map(([u,s]) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #f1f5f9;">${u}</td>
                            <td style="padding: 10px; text-align: center; color: #cbd5e1;">${s.count}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="3" style="text-align: center; padding: 25px; color: #64748b;">No staff cashier data found</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderDailySalesReport(orders) {
    const daily = {};
    orders.forEach(o => { 
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().slice(0, 10) : (o.date || 'Unknown'); 
        if (!daily[d]) daily[d] = { count: 0, total: 0 }; 
        daily[d].count++; 
        daily[d].total += (parseFloat(o.total) || 0); 
    });
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Date</th>
                        <th style="padding: 10px; text-align: center;">Completed Orders</th>
                        <th style="padding: 10px; text-align: right;">Total Revenue (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${Object.entries(daily).sort((a,b) => b[0].localeCompare(a[0])).map(([d,s]) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #38bdf8;">${d}</td>
                            <td style="padding: 10px; text-align: center; color: #cbd5e1;">${s.count}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="3" style="text-align: center; padding: 25px; color: #64748b;">No daily sales found</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderHourlySalesReport(orders) {
    const hourly = Array(24).fill(0).map(() => ({ count: 0, total: 0 }));
    orders.forEach(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : null;
        if (d) {
            const h = d.getHours();
            hourly[h].count++;
            hourly[h].total += (parseFloat(o.total) || 0);
        }
    });

    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Hour Slot</th>
                        <th style="padding: 10px; text-align: center;">Orders Count</th>
                        <th style="padding: 10px; text-align: right;">Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${hourly.map((h, idx) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #38bdf8;">${String(idx).padStart(2, '0')}:00 - ${String(idx).padStart(2, '0')}:59</td>
                            <td style="padding: 10px; text-align: center; color: #cbd5e1;">${h.count}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 800; color: ${h.total > 0 ? '#10b981' : '#64748b'};">LKR ${(h.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderRefundsReport(orders) {
    const voids = (window.allOrders || []).filter(o => o.status === 'Void' || o.isVoid === true);
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">#</th>
                        <th style="padding: 10px;">Order ID</th>
                        <th style="padding: 10px;">Date & Time</th>
                        <th style="padding: 10px; text-align: right;">Voided Amount (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${voids.map((o, idx) => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 10px; font-weight: 700; color: #ef4444;">#${o.orderId || o.docId}</td>
                            <td style="padding: 10px; color: #cbd5e1;">${o.date || '-'}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #ef4444;">LKR ${(parseFloat(o.total) || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 25px; color: #10b981;">🎉 No voided or refunded transactions recorded!</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderTaxRatesReport(orders) {
    const gross = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
    const vat = gross * (0.18 / 1.18);
    const net = gross - vat;
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Tax Category</th>
                        <th style="padding: 10px; text-align: right;">Taxable Base (LKR)</th>
                        <th style="padding: 10px; text-align: right;">VAT Liability (18%)</th>
                        <th style="padding: 10px; text-align: right;">Gross Billed Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <td style="padding: 10px; font-weight: 700; color: #f1f5f9;">Standard Output VAT (18%)</td>
                        <td style="padding: 10px; text-align: right; color: #cbd5e1;">LKR ${net.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 10px; text-align: right; color: #ef4444; font-weight: 800;">LKR ${vat.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 10px; text-align: right; color: #10b981; font-weight: 900;">LKR ${gross.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    `;
}

function renderStockMovementReport(orders) {
    const prods = window.allProducts || [];
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Product Name</th>
                        <th style="padding: 10px;">Category</th>
                        <th style="padding: 10px; text-align: center;">Current Stock</th>
                    </tr>
                </thead>
                <tbody>
                    ${prods.map(p => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #f1f5f9;">${p.name}</td>
                            <td style="padding: 10px; color: #94a3b8;">${p.category || 'General'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 800; color: ${(p.stock || 0) < 10 ? '#ef4444' : '#10b981'};">${p.stock ?? 'INF'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderLowStockReport(orders) {
    const lowProds = (window.allProducts || []).filter(p => p.mode !== 'Service' && (parseFloat(p.stock) || 0) <= 5);
    return `
        <div style="overflow-x: auto;">
            <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                <thead>
                    <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                        <th style="padding: 10px;">Product Name</th>
                        <th style="padding: 10px;">Category</th>
                        <th style="padding: 10px; text-align: center;">Current Stock</th>
                        <th style="padding: 10px; text-align: center;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${lowProds.map(p => `
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 700; color: #ef4444;">${p.name}</td>
                            <td style="padding: 10px; color: #94a3b8;">${p.category || 'General'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 900; color: #ef4444;">${p.stock || 0}</td>
                            <td style="padding: 10px; text-align: center;"><span style="background: rgba(239,68,68,0.2); color: #ef4444; padding: 4px 8px; border-radius: 6px; font-weight:700;">REORDER NOW</span></td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 25px; color: #10b981;">✅ All inventory items are well-stocked above reorder threshold!</td></tr>'}
                </tbody>
            </table>
        </div>
    `;
}

function renderSuppliersReport(orders) {
    return `<div style="padding: 20px; text-align: center; color: #94a3b8;">Supplier purchase analytics active. Total registered suppliers: ${(window.allSuppliers || []).length}</div>`;
}

// ==========================================
// --- RESTORED OLD REPORTS LOGIC ---
// ==========================================

window.generateReports = (orders) => window.generateReportsOld(orders);

window.generateReportsOld = (orders) => {
    let start = window.currentReportFiltersOld.start;
    let end = window.currentReportFiltersOld.end;
    if (!start || !end) {
        const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
        start = parseLocalStart(todayStr);
        end = parseLocalEnd(todayStr);
        window.currentReportFiltersOld.start = start;
        window.currentReportFiltersOld.end = end;
    }
    if (!start || !end) return;

    // 1. Filter orders by date
    const filteredOrders = (orders || []).filter(o => {
        let d = null;
        if (o.timestamp?.seconds) {
            d = new Date(o.timestamp.seconds * 1000);
        } else if (o.createdAt?.seconds) {
            d = new Date(o.createdAt.seconds * 1000);
        } else if (o.date) {
            // Check if o.date has time attached or is just YYYY-MM-DD
            d = o.date.includes('T') || o.date.includes(' ') ? new Date(o.date) : new Date(o.date + 'T12:00:00');
        } else if (o.orderDate) {
            d = new Date(o.orderDate);
        }
        if (!d || isNaN(d.getTime())) return false;
        return d >= start && d <= end && o.status !== 'Void';
    });

    // 2. Filter reloads by date (excluding POS-embedded ones to avoid double-counting)
    const filteredReloads = (window.allReloads || []).filter(r => {
        const d = r.timestamp?.seconds ? new Date(r.timestamp.seconds * 1000) : (r.date ? new Date(r.date + 'T12:00:00') : null);
        if (!d) return false;
        return d >= start && d <= end && r.status !== 'Void' && r.isPOS !== true;
    });

    // --- PRECISE REAL-TIME CATEGORY CALCULATIONS (EXACT CENTS / NO ESTIMATES) ---
    let posSales = 0, posCost = 0;
    let webSales = 0, webCost = 0;
    let repairSales = 0, repairCost = 0;
    let reloadSales = 0, reloadCost = 0, reloadProfit = 0;
    let webCOD = 0, webBank = 0;
    let deliveredTotal = 0, pendingTotal = 0;
    let posBilledCount = 0, webBilledCount = 0, repairBilledCount = 0, reloadBilledCount = 0;

    filteredOrders.forEach(o => {
        const orderIdStr = String(o.orderId || o.id || "");
        const isRepair = orderIdStr.startsWith("#REP-") || orderIdStr.startsWith("REP-") || o.type === 'RepairBill' || Boolean(o.repairJobId);
        const isWeb = (o.isPOS !== true && !orderIdStr.startsWith("#POS") && !orderIdStr.startsWith("POS-") && !isRepair);
        const isPOS = !isRepair && !isWeb;

        const orderTotal = parseFloat(o.total) || 0;
        
        // Sum any embedded reload items inside this order
        let orderEmbeddedReloadSales = 0;
        let orderEmbeddedReloadCost = 0;

        (o.items || []).forEach(item => {
            const qty = parseFloat(item.quantity) || 1;
            const price = parseFloat(item.price || 0);
            const discount = parseFloat(item.discount || 0);
            const itemNetPrice = (price - discount) * qty;

            if (item.isReload) {
                const itemCost = (parseFloat(item.costPrice) || 0) * qty;
                orderEmbeddedReloadSales += itemNetPrice;
                orderEmbeddedReloadCost += itemCost;
                return;
            }

            // Normal item cost lookup (item costPrice or fallback to product registry)
            let unitCost = parseFloat(item.costPrice);
            if (isNaN(unitCost) || unitCost === 0) {
                if (window.allProducts) {
                    const prod = window.allProducts.find(p => p.docId === item.docId || p.sku === item.sku);
                    if (prod) {
                        unitCost = parseFloat(prod.cost || prod.buyingPrice) || 0;
                    } else {
                        unitCost = 0;
                    }
                } else {
                    unitCost = 0;
                }
            }
            const totalItemCost = (unitCost || 0) * qty;

            if (isRepair) {
                repairCost += totalItemCost;
            } else if (isWeb) {
                webCost += totalItemCost;
            } else {
                posCost += totalItemCost;
            }
        });

        // Add embedded reloads to reload category
        if (orderEmbeddedReloadSales > 0) {
            reloadSales += orderEmbeddedReloadSales;
            reloadCost += orderEmbeddedReloadCost;
            reloadProfit += (orderEmbeddedReloadSales - orderEmbeddedReloadCost);
            reloadBilledCount++;
        }

        const netNonReloadOrderAmount = Math.max(0, orderTotal - orderEmbeddedReloadSales);

        if (isRepair) {
            repairSales += netNonReloadOrderAmount;
            repairBilledCount++;
        } else if (isWeb) {
            webSales += netNonReloadOrderAmount;
            webBilledCount++;
            const payMethod = (o.paymentMethod || o.method || "").toLowerCase();
            if (payMethod.includes('cod') || payMethod.includes('cash on delivery')) webCOD += orderTotal;
            else if (payMethod.includes('bank') || payMethod.includes('transfer')) webBank += orderTotal;
        } else {
            posSales += netNonReloadOrderAmount;
            posBilledCount++;
        }

        // Delivery Status
        if (o.status === 'Delivered') deliveredTotal += orderTotal;
        else pendingTotal += orderTotal;
    });

    // Add standalone reloads from allReloads collection
    filteredReloads.forEach(r => {
        const amt = parseFloat(r.baseAmount || r.amount || 0);
        const comm = parseFloat(r.commission || 0);
        reloadSales += amt;
        reloadCost += (amt - comm);
        reloadProfit += comm;
        reloadBilledCount++;
    });

    // Individual Channel Profits
    const posProfit = posSales - posCost;
    const webProfit = webSales - webCost;
    const repairProfit = repairSales - repairCost;
    const posMarginPct = posSales > 0 ? ((posProfit / posSales) * 100).toFixed(1) : '0.0';
    const reloadMarginPct = reloadSales > 0 ? ((reloadProfit / reloadSales) * 100).toFixed(1) : '0.0';
    const webMarginPct = webSales > 0 ? ((webProfit / webSales) * 100).toFixed(1) : '0.0';
    const repairMarginPct = repairSales > 0 ? ((repairProfit / repairSales) * 100).toFixed(1) : '0.0';

    // Grand Totals across all channels (Exact to cent)
    const grandTotalSales = posSales + reloadSales + webSales + repairSales;
    const grandTotalCost = posCost + reloadCost + webCost + repairCost;
    const grandGrossProfit = posProfit + reloadProfit + webProfit + repairProfit;

    // Operational expenses in the selected period
    const periodExpenses = (window.allExpenses || []).filter(exp => {
        let expD = exp.date ? (exp.date.includes("T") ? new Date(exp.date) : new Date(exp.date + "T12:00:00")) : null;
        return expD && expD >= start && expD <= end && exp.status !== "Void";
    }).reduce((sum, exp) => sum + (parseFloat(exp.amount) || 0), 0);

    const grandRealNetProfit = grandGrossProfit - periodExpenses;
    const bankAccount1Cheque = grandTotalCost + periodExpenses;
    const bankAccount2Savings = Math.max(0, grandRealNetProfit);

    // Keep legacy names mapped for backward compatibility in sub-views
    const shopSales = grandTotalSales;
    const shopCost = grandTotalCost;
    const shopProfit = grandGrossProfit;
    const realNetProfit = grandRealNetProfit;

    // --- RENDER EXECUTIVE SUMMARY CARDS ---
    const overview = document.getElementById('reports-overview-grid');
    if (overview) {
        overview.innerHTML = `
            <!-- 🌟 SECTION 1: OVERALL SHOP GRAND TOTALS (100% REALTIME ACCURATE) -->
            <div style="grid-column: 1 / -1; margin-bottom: 5px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <div style="font-size: 0.82rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.6px; display: flex; align-items: center; gap: 8px;">
                        <span>🏢</span> මුළු ආයතනයේ සම්පූර්ණ එකතුව (Shop Grand Totals)
                    </div>
                    <span style="font-size: 0.72rem; color: #94a3b8; background: rgba(255,255,255,0.05); padding: 3px 10px; border-radius: 20px;">Realtime Firestore Sync</span>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px;">
                    <!-- Shop Total Sales -->
                    <div class="stat-card" style="background: linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(56, 189, 248, 0.35); border-radius: 16px; padding: 18px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4 style="margin: 0; color: #94a3b8; font-size: 0.75rem; text-transform: uppercase; font-weight: 800;">Shop Total Sales</h4>
                                <div style="font-size: 1.6rem; font-weight: 900; color: #fff; margin: 6px 0 2px;">LKR ${formatCurrency(grandTotalSales)}</div>
                                <p style="margin: 0; font-size: 0.72rem; color: #38bdf8; font-weight: 700;">සියලු මාර්ගවල මුළු විකුණුම්</p>
                            </div>
                            <div style="font-size: 2rem;">💰</div>
                        </div>
                    </div>

                    <!-- Total Inventory Cost -->
                    <div class="stat-card" style="background: linear-gradient(135deg, rgba(239, 68, 68, 0.12), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(239, 68, 68, 0.3); border-radius: 16px; padding: 18px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4 style="margin: 0; color: #94a3b8; font-size: 0.75rem; text-transform: uppercase; font-weight: 800;">Total Inventory Cost</h4>
                                <div style="font-size: 1.6rem; font-weight: 900; color: #f87171; margin: 6px 0 2px;">LKR ${formatCurrency(grandTotalCost)}</div>
                                <p style="margin: 0; font-size: 0.72rem; color: #94a3b8;">මුළු මිලදී ගැනීමේ වියදම (COGS)</p>
                            </div>
                            <div style="font-size: 2rem;">📉</div>
                        </div>
                    </div>

                    <!-- Gross Profit -->
                    <div class="stat-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(16, 185, 129, 0.3); border-radius: 16px; padding: 18px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4 style="margin: 0; color: #94a3b8; font-size: 0.75rem; text-transform: uppercase; font-weight: 800;">Total Gross Profit</h4>
                                <div style="font-size: 1.6rem; font-weight: 900; color: #10b981; margin: 6px 0 2px;">LKR ${formatCurrency(grandGrossProfit)}</div>
                                <p style="margin: 0; font-size: 0.72rem; color: #10b981; font-weight: 700;">දළ ලාභය (විකුණුම් - භාණ්ඩ වියදම)</p>
                            </div>
                            <div style="font-size: 2rem;">📈</div>
                        </div>
                    </div>

                    <!-- Real Net Profit -->
                    <div class="stat-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.25), rgba(15, 23, 42, 0.98)); border: 2px solid #10b981; box-shadow: 0 4px 25px rgba(16, 185, 129, 0.25); border-radius: 16px; padding: 18px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4 style="margin: 0; color: #a7f3d0; font-size: 0.75rem; text-transform: uppercase; font-weight: 800;">Shop Real Net Profit</h4>
                                <div style="font-size: 1.65rem; font-weight: 900; color: #34d399; margin: 6px 0 2px;">LKR ${formatCurrency(grandRealNetProfit)}</div>
                                <p style="margin: 0; font-size: 0.72rem; color: #cbd5e1;">වියදම් (LKR ${formatCurrency(periodExpenses)}) අඩු කළ ශුද්ධ ලාභය</p>
                            </div>
                            <div style="font-size: 2rem;">🎯</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 🌟 SECTION 2: 4 CHANNELS DEDICATED BREAKDOWN (POS / RELOAD / WEB / REPAIR) -->
            <div style="grid-column: 1 / -1; margin-top: 10px;">
                <div style="font-size: 0.82rem; font-weight: 800; color: #c084fc; text-transform: uppercase; letter-spacing: 0.6px; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                    <span>📊</span> අංශ අනුව වෙන් වෙන්ව විකුණුම්, වියදම සහ ලාභය (Channel-by-Channel Breakdown)
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 14px;">
                    
                    <!-- 1. POS STORE SALE CARD -->
                    <div class="stat-card" style="display: flex !important; flex-direction: column !important; align-items: stretch !important; gap: 0 !important; background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(56, 189, 248, 0.35); border-radius: 16px; padding: 18px; box-shadow: 0 8px 24px rgba(0,0,0,0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 14px; width: 100%;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(56, 189, 248, 0.15); border: 1px solid rgba(56, 189, 248, 0.3); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">🏪</div>
                                <div>
                                    <h4 style="margin: 0; color: #38bdf8; font-size: 0.98rem; font-weight: 900; letter-spacing: 0.3px;">POS Shop Sales</h4>
                                    <div style="font-size: 0.72rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">📋 ${posBilledCount} Invoices Billed</div>
                                </div>
                            </div>
                            <span style="font-size: 0.68rem; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 3px 9px; border-radius: 12px; font-weight: 800; letter-spacing: 0.5px;">COUNTER</span>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                            <div style="background: rgba(15, 23, 42, 0.5); padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(255, 255, 255, 0.05);">
                                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                                    <span style="color: #94a3b8; font-size: 0.74rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Sale Amount:</span>
                                    <span style="font-weight: 900; color: #ffffff; font-size: 1.35rem;">LKR ${formatCurrency(posSales)}</span>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 2px 6px;">
                                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                                    <span style="width: 6px; height: 6px; border-radius: 50%; background: #f87171; display: inline-block;"></span>
                                    Cost (මිලදී ගත් මුදල):
                                </span>
                                <span style="font-weight: 800; color: #f87171; font-size: 0.92rem;">LKR ${formatCurrency(posCost)}</span>
                            </div>
                            <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(16, 185, 129, 0.04)); border: 1px solid rgba(16, 185, 129, 0.28); border-radius: 10px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
                                <div>
                                    <div style="color: #a7f3d0; font-weight: 800; font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.5px;">POS Net Margin</div>
                                    <div style="font-size: 0.68rem; color: #6ee7b7; font-weight: 600; margin-top: 1px;">${posMarginPct}% Margin</div>
                                </div>
                                <div style="font-weight: 900; color: #34d399; font-size: 1.18rem; text-align: right;">
                                    LKR ${formatCurrency(posProfit)}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 2. RELOAD SALES CARD -->
                    <div class="stat-card" style="display: flex !important; flex-direction: column !important; align-items: stretch !important; gap: 0 !important; background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(168, 85, 247, 0.35); border-radius: 16px; padding: 18px; box-shadow: 0 8px 24px rgba(0,0,0,0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 14px; width: 100%;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(168, 85, 247, 0.15); border: 1px solid rgba(168, 85, 247, 0.3); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">📱</div>
                                <div>
                                    <h4 style="margin: 0; color: #c084fc; font-size: 0.98rem; font-weight: 900; letter-spacing: 0.3px;">Reload Sales</h4>
                                    <div style="font-size: 0.72rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">📋 ${reloadBilledCount} Reloads Transacted</div>
                                </div>
                            </div>
                            <span style="font-size: 0.68rem; background: rgba(168, 85, 247, 0.15); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.3); padding: 3px 9px; border-radius: 12px; font-weight: 800; letter-spacing: 0.5px;">TOP-UP</span>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                            <div style="background: rgba(15, 23, 42, 0.5); padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(255, 255, 255, 0.05);">
                                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                                    <span style="color: #94a3b8; font-size: 0.74rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Sale Amount:</span>
                                    <span style="font-weight: 900; color: #ffffff; font-size: 1.35rem;">LKR ${formatCurrency(reloadSales)}</span>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 2px 6px;">
                                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                                    <span style="width: 6px; height: 6px; border-radius: 50%; background: #f87171; display: inline-block;"></span>
                                    Base Cost (මූලික මුදල):
                                </span>
                                <span style="font-weight: 800; color: #f87171; font-size: 0.92rem;">LKR ${formatCurrency(reloadCost)}</span>
                            </div>
                            <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(16, 185, 129, 0.04)); border: 1px solid rgba(16, 185, 129, 0.28); border-radius: 10px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
                                <div>
                                    <div style="color: #a7f3d0; font-weight: 800; font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.5px;">Commission / Profit</div>
                                    <div style="font-size: 0.68rem; color: #6ee7b7; font-weight: 600; margin-top: 1px;">${reloadMarginPct}% Margin</div>
                                </div>
                                <div style="font-weight: 900; color: #34d399; font-size: 1.18rem; text-align: right;">
                                    LKR ${formatCurrency(reloadProfit)}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 3. WEB STORE SALES CARD -->
                    <div class="stat-card" style="display: flex !important; flex-direction: column !important; align-items: stretch !important; gap: 0 !important; background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(245, 158, 11, 0.35); border-radius: 16px; padding: 18px; box-shadow: 0 8px 24px rgba(0,0,0,0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 14px; width: 100%;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.3); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">🌐</div>
                                <div>
                                    <h4 style="margin: 0; color: #f59e0b; font-size: 0.98rem; font-weight: 900; letter-spacing: 0.3px;">Web Store Sales</h4>
                                    <div style="font-size: 0.72rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">📦 ${webBilledCount} Online Orders</div>
                                </div>
                            </div>
                            <span style="font-size: 0.68rem; background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3); padding: 3px 9px; border-radius: 12px; font-weight: 800; letter-spacing: 0.5px;">ONLINE</span>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                            <div style="background: rgba(15, 23, 42, 0.5); padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(255, 255, 255, 0.05);">
                                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                                    <span style="color: #94a3b8; font-size: 0.74rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Sale Amount:</span>
                                    <span style="font-weight: 900; color: #ffffff; font-size: 1.35rem;">LKR ${formatCurrency(webSales)}</span>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 2px 6px;">
                                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                                    <span style="width: 6px; height: 6px; border-radius: 50%; background: #f87171; display: inline-block;"></span>
                                    Product Cost (භාණ්ඩ වියදම):
                                </span>
                                <span style="font-weight: 800; color: #f87171; font-size: 0.92rem;">LKR ${formatCurrency(webCost)}</span>
                            </div>
                            <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(16, 185, 129, 0.04)); border: 1px solid rgba(16, 185, 129, 0.28); border-radius: 10px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
                                <div>
                                    <div style="color: #a7f3d0; font-weight: 800; font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.5px;">Web Net Margin</div>
                                    <div style="font-size: 0.68rem; color: #6ee7b7; font-weight: 600; margin-top: 1px;">${webMarginPct}% Margin</div>
                                </div>
                                <div style="font-weight: 900; color: #34d399; font-size: 1.18rem; text-align: right;">
                                    LKR ${formatCurrency(webProfit)}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 4. REPAIR SHOP SALES CARD -->
                    <div class="stat-card" style="display: flex !important; flex-direction: column !important; align-items: stretch !important; gap: 0 !important; background: linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(236, 72, 153, 0.35); border-radius: 16px; padding: 18px; box-shadow: 0 8px 24px rgba(0,0,0,0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 12px; margin-bottom: 14px; width: 100%;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(236, 72, 153, 0.15); border: 1px solid rgba(236, 72, 153, 0.3); display: flex; align-items: center; justify-content: center; font-size: 1.25rem;">🔧</div>
                                <div>
                                    <h4 style="margin: 0; color: #f472b6; font-size: 0.98rem; font-weight: 900; letter-spacing: 0.3px;">Repair Shop Sales</h4>
                                    <div style="font-size: 0.72rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">🛠️ ${repairBilledCount} Jobs Handled</div>
                                </div>
                            </div>
                            <span style="font-size: 0.68rem; background: rgba(236, 72, 153, 0.15); color: #f472b6; border: 1px solid rgba(236, 72, 153, 0.3); padding: 3px 9px; border-radius: 12px; font-weight: 800; letter-spacing: 0.5px;">SERVICE</span>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 10px; width: 100%;">
                            <div style="background: rgba(15, 23, 42, 0.5); padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(255, 255, 255, 0.05);">
                                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                                    <span style="color: #94a3b8; font-size: 0.74rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Total Charged:</span>
                                    <span style="font-weight: 900; color: #ffffff; font-size: 1.35rem;">LKR ${formatCurrency(repairSales)}</span>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 2px 6px;">
                                <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                                    <span style="width: 6px; height: 6px; border-radius: 50%; background: #f87171; display: inline-block;"></span>
                                    Spare Parts Cost (අමතර කොටස්):
                                </span>
                                <span style="font-weight: 800; color: #f87171; font-size: 0.92rem;">LKR ${formatCurrency(repairCost)}</span>
                            </div>
                            <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(16, 185, 129, 0.04)); border: 1px solid rgba(16, 185, 129, 0.28); border-radius: 10px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
                                <div>
                                    <div style="color: #a7f3d0; font-weight: 800; font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.5px;">Service Profit</div>
                                    <div style="font-size: 0.68rem; color: #6ee7b7; font-weight: 600; margin-top: 1px;">${repairMarginPct}% Margin</div>
                                </div>
                                <div style="font-weight: 900; color: #34d399; font-size: 1.18rem; text-align: right;">
                                    LKR ${formatCurrency(repairProfit)}
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- 🌟 SECTION 3: BANK DEPOSIT SPLIT WIDGET -->
            <div class="stat-card dual-bank-split" style="display: flex !important; flex-direction: column !important; align-items: stretch !important; gap: 0 !important; grid-column: 1 / -1; background: linear-gradient(135deg, rgba(56, 189, 248, 0.08), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(56, 189, 248, 0.3); padding: 18px; border-radius: 16px; margin-top: 8px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; width: 100%;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.4rem;">🏦</span>
                        <div>
                            <div style="font-weight: 900; color: #38bdf8; font-size: 1.05rem; letter-spacing: 0.3px;">Automated Dual Bank Deposit Split (NDB Accounts)</div>
                            <div style="font-size: 0.72rem; color: #94a3b8;">Recommended Daily Cash Deposit Allocation for Cost vs Profit</div>
                        </div>
                    </div>
                    <span style="font-size: 0.72rem; background: rgba(56, 189, 248, 0.15); color: #38bdf8; padding: 4px 12px; border-radius: 20px; font-weight: 800; border: 1px solid rgba(56, 189, 248, 0.3);">NDB BANK ALLOCATION</span>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; width: 100%;">
                    <div style="background: rgba(15, 23, 42, 0.7); padding: 14px 18px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08);">
                        <div style="font-size: 0.78rem; color: #38bdf8; font-weight: 800; letter-spacing: 0.5px;">1️⃣ CHEQUE / CURRENT A/C (#111000391437)</div>
                        <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 3px;">Cost of Goods + Operating Expenses + Rent Reserve</div>
                        <div style="font-size: 1.35rem; font-weight: 900; color: #38bdf8; margin-top: 6px;">LKR ${formatCurrency(bankAccount1Cheque)}</div>
                    </div>
                    <div style="background: rgba(15, 23, 42, 0.7); padding: 14px 18px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08);">
                        <div style="font-size: 0.78rem; color: #10b981; font-weight: 800; letter-spacing: 0.5px;">2️⃣ SAVINGS / PROFIT A/C (#115512344412)</div>
                        <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 3px;">Net Profit Allocation for Business Expansion</div>
                        <div style="font-size: 1.35rem; font-weight: 900; color: #34d399; margin-top: 6px;">LKR ${formatCurrency(bankAccount2Savings)}</div>
                    </div>
                </div>
            </div>

            <!-- 🌟 SECTION 4: WEB & DELIVERY LOGISTICS (COMPLETED & PENDING) -->
            <div style="grid-column: 1 / -1; margin-top: 8px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px;">
                    <div class="stat-card web-cod">
                        <div class="icon">🚚</div>
                        <div class="details">
                            <h4>Web Store (COD)</h4>
                            <div class="val">LKR ${formatCurrency(webCOD)}</div>
                            <p>Cash on delivery orders</p>
                        </div>
                    </div>
                    <div class="stat-card web-bank">
                        <div class="icon">🏦</div>
                        <div class="details">
                            <h4>Web Store (Bank)</h4>
                            <div class="val">LKR ${formatCurrency(webBank)}</div>
                            <p>Direct bank transfers</p>
                        </div>
                    </div>
                    <div class="stat-card status-delivered">
                        <div class="icon">✅</div>
                        <div class="details">
                            <h4>Delivered Sales</h4>
                            <div class="val">LKR ${formatCurrency(deliveredTotal)}</div>
                            <p>Completed transactions</p>
                        </div>
                    </div>
                    <div class="stat-card status-pending">
                        <div class="icon">⏳</div>
                        <div class="details">
                            <h4>Pending Sales</h4>
                            <div class="val" style="color: #f59e0b;">LKR ${formatCurrency(pendingTotal)}</div>
                            <p>Orders in pipeline</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Render Dashboard Graphs Container directly inside the dedicated Executive Dashboard view
        let chartsContainer = document.getElementById('reports-visual-charts-wrap');
        if (!chartsContainer) {
            const dashView = document.getElementById('report-view-dashboard');
            if (dashView) {
                chartsContainer = document.createElement('div');
                chartsContainer.id = 'reports-visual-charts-wrap';
                dashView.appendChild(chartsContainer);
            }
        }

        // Compute Today, This Month, Last Month, and Last Year historical metrics from allOrders
        const allOrdersList = window.allOrders || [];
        const now = new Date();
        const curYear = now.getFullYear();
        const curMonth = now.getMonth(); // 0-indexed
        const todayYYYYMMDD = now.toISOString().slice(0, 10);

        let todaySalesSum = 0, todayOrdersCount = 0;
        let curMonthSalesSum = 0, curMonthCostSum = 0, curMonthOrdersCount = 0;
        let lastMonthSalesSum = 0, lastMonthOrdersCount = 0;
        let lastYearMonthSalesSum = 0;

        // Today's real-time precise breakdown across all 4 channels
        let todayPOSSales = 0, todayPOSCost = 0;
        let todayReloadSales = 0, todayReloadCost = 0, todayReloadProfit = 0;
        let todayWebSales = 0, todayWebCost = 0;
        let todayRepairSales = 0, todayRepairCost = 0;

        allOrdersList.forEach(o => {
            if (o.status === 'Void') return;
            let d = null;
            if (o.timestamp?.seconds) d = new Date(o.timestamp.seconds * 1000);
            else if (o.createdAt?.seconds) d = new Date(o.createdAt.seconds * 1000);
            else if (o.date) d = o.date.includes('T') || o.date.includes(' ') ? new Date(o.date) : new Date(o.date + 'T12:00:00');
            else if (o.orderDate) d = new Date(o.orderDate);
            if (!d || isNaN(d.getTime())) return;

            const tot = parseFloat(o.total) || 0;
            const y = d.getFullYear();
            const m = d.getMonth();
            const isoDate = d.toISOString().slice(0, 10);

            // Today's accurate calculations
            if (isoDate === todayYYYYMMDD) {
                todaySalesSum += tot;
                todayOrdersCount++;

                const orderIdStr = String(o.orderId || o.id || "");
                const isRepair = orderIdStr.startsWith("#REP-") || orderIdStr.startsWith("REP-") || o.type === 'RepairBill' || Boolean(o.repairJobId);
                const isWeb = (o.isPOS !== true && !orderIdStr.startsWith("#POS") && !orderIdStr.startsWith("POS-") && !isRepair);

                let orderReloads = 0, orderReloadCosts = 0;
                (o.items || []).forEach(i => {
                    const qty = parseFloat(i.quantity) || 1;
                    const price = parseFloat(i.price || 0);
                    const discount = parseFloat(i.discount || 0);
                    const itemNetPrice = (price - discount) * qty;

                    if (i.isReload) {
                        const rCost = (parseFloat(i.costPrice) || 0) * qty;
                        orderReloads += itemNetPrice;
                        orderReloadCosts += rCost;
                        return;
                    }

                    let uCost = parseFloat(i.costPrice);
                    if (isNaN(uCost) || uCost === 0) {
                        const p = (window.allProducts || []).find(pr => pr.docId === i.docId || pr.sku === i.sku);
                        uCost = p ? (parseFloat(p.cost || p.buyingPrice) || 0) : 0;
                    }
                    const totalCost = (uCost || 0) * qty;

                    if (isRepair) todayRepairCost += totalCost;
                    else if (isWeb) todayWebCost += totalCost;
                    else todayPOSCost += totalCost;
                });

                if (orderReloads > 0) {
                    todayReloadSales += orderReloads;
                    todayReloadCost += orderReloadCosts;
                    todayReloadProfit += (orderReloads - orderReloadCosts);
                }

                const netNonReload = Math.max(0, tot - orderReloads);
                if (isRepair) todayRepairSales += netNonReload;
                else if (isWeb) todayWebSales += netNonReload;
                else todayPOSSales += netNonReload;
            }

            // Current Month
            if (y === curYear && m === curMonth) {
                curMonthSalesSum += tot;
                curMonthOrdersCount++;
                (o.items || []).forEach(i => {
                    const p = (window.allProducts || []).find(pr => pr.docId === i.docId || pr.sku === i.sku) || i;
                    curMonthCostSum += ((parseFloat(p.cost || p.buyingPrice) || 0) * (i.quantity || 1));
                });
            }

            // Last Month
            const lastMonthTarget = curMonth === 0 ? 11 : curMonth - 1;
            const lastMonthYearTarget = curMonth === 0 ? curYear - 1 : curYear;
            if (y === lastMonthYearTarget && m === lastMonthTarget) {
                lastMonthSalesSum += tot;
                lastMonthOrdersCount++;
            }

            // Last Year (Same Month)
            if (y === curYear - 1 && m === curMonth) {
                lastYearMonthSalesSum += tot;
            }
        });

        // Add standalone reloads transacted today
        (window.allReloads || []).forEach(r => {
            if (r.status === 'Void' || r.isPOS === true) return;
            const d = r.timestamp?.seconds ? new Date(r.timestamp.seconds * 1000) : (r.date ? new Date(r.date + 'T12:00:00') : null);
            if (d && d.toISOString().slice(0, 10) === todayYYYYMMDD) {
                const amt = parseFloat(r.baseAmount || r.amount || 0);
                const comm = parseFloat(r.commission || 0);
                todayReloadSales += amt;
                todayReloadCost += (amt - comm);
                todayReloadProfit += comm;
                todaySalesSum += amt;
            }
        });

        const todayTotalCost = todayPOSCost + todayReloadCost + todayWebCost + todayRepairCost;
        const todayGrossProfit = todaySalesSum - todayTotalCost;

        const curMonthProfit = Math.max(0, curMonthSalesSum - curMonthCostSum);
        const monthGrowthVsLastMonth = lastMonthSalesSum > 0 ? (((curMonthSalesSum - lastMonthSalesSum) / lastMonthSalesSum) * 100).toFixed(1) : '+100';
        const monthGrowthVsLastYear = lastYearMonthSalesSum > 0 ? (((curMonthSalesSum - lastYearMonthSalesSum) / lastYearMonthSalesSum) * 100).toFixed(1) : '+100';

        chartsContainer.innerHTML = `
            <!-- Top Executive Performance KPI Banner (Today & Monthly Horizon) -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.2rem; margin-bottom: 1.5rem;">
                <div class="card glass-card" style="padding: 1.25rem 1.5rem; background: linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(56, 189, 248, 0.35); border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="font-size: 0.75rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.8px;">Today's Live Sales</span>
                            <h3 style="margin: 6px 0 2px; font-size: 1.6rem; font-weight: 900; color: #fff;">LKR ${formatCurrency(todaySalesSum)}</h3>
                            <div style="font-size: 0.72rem; color: #10b981; font-weight: 700;">Gross Profit: LKR ${formatCurrency(todayGrossProfit)} (Cost: LKR ${formatCurrency(todayTotalCost)})</div>
                            <div style="font-size: 0.7rem; color: #94a3b8; margin-top: 2px;">${todayOrdersCount} Orders Billed Today</div>
                        </div>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(56, 189, 248, 0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">☀️</div>
                    </div>
                </div>

                <div class="card glass-card" style="padding: 1.25rem 1.5rem; background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(15, 23, 42, 0.95)); border: 1.5px solid rgba(16, 185, 129, 0.35); border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="font-size: 0.75rem; font-weight: 800; color: #10b981; text-transform: uppercase; letter-spacing: 0.8px;">This Month Revenue</span>
                            <h3 style="margin: 6px 0 2px; font-size: 1.6rem; font-weight: 900; color: #10b981;">LKR ${formatCurrency(curMonthSalesSum)}</h3>
                            <div style="font-size: 0.75rem; color: #94a3b8;">Gross Profit: LKR ${formatCurrency(curMonthProfit)}</div>
                        </div>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(16, 185, 129, 0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">📅</div>
                    </div>
                </div>

                <div class="card glass-card" style="padding: 1.25rem 1.5rem; background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(15, 23, 42, 0.95)); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="font-size: 0.75rem; font-weight: 800; color: #f59e0b; text-transform: uppercase; letter-spacing: 0.8px;">Last Month (පසුගිය මාසය)</span>
                            <h3 style="margin: 6px 0 2px; font-size: 1.6rem; font-weight: 900; color: #f59e0b;">LKR ${formatCurrency(lastMonthSalesSum)}</h3>
                            <div style="font-size: 0.75rem; color: ${parseFloat(monthGrowthVsLastMonth) >= 0 ? '#10b981' : '#ef4444'}; font-weight: 700;">
                                ${parseFloat(monthGrowthVsLastMonth) >= 0 ? '▲ +' : '▼ '}${monthGrowthVsLastMonth}% මාසික වෙනස (MoM)
                            </div>
                        </div>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(245, 158, 11, 0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">⏪</div>
                    </div>
                </div>

                <div class="card glass-card" style="padding: 1.25rem 1.5rem; background: linear-gradient(135deg, rgba(168, 85, 247, 0.15), rgba(15, 23, 42, 0.95)); border: 1px solid rgba(168, 85, 247, 0.35); border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <span style="font-size: 0.75rem; font-weight: 800; color: #c084fc; text-transform: uppercase; letter-spacing: 0.8px;">Last Year Same Month (පසුගිය වසරේ)</span>
                            <h3 style="margin: 6px 0 2px; font-size: 1.6rem; font-weight: 900; color: #c084fc;">LKR ${formatCurrency(lastYearMonthSalesSum)}</h3>
                            <div style="font-size: 0.75rem; color: ${parseFloat(monthGrowthVsLastYear) >= 0 ? '#10b981' : '#ef4444'}; font-weight: 700;">
                                ${parseFloat(monthGrowthVsLastYear) >= 0 ? '▲ +' : '▼ '}${monthGrowthVsLastYear}% වාර්ෂික වෙනස (YoY)
                            </div>
                        </div>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(168, 85, 247, 0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">🏛️</div>
                    </div>
                </div>
            </div>

            <!-- Quick Live Category Performance Strip (Today) -->
            <div style="background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 14px 20px; margin-bottom: 2rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div style="border-right: 1px solid rgba(255,255,255,0.06); padding-right: 10px;">
                    <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 800;">🏪 TODAY POS SALES</div>
                    <div style="font-size: 1.15rem; font-weight: 900; color: #38bdf8; margin: 3px 0 1px;">LKR ${formatCurrency(todayPOSSales)}</div>
                    <div style="font-size: 0.7rem; color: #10b981; font-weight: 700;">Profit: LKR ${formatCurrency(todayPOSSales - todayPOSCost)}</div>
                </div>
                <div style="border-right: 1px solid rgba(255,255,255,0.06); padding-right: 10px;">
                    <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 800;">📱 TODAY RELOADS</div>
                    <div style="font-size: 1.15rem; font-weight: 900; color: #c084fc; margin: 3px 0 1px;">LKR ${formatCurrency(todayReloadSales)}</div>
                    <div style="font-size: 0.7rem; color: #10b981; font-weight: 700;">Comm: LKR ${formatCurrency(todayReloadProfit)}</div>
                </div>
                <div style="border-right: 1px solid rgba(255,255,255,0.06); padding-right: 10px;">
                    <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 800;">🌐 TODAY WEB SALES</div>
                    <div style="font-size: 1.15rem; font-weight: 900; color: #f59e0b; margin: 3px 0 1px;">LKR ${formatCurrency(todayWebSales)}</div>
                    <div style="font-size: 0.7rem; color: #10b981; font-weight: 700;">Profit: LKR ${formatCurrency(todayWebSales - todayWebCost)}</div>
                </div>
                <div>
                    <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 800;">🔧 TODAY REPAIR SALES</div>
                    <div style="font-size: 1.15rem; font-weight: 900; color: #f472b6; margin: 3px 0 1px;">LKR ${formatCurrency(todayRepairSales)}</div>
                    <div style="font-size: 0.7rem; color: #10b981; font-weight: 700;">Profit: LKR ${formatCurrency(todayRepairSales - todayRepairCost)}</div>
                </div>
            </div>

            <!-- Main Charts Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 1.5rem;">
                <!-- 1. Financial Year Monthly Performance (April 01 - March 31): Sales, Cost & Profit (Line/Area Chart) -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #38bdf8; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>📈</span> Financial Year Monthly Trajectory (Apr 01 – Mar 31)
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">සම්පූර්ණ විකුණුම් (Sales), වියදම (Cost) සහ ලාභය (Profit) මාසෙන් මාසයට</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #38bdf8; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">FY Monthly</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-timeline-chart"></canvas>
                    </div>
                </div>

                <!-- 2. Historical Comparison: This Month vs Last Month & Last Year -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(244, 63, 94, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #fb7185; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>📊</span> Past Month & Last Year Sales Comparison
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">පසුගිය වසර, පසුගිය මාසය සහ මේ මාසයේ විකුණුම් සංසන්දනය</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #fb7185; background: rgba(244, 63, 94, 0.1); border: 1px solid rgba(244, 63, 94, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">Sales Growth</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-growth-compare-chart"></canvas>
                    </div>
                </div>

                <!-- 3. Payment Channels & Revenue Mix (Doughnut) -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #10b981; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>💳</span> Payment Channels & Revenue Mix
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">Cash, Card, Bank, Credit & Reload share</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #10b981; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">Distribution</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-payment-chart"></canvas>
                    </div>
                </div>

                <!-- 4. Top 5 Revenue Contributing Products (Horizontal Bar) -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #f59e0b; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>🏆</span> Top 5 Revenue Contributing Items
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">Ranked by gross sales volume (LKR)</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #f59e0b; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">Top Performers</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-products-chart"></canvas>
                    </div>
                </div>

                <!-- 5. Cost vs Gross Margin Composition (Doughnut) -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(168, 85, 247, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #c084fc; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>⚖️</span> Cost vs Net Margin Ratio
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">Inventory COGS vs Gross Profitability</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #c084fc; background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">Margin Ratio</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-margin-chart"></canvas>
                    </div>
                </div>

                <!-- 6. Revenue & Profit by Channel Comparison (Bar Chart) - Fills the 6th slot -->
                <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(14, 165, 233, 0.25); border-radius: 18px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2rem;">
                        <div>
                            <h4 style="margin: 0; color: #38bdf8; font-size: 1.05rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                                <span>🏪</span> 4-Channel Revenue & Profit
                            </h4>
                            <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.75rem;">POS, Reload, Web & Repair සංසන්දනය</p>
                        </div>
                        <span style="font-size: 0.72rem; color: #38bdf8; background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 12px; border-radius: 20px; font-weight: 800;">Channels</span>
                    </div>
                    <div style="position: relative; height: 280px; width: 100%;">
                        <canvas id="rep-dash-channels-chart"></canvas>
                    </div>
                </div>
            </div>
        `;

        // Render Chart.js Visualizations
        window.renderVisualDashboardCharts(
            filteredOrders, 
            shopSales, shopCost, shopProfit, 
            webCOD, webBank, 
            repairSales, repairProfit,
            reloadSales, reloadProfit,
            posSales, posProfit,
            webSales, webProfit
        );
    }

    window.renderSalesReportOld(filteredOrders);
    window.renderProductReportOld(filteredOrders);
    window.renderProfitReportOld(filteredOrders);
};

// Dynamic Chart.js Rendering Engine
window.renderVisualDashboardCharts = (
    orders, 
    shopSales, shopCost, shopProfit, 
    webCOD, webBank, 
    repairSales, repairProfit,
    reloadSales, reloadProfit,
    posSales, posProfit,
    webSales, webProfit
) => {
    if (typeof Chart === 'undefined') return;

    // 1. Financial Year Monthly Trajectory (April 01 - March 31): Sales, Cost & Profit
    const nowForFY = new Date();
    const currentCalYear = nowForFY.getFullYear();
    const currentCalMonth = nowForFY.getMonth(); // 0-indexed (0=Jan, 3=Apr)
    // In Sri Lanka / corporate financial year: if current month is Jan-Mar (0,1,2), FY started previous year April
    const fyStartYear = currentCalMonth >= 3 ? currentCalYear : currentCalYear - 1;
    const fyEndYear = fyStartYear + 1;

    // Build the 12 months array: Apr (fyStartYear) to Mar (fyEndYear)
    const monthShortNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const fyMonths = []; // { year, monthIndex, key: 'YYYY-MM', label: 'Apr 2026' }
    for (let m = 3; m <= 11; m++) {
        fyMonths.push({
            year: fyStartYear,
            monthIndex: m,
            key: `${fyStartYear}-${String(m + 1).padStart(2, '0')}`,
            label: `${monthShortNames[m]} ${fyStartYear}`
        });
    }
    for (let m = 0; m <= 2; m++) {
        fyMonths.push({
            year: fyEndYear,
            monthIndex: m,
            key: `${fyEndYear}-${String(m + 1).padStart(2, '0')}`,
            label: `${monthShortNames[m]} ${fyEndYear}`
        });
    }

    // Accumulate Sales, Cost, and Profit per month for the FY from window.allOrders
    const fyDataMap = {};
    fyMonths.forEach(fm => {
        fyDataMap[fm.key] = { sales: 0, cost: 0, profit: 0 };
    });

    const allOrdersFY = window.allOrders || orders || [];
    allOrdersFY.forEach(o => {
        if (o.status === 'Void') return;
        let d = null;
        if (o.timestamp?.seconds) d = new Date(o.timestamp.seconds * 1000);
        else if (o.createdAt?.seconds) d = new Date(o.createdAt.seconds * 1000);
        else if (o.date) d = o.date.includes('T') || o.date.includes(' ') ? new Date(o.date) : new Date(o.date + 'T12:00:00');
        else if (o.orderDate) d = new Date(o.orderDate);
        if (!d || isNaN(d.getTime())) return;

        const y = d.getFullYear();
        const m = d.getMonth();
        const k = `${y}-${String(m + 1).padStart(2, '0')}`;

        if (fyDataMap[k]) {
            const tot = parseFloat(o.total) || 0;
            let c = 0;
            (o.items || []).forEach(i => {
                const p = (window.allProducts || []).find(pr => pr.docId === i.docId || pr.sku === i.sku) || i;
                c += ((parseFloat(p.cost || p.buyingPrice) || 0) * (i.quantity || 1));
            });
            fyDataMap[k].sales += tot;
            fyDataMap[k].cost += c;
            fyDataMap[k].profit += Math.max(0, tot - c);
        }
    });

    const fyLabels = fyMonths.map(fm => fm.label);
    const fySalesData = fyMonths.map(fm => fyDataMap[fm.key].sales.toFixed(2));
    const fyCostData = fyMonths.map(fm => fyDataMap[fm.key].cost.toFixed(2));
    const fyProfitData = fyMonths.map(fm => fyDataMap[fm.key].profit.toFixed(2));

    const ctxTimeline = document.getElementById('rep-dash-timeline-chart');
    if (ctxTimeline) {
        if (window._chartTimeline) window._chartTimeline.destroy();
        window._chartTimeline = new Chart(ctxTimeline, {
            type: 'line',
            data: {
                labels: fyLabels,
                datasets: [
                    {
                        label: 'Total Sales (විකුණුම්)',
                        data: fySalesData,
                        borderColor: '#38bdf8',
                        backgroundColor: 'rgba(56, 189, 248, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#38bdf8',
                        pointRadius: 4,
                        pointHoverRadius: 6
                    },
                    {
                        label: 'Buying Cost (වියදම/Cost)',
                        data: fyCostData,
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.05)',
                        borderWidth: 2.5,
                        borderDash: [5, 5],
                        fill: false,
                        tension: 0.35,
                        pointBackgroundColor: '#f59e0b',
                        pointRadius: 3.5,
                        pointHoverRadius: 6
                    },
                    {
                        label: 'Net Profit (ලාභය)',
                        data: fyProfitData,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#10b981',
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#cbd5e1', font: { family: 'Outfit', weight: '700' } } },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return ` ${context.dataset.label}: LKR ${parseFloat(context.parsed.y).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8', font: { weight: '600', size: 10 } } },
                    y: { 
                        grid: { color: 'rgba(255,255,255,0.05)' }, 
                        ticks: { 
                            color: '#94a3b8',
                            callback: function(value) {
                                return value >= 1000 ? (value / 1000).toFixed(0) + 'k' : value;
                            }
                        } 
                    }
                }
            }
        });
    }

    // 2. Historical Benchmark: This Month vs Last Month vs Last Year (Grouped Bar Chart)
    const ctxCompare = document.getElementById('rep-dash-growth-compare-chart');
    if (ctxCompare) {
        if (window._chartCompare) window._chartCompare.destroy();

        // Calculate metrics for This Month, Last Month, and Last Year
        const allList = window.allOrders || [];
        const nDate = new Date();
        const thisYr = nDate.getFullYear();
        const thisMo = nDate.getMonth();

        let thisMoRev = 0, lastMoRev = 0, lastYrRev = 0;
        let thisMoProfit = 0, lastMoProfit = 0, lastYrProfit = 0;

        allList.forEach(o => {
            if (o.status === 'Void') return;
            let d = null;
            if (o.timestamp?.seconds) d = new Date(o.timestamp.seconds * 1000);
            else if (o.createdAt?.seconds) d = new Date(o.createdAt.seconds * 1000);
            else if (o.date) d = o.date.includes('T') || o.date.includes(' ') ? new Date(o.date) : new Date(o.date + 'T12:00:00');
            else if (o.orderDate) d = new Date(o.orderDate);
            if (!d || isNaN(d.getTime())) return;

            const t = parseFloat(o.total) || 0;
            let c = 0;
            (o.items || []).forEach(i => {
                const p = (window.allProducts || []).find(pr => pr.docId === i.docId || pr.sku === i.sku) || i;
                c += ((parseFloat(p.cost || p.buyingPrice) || 0) * (i.quantity || 1));
            });

            const y = d.getFullYear();
            const m = d.getMonth();

            if (y === thisYr && m === thisMo) {
                thisMoRev += t;
                thisMoProfit += Math.max(0, t - c);
            }
            const prevMo = thisMo === 0 ? 11 : thisMo - 1;
            const prevYr = thisMo === 0 ? thisYr - 1 : thisYr;
            if (y === prevYr && m === prevMo) {
                lastMoRev += t;
                lastMoProfit += Math.max(0, t - c);
            }
            if (y === thisYr - 1 && m === thisMo) {
                lastYrRev += t;
                lastYrProfit += Math.max(0, t - c);
            }
        });

        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const thisMoLabel = `${monthNames[thisMo]} ${thisYr} (මේ මාසය)`;
        const prevMo = thisMo === 0 ? 11 : thisMo - 1;
        const prevYr = thisMo === 0 ? thisYr - 1 : thisYr;
        const lastMoLabel = `${monthNames[prevMo]} ${prevYr} (පසුගිය මාසය)`;
        const lastYrLabel = `${monthNames[thisMo]} ${thisYr - 1} (පසුගිය වසර)`;

        window._chartCompare = new Chart(ctxCompare, {
            type: 'bar',
            data: {
                labels: [lastYrLabel, lastMoLabel, thisMoLabel],
                datasets: [
                    {
                        label: 'Total Revenue (LKR)',
                        data: [lastYrRev.toFixed(2), lastMoRev.toFixed(2), thisMoRev.toFixed(2)],
                        backgroundColor: 'rgba(56, 189, 248, 0.85)',
                        borderColor: '#38bdf8',
                        borderWidth: 2,
                        borderRadius: 8
                    },
                    {
                        label: 'Gross Profit (LKR)',
                        data: [lastYrProfit.toFixed(2), lastMoProfit.toFixed(2), thisMoProfit.toFixed(2)],
                        backgroundColor: 'rgba(16, 185, 129, 0.85)',
                        borderColor: '#10b981',
                        borderWidth: 2,
                        borderRadius: 8
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#cbd5e1', font: { family: 'Outfit', weight: '700' } } }
                },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8', font: { weight: '700' } } },
                    y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } }
                }
            }
        });
    }

    // 3. Payment Channels Mix
    let cashSales = 0, cardSales = 0, creditSales = 0, otherSales = 0;
    (orders || []).forEach(o => {
        const m = (o.paymentMethod || o.method || "").toLowerCase();
        const tot = parseFloat(o.total) || 0;
        if (m.includes('cash')) cashSales += tot;
        else if (m.includes('card')) cardSales += tot;
        else if (m.includes('credit')) creditSales += tot;
        else otherSales += tot;
    });

    const ctxPayment = document.getElementById('rep-dash-payment-chart');
    if (ctxPayment) {
        if (window._chartPayment) window._chartPayment.destroy();
        window._chartPayment = new Chart(ctxPayment, {
            type: 'doughnut',
            data: {
                labels: ['Cash', 'Card', 'Credit Ledger', 'Web / Other'],
                datasets: [{
                    data: [cashSales || 1, cardSales, creditSales, otherSales],
                    backgroundColor: ['#10b981', '#38bdf8', '#f59e0b', '#8b5cf6'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: { position: 'right', labels: { color: '#cbd5e1', font: { family: 'Outfit', weight: '700' } } }
                }
            }
        });
    }

    // 3. Top 5 Products Bar Chart
    const prodRevenueMap = {};
    (orders || []).forEach(o => {
        (o.items || []).forEach(item => {
            const name = item.name || 'Unknown';
            if (!prodRevenueMap[name]) prodRevenueMap[name] = 0;
            prodRevenueMap[name] += ((parseFloat(item.price) || 0) * (item.quantity || 1));
        });
    });

    const sortedProds = Object.entries(prodRevenueMap).sort((a,b) => b[1] - a[1]).slice(0, 5);
    const prodLabels = sortedProds.map(p => p[0].length > 18 ? p[0].slice(0, 16) + '...' : p[0]);
    const prodData = sortedProds.map(p => p[1]);

    const ctxProds = document.getElementById('rep-dash-products-chart');
    if (ctxProds) {
        if (window._chartProds) window._chartProds.destroy();
        window._chartProds = new Chart(ctxProds, {
            type: 'bar',
            data: {
                labels: prodLabels.length ? prodLabels : ['No Sales Recorded'],
                datasets: [{
                    label: 'Gross Sales (LKR)',
                    data: prodData.length ? prodData : [0],
                    backgroundColor: ['#f59e0b', '#38bdf8', '#10b981', '#a855f7', '#ec4899'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                    y: { grid: { display: false }, ticks: { color: '#cbd5e1', font: { weight: '600' } } }
                }
            }
        });
    }

    // 5. Cost vs Margin Doughnut
    const ctxMargin = document.getElementById('rep-dash-margin-chart');
    if (ctxMargin) {
        if (window._chartMargin) window._chartMargin.destroy();
        window._chartMargin = new Chart(ctxMargin, {
            type: 'doughnut',
            data: {
                labels: ['Buying Cost (COGS)', 'Net Gross Profit'],
                datasets: [{
                    data: [shopCost || 0.01, Math.max(0, shopProfit) || 0.01],
                    backgroundColor: ['#ef4444', '#10b981'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: { position: 'right', labels: { color: '#cbd5e1', font: { family: 'Outfit', weight: '700' } } }
                }
            }
        });
    }

    // 6. 4-Channel Revenue & Profit Bar Chart (Fills 6th slot in 3x2 grid)
    const ctxChannels = document.getElementById('rep-dash-channels-chart');
    if (ctxChannels) {
        if (window._chartChannels) window._chartChannels.destroy();
        window._chartChannels = new Chart(ctxChannels, {
            type: 'bar',
            data: {
                labels: ['POS Shop', 'Reloads', 'Web Store', 'Repair Shop'],
                datasets: [
                    {
                        label: 'Revenue / Sales (LKR)',
                        data: [
                            (posSales || 0).toFixed(2), 
                            (reloadSales || 0).toFixed(2), 
                            (webSales || 0).toFixed(2), 
                            (repairSales || 0).toFixed(2)
                        ],
                        backgroundColor: '#38bdf8',
                        borderRadius: 6
                    },
                    {
                        label: 'Net Margin / Profit (LKR)',
                        data: [
                            (posProfit || 0).toFixed(2), 
                            (reloadProfit || 0).toFixed(2), 
                            (webProfit || 0).toFixed(2), 
                            (repairProfit || 0).toFixed(2)
                        ],
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { 
                        position: 'top', 
                        labels: { color: '#cbd5e1', font: { family: 'Outfit', weight: '700', size: 10 }, boxWidth: 12 } 
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ` ${context.dataset.label}: LKR ${parseFloat(context.parsed.y).toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8', font: { weight: '700', size: 10 } } },
                    y: { 
                        grid: { color: 'rgba(255,255,255,0.05)' }, 
                        ticks: { 
                            color: '#94a3b8',
                            callback: function(value) {
                                return value >= 1000 ? (value / 1000).toFixed(0) + 'k' : value;
                            }
                        } 
                    }
                }
            }
        });
    }
};

window.renderSalesReportOld = (orders) => {
    const container = document.getElementById('sales-report-content');
    if (!container) return;
    if (!orders || orders.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 2.5rem 1rem; color: #94a3b8;">
                <div style="font-size: 2.2rem; margin-bottom: 0.5rem; opacity: 0.7;">🧾</div>
                <div style="font-weight: 700; font-size: 0.95rem; color: #e2e8f0;">No Sales Records Found</div>
                <div style="font-size: 0.8rem; color: #64748b; margin-top: 0.25rem;">There are no transactions recorded for the selected date range.</div>
            </div>`;
        return;
    }
    container.innerHTML = `<table class="admin-table"><thead><tr><th>DATE</th><th>INVOICE</th><th>STATUS</th><th style="text-align:right;">TOTAL</th></tr></thead><tbody>${orders.map(o => `<tr><td>${o.date || (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleDateString() : 'N/A')}</td><td>#${o.orderId || o.id || 'N/A'}</td><td><span class="status-badge" data-status="${o.status}">${o.status || 'Completed'}</span></td><td style="text-align:right; font-weight:800;">${formatCurrency(o.total || 0)}</td></tr>`).join('')}</tbody></table>`;
};

window.renderProductReportOld = (orders) => {
    const container = document.getElementById('products-report-content');
    if (!container) return;
    const prodMap = {};
    (orders || []).forEach(o => { (o.items || []).forEach(item => { if (!prodMap[item.name]) prodMap[item.name] = { qty: 0, total: 0 }; prodMap[item.name].qty += (item.quantity || 1); prodMap[item.name].total += (item.price * (item.quantity || 1)); }); });
    const sorted = Object.entries(prodMap).sort((a,b) => b.total - a.total).slice(0, 10);
    if (!sorted || sorted.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 2.5rem 1rem; color: #94a3b8;">
                <div style="font-size: 2.2rem; margin-bottom: 0.5rem; opacity: 0.7;">📦</div>
                <div style="font-weight: 700; font-size: 0.95rem; color: #e2e8f0;">No Product Sales Found</div>
                <div style="font-size: 0.8rem; color: #64748b; margin-top: 0.25rem;">No product items were sold during the selected period.</div>
            </div>`;
        return;
    }
    container.innerHTML = `<table class="admin-table"><thead><tr><th>PRODUCT</th><th style="text-align:right;">QTY</th><th style="text-align:right;">REVENUE</th></tr></thead><tbody>${sorted.map(([n,s]) => `<tr><td>${n}</td><td style="text-align:right;">${s.qty}</td><td style="text-align:right; font-weight:800; color:#10b981;">${s.total.toFixed(2)}</td></tr>`).join('')}</tbody></table>`;
};

window.switchReportView = (view, btn) => {
    // 0. Permission Guard for Cash Balancing History
    if (view === 'cash-history') {
        if (typeof window.canAccessCashHistory === 'function' && !window.canAccessCashHistory()) {
            if (window.showToast) {
                window.showToast("🔒 Access Restricted: Cash Balancing Sheets can only be accessed by CEO, HR, and Account Managers.", "error");
            }
            return;
        }
    }

    const views = ['dashboard', 'summary', 'profit', 'ledger', 'recon', 'aging', 'forecast', 'tax', 'cash-balancing', 'cash-history'];
    
    // 1. Hide all report views
    views.forEach(v => {
        const el = document.getElementById(`report-view-${v}`);
        if (el) el.style.display = 'none';
    });

    // 2. Reset ALL report navigation buttons
    document.querySelectorAll('.pro-nav-btn').forEach(b => {
        b.classList.remove('active');
    });

    // 3. Show the selected report view
    const activeEl = document.getElementById(`report-view-${view}`) || document.getElementById('report-view-summary');
    if (activeEl) {
        activeEl.style.display = 'block';
        activeEl.classList.add('animate-fade-in');
    }

    // 4. Set the clicked button as active
    if (btn) {
        btn.classList.add('active');
    } else {
        // Fallback for direct JS calls without 'this' context
        document.querySelectorAll('.pro-nav-btn').forEach(b => {
            const onc = b.getAttribute('onclick') || "";
            if (onc.includes(`'${view}'`) || onc.includes(`"${view}"`)) {
                b.classList.add('active');
            }
        });
    }

    // 5. Run view-specific data generation
    try {
        const data = window.allOrders || [];
        if (view === 'dashboard' || view === 'summary') window.generateReportsOld(data);
        if (view === 'profit') window.renderProfitReportOld(data);
        if (view === 'ledger') window.generateDoubleEntryLedger();
        if (view === 'tax') window.renderTaxReportOld(data);
        if (view === 'aging') window.renderAgingReport();
        if (view === 'forecast') window.renderCashflowForecast();
        if (view === 'recon') window.renderBankRecon();
        if (view === 'cash-balancing') window.renderCashBalancingReport();
        if (view === 'cash-history') window.renderCashBalancingHistory();
    } catch (e) {
        console.error("Error generating report view:", e);
    }

    // Trigger automated AI analysis in background (if enabled)
    if (window.isAIAnalystEnabled !== false) {
        window.runAIReportAnalysis(view);
    }
};

window.toggleAIFinancialAnalyst = (enabled) => {
    window.isAIAnalystEnabled = enabled;
    localStorage.setItem('mecpos_ai_analyst_enabled', enabled ? 'true' : 'false');

    const aiPanel = document.getElementById('ai-report-analyst-panel');
    if (aiPanel) {
        aiPanel.style.display = enabled ? 'block' : 'none';
    }

    const copilotSwitch = document.getElementById('copilot-ai-reports-toggle');
    if (copilotSwitch) {
        copilotSwitch.checked = enabled;
    }

    const reportToggle = document.getElementById('toggle-ai-financial-analyst');
    if (reportToggle) {
        reportToggle.checked = enabled;
    }

    const label = document.getElementById('ai-analyst-status-label');
    const refreshBtn = document.getElementById('btn-refresh-ai-analyst');
    const slider = document.querySelector('#ai-report-analyst-panel .slider');

    if (label) {
        label.innerText = enabled ? 'AI ON' : 'AI OFF';
        label.style.color = enabled ? '#10b981' : '#94a3b8';
    }
    if (slider) {
        slider.style.backgroundColor = enabled ? '#10b981' : '#475569';
    }
    if (refreshBtn) {
        refreshBtn.disabled = !enabled;
        refreshBtn.style.opacity = enabled ? '1' : '0.4';
        refreshBtn.style.pointerEvents = enabled ? 'auto' : 'none';
    }

    if (!enabled) {
        window.showToast("AI Financial Analyst turned OFF & hidden from Reports.", "info");
    } else {
        window.showToast("AI Financial Analyst turned ON!", "success");
        window.runAIReportAnalysis(null, true);
    }
};

window.runAIReportAnalysis = async (view, force = false) => {
    // Check saved state
    const savedState = localStorage.getItem('mecpos_ai_analyst_enabled');
    if (savedState !== null) {
        window.isAIAnalystEnabled = savedState === 'true';
    }
    
    const toggleInput = document.getElementById('toggle-ai-financial-analyst');
    const label = document.getElementById('ai-analyst-status-label');
    const slider = document.querySelector('#ai-report-analyst-panel .slider');
    const refreshBtn = document.getElementById('btn-refresh-ai-analyst');

    if (toggleInput && savedState !== null) {
        toggleInput.checked = window.isAIAnalystEnabled;
    }
    if (label && savedState !== null) {
        label.innerText = window.isAIAnalystEnabled ? 'AI ON' : 'AI OFF';
        label.style.color = window.isAIAnalystEnabled ? '#10b981' : '#94a3b8';
    }
    if (slider && savedState !== null) {
        slider.style.backgroundColor = window.isAIAnalystEnabled ? '#10b981' : '#475569';
    }
    if (refreshBtn && savedState !== null) {
        refreshBtn.disabled = !window.isAIAnalystEnabled;
        refreshBtn.style.opacity = window.isAIAnalystEnabled ? '1' : '0.4';
        refreshBtn.style.pointerEvents = window.isAIAnalystEnabled ? 'auto' : 'none';
    }

    if (window.isAIAnalystEnabled === false && !force) {
        const content = document.getElementById('ai-report-insights-content');
        if (content) {
            content.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px; color: #64748b; font-size: 0.85rem; padding: 5px 0;">
                    <span>💤 AI Financial Analyst is currently turned OFF. Turn switch ON to generate automated audits and insights.</span>
                </div>
            `;
        }
        return;
    }

    if (view) {
        window.currentSelectedReportView = view;
    }
    const activeView = window.currentSelectedReportView || 'dashboard';
    
    const panel = document.getElementById('ai-report-analyst-panel');
    const content = document.getElementById('ai-report-insights-content');
    if (!panel || !content) return;

    panel.style.display = 'block';
    content.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px; color: #a855f7;">
            <div class="loader-report" style="width: 20px; height: 20px; border-width: 2px; border-color: #a855f7 transparent #a855f7 transparent;"></div>
            <span>🤖 AI is analyzing ${activeView.replace(/-/g, ' ').toUpperCase()} report data in the background...</span>
        </div>
    `;

    try {
        const orders = window.allOrders || [];
        const start = window.currentReportFiltersOld.start;
        const end = window.currentReportFiltersOld.end;

        // Filter orders by date range
        const filtered = orders.filter(o => {
            const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
            return d >= start && d <= end && o.status !== 'Void';
        });

        // Compute summary metrics
        let totalRevenue = 0;
        let totalCost = 0;
        let itemMap = {};
        let orderCount = filtered.length;

        filtered.forEach(o => {
            totalRevenue += parseFloat(o.netTotal || o.total || 0);
            (o.items || []).forEach(item => {
                const qty = parseFloat(item.quantity) || 0;
                let cost = parseFloat(item.costPrice) || 0;
                if (!cost && window.allProducts) {
                    const p = window.allProducts.find(prod => prod.docId === item.docId || prod.sku === item.sku);
                    if (p) cost = parseFloat(p.cost || p.buyingPrice) || 0;
                }
                totalCost += cost * qty;
                const name = item.name || 'Unknown';
                itemMap[name] = (itemMap[name] || 0) + qty;
            });
        });

        const grossProfit = totalRevenue - totalCost;
        const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

        // Get top 5 selling items
        const topItems = Object.entries(itemMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([name, qty]) => `${name} (${qty} units)`)
            .join(', ');

        const dataPrompt = `
Report View: ${activeView.toUpperCase()}
Date Range: ${start ? start.toLocaleDateString() : 'N/A'} to ${end ? end.toLocaleDateString() : 'N/A'}
Total Orders: ${orderCount}
Total Revenue: LKR ${totalRevenue.toFixed(2)}
Total Cost of Goods Sold: LKR ${totalCost.toFixed(2)}
Gross Profit: LKR ${grossProfit.toFixed(2)}
Average Profit Margin: ${profitMargin.toFixed(2)}%
Top 5 Best Selling Items: ${topItems || 'None'}
        `;

        const apiKey = "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";

        const aiLang = document.getElementById('set-ai-language')?.value || 'english';
        const langInstruction = aiLang === 'sinhala' 
            ? "You MUST write and respond ONLY in beautiful, professional Sinhala language. Use standard financial terms in Sinhala where appropriate."
            : "You MUST write and respond ONLY in professional English language.";

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    {
                        role: "system",
                        content: `You are the premium Virtual CFO and automated AI Financial Analyst for MEC POS. Analyze the provided report metrics and raw data. Highlight sales trends, profit quality, potential margins leakages, and give 3 precise, highly actionable recommendations for improvement. Respond ONLY in clean HTML elements (e.g. <p>, <ul>, <li>, <strong>, <span style='...'>) with nice color tags. Do NOT wrap your output in markdown code blocks like \`\`\`html. ${langInstruction}`
                    },
                    {
                        role: "user",
                        content: `Sales Data Summary for analysis:\n${dataPrompt}`
                    }
                ]
            })
        });

        if (!response.ok) {
            console.warn(`OpenAI API failed with status ${response.status}. Falling back to Gemini...`);
            await runGeminiReportAnalysisFallback(dataPrompt, content);
            return;
        }

        const resJson = await response.json();
        const analysis = resJson.choices[0].message.content;

        content.innerHTML = `<div class="ai-report-text animate-fade-in" style="font-family: inherit;">${analysis}</div>`;
    } catch (err) {
        console.warn("AI Report Analysis OpenAI attempt failed, trying Gemini fallback directly...", err);
        try {
            await runGeminiReportAnalysisFallback(`
Report View: ${window.currentSelectedReportView || 'summary'}
Total Orders loaded in context: ${window.allOrders?.length || 0}
            `, content);
        } catch (fallbackErr) {
            console.error("AI Report Analysis total failure:", fallbackErr);
            content.innerHTML = `
                <div style="color: #ef4444; display: flex; align-items: center; gap: 8px;">
                    <span>⚠️</span> Failed to generate AI analysis: ${fallbackErr.message}
                </div>
            `;
        }
    }
};

async function runGeminiReportAnalysisFallback(dataPrompt, content) {
    const geminiKey = "AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey}`;
    
    const aiLang = document.getElementById('set-ai-language')?.value || 'english';
    const langInstruction = aiLang === 'sinhala' 
        ? "You MUST write and respond ONLY in beautiful, professional Sinhala language. Use standard financial terms in Sinhala where appropriate."
        : "You MUST write and respond ONLY in professional English language.";

    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            contents: [{
                parts: [{
                    text: `System Instruction: You are the premium Virtual CFO and automated AI Financial Analyst for MEC POS. Analyze the provided report metrics and raw data. Highlight sales trends, profit quality, potential margins leakages, and give 3 precise, highly actionable recommendations for improvement. Respond ONLY in clean HTML elements (e.g. <p>, <ul>, <li>, <strong>, <span style='...'>) with nice color tags. Do NOT wrap your output in markdown code blocks like \`\`\`html. ${langInstruction}\n\nUser Data:\n${dataPrompt}`
                }]
            }]
        })
    });

    if (!response.ok) {
        if (response.status === 429) {
            throw new Error("⏱️ AI engine is busy (Rate Limit). Please wait 10 seconds and click 'Refresh Insights' again.");
        }
        throw new Error(`Gemini API responded with status ${response.status}`);
    }

    const resJson = await response.json();
    let analysis = resJson.candidates?.[0]?.content?.parts?.[0]?.text || "";
    
    // Clean up markdown block if model outputted it despite instructions
    analysis = analysis.replace(/```html/gi, "").replace(/```/g, "").trim();

    content.innerHTML = `<div class="ai-report-text animate-fade-in" style="font-family: inherit;">${analysis}</div>`;
}

window.currentHubActiveView = 'sales-summary';

window.initReportHubUI = () => {
    const startInput = document.getElementById('hub-start-date');
    const endInput = document.getElementById('hub-end-date');
    const now = new Date();
    if (startInput && !startInput.value) {
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        startInput.value = firstDay.toISOString().slice(0, 10);
    }
    if (endInput && !endInput.value) {
        endInput.value = now.toISOString().slice(0, 10);
    }
    window.renderCurrentHubReport();
};

window.setHubDatePreset = (preset) => {
    const startInput = document.getElementById('hub-start-date');
    const endInput = document.getElementById('hub-end-date');
    if (!startInput || !endInput) return;
    const now = new Date();
    let start = new Date();
    let end = new Date();

    const formatDateStr = (d) => {
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    };

    if (preset === 'today') {
        start = now;
        end = now;
    } else if (preset === 'this_week') {
        const day = now.getDay() || 7;
        start = new Date(now);
        start.setDate(now.getDate() - day + 1);
        end = now;
    } else if (preset === 'this_month') {
        start = new Date(now.getFullYear(), now.getMonth(), 1);
        end = now;
    } else if (preset === 'last_month') {
        start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        end = new Date(now.getFullYear(), now.getMonth(), 0);
    } else if (preset === 'last_3_months') {
        start = new Date(now.getFullYear(), now.getMonth() - 2, 1);
        end = now;
    } else if (preset === 'financial_year') {
        const currentYear = now.getFullYear();
        const currentMonth = now.getMonth(); // 0 = Jan, 3 = Apr
        if (currentMonth >= 3) {
            // Apr 1 of current year to Mar 31 of next year
            start = new Date(currentYear, 3, 1);
            end = new Date(currentYear + 1, 2, 31);
        } else {
            // Apr 1 of previous year to Mar 31 of current year
            start = new Date(currentYear - 1, 3, 1);
            end = new Date(currentYear, 2, 31);
        }
    } else if (preset === 'all') {
        start = new Date(2020, 0, 1);
        end = now;
    }

    startInput.value = formatDateStr(start);
    endInput.value = formatDateStr(end);

    // Update active highlight class on buttons
    const btns = document.querySelectorAll('.hub-preset-btn');
    btns.forEach(btn => {
        if (btn.getAttribute('data-preset') === preset) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    window.renderCurrentHubReport();
};

window.applyHubDateFilter = () => {
    window.renderCurrentHubReport();
    if (window.showToast) window.showToast("📊 Date Filter Applied", "info");
};

window.switchReportHubView = (view) => {
    window.currentHubActiveView = view;

    const allItems = document.querySelectorAll('.report-item');
    allItems.forEach(item => {
        const onclickAttr = item.getAttribute('onclick') || "";
        if (onclickAttr.includes(`'${view}'`) || onclickAttr.includes(`"${view}"`)) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    window.renderCurrentHubReport();
};

function getHubFilteredData() {
    const isAnalytics = document.getElementById('section-analytics')?.style.display !== 'none';
    const isReportsOld = document.getElementById('section-reports')?.style.display !== 'none';
    
    let startInput = null;
    let endInput = null;

    if (isAnalytics) {
        startInput = document.getElementById('report-start-date');
        endInput = document.getElementById('report-end-date');
    } else if (isReportsOld) {
        startInput = document.getElementById('report-start-date-old');
        endInput = document.getElementById('report-end-date-old');
    } else {
        startInput = document.getElementById('hub-start-date') || document.getElementById('report-start-date');
        endInput = document.getElementById('hub-end-date') || document.getElementById('report-end-date');
    }
    
    let startDate = new Date(0);
    let endDate = new Date(8640000000000000);

    if (startInput && startInput.value) {
        startDate = parseLocalStart(startInput.value) || new Date(startInput.value + 'T00:00:00');
    } else if (window.currentReportFilters?.start) {
        startDate = window.currentReportFilters.start;
    }

    if (endInput && endInput.value) {
        endDate = parseLocalEnd(endInput.value) || new Date(endInput.value + 'T23:59:59.999');
    } else if (window.currentReportFilters?.end) {
        endDate = window.currentReportFilters.end;
    }

    const entity = isAnalytics ? (document.getElementById('report-filter-entity')?.value || 'All') : 'All';
    const user = isAnalytics ? (document.getElementById('report-filter-user')?.value || 'All') : 'All';
    const category = isAnalytics ? (document.getElementById('report-filter-category')?.value || 'All') : 'All';

    const orders = (window.allOrders || []).filter(o => {
        if (o.status === 'Void' || o.isVoid === true || o.status === 'Cancelled') return false;
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        if (d < startDate || d > endDate) return false;
        if (entity !== 'All' && o.userName !== entity) return false;
        if (user !== 'All' && o.cashier !== user) return false;
        return true;
    });

    const expenses = (window.allExpenses || []).filter(e => {
        const d = e.timestamp?.seconds ? new Date(e.timestamp.seconds * 1000) : (e.date ? new Date(e.date + 'T12:00:00') : new Date(0));
        return d >= startDate && d <= endDate;
    });

    const income = (window.allIncome || []).filter(i => {
        const d = i.timestamp?.seconds ? new Date(i.timestamp.seconds * 1000) : (i.date ? new Date(i.date + 'T12:00:00') : new Date(0));
        return d >= startDate && d <= endDate;
    });

    return { startDate, endDate, orders, expenses, income, category, entity, user };
}

window.renderCurrentHubReport = () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const titleEl = document.getElementById('hub-report-title');
    const dateRangeEl = document.getElementById('hub-report-date-range');
    const contentEl = document.getElementById('hub-report-content-body');
    if (!contentEl) return;

    const startStr = startDate.toLocaleDateString();
    const endStr = endDate.toLocaleDateString();
    if (dateRangeEl) dateRangeEl.innerText = `Period: ${startStr} to ${endStr} | ${orders.length} Orders Found`;

    const view = window.currentHubActiveView || 'sales-summary';

    if (view === 'sales-summary') {
        if (titleEl) titleEl.innerText = "Sales Summary Report";
        
        const totalSales = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
        const totalItems = orders.reduce((acc, o) => acc + (o.items ? o.items.reduce((sum, i) => sum + (parseFloat(i.quantity) || 1), 0) : 0), 0);
        const avgOrder = orders.length > 0 ? totalSales / orders.length : 0;

        let cashSales = 0, cardSales = 0, bankSales = 0, onlineSales = 0;
        orders.forEach(o => {
            const pm = (o.paymentMethod || 'cash').toLowerCase();
            const tot = parseFloat(o.total) || 0;
            if (pm.includes('cash')) cashSales += tot;
            else if (pm.includes('card')) cardSales += tot;
            else if (pm.includes('bank')) bankSales += tot;
            else onlineSales += tot;
        });

        contentEl.innerHTML = `
            <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL SALES REVENUE</span>
                    <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">COMPLETED ORDERS</span>
                    <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">${orders.length}</div>
                </div>
                <div style="background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL ITEMS SOLD</span>
                    <div style="color: #c084fc; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">${totalItems}</div>
                </div>
                <div style="background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">AVG ORDER VALUE</span>
                    <div style="color: #fbbf24; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${avgOrder.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="display: flex; gap: 15px; margin-bottom: 25px; background: rgba(255,255,255,0.02); padding: 14px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); font-size: 0.85rem; flex-wrap: wrap;">
                <span style="color: #94a3b8;">Payment Methods:</span>
                <span style="color: #10b981; font-weight: 700;">💵 Cash: LKR ${cashSales.toLocaleString()}</span> |
                <span style="color: #38bdf8; font-weight: 700;">💳 Card: LKR ${cardSales.toLocaleString()}</span> |
                <span style="color: #fbbf24; font-weight: 700;">🏛️ Bank: LKR ${bankSales.toLocaleString()}</span> |
                <span style="color: #c084fc; font-weight: 700;">🌐 Online: LKR ${onlineSales.toLocaleString()}</span>
            </div>

            <div style="overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                            <th style="padding: 10px;">#</th>
                            <th style="padding: 10px;">Date & Time</th>
                            <th style="padding: 10px;">Order ID</th>
                            <th style="padding: 10px;">Customer</th>
                            <th style="padding: 10px; text-align: center;">Items</th>
                            <th style="padding: 10px;">Payment Method</th>
                            <th style="padding: 10px; text-align: right;">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${orders.map((o, idx) => {
                            const dateStr = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleString() : (o.date || '-');
                            const custName = o.customerName || o.customer?.name || 'Walk-in Customer';
                            const itemCount = o.items ? o.items.length : 0;
                            return `
                                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                    <td style="padding: 10px; color: #64748b;">${idx + 1}</td>
                                    <td style="padding: 10px; color: #cbd5e1;">${dateStr}</td>
                                    <td style="padding: 10px; font-weight: 800; color: #38bdf8;">#${o.orderId || o.docId}</td>
                                    <td style="padding: 10px; color: #f1f5f9;">${custName}</td>
                                    <td style="padding: 10px; text-align: center; color: #cbd5e1;">${itemCount}</td>
                                    <td style="padding: 10px; color: #94a3b8; text-transform: capitalize;">${o.paymentMethod || 'Cash'}</td>
                                    <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${(parseFloat(o.total) || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                </tr>
                            `;
                        }).join('') || '<tr><td colspan="7" style="text-align: center; padding: 25px; color: #64748b;">No sales records found for selected period</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    } else if (view === 'profit-margin') {
        if (titleEl) titleEl.innerText = "Profit & Margin Report";
        
        let totalRevenue = 0;
        let totalCost = 0;

        orders.forEach(o => {
            totalRevenue += parseFloat(o.total) || 0;
            if (o.items) {
                o.items.forEach(i => {
                    const c = parseFloat(i.cost || i.buyingPrice || 0);
                    const q = parseFloat(i.quantity || 1);
                    totalCost += (c * q);
                });
            }
        });

        const totalExpenses = (expenses || []).reduce((sum, e) => sum + (parseFloat(e.amount || e.cost || 0) || 0), 0);
        const grossProfit = totalRevenue - totalCost;
        const netProfit = grossProfit - totalExpenses;
        const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

        contentEl.innerHTML = `
            <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL REVENUE</span>
                    <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL COGS (COST)</span>
                    <div style="color: #ef4444; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(249, 115, 22, 0.1); border: 1px solid rgba(249, 115, 22, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL SHOP EXPENSES</span>
                    <div style="color: #f97316; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalExpenses.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">NET BUSINESS PROFIT</span>
                    <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${netProfit.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                            <th style="padding: 10px;">#</th>
                            <th style="padding: 10px;">Order ID</th>
                            <th style="padding: 10px;">Date</th>
                            <th style="padding: 10px; text-align: right;">Revenue</th>
                            <th style="padding: 10px; text-align: right;">Est Cost</th>
                            <th style="padding: 10px; text-align: right;">Gross Profit</th>
                            <th style="padding: 10px; text-align: right;">Margin %</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${orders.map((o, idx) => {
                            const dateStr = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleDateString() : (o.date || '-');
                            const rev = parseFloat(o.total) || 0;
                            let cost = 0;
                            if (o.items) {
                                o.items.forEach(i => {
                                    cost += ((parseFloat(i.cost || i.buyingPrice || 0)) * (parseFloat(i.quantity || 1)));
                                });
                            }
                            const prof = rev - cost;
                            const marg = rev > 0 ? (prof / rev) * 100 : 0;
                            return `
                                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                    <td style="padding: 10px; color: #64748b;">${idx + 1}</td>
                                    <td style="padding: 10px; font-weight: 800; color: #38bdf8;">#${o.orderId || o.docId}</td>
                                    <td style="padding: 10px; color: #cbd5e1;">${dateStr}</td>
                                    <td style="padding: 10px; text-align: right; color: #f1f5f9;">LKR ${rev.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                    <td style="padding: 10px; text-align: right; color: #ef4444;">LKR ${cost.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                    <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${prof.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                    <td style="padding: 10px; text-align: right; font-weight: 800; color: #fbbf24;">${marg.toFixed(1)}%</td>
                                </tr>
                            `;
                        }).join('') || '<tr><td colspan="7" style="text-align: center; padding: 25px; color: #64748b;">No records found</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    } else if (view === 'daily-sales') {
        if (titleEl) titleEl.innerText = "Daily Sales Breakdown";
        
        const dailyMap = {};
        orders.forEach(o => {
            const dateKey = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().slice(0, 10) : (o.date || 'Unknown');
            if (!dailyMap[dateKey]) {
                dailyMap[dateKey] = { date: dateKey, count: 0, total: 0, items: 0 };
            }
            dailyMap[dateKey].count += 1;
            dailyMap[dateKey].total += (parseFloat(o.total) || 0);
            dailyMap[dateKey].items += o.items ? o.items.reduce((s, i) => s + (parseFloat(i.quantity) || 1), 0) : 0;
        });

        const dailyList = Object.values(dailyMap).sort((a,b) => b.date.localeCompare(a.date));
        const totalSales = dailyList.reduce((acc, d) => acc + d.total, 0);
        const avgDaily = dailyList.length > 0 ? totalSales / dailyList.length : 0;

        contentEl.innerHTML = `
            <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL PERIOD REVENUE</span>
                    <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">ACTIVE DAYS</span>
                    <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">${dailyList.length} Days</div>
                </div>
                <div style="background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">DAILY AVERAGE</span>
                    <div style="color: #fbbf24; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${avgDaily.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                            <th style="padding: 10px;">Date</th>
                            <th style="padding: 10px; text-align: center;">Orders Count</th>
                            <th style="padding: 10px; text-align: center;">Items Sold</th>
                            <th style="padding: 10px; text-align: right;">Total Sales (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${dailyList.map(d => `
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                <td style="padding: 10px; font-weight: 800; color: #38bdf8;">${d.date}</td>
                                <td style="padding: 10px; text-align: center; color: #f1f5f9;">${d.count}</td>
                                <td style="padding: 10px; text-align: center; color: #cbd5e1;">${d.items}</td>
                                <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">LKR ${d.total.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                            </tr>
                        `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 25px; color: #64748b;">No daily records found</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    } else if (view === 'ledger-export') {
        if (titleEl) titleEl.innerText = "General Ledger Export";
        
        let ledgerEntries = [];
        orders.forEach(o => {
            const date = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
            const tot = parseFloat(o.total) || 0;
            ledgerEntries.push({ date, desc: `Sales Revenue (Order #${o.orderId || o.docId})`, dr: 0, cr: tot });
        });

        expenses.forEach(e => {
            const date = e.timestamp?.seconds ? new Date(e.timestamp.seconds * 1000) : (e.date ? new Date(e.date + 'T12:00:00') : new Date(0));
            const amt = parseFloat(e.amount) || 0;
            ledgerEntries.push({ date, desc: `Expense: ${e.category || e.title || 'General Expense'}`, dr: amt, cr: 0 });
        });

        income.forEach(inc => {
            const date = inc.timestamp?.seconds ? new Date(inc.timestamp.seconds * 1000) : (inc.date ? new Date(inc.date + 'T12:00:00') : new Date(0));
            const amt = parseFloat(inc.amount) || 0;
            ledgerEntries.push({ date, desc: `Extra Income: ${inc.title || inc.category || 'Revenue'}`, dr: 0, cr: amt });
        });

        ledgerEntries.sort((a,b) => b.date - a.date);

        const totalCr = ledgerEntries.reduce((acc, e) => acc + e.cr, 0);
        const totalDr = ledgerEntries.reduce((acc, e) => acc + e.dr, 0);
        const netBal = totalCr - totalDr;

        contentEl.innerHTML = `
            <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL INFLOW (CREDITS)</span>
                    <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalCr.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">TOTAL OUTFLOW (DEBITS)</span>
                    <div style="color: #ef4444; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${totalDr.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">NET LEDGER BALANCE</span>
                    <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${netBal.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                            <th style="padding: 10px;">Date</th>
                            <th style="padding: 10px;">Description</th>
                            <th style="padding: 10px; text-align: right;">Debit (Dr)</th>
                            <th style="padding: 10px; text-align: right;">Credit (Cr)</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${ledgerEntries.map(e => `
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                <td style="padding: 10px; color: #cbd5e1;">${e.date.toLocaleDateString()}</td>
                                <td style="padding: 10px; color: #f1f5f9;">${e.desc}</td>
                                <td style="padding: 10px; text-align: right; color: #ef4444;">${e.dr > 0 ? `LKR ${e.dr.toLocaleString(undefined, {minimumFractionDigits: 2})}` : '-'}</td>
                                <td style="padding: 10px; text-align: right; color: #10b981; font-weight: 700;">${e.cr > 0 ? `LKR ${e.cr.toLocaleString(undefined, {minimumFractionDigits: 2})}` : '-'}</td>
                            </tr>
                        `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 25px; color: #64748b;">No ledger transactions found</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    } else if (view === 'tax-report') {
        if (titleEl) titleEl.innerText = "Tax Liability Report";
        
        const grossRevenue = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
        const vatRate = 0.18; // 18% VAT
        const vatAmount = grossRevenue * (vatRate / (1 + vatRate));
        const netRevenue = grossRevenue - vatAmount;

        contentEl.innerHTML = `
            <div class="stats-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 25px;">
                <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">GROSS REVENUE (TAX INCL)</span>
                    <div style="color: #38bdf8; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">VAT LIABILITY (18%)</span>
                    <div style="color: #ef4444; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); padding: 16px; border-radius: 14px;">
                    <span style="color: #94a3b8; font-size: 0.78rem; font-weight: 700;">NET REVENUE (EXCL TAX)</span>
                    <div style="color: #10b981; font-size: 1.5rem; font-weight: 900; margin-top: 4px;">LKR ${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.05); color: #94a3b8; text-align: left;">
                            <th style="padding: 10px;">Description</th>
                            <th style="padding: 10px; text-align: right;">Base Amount (LKR)</th>
                            <th style="padding: 10px; text-align: right;">Tax Rate</th>
                            <th style="padding: 10px; text-align: right;">VAT Amount (LKR)</th>
                            <th style="padding: 10px; text-align: right;">Gross Total (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px; font-weight: 800; color: #f1f5f9;">Standard Rated Sales (VAT 18%)</td>
                            <td style="padding: 10px; text-align: right; color: #cbd5e1;">${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                            <td style="padding: 10px; text-align: right; color: #fbbf24;">18%</td>
                            <td style="padding: 10px; text-align: right; color: #ef4444; font-weight: 800;">${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                            <td style="padding: 10px; text-align: right; font-weight: 900; color: #10b981;">${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `;
    }
};

function generateCleanPDFHTML(view, orders, expenses, income, startDate, endDate) {
    const storeName = window.STORE_CONFIG?.name || (window.systemConfig?.invPhone ? "MEC POS Store" : "MEC Book Shop & Communication");
    const storeAddress = window.STORE_CONFIG?.address || "No-97, Victoria estate, Panadura road, Munagama, Horana";
    const storePhone = window.STORE_CONFIG?.phone || "071 923 3388";
    
    const startStr = (startDate instanceof Date && !isNaN(startDate.getTime()) && startDate.getTime() > 0)
        ? startDate.toLocaleDateString()
        : 'All Time';
    const endStr = (endDate instanceof Date && !isNaN(endDate.getTime()) && endDate.getFullYear() < 9000)
        ? endDate.toLocaleDateString()
        : 'Present';

    let reportTitle = "Sales Summary Report";
    if (view === 'profit-margin') reportTitle = "Sales / Profit & Margin Analysis";
    else if (view === 'products') reportTitle = "Products Performance Report";
    else if (view === 'customers') reportTitle = "Customer Purchasing Analytics";
    else if (view === 'users') reportTitle = "Staff / Cashier Performance";
    else if (view === 'daily-sales') reportTitle = "Daily Sales Breakdown";
    else if (view === 'hourly-sales') reportTitle = "Hourly Sales Heatmap";
    else if (view === 'refunds') reportTitle = "Returns & Refunds Report";
    else if (view === 'tax-rates' || view === 'tax-report') reportTitle = "Tax Liability Report";
    else if (view === 'stock-movement') reportTitle = "Stock Movement Analytics";
    else if (view === 'low-stock') reportTitle = "Low Stock Warning Report";
    else if (view === 'suppliers') reportTitle = "Supplier Analytics Report";
    else if (view === 'ledger-export') reportTitle = "General Ledger Audit Report";

    let bodyHTML = "";

    if (view === 'sales-summary') {
        const totalSales = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
        const totalItems = orders.reduce((acc, o) => acc + (o.items ? o.items.reduce((sum, i) => sum + (parseFloat(i.quantity) || 1), 0) : 0), 0);
        const avgOrder = orders.length > 0 ? totalSales / orders.length : 0;

        let cashSales = 0, cardSales = 0, bankSales = 0, onlineSales = 0;
        orders.forEach(o => {
            const pm = (o.paymentMethod || 'cash').toLowerCase();
            const tot = parseFloat(o.total) || 0;
            if (pm.includes('cash')) cashSales += tot;
            else if (pm.includes('card')) cardSales += tot;
            else if (pm.includes('bank')) bankSales += tot;
            else onlineSales += tot;
        });

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Revenue</div>
                    <div style="color: #15803d; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                </div>
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Orders Count</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${orders.length}</div>
                </div>
                <div style="background: #faf5ff; border: 1px solid #e9d5ff; padding: 12px; border-radius: 8px;">
                    <div style="color: #6b21a8; font-size: 10px; font-weight: 700; text-transform: uppercase;">Items Sold</div>
                    <div style="color: #7e22ce; font-size: 15px; font-weight: 900; margin-top: 2px;">${totalItems}</div>
                </div>
                <div style="background: #fffbeb; border: 1px solid #fef3c7; padding: 12px; border-radius: 8px;">
                    <div style="color: #92400e; font-size: 10px; font-weight: 700; text-transform: uppercase;">Avg Order Value</div>
                    <div style="color: #b45309; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${avgOrder.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                </div>
            </div>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; border-radius: 6px; font-size: 11px; margin-bottom: 20px; color: #334155;">
                <strong>Payment Methods:</strong> Cash: LKR ${cashSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Card: LKR ${cardSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Bank: LKR ${bankSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Online: LKR ${onlineSales.toLocaleString(undefined, {minimumFractionDigits: 2})}
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Date & Time</th>
                        <th style="padding: 8px; text-align: left;">Order ID</th>
                        <th style="padding: 8px; text-align: left;">Customer</th>
                        <th style="padding: 8px; text-align: center;">Items</th>
                        <th style="padding: 8px; text-align: left;">Payment</th>
                        <th style="padding: 8px; text-align: right;">Total (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${orders.map((o, idx) => {
                        const dateStr = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleString() : (o.date || '-');
                        const custName = o.customerName || o.customer?.name || 'Walk-in Customer';
                        const itemCount = o.items ? o.items.length : 0;
                        return `
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                                <td style="padding: 6px 8px;">${dateStr}</td>
                                <td style="padding: 6px 8px; font-weight: 700; color: #0284c7;">#${o.orderId || o.docId}</td>
                                <td style="padding: 6px 8px;">${custName}</td>
                                <td style="padding: 6px 8px; text-align: center;">${itemCount}</td>
                                <td style="padding: 6px 8px; text-transform: capitalize;">${o.paymentMethod || 'Cash'}</td>
                                <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">${(parseFloat(o.total) || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                            </tr>
                        `;
                    }).join('') || '<tr><td colspan="7" style="text-align: center; padding: 20px; color: #64748b;">No orders found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'profit-margin') {
        const itemsMap = {};
        let totalRevenue = 0;
        let totalCost = 0;

        orders.forEach(o => {
            (o.items || []).forEach(i => {
                if (window.currentReportFilters?.category && window.currentReportFilters.category !== 'All') {
                    const product = (window.allProducts || []).find(p => p.name === i.name);
                    if (!product || product.category !== window.currentReportFilters.category) return;
                }
                const name = i.name || i.productName || 'Unknown Product';
                const qty = parseFloat(i.quantity || 1);
                const price = parseFloat(i.price || 0);
                const costPrice = parseFloat(i.costPrice || i.buyingPrice || i.cost || 0);
                
                const itemRev = price * qty;
                const itemCost = costPrice * qty;

                if (!itemsMap[name]) {
                    itemsMap[name] = { qty: 0, revenue: 0, cost: 0 };
                }
                itemsMap[name].qty += qty;
                itemsMap[name].revenue += itemRev;
                itemsMap[name].cost += itemCost;

                totalRevenue += itemRev;
                totalCost += itemCost;
            });
        });

        const grossProfit = totalRevenue - totalCost;
        const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

        const sortedItems = Object.entries(itemsMap).sort((a, b) => b[1].revenue - a[1].revenue);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Revenue</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Buying Cost</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Net Gross Profit</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${grossProfit.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #fffbeb; border: 1px solid #fef3c7; padding: 12px; border-radius: 8px;">
                    <div style="color: #92400e; font-size: 10px; font-weight: 700; text-transform: uppercase;">Overall Margin %</div>
                    <div style="color: #d97706; font-size: 15px; font-weight: 900; margin-top: 2px;">${profitMargin.toFixed(1)}%</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Product / Item Name</th>
                        <th style="padding: 8px; text-align: center;">Qty Sold</th>
                        <th style="padding: 8px; text-align: right;">Total Revenue</th>
                        <th style="padding: 8px; text-align: right;">Total Cost</th>
                        <th style="padding: 8px; text-align: right;">Gross Profit</th>
                        <th style="padding: 8px; text-align: right;">Margin %</th>
                    </tr>
                </thead>
                <tbody>
                    ${sortedItems.map(([name, data], idx) => {
                        const prof = data.revenue - data.cost;
                        const marg = data.revenue > 0 ? (prof / data.revenue) * 100 : 0;
                        return `
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                                <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${name}</td>
                                <td style="padding: 6px 8px; text-align: center; color: #475569;">${data.qty}</td>
                                <td style="padding: 6px 8px; text-align: right;">LKR ${data.revenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 6px 8px; text-align: right; color: #dc2626;">LKR ${data.cost.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">LKR ${prof.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 6px 8px; text-align: right; font-weight: 700; color: #d97706;">${marg.toFixed(1)}%</td>
                            </tr>
                        `;
                    }).join('') || '<tr><td colspan="7" style="text-align: center; padding: 20px; color: #64748b;">No product sales recorded for selected period</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'products') {
        const prodMap = {};
        orders.forEach(o => { 
            (o.items || []).forEach(item => { 
                if (!prodMap[item.name]) prodMap[item.name] = { qty: 0, total: 0 }; 
                const qty = parseFloat(item.quantity || 1);
                prodMap[item.name].qty += qty; 
                prodMap[item.name].total += ((parseFloat(item.price) || 0) * qty); 
            }); 
        });
        const sorted = Object.entries(prodMap).sort((a,b) => b[1].total - a[1].total);
        const totalUnits = sorted.reduce((acc, s) => acc + s[1].qty, 0);
        const totalSales = sorted.reduce((acc, s) => acc + s[1].total, 0);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Products Sold</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${sorted.length} Products</div>
                </div>
                <div style="background: #faf5ff; border: 1px solid #e9d5ff; padding: 12px; border-radius: 8px;">
                    <div style="color: #6b21a8; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Units Sold</div>
                    <div style="color: #7e22ce; font-size: 15px; font-weight: 900; margin-top: 2px;">${totalUnits} Units</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Product Revenue</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Product Name</th>
                        <th style="padding: 8px; text-align: center;">Units Sold</th>
                        <th style="padding: 8px; text-align: right;">Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${sorted.map(([n, s], idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${n}</td>
                            <td style="padding: 6px 8px; text-align: center; color: #475569;">${s.qty}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No product performance data found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'customers') {
        const custMap = {};
        orders.forEach(o => {
            const name = o.customerName || o.customer?.name || 'Walk-in Customer';
            if (!custMap[name]) custMap[name] = { count: 0, total: 0 };
            custMap[name].count += 1;
            custMap[name].total += (parseFloat(o.total) || 0);
        });
        const sorted = Object.entries(custMap).sort((a,b) => b[1].total - a[1].total);
        const totalSpent = sorted.reduce((acc, s) => acc + s[1].total, 0);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Active Customers</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${sorted.length}</div>
                </div>
                <div style="background: #faf5ff; border: 1px solid #e9d5ff; padding: 12px; border-radius: 8px;">
                    <div style="color: #6b21a8; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Orders</div>
                    <div style="color: #7e22ce; font-size: 15px; font-weight: 900; margin-top: 2px;">${orders.length}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Spent</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalSpent.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Customer Name</th>
                        <th style="padding: 8px; text-align: center;">Orders Count</th>
                        <th style="padding: 8px; text-align: right;">Total Spent (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${sorted.map(([n, s], idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${n}</td>
                            <td style="padding: 6px 8px; text-align: center; color: #475569;">${s.count}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No customer data found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'users') {
        const userMap = {};
        orders.forEach(o => {
            const user = o.cashier || o.userName || 'System POS';
            if (!userMap[user]) userMap[user] = { count: 0, total: 0 };
            userMap[user].count += 1;
            userMap[user].total += (parseFloat(o.total) || 0);
        });
        const sorted = Object.entries(userMap).sort((a,b) => b[1].total - a[1].total);
        const totalBilled = sorted.reduce((acc, s) => acc + s[1].total, 0);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Active Staff / Cashiers</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${sorted.length}</div>
                </div>
                <div style="background: #faf5ff; border: 1px solid #e9d5ff; padding: 12px; border-radius: 8px;">
                    <div style="color: #6b21a8; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Orders Processed</div>
                    <div style="color: #7e22ce; font-size: 15px; font-weight: 900; margin-top: 2px;">${orders.length}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Billed</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalBilled.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Staff / Cashier</th>
                        <th style="padding: 8px; text-align: center;">Processed Orders</th>
                        <th style="padding: 8px; text-align: right;">Total Billed (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${sorted.map(([u, s], idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${u}</td>
                            <td style="padding: 6px 8px; text-align: center; color: #475569;">${s.count}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">LKR ${(s.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No staff cashier data found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'daily-sales') {
        const dailyMap = {};
        orders.forEach(o => {
            const dateKey = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().slice(0, 10) : (o.date || 'Unknown');
            if (!dailyMap[dateKey]) dailyMap[dateKey] = { date: dateKey, count: 0, total: 0, items: 0 };
            dailyMap[dateKey].count += 1;
            dailyMap[dateKey].total += (parseFloat(o.total) || 0);
            dailyMap[dateKey].items += o.items ? o.items.reduce((s, i) => s + (parseFloat(i.quantity) || 1), 0) : 0;
        });

        const dailyList = Object.values(dailyMap).sort((a,b) => b.date.localeCompare(a.date));
        const totalSales = dailyList.reduce((acc, d) => acc + d.total, 0);
        const avgDaily = dailyList.length > 0 ? totalSales / dailyList.length : 0;

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Period Revenue</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Active Sales Days</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">${dailyList.length} Days</div>
                </div>
                <div style="background: #fffbeb; border: 1px solid #fef3c7; padding: 12px; border-radius: 8px;">
                    <div style="color: #92400e; font-size: 10px; font-weight: 700; text-transform: uppercase;">Daily Average Sales</div>
                    <div style="color: #d97706; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${avgDaily.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Date</th>
                        <th style="padding: 8px; text-align: center;">Orders Count</th>
                        <th style="padding: 8px; text-align: center;">Items Sold</th>
                        <th style="padding: 8px; text-align: right;">Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${dailyList.map((d, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0284c7;">${d.date}</td>
                            <td style="padding: 6px 8px; text-align: center;">${d.count}</td>
                            <td style="padding: 6px 8px; text-align: center;">${d.items}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #16a34a;">LKR ${d.total.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="5" style="text-align: center; padding: 20px; color: #64748b;">No daily records found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'hourly-sales') {
        const hourly = Array(24).fill(0).map(() => ({ count: 0, total: 0 }));
        orders.forEach(o => {
            const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : null;
            if (d) {
                const h = d.getHours();
                hourly[h].count++;
                hourly[h].total += (parseFloat(o.total) || 0);
            }
        });
        const totalSales = hourly.reduce((acc, h) => acc + h.total, 0);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Tracked Orders</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${orders.length}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Revenue</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left;">Hour Slot</th>
                        <th style="padding: 8px; text-align: center;">Orders Count</th>
                        <th style="padding: 8px; text-align: right;">Total Sales (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${hourly.map((h, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; font-weight: 700; color: #0284c7;">${String(idx).padStart(2, '0')}:00 - ${String(idx).padStart(2, '0')}:59</td>
                            <td style="padding: 6px 8px; text-align: center;">${h.count}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: ${h.total > 0 ? '#16a34a' : '#64748b'};">LKR ${(h.total).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } else if (view === 'refunds') {
        const voids = (window.allOrders || []).filter(o => {
            if (o.status !== 'Void' && o.isVoid !== true) return false;
            const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
            return d >= startDate && d <= endDate;
        });
        const totalVoidAmount = voids.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Voided Orders</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">${voids.length}</div>
                </div>
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Voided Value</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalVoidAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Order ID</th>
                        <th style="padding: 8px; text-align: left;">Date & Time</th>
                        <th style="padding: 8px; text-align: right;">Voided Amount (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    ${voids.map((o, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #dc2626;">#${o.orderId || o.docId}</td>
                            <td style="padding: 6px 8px;">${o.date || '-'}</td>
                            <td style="padding: 6px 8px; text-align: right; font-weight: 800; color: #dc2626;">LKR ${(parseFloat(o.total) || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #16a34a;">🎉 No voided or refunded transactions recorded for selected period</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'tax-rates' || view === 'tax-report') {
        const grossRevenue = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
        const vatRate = 0.18;
        const vatAmount = grossRevenue * (vatRate / (1 + vatRate));
        const netRevenue = grossRevenue - vatAmount;

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Gross Revenue (Tax Incl)</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">VAT Liability (18%)</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Net Revenue (Excl Tax)</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left;">Description</th>
                        <th style="padding: 8px; text-align: right;">Base Amount (LKR)</th>
                        <th style="padding: 8px; text-align: right;">Tax Rate</th>
                        <th style="padding: 8px; text-align: right;">VAT Amount (LKR)</th>
                        <th style="padding: 8px; text-align: right;">Gross Total (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #e2e8f0;">
                        <td style="padding: 8px; font-weight: 700;">Standard Rated Sales (VAT 18%)</td>
                        <td style="padding: 8px; text-align: right;">${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 8px; text-align: right; color: #d97706; font-weight: 700;">18%</td>
                        <td style="padding: 8px; text-align: right; color: #dc2626; font-weight: 800;">${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 8px; text-align: right; font-weight: 900; color: #16a34a;">${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                </tbody>
            </table>
        `;
    } else if (view === 'stock-movement') {
        const prods = window.allProducts || [];
        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Products Tracked</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${prods.length}</div>
                </div>
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">In Stock</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">${prods.filter(p => (parseFloat(p.stock) || 0) > 5).length}</div>
                </div>
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Low Stock Warning</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">${prods.filter(p => p.mode !== 'Service' && (parseFloat(p.stock) || 0) <= 5).length}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Product Name</th>
                        <th style="padding: 8px; text-align: left;">Category</th>
                        <th style="padding: 8px; text-align: center;">Current Stock</th>
                    </tr>
                </thead>
                <tbody>
                    ${prods.map((p, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${p.name}</td>
                            <td style="padding: 6px 8px; color: #475569;">${p.category || 'General'}</td>
                            <td style="padding: 6px 8px; text-align: center; font-weight: 800; color: ${(p.stock || 0) < 10 ? '#dc2626' : '#16a34a'};">${p.stock ?? 'INF'}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No products found</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'low-stock') {
        const lowProds = (window.allProducts || []).filter(p => p.mode !== 'Service' && (parseFloat(p.stock) || 0) <= 5);
        bodyHTML = `
            <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
                <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Low Stock Warning Items</div>
                <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">${lowProds.length} Products Need Replenishment</div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Product Name</th>
                        <th style="padding: 8px; text-align: left;">Category</th>
                        <th style="padding: 8px; text-align: center;">Stock Remaining</th>
                    </tr>
                </thead>
                <tbody>
                    ${lowProds.map((p, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${p.name}</td>
                            <td style="padding: 6px 8px; color: #475569;">${p.category || 'General'}</td>
                            <td style="padding: 6px 8px; text-align: center; font-weight: 900; color: #dc2626;">${p.stock ?? 0}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #16a34a;">🎉 All product stocks are healthy!</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'suppliers') {
        const suppliers = window.allSuppliers || [];
        bodyHTML = `
            <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px; margin-bottom: 20px;">
                <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Registered Suppliers</div>
                <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">${suppliers.length} Suppliers</div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left; width: 30px;">#</th>
                        <th style="padding: 8px; text-align: left;">Supplier Name</th>
                        <th style="padding: 8px; text-align: left;">Phone / Contact</th>
                        <th style="padding: 8px; text-align: left;">Email / Address</th>
                    </tr>
                </thead>
                <tbody>
                    ${suppliers.map((s, idx) => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px; color: #64748b;">${idx + 1}</td>
                            <td style="padding: 6px 8px; font-weight: 700; color: #0f172a;">${s.name || s.supplierName || 'Unknown'}</td>
                            <td style="padding: 6px 8px;">${s.phone || s.contact || '-'}</td>
                            <td style="padding: 6px 8px; color: #475569;">${s.email || s.address || '-'}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No suppliers registered</td></tr>'}
                </tbody>
            </table>
        `;
    } else if (view === 'ledger-export') {
        let ledgerEntries = [];
        orders.forEach(o => {
            const date = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
            const tot = parseFloat(o.total) || 0;
            ledgerEntries.push({ date, desc: `Sales Revenue (Order #${o.orderId || o.docId})`, dr: 0, cr: tot });
        });
        expenses.forEach(e => {
            const date = e.timestamp?.seconds ? new Date(e.timestamp.seconds * 1000) : (e.date ? new Date(e.date + 'T12:00:00') : new Date(0));
            const amt = parseFloat(e.amount) || 0;
            ledgerEntries.push({ date, desc: `Expense: ${e.category || e.title || 'General Expense'}`, dr: amt, cr: 0 });
        });
        income.forEach(inc => {
            const date = inc.timestamp?.seconds ? new Date(inc.timestamp.seconds * 1000) : (inc.date ? new Date(inc.date + 'T12:00:00') : new Date(0));
            const amt = parseFloat(inc.amount) || 0;
            ledgerEntries.push({ date, desc: `Extra Income: ${inc.title || inc.category || 'Revenue'}`, dr: 0, cr: amt });
        });

        ledgerEntries.sort((a,b) => b.date - a.date);

        const totalCr = ledgerEntries.reduce((acc, e) => acc + e.cr, 0);
        const totalDr = ledgerEntries.reduce((acc, e) => acc + e.dr, 0);
        const netBal = totalCr - totalDr;

        bodyHTML = `
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 8px;">
                    <div style="color: #166534; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Credits (Inflow)</div>
                    <div style="color: #16a34a; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalCr.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 8px;">
                    <div style="color: #991b1b; font-size: 10px; font-weight: 700; text-transform: uppercase;">Total Debits (Outflow)</div>
                    <div style="color: #dc2626; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${totalDr.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
                <div style="background: #f0f9ff; border: 1px solid #bae6fd; padding: 12px; border-radius: 8px;">
                    <div style="color: #075985; font-size: 10px; font-weight: 700; text-transform: uppercase;">Net Ledger Balance</div>
                    <div style="color: #0369a1; font-size: 15px; font-weight: 900; margin-top: 2px;">LKR ${netBal.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #0f172a;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1;">
                        <th style="padding: 8px; text-align: left;">Date</th>
                        <th style="padding: 8px; text-align: left;">Description</th>
                        <th style="padding: 8px; text-align: right;">Debit (Dr)</th>
                        <th style="padding: 8px; text-align: right;">Credit (Cr)</th>
                    </tr>
                </thead>
                <tbody>
                    ${ledgerEntries.map(e => `
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 6px 8px;">${e.date.toLocaleDateString()}</td>
                            <td style="padding: 6px 8px;">${e.desc}</td>
                            <td style="padding: 6px 8px; text-align: right; color: #dc2626;">${e.dr > 0 ? `LKR ${e.dr.toLocaleString(undefined, {minimumFractionDigits: 2})}` : '-'}</td>
                            <td style="padding: 6px 8px; text-align: right; color: #16a34a; font-weight: 700;">${e.cr > 0 ? `LKR ${e.cr.toLocaleString(undefined, {minimumFractionDigits: 2})}` : '-'}</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" style="text-align: center; padding: 20px; color: #64748b;">No transactions found</td></tr>'}
                </tbody>
            </table>
        `;
    }

    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>${reportTitle}</title>
            <meta charset="utf-8">
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', Arial, sans-serif; background: #ffffff; color: #0f172a; margin: 0; padding: 20px; }
                @media print {
                    body { -webkit-print-color-adjust: exact; margin: 0; padding: 15px; }
                }
            </style>
        </head>
        <body>
            <div style="max-width: 850px; margin: 0 auto; background: #ffffff;">
                <div style="display: flex; justify-content: space-between; border-bottom: 3px solid #0284c7; padding-bottom: 12px; margin-bottom: 20px;">
                    <div>
                        <h1 style="margin: 0; color: #0284c7; font-size: 20px; font-weight: 900; text-transform: uppercase;">${storeName}</h1>
                        <p style="margin: 3px 0 0; color: #64748b; font-size: 11px;">${storeAddress} | Tel: ${storePhone}</p>
                    </div>
                    <div style="text-align: right;">
                        <h2 style="margin: 0; color: #0f172a; font-size: 16px; font-weight: 800;">${reportTitle}</h2>
                        <p style="margin: 3px 0 0; color: #0284c7; font-size: 11px; font-weight: 700;">Period: ${startStr} to ${endStr}</p>
                        <p style="margin: 2px 0 0; color: #94a3b8; font-size: 10px;">Generated: ${new Date().toLocaleString()}</p>
                    </div>
                </div>

                ${bodyHTML}

                <div style="margin-top: 40px; border-top: 1px solid #cbd5e1; padding-top: 15px; display: flex; justify-content: space-between; font-size: 10px; color: #64748b;">
                    <div>Report Generated by MEC ERP Autopilot</div>
                    <div>Authorized Signature: ___________________________</div>
                </div>
            </div>
        </body>
        </html>
    `;
}

function generateCSVData(view, orders, expenses, income, startDate, endDate) {
    let csvRows = [];
    const sanitize = (val) => `"${String(val ?? '').replace(/"/g, '""')}"`;

    if (view === 'sales-summary') {
        csvRows.push(["#", "Date & Time", "Order ID", "Customer", "Items Count", "Payment Method", "Total Amount (LKR)"]);
        orders.forEach((o, idx) => {
            const dateStr = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleString() : (o.date || '-');
            const custName = o.customerName || o.customer?.name || 'Walk-in Customer';
            const itemCount = o.items ? o.items.length : 0;
            const total = parseFloat(o.total) || 0;
            csvRows.push([idx + 1, sanitize(dateStr), sanitize(o.orderId || o.docId), sanitize(custName), itemCount, sanitize(o.paymentMethod || 'Cash'), total]);
        });
    } else if (view === 'profit-margin') {
        csvRows.push(["#", "Product / Item Name", "Qty Sold", "Revenue (LKR)", "Cost (LKR)", "Gross Profit (LKR)", "Margin %"]);
        const itemsMap = {};
        orders.forEach(o => {
            (o.items || []).forEach(i => {
                if (window.currentReportFilters?.category && window.currentReportFilters.category !== 'All') {
                    const product = (window.allProducts || []).find(p => p.name === i.name);
                    if (!product || product.category !== window.currentReportFilters.category) return;
                }
                const name = i.name || i.productName || 'Unknown Product';
                const qty = parseFloat(i.quantity || 1);
                const price = parseFloat(i.price || 0);
                const costPrice = parseFloat(i.costPrice || i.buyingPrice || i.cost || 0);
                
                if (!itemsMap[name]) itemsMap[name] = { qty: 0, revenue: 0, cost: 0 };
                itemsMap[name].qty += qty;
                itemsMap[name].revenue += (price * qty);
                itemsMap[name].cost += (costPrice * qty);
            });
        });
        const sortedItems = Object.entries(itemsMap).sort((a, b) => b[1].revenue - a[1].revenue);
        sortedItems.forEach(([name, data], idx) => {
            const prof = data.revenue - data.cost;
            const marg = data.revenue > 0 ? (prof / data.revenue) * 100 : 0;
            csvRows.push([idx + 1, sanitize(name), data.qty, data.revenue.toFixed(2), data.cost.toFixed(2), prof.toFixed(2), `${marg.toFixed(1)}%`]);
        });
    } else if (view === 'products') {
        csvRows.push(["#", "Product Name", "Units Sold", "Total Sales (LKR)"]);
        const prodMap = {};
        orders.forEach(o => { 
            (o.items || []).forEach(item => { 
                if (!prodMap[item.name]) prodMap[item.name] = { qty: 0, total: 0 }; 
                const qty = parseFloat(item.quantity || 1);
                prodMap[item.name].qty += qty; 
                prodMap[item.name].total += ((parseFloat(item.price) || 0) * qty); 
            }); 
        });
        const sorted = Object.entries(prodMap).sort((a,b) => b[1].total - a[1].total);
        sorted.forEach(([n, s], idx) => {
            csvRows.push([idx + 1, sanitize(n), s.qty, s.total.toFixed(2)]);
        });
    } else if (view === 'customers') {
        csvRows.push(["#", "Customer Name", "Orders Count", "Total Spent (LKR)"]);
        const custMap = {};
        orders.forEach(o => {
            const name = o.customerName || o.customer?.name || 'Walk-in Customer';
            if (!custMap[name]) custMap[name] = { count: 0, total: 0 };
            custMap[name].count += 1;
            custMap[name].total += (parseFloat(o.total) || 0);
        });
        const sorted = Object.entries(custMap).sort((a,b) => b[1].total - a[1].total);
        sorted.forEach(([n, s], idx) => {
            csvRows.push([idx + 1, sanitize(n), s.count, s.total.toFixed(2)]);
        });
    } else if (view === 'users') {
        csvRows.push(["#", "Staff / Cashier", "Processed Orders", "Total Billed (LKR)"]);
        const userMap = {};
        orders.forEach(o => {
            const user = o.cashier || o.userName || 'System POS';
            if (!userMap[user]) userMap[user] = { count: 0, total: 0 };
            userMap[user].count += 1;
            userMap[user].total += (parseFloat(o.total) || 0);
        });
        const sorted = Object.entries(userMap).sort((a,b) => b[1].total - a[1].total);
        sorted.forEach(([u, s], idx) => {
            csvRows.push([idx + 1, sanitize(u), s.count, s.total.toFixed(2)]);
        });
    } else if (view === 'daily-sales') {
        csvRows.push(["#", "Date", "Orders Count", "Items Sold", "Total Revenue (LKR)"]);
        const dailyMap = {};
        orders.forEach(o => {
            const dateKey = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().slice(0, 10) : (o.date || 'Unknown');
            if (!dailyMap[dateKey]) dailyMap[dateKey] = { date: dateKey, count: 0, total: 0, items: 0 };
            dailyMap[dateKey].count += 1;
            dailyMap[dateKey].total += (parseFloat(o.total) || 0);
            dailyMap[dateKey].items += o.items ? o.items.reduce((s, i) => s + (parseFloat(i.quantity) || 1), 0) : 0;
        });
        Object.values(dailyMap).sort((a,b) => b.date.localeCompare(a.date)).forEach((d, idx) => {
            csvRows.push([idx + 1, sanitize(d.date), d.count, d.items, d.total.toFixed(2)]);
        });
    } else if (view === 'hourly-sales') {
        csvRows.push(["Hour Slot", "Orders Count", "Total Sales (LKR)"]);
        const hourly = Array(24).fill(0).map(() => ({ count: 0, total: 0 }));
        orders.forEach(o => {
            const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : null;
            if (d) {
                const h = d.getHours();
                hourly[h].count++;
                hourly[h].total += (parseFloat(o.total) || 0);
            }
        });
        hourly.forEach((h, idx) => {
            csvRows.push([sanitize(`${String(idx).padStart(2, '0')}:00 - ${String(idx).padStart(2, '0')}:59`), h.count, h.total.toFixed(2)]);
        });
    } else if (view === 'refunds') {
        csvRows.push(["#", "Order ID", "Date & Time", "Voided Amount (LKR)"]);
        const voids = (window.allOrders || []).filter(o => {
            if (o.status !== 'Void' && o.isVoid !== true) return false;
            const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
            return d >= startDate && d <= endDate;
        });
        voids.forEach((o, idx) => {
            csvRows.push([idx + 1, sanitize(o.orderId || o.docId), sanitize(o.date || '-'), (parseFloat(o.total) || 0).toFixed(2)]);
        });
    } else if (view === 'stock-movement') {
        csvRows.push(["#", "Product Name", "Category", "Current Stock"]);
        (window.allProducts || []).forEach((p, idx) => {
            csvRows.push([idx + 1, sanitize(p.name), sanitize(p.category || 'General'), p.stock ?? 'INF']);
        });
    } else if (view === 'low-stock') {
        csvRows.push(["#", "Product Name", "Category", "Stock Remaining"]);
        const lowProds = (window.allProducts || []).filter(p => p.mode !== 'Service' && (parseFloat(p.stock) || 0) <= 5);
        lowProds.forEach((p, idx) => {
            csvRows.push([idx + 1, sanitize(p.name), sanitize(p.category || 'General'), p.stock ?? 0]);
        });
    } else if (view === 'suppliers') {
        csvRows.push(["#", "Supplier Name", "Phone / Contact", "Email / Address"]);
        (window.allSuppliers || []).forEach((s, idx) => {
            csvRows.push([idx + 1, sanitize(s.name || s.supplierName || 'Unknown'), sanitize(s.phone || s.contact || '-'), sanitize(s.email || s.address || '-')]);
        });
    } else if (view === 'ledger-export') {
        csvRows.push(["Date", "Description", "Debit (Dr)", "Credit (Cr)"]);
        let ledgerEntries = [];
        orders.forEach(o => {
            const dateStr = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleDateString() : (o.date || '-');
            ledgerEntries.push({ dateStr, desc: `Sales Revenue (Order #${o.orderId || o.docId})`, dr: 0, cr: parseFloat(o.total) || 0 });
        });
        expenses.forEach(e => {
            const dateStr = e.timestamp?.seconds ? new Date(e.timestamp.seconds * 1000).toLocaleDateString() : (e.date || '-');
            ledgerEntries.push({ dateStr, desc: `Expense: ${e.category || e.title || 'General Expense'}`, dr: parseFloat(e.amount) || 0, cr: 0 });
        });
        income.forEach(inc => {
            const dateStr = inc.timestamp?.seconds ? new Date(inc.timestamp.seconds * 1000).toLocaleDateString() : (inc.date || '-');
            ledgerEntries.push({ dateStr, desc: `Extra Income: ${inc.title || inc.category || 'Revenue'}`, dr: 0, cr: parseFloat(inc.amount) || 0 });
        });
        ledgerEntries.forEach(e => {
            csvRows.push([sanitize(e.dateStr), sanitize(e.desc), e.dr.toFixed(2), e.cr.toFixed(2)]);
        });
    } else if (view === 'tax-report' || view === 'tax-rates') {
        csvRows.push(["Description", "Base Amount (LKR)", "Tax Rate", "VAT Amount (LKR)", "Gross Total (LKR)"]);
        const grossRevenue = orders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
        const vatRate = 0.18;
        const vatAmount = grossRevenue * (vatRate / (1 + vatRate));
        const netRevenue = grossRevenue - vatAmount;
        csvRows.push(["Standard Rated Sales (VAT 18%)", netRevenue.toFixed(2), "18%", vatAmount.toFixed(2), grossRevenue.toFixed(2)]);
    }
    return csvRows;
}

function printHTMLViaIframe(htmlContent) {
    let frame = document.getElementById('mec-report-print-frame');
    if (!frame) {
        frame = document.createElement('iframe');
        frame.id = 'mec-report-print-frame';
        frame.style.position = 'fixed';
        frame.style.right = '0';
        frame.style.bottom = '0';
        frame.style.width = '1px';
        frame.style.height = '1px';
        frame.style.opacity = '0.001';
        frame.style.border = 'none';
        frame.style.pointerEvents = 'none';
        frame.style.zIndex = '-9999';
        document.body.appendChild(frame);
    }

    const frameDoc = frame.contentWindow.document;
    frameDoc.open();
    frameDoc.write(htmlContent);
    frameDoc.close();

    setTimeout(() => {
        try {
            frame.contentWindow.focus();
            frame.contentWindow.print();
        } catch (err) {
            console.error("Iframe print error:", err);
            window.showToast("Failed to launch print dialog", "error");
        }
    }, 250);
}

window.downloadReportHubPDF = async () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const view = window.currentHubActiveView || 'sales-summary';

    const printableHTML = generateCleanPDFHTML(view, orders, expenses, income, startDate, endDate);

    // Attempt high-fidelity silent PDF generation via Puppeteer engine if running
    try {
        const response = await fetch('http://127.0.0.1:3899/api/generate-pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                html: printableHTML,
                options: {
                    fileName: `MEC_Report_${view}_${new Date().toISOString().split('T')[0]}.pdf`,
                    landscape: false
                }
            })
        });
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                if (data.base64) {
                    const link = document.createElement('a');
                    link.href = `data:application/pdf;base64,${data.base64}`;
                    link.download = data.fileName;
                    link.click();
                } else if (data.downloadUrl) {
                    const link = document.createElement('a');
                    link.href = data.downloadUrl;
                    link.download = data.fileName;
                    link.click();
                }
                if (window.showToast) window.showToast(`✨ High-Res Vector PDF Downloaded: ${data.fileName}`, "success");
                return;
            }
        }
    } catch (e) {
        // Fallback to iframe browser print
    }

    printHTMLViaIframe(printableHTML);
    if (window.showToast) window.showToast("📄 Save PDF / Print Dialog Opened!", "success");
};

window.downloadReportHubExcel = () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const view = window.currentHubActiveView || 'sales-summary';
    const startStr = (startDate instanceof Date && !isNaN(startDate.getTime())) ? startDate.toISOString().slice(0, 10) : 'all';
    const endStr = (endDate instanceof Date && !isNaN(endDate.getTime())) ? endDate.toISOString().slice(0, 10) : 'all';

    const csvRows = generateCSVData(view, orders, expenses, income, startDate, endDate);

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + csvRows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `MEC_${view.replace(/-/g, '_')}_${startStr}_to_${endStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (window.showToast) window.showToast("📊 Excel/CSV Report Downloaded!", "success");
};

window.filterReportList = (query) => {
    const q = query.toLowerCase();
    const items = document.querySelectorAll('.report-item');
    items.forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(q) ? 'flex' : 'none';
    });
};

window.applyDateFilterOld = () => {
    const startInput = document.getElementById('report-start-date-old');
    const endInput = document.getElementById('report-end-date-old');
    if (!startInput || !endInput) return;
    window.currentReportFiltersOld.start = parseLocalStart(startInput.value);
    window.currentReportFiltersOld.end = parseLocalEnd(endInput.value);
    if (window.allOrders) window.generateReportsOld(window.allOrders);
    window.showToast("📊 Applied Old Report Filters", "info");
};

window.resetDateFilterOld = () => {
    window.initReports();
    if (window.allOrders) window.generateReportsOld(window.allOrders);
};

window.generateDoubleEntryLedger = () => {
    const body = document.getElementById('ledger-body');
    if (!body) return;
    const { start, end } = window.currentReportFiltersOld;
    let entries = [];
    (window.allOrders || []).filter(o => o.status === 'Delivered').filter(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        return d >= start && d <= end;
    }).forEach(o => {
        const date = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        entries.push({ date, desc: `Sales Revenue (Order #${o.orderId})`, dr: 0, cr: o.total });
        entries.push({ date, desc: `${o.paymentMethod || 'Cash'} Asset`, dr: o.total, cr: 0 });
    });
    entries.sort((a,b) => b.date - a.date);
    let bal = 0;
    body.innerHTML = entries.map(e => { bal += (e.dr - e.cr); return `<tr><td>${e.date.toLocaleDateString()}</td><td>${e.desc}</td><td style="text-align:right; color:#10b981;">${e.dr || '-'}</td><td style="text-align:right; color:#fbbf24;">${e.cr || '-'}</td><td style="text-align:right;">${bal.toLocaleString()}</td></tr>`; }).join('');
};

window.renderTaxReportOld = (orders) => {
    const container = document.getElementById('tax-content-body');
    if (!container) return;
    const { start, end } = window.currentReportFiltersOld;
    const filtered = orders.filter(o => { 
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0)); 
        return d >= start && d <= end && o.status === 'Delivered'; 
    });
    
    let grossRevenue = filtered.reduce((acc, o) => acc + (o.total || 0), 0);
    const vatRate = 0.18; // Standard 18% VAT
    const vatAmount = grossRevenue * (vatRate / (1 + vatRate)); // Calculate VAT from gross
    const netRevenue = grossRevenue - vatAmount;

    container.innerHTML = `
        <div class="stats-overview-grid" style="margin-bottom: 2rem;">
            <div class="stat-box info" style="background: rgba(14, 165, 233, 0.1);">
                <h4 style="color: #38bdf8;">Gross Sales (Tax Incl.)</h4>
                <div class="val">LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
            <div class="stat-box error" style="background: rgba(239, 68, 68, 0.1);">
                <h4 style="color: #ef4444;">VAT Liability (18%)</h4>
                <div class="val">LKR ${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
            <div class="stat-box success" style="background: rgba(16, 185, 129, 0.1);">
                <h4 style="color: #10b981;">Net Sales (Tax Excl.)</h4>
                <div class="val">LKR ${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
            </div>
        </div>

        <!-- Tax Composition Visual Graph -->
        <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 16px; margin-bottom: 2rem; max-width: 500px;">
            <h4 style="margin: 0 0 10px 0; color: #ef4444; font-size: 0.95rem; font-weight: 800;">⚖️ Tax (VAT) vs Net Inflow Proportion</h4>
            <div style="position: relative; height: 200px; width: 100%;">
                <canvas id="tax-view-doughnut-chart"></canvas>
            </div>
        </div>

        <table class="report-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align: right;">Base Amount</th>
                    <th style="text-align: right;">Tax Amount</th>
                    <th style="text-align: right;">Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="font-weight: 700;">Standard Rated Sales (18%)</td>
                    <td style="text-align: right;">${netRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    <td style="text-align: right; color: #ef4444;">${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    <td style="text-align: right; font-weight: 800;">${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                </tr>
                <tr style="background: rgba(255,255,255,0.05);">
                    <td colspan="3" style="text-align: right; font-weight: 800;">Total Tax Liability</td>
                    <td style="text-align: right; font-weight: 900; color: #ef4444;">LKR ${vatAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                </tr>
            </tbody>
        </table>
    `;

    if (typeof Chart !== 'undefined') {
        const ctxTax = document.getElementById('tax-view-doughnut-chart');
        if (ctxTax) {
            if (window._chartTaxDoughnut) window._chartTaxDoughnut.destroy();
            window._chartTaxDoughnut = new Chart(ctxTax, {
                type: 'doughnut',
                data: {
                    labels: ['Net Retained Revenue', 'Government VAT 18%'],
                    datasets: [{
                        data: [Math.max(0, netRevenue) || 0.01, vatAmount || 0],
                        backgroundColor: ['#10b981', '#ef4444'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: { legend: { position: 'right', labels: { color: '#cbd5e1', font: { weight: '700' } } } }
                }
            });
        }
    }
};

window.renderAgingReport = () => {
    const container = document.getElementById('aging-content-body');
    if (!container) return;

    const customers = window.allCustomers || [];
    const orders = window.allOrders || [];
    const reloads = window.allReloads || [];
    const now = new Date();

    let buckets = {
        current: 0,
        thirty: 0,
        sixty: 0,
        ninety: 0,
        plus: 0
    };

    const debtorList = [];

    customers.forEach(c => {
        const cleanCustPhone = (c.phone || "").replace(/[\s-]/g, "").toLowerCase();
        
        // 1. Get Credit Orders (Shop/Repair)
        const creditOrders = orders.filter(o => {
            if (o.status === 'Void') return false;
            const isCredit = (o.paymentMethod || o.payMode || "").toLowerCase() === 'credit';
            if (!isCredit) return false;

            if (o.customerId === c.docId) return true;
            
            // Phone Fallback
            const cleanOrderPhone = (o.customerPhone || o.phone || "").replace(/[\s-]/g, "").toLowerCase();
            return cleanCustPhone !== "" && cleanCustPhone === cleanOrderPhone;
        });

        // 2. Get Credit Reloads
        const creditReloads = reloads.filter(r => {
            if (r.status === 'Void') return false;
            if (r.isPOS === true) return false;
            if ((r.payMode || "").toLowerCase() !== 'credit') return false;

            if (r.customerId === c.docId) return true;

            // Phone Fallback
            const cleanReloadPhone = (r.phone || "").replace(/[\s-]/g, "").toLowerCase();
            return cleanCustPhone !== "" && cleanCustPhone === cleanReloadPhone;
        });

        const allCreditItems = [...creditOrders, ...creditReloads];

        if (allCreditItems.length === 0 && (!c.outstanding || c.outstanding <= 0)) return;

        let totalOutstanding = c.outstanding || 0;
        let agingBuckets = { current: 0, thirty: 0, sixty: 0, ninety: 0, plus: 0 };

        allCreditItems.forEach(item => {
            const oDate = item.timestamp?.seconds ? new Date(item.timestamp.seconds * 1000) : (item.date ? new Date(item.date + 'T12:00:00') : new Date(0));
            if (isNaN(oDate.getTime())) return;

            const diffDays = Math.floor((now - oDate) / (1000 * 60 * 60 * 24));
            const billTotal = item.total || item.amount || 0;
            const paid = (item.paymentMethod || item.payMode || "").toLowerCase() === 'credit' ? (item.tenderedAmount || 0) : 0;
            const amount = Math.max(0, billTotal - paid);

            if (diffDays <= 30) agingBuckets.current += amount;
            else if (diffDays <= 60) agingBuckets.thirty += amount;
            else if (diffDays <= 90) agingBuckets.sixty += amount;
            else agingBuckets.ninety += amount;
        });

        // If total outstanding > sum of tracked items (legacy/manual adjustments), put excess in plus
        const itemSum = Object.values(agingBuckets).reduce((a, b) => a + b, 0);
        if (totalOutstanding > itemSum) {
            agingBuckets.plus += (totalOutstanding - itemSum);
        }

        Object.keys(buckets).forEach(k => buckets[k] += agingBuckets[k]);
        debtorList.push({ name: c.name, phone: c.phone, buckets: agingBuckets, total: totalOutstanding });
    });

    debtorList.sort((a, b) => b.total - a.total);

    container.innerHTML = `
        <div class="stats-overview-grid" style="margin-bottom: 2rem;">
            <div class="stat-box success"><h4>Current (0-30)</h4><div class="val">LKR ${formatCurrency(buckets.current)}</div></div>
            <div class="stat-box info"><h4>31-60 Days</h4><div class="val">LKR ${formatCurrency(buckets.thirty)}</div></div>
            <div class="stat-box warning"><h4>61-90 Days</h4><div class="val">LKR ${formatCurrency(buckets.sixty)}</div></div>
            <div class="stat-box error"><h4>90+ Days</h4><div class="val">LKR ${formatCurrency(buckets.ninety + buckets.plus)}</div></div>
        </div>

        <!-- Aging Visual Analytics Graph -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 2rem;">
            <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 16px;">
                <h4 style="margin: 0 0 10px 0; color: #38bdf8; font-size: 0.95rem; font-weight: 800;">📊 Debt Aging Distribution</h4>
                <div style="position: relative; height: 220px; width: 100%;">
                    <canvas id="aging-view-doughnut-chart"></canvas>
                </div>
            </div>
            <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 16px;">
                <h4 style="margin: 0 0 10px 0; color: #ef4444; font-size: 0.95rem; font-weight: 800;">👥 Top 5 High-Balance Debtors</h4>
                <div style="position: relative; height: 220px; width: 100%;">
                    <canvas id="aging-view-bar-chart"></canvas>
                </div>
            </div>
        </div>

        <table class="report-table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th style="text-align: right;">Current</th>
                    <th style="text-align: right;">31-60</th>
                    <th style="text-align: right;">61-90</th>
                    <th style="text-align: right;">90+</th>
                    <th style="text-align: right;">Total Balance</th>
                </tr>
            </thead>
            <tbody>
                ${debtorList.map(d => `
                    <tr>
                        <td style="font-weight: 700;">${d.name}<br><small style="opacity: 0.5;">${d.phone}</small></td>
                        <td style="text-align: right;">${formatCurrency(d.buckets.current)}</td>
                        <td style="text-align: right;">${formatCurrency(d.buckets.thirty)}</td>
                        <td style="text-align: right;">${formatCurrency(d.buckets.sixty)}</td>
                        <td style="text-align: right; color: #ef4444;">${formatCurrency(d.buckets.ninety + d.buckets.plus)}</td>
                        <td style="text-align: right; font-weight: 900; color: #38bdf8;">LKR ${formatCurrency(d.total)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;

    // Render Aging Charts
    if (typeof Chart !== 'undefined') {
        const ctxAgingPie = document.getElementById('aging-view-doughnut-chart');
        if (ctxAgingPie) {
            if (window._chartAgingPie) window._chartAgingPie.destroy();
            window._chartAgingPie = new Chart(ctxAgingPie, {
                type: 'doughnut',
                data: {
                    labels: ['0-30 Days', '31-60 Days', '61-90 Days', '90+ Days'],
                    datasets: [{
                        data: [buckets.current || 0.01, buckets.thirty, buckets.sixty, (buckets.ninety + buckets.plus)],
                        backgroundColor: ['#10b981', '#38bdf8', '#f59e0b', '#ef4444'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: { legend: { position: 'right', labels: { color: '#cbd5e1', font: { weight: '700' } } } }
                }
            });
        }

        const ctxAgingBar = document.getElementById('aging-view-bar-chart');
        if (ctxAgingBar) {
            const topDebtors = debtorList.slice(0, 5);
            if (window._chartAgingBar) window._chartAgingBar.destroy();
            window._chartAgingBar = new Chart(ctxAgingBar, {
                type: 'bar',
                data: {
                    labels: topDebtors.map(d => d.name.length > 14 ? d.name.slice(0, 12) + '...' : d.name),
                    datasets: [{
                        label: 'Outstanding (LKR)',
                        data: topDebtors.map(d => d.total),
                        backgroundColor: '#ef4444',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } }
                    }
                }
            });
        }
    }
};

window.renderCashflowForecast = () => {
    const container = document.getElementById('forecast-content-body');
    if (!container) return;

    const orders = window.allOrders || [];
    const expenses = window.allExpenses || [];
    const now = new Date();

    // Group by week for the last 4 weeks
    const weeklyData = [0, 0, 0, 0]; // Index 0 is 4 weeks ago
    orders.filter(o => o.status === 'Delivered').forEach(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        const diffWeeks = Math.floor((now - d) / (1000 * 60 * 60 * 24 * 7));
        if (diffWeeks >= 0 && diffWeeks < 4) weeklyData[3 - diffWeeks] += o.total;
    });

    const avgWeeklyIncome = weeklyData.reduce((a, b) => a + b, 0) / 4;
    
    // Group expenses
    let weeklyExp = 0;
    expenses.forEach(e => {
        const d = e.date ? new Date(e.date + 'T12:00:00') : new Date(0);
        const diffWeeks = Math.floor((now - d) / (1000 * 60 * 60 * 24 * 7));
        if (diffWeeks >= 0 && diffWeeks < 4) weeklyExp += e.amount;
    });
    const avgWeeklyExp = weeklyExp / 4;

    const weeks = ['Next Week', 'Week 2', 'Week 3', 'Week 4'];
    const projectedNetValues = weeks.map((w, i) => (avgWeeklyIncome - avgWeeklyExp) * (i + 1));

    container.innerHTML = `
        <div class="stats-overview-grid" style="margin-bottom: 2rem;">
            <div class="stat-box success"><h4>Avg. Weekly Income</h4><div class="val">LKR ${formatCurrency(avgWeeklyIncome)}</div></div>
            <div class="stat-box error"><h4>Avg. Weekly Expense</h4><div class="val">LKR ${formatCurrency(avgWeeklyExp)}</div></div>
            <div class="stat-box info"><h4>Predicted Monthly Cashflow</h4><div class="val">LKR ${formatCurrency((avgWeeklyIncome - avgWeeklyExp) * 4)}</div></div>
        </div>

        <!-- Cashflow Predictive Line & Projection Chart -->
        <div class="card glass-card" style="padding: 1.5rem; background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 16px; margin-bottom: 2rem;">
            <h4 style="margin: 0 0 10px 0; color: #10b981; font-size: 0.95rem; font-weight: 800;">📈 4-Week Net Cashflow Trajectory</h4>
            <div style="position: relative; height: 230px; width: 100%;">
                <canvas id="forecast-view-line-chart"></canvas>
            </div>
        </div>

        <div style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.08);">
            <h4 style="margin-top: 0; color: #38bdf8;">4-Week Forecast Projection</h4>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;">
                ${weeks.map((w, i) => {
                    const projectedNet = projectedNetValues[i];
                    return `
                        <div style="padding: 15px; background: rgba(255,255,255,0.05); border-radius: 12px; text-align: center;">
                            <div style="font-size: 0.7rem; opacity: 0.6;">${w}</div>
                            <div style="font-size: 1.1rem; font-weight: 800; color: ${projectedNet >= 0 ? '#10b981' : '#ef4444'};">
                                ${projectedNet >= 0 ? '+' : ''}LKR ${projectedNet.toLocaleString()}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
            <p style="font-size: 0.75rem; color: #94a3b8; margin-top: 15px; font-style: italic;">
                * Forecast is based on the average performance of the last 30 business days. Seasonal variations are not included.
            </p>
        </div>
    `;

    if (typeof Chart !== 'undefined') {
        const ctxForecast = document.getElementById('forecast-view-line-chart');
        if (ctxForecast) {
            if (window._chartForecastLine) window._chartForecastLine.destroy();
            window._chartForecastLine = new Chart(ctxForecast, {
                type: 'line',
                data: {
                    labels: ['Current', ...weeks],
                    datasets: [
                        {
                            label: 'Cumulative Net Cashflow (LKR)',
                            data: [0, ...projectedNetValues],
                            borderColor: '#10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.15)',
                            fill: true,
                            tension: 0.35,
                            borderWidth: 3,
                            pointBackgroundColor: '#10b981',
                            pointRadius: 5
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { labels: { color: '#cbd5e1', font: { weight: '700' } } } },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } }
                    }
                }
            });
        }
    }
};

window.renderBankRecon = () => {
    const container = document.getElementById('recon-content-body');
    if (!container) return;

    // Preserve the upload UI
    const uploadUI = `
        <div style="display: flex; justify-content: flex-end; gap: 10px; margin-bottom: 1.5rem;">
            <input type="file" id="bank-statement-upload" style="display: none;" onchange="window.handleBankStatementUpload(this)">
            <button class="action-btn" onclick="document.getElementById('bank-statement-upload').click()" style="background: rgba(139, 92, 246, 0.1); color: #8b5cf6; border: 1px solid rgba(139, 92, 246, 0.2); font-weight: 800;">
                <span>📂</span> Upload CSV Statement
            </button>
            <button class="action-btn primary" onclick="window.showToast('Reconciliation Saved Locally', 'success')">Save Progress</button>
        </div>
    `;

    const income = window.allIncome || [];
    const expenses = window.allExpenses || [];
    const combined = [
        ...income.map(i => ({ ...i, type: 'INCOME', color: '#10b981' })),
        ...expenses.map(e => ({ ...e, type: 'EXPENSE', color: '#ef4444', title: e.title || e.category }))
    ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 50);

    let mainContent = "";

    if (window.lastUploadedStatement && window.lastUploadedStatement.length > 0) {
        // --- Comparison Mode ---
        mainContent = `
            <div style="margin-bottom: 2rem;">
                <h4 style="color: #8b5cf6; margin-bottom: 10px;">Bank Statement Comparison (Uploaded)</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <!-- System side -->
                    <div>
                        <div style="font-size: 0.7rem; color: #94a3b8; text-transform: uppercase; margin-bottom: 5px;">System Transactions</div>
                        ${combined.slice(0, 10).map(t => {
                            const match = window.lastUploadedStatement.find(s => Math.abs(s.amount - t.amount) < 0.01);
                            return `
                                <div style="padding: 10px; background: ${match ? 'rgba(16, 185, 129, 0.05)' : 'rgba(255, 255, 255, 0.02)'}; border-radius: 10px; border: 1px solid ${match ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.05)'}; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-size: 0.8rem; font-weight: 700;">${t.title || 'N/A'}</div>
                                        <div style="font-size: 0.65rem; opacity: 0.5;">${t.date} | ${t.type}</div>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 800; color: ${t.color};">${t.type === 'INCOME' ? '+' : '-'} LKR ${t.amount.toLocaleString()}</div>
                                        ${match ? '<span style="font-size: 0.6rem; color: #10b981; font-weight: 900;">✓ MATCHED</span>' : '<span style="font-size: 0.6rem; color: #ef4444; font-weight: 900;">UNMATCHED</span>'}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    <!-- Bank side -->
                    <div>
                        <div style="font-size: 0.7rem; color: #94a3b8; text-transform: uppercase; margin-bottom: 5px;">Bank Statement Entries</div>
                        ${window.lastUploadedStatement.slice(0, 10).map(s => {
                            const match = combined.find(t => Math.abs(t.amount - s.amount) < 0.01);
                            return `
                                <div style="padding: 10px; background: ${match ? 'rgba(139, 92, 246, 0.05)' : 'rgba(255, 255, 255, 0.02)'}; border-radius: 10px; border: 1px solid ${match ? 'rgba(139, 92, 246, 0.2)' : 'rgba(255,255,255,0.05)'}; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-size: 0.8rem; font-weight: 700;">${s.description}</div>
                                        <div style="font-size: 0.65rem; opacity: 0.5;">${s.date}</div>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 800; color: #fff;">LKR ${s.amount.toLocaleString()}</div>
                                        ${match ? '<span style="font-size: 0.6rem; color: #8b5cf6; font-weight: 900;">✓ IN SYSTEM</span>' : '<span style="font-size: 0.6rem; color: #f59e0b; font-weight: 900;">EXTERNAL</span>'}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            </div>
        `;
    } else {
        mainContent = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                <p style="color: #94a3b8; margin: 0;">Showing last 50 financial transactions for manual verification. Upload a statement for auto-match.</p>
            </div>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reference / Title</th>
                        <th>Type</th>
                        <th style="text-align: right;">Amount</th>
                        <th style="text-align: center;">Verify</th>
                    </tr>
                </thead>
                <tbody>
                    ${combined.map(t => `
                        <tr>
                            <td>${t.date}</td>
                            <td style="font-weight: 600;">${t.title || 'Other'}</td>
                            <td><span style="background: ${t.color}20; color: ${t.color}; padding: 4px 8px; border-radius: 6px; font-size: 0.7rem; font-weight: 800;">${t.type}</span></td>
                            <td style="text-align: right; font-weight: 800; color: ${t.color};">${t.type === 'INCOME' ? '+' : '-'} LKR ${t.amount.toLocaleString()}</td>
                            <td style="text-align: center;">
                                <input type="checkbox" style="width: 18px; height: 18px; cursor: pointer;">
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    container.innerHTML = uploadUI + mainContent;
};

window.handleBankStatementUpload = (input) => {
    const file = input.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target.result;
        try {
            const rows = text.split('\n').map(r => r.split(',').map(c => c.replace(/"/g, '').trim()));
            if (rows.length < 2) throw new Error("Invalid CSV format");

            // Look for headers to identify columns
            const headers = rows[0].map(h => h.toLowerCase());
            const dateIdx = headers.findIndex(h => h.includes('date'));
            const descIdx = headers.findIndex(h => h.includes('description') || h.includes('memo') || h.includes('details'));
            const amountIdx = headers.findIndex(h => h.includes('amount') || h.includes('balance') || h.includes('value'));

            if (dateIdx === -1 || amountIdx === -1) {
                window.showToast("Could not identify Date or Amount columns in CSV.", "error");
                return;
            }

            const parsed = rows.slice(1).filter(r => r.length > 1).map(r => ({
                date: r[dateIdx],
                description: r[descIdx] || "No Description",
                amount: Math.abs(parseFloat(r[amountIdx].replace(/[^-0-9.]/g, ''))) || 0
            })).filter(item => !isNaN(item.amount) && item.amount > 0);

            window.lastUploadedStatement = parsed;
            window.showToast(`Successfully parsed ${parsed.length} statement entries.`, "success");
            window.renderBankRecon();
        } catch (err) {
            console.error(err);
            window.showToast("Error parsing bank statement CSV.", "error");
        }
    };
    reader.readAsText(file);
};

// ==========================================
// --- COMMON EXPORT LOGIC ---
// ==========================================

window.switchSummarySubView = (view, btn) => {
    document.querySelectorAll('#report-view-summary [id^="summary-sub-view-"]').forEach(v => v.style.display = 'none');
    document.querySelectorAll('.report-sub-tab-btn').forEach(b => b.classList.remove('active'));
    
    const target = document.getElementById(`summary-sub-view-${view}`);
    if (target) {
        target.style.display = 'block';
        // Auto-refresh if the content container is empty but orders are present
        const salesContent = document.getElementById('sales-report-content');
        if (view === 'sales' && salesContent && salesContent.innerHTML.trim() === '' && window.allOrders) {
            window.generateReportsOld(window.allOrders);
        }
    }
    if (btn) btn.classList.add('active');
};

window.exportReportPDF = async () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const view = window.currentSelectedReport || 'profit-margin';
    const printableHTML = generateCleanPDFHTML(view, orders, expenses, income, startDate, endDate);
    
    // Attempt high-fidelity silent PDF generation via Puppeteer engine if available
    try {
        const response = await fetch('http://127.0.0.1:3899/api/generate-pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                html: printableHTML,
                options: {
                    fileName: `MEC_${view}_${new Date().toISOString().split('T')[0]}.pdf`,
                    landscape: false
                }
            })
        });
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                if (data.base64) {
                    const link = document.createElement('a');
                    link.href = `data:application/pdf;base64,${data.base64}`;
                    link.download = data.fileName;
                    link.click();
                } else if (data.downloadUrl) {
                    const link = document.createElement('a');
                    link.href = data.downloadUrl;
                    link.download = data.fileName;
                    link.click();
                }
                if (window.showToast) window.showToast(`✨ High-Res Vector PDF Downloaded: ${data.fileName}`, "success");
                return;
            }
        }
    } catch (e) {
        // Fallback to standard clean iframe print if background microservice is offline
    }

    printHTMLViaIframe(printableHTML);
    if (window.showToast) window.showToast("📄 Save PDF / Print Dialog Opened!", "success");
};

window.exportReportExcel = () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const isAnalytics = document.getElementById('section-analytics')?.style.display !== 'none';
    const view = isAnalytics ? (window.currentSelectedReport || 'profit-margin') : (window.currentHubActiveView || 'sales-summary');
    const startStr = (startDate instanceof Date && !isNaN(startDate.getTime()) && startDate.getTime() > 0) ? startDate.toISOString().slice(0, 10) : 'all';
    const endStr = (endDate instanceof Date && !isNaN(endDate.getTime()) && endDate.getFullYear() < 9000) ? endDate.toISOString().slice(0, 10) : 'all';

    const csvRows = generateCSVData(view, orders, expenses, income, startDate, endDate);
    if (!csvRows || csvRows.length === 0) {
        if (window.showToast) window.showToast("No data available to export for selected dates", "warning");
        return;
    }

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + csvRows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `MEC_${view.replace(/-/g, '_')}_${startStr}_to_${endStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (window.showToast) window.showToast("📊 Excel/CSV Report Downloaded!", "success");
};

window.printReport = () => {
    const { startDate, endDate, orders, expenses, income } = getHubFilteredData();
    const isAnalytics = document.getElementById('section-analytics')?.style.display !== 'none';
    const view = isAnalytics ? (window.currentSelectedReport || 'profit-margin') : (window.currentHubActiveView || 'sales-summary');
    const printableHTML = generateCleanPDFHTML(view, orders, expenses, income, startDate, endDate);
    printHTMLViaIframe(printableHTML);
};

window.renderProfitReportOld = (orders) => {
    const container = document.getElementById('profit-report-content');
    if (!container) return;

    const start = window.currentReportFiltersOld.start;
    const end = window.currentReportFiltersOld.end;

    // Filter by date first
    const filtered = (orders || []).filter(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000) : (o.date ? new Date(o.date + 'T12:00:00') : new Date(0));
        return d >= start && d <= end && o.status !== 'Void';
    });

    // Aggregation logic by SKU/Name
    const productMap = new Map();
    filtered.forEach(o => {
        (o.items || []).forEach(item => {
            if (item.isReload) return; // Skip reload items in profit report
            const sku = item.sku || 'N/A';
            const name = item.name || 'Unknown';
            const qty = parseFloat(item.quantity) || 0;
            const price = parseFloat(item.price) || 0;
            const discount = parseFloat(item.discount) || 0;
            const netPrice = price - discount;
            const totalSales = netPrice * qty;

            let itemCost = item.costPrice || 0;
            if (!itemCost && window.allProducts) {
                const prod = window.allProducts.find(p => p.docId === item.docId || p.sku === item.sku);
                if (prod) itemCost = parseFloat(prod.cost || prod.buyingPrice) || 0;
            }
            const totalCost = itemCost * qty;

            const key = sku + "_" + name;
            if (productMap.has(key)) {
                const existing = productMap.get(key);
                existing.qty += qty;
                existing.totalSales += totalSales;
                existing.totalCost += totalCost;
            } else {
                productMap.set(key, { sku, name, qty, totalSales, totalCost });
            }
        });
    });

    const results = Array.from(productMap.values()).sort((a, b) => b.totalSales - a.totalSales);

    let totalCostAll = 0, totalSalesAll = 0, totalProfitAll = 0;

    const tableHTML = `
        <div style="font-family: 'Inter', sans-serif; background: white; padding: 10px; color: #333;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 2rem; border-bottom: 3px solid #1e293b; padding-bottom: 1.5rem;">
                <div>
                    <h1 style="margin: 0; color: #1e293b; font-size: 2.2rem; font-weight: 900; letter-spacing: -1px;">PROFIT ANALYSIS</h1>
                    <p style="margin: 8px 0; color: #64748b; font-weight: 700; font-size: 0.9rem;">
                        PERIOD: <span style="color: #000;">${start.toISOString().split('T')[0]}</span> TO <span style="color: #000;">${end.toISOString().split('T')[0]}</span>
                    </p>
                </div>
                <div style="text-align: right;">
                    <h2 style="margin: 0; color: #1e293b; font-weight: 800;">MEC Book Shop</h2>
                    <p style="margin: 5px 0; color: #64748b; font-size: 0.8rem; font-weight: 600; line-height: 1.4;">
                        no-97 victoria park panadura road<br>
                        munagama horana, 12400 horana
                    </p>
                </div>
            </div>

            <!-- Profit Visual Analytics Charts (Top Margins & Cost Breakdown) -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 2rem;">
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 15px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 0.85rem; color: #0f172a; font-weight: 800;">🏆 Top Profit Generating Products</h4>
                    <div style="position: relative; height: 220px; width: 100%;">
                        <canvas id="profit-view-bar-chart"></canvas>
                    </div>
                </div>
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 15px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 0.85rem; color: #0f172a; font-weight: 800;">⚖️ Overall Profit vs Cost Breakdown</h4>
                    <div style="position: relative; height: 220px; width: 100%;">
                        <canvas id="profit-view-pie-chart"></canvas>
                    </div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; border: 1px solid #e2e8f0;">
                <thead>
                    <tr style="background: #1e293b; color: white;">
                        <th style="padding: 15px; text-align: left; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">SKU / Code</th>
                        <th style="padding: 15px; text-align: left; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Product Description</th>
                        <th style="padding: 15px; text-align: center; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Qty</th>
                        <th style="padding: 15px; text-align: right; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Cost (LKR)</th>
                        <th style="padding: 15px; text-align: right; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Sales (LKR)</th>
                        <th style="padding: 15px; text-align: right; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Profit (LKR)</th>
                        <th style="padding: 15px; text-align: right; text-transform: uppercase; font-size: 0.7rem; letter-spacing: 1px;">Margin (%)</th>
                    </tr>
                </thead>
                <tbody>
                    ${results.map(r => {
                        const profit = r.totalSales - r.totalCost;
                        const margin = r.totalSales > 0 ? (profit / r.totalSales) * 100 : 0;
                        totalCostAll += r.totalCost;
                        totalSalesAll += r.totalSales;
                        totalProfitAll += profit;
                        return `
                            <tr style="border-bottom: 1px solid #f1f5f9; transition: background 0.2s;">
                                <td style="padding: 12px; font-family: monospace; font-weight: 700;">${r.sku}</td>
                                <td style="padding: 12px; font-weight: 600;">${r.name}</td>
                                <td style="padding: 12px; text-align: center; font-weight: 800;">${r.qty}</td>
                                <td style="padding: 12px; text-align: right;">${r.totalCost.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 12px; text-align: right; font-weight: 700;">${r.totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 12px; text-align: right; font-weight: 900; color: ${profit >= 0 ? '#10b981' : '#ef4444'};">${profit.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td style="padding: 12px; text-align: right; font-weight: 700;">
                                    <span style="background: ${margin > 30 ? '#dcfce7' : margin > 10 ? '#fef9c3' : '#fee2e2'}; color: ${margin > 30 ? '#166534' : margin > 10 ? '#854d0e' : '#991b1b'}; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem;">
                                        ${margin.toFixed(2)}%
                                    </span>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
                <tfoot>
                    <tr style="background: #f8fafc; border-top: 3px solid #1e293b; font-weight: 900; font-size: 1.1rem; color: #1e293b;">
                        <td colspan="3" style="padding: 20px; text-align: right;">GRAND TOTALS</td>
                        <td style="padding: 20px; text-align: right;">${totalCostAll.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 20px; text-align: right;">${totalSalesAll.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 20px; text-align: right; color: #10b981;">${totalProfitAll.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                        <td style="padding: 20px; text-align: right; background: #1e293b; color: white;">${(totalSalesAll > 0 ? (totalProfitAll / totalSalesAll) * 100 : 0).toFixed(2)}%</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    `;
    container.innerHTML = tableHTML;

    // Render Profit View Charts
    if (typeof Chart !== 'undefined') {
        const topProfItems = results.slice(0, 5);
        const ctxProfitBar = document.getElementById('profit-view-bar-chart');
        if (ctxProfitBar) {
            if (window._chartProfitBar) window._chartProfitBar.destroy();
            window._chartProfitBar = new Chart(ctxProfitBar, {
                type: 'bar',
                data: {
                    labels: topProfItems.map(i => i.name.length > 15 ? i.name.slice(0, 13) + '...' : i.name),
                    datasets: [{
                        label: 'Net Profit (LKR)',
                        data: topProfItems.map(i => (i.totalSales - i.totalCost).toFixed(2)),
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false }, ticks: { color: '#64748b' } },
                        y: { grid: { color: '#e2e8f0' }, ticks: { color: '#64748b' } }
                    }
                }
            });
        }

        const ctxProfitPie = document.getElementById('profit-view-pie-chart');
        if (ctxProfitPie) {
            if (window._chartProfitPie) window._chartProfitPie.destroy();
            window._chartProfitPie = new Chart(ctxProfitPie, {
                type: 'doughnut',
                data: {
                    labels: ['Cost of Goods (COGS)', 'Net Gross Profit'],
                    datasets: [{
                        data: [totalCostAll || 1, Math.max(0, totalProfitAll) || 0],
                        backgroundColor: ['#ef4444', '#10b981'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: { legend: { position: 'right', labels: { color: '#0f172a', font: { family: 'Inter', weight: '700' } } } }
                }
            });
        }
    }
};

window.exportProfitToExcel = () => {
    const table = document.querySelector('#profit-report-content table');
    if (!table) return;
    const wb = XLSX.utils.table_to_book(table, { sheet: "Profit Analysis" });
    XLSX.writeFile(wb, `Profit_Analysis_${new Date().toISOString().split('T')[0]}.xlsx`);
};

window.exportProfitToPDF = async () => {
    const element = document.getElementById('profit-report-render-area');
    if (!element) return;
    
    const opt = {
        margin: 10,
        filename: `Profit_Report_${new Date().toISOString().split('T')[0]}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };
    
    window.showToast("Generating PDF... Please wait", "info");
    html2pdf().set(opt).from(element).save();
};

window.filterReportList = (query) => {
    const items = document.querySelectorAll('.report-item');
    query = query.toLowerCase();
    items.forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(query) ? 'flex' : 'none';
    });
};

window.renderCashBalancingReport = () => {
    const today = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    const dateInput = document.getElementById('cash-balance-date');
    if (dateInput && !dateInput.value) {
        dateInput.value = today;
    }
    const selectedDate = dateInput ? dateInput.value : today;

    const cashierSelect = document.getElementById('cash-balance-cashier');
    const currentRole = (sessionStorage.getItem('userRole') || 'Admin').toLowerCase();
    const currentUserName = sessionStorage.getItem('userName') || 'Master Admin';
    const currentUserId = sessionStorage.getItem('userId') || sessionStorage.getItem('userUsername') || sessionStorage.getItem('userEmail') || 'Master';
    const currentUserEmail = sessionStorage.getItem('userEmail') || '';
    const currentUserUsername = sessionStorage.getItem('userUsername') || '';
    const userBranch = sessionStorage.getItem('userBranchId');
    const activeBranch = window.activeBranchFilter || (userBranch && userBranch !== 'Global' ? userBranch : 'All');

    const isCashierRole = currentRole === 'cashier' || currentRole === 'staff';

    if (cashierSelect) {
        const employees = window.allEmployees || [];
        
        let cashierList = [];
        if (isCashierRole) {
            // Cashier only balances their own shift
            cashierList = [{ 
                name: `${currentUserName} (${currentUserUsername || currentUserId})`, 
                id: currentUserId 
            }];
        } else {
            // Managers / Admins see cashiers belonging to the active branch
            const filteredEmployees = employees.filter(emp => {
                if (activeBranch === 'All') return true;
                const isTargetHorana = activeBranch === 'main' || activeBranch === 'Global' || activeBranch.toLowerCase().includes('horana');
                const empBranch = (emp.branchId || 'main').toLowerCase();
                const isEmpPanadura = empBranch.includes('panadura') || empBranch === 'j8lsw5vrjwmssc630dh0';
                if (isTargetHorana) return !isEmpPanadura;
                return empBranch === activeBranch.toLowerCase();
            });

            cashierList = filteredEmployees.map(emp => ({ 
                name: `${emp.name} (${emp.username || emp.email || 'Cashier'})`, 
                id: emp.docId || emp.username || emp.email
            }));
            
            if (activeBranch === 'All' || activeBranch === 'main' || activeBranch === 'Global') {
                cashierList.unshift({ name: 'Master Admin (CEO/SuperAdmin)', id: 'Master' });
            }
        }

        const savedCashierVal = cashierSelect.value;
        cashierSelect.innerHTML = cashierList.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

        if (isCashierRole) {
            cashierSelect.value = currentUserId;
            cashierSelect.disabled = true;
        } else if (savedCashierVal && cashierList.some(c => c.id === savedCashierVal)) {
            cashierSelect.value = savedCashierVal;
        } else if (currentUserId && cashierList.some(c => c.id === currentUserId)) {
            cashierSelect.value = currentUserId;
        } else if (cashierList.length > 0) {
            cashierSelect.value = cashierList[0].id;
        }
    }

    const selectedCashierId = cashierSelect ? cashierSelect.value : currentUserId;

    // Find the selected employee object for matching
    const selectedEmployee = (window.allEmployees || []).find(emp => 
        emp.docId === selectedCashierId || 
        emp.id === selectedCashierId || 
        emp.email?.toLowerCase() === selectedCashierId.toLowerCase() || 
        emp.username?.toLowerCase() === selectedCashierId.toLowerCase() ||
        emp.name?.toLowerCase() === selectedCashierId.toLowerCase()
    );
    const cashierBranch = selectedEmployee?.branchId || sessionStorage.getItem('userBranchId') || window.activeBranchFilter || 'main';
    const isTargetHorana = cashierBranch === 'main' || cashierBranch === 'Global' || cashierBranch.toLowerCase().includes('horana');

    const isCashierMatch = (staffId, staffName) => {
        if (!selectedCashierId || selectedCashierId === 'All') return true;
        if (selectedCashierId === 'Master') {
            const s = (staffId || '').toLowerCase();
            return s === 'master' || s === 'mecbookshop@gmail.com' || s === 'malinduec@gmail.com' || s === 'mecposadmin@gmail.com' || (staffName || '').toLowerCase().includes('master');
        }
        const targetStaffId = (staffId || '').toLowerCase();
        const targetStaffName = (staffName || '').toLowerCase();
        
        if (targetStaffId && targetStaffId === selectedCashierId.toLowerCase()) return true;
        if (targetStaffName && targetStaffName === selectedCashierId.toLowerCase()) return true;
        
        if (selectedEmployee) {
            if (selectedEmployee.docId && targetStaffId === selectedEmployee.docId.toLowerCase()) return true;
            if (selectedEmployee.id && targetStaffId === selectedEmployee.id.toLowerCase()) return true;
            if (selectedEmployee.email && (targetStaffId === selectedEmployee.email.toLowerCase() || targetStaffName === selectedEmployee.email.toLowerCase())) return true;
            if (selectedEmployee.username && (targetStaffId === selectedEmployee.username.toLowerCase() || targetStaffName === selectedEmployee.username.toLowerCase())) return true;
            if (selectedEmployee.name && targetStaffName === selectedEmployee.name.toLowerCase()) return true;
        }
        return false;
    };

    let totalSalesCount = 0;
    let totalSalesAmount = 0;
    let cardSales = 0;
    let bankSales = 0;
    let creditSales = 0;
    let chequeSales = 0;
    let cashSales = 0;
    let cashReloads = 0;

    const orders = window.allOrders || [];
    orders.forEach(o => {
        if (o.date === selectedDate && o.status !== 'Void') {
            const orderBranchId = (o.branchId || 'main').toLowerCase();
            const isOrderPanadura = orderBranchId.includes('panadura') || orderBranchId === 'j8lsw5vrjwmssc630dh0';
            if (cashierBranch !== 'All') {
                if (isTargetHorana && isOrderPanadura) return;
                if (!isTargetHorana && !orderBranchId.includes(cashierBranch.toLowerCase())) return;
            }

            if (isCashierMatch(o.staffId, o.staffName)) {
                totalSalesCount++;
                const total = parseFloat(o.total) || 0;
                totalSalesAmount += total;
                
                let orderReloadAmount = 0;
                if (o.items && Array.isArray(o.items)) {
                    o.items.forEach(item => {
                        if (item.isReload) {
                            orderReloadAmount += (parseFloat(item.price) || 0);
                        }
                    });
                }

                const method = (o.paymentMethod || o.method || "cash").toLowerCase();
                if (method.includes('card')) {
                    cardSales += total;
                } else if (method.includes('bank') || method.includes('transfer')) {
                    bankSales += total;
                } else if (method.includes('credit')) {
                    const tendered = parseFloat(o.tenderedAmount) || 0;
                    const creditPortion = Math.max(0, total - tendered);
                    creditSales += creditPortion;
                    
                    const effectiveCash = total - creditPortion - orderReloadAmount;
                    cashSales += effectiveCash;
                    cashReloads += orderReloadAmount;
                } else if (method.includes('cheque')) {
                    chequeSales += total;
                } else {
                    cashSales += (total - orderReloadAmount);
                    cashReloads += orderReloadAmount;
                }
            }
        }
    });

    const reloads = window.allReloads || [];
    reloads.forEach(r => {
        if (r.isPOS === true) return;
        if (r.date === selectedDate && r.status !== 'Void') {
            const reloadBranchId = (r.branchId || 'main').toLowerCase();
            const isReloadPanadura = reloadBranchId.includes('panadura') || reloadBranchId === 'j8lsw5vrjwmssc630dh0';
            if (cashierBranch !== 'All') {
                if (isTargetHorana && isReloadPanadura) return;
                if (!isTargetHorana && !reloadBranchId.includes(cashierBranch.toLowerCase())) return;
            }

            if (isCashierMatch(r.staffId, r.staffName)) {
                const method = (r.payMode || "").toLowerCase();
                if (method.includes('cash')) {
                    cashReloads += (parseFloat(r.baseAmount || r.amount) || 0);
                }
            }
        }
    });

    let cashExpenses = 0;
    const expenses = window.allExpenses || [];
    expenses.forEach(e => {
        if (e.date === selectedDate) {
            const expBranch = (e.branchId || 'main').toLowerCase();
            const isExpPanadura = expBranch.includes('panadura') || expBranch === 'j8lsw5vrjwmssc630dh0';

            if (cashierBranch !== 'All') {
                if (isTargetHorana) {
                    if (isExpPanadura) return;
                } else if (cashierBranch.toLowerCase().includes('panadura') || cashierBranch === 'j8lsw5vrjwmssc630dh0') {
                    if (!isExpPanadura) return;
                } else {
                    if (expBranch !== cashierBranch.toLowerCase()) return;
                }
            }

            // Only count if associated with this cashier or general branch expense
            if (isCashierMatch(e.staffId || e.staffEmail, e.staffName)) {
                cashExpenses += (parseFloat(e.amount) || 0);
            } else if (!e.staffId && !e.staffName && (selectedCashierId === 'Master' || selectedCashierId === 'All')) {
                cashExpenses += (parseFloat(e.amount) || 0);
            }
        }
    });

    const totalBillsCountEl = document.getElementById('cb-total-bills-count');
    const totalSalesAmountEl = document.getElementById('cb-total-sales-amount');
    const cardSalesEl = document.getElementById('cb-card-sales');
    const bankSalesEl = document.getElementById('cb-bank-sales');
    const creditSalesEl = document.getElementById('cb-credit-sales');
    const chequeSalesEl = document.getElementById('cb-cheque-sales');
    const expectedSalesEl = document.getElementById('cb-expected-sales');
    const expectedReloadsEl = document.getElementById('cb-expected-reloads');
    const expectedExpensesEl = document.getElementById('cb-expected-expenses');

    if (totalBillsCountEl) totalBillsCountEl.innerText = totalSalesCount + ' Bills';
    if (totalSalesAmountEl) totalSalesAmountEl.innerText = 'LKR ' + window.formatCurrency(totalSalesAmount);
    if (cardSalesEl) cardSalesEl.innerText = 'LKR ' + window.formatCurrency(cardSales);
    if (bankSalesEl) bankSalesEl.innerText = 'LKR ' + window.formatCurrency(bankSales);
    if (creditSalesEl) creditSalesEl.innerText = 'LKR ' + window.formatCurrency(creditSales);
    if (chequeSalesEl) chequeSalesEl.innerText = 'LKR ' + window.formatCurrency(chequeSales);
    if (expectedSalesEl) expectedSalesEl.innerText = 'LKR ' + window.formatCurrency(cashSales);
    if (expectedReloadsEl) expectedReloadsEl.innerText = 'LKR ' + window.formatCurrency(cashReloads);
    if (expectedExpensesEl) expectedExpensesEl.innerText = 'LKR ' + window.formatCurrency(cashExpenses);
    
    window.calculateCashDifference();
};

window.calculateCashDifference = () => {
    const salesStr = document.getElementById('cb-expected-sales')?.innerText.replace('LKR ', '').replace(/,/g, '') || '0';
    const reloadsStr = document.getElementById('cb-expected-reloads')?.innerText.replace('LKR ', '').replace(/,/g, '') || '0';
    const expensesStr = document.getElementById('cb-expected-expenses')?.innerText.replace('LKR ', '').replace(/,/g, '') || '0';
    
    const cashSales = parseFloat(salesStr) || 0;
    const cashReloads = parseFloat(reloadsStr) || 0;
    const cashExpenses = parseFloat(expensesStr) || 0;
    const openingCash = parseFloat(document.getElementById('cb-opening-cash')?.value) || 0;

    const expectedTotal = cashSales + cashReloads - cashExpenses + openingCash;
    const expectedTotalEl = document.getElementById('cb-expected-total');
    if (expectedTotalEl) expectedTotalEl.innerText = 'LKR ' + window.formatCurrency(expectedTotal);

    let countedTotal = 0;
    document.querySelectorAll('.denom-row').forEach(row => {
        const input = row.querySelector('.denom-input');
        const sumEl = row.querySelector('.denom-sum');
        if (input && sumEl) {
            const val = parseFloat(input.getAttribute('data-val')) || 0;
            const qty = parseFloat(input.value) || 0;
            const subtotal = val * qty;
            countedTotal += subtotal;
            sumEl.innerText = 'LKR ' + window.formatCurrency(subtotal);
        }
    });

    const actualTotalEl = document.getElementById('cb-actual-total');
    if (actualTotalEl) actualTotalEl.innerText = 'LKR ' + window.formatCurrency(countedTotal);

    const discrepancy = countedTotal - expectedTotal;
    const discrepancyEl = document.getElementById('cb-discrepancy');
    const badgeEl = document.getElementById('cb-status-badge');

    if (discrepancyEl && badgeEl) {
        discrepancyEl.innerText = (discrepancy >= 0 ? '+' : '') + 'LKR ' + window.formatCurrency(discrepancy);
        
        if (Math.abs(discrepancy) < 0.01) {
            discrepancyEl.style.color = '#fff';
            badgeEl.innerText = 'Balanced';
            badgeEl.style.background = 'rgba(16, 185, 129, 0.2)';
            badgeEl.style.color = '#10b981';
        } else if (discrepancy > 0) {
            discrepancyEl.style.color = '#10b981';
            badgeEl.innerText = 'Surplus (Excess Cash)';
            badgeEl.style.background = 'rgba(16, 185, 129, 0.2)';
            badgeEl.style.color = '#10b981';
        } else {
            discrepancyEl.style.color = '#ef4444';
            badgeEl.innerText = 'Shortage (Missing Cash)';
            badgeEl.style.background = 'rgba(239, 68, 68, 0.2)';
            badgeEl.style.color = '#ef4444';
        }
    }
};

// Keyboard navigation (ArrowUp, ArrowDown, Enter) for Cash Balancing inputs
if (!window._cashNavBound) {
    window._cashNavBound = true;
    document.addEventListener('keydown', (e) => {
        const active = document.activeElement;
        if (!active) return;

        const isDenom = active.classList?.contains('denom-input');
        const isOpening = active.id === 'cb-opening-cash';

        if (!isDenom && !isOpening) return;

        if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === 'ArrowUp') {
            const denomInputs = Array.from(document.querySelectorAll('.denom-input'));
            const allCashInputs = [document.getElementById('cb-opening-cash'), ...denomInputs].filter(Boolean);
            const currentIndex = allCashInputs.indexOf(active);

            if (currentIndex === -1) return;

            e.preventDefault();
            e.stopPropagation();

            let targetIndex;
            if (e.key === 'ArrowDown' || e.key === 'Enter') {
                targetIndex = (currentIndex + 1) % allCashInputs.length;
            } else if (e.key === 'ArrowUp') {
                targetIndex = (currentIndex - 1 + allCashInputs.length) % allCashInputs.length;
            }

            const target = allCashInputs[targetIndex];
            if (target) {
                target.focus();
                setTimeout(() => target.select(), 10);
            }
        }
    });
}

window.printCashBalancingReport = () => {
    const date = document.getElementById('cash-balance-date')?.value || '';
    const cashierEl = document.getElementById('cash-balance-cashier');
    const cashierName = cashierEl ? cashierEl.options[cashierEl.selectedIndex]?.text : '';
    
    const sales = document.getElementById('cb-expected-sales')?.innerText || '';
    const reloads = document.getElementById('cb-expected-reloads')?.innerText || '';
    const expenses = document.getElementById('cb-expected-expenses')?.innerText || '';
    const opening = document.getElementById('cb-opening-cash')?.value || '0';
    const expected = document.getElementById('cb-expected-total')?.innerText || '';
    const actual = document.getElementById('cb-actual-total')?.innerText || '';
    const discrepancy = document.getElementById('cb-discrepancy')?.innerText || '';
    const status = document.getElementById('cb-status-badge')?.innerText || '';

    const totalBills = document.getElementById('cb-total-bills-count')?.innerText || '0 Bills';
    const grossSales = document.getElementById('cb-total-sales-amount')?.innerText || 'LKR 0.00';
    const cardSales = document.getElementById('cb-card-sales')?.innerText || 'LKR 0.00';
    const bankSales = document.getElementById('cb-bank-sales')?.innerText || 'LKR 0.00';
    const creditSales = document.getElementById('cb-credit-sales')?.innerText || 'LKR 0.00';
    const chequeSales = document.getElementById('cb-cheque-sales')?.innerText || 'LKR 0.00';

    let denomRowsHtml = '';
    document.querySelectorAll('.denom-row').forEach(row => {
        const input = row.querySelector('.denom-input');
        if (input && parseFloat(input.value) > 0) {
            const denom = input.getAttribute('data-val');
            const qty = input.value;
            denomRowsHtml += `<tr><td>LKR ${denom}</td><td style="text-align: center;">${qty}</td><td style="text-align: right;">LKR ${(denom * qty).toLocaleString(undefined, {minimumFractionDigits: 2})}</td></tr>`;
        }
    });

    const physicalTableHtml = denomRowsHtml ? `
                <div class="section-title">PHYSICAL CASH BREAKDOWN</div>
                <table>
                    <thead>
                        <tr><th>Denomination</th><th style="text-align: center;">Qty</th><th style="text-align: right;">Subtotal</th></tr>
                    </thead>
                    <tbody>
                        ${denomRowsHtml}
                        <tr class="totals"><td colspan="2">Total Physical Count</td><td style="text-align: right;">${actual}</td></tr>
                    </tbody>
                </table>
    ` : '';

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>Cash Balancing Report - ${date}</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Noto+Sans+Sinhala:wght@400;600;700;800&family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
                <style>
                    body { font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', sans-serif; padding: 30px; color: #333; }
                    .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
                    .section-title { font-weight: bold; margin-top: 20px; margin-bottom: 10px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { padding: 8px; border-bottom: 1px solid #eee; text-align: left; }
                    th { background-color: #f5f5f5; }
                    .totals { font-weight: bold; }
                    .variance-box { border: 2px solid #333; padding: 15px; margin-top: 20px; display: flex; justify-content: space-between; font-size: 1.2rem; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>MEC POS - CASH BALANCING REPORT</h2>
                    <p>Date: ${date} | Cashier: ${cashierName}</p>
                </div>
                
                <div class="section-title">SYSTEM TRANSACTION SUMMARY</div>
                <table>
                    <tr><td>Total Bills Count</td><td style="text-align: right;">${totalBills}</td></tr>
                    <tr><td>Gross Sales Amount</td><td style="text-align: right;">${grossSales}</td></tr>
                    <tr><td>Card Payments Summary</td><td style="text-align: right;">-${cardSales}</td></tr>
                    <tr><td>Bank Transfer Summary</td><td style="text-align: right;">-${bankSales}</td></tr>
                    <tr><td>Credit / On Credit Summary</td><td style="text-align: right;">-${creditSales}</td></tr>
                    <tr><td>Cheque Summary</td><td style="text-align: right;">-${chequeSales}</td></tr>
                    <tr class="totals"><td>Expected Net Cash Sales</td><td style="text-align: right;">${sales}</td></tr>
                </table>

                <div class="section-title">SYSTEM EXPECTED CASH</div>
                <table>
                    <tr><td>Expected Net Cash Sales</td><td style="text-align: right;">${sales}</td></tr>
                    <tr><td>Expected Reloads</td><td style="text-align: right;">${reloads}</td></tr>
                    <tr><td>Expected Expenses</td><td style="text-align: right;">-${expenses}</td></tr>
                    <tr><td>Opening Cash Drawer Limit</td><td style="text-align: right;">LKR ${parseFloat(opening).toLocaleString(undefined, {minimumFractionDigits: 2})}</td></tr>
                    <tr class="totals"><td>Total Expected Cash</td><td style="text-align: right;">${expected}</td></tr>
                </table>

                ${physicalTableHtml}

                <div class="variance-box">
                    <span>Variance / Discrepancy (${status})</span>
                    <span>${discrepancy}</span>
                </div>

                <div style="margin-top: 50px; display: flex; justify-content: space-between;">
                    <div style="border-top: 1px solid #333; width: 200px; text-align: center; padding-top: 5px;">Cashier Signature</div>
                    <div style="border-top: 1px solid #333; width: 200px; text-align: center; padding-top: 5px;">Manager Signature</div>
                </div>
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
};

window.saveCashBalancingShift = async () => {
    const date = document.getElementById('cash-balance-date')?.value || '';
    const cashierEl = document.getElementById('cash-balance-cashier');
    const cashierId = cashierEl ? cashierEl.value : '';
    const cashierName = cashierEl ? cashierEl.options[cashierEl.selectedIndex]?.text : '';

    const sales = parseFloat(document.getElementById('cb-expected-sales')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const reloads = parseFloat(document.getElementById('cb-expected-reloads')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const expenses = parseFloat(document.getElementById('cb-expected-expenses')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const opening = parseFloat(document.getElementById('cb-opening-cash')?.value) || 0;
    const expected = parseFloat(document.getElementById('cb-expected-total')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const actual = parseFloat(document.getElementById('cb-actual-total')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const discrepancy = actual - expected;

    const totalBills = parseInt(document.getElementById('cb-total-bills-count')?.innerText || '0') || 0;
    const grossSales = parseFloat(document.getElementById('cb-total-sales-amount')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const cardSales = parseFloat(document.getElementById('cb-card-sales')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const bankSales = parseFloat(document.getElementById('cb-bank-sales')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const creditSales = parseFloat(document.getElementById('cb-credit-sales')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;
    const chequeSales = parseFloat(document.getElementById('cb-cheque-sales')?.innerText.replace('LKR ', '').replace(/,/g, '')) || 0;

    // Calculate shift timing & duration
    const closeDate = new Date();
    const loginTimeIso = sessionStorage.getItem('mec_shift_login_time') || localStorage.getItem('mec_shift_login_time');
    let startDate = loginTimeIso ? new Date(loginTimeIso) : new Date(closeDate.getTime() - 8 * 3600 * 1000);
    if (isNaN(startDate.getTime()) || startDate > closeDate) {
        startDate = new Date(closeDate.getTime() - 8 * 3600 * 1000);
    }

    const diffMs = Math.max(0, closeDate.getTime() - startDate.getTime());
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const shiftDuration = `${diffHours} hrs ${diffMinutes} mins`;

    const shiftStartTime = startDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    const shiftCloseTime = closeDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

    // Cashier and employee details
    let cashierEmp = (window.allEmployees || []).find(emp => 
        emp.docId === cashierId || 
        emp.id === cashierId || 
        emp.email?.toLowerCase() === (cashierId || '').toLowerCase() || 
        emp.username?.toLowerCase() === (cashierId || '').toLowerCase() ||
        emp.name?.toLowerCase() === (cashierName || '').toLowerCase()
    );

    let cashierDisplay = cashierName || 'Primary Cashier';
    let cashierEmpId = '';
    let cashierDesignation = '';
    let cashierPhone = '';

    if (cashierEmp) {
        cashierEmpId = cashierEmp.regno || cashierEmp.empId || cashierEmp.id || '';
        cashierDesignation = cashierEmp.role || cashierEmp.role_access || cashierEmp.designation || 'Cashier';
        cashierPhone = cashierEmp.phone || '';
        const detailsPart = [cashierDesignation, cashierEmpId].filter(Boolean).join(' - ');
        cashierDisplay = `${cashierEmp.name || cashierName} (${detailsPart || 'Staff'})`;
    } else if (cashierId === 'Master' || sessionStorage.getItem('userRole') === 'CEO_Admin' || sessionStorage.getItem('userRole') === 'SuperAdmin') {
        const sName = sessionStorage.getItem('userName') || 'Master Admin';
        const sRole = sessionStorage.getItem('userDesignation') || sessionStorage.getItem('userRole') || 'CEO / SuperAdmin';
        const sReg = sessionStorage.getItem('userRegNo') || 'EMP-001';
        cashierDisplay = `${sName} (${sRole} - ${sReg})`;
        cashierEmpId = sReg;
        cashierDesignation = sRole;
        cashierPhone = sessionStorage.getItem('userPhone') || '';
    } else {
        const sName = sessionStorage.getItem('userName') || cashierName;
        const sRole = sessionStorage.getItem('userDesignation') || sessionStorage.getItem('userRole') || 'Cashier';
        const sReg = sessionStorage.getItem('userRegNo') || '';
        const detailsPart = [sRole, sReg].filter(Boolean).join(' - ');
        cashierDisplay = `${sName} (${detailsPart || 'Staff'})`;
        cashierEmpId = sReg;
        cashierDesignation = sRole;
        cashierPhone = sessionStorage.getItem('userPhone') || '';
    }

    // Collect physical cash denomination breakdown
    const denominations = [];
    document.querySelectorAll('.denom-row').forEach(row => {
        const input = row.querySelector('.denom-input');
        if (input) {
            const val = parseFloat(input.getAttribute('data-val')) || 0;
            const qty = parseFloat(input.value) || 0;
            if (qty > 0) {
                denominations.push({ val, qty, subtotal: val * qty });
            }
        }
    });

    const shiftData = {
        date,
        cashierId,
        cashierName,
        cashierDisplay,
        cashierEmpId,
        cashierDesignation,
        cashierPhone,
        shiftStartTime,
        shiftCloseTime,
        shiftDuration,
        expectedSales: sales,
        expectedReloads: reloads,
        expectedExpenses: expenses,
        openingCash: opening,
        expectedTotal: expected,
        actualCounted: actual,
        discrepancy,
        totalBillsCount: totalBills,
        grossSalesAmount: grossSales,
        cardSalesAmount: cardSales,
        bankSalesAmount: bankSales,
        creditSalesAmount: creditSales,
        chequeSalesAmount: chequeSales,
        denominations,
        storeId: window.getStoreId(),
        timestamp: new Date()
    };

    try {
        const { collection, addDoc } = await import("firebase/firestore");
        const { db } = await import("../firebase.js");
        const docRef = await addDoc(collection(db, 'cash_shift_settlements'), shiftData);
        window.showToast("💾 Shift balancing successfully saved & locked!", "success");

        if (window.allCashSettlements) {
            window.allCashSettlements.unshift({ id: docRef.id, ...shiftData });
        }

        // Reset shift timer for subsequent shift sessions
        const nextShiftStartIso = new Date().toISOString();
        sessionStorage.setItem('mec_shift_login_time', nextShiftStartIso);
        localStorage.setItem('mec_shift_login_time', nextShiftStartIso);

        // Automatically dispatch Shift Balancing Summary to CEO WhatsApp
        if (typeof window.sendShiftBalancingWhatsApp === 'function') {
            try {
                await window.sendShiftBalancingWhatsApp({ id: docRef.id, ...shiftData }, false);
            } catch (shiftWaErr) {
                console.warn("Auto Shift WhatsApp dispatch warning:", shiftWaErr);
            }
        }

        // Show Shift Summary Modal immediately so the user can inspect, print, or review
        if (typeof window.viewCashSheetDetails === 'function') {
            setTimeout(() => {
                window.viewCashSheetDetails({ id: docRef.id, ...shiftData });
            }, 300);
        }
    } catch (e) {
        console.error("Error saving shift settlement:", e);
        window.showToast("Failed to save shift settlement.", "error");
    }
};

window.openTodaySalesModal = () => {
    if (typeof window.showTab === 'function') {
        window.showTab('reports');
    }
    setTimeout(() => {
        const todayStr = new Date().toISOString().split('T')[0];
        const startInput = document.getElementById('report-start-date');
        const endInput = document.getElementById('report-end-date');
        if (startInput) startInput.value = todayStr;
        if (endInput) endInput.value = todayStr;

        const salesHistEl = document.querySelector('.report-item[onclick*="sales-history"]');
        if (typeof window.selectReport === 'function') {
            window.selectReport('sales-history', salesHistEl);
        }
        if (typeof window.generateCurrentReport === 'function') {
            window.generateCurrentReport();
        }
    }, 150);
};

// =========================================================================
// 📜 CASH BALANCING HISTORY & SHIFT SETTLEMENT AUDIT (RBAC PROTECTED)
// Permitted: CEO, HR Manager, Finance/Account Manager, Branch Manager, Admin
// =========================================================================

window.canAccessCashHistory = () => {
    const role = (sessionStorage.getItem('userRole') || '').toLowerCase();
    const designation = (sessionStorage.getItem('userDesignation') || '').toLowerCase();
    const email = (sessionStorage.getItem('userEmail') || '').toLowerCase();

    // Master / Platform Owner bypass
    if (email === 'mecbookshop@gmail.com' || email === 'malinduec@gmail.com' || email === 'mecposadmin@gmail.com') {
        return true;
    }

    // Role checks
    const isSuperOrCeo = role.includes('ceo') || role.includes('superadmin') || role.includes('admin') || designation.includes('ceo') || designation.includes('founder') || designation.includes('super admin');
    const isHR = role.includes('hr') || designation.includes('hr');
    const isFinanceOrAccountant = role.includes('account') || role.includes('finance') || designation.includes('account') || designation.includes('finance');
    const isManager = role.includes('manager') || designation.includes('manager');

    // Reject pure cashiers, repair tech, store keepers
    if (role === 'cashier' && !isManager && !isSuperOrCeo) {
        return false;
    }

    return isSuperOrCeo || isHR || isFinanceOrAccountant || isManager;
};

window.checkCashHistoryNavVisibility = () => {
    const canSee = window.canAccessCashHistory();
    const tabBtn = document.getElementById('btn-report-cash-history');
    if (tabBtn) tabBtn.style.display = canSee ? 'inline-block' : 'none';
    const innerBtn = document.getElementById('btn-open-cash-history');
    if (innerBtn) innerBtn.style.display = canSee ? 'inline-flex' : 'none';
};

window.loadCashBalancingHistory = async (force = false) => {
    if (!window.canAccessCashHistory()) return [];
    if (window.allCashSettlements && !force) return window.allCashSettlements;

    const tbody = document.getElementById('cash-history-table-body');
    if (tbody && (!window.allCashSettlements || force)) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 40px; color: #38bdf8;"><span class="spinner" style="display:inline-block; margin-right:8px;">⏳</span> Fetching shift cash balancing settlements from cloud...</td></tr>`;
    }

    try {
        const { collection, getDocs, query, orderBy, limit } = await import("firebase/firestore");
        const { db } = await import("../firebase.js");
        const storeId = window.getStoreId ? window.getStoreId() : 'mec-book-shop';

        let docs = [];
        try {
            const q = query(collection(db, 'cash_shift_settlements'), orderBy('timestamp', 'desc'), limit(250));
            const snap = await getDocs(q);
            docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        } catch (idxErr) {
            console.warn("Index fallback for cash_shift_settlements query:", idxErr);
            const snap = await getDocs(query(collection(db, 'cash_shift_settlements'), limit(250)));
            docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        }

        // Store filtering
        if (storeId && storeId !== 'master') {
            docs = docs.filter(s => !s.storeId || s.storeId === storeId || s.storeId === 'mec-book-shop' || s.storeId === '1001');
        }

        docs.sort((a, b) => {
            const tA = a.timestamp?.seconds ? a.timestamp.seconds * 1000 : (a.timestamp ? new Date(a.timestamp).getTime() : 0);
            const tB = b.timestamp?.seconds ? b.timestamp.seconds * 1000 : (b.timestamp ? new Date(b.timestamp).getTime() : 0);
            return tB - tA;
        });

        window.allCashSettlements = docs;
        return docs;
    } catch (e) {
        console.error("Error loading cash balancing history:", e);
        if (window.showToast) window.showToast("Failed to load shift settlements", "error");
        return [];
    }
};

window.renderCashBalancingHistory = async (force = false) => {
    if (!window.canAccessCashHistory()) {
        if (window.showToast) {
            window.showToast("🔒 Access Restricted: You do not have permission to view Cash Balancing History.", "error");
        }
        window.switchReportView('cash-balancing');
        return;
    }

    window.checkCashHistoryNavVisibility();

    // Default dates: past 30 days up to today
    const fromInput = document.getElementById('cash-hist-from-date');
    const toInput = document.getElementById('cash-hist-to-date');
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    if (toInput && !toInput.value) toInput.value = todayStr;
    if (fromInput && !fromInput.value) {
        const d = new Date();
        d.setDate(d.getDate() - 30);
        fromInput.value = d.toISOString().split('T')[0];
    }

    const data = await window.loadCashBalancingHistory(force);

    // Populate Cashiers dropdown
    const cashierSelect = document.getElementById('cash-hist-cashier-filter');
    if (cashierSelect) {
        const cashiers = new Set();
        data.forEach(s => {
            const name = s.cashierName || (s.cashierDisplay ? s.cashierDisplay.split('(')[0].trim() : '');
            if (name) cashiers.add(name);
        });
        const currentVal = cashierSelect.value || 'All';
        let optHtml = `<option value="All">All Cashiers (${cashiers.size})</option>`;
        Array.from(cashiers).sort().forEach(cName => {
            optHtml += `<option value="${cName}">${cName}</option>`;
        });
        cashierSelect.innerHTML = optHtml;
        if (Array.from(cashiers).includes(currentVal)) {
            cashierSelect.value = currentVal;
        } else {
            cashierSelect.value = 'All';
        }
    }

    window.filterCashHistoryList();
};

window.filterCashHistoryList = () => {
    const list = window.allCashSettlements || [];
    const fromDate = document.getElementById('cash-hist-from-date')?.value || '';
    const toDate = document.getElementById('cash-hist-to-date')?.value || '';
    const cashier = document.getElementById('cash-hist-cashier-filter')?.value || 'All';
    const status = document.getElementById('cash-hist-status-filter')?.value || 'All';
    const search = (document.getElementById('cash-hist-search-input')?.value || '').toLowerCase().trim();

    let filtered = list.filter(s => {
        const d = s.date || (s.timestamp?.seconds ? new Date(s.timestamp.seconds * 1000).toISOString().split('T')[0] : '');
        if (fromDate && d && d < fromDate) return false;
        if (toDate && d && d > toDate) return false;

        if (cashier !== 'All') {
            const sName = s.cashierName || s.cashierDisplay || '';
            if (!sName.toLowerCase().includes(cashier.toLowerCase())) return false;
        }

        const disc = (s.discrepancy !== undefined) ? parseFloat(s.discrepancy) : ((parseFloat(s.actualCounted) || 0) - (parseFloat(s.expectedTotal) || 0));
        if (status === 'balanced' && Math.abs(disc) >= 0.01) return false;
        if (status === 'surplus' && disc <= 0.01) return false;
        if (status === 'shortage' && disc >= -0.01) return false;

        if (search) {
            const combined = `${s.cashierName || ''} ${s.cashierDisplay || ''} ${s.cashierEmpId || ''} ${s.cashierDesignation || ''} ${d}`.toLowerCase();
            if (!combined.includes(search)) return false;
        }

        return true;
    });

    // Update KPI Cards
    let totalCounted = 0;
    let totalExpected = 0;
    let totalVariance = 0;
    let totalBills = 0;

    filtered.forEach(s => {
        totalCounted += (parseFloat(s.actualCounted) || 0);
        totalExpected += (parseFloat(s.expectedTotal) || 0);
        const disc = (s.discrepancy !== undefined) ? parseFloat(s.discrepancy) : ((parseFloat(s.actualCounted) || 0) - (parseFloat(s.expectedTotal) || 0));
        totalVariance += disc;
        totalBills += (parseInt(s.totalBillsCount) || 0);
    });

    const shiftCountEl = document.getElementById('kpi-hist-shift-count');
    if (shiftCountEl) shiftCountEl.innerText = `${filtered.length} Shifts`;
    const actualCashEl = document.getElementById('kpi-hist-actual-cash');
    if (actualCashEl) actualCashEl.innerText = `LKR ${window.formatCurrency ? window.formatCurrency(totalCounted) : totalCounted.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    const expCashEl = document.getElementById('kpi-hist-expected-cash');
    if (expCashEl) expCashEl.innerText = `LKR ${window.formatCurrency ? window.formatCurrency(totalExpected) : totalExpected.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
    
    const varEl = document.getElementById('kpi-hist-net-variance');
    const varLabelEl = document.getElementById('kpi-hist-net-variance-label');
    if (varEl) {
        const sign = totalVariance > 0.01 ? '+' : (totalVariance < -0.01 ? '-' : '');
        const formattedVar = window.formatCurrency ? window.formatCurrency(Math.abs(totalVariance)) : Math.abs(totalVariance).toLocaleString(undefined, {minimumFractionDigits: 2});
        varEl.innerText = `${sign}LKR ${formattedVar}`;
        if (Math.abs(totalVariance) < 0.01) {
            varEl.style.color = '#10b981';
            if (varLabelEl) varLabelEl.innerText = '✅ Perfectly Balanced';
        } else if (totalVariance > 0) {
            varEl.style.color = '#10b981';
            if (varLabelEl) varLabelEl.innerText = '🟢 Net Surplus Across Shifts';
        } else {
            varEl.style.color = '#ef4444';
            if (varLabelEl) varLabelEl.innerText = '🔴 Net Shortage Across Shifts';
        }
    }

    const billsEl = document.getElementById('kpi-hist-total-bills');
    if (billsEl) billsEl.innerText = `${totalBills.toLocaleString()} Bills`;

    // Render Table Rows
    const tbody = document.getElementById('cash-history-table-body');
    if (!tbody) return;

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 50px; color: #94a3b8;">
                    <div style="font-size: 2rem; margin-bottom: 10px;">📜</div>
                    <div style="font-weight: 700; font-size: 1.05rem; color: #fff;">No Shift Settlements Found</div>
                    <div style="font-size: 0.85rem; margin-top: 4px;">Try adjusting the date range, cashier selector, or search filter.</div>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = filtered.map(s => {
        const d = s.date || (s.timestamp?.seconds ? new Date(s.timestamp.seconds * 1000).toISOString().split('T')[0] : 'N/A');
        const startTime = s.shiftStartTime || '';
        const closeTime = s.shiftCloseTime || '';
        const duration = s.shiftDuration || '';

        const cashierName = s.cashierName || 'Cashier';
        const empId = s.cashierEmpId || '';
        const designation = s.cashierDesignation || '';

        const bills = s.totalBillsCount || 0;
        const gross = parseFloat(s.grossSalesAmount || 0);
        const card = parseFloat(s.cardSalesAmount || 0);
        const bank = parseFloat(s.bankSalesAmount || 0);
        const credit = parseFloat(s.creditSalesAmount || 0);

        const expected = parseFloat(s.expectedTotal || 0);
        const actual = parseFloat(s.actualCounted || 0);
        const discrepancy = (s.discrepancy !== undefined) ? parseFloat(s.discrepancy) : (actual - expected);

        let badgeHtml = '';
        if (Math.abs(discrepancy) < 0.01) {
            badgeHtml = `<span style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); padding: 4px 10px; border-radius: 20px; font-weight: 800; font-size: 0.72rem; display: inline-flex; align-items: center; gap: 4px;">✅ Balanced</span>`;
        } else if (discrepancy > 0) {
            badgeHtml = `<span style="background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); padding: 4px 10px; border-radius: 20px; font-weight: 800; font-size: 0.72rem; display: inline-flex; align-items: center; gap: 4px;">🟢 +LKR ${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>`;
        } else {
            badgeHtml = `<span style="background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3); padding: 4px 10px; border-radius: 20px; font-weight: 800; font-size: 0.72rem; display: inline-flex; align-items: center; gap: 4px;">🔴 -LKR ${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})}</span>`;
        }

        const idStr = s.id || '';

        return `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.04); transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.02)';" onmouseout="this.style.background='transparent';">
                <td style="padding: 14px 16px;">
                    <div style="font-weight: 800; color: #fff; font-size: 0.95rem;">📅 ${d}</div>
                    ${closeTime ? `<div style="font-size: 0.75rem; color: #38bdf8; margin-top: 3px;">🏁 Closed: <b>${closeTime}</b></div>` : ''}
                    ${startTime ? `<div style="font-size: 0.72rem; color: #94a3b8;">⏰ Started: ${startTime}</div>` : ''}
                    ${duration ? `<div style="font-size: 0.72rem; color: #c084fc;">⏱️ Duration: <b>${duration}</b></div>` : ''}
                </td>
                <td style="padding: 14px 16px;">
                    <div style="font-weight: 800; color: #fff;">👤 ${cashierName}</div>
                    ${(designation || empId) ? `<div style="font-size: 0.72rem; color: #94a3b8; margin-top: 2px;">${[designation, empId].filter(Boolean).join(' • ')}</div>` : ''}
                </td>
                <td style="padding: 14px 16px;">
                    <div style="font-weight: 700; color: #fff;">LKR ${gross.toLocaleString(undefined, {minimumFractionDigits: 2})} <span style="font-size: 0.75rem; color: #94a3b8; font-weight: 500;">(${bills} Bills)</span></div>
                    <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 2px;">
                        ${card > 0 ? `<span>Card: LKR ${card.toLocaleString()}</span> • ` : ''}
                        ${bank > 0 ? `<span>Bank: LKR ${bank.toLocaleString()}</span> • ` : ''}
                        ${credit > 0 ? `<span style="color:#f59e0b;">Credit: LKR ${credit.toLocaleString()}</span>` : '<span style="opacity:0.6;">All Cash</span>'}
                    </div>
                </td>
                <td style="padding: 14px 16px; text-align: right; font-weight: 800; color: #cbd5e1;">
                    LKR ${expected.toLocaleString(undefined, {minimumFractionDigits: 2})}
                </td>
                <td style="padding: 14px 16px; text-align: right; font-weight: 900; color: #10b981; font-size: 1rem;">
                    LKR ${actual.toLocaleString(undefined, {minimumFractionDigits: 2})}
                </td>
                <td style="padding: 14px 16px; text-align: center;">
                    ${badgeHtml}
                </td>
                <td style="padding: 14px 16px; text-align: right;">
                    <div style="display: flex; gap: 6px; justify-content: flex-end;">
                        <button onclick="window.viewCashSheetDetails('${idStr}')" title="View Full Balance Sheet" style="background: rgba(56, 189, 248, 0.15); border: 1px solid rgba(56, 189, 248, 0.3); color: #38bdf8; border-radius: 8px; padding: 6px 10px; cursor: pointer; font-size: 0.8rem; font-weight: 700;">
                            👁️ View
                        </button>
                        <button onclick="window.printSavedCashBalancingSlip('${idStr}')" title="Print Slip" style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px; padding: 6px 10px; cursor: pointer; font-size: 0.8rem;">
                            🖨️
                        </button>
                        <button onclick="window.resendSheetWhatsApp('${idStr}')" title="Resend WhatsApp Summary" style="background: rgba(37, 211, 102, 0.15); border: 1px solid rgba(37, 211, 102, 0.3); color: #25d366; border-radius: 8px; padding: 6px 10px; cursor: pointer; font-size: 0.8rem;">
                            📲
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
};

window.resetCashHistoryFilters = () => {
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    const d = new Date();
    d.setDate(d.getDate() - 30);
    const fromStr = d.toISOString().split('T')[0];

    const f = document.getElementById('cash-hist-from-date');
    if (f) f.value = fromStr;
    const t = document.getElementById('cash-hist-to-date');
    if (t) t.value = todayStr;
    const c = document.getElementById('cash-hist-cashier-filter');
    if (c) c.value = 'All';
    const s = document.getElementById('cash-hist-status-filter');
    if (s) s.value = 'All';
    const q = document.getElementById('cash-hist-search-input');
    if (q) q.value = '';

    window.filterCashHistoryList();
};

window.viewCashSheetDetails = (sheetId) => {
    const list = window.allCashSettlements || [];
    const sheet = typeof sheetId === 'object' ? sheetId : list.find(s => s.id === sheetId);
    if (!sheet) {
        if (window.showToast) window.showToast("Settlement details not found", "error");
        return;
    }

    window._currentActiveSheet = sheet;

    const modal = document.getElementById('modal-cash-sheet-details');
    const contentArea = document.getElementById('sheet-modal-content-area');
    const subTitle = document.getElementById('sheet-modal-subtitle');
    if (!modal || !contentArea) return;

    const d = sheet.date || 'N/A';
    const storeName = document.querySelector('.main')?.innerText || 'MEC BOOK SHOP';
    if (subTitle) subTitle.innerText = `Settlement Date: ${d} | Ref ID: ${(sheet.id || '').substring(0, 10)}...`;

    const gross = parseFloat(sheet.grossSalesAmount || 0);
    const card = parseFloat(sheet.cardSalesAmount || 0);
    const bank = parseFloat(sheet.bankSalesAmount || 0);
    const credit = parseFloat(sheet.creditSalesAmount || 0);
    const cheque = parseFloat(sheet.chequeSalesAmount || 0);
    const expectedSales = parseFloat(sheet.expectedSales || 0);
    const reloads = parseFloat(sheet.expectedReloads || 0);
    const expenses = parseFloat(sheet.expectedExpenses || 0);
    const opening = parseFloat(sheet.openingCash || 0);
    const expectedTotal = parseFloat(sheet.expectedTotal || 0);
    const actualCounted = parseFloat(sheet.actualCounted || 0);
    const discrepancy = (sheet.discrepancy !== undefined) ? parseFloat(sheet.discrepancy) : (actualCounted - expectedTotal);

    let statusHtml = '';
    if (Math.abs(discrepancy) < 0.01) {
        statusHtml = `<div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 12px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
            <span style="color: #10b981; font-weight: 800;">✅ Shift Status: PERFECTLY BALANCED</span>
            <span style="color: #10b981; font-weight: 900; font-size: 1.2rem;">LKR 0.00</span>
        </div>`;
    } else if (discrepancy > 0) {
        statusHtml = `<div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 12px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
            <span style="color: #10b981; font-weight: 800;">🟢 Shift Status: CASH EXCESS / SURPLUS</span>
            <span style="color: #10b981; font-weight: 900; font-size: 1.2rem;">+LKR ${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
        </div>`;
    } else {
        statusHtml = `<div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
            <span style="color: #ef4444; font-weight: 800;">🔴 Shift Status: CASH SHORTAGE / DEFICIT</span>
            <span style="color: #ef4444; font-weight: 900; font-size: 1.2rem;">-LKR ${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
        </div>`;
    }

    // Denomination details if available
    let denomHtml = '';
    if (Array.isArray(sheet.denominations) && sheet.denominations.length > 0) {
        denomHtml = `
            <div style="margin-top: 20px;">
                <div style="font-size: 0.8rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; margin-bottom: 8px;">Physical Cash Denominations Count</div>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px;">
                    ${sheet.denominations.map(dn => `
                        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 8px; padding: 8px 10px; font-size: 0.8rem;">
                            <div style="opacity: 0.7;">LKR ${dn.val} × ${dn.qty}</div>
                            <div style="font-weight: 800; color: #10b981;">LKR ${(dn.subtotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    contentArea.innerHTML = `
        <!-- Meta Details Box -->
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px; margin-bottom: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 0.85rem;">
            <div>
                <div style="color: #94a3b8; font-size: 0.72rem; text-transform: uppercase; font-weight: 700;">Cashier & Employee</div>
                <div style="font-weight: 800; color: #fff; margin-top: 2px;">👤 ${sheet.cashierDisplay || sheet.cashierName}</div>
                ${sheet.cashierPhone ? `<div style="color: #38bdf8; font-size: 0.78rem;">📞 ${sheet.cashierPhone}</div>` : ''}
            </div>
            <div>
                <div style="color: #94a3b8; font-size: 0.72rem; text-transform: uppercase; font-weight: 700;">Shift Timing & Duration</div>
                <div style="font-weight: 800; color: #fff; margin-top: 2px;">⏰ ${sheet.shiftStartTime || 'N/A'} - ${sheet.shiftCloseTime || 'N/A'}</div>
                <div style="color: #c084fc; font-size: 0.78rem;">⏱️ Duration: <b>${sheet.shiftDuration || 'N/A'}</b></div>
            </div>
        </div>

        <!-- Sales Breakdown Grid -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 14px;">
                <div style="font-size: 0.75rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; margin-bottom: 10px;">Sales Inflow Ledger</div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Total Bills:</span><span style="font-weight:800;">${sheet.totalBillsCount || 0} Bills</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Gross Sales:</span><span style="font-weight:800; color:#fff;">LKR ${gross.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Card Sales:</span><span style="font-weight:700;">LKR ${card.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Bank Transfers:</span><span style="font-weight:700;">LKR ${bank.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Credit Sales:</span><span style="font-weight:700; color:#f59e0b;">LKR ${credit.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.08); font-size: 0.9rem; font-weight: 800;"><span>Net Cash Sales:</span><span style="color:#10b981;">LKR ${expectedSales.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
            </div>

            <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 14px;">
                <div style="font-size: 0.75rem; font-weight: 800; color: #38bdf8; text-transform: uppercase; margin-bottom: 10px;">Drawer Reconciliation</div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">Opening Cash Limit:</span><span style="font-weight:800;">LKR ${opening.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">+ Cash Reloads:</span><span style="font-weight:800; color:#38bdf8;">LKR ${reloads.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.85rem;"><span style="color:#94a3b8;">- Cash Expenses:</span><span style="font-weight:800; color:#ef4444;">-LKR ${expenses.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.08); font-size: 0.88rem; font-weight: 800;"><span>Expected Total Cash:</span><span style="color:#fff;">LKR ${expectedTotal.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
                <div style="display: flex; justify-content: space-between; padding-top: 6px; font-size: 1rem; font-weight: 900;"><span>Actual Counted Cash:</span><span style="color:#10b981;">LKR ${actualCounted.toLocaleString(undefined, {minimumFractionDigits: 2})}</span></div>
            </div>
        </div>

        ${statusHtml}
        ${denomHtml}
    `;

    modal.style.display = 'flex';
};

window.printSavedCashBalancingSlip = (sheetDataOrId) => {
    let sheet = sheetDataOrId;
    if (typeof sheetDataOrId === 'string') {
        sheet = (window.allCashSettlements || []).find(s => s.id === sheetDataOrId);
    }
    if (!sheet) {
        if (window.showToast) window.showToast("Sheet data not found", "error");
        return;
    }

    const d = sheet.date || 'N/A';
    const storeName = document.querySelector('.main')?.innerText || 'MEC BOOK SHOP';
    const cashier = sheet.cashierDisplay || sheet.cashierName || 'Cashier';
    const startTime = sheet.shiftStartTime || '';
    const closeTime = sheet.shiftCloseTime || '';
    const duration = sheet.shiftDuration || '';

    const gross = parseFloat(sheet.grossSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const card = parseFloat(sheet.cardSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const bank = parseFloat(sheet.bankSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const credit = parseFloat(sheet.creditSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const cheque = parseFloat(sheet.chequeSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const expectedSales = parseFloat(sheet.expectedSales || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const reloads = parseFloat(sheet.expectedReloads || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const expenses = parseFloat(sheet.expectedExpenses || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const opening = parseFloat(sheet.openingCash || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const expectedTotal = parseFloat(sheet.expectedTotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const actualCounted = parseFloat(sheet.actualCounted || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    const discrepancyVal = (sheet.discrepancy !== undefined) ? parseFloat(sheet.discrepancy) : ((parseFloat(sheet.actualCounted) || 0) - (parseFloat(sheet.expectedTotal) || 0));
    
    let statusLabel = 'Balanced';
    let discrepancyStr = 'LKR 0.00';
    if (Math.abs(discrepancyVal) < 0.01) {
        statusLabel = 'Balanced (✅)';
        discrepancyStr = 'LKR 0.00';
    } else if (discrepancyVal > 0) {
        statusLabel = 'Surplus (Excess Cash)';
        discrepancyStr = '+LKR ' + discrepancyVal.toLocaleString(undefined, {minimumFractionDigits: 2});
    } else {
        statusLabel = 'Deficit (Shortage)';
        discrepancyStr = '-LKR ' + Math.abs(discrepancyVal).toLocaleString(undefined, {minimumFractionDigits: 2});
    }

    let denomRowsHtml = '';
    if (Array.isArray(sheet.denominations) && sheet.denominations.length > 0) {
        denomRowsHtml = sheet.denominations.map(dn => `
            <tr>
                <td>LKR ${dn.val}</td>
                <td style="text-align: center;">${dn.qty}</td>
                <td style="text-align: right;">LKR ${(dn.subtotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
            </tr>
        `).join('');
    }

    const physicalTableHtml = denomRowsHtml ? `
        <div class="section-title">PHYSICAL CASH BREAKDOWN</div>
        <table>
            <thead>
                <tr><th>Denomination</th><th style="text-align: center;">Qty</th><th style="text-align: right;">Subtotal</th></tr>
            </thead>
            <tbody>
                ${denomRowsHtml}
                <tr class="totals"><td colspan="2">Total Physical Count</td><td style="text-align: right;">LKR ${actualCounted}</td></tr>
            </tbody>
        </table>
    ` : '';

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
        if (window.showToast) window.showToast("Please allow popups to print report", "warning");
        return;
    }

    printWindow.document.write(`
        <html>
            <head>
                <title>Cash Balancing Sheet - ${d}</title>
                <style>
                    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 30px; color: #222; font-size: 13px; line-height: 1.4; }
                    .header { text-align: center; border-bottom: 2px solid #222; padding-bottom: 12px; margin-bottom: 18px; }
                    .header h2 { margin: 0 0 5px 0; font-size: 18px; font-weight: 800; letter-spacing: 0.5px; }
                    .meta-grid { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 15px; background: #f8fafc; padding: 10px; border-radius: 6px; }
                    .section-title { font-weight: 800; font-size: 12px; text-transform: uppercase; margin-top: 18px; margin-bottom: 8px; border-bottom: 1px solid #ccc; padding-bottom: 4px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                    th, td { padding: 6px 8px; border-bottom: 1px solid #eee; text-align: left; }
                    th { background-color: #f1f5f9; font-weight: 700; }
                    .totals { font-weight: 800; border-top: 1px solid #333; }
                    .variance-box { border: 2px solid #222; padding: 12px 16px; margin-top: 18px; display: flex; justify-content: space-between; font-size: 14px; font-weight: 800; border-radius: 6px; }
                    .signatures { margin-top: 45px; display: flex; justify-content: space-between; }
                    .sig-line { border-top: 1px solid #333; width: 180px; text-align: center; padding-top: 5px; font-size: 11px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>${storeName.toUpperCase()}</h2>
                    <div>MEC POS — CASH SHIFT BALANCING SETTLEMENT SHEET</div>
                </div>

                <div class="meta-grid">
                    <div>
                        <div><b>Date:</b> ${d}</div>
                        <div><b>Cashier:</b> ${cashier}</div>
                    </div>
                    <div style="text-align: right;">
                        <div><b>Shift Started:</b> ${startTime || 'N/A'}</div>
                        <div><b>Shift Closed:</b> ${closeTime || 'N/A'} (${duration || 'N/A'})</div>
                    </div>
                </div>

                <div class="section-title">SYSTEM TRANSACTION SUMMARY</div>
                <table>
                    <tr><td>Total Bills Count</td><td style="text-align: right;">${sheet.totalBillsCount || 0} Bills</td></tr>
                    <tr><td>Gross Sales Amount</td><td style="text-align: right;">LKR ${gross}</td></tr>
                    <tr><td>Card Payments Summary</td><td style="text-align: right;">-LKR ${card}</td></tr>
                    <tr><td>Bank Transfer Summary</td><td style="text-align: right;">-LKR ${bank}</td></tr>
                    <tr><td>Credit / On Credit Summary</td><td style="text-align: right;">-LKR ${credit}</td></tr>
                    <tr><td>Cheque Summary</td><td style="text-align: right;">-LKR ${cheque}</td></tr>
                    <tr class="totals"><td>Expected Net Cash Sales</td><td style="text-align: right;">LKR ${expectedSales}</td></tr>
                </table>

                <div class="section-title">SYSTEM EXPECTED CASH (DRAWER LEDGER)</div>
                <table>
                    <tr><td>Expected Net Cash Sales</td><td style="text-align: right;">LKR ${expectedSales}</td></tr>
                    <tr><td>Expected Reloads</td><td style="text-align: right;">LKR ${reloads}</td></tr>
                    <tr><td>Expected Expenses</td><td style="text-align: right;">-LKR ${expenses}</td></tr>
                    <tr><td>Opening Cash Drawer Limit</td><td style="text-align: right;">LKR ${opening}</td></tr>
                    <tr class="totals"><td>Total Expected Cash</td><td style="text-align: right;">LKR ${expectedTotal}</td></tr>
                </table>

                ${physicalTableHtml}

                <div class="variance-box">
                    <span>Variance / Discrepancy (${statusLabel})</span>
                    <span>${discrepancyStr}</span>
                </div>

                <div class="signatures">
                    <div class="sig-line">Cashier Signature</div>
                    <div class="sig-line">Manager / Audit Signature</div>
                </div>
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
    }, 250);
};

window.resendSheetWhatsApp = async (sheetDataOrId) => {
    let sheet = sheetDataOrId;
    if (typeof sheetDataOrId === 'string') {
        sheet = (window.allCashSettlements || []).find(s => s.id === sheetDataOrId);
    }
    if (!sheet) {
        if (window.showToast) window.showToast("Sheet data not found", "error");
        return;
    }

    if (typeof window.sendShiftBalancingWhatsApp === 'function') {
        if (window.showToast) window.showToast("🚀 Sending Shift Summary to CEO WhatsApp...", "info");
        try {
            await window.sendShiftBalancingWhatsApp(sheet, true);
        } catch (e) {
            console.error("Resend WhatsApp error:", e);
            if (window.showToast) window.showToast("Failed to dispatch WhatsApp message", "error");
        }
    }
};

window.exportCashHistoryToExcel = () => {
    const list = window.allCashSettlements || [];
    if (list.length === 0) {
        if (window.showToast) window.showToast("No settlement records to export", "warning");
        return;
    }

    if (typeof XLSX === 'undefined') {
        if (window.showToast) window.showToast("Excel export library not loaded", "error");
        return;
    }

    const excelRows = list.map(s => {
        const d = s.date || '';
        const gross = parseFloat(s.grossSalesAmount || 0);
        const card = parseFloat(s.cardSalesAmount || 0);
        const bank = parseFloat(s.bankSalesAmount || 0);
        const credit = parseFloat(s.creditSalesAmount || 0);
        const netCash = parseFloat(s.expectedSales || 0);
        const reloads = parseFloat(s.expectedReloads || 0);
        const expenses = parseFloat(s.expectedExpenses || 0);
        const opening = parseFloat(s.openingCash || 0);
        const expected = parseFloat(s.expectedTotal || 0);
        const actual = parseFloat(s.actualCounted || 0);
        const discrepancy = (s.discrepancy !== undefined) ? parseFloat(s.discrepancy) : (actual - expected);

        let statusText = 'Balanced';
        if (discrepancy > 0.01) statusText = 'Surplus (Excess)';
        else if (discrepancy < -0.01) statusText = 'Shortage (Deficit)';

        return {
            "Settlement Date": d,
            "Shift Started": s.shiftStartTime || '',
            "Shift Closed": s.shiftCloseTime || '',
            "Shift Duration": s.shiftDuration || '',
            "Cashier Name": s.cashierName || '',
            "Employee ID": s.cashierEmpId || '',
            "Designation": s.cashierDesignation || '',
            "Total Bills": s.totalBillsCount || 0,
            "Gross Sales (LKR)": gross,
            "Card Sales (LKR)": card,
            "Bank Sales (LKR)": bank,
            "Credit Sales (LKR)": credit,
            "Net Cash Sales (LKR)": netCash,
            "Reloads (LKR)": reloads,
            "Expenses (LKR)": expenses,
            "Opening Drawer (LKR)": opening,
            "Expected Total Cash (LKR)": expected,
            "Actual Counted Cash (LKR)": actual,
            "Discrepancy (LKR)": discrepancy,
            "Status": statusText
        };
    });

    const ws = XLSX.utils.json_to_sheet(excelRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Shift Settlements");

    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');
    XLSX.writeFile(wb, `Cash_Balancing_History_${todayStr}.xlsx`);
    if (window.showToast) window.showToast("📥 Exported Cash Balancing History to Excel!", "success");
};

window.printCashHistoryLog = () => {
    const list = window.allCashSettlements || [];
    if (list.length === 0) {
        if (window.showToast) window.showToast("No settlement records to print", "warning");
        return;
    }

    const storeName = document.querySelector('.main')?.innerText || 'MEC BOOK SHOP';
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    let rowsHtml = list.map(s => {
        const d = s.date || '';
        const cName = s.cashierName || 'Cashier';
        const bills = s.totalBillsCount || 0;
        const gross = parseFloat(s.grossSalesAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
        const expected = parseFloat(s.expectedTotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
        const actual = parseFloat(s.actualCounted || 0).toLocaleString(undefined, {minimumFractionDigits: 2});
        const discrepancy = (s.discrepancy !== undefined) ? parseFloat(s.discrepancy) : ((parseFloat(s.actualCounted) || 0) - (parseFloat(s.expectedTotal) || 0));
        
        let status = 'Balanced';
        if (discrepancy > 0.01) status = `+${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
        else if (discrepancy < -0.01) status = `-${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})}`;

        return `
            <tr>
                <td>${d}</td>
                <td>${s.shiftStartTime || ''} - ${s.shiftCloseTime || ''}</td>
                <td>${cName}</td>
                <td style="text-align: center;">${bills}</td>
                <td style="text-align: right;">${gross}</td>
                <td style="text-align: right;">${expected}</td>
                <td style="text-align: right; font-weight: bold;">${actual}</td>
                <td style="text-align: center;">${status}</td>
            </tr>
        `;
    }).join('');

    printWindow.document.write(`
        <html>
            <head>
                <title>Cash Balancing Audit Log - ${todayStr}</title>
                <style>
                    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 25px; color: #222; font-size: 12px; }
                    .header { text-align: center; border-bottom: 2px solid #222; padding-bottom: 10px; margin-bottom: 15px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                    th, td { padding: 6px 8px; border-bottom: 1px solid #ccc; font-size: 11px; text-align: left; }
                    th { background: #f1f5f9; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>${storeName.toUpperCase()}</h2>
                    <div>CASH BALANCING SHIFT SETTLEMENT AUDIT LOG (${todayStr})</div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Shift Hours</th>
                            <th>Cashier</th>
                            <th style="text-align: center;">Bills</th>
                            <th style="text-align: right;">Gross (LKR)</th>
                            <th style="text-align: right;">Expected (LKR)</th>
                            <th style="text-align: right;">Counted (LKR)</th>
                            <th style="text-align: center;">Discrepancy</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml}
                    </tbody>
                </table>
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
    }, 250);
};
