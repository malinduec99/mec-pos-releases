import { db, storage } from '../firebase.js';
import { 
    collection, 
    addDoc, 
    getDocs, 
    setDoc,
    doc,
    query, 
    where, 
    serverTimestamp,
    orderBy,
    limit,
    onSnapshot,
    Timestamp
} from "firebase/firestore";
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";

const copilotLogsCol = collection(db, 'ai_copilot_logs');

// Load configurations from localStorage (isolated per store)
function getCurrentStoreId() {
    return (typeof window.getStoreId === 'function' ? window.getStoreId() : (sessionStorage.getItem('userStoreId') || 'mec-book-shop')).toLowerCase();
}

function getRegisteredMerchantPhone() {
    // 1. Check logged-in user phone if CEO/Owner
    const userRole = sessionStorage.getItem('userRole') || '';
    const userPhone = (sessionStorage.getItem('userPhone') || '').trim();
    if (userPhone && userPhone !== 'N/A' && !userPhone.includes('9233388') && (userRole.includes('CEO') || userRole.includes('Admin') || userRole.includes('Owner'))) {
        return userPhone;
    }

    // 2. Default for MEC Book Shop / Horana is strictly the CEO's personal WhatsApp
    const storeId = getCurrentStoreId();
    if (storeId === 'mec-book-shop' || storeId === 'master' || storeId === '1001' || storeId.includes('horana')) {
        return '0770658356';
    }

    // 3. Fallback to settings invoice phone if available (skip store landlines)
    if (window.systemConfig?.invPhone && !window.systemConfig.invPhone.includes('9233388')) {
        return window.systemConfig.invPhone;
    }

    // 4. Check store list for current merchant owner phone (skip store landlines)
    if (window.allStores && Array.isArray(window.allStores)) {
        const currentStore = window.allStores.find(s => (s.slug || '').toLowerCase() === storeId || (s.id || '').toLowerCase() === storeId);
        if (currentStore && currentStore.phone && currentStore.phone !== 'N/A' && !currentStore.phone.includes('9233388')) {
            return currentStore.phone;
        }
    }

    return '0770658356';
}

const localStorageKeys = {
    autoSmsDebt: 'ai_auto_sms_debt',
    autoPO: 'ai_auto_po',
    weeklyBrief: 'ai_weekly_brief',
    autoCeoWhatsapp: 'ai_auto_ceo_whatsapp',
    ceoPhone: 'ai_ceo_whatsapp_phone',
    aiReports: 'mecpos_ai_analyst_enabled'
};

function sanitizeCeoPhone(phone) {
    if (!phone || typeof phone !== 'string') return '0770658356';
    const cleaned = phone.trim();
    if (cleaned.includes('9233388') || cleaned === '0719233388') {
        return '0770658356';
    }
    return cleaned;
}

let initialStoredCeoPhone = localStorage.getItem(localStorageKeys.ceoPhone);
if (initialStoredCeoPhone && (initialStoredCeoPhone.includes('9233388') || initialStoredCeoPhone === '0719233388')) {
    initialStoredCeoPhone = '0770658356';
    localStorage.setItem(localStorageKeys.ceoPhone, '0770658356');
}

let copilotConfig = {
    autoSmsDebt: localStorage.getItem(localStorageKeys.autoSmsDebt) === 'true',
    autoPO: localStorage.getItem(localStorageKeys.autoPO) === 'true',
    weeklyBrief: localStorage.getItem(localStorageKeys.weeklyBrief) !== 'false',
    autoCeoWhatsapp: localStorage.getItem(localStorageKeys.autoCeoWhatsapp) !== 'false',
    ceoPhone: sanitizeCeoPhone(initialStoredCeoPhone || getRegisteredMerchantPhone() || '0770658356'),
    aiReports: localStorage.getItem(localStorageKeys.aiReports) !== 'false'
};

// Setup Firebase Listener & Realtime Sync across devices
let isFirebaseCopilotSynced = false;

function setupFirebaseCopilotSync() {
    if (isFirebaseCopilotSynced) return;
    isFirebaseCopilotSynced = true;

    try {
        const storeId = getCurrentStoreId();
        // Listen to merchant-specific store config if not master, else appConfig/copilot
        const docRef = (storeId === 'mec-book-shop' || storeId === 'master') 
            ? doc(db, 'appConfig', 'copilot')
            : doc(db, 'config', storeId);

        onSnapshot(docRef, (snapshot) => {
            if (snapshot.exists()) {
                const data = snapshot.data();
                if (data.autoSmsDebt !== undefined) {
                    copilotConfig.autoSmsDebt = !!data.autoSmsDebt;
                    localStorage.setItem(localStorageKeys.autoSmsDebt, data.autoSmsDebt);
                }
                if (data.autoPO !== undefined) {
                    copilotConfig.autoPO = !!data.autoPO;
                    localStorage.setItem(localStorageKeys.autoPO, data.autoPO);
                }
                if (data.weeklyBrief !== undefined) {
                    copilotConfig.weeklyBrief = !!data.weeklyBrief;
                    localStorage.setItem(localStorageKeys.weeklyBrief, data.weeklyBrief);
                }
                if (data.autoCeoWhatsapp !== undefined) {
                    copilotConfig.autoCeoWhatsapp = !!data.autoCeoWhatsapp;
                    localStorage.setItem(localStorageKeys.autoCeoWhatsapp, data.autoCeoWhatsapp);
                }
                const remoteCeoPhone = sanitizeCeoPhone(data.ceoPhone || data.copilot_ceoPhone);
                if (remoteCeoPhone) {
                    copilotConfig.ceoPhone = remoteCeoPhone;
                    localStorage.setItem(localStorageKeys.ceoPhone, remoteCeoPhone);
                } else if (!copilotConfig.ceoPhone) {
                    copilotConfig.ceoPhone = getRegisteredMerchantPhone();
                }

                const smsCheck = document.getElementById('copilot-auto-sms');
                if (smsCheck) smsCheck.checked = copilotConfig.autoSmsDebt;
                const poCheck = document.getElementById('copilot-auto-po');
                if (poCheck) poCheck.checked = copilotConfig.autoPO;
                const waCheck = document.getElementById('copilot-auto-whatsapp-ceo');
                if (waCheck) waCheck.checked = copilotConfig.autoCeoWhatsapp;
                const phoneInp = document.getElementById('copilot-ceo-phone-input');
                if (phoneInp && copilotConfig.ceoPhone) phoneInp.value = copilotConfig.ceoPhone;
            } else {
                // If no config saved yet, assign merchant registered phone
                if (!copilotConfig.ceoPhone) {
                    copilotConfig.ceoPhone = getRegisteredMerchantPhone();
                    const phoneInp = document.getElementById('copilot-ceo-phone-input');
                    if (phoneInp && copilotConfig.ceoPhone) phoneInp.value = copilotConfig.ceoPhone;
                }
            }
        }, (err) => {
            console.warn("Copilot Firebase sync warning:", err);
        });
    } catch(e) {
        console.error("Copilot Firebase sync error:", e);
    }
}

// Immediately attempt sync on script load
setupFirebaseCopilotSync();

window.initAICopilot = () => {
    setupFirebaseCopilotSync();
    window.currentCopilotTab = 'dashboard';
    renderAICopilotUI();
    loadCopilotLogs();
    
    // Automatically run silent background check on portal load and every 10 minutes thereafter
    setTimeout(() => {
        runSilentDiagnostics();
    }, 5000);

    if (!window._copilotDiagnosticsInterval) {
        window._copilotDiagnosticsInterval = setInterval(() => {
            runSilentDiagnostics();
        }, 10 * 60 * 1000); // Check every 10 mins
    }
};

window.setCopilotTab = (tabName) => {
    window.currentCopilotTab = tabName;
    renderAICopilotUI();
    if (tabName === 'dashboard') {
        loadCopilotLogs();
    } else {
        loadSMSLogsReport();
    }
};

// Expose status toggles to window with Firebase & Local Storage dual saving
window.toggleCopilotFeature = async (key, checkbox) => {
    const isChecked = checkbox.checked;
    copilotConfig[key] = isChecked;
    
    // 1. Save to LocalStorage
    localStorage.setItem(localStorageKeys[key] || `ai_${key}`, isChecked);
    
    // 2. Save to Firebase Cloud Settings
    try {
        const docRef = doc(db, 'appConfig', 'copilot');
        await setDoc(docRef, { [key]: isChecked, updatedAt: serverTimestamp() }, { merge: true });
        
        const storeId = window.getStoreId ? window.getStoreId() : 'mec-book-shop';
        if (storeId) {
            const storeDocRef = doc(db, 'config', storeId);
            await setDoc(storeDocRef, { [`copilot_${key}`]: isChecked }, { merge: true }).catch(() => {});
        }
        window.showToast(`🤖 AI Copilot: ${key} saved to Firebase & Local Storage (${isChecked ? 'ON' : 'OFF'})`, "success");
    } catch(e) {
        console.error("Error saving Copilot setting to Firebase:", e);
        window.showToast(`🤖 AI Copilot: Saved locally (${isChecked ? 'ON' : 'OFF'})`, "info");
    }
    
    renderAICopilotUI();
};

function renderAICopilotUI() {
    const section = document.getElementById('section-ai-copilot');
    if (!section) return;

    if (!window.currentCopilotTab) window.currentCopilotTab = 'dashboard';

    let headerHTML = `
        <div class="it-header-actions" style="margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin:0; font-size: 1.8rem; font-weight: 900; color: #fff;">🤖 Autonomous AI Business Copilot</h2>
                <p style="color:var(--text-muted); font-size:0.85rem; margin-top: 5px;">Fully autonomous background agent making decisions to optimize sales, recovery, and restocking.</p>
            </div>
            <button onclick="window.runInteractiveDiagnostic()" class="action-btn primary large" style="background: #a855f7; border-radius: 12px; font-weight: 800; font-size: 0.9rem; padding: 10px 24px; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(168, 85, 247, 0.4);">
                <span>🚀</span> Run Manual AI Audit
            </button>
        </div>

        <!-- Copilot Internal Tabs -->
        <div style="display: flex; gap: 10px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; margin-bottom: 25px;">
            <button onclick="window.setCopilotTab('dashboard')" style="padding: 8px 20px; border-radius: 10px; border: none; font-weight: 800; font-size: 0.85rem; cursor: pointer; transition: all 0.2s; 
                ${window.currentCopilotTab === 'dashboard' ? 'background: #a855f7; color: white; box-shadow: 0 4px 12px rgba(168, 85, 247, 0.3);' : 'background: rgba(255,255,255,0.03); color: #cbd5e1;' }">
                ⚙️ Config & Dashboard
            </button>
            <button onclick="window.setCopilotTab('sms_report')" style="padding: 8px 20px; border-radius: 10px; border: none; font-weight: 800; font-size: 0.85rem; cursor: pointer; transition: all 0.2s; 
                ${window.currentCopilotTab === 'sms_report' ? 'background: #a855f7; color: white; box-shadow: 0 4px 12px rgba(168, 85, 247, 0.3);' : 'background: rgba(255,255,255,0.03); color: #cbd5e1;' }">
                📲 SMS History Report
            </button>
        </div>
    `;

    let mainContentHTML = '';
    if (window.currentCopilotTab === 'dashboard') {
        mainContentHTML = `
            <div style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 2.5rem; margin-top: 1rem;">
                <!-- Left Side: Config & Status -->
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div class="card glass-card" style="padding: 24px; border: 1px solid rgba(168, 85, 247, 0.2); background: linear-gradient(135deg, rgba(168, 85, 247, 0.03), rgba(15, 23, 42, 0.8));">
                        <h3 style="margin-top: 0; color: #c084fc; font-weight: 800; font-size: 1.2rem; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; margin-bottom: 20px;">⚙️ Automation Settings</h3>
                        
                        <div style="display: flex; flex-direction: column; gap: 20px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.02); padding: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                                <div>
                                    <div style="font-weight: 800; color: #fff; font-size: 0.95rem;">Auto-SMS Debt Reminders</div>
                                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">Automatically text clients with unpaid credit balances.</div>
                                </div>
                                <label class="switch-container" style="position: relative; display: inline-block; width: 46px; height: 24px;">
                                    <input type="checkbox" id="copilot-auto-sms" ${copilotConfig.autoSmsDebt ? 'checked' : ''} onchange="window.toggleCopilotFeature('autoSmsDebt', this)" style="opacity: 0; width: 0; height: 0;">
                                    <span class="slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(255,255,255,0.1); transition: .3s; border-radius: 34px;"></span>
                                </label>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.02); padding: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                                <div>
                                    <div style="font-weight: 800; color: #fff; font-size: 0.95rem;">Auto-Inventory PO Generation</div>
                                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">Monitor stock levels and draft reorders for suppliers.</div>
                                </div>
                                <label class="switch-container" style="position: relative; display: inline-block; width: 46px; height: 24px;">
                                    <input type="checkbox" id="copilot-auto-po" ${copilotConfig.autoPO ? 'checked' : ''} onchange="window.toggleCopilotFeature('autoPO', this)" style="opacity: 0; width: 0; height: 0;">
                                    <span class="slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(255,255,255,0.1); transition: .3s; border-radius: 34px;"></span>
                                </label>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, rgba(37, 211, 102, 0.08), rgba(255,255,255,0.02)); padding: 15px; border-radius: 12px; border: 1px solid rgba(37, 211, 102, 0.2);">
                                <div>
                                    <div style="font-weight: 800; color: #25d366; font-size: 0.95rem; display: flex; align-items: center; gap: 6px;">
                                        <span>📲</span> Nightly CEO SMS & PDF Financial Brief (11:30 PM)
                                    </div>
                                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">Auto-generate executive closing PDF & send financial SMS summary with PDF download link to CEO at 11:30 PM daily.</div>
                                </div>
                                <label class="switch-container" style="position: relative; display: inline-block; width: 46px; height: 24px;">
                                    <input type="checkbox" id="copilot-auto-whatsapp-ceo" ${copilotConfig.autoCeoWhatsapp ? 'checked' : ''} onchange="window.toggleCopilotFeature('autoCeoWhatsapp', this)" style="opacity: 0; width: 0; height: 0;">
                                    <span class="slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(255,255,255,0.1); transition: .3s; border-radius: 34px;"></span>
                                </label>
                            </div>

                            <div style="background: rgba(255,255,255,0.02); padding: 12px 15px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.05); display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                                <span style="font-size: 0.75rem; color: #38bdf8; font-weight: 800; white-space: nowrap;">CEO PHONE:</span>
                                <input type="text" id="copilot-ceo-phone-input" value="${copilotConfig.ceoPhone}" placeholder="0770658356" class="form-input" style="padding: 6px 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: #fff; font-weight: 700; font-size: 0.85rem; flex: 1; min-width: 140px;" onchange="window.updateCeoWhatsappPhone(this.value)">
                                <button onclick="window.downloadTodayDailyPDF()" class="action-btn" style="background: rgba(56, 189, 248, 0.2); border: 1px solid rgba(56, 189, 248, 0.4); color: #38bdf8; font-weight: 800; font-size: 0.75rem; padding: 6px 12px; border-radius: 8px; white-space: nowrap;">
                                    📄 Export PDF
                                </button>
                                <button onclick="window.sendManualCeoDailyWhatsAppReport()" class="action-btn" style="background: #25d366; color: white; font-weight: 800; font-size: 0.75rem; padding: 6px 14px; border-radius: 8px; white-space: nowrap;">
                                    🚀 Test Send Now
                                </button>
                                <button onclick="window.resendYesterdayMorningBrief()" class="action-btn" style="background: linear-gradient(135deg, #f59e0b, #d97706); color: white; font-weight: 800; font-size: 0.75rem; padding: 6px 14px; border-radius: 8px; white-space: nowrap; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);">
                                    🌅 Resend Yesterday Brief SMS (Firebase Sync)
                                </button>
                            </div>

                            <!-- AI Smart Financial Analyst (Reports Panel) Switch -->
                            <div style="display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, rgba(168, 85, 247, 0.08), rgba(255,255,255,0.02)); padding: 15px; border-radius: 12px; border: 1px solid rgba(168, 85, 247, 0.25); margin-top: 5px;">
                                <div>
                                    <div style="font-weight: 800; color: #c084fc; font-size: 0.95rem; display: flex; align-items: center; gap: 6px;">
                                        <span>🤖</span> AI Smart Financial Analyst (Reports Audit)
                                    </div>
                                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">Automated GPT financial diagnostics panel in Financial Reports. When turned OFF, the entire AI box &amp; logo are completely hidden.</div>
                                </div>
                                <label class="switch-container" style="position: relative; display: inline-block; width: 46px; height: 24px;">
                                    <input type="checkbox" id="copilot-ai-reports-toggle" ${copilotConfig.aiReports ? 'checked' : ''} onchange="window.toggleAIFinancialAnalyst(this.checked)" style="opacity: 0; width: 0; height: 0;">
                                    <span class="slider" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: ${copilotConfig.aiReports ? '#a855f7' : 'rgba(255,255,255,0.1)'}; transition: .3s; border-radius: 34px;"></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="card glass-card" style="padding: 24px; background: rgba(15, 23, 42, 0.4);">
                        <h3 style="margin-top: 0; font-weight: 800; font-size: 1.1rem; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 10px; margin-bottom: 15px;">📊 Key Insights Overview</h3>
                        <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.85rem; color: #cbd5e1;">
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color:#94a3b8;">Total Outstanding Debt:</span>
                                <strong id="copilot-stat-debt" style="color: #ef4444;">LKR 0.00</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color:#94a3b8;">Low Stock Warning Items:</span>
                                <strong id="copilot-stat-lowstock" style="color: #f59e0b;">0 Items</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color:#94a3b8;">System AI Engine:</span>
                                <strong style="color: #10b981;">GPT-4o-mini / Gemini-2.5</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Side: Action Log & Timeline -->
                <div class="card glass-card" style="padding: 24px; display: flex; flex-direction: column; min-height: 450px;">
                    <h3 style="margin-top: 0; font-weight: 800; font-size: 1.2rem; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                        <span>📜 Copilot Decision Log</span>
                        <span style="font-size: 0.75rem; color: #10b981; font-weight: bold; background: rgba(16, 185, 129, 0.1); padding: 4px 10px; border-radius: 20px;">Agent Running Silently</span>
                    </h3>

                    <div id="copilot-log-timeline" style="flex-grow: 1; display: flex; flex-direction: column; gap: 15px; max-height: 480px; overflow-y: auto;">
                        <div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">
                            <span>⏳ Loading decision timeline...</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    } else {
        mainContentHTML = `
            <div class="card glass-card" style="padding: 24px; min-height: 450px;">
                <h3 style="margin-top: 0; font-weight: 800; font-size: 1.2rem; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 10px; margin-bottom: 20px;">
                    📲 SMS Sent History & Reports
                </h3>
                <div id="sms-report-list" style="overflow-x: auto; max-height: 520px;">
                    <div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">
                        <span>⏳ Loading SMS report data...</span>
                    </div>
                </div>
            </div>
        `;
    }

    section.innerHTML = headerHTML + mainContentHTML;

    // Inject switch slider styling rules
    if (!document.getElementById('copilot-switch-css')) {
        const style = document.createElement('style');
        style.id = 'copilot-switch-css';
        style.textContent = `
            .switch-container {
                position: relative;
                display: inline-block;
                width: 48px;
                height: 26px;
                flex-shrink: 0;
            }
            .switch-container input {
                opacity: 0;
                width: 0;
                height: 0;
            }
            .switch-container .slider {
                position: absolute;
                cursor: pointer;
                top: 0; left: 0; right: 0; bottom: 0;
                background-color: #334155;
                transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
                border-radius: 34px;
                border: 1px solid rgba(255,255,255,0.1);
            }
            .switch-container .slider:before {
                position: absolute;
                content: "";
                height: 18px;
                width: 18px;
                left: 3px;
                bottom: 3px;
                background-color: #ffffff;
                transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
                border-radius: 50%;
                box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            }
            .switch-container input:checked + .slider {
                background-color: #10b981;
                border-color: #10b981;
                box-shadow: 0 0 12px rgba(16, 185, 129, 0.4);
            }
            .switch-container input:checked + .slider:before {
                transform: translateX(22px);
                background-color: #ffffff;
            }
        `;
        document.head.appendChild(style);
    }

    calculateCopilotMetrics();
}

async function calculateCopilotMetrics() {
    try {
        // Outstanding Debt calculation
        const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
        let targetRecords = [];
        const shopRecs = (window.allOrders || []).filter(o => 
            o.paymentMethod === 'Credit' && !o.repairJobId && o.status !== 'Void' && o.status !== 'Cancelled' && (o.storeId === storeId || storeId === 'master')
        );
        const repairRecs = (window.allOrders || []).filter(o => 
            o.paymentMethod === 'Credit' && o.repairJobId && o.status !== 'Void' && o.status !== 'Cancelled' && (o.storeId === storeId || storeId === 'master')
        );
        const reloadRecs = (window.allReloads || []).filter(o => 
            o.payMode === 'Credit' && o.status !== 'Void' && o.status !== 'Cancelled' && (o.storeId === storeId || storeId === 'master')
        );
        targetRecords = [...shopRecs, ...repairRecs, ...reloadRecs];

        let totalOutstanding = 0;
        if (window.allCustomers) {
            window.allCustomers.forEach(c => {
                const myRecords = targetRecords.filter(o => {
                    if (o.customerId) return o.customerId === c.docId;
                    const cleanCustPhone = (c.phone || "").replace(/[\s-]/g, "");
                    const cleanOrderPhone = (o.phone || "").replace(/[\s-]/g, "");
                    return cleanCustPhone !== "" && cleanCustPhone === cleanOrderPhone;
                });
                const outstanding = myRecords.reduce((sum, o) => {
                    const billTotal = o.total || o.amount || 0;
                    const paid = (o.paymentMethod === 'Credit' || o.payMode === 'Credit') ? (o.tenderedAmount || 0) : 0;
                    return sum + Math.max(0, billTotal - paid);
                }, 0);
                totalOutstanding += outstanding;
            });
        }

        const debtEl = document.getElementById('copilot-stat-debt');
        if (debtEl) debtEl.innerText = `LKR ${totalOutstanding.toLocaleString(undefined, {minimumFractionDigits: 2})}`;

        // Low stock warning items count
        let lowStockCount = 0;
        if (window.allProducts) {
            lowStockCount = window.allProducts.filter(p => (parseFloat(p.stock) || 0) <= 10).length;
        }
        const lowEl = document.getElementById('copilot-stat-lowstock');
        if (lowEl) lowEl.innerText = `${lowStockCount} Items`;
    } catch (err) {
        console.error(err);
    }
}

function loadCopilotLogs() {
    const timeline = document.getElementById('copilot-log-timeline');
    if (!timeline) return;

    const currentStoreId = window.getStoreId ? window.getStoreId() : 'mec-book-shop';

    const renderLogs = (docSnaps) => {
        const timelineCheck = document.getElementById('copilot-log-timeline');
        if (!timelineCheck) return;

        let docs = docSnaps.map(d => ({ docId: d.id, ...d.data() }));

        // Store filtering
        if (currentStoreId && currentStoreId !== 'master') {
            docs = docs.filter(l => !l.storeId || l.storeId === currentStoreId || l.storeId === 'mec-book-shop' || l.storeId === '1001');
        }

        // Sort descending
        docs.sort((a, b) => {
            const tA = a.timestamp?.seconds ? a.timestamp.seconds : (new Date(a.date || 0).getTime() / 1000) || 0;
            const tB = b.timestamp?.seconds ? b.timestamp.seconds : (new Date(b.date || 0).getTime() / 1000) || 0;
            return tB - tA;
        });

        if (docs.length === 0) {
            timelineCheck.innerHTML = `
                <div style="text-align: center; color: var(--text-muted); padding: 3rem 0; font-size: 0.9rem;">
                    <span>🤖 No decisions logged yet. The copilot will add actions here as they occur.</span>
                </div>
            `;
            return;
        }

        timelineCheck.innerHTML = docs.slice(0, 20).map(l => {
            const time = l.timestamp?.seconds ? new Date(l.timestamp.seconds * 1000).toLocaleString() : (l.date || 'Just now');
            let color = '#a855f7';
            if (l.type === 'SMS') color = '#10b981';
            if (l.type === 'PO') color = '#f59e0b';
            if (l.type === 'DIAG') color = '#0ea5e9';

            return `
                <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; display: flex; gap: 15px; align-items: flex-start;">
                    <div style="background: ${color}20; color: ${color}; width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0;">
                        ${l.type === 'SMS' ? '💬' : (l.type === 'PO' ? '📦' : '⚙️')}
                    </div>
                    <div style="flex-grow: 1;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                            <span style="font-weight: 800; color: #fff; font-size: 0.9rem;">${l.title || 'Decision'}</span>
                            <span style="font-size: 0.7rem; color: #64748b;">${time}</span>
                        </div>
                        <p style="margin: 0; color: #cbd5e1; font-size: 0.8rem; line-height: 1.5;">${l.description}</p>
                    </div>
                </div>
            `;
        }).join('');
    };

    try {
        const qSimple = query(copilotLogsCol, limit(50));
        onSnapshot(qSimple, (snapshot) => {
            renderLogs(snapshot.docs);
        }, (err) => {
            console.warn("Copilot logs snapshot warning:", err);
            getDocs(query(copilotLogsCol, limit(50)))
                .then(snap => renderLogs(snap.docs))
                .catch(() => {
                    timeline.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">🤖 No decision logs recorded yet.</div>`;
                });
        });
    } catch(e) {
        console.error("loadCopilotLogs error:", e);
        timeline.innerHTML = `<div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">🤖 No decision logs recorded yet.</div>`;
    }
}

async function loadSMSLogsReport() {
    const listContainer = document.getElementById('sms-report-list');
    if (!listContainer) return;
    
    listContainer.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">
            <span>⏳ Loading SMS report data...</span>
        </div>
    `;

    try {
        const currentStoreId = window.getStoreId ? window.getStoreId() : 'mec-book-shop';
        const snapshot = await getDocs(query(copilotLogsCol, limit(100)));
        let docs = snapshot.docs.map(docSnap => ({ docId: docSnap.id, ...docSnap.data() })).filter(l => l.type === 'SMS');

        if (currentStoreId && currentStoreId !== 'master') {
            docs = docs.filter(l => !l.storeId || l.storeId === currentStoreId || l.storeId === 'mec-book-shop' || l.storeId === '1001');
        }

        docs.sort((a, b) => {
            const tA = a.timestamp?.seconds || 0;
            const tB = b.timestamp?.seconds || 0;
            return tB - tA;
        });

        if (docs.length === 0) {
            listContainer.innerHTML = `
                <div style="text-align: center; color: var(--text-muted); padding: 4rem 0; font-size: 0.95rem;">
                    <span>📲 No SMS logs found for this branch.</span>
                </div>
            `;
            return;
        }

        let html = `
            <table class="admin-table" style="width:100%; border-collapse:collapse; text-align:left; font-size:0.9rem; color:#cbd5e1;">
                <thead>
                    <tr style="border-bottom:1px solid rgba(255,255,255,0.08); color:#94a3b8; font-weight:800;">
                        <th style="padding:15px 10px;">Customer Name</th>
                        <th style="padding:15px 10px;">Phone Number</th>
                        <th style="padding:15px 10px;">Message Details</th>
                        <th style="padding:15px 10px;">Sent Time</th>
                    </tr>
                </thead>
                <tbody>
        `;

        docs.forEach(l => {
            const time = l.timestamp?.seconds ? new Date(l.timestamp.seconds * 1000).toLocaleString() : 'Just now';
            
            let cleanPhone = l.phone || '';
            let custName = l.customerName || 'Unknown';
            if (!cleanPhone && l.description) {
                const match = l.description.match(/\(([^)]+)\)/);
                if (match) cleanPhone = match[1];
            }
            if (custName === 'Unknown' && l.description) {
                const match = l.description.match(/sent to ([^\(]+)/);
                if (match) custName = match[1].trim();
            }

            let messageText = l.description || '';
            messageText = messageText.replace('Silent automated SMS sent to ', '');
            messageText = messageText.replace('Branded SMS successfully dispatched to ', '');
            
            html += `
                <tr style="border-bottom:1px solid rgba(255,255,255,0.04); transition:background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.02)';" onmouseout="this.style.background='transparent';">
                    <td style="padding:15px 10px; font-weight:800; color:#fff;">${custName}</td>
                    <td style="padding:15px 10px; font-family:monospace; color:#38bdf8;">${cleanPhone}</td>
                    <td style="padding:15px 10px; color:#cbd5e1; line-height:1.4; max-width:300px; word-break:break-word;">${messageText}</td>
                    <td style="padding:15px 10px; color:#94a3b8; font-size:0.8rem;">${time}</td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;
        listContainer.innerHTML = html;

    } catch (err) {
        console.error("SMS Report load failed:", err);
        listContainer.innerHTML = `
            <div style="text-align: center; color: var(--text-muted); padding: 3rem 0;">
                <span>📲 No SMS report data recorded yet.</span>
            </div>
        `;
    }
}

// Background Silent Diagnostics
async function runSilentDiagnostics() {
    if (!copilotConfig.autoSmsDebt && !copilotConfig.autoPO && !copilotConfig.autoCeoWhatsapp) return;
    
    try {
        const storeId = window.getStoreId();
        
        // 1. Process Silent Debt Recovery SMS Reminders
        if (copilotConfig.autoSmsDebt && window.allCustomers) {
            // Find customers with unpaid credits
            const shopRecs = (window.allOrders || []).filter(o => 
                o.paymentMethod === 'Credit' && !o.repairJobId && o.status !== 'Void' && o.status !== 'Cancelled' && o.storeId === storeId
            );
            
            for (const c of window.allCustomers) {
                const myRecords = shopRecs.filter(o => o.customerId === c.docId || (o.phone && o.phone === c.phone));
                const outstanding = myRecords.reduce((sum, o) => sum + (o.total - (o.tenderedAmount || 0)), 0);
                
                if (outstanding > 100) {
                    // Check if we already sent a log reminder to this customer recently
                    let recentLogsDocs = [];
                    try {
                        const recentQS = query(copilotLogsCol, where('storeId', '==', storeId), where('customerId', '==', c.docId));
                        const recentLogs = await getDocs(recentQS);
                        recentLogsDocs = recentLogs.docs.map(d => d.data()).filter(l => l.type === 'SMS');
                        recentLogsDocs.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
                    } catch (err) {
                        console.warn("Copilot recent SMS query warning:", err);
                    }
                    
                    let canSend = true;
                    if (recentLogsDocs.length > 0) {
                        const lastLog = recentLogsDocs[0];
                        const hoursSinceLast = (Date.now() - ((lastLog.timestamp?.seconds || 0) * 1000)) / (1000 * 60 * 60);
                        
                        // Seed random offset based on customer doc ID to keep it consistent but randomized per client
                        let offsetHours = 0;
                        if (c.docId) {
                            let hash = 0;
                            for (let i = 0; i < c.docId.length; i++) {
                                hash = c.docId.charCodeAt(i) + ((hash << 5) - hash);
                            }
                            offsetHours = Math.abs(hash) % 73; // 0 to 72 hours offset (up to 3 days extra)
                        }
                        
                        const requiredInterval = 24 + offsetHours; // Minimum 1 day (24h), max 4 days (96h)
                        if (hoursSinceLast < requiredInterval) canSend = false;
                    }

                    if (canSend) {
                        const storeName = document.querySelector('.main')?.innerText || "MEC Book Shop";
                        const msg = typeof window.getRandomReminderMessage === 'function'
                            ? window.getRandomReminderMessage(c.name, storeName, outstanding)
                            : `Halo ${c.name},\n\nFriendly payment reminder from *${storeName}*.\n\nYour current outstanding balance is *LKR ${outstanding.toLocaleString()}*.\n\nWe kindly request you to settle this amount. Thank you!`;
                        
                        // Send direct SMS silently
                        if (window.sendDirectSMS) {
                            await window.sendDirectSMS(c.phone, msg);
                            await addDoc(copilotLogsCol, {
                                type: 'SMS',
                                title: `Sent Debt Reminder SMS`,
                                description: `Silent automated SMS sent to ${c.name} (${c.phone}) regarding LKR ${outstanding.toLocaleString()} outstanding balance.`,
                                customerId: c.docId,
                                storeId,
                                timestamp: serverTimestamp()
                            });
                        }
                    }
                }
            }
        }

        // 2. Process Auto PO generation diagnostics
        if (copilotConfig.autoPO && window.allProducts) {
            const lowStockProducts = window.allProducts.filter(p => (parseFloat(p.stock) || 0) <= 5);
            for (const p of lowStockProducts) {
                // Check if reorder log has been generated recently
                let recentPODocs = [];
                try {
                    const recentPOQS = query(copilotLogsCol, where('storeId', '==', storeId), where('productId', '==', p.docId));
                    const recentPOLogs = await getDocs(recentPOQS);
                    recentPODocs = recentPOLogs.docs.map(d => d.data()).filter(l => l.type === 'PO');
                    recentPODocs.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
                } catch (err) {
                    console.warn("Copilot recent PO query warning:", err);
                }
                
                let canCreate = true;
                if (recentPODocs.length > 0) {
                    const lastLog = recentPODocs[0];
                    const daysSinceLast = (Date.now() - ((lastLog.timestamp?.seconds || 0) * 1000)) / (1000 * 60 * 60 * 24);
                    if (daysSinceLast < 7) canCreate = false; // Only once a week per product
                }

                if (canCreate) {
                    const reorderQty = 50; // default reorder batch size
                    const supplier = p.supplierName || 'General';
                    
                    await addDoc(copilotLogsCol, {
                        type: 'PO',
                        title: `Reorder Recommendation Generated`,
                        description: `Autonomous inventory audit suggests purchasing ${reorderQty} units of '${p.name}' (SKU: ${p.sku}) from Supplier: ${supplier} since current stock is low (${p.stock}).`,
                        productId: p.docId,
                        storeId,
                        timestamp: serverTimestamp()
                    });
                }
            }
        }
        // 3. Process Automated Nightly CEO WhatsApp Financial Brief (Evening/Night only)
        if (copilotConfig.autoCeoWhatsapp) {
            await checkAndDispatchCeoNightlyWhatsApp();
        }
        // 4. Automated Morning CEO Brief SMS is dispatched strictly once upon morning app login via auth.js
    } catch (e) {
        console.error("Silent diagnostics error:", e);
    }
}

window.updateCeoWhatsappPhone = async (phone) => {
    const storeId = getCurrentStoreId();
    copilotConfig.ceoPhone = phone.trim();
    localStorage.setItem(localStorageKeys.ceoPhone, copilotConfig.ceoPhone);
    try {
        if (storeId === 'mec-book-shop' || storeId === 'master') {
            const docRef = doc(db, 'appConfig', 'copilot');
            await setDoc(docRef, { ceoPhone: copilotConfig.ceoPhone }, { merge: true });
        }
        const storeDocRef = doc(db, 'config', storeId);
        await setDoc(storeDocRef, { 
            ceoPhone: copilotConfig.ceoPhone,
            copilot_ceoPhone: copilotConfig.ceoPhone 
        }, { merge: true });
    } catch (e) {
        console.warn("Could not sync CEO phone to cloud config:", e);
    }
    window.showToast("📱 CEO WhatsApp/SMS Phone Number Updated!", "success");
};

/**
 * Builds clean, executive WhatsApp brief with emoji formatting and key financial KPIs
 */
export function buildCeoWhatsAppBriefText() {
    const orders = window.allOrders || [];
    const expenses = window.allExpenses || [];
    const income = window.allIncome || [];
    const products = window.allProducts || [];
    const customers = window.allCustomers || [];

    const todayStr = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().split('T')[0] : (o.date || '');
        return d === todayStr && o.status !== 'Void';
    });

    const todayGrossRevenue = todayOrders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
    const todayOrderCount = todayOrders.length;

    // Calculate Estimated Daily Profit & Top Products
    let todayTotalCost = 0;
    const itemMap = {};
    todayOrders.forEach(o => {
        (o.items || []).forEach(item => {
            const qty = parseFloat(item.quantity) || 1;
            let cost = parseFloat(item.costPrice || item.buyingPrice || item.cost || 0);
            if (!cost) {
                const prod = products.find(p => p.docId === item.docId || p.sku === item.sku);
                if (prod) cost = parseFloat(prod.cost || prod.buyingPrice) || 0;
            }
            todayTotalCost += (cost * qty);

            const name = item.name || 'Product';
            if (!itemMap[name]) itemMap[name] = 0;
            itemMap[name] += qty;
        });
    });

    const estimatedNetProfit = Math.max(0, todayGrossRevenue - todayTotalCost);
    const profitMargin = todayGrossRevenue > 0 ? ((estimatedNetProfit / todayGrossRevenue) * 100).toFixed(1) : "0.0";

    // Top Selling Items Today
    const topItems = Object.entries(itemMap).sort((a, b) => b[1] - a[1]).slice(0, 3);
    const topItemsText = topItems.length > 0 
        ? topItems.map(([name, qty], idx) => `   ${idx + 1}. *${name}* (${qty} pcs)`).join('\n')
        : '   (No items sold today yet)';

    // Total Outstanding Credit
    const totalCreditDebt = customers.reduce((acc, c) => acc + (parseFloat(c.creditBalance || c.outstanding || 0)), 0);

    const storeName = document.querySelector('.main')?.innerText || 'MEC BOOK SHOP';
    const nowFormatted = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    return `📊 *MEC POS — CEO EXECUTIVE DAILY FINANCIAL BRIEF* 📊\n` +
           `🏛️ Store: *${storeName.toUpperCase()}*\n` +
           `📅 Date: *${todayStr}* (${nowFormatted})\n` +
           `────────────────────────\n` +
           `💰 Daily Gross Revenue: *LKR ${todayGrossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}*\n` +
           `📈 Estimated Gross Profit: *LKR ${estimatedNetProfit.toLocaleString(undefined, {minimumFractionDigits: 2})} (${profitMargin}% Margin)*\n` +
           `🧾 Invoices / Orders Count: *${todayOrderCount} Bills*\n` +
           `👥 Total Market Debt (Receivables): *LKR ${totalCreditDebt.toLocaleString(undefined, {minimumFractionDigits: 2})}*\n` +
           `────────────────────────\n` +
           `🏆 *Top Selling Products Today:*\n${topItemsText}\n` +
           `────────────────────────\n` +
           `🤖 *AI Virtual CFO Summary:*\n` +
           `${todayGrossRevenue > 0 ? '✅ Healthy business cash flow observed today with positive gross margin.' : 'ℹ️ No sales records logged for today so far.'}\n\n` +
           `_Generated autonomously by MEC POS AI Copilot_ 🚀`;
}

/**
 * Generates an executive daily financial report HTML element for PDF export
 */
export function buildDailyExecutivePDFElement(dateStr) {
    const orders = window.allOrders || [];
    const products = window.allProducts || [];
    const customers = window.allCustomers || [];
    const targetDate = dateStr || new Date().toISOString().split('T')[0];

    const todayOrders = orders.filter(o => {
        const d = o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toISOString().split('T')[0] : (o.date || '');
        return d === targetDate && o.status !== 'Void' && o.status !== 'Cancelled';
    });

    const grossRevenue = todayOrders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
    const orderCount = todayOrders.length;

    let totalCost = 0;
    const itemMap = {};
    const paymentMap = { Cash: 0, Card: 0, Credit: 0, Bank: 0, Other: 0 };

    todayOrders.forEach(o => {
        // Payment breakdown
        const method = (o.paymentMethod || 'Cash');
        if (paymentMap[method] !== undefined) {
            paymentMap[method] += (parseFloat(o.total) || 0);
        } else {
            paymentMap.Other += (parseFloat(o.total) || 0);
        }

        (o.items || []).forEach(item => {
            const qty = parseFloat(item.quantity) || 1;
            let cost = parseFloat(item.costPrice || item.buyingPrice || item.cost || 0);
            if (!cost) {
                const prod = products.find(p => p.docId === item.docId || p.sku === item.sku);
                if (prod) cost = parseFloat(prod.cost || prod.buyingPrice) || 0;
            }
            totalCost += (cost * qty);

            const name = item.name || 'Product';
            if (!itemMap[name]) itemMap[name] = { qty: 0, revenue: 0 };
            itemMap[name].qty += qty;
            itemMap[name].revenue += ((parseFloat(item.price) || 0) * qty);
        });
    });

    const netProfit = Math.max(0, grossRevenue - totalCost);
    const profitMargin = grossRevenue > 0 ? ((netProfit / grossRevenue) * 100).toFixed(1) : "0.0";
    const totalCreditDebt = customers.reduce((acc, c) => acc + (parseFloat(c.creditBalance || c.outstanding || 0)), 0);

    const sortedItems = Object.entries(itemMap).sort((a, b) => b[1].qty - a[1].qty).slice(0, 5);

    const storeName = document.querySelector('.main')?.innerText || (window.systemConfig?.invPhone ? 'MEC POS Store' : 'MEC Book Shop');
    const storeAddress = window.systemConfig?.invAddress || 'Main Branch, Sri Lanka';
    const storePhone = window.systemConfig?.invPhone || '0770658356';
    const generatedTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });

    const container = document.createElement('div');
    container.id = 'executive-daily-report-canvas';
    container.style.cssText = 'width: 800px; padding: 30px; background: #ffffff; color: #1e293b; font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif; box-sizing: border-box;';

    container.innerHTML = `
        <div style="border-bottom: 2px solid #0f172a; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-end;">
            <div>
                <h1 style="margin: 0; font-size: 24px; color: #0f172a; text-transform: uppercase; font-weight: 900; letter-spacing: 0.5px;">${storeName}</h1>
                <p style="margin: 3px 0 0 0; font-size: 11px; color: #64748b;">${storeAddress} | Tel: ${storePhone}</p>
                <div style="margin-top: 6px; display: inline-block; background: #0f172a; color: #ffffff; font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">
                    Nightly Executive Financial Closing Report
                </div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 11px; color: #64748b; font-weight: 600;">REPORT DATE</div>
                <div style="font-size: 16px; font-weight: 800; color: #0f172a;">${targetDate}</div>
                <div style="font-size: 10px; color: #94a3b8; margin-top: 2px;">Generated at: ${generatedTime} (11:30 PM Nightly Auto)</div>
            </div>
        </div>

        <!-- 4 Key KPI Cards -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px;">
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
                <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Gross Revenue</div>
                <div style="font-size: 16px; font-weight: 900; color: #0f172a; margin-top: 4px;">LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                <div style="font-size: 9px; color: #10b981; margin-top: 2px; font-weight: 600;">Total Invoiced Sales</div>
            </div>
            <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px;">
                <div style="font-size: 10px; font-weight: 700; color: #166534; text-transform: uppercase;">Estimated Profit</div>
                <div style="font-size: 16px; font-weight: 900; color: #15803d; margin-top: 4px;">LKR ${netProfit.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                <div style="font-size: 9px; color: #16a34a; margin-top: 2px; font-weight: 700;">${profitMargin}% Net Margin</div>
            </div>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
                <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Bills / Invoices</div>
                <div style="font-size: 16px; font-weight: 900; color: #0f172a; margin-top: 4px;">${orderCount}</div>
                <div style="font-size: 9px; color: #64748b; margin-top: 2px; font-weight: 600;">Settled Transactions</div>
            </div>
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 12px;">
                <div style="font-size: 10px; font-weight: 700; color: #991b1b; text-transform: uppercase;">Market Receivables</div>
                <div style="font-size: 16px; font-weight: 900; color: #dc2626; margin-top: 4px;">LKR ${totalCreditDebt.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                <div style="font-size: 9px; color: #b91c1c; margin-top: 2px; font-weight: 600;">Total Outstanding Credit</div>
            </div>
        </div>

        <!-- Payment Breakdown & Sales Stats -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
            <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #ffffff;">
                <h3 style="margin: 0 0 10px 0; font-size: 12px; text-transform: uppercase; font-weight: 800; color: #334155;">💳 Payment Collection Summary</h3>
                <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Cash In Drawer</td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 800; color: #0f172a;">LKR ${(paymentMap.Cash || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Credit / Debit Card</td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 800; color: #0f172a;">LKR ${(paymentMap.Card || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 6px 0; color: #64748b; font-weight: 600;">Bank Direct Transfer</td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 800; color: #0f172a;">LKR ${(paymentMap.Bank || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 6px 0; color: #dc2626; font-weight: 600;">Credit Invoiced (Pay Later)</td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 800; color: #dc2626;">LKR ${(paymentMap.Credit || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0 0 0; font-weight: 900; color: #0f172a;">Total Realized Revenue</td>
                        <td style="padding: 8px 0 0 0; text-align: right; font-weight: 900; color: #0f172a; font-size: 12px;">LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    </tr>
                </table>
            </div>

            <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background: #ffffff;">
                <h3 style="margin: 0 0 10px 0; font-size: 12px; text-transform: uppercase; font-weight: 800; color: #334155;">🏆 Top 5 Selling Products Today</h3>
                <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
                    <thead>
                        <tr style="border-bottom: 1px solid #e2e8f0; color: #94a3b8; text-align: left; font-size: 10px;">
                            <th style="padding: 4px 0;">Item</th>
                            <th style="padding: 4px 0; text-align: center;">Qty</th>
                            <th style="padding: 4px 0; text-align: right;">Total (LKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${sortedItems.length > 0 ? sortedItems.map(([name, stat], idx) => `
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 5px 0; font-weight: 600; color: #1e293b; max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${idx + 1}. ${name}</td>
                                <td style="padding: 5px 0; text-align: center; font-weight: 800; color: #0f172a;">${stat.qty}</td>
                                <td style="padding: 5px 0; text-align: right; font-weight: 700; color: #0f172a;">${stat.revenue.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                            </tr>
                        `).join('') : `
                            <tr>
                                <td colspan="3" style="padding: 15px 0; text-align: center; color: #94a3b8; font-style: italic;">No items sold today</td>
                            </tr>
                        `}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- AI Virtual CFO Audit Comment -->
        <div style="background: #f8fafc; border-left: 4px solid #a855f7; border-radius: 4px; padding: 12px 15px; margin-bottom: 20px;">
            <div style="font-size: 11px; font-weight: 800; color: #7e22ce; margin-bottom: 3px;">🤖 AI VIRTUAL CFO NIGHTLY CLOSING AUDIT</div>
            <p style="margin: 0; font-size: 10.5px; color: #475569; line-height: 1.5;">
                ${grossRevenue > 0 
                    ? `Store recorded total daily gross revenue of LKR ${grossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})} with ${profitMargin}% gross margin. Cash balance collected: LKR ${(paymentMap.Cash || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}. All closing books and transactions validated autonomously.` 
                    : `No billing transactions were recorded for ${targetDate}. Drawer and financial ledgers balanced at zero.`}
            </p>
        </div>

        <!-- Document Footer -->
        <div style="border-top: 1px solid #e2e8f0; padding-top: 10px; display: flex; justify-content: space-between; align-items: center; font-size: 9px; color: #94a3b8;">
            <div>CONFIDENTIAL — FOR EXECUTIVE / CEO USE ONLY</div>
            <div>Generated by MEC POS System v3.28 | Cloud Storage Secured</div>
        </div>
    `;

    return container;
}

/**
 * Renders daily executive PDF and uploads to Firebase Cloud Storage, returning download URL
 */
export async function generateAndUploadDailyPDF(dateStr) {
    const targetDate = dateStr || new Date().toISOString().split('T')[0];
    const storeId = getCurrentStoreId();
    const fileName = `Daily_Report_${storeId}_${targetDate}.pdf`;

    if (!window.html2pdf) {
        console.warn("html2pdf is not loaded in window.");
        return null;
    }

    const container = buildDailyExecutivePDFElement(targetDate);
    document.body.appendChild(container);

    const opt = {
        margin:       [5, 5, 5, 5],
        filename:     fileName,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    try {
        const pdfBlob = await window.html2pdf().set(opt).from(container).toPdf().output('blob');
        document.body.removeChild(container);

        // 1. If running inside Electron desktop app, save to C:\MEC_EXPORTS\
        if (window.electron) {
            try {
                const reader = new FileReader();
                reader.readAsDataURL(pdfBlob);
                reader.onloadend = () => {
                    window.electron.send('save-order-export', { base64Data: reader.result, fileName });
                };
            } catch (err) {
                console.warn("Electron export error:", err);
            }
        }

        // 2. Upload to Firebase Storage
        if (storage) {
            const reportStorageRef = storageRef(storage, `daily_reports/${storeId}_${targetDate}.pdf`);
            const uploadResult = await uploadBytes(reportStorageRef, pdfBlob, {
                contentType: 'application/pdf',
                customMetadata: {
                    storeId,
                    date: targetDate,
                    generatedBy: 'MEC_POS_AI_Copilot'
                }
            });
            const downloadUrl = await getDownloadURL(uploadResult.ref);
            console.log("📄 Daily PDF Report uploaded to Cloud Storage:", downloadUrl);
            return downloadUrl;
        }

        return null;
    } catch (e) {
        console.error("PDF generation or upload failed:", e);
        if (document.body.contains(container)) {
            document.body.removeChild(container);
        }
        return null;
    }
}

/**
 * Downloads the Daily PDF Report locally for manual inspection
 */
window.downloadTodayDailyPDF = async () => {
    const todayStr = new Date().toISOString().split('T')[0];
    const storeId = getCurrentStoreId();
    const fileName = `Daily_Report_${storeId}_${todayStr}.pdf`;

    if (!window.html2pdf) {
        window.showToast("⚠️ html2pdf library is initializing, please try again in a moment.", "error");
        return;
    }

    window.showToast("📄 Generating Daily Financial PDF Report...", "info");
    const container = buildDailyExecutivePDFElement(todayStr);
    document.body.appendChild(container);

    const opt = {
        margin:       [5, 5, 5, 5],
        filename:     fileName,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    try {
        await window.html2pdf().set(opt).from(container).save();
        document.body.removeChild(container);
        window.showToast("✅ Daily PDF Report downloaded successfully!", "success");
    } catch (err) {
        console.error("Manual PDF download error:", err);
        if (document.body.contains(container)) document.body.removeChild(container);
        window.showToast("❌ Could not download PDF: " + err.message, "error");
    }
};

export async function sendCeoDirectSMS(phone, customBriefText, pdfUrl = null) {
    let cleanPhone = (phone || copilotConfig.ceoPhone || '0770658356').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
        cleanPhone = '94' + cleanPhone.substring(1);
    } else if (!cleanPhone.startsWith('94')) {
        cleanPhone = '94' + cleanPhone;
    }

    if (cleanPhone.length !== 11) {
        console.warn("[Auto SMS] Invalid CEO Phone number format:", phone);
        return false;
    }

    const orders = window.allOrders || [];
    const products = window.allProducts || [];
    const customers = window.allCustomers || [];
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : new Date().toLocaleDateString('sv-SE');

    const todayOrders = orders.filter(o => {
        const d = (o.date && typeof o.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(o.date))
            ? o.date 
            : (o.timestamp?.seconds ? new Date(o.timestamp.seconds * 1000).toLocaleDateString('sv-SE') : '');
        return d === todayStr && o.status !== 'Void' && o.status !== 'Cancelled';
    });

    const todayGrossRevenue = todayOrders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
    const todayOrderCount = todayOrders.length;
    let todayTotalCost = 0;
    todayOrders.forEach(o => {
        (o.items || []).forEach(item => {
            const qty = parseFloat(item.quantity) || 1;
            let cost = parseFloat(item.costPrice || item.buyingPrice || item.cost || 0);
            if (!cost) {
                const prod = products.find(p => p.docId === item.docId || p.sku === item.sku);
                if (prod) cost = parseFloat(prod.cost || prod.buyingPrice) || 0;
            }
            todayTotalCost += (cost * qty);
        });
    });
    const estimatedNetProfit = Math.max(0, todayGrossRevenue - todayTotalCost);
    const profitMargin = todayGrossRevenue > 0 ? ((estimatedNetProfit / todayGrossRevenue) * 100).toFixed(1) : "0.0";
    const totalCreditDebt = customers.reduce((acc, c) => acc + (parseFloat(c.creditBalance || c.outstanding || 0)), 0);

    const storeName = document.querySelector('.main')?.innerText || (window.systemConfig?.invPhone ? 'MEC POS Store' : 'MEC POS');
    
    let pdfLine = '';
    if (pdfUrl) {
        pdfLine = `\nPDF Report: ${pdfUrl}`;
    }

    const smsBrief = customBriefText || 
`[${storeName.toUpperCase()} DAILY BRIEF - ${todayStr}]
Gross Sales: LKR ${todayGrossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2})}
Est. Gross Profit: LKR ${estimatedNetProfit.toLocaleString(undefined, {minimumFractionDigits: 2})} (${profitMargin}%)
Bills: ${todayOrderCount}
Credit Debt: LKR ${totalCreditDebt.toLocaleString(undefined, {minimumFractionDigits: 2})}${pdfLine}
MEC POS Virtual CFO`;

    // Retrieve merchant configured SMS credentials from Settings, or fallback to default SMSLenz gateway
    const smsConf = window.systemConfig?.smsConfig || {};
    const apiBase = smsConf.apiBase || "https://smslenz.lk/api/send-sms";
    const apiKey = smsConf.apiKey || "40b621ec-69ba-48c4-869b-cf30f3f58791";
    const userId = smsConf.userId || "981";
    const senderId = smsConf.senderId || "MECBookShop";

    try {
        const contactNumber = cleanPhone.startsWith('+') ? cleanPhone : ('+' + cleanPhone);
        const url = new URL(apiBase);
        url.searchParams.set("user_id", userId);
        url.searchParams.set("api_key", apiKey);
        url.searchParams.set("sender_id", senderId);
        url.searchParams.set("contact", contactNumber);
        url.searchParams.set("message", smsBrief);

        if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage(JSON.stringify({
                    type: "send-sms",
                    user_id: userId,
                    api_key: apiKey,
                    sender_id: senderId,
                    contact: contactNumber,
                    message: smsBrief
                }));
                console.log(`📲 SMS dispatched to CEO (${cleanPhone}) via C# Native Bridge`);
                return true;
            } catch(e) {}
        }

        await fetch(url.toString(), { method: 'GET', mode: 'no-cors' });
        console.log(`📲 SMS dispatched to CEO (${cleanPhone}) via Gateway [Sender: ${senderId}]`);
        return true;
    } catch (err) {
        console.error("SMS CEO dispatch error:", err);
        return false;
    }
}
window.sendCeoDirectSMS = sendCeoDirectSMS;

// Helper to dispatch WhatsApp strictly via Meta Cloud API without opening browser/WebView2
export async function launchWhatsAppUrl(phone, textMessage, forceWeb = false) {
    if (!forceWeb && typeof sendDirectMetaWhatsAppText === 'function') {
        const res = await sendDirectMetaWhatsAppText(phone, textMessage);
        if (res.success) {
            if (window.showToast) window.showToast("✅ Sent directly via WhatsApp Cloud API!", "success");
            return;
        }
    }

    if (!forceWeb) {
        // Do not open browser or desktop app unless explicitly requested
        return;
    }

    let cleanPhone = (phone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
        cleanPhone = '94' + cleanPhone.substring(1);
    } else if (!cleanPhone.startsWith('94')) {
        cleanPhone = '94' + cleanPhone;
    }
    const encoded = encodeURIComponent(textMessage);
    const targetUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;

    if (typeof window.openExternalUrl === 'function') {
        window.openExternalUrl(targetUrl);
    } else if (window.electronAPI?.openExternal) {
        window.electronAPI.openExternal(targetUrl);
    } else if (window.chrome?.webview) {
        try {
            window.chrome.webview.postMessage(JSON.stringify({ type: 'openExternalUrl', action: 'openExternalUrl', url: targetUrl }));
        } catch (e) {
            window.open(targetUrl, '_blank');
        }
    } else {
        window.open(targetUrl, '_blank');
    }
}
window.launchWhatsAppUrl = launchWhatsAppUrl;

export function getCeoKpiData() {
    const orders = window.allOrders || [];
    const products = window.allProducts || [];
    const customers = window.allCustomers || [];

    const now = new Date();
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : now.toLocaleDateString('sv-SE');
    const todayOrders = orders.filter(o => {
        if (o.status === 'Void' || o.status === 'Cancelled') return false;
        let d = '';
        if (o.date && typeof o.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(o.date)) {
            d = o.date;
        } else if (o.timestamp?.seconds) {
            d = new Date(o.timestamp.seconds * 1000).toLocaleDateString('sv-SE');
        } else if (o.timestamp?.toDate) {
            d = o.timestamp.toDate().toLocaleDateString('sv-SE');
        } else if (o.createdAt) {
            const dt = new Date(o.createdAt);
            if (!isNaN(dt.getTime())) d = dt.toLocaleDateString('sv-SE');
        }
        return d === todayStr;
    });

    const todayGrossRevenue = todayOrders.reduce((acc, o) => acc + (parseFloat(o.total) || 0), 0);
    const todayOrderCount = todayOrders.length;

    let todayTotalCost = 0;
    todayOrders.forEach(o => {
        (o.items || []).forEach(item => {
            const qty = parseFloat(item.quantity) || 1;
            let cost = parseFloat(item.costPrice || item.buyingPrice || item.cost || 0);
            if (!cost) {
                const prod = products.find(p => p.docId === item.docId || p.sku === item.sku);
                if (prod) cost = parseFloat(prod.cost || prod.buyingPrice) || 0;
            }
            todayTotalCost += (cost * qty);
        });
    });

    const estimatedNetProfit = Math.max(0, todayGrossRevenue - todayTotalCost);
    const totalCreditDebt = customers.reduce((acc, c) => acc + (parseFloat(c.creditBalance || c.outstanding || 0)), 0);
    const storeName = document.querySelector('.main')?.innerText || 'MEC POS Store';

    return {
        storeName: storeName.substring(0, 30),
        date: todayStr,
        sales: todayGrossRevenue.toLocaleString(undefined, {minimumFractionDigits: 2}),
        profit: estimatedNetProfit.toLocaleString(undefined, {minimumFractionDigits: 2}),
        invoices: todayOrderCount.toString(),
        creditDebt: totalCreditDebt.toLocaleString(undefined, {minimumFractionDigits: 2}),
        cfoNote: todayGrossRevenue > 0 ? 'Healthy margin & positive cash flow.' : 'Zero transactions recorded today.'
    };
}
window.getCeoKpiData = getCeoKpiData;

export async function sendMetaWhatsAppMessage(toPhone, textMessage, customKpis = null) {
    let rawPhone = (toPhone || '0770658356').trim();
    if (rawPhone.includes('9233388') || rawPhone === '0719233388') {
        rawPhone = '0770658356';
    }

    let cleanPhone = rawPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('940')) {
        cleanPhone = '94' + cleanPhone.substring(3);
    } else if (cleanPhone.startsWith('0')) {
        cleanPhone = '94' + cleanPhone.substring(1);
    } else if (!cleanPhone.startsWith('94')) {
        cleanPhone = '94' + cleanPhone;
    }

    const permanentToken = "EAAaRKVpmPacBS9WVgvFzcoJdiCkvzTI0xEf7gAYbQzwmJFhvd3ufDPUtrdouPdNZA3gZCsEkPRhDfIJlMXcjQRmWZC3ZBt3slSuZBq6xSk8t8OcZCFoZAvXfYmgKe9zdi91ngAm4WbhfFdDuYTZA2RR6OHgnH5Vmq2UZAnrJVyIOnVVqC0GazulveFZCkPwBJr8YLNLAZDZD";
    const permanentPhoneId = "1458508587349126";

    const metaConf = window.systemConfig?.metaWhatsappConfig || {};
    let phoneNumberId = (metaConf.phoneNumberId || "").trim();
    if (!phoneNumberId || phoneNumberId === "61595312696922" || phoneNumberId === "1299065503300070") {
        phoneNumberId = permanentPhoneId;
    }
    let accessToken = (metaConf.accessToken || "").trim();
    if (!accessToken || !accessToken.startsWith("EAAaRKVpmPac")) {
        accessToken = permanentToken;
    }

    const endpoint = `https://graph.facebook.com/v22.0/${phoneNumberId}/messages`;
    const headers = {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
    };

    const metrics = customKpis || getCeoKpiData();

    let dispatched = false;
    let templateSuccess = false;

    // 1. Send Primary Custom Template (mec_pos_daily_brief) if approved
    try {
        const customTemplatePayload = {
            messaging_product: "whatsapp",
            to: cleanPhone,
            type: "template",
            template: {
                name: "mec_pos_daily_brief",
                language: { code: "en_US" },
                components: [{
                    type: "body",
                    parameters: [
                        { type: "text", text: (metrics.storeName || "MEC POS").toString() },
                        { type: "text", text: (metrics.date || new Date().toISOString().split('T')[0]).toString() },
                        { type: "text", text: (metrics.sales || "0.00").toString() },
                        { type: "text", text: (metrics.profit || "0.00").toString() },
                        { type: "text", text: (metrics.invoices || "0").toString() },
                        { type: "text", text: (metrics.creditDebt || "0.00").toString() },
                        { type: "text", text: (metrics.cfoNote || "Autonomous report generated.").toString() }
                    ]
                }]
            }
        };

        let response = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(customTemplatePayload)
        });
        let data = await response.json();

        // Retry with permanent credentials if initial custom credentials failed
        if (!response.ok && (phoneNumberId !== permanentPhoneId || accessToken !== permanentToken)) {
            console.warn("Retrying custom template with verified permanent credentials...");
            const retryEndpoint = `https://graph.facebook.com/v22.0/${permanentPhoneId}/messages`;
            response = await fetch(retryEndpoint, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${permanentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(customTemplatePayload)
            });
            data = await response.json();
        }

        if (response.ok && data.messages && data.messages.length > 0) {
            console.log("✅ Custom Template (mec_pos_daily_brief) delivered:", data);
            templateSuccess = true;
            dispatched = true;
        } else {
            console.warn("ℹ️ Custom template (mec_pos_daily_brief) delivery note:", data?.error?.message);
        }
    } catch (err) {
        console.warn("⚠️ Custom template fetch error:", err);
    }

    // 2. If Primary Custom Template not approved yet, try Marketing Custom Template (mec_financial_brief_v1)
    if (!templateSuccess) {
        try {
            const marketingPayload = {
                messaging_product: "whatsapp",
                to: cleanPhone,
                type: "template",
                template: {
                    name: "mec_financial_brief_v1",
                    language: { code: "en_US" },
                    components: [{
                        type: "body",
                        parameters: [
                            { type: "text", text: metrics.storeName || "MEC BOOK SHOP" },
                            { type: "text", text: metrics.date || new Date().toISOString().split('T')[0] },
                            { type: "text", text: metrics.sales || "0.00" },
                            { type: "text", text: metrics.profit || "0.00" },
                            { type: "text", text: metrics.invoices || "0" },
                            { type: "text", text: metrics.creditDebt || "0.00" },
                            { type: "text", text: metrics.cfoNote || "Autonomous report generated." }
                        ]
                    }]
                }
            };

            const response = await fetch(endpoint, {
                method: 'POST',
                headers,
                body: JSON.stringify(marketingPayload)
            });
            const data = await response.json();
            if (response.ok && data.messages && data.messages.length > 0) {
                console.log("✅ Marketing Template (mec_financial_brief_v1) delivered:", data);
                templateSuccess = true;
                dispatched = true;
            } else {
                console.warn("ℹ️ Marketing template (mec_financial_brief_v1) pending review:", data?.error?.message);
            }
        } catch (err) {
            console.warn("⚠️ Marketing template fetch error:", err);
        }
    }

    // 3. ALSO dispatch full formatted text message (delivers when 24h conversation window is active)
    let textSuccess = false;
    try {
        const textPayload = {
            messaging_product: "whatsapp",
            recipient_type: "individual",
            to: cleanPhone,
            type: "text",
            text: { preview_url: false, body: textMessage }
        };

        const response = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(textPayload)
        });
        const data = await response.json();
        if (response.ok && data.messages && data.messages.length > 0) {
            console.log(`✅ Direct text brief dispatched via Meta Cloud API:`, data);
            textSuccess = true;
            dispatched = true;
        }
    } catch (err) {
        console.warn("⚠️ Meta Text API fetch error:", err);
    }

    if (templateSuccess) {
        return { success: true, type: 'template' };
    }
    if (textSuccess) {
        return { success: true, type: 'text' };
    }

    return { success: false, error: "Meta WhatsApp templates pending review & 24h customer window not open." };
}
window.sendMetaWhatsAppMessage = sendMetaWhatsAppMessage;

export async function checkAndDispatchCeoNightlyWhatsApp(force = false) {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMin = now.getMinutes();
    const todayStr = now.toISOString().split('T')[0];

    // Strictly dispatch at or after 11:30 PM (23:30) every night unless forced
    const is1130PMOrLater = (currentHour === 23 && currentMin >= 30) || (currentHour > 23);
    if (!force && !is1130PMOrLater) return;

    const lastSentDate = localStorage.getItem('mecpos_ceo_whatsapp_last_sent_date');
    if (!force && lastSentDate === todayStr) return; // Already sent today

    const phone = (copilotConfig.ceoPhone || document.getElementById('copilot-ceo-phone-input')?.value || '0770658356').replace(/[^0-9]/g, '');
    if (!phone) return;

    // 1. Generate Daily PDF Report & upload to Cloud Storage
    let pdfUrl = null;
    try {
        pdfUrl = await generateAndUploadDailyPDF(todayStr);
    } catch (err) {
        console.warn("PDF auto-generation warning:", err);
    }

    // 2. Build Brief Text (incorporating PDF link if available)
    let message = buildCeoWhatsAppBriefText();
    if (pdfUrl) {
        message += `\n\n📄 *Executive PDF Report:* ${pdfUrl}`;
    }

    // 3. Send WhatsApp: First try Cloud API, then automatically open WhatsApp Web/App if Cloud API is expired
    const metaRes = await sendMetaWhatsAppMessage(phone, message);
    if (!metaRes.success) {
        console.warn("Meta Cloud API failed, opening WhatsApp Web/Desktop fallback...");
        launchWhatsAppUrl(phone, message);
    }

    // 4. Log decision to Firestore
    try {
        const storeId = getCurrentStoreId();
        await addDoc(copilotLogsCol, {
            type: 'WA_CEO',
            title: `Nightly 11:30 PM CEO Financial Brief & PDF Dispatched`,
            description: `Autonomous 11:30 PM daily closing brief & PDF delivered via WhatsApp to CEO (${copilotConfig.ceoPhone || phone}).${pdfUrl ? ` PDF URL: ${pdfUrl}` : ''}`,
            storeId,
            pdfUrl: pdfUrl || '',
            timestamp: serverTimestamp()
        });
        localStorage.setItem('mecpos_ceo_whatsapp_last_sent_date', todayStr);
    } catch (e) {}

    // 5. Complete background dispatch toast
    if (force && window.showToast) {
        window.showToast("📲 CEO Financial Brief Dispatched to WhatsApp!", "success");
    }
}
window.checkAndDispatchCeoNightlyWhatsApp = checkAndDispatchCeoNightlyWhatsApp;

/**
 * Autonomous Morning CEO Brief via SMSLenz
 * Dispatched on morning app login: contains Yesterday's Sales, Profit, Bills & Today's Cheques Due
 * Authoritative: queries Firestore directly to ensure 100% accurate sales regardless of client sync or cash balance state
 */
export async function checkAndDispatchCeoMorningSMS(force = false) {
    // 1. In-flight concurrency lock to prevent duplicate sends across triggers
    if (window._isDispatchingMorningSMS) {
        console.log("[Morning SMS] Already in progress, blocking concurrent dispatch.");
        return false;
    }

    const now = new Date();
    const currentHour = now.getHours();
    // Use local Swedish ISO date format (YYYY-MM-DD) in Sri Lanka local time
    const todayStr = window.getLocalYYYYMMDD ? window.getLocalYYYYMMDD() : now.toLocaleDateString('sv-SE');

    // Only dispatch during morning/daytime (before 5:00 PM / 17:00) unless forced
    if (!force && currentHour >= 17) {
        console.log(`[Morning SMS] Skipping auto-dispatch: current hour (${currentHour}:00) is outside morning window.`);
        return false;
    }

    // Check if already dispatched today
    const lastSentDate = localStorage.getItem('mecpos_ceo_morning_sms_date');
    const lastSentSales = localStorage.getItem('mecpos_ceo_morning_sms_sales');
    // If sent today, but lastSentSales was "0.00", allow auto-re-evaluating with Firestore in case it was sent before sync!
    if (!force && lastSentDate === todayStr && lastSentSales !== '0.00' && lastSentSales !== null) {
        console.log(`[Morning SMS] Today's morning brief already dispatched (${todayStr}) with sales: LKR ${lastSentSales}.`);
        return false;
    }

    const phone = (copilotConfig.ceoPhone || document.getElementById('copilot-ceo-phone-input')?.value || getRegisteredMerchantPhone() || '0770658356').replace(/[^0-9]/g, '');
    if (!phone) return false;

    window._isDispatchingMorningSMS = true;

    try {
        // --- 1. Compute Yesterday's Date Boundaries in Sri Lanka Local Time ---
        const yDate = new Date();
        yDate.setDate(yDate.getDate() - 1);
        const yesterdayStr = window.getLocalYYYYMMDD ? 
            (function() {
                const d = new Date();
                d.setDate(d.getDate() - 1);
                return d.toLocaleDateString('sv-SE');
            })() : yDate.toLocaleDateString('sv-SE');

        const startOfYesterday = new Date(yesterdayStr + 'T00:00:00');
        const endOfYesterday = new Date(yesterdayStr + 'T23:59:59.999');

        const storeId = getCurrentStoreId();

        let candidateOrders = Array.isArray(window.allOrders) ? [...window.allOrders] : [];
        let candidateReloads = Array.isArray(window.allReloads) ? [...window.allReloads] : [];
        let products = Array.isArray(window.allProducts) && window.allProducts.length > 0 ? window.allProducts : [];
        let customers = Array.isArray(window.allCustomers) && window.allCustomers.length > 0 ? window.allCustomers : [];

        // Order date parser: 100% robust, handles Firestore Timestamps, ISO format, and local YYYY-MM-DD
        const parseRecordDate = (o) => {
            if (!o) return null;
            let d = null;
            if (o.timestamp?.seconds) {
                d = new Date(o.timestamp.seconds * 1000);
            } else if (o.createdAt?.seconds) {
                d = new Date(o.createdAt.seconds * 1000);
            } else if (o.timestamp?.toDate) {
                d = o.timestamp.toDate();
            } else if (o.date) {
                d = (o.date.includes('T') || o.date.includes(' ')) ? new Date(o.date) : new Date(o.date + 'T12:00:00');
            } else if (o.createdAt) {
                d = new Date(o.createdAt);
            } else if (o.orderDate) {
                d = new Date(o.orderDate);
            }
            return (d && !isNaN(d.getTime())) ? d : null;
        };

        const isYesterdayMatch = (record) => {
            if (!record || record.status === 'Void' || record.status === 'Cancelled') return false;
            if (typeof record.date === 'string' && record.date.startsWith(yesterdayStr)) return true;
            const d = parseRecordDate(record);
            if (!d) return false;
            return d >= startOfYesterday && d <= endOfYesterday;
        };

        let yesterdayOrders = candidateOrders.filter(isYesterdayMatch);

        // DIRECT FIREBASE RUN:
        // If candidateOrders is empty OR found 0 orders for yesterday, query Firestore directly!
        if (candidateOrders.length === 0 || yesterdayOrders.length === 0) {
            console.log(`[Morning SMS] In-memory orders gave 0 records for ${yesterdayStr}. Running authoritative direct Firebase query...`);
            try {
                const ordersCol = collection(db, 'orders');
                // Primary query: date == yesterdayStr
                let snap = await getDocs(query(ordersCol, where('date', '==', yesterdayStr)));
                let directDocs = snap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));

                // Fallback 1: timestamp range query if date field was formatted differently
                if (directDocs.length === 0) {
                    try {
                        const yesterdayStartTs = Timestamp.fromDate(startOfYesterday);
                        const yesterdayEndTs = Timestamp.fromDate(endOfYesterday);
                        const tsSnap = await getDocs(query(
                            ordersCol,
                            where('timestamp', '>=', yesterdayStartTs),
                            where('timestamp', '<=', yesterdayEndTs)
                        ));
                        directDocs = tsSnap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                    } catch (e) {}
                }

                // Fallback 2: store query if still empty
                if (directDocs.length === 0) {
                    try {
                        const storeSnap = await getDocs(query(ordersCol, where('storeId', '==', storeId), limit(200)));
                        directDocs = storeSnap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                    } catch (e) {}
                }

                const directFiltered = directDocs.filter(isYesterdayMatch);
                if (directFiltered.length > 0) {
                    yesterdayOrders = directFiltered;
                    directDocs.forEach(d => {
                        if (!candidateOrders.some(x => (x.orderId && x.orderId === d.orderId) || x.docId === d.docId)) {
                            candidateOrders.push(d);
                        }
                    });
                }
                console.log(`[Morning SMS] Direct Firestore order fetch result: ${yesterdayOrders.length} orders found.`);
            } catch (fsErr) {
                console.error("[Morning SMS] Error fetching orders directly from Firestore:", fsErr);
            }
        }

        // Deduplicate yesterday's orders by orderId or docId
        const seenOrderKeys = new Set();
        yesterdayOrders = yesterdayOrders.filter(o => {
            const key = o.orderId || o.docId;
            if (key && seenOrderKeys.has(key)) return false;
            if (key) seenOrderKeys.add(key);
            return true;
        });

        // Standalone Reloads
        let yesterdayReloads = candidateReloads.filter(r => isYesterdayMatch(r) && r.isPOS !== true);
        if (candidateReloads.length === 0 || yesterdayReloads.length === 0) {
            try {
                const reloadsCol = collection(db, 'reloads');
                const rSnap = await getDocs(query(reloadsCol, where('date', '==', yesterdayStr)));
                const rDocs = rSnap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                const rFiltered = rDocs.filter(r => isYesterdayMatch(r) && r.isPOS !== true);
                if (rFiltered.length > 0) {
                    yesterdayReloads = rFiltered;
                }
            } catch (e) {}
        }

        // Products for Costing (fallback to Firestore if in-memory products not loaded)
        if (products.length === 0) {
            try {
                const prodSnap = await getDocs(collection(db, 'products'));
                products = prodSnap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
            } catch (e) {}
        }

        // Customers for Credit Debt (fallback to Firestore if in-memory customers not loaded)
        if (customers.length === 0) {
            try {
                const custSnap = await getDocs(collection(db, 'customers'));
                customers = custSnap.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
            } catch (e) {}
        }
        const totalCreditDebt = customers.reduce((sum, c) => sum + (parseFloat(c.creditBalance || c.outstanding || 0)), 0);

        // --- Calculate Exact Sales, Cost, and Profit Matching Financial Reports Screen ---
        let posSales = 0;
        let posCost = 0;
        let reloadSales = 0;
        let reloadCost = 0;
        let reloadProfit = 0;
        let billsCount = 0;

        yesterdayOrders.forEach(o => {
            const orderTotal = parseFloat(o.total) || 0;
            let orderEmbeddedReloadSales = 0;
            let orderEmbeddedReloadCost = 0;

            (o.items || []).forEach(item => {
                const qty = parseFloat(item.quantity) || 1;
                const price = parseFloat(item.price || 0);
                const discount = parseFloat(item.discount || 0);
                const itemNetPrice = (price - discount) * qty;

                if (item.isReload) {
                    const itemCost = (parseFloat(item.costPrice) || 0) * qty;
                    orderEmbeddedReloadSales += itemNetPrice;
                    orderEmbeddedReloadCost += itemCost;
                    return;
                }

                let unitCost = parseFloat(item.costPrice);
                if (isNaN(unitCost) || unitCost === 0) {
                    if (products.length > 0) {
                        const prod = products.find(p => p.docId === item.docId || p.sku === item.sku);
                        if (prod) {
                            unitCost = parseFloat(prod.cost || prod.buyingPrice) || 0;
                        } else {
                            unitCost = 0;
                        }
                    } else {
                        unitCost = 0;
                    }
                }
                posCost += ((unitCost || 0) * qty);
            });

            if (orderEmbeddedReloadSales > 0) {
                reloadSales += orderEmbeddedReloadSales;
                reloadCost += orderEmbeddedReloadCost;
                reloadProfit += (orderEmbeddedReloadSales - orderEmbeddedReloadCost);
            }

            posSales += Math.max(0, orderTotal - orderEmbeddedReloadSales);
            billsCount++;
        });

        yesterdayReloads.forEach(r => {
            const amt = parseFloat(r.baseAmount || r.amount || 0);
            const comm = parseFloat(r.commission || 0);
            reloadSales += amt;
            reloadCost += (amt - comm);
            reloadProfit += comm;
            billsCount++;
        });

        const grandTotalSales = posSales + reloadSales;
        const grandTotalCost = posCost + reloadCost;
        const grandGrossProfit = (posSales - posCost) + reloadProfit;
        const yMargin = grandTotalSales > 0 ? ((grandGrossProfit / grandTotalSales) * 100).toFixed(1) : "0.0";

        // Safety retry: If automated call found 0 bills and in-memory window.allOrders hasn't synced, wait and retry
        if (!force && billsCount === 0 && (!window.allOrders || window.allOrders.length === 0)) {
            window._morningSmsRetryCount = (window._morningSmsRetryCount || 0) + 1;
            if (window._morningSmsRetryCount <= 4) {
                console.log(`[Morning SMS] Orders still syncing, retrying in 3s (attempt ${window._morningSmsRetryCount}/4)...`);
                setTimeout(() => checkAndDispatchCeoMorningSMS(force), 3000);
                return false;
            }
        }
        window._morningSmsRetryCount = 0;

        // --- Cheques Due Today Calculation ---
        const parseChequeDate = (raw) => {
            if (!raw) return null;
            if (typeof raw === 'string') {
                const cleaned = raw.trim();
                if (/^\d{4}-\d{2}-\d{2}/.test(cleaned)) {
                    return cleaned.substring(0, 10);
                }
            }
            if (raw.seconds) {
                return new Date(raw.seconds * 1000).toLocaleDateString('sv-SE');
            }
            if (raw.toDate) {
                return raw.toDate().toLocaleDateString('sv-SE');
            }
            const d = new Date(raw);
            if (!isNaN(d.getTime())) {
                return d.toLocaleDateString('sv-SE');
            }
            return null;
        };

        // Query active cheques for today directly from Firestore if needed
        try {
            const chqSnap = await getDocs(query(collection(db, 'orders'), where('chequeDate', '==', todayStr)));
            chqSnap.docs.forEach(doc => {
                const co = { ...doc.data(), docId: doc.id };
                if (!candidateOrders.some(x => (x.orderId && x.orderId === co.orderId) || x.docId === co.docId)) {
                    candidateOrders.push(co);
                }
            });
        } catch (e) {}

        const customerChequesDue = candidateOrders.filter(o => {
            const oStatus = (o.status || '').toLowerCase();
            if (oStatus === 'void' || oStatus === 'cancelled') return false;
            if (oStatus === 'paid' || (o.chequeStatus || '').toLowerCase() === 'cleared' || (o.chequeStatus || '').toLowerCase() === 'paid') {
                return false;
            }
            const isCheque = (o.paymentMethod || '').toLowerCase() === 'cheque' || !!o.chequeDate;
            if (!isCheque) return false;
            const cDate = parseChequeDate(o.chequeDate);
            return cDate === todayStr;
        });

        const custChequeTotal = customerChequesDue.reduce((sum, o) => sum + (parseFloat(o.total) || 0), 0);

        const supplierInvoices = window.allSupplierInvoices || window.allSInvoices || [];
        const supplierChequesDue = supplierInvoices.filter(inv => {
            const invStatus = (inv.status || '').toLowerCase();
            if (invStatus === 'void' || invStatus === 'cancelled') return false;
            if (invStatus === 'paid' || invStatus === 'settled' || (inv.chequeStatus || '').toLowerCase() === 'cleared' || (inv.chequeStatus || '').toLowerCase() === 'paid') {
                return false;
            }
            const isCheque = (inv.paymentMethod || '').toLowerCase() === 'cheque' || !!inv.chequeDate;
            if (!isCheque) return false;
            const cDate = parseChequeDate(inv.chequeDate);
            return cDate === todayStr;
        });

        const suppChequeTotal = supplierChequesDue.reduce((sum, inv) => sum + (parseFloat(inv.totalAmount || inv.grandTotal || 0)), 0);

        // Format Cheque Details String
        let chequeSection = "";
        if (customerChequesDue.length === 0 && supplierChequesDue.length === 0) {
            chequeSection = "CHEQUES DUE TODAY: None (LKR 0.00)";
        } else {
            const lines = [];
            if (customerChequesDue.length > 0) {
                lines.push(`Deposit Cheques: LKR ${custChequeTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} (${customerChequesDue.length})`);
                customerChequesDue.slice(0, 3).forEach(c => {
                    const invId = c.orderId || c.invoiceNo || 'Inv';
                    const amt = (parseFloat(c.total) || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    lines.push(` * ${invId}: LKR ${amt}`);
                });
                if (customerChequesDue.length > 3) {
                    lines.push(` * +${customerChequesDue.length - 3} more cheques`);
                }
            }
            if (supplierChequesDue.length > 0) {
                lines.push(`Supplier Payable: LKR ${suppChequeTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} (${supplierChequesDue.length})`);
                supplierChequesDue.slice(0, 2).forEach(s => {
                    const name = (s.supplierName || 'Supplier').substring(0, 16);
                    const amt = (parseFloat(s.totalAmount || s.grandTotal || 0)).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    lines.push(` * ${name}: LKR ${amt}`);
                });
            }
            chequeSection = `CHEQUES DUE TODAY (${todayStr}):\n${lines.join('\n')}`;
        }

        const storeName = document.querySelector('.main')?.innerText || (window.systemConfig?.invPhone ? 'MEC POS Store' : 'MEC BOOK SHOP');
        const isCorrected = (!force && lastSentDate === todayStr && lastSentSales === '0.00');

        const morningSmsText = 
`[${storeName.toUpperCase()} - ${isCorrected ? 'CORRECTED ' : ''}YESTERDAY SALES BRIEF]
Date: ${yesterdayStr}
Good Morning CEO!

Yesterday Sales: LKR ${grandTotalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}
Est. Profit: LKR ${grandGrossProfit.toLocaleString(undefined, {minimumFractionDigits: 2})} (${yMargin}%)
Bills Settled: ${billsCount}
Credit Debt: LKR ${totalCreditDebt.toLocaleString(undefined, {minimumFractionDigits: 2})}

-- ${chequeSection}

MEC POS Virtual CFO`;

        console.log("[Morning SMS] Dispatching to CEO (" + phone + "):\n" + morningSmsText);

        // Send SMS via SMSLenz Gateway
        const sent = await sendCeoDirectSMS(phone, morningSmsText);
        if (sent) {
            localStorage.setItem('mecpos_ceo_morning_sms_date', todayStr);
            localStorage.setItem('mecpos_ceo_morning_sms_sales', grandTotalSales.toFixed(2));

            try {
                await addDoc(copilotLogsCol, {
                    type: 'SMS_CEO_MORNING',
                    title: `Morning CEO Financial Brief Dispatched (Firebase Realtime)`,
                    description: `Morning brief sent via SMSLenz to CEO (${phone}). Yesterday Sales: LKR ${grandTotalSales.toLocaleString()}, Est. Profit: LKR ${grandGrossProfit.toLocaleString()}, Bills: ${billsCount}, Cheques Due: LKR ${(custChequeTotal + suppChequeTotal).toLocaleString()}.`,
                    storeId,
                    sales: grandTotalSales,
                    bills: billsCount,
                    profit: grandGrossProfit,
                    timestamp: serverTimestamp()
                });
            } catch (e) {}

            if (force && window.showToast) {
                window.showToast(`📲 Morning CEO Brief SMS Dispatched! (Sales: LKR ${grandTotalSales.toLocaleString()})`, "success");
            }
            return true;
        } else {
            console.warn("[Morning SMS] SMS dispatch returned false, clearing today's mark for retry.");
            return false;
        }
    } catch (err) {
        console.error("[Morning SMS] Error during dispatch:", err);
        return false;
    } finally {
        window._isDispatchingMorningSMS = false;
    }
}
window.checkAndDispatchCeoMorningSMS = checkAndDispatchCeoMorningSMS;
window.sendTestMorningSMS = () => checkAndDispatchCeoMorningSMS(true);
window.resendYesterdayMorningBrief = () => checkAndDispatchCeoMorningSMS(true);

// Direct Text Sender via Meta Cloud API (Bypasses templates completely so template messages like Image 3 are never sent)
export async function sendDirectMetaWhatsAppText(toPhone, textMessage) {
    let rawPhone = (toPhone || '0770658356').trim();
    if (rawPhone.includes('9233388') || rawPhone === '0719233388') {
        rawPhone = '0770658356';
    }

    let cleanPhone = rawPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('940')) {
        cleanPhone = '94' + cleanPhone.substring(3);
    } else if (cleanPhone.startsWith('0')) {
        cleanPhone = '94' + cleanPhone.substring(1);
    } else if (!cleanPhone.startsWith('94')) {
        cleanPhone = '94' + cleanPhone;
    }

    // Updated: 2026-10-19 — Verified permanent token (never expires) from Meta System User
    const permanentToken = "EAAaRKVpmPacBS9WVgvFzcoJdiCkvzTI0xEf7gAYbQzwmJFhvd3ufDPUtrdouPdNZA3gZCsEkPRhDfIJlMXcjQRmWZC3ZBt3slSuZBq6xSk8t8OcZCFoZAvXfYmgKe9zdi91ngAm4WbhfFdDuYTZA2RR6OHgnH5Vmq2UZAnrJVyIOnVVqC0GazulveFZCkPwBJr8YLNLAZDZD";
    const permanentPhoneId = "1458508587349126";

    const metaConf = window.systemConfig?.metaWhatsappConfig || {};
    let phoneNumberId = (metaConf.phoneNumberId || "").trim();
    if (!phoneNumberId || phoneNumberId === "61595312696922" || phoneNumberId === "1299065503300070") {
        phoneNumberId = permanentPhoneId;
    }
    let accessToken = (metaConf.accessToken || "").trim();
    if (!accessToken || !accessToken.startsWith("EAAaRKVpmPac")) {
        accessToken = permanentToken;
    }

    const textPayload = {
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: cleanPhone,
        type: "text",
        text: { preview_url: false, body: textMessage }
    };

    const dispatchWithAuth = async (pId, token) => {
        const endpoint = `https://graph.facebook.com/v22.0/${pId}/messages`;
        const headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json; charset=utf-8'
        };
        const response = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(textPayload)
        });
        const data = await response.json().catch(() => null);
        return { ok: response.ok, data };
    };

    try {
        let res = await dispatchWithAuth(phoneNumberId, accessToken);
        // If failed and custom token or phone ID was used, retry with permanent credentials
        if (!res.ok && (phoneNumberId !== permanentPhoneId || accessToken !== permanentToken)) {
            console.warn("Retrying direct WhatsApp text with verified permanent credentials...");
            res = await dispatchWithAuth(permanentPhoneId, permanentToken);
        }

        if (res.ok && res.data?.messages?.length > 0) {
            console.log(`✅ Direct WhatsApp settlement text dispatched via Meta Cloud API:`, res.data);
            return { success: true, data: res.data };
        } else {
            console.warn("⚠️ Meta Direct Text API error response:", res.data);
            return { success: false, error: res.data?.error?.message || "Meta API Error" };
        }
    } catch (err) {
        console.warn("⚠️ Meta Direct Text API fetch error:", err);
        return { success: false, error: err.message };
    }
}
window.sendDirectMetaWhatsAppText = sendDirectMetaWhatsAppText;

// Dispatch Shift Settlement Summary to CEO via WhatsApp (Matching user's preferred aesthetic design)
export async function sendShiftBalancingWhatsApp(shiftData = {}, isManualInteractive = false) {
    const metaConf = window.systemConfig?.metaWhatsappConfig || {};
    let phone = (metaConf.defaultPhone || copilotConfig.ceoPhone || document.getElementById('copilot-ceo-phone-input')?.value || getRegisteredMerchantPhone() || '0770658356').trim();
    if (!phone || phone.includes('9233388') || phone === '0719233388') {
        phone = '0770658356';
    }

    const storeName = document.querySelector('.main')?.innerText || (window.systemConfig?.invPhone ? 'MEC POS Store' : 'MEC BOOK SHOP');
    const shiftDate = shiftData.date || new Date().toISOString().split('T')[0];
    const startTimeStr = shiftData.shiftStartTime || '';
    const closeTimeStr = shiftData.shiftCloseTime || new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    const durationStr = shiftData.shiftDuration || '';

    // Cashier and employee details
    const cashierName = shiftData.cashierName || 'Primary Cashier';
    const cashierEmpId = shiftData.cashierEmpId || '';
    const cashierDesignation = shiftData.cashierDesignation || '';
    const cashierPhone = shiftData.cashierPhone || '';

    const totalBills = parseInt(shiftData.totalBillsCount) || 0;
    const grossSales = parseFloat(shiftData.grossSalesAmount || 0);
    const cardSales = parseFloat(shiftData.cardSalesAmount || 0);
    const bankSales = parseFloat(shiftData.bankSalesAmount || 0);
    const creditSales = parseFloat(shiftData.creditSalesAmount || 0);
    const chequeSales = parseFloat(shiftData.chequeSalesAmount || 0);

    const netCash = parseFloat(shiftData.expectedSales || 0);
    const reloads = parseFloat(shiftData.expectedReloads || 0);
    const expenses = parseFloat(shiftData.expectedExpenses || 0);
    const opening = parseFloat(shiftData.openingCash || 0);

    const expected = parseFloat(shiftData.expectedTotal || 0);
    const actual = parseFloat(shiftData.actualCounted || 0);
    const discrepancy = (shiftData.discrepancy !== undefined) ? parseFloat(shiftData.discrepancy) : (actual - expected);

    // Format variance indicators
    let varianceStatusStr = "LKR 0.00 [BALANCED ✅]";
    let varianceDisplay = "LKR 0.00 (✅ PERFECTLY BALANCED)";
    let auditNote = "✅ Physical drawer cash matches system calculations perfectly.";
    if (Math.abs(discrepancy) >= 0.01) {
        if (discrepancy > 0) {
            varianceStatusStr = `+LKR ${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})} [SURPLUS 🟢]`;
            varianceDisplay = `+LKR ${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})} (🟢 CASH SURPLUS / EXCESS)`;
            auditNote = `🟢 Excess cash of LKR ${discrepancy.toLocaleString(undefined, {minimumFractionDigits: 2})} recorded in drawer.`;
        } else {
            varianceStatusStr = `-LKR ${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})} [SHORTAGE 🔴]`;
            varianceDisplay = `-LKR ${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})} (🔴 CASH SHORTAGE)`;
            auditNote = `🔴 Cash shortage of LKR ${Math.abs(discrepancy).toLocaleString(undefined, {minimumFractionDigits: 2})} detected during shift balancing.`;
        }
    }

    // Cash denominations list (if entered during balancing)
    let denomSection = "";
    if (Array.isArray(shiftData.denominations) && shiftData.denominations.length > 0) {
        const lines = shiftData.denominations.map(d => ` • LKR ${d.val} x ${d.qty} = LKR ${(d.subtotal || (d.val * d.qty)).toLocaleString(undefined, {minimumFractionDigits: 2})}`);
        denomSection = `────────────────────────\n💵 *Cash Denominations Counted:*\n${lines.join('\n')}\n`;
    }

    // Beautiful Full Formatted Rich Message (exact layout requested by user)
    let richMessage = 
`🔐 *MEC POS — CASH SHIFT BALANCING SETTLEMENT* 🔐
🏛️ Store: *${storeName.toUpperCase()}*
📅 Date: *${shiftDate}*
────────────────────────
⏰ Shift Login (Start): *${startTimeStr || 'N/A'}*
🏁 Shift Closed: *${closeTimeStr}*
⏱️ Shift Duration: *${durationStr || 'N/A'}*
👤 Cashier Name: *${cashierName}*
${cashierEmpId ? `🪪 Employee ID: *${cashierEmpId}*\n` : ''}${cashierDesignation ? `💼 Designation: *${cashierDesignation}*\n` : ''}${cashierPhone ? `📞 Staff Phone: *${cashierPhone}*\n` : ''}────────────────────────
🧾 Total Invoices / Bills: *${totalBills} Bills*
💵 Daily Gross Revenue: *LKR ${grossSales.toLocaleString(undefined, {minimumFractionDigits: 2})}*
💳 Card Payments: *LKR ${cardSales.toLocaleString(undefined, {minimumFractionDigits: 2})}*
🏦 Bank Transfers: *LKR ${bankSales.toLocaleString(undefined, {minimumFractionDigits: 2})}*
⏳ Credit (Debt) Sales: *LKR ${creditSales.toLocaleString(undefined, {minimumFractionDigits: 2})}*
${chequeSales > 0 ? `📜 Cheque Payments: *LKR ${chequeSales.toLocaleString(undefined, {minimumFractionDigits: 2})}*\n` : ''}────────────────────────
💰 Net Cash Sales: *LKR ${netCash.toLocaleString(undefined, {minimumFractionDigits: 2})}*
📲 Cash Reloads: *LKR ${reloads.toLocaleString(undefined, {minimumFractionDigits: 2})}*
💸 Cash Expenses (Paid Out): *LKR ${expenses.toLocaleString(undefined, {minimumFractionDigits: 2})}*
🔑 Opening Drawer Cash: *LKR ${opening.toLocaleString(undefined, {minimumFractionDigits: 2})}*
────────────────────────
🎯 Expected Drawer Total: *LKR ${expected.toLocaleString(undefined, {minimumFractionDigits: 2})}*
💵 Actual Physical Count: *LKR ${actual.toLocaleString(undefined, {minimumFractionDigits: 2})}*
⚖️ Shift Variance: *${varianceDisplay}*
${denomSection}────────────────────────
🤖 *AI Virtual CFO Summary:*
${auditNote}

_Shift settlement locked & verified autonomously by MEC POS AI Copilot_ 🚀`;

    // 1. Build Shift Template Payload for approved Meta Template mec_pos_daily_brief
    // (Bypasses Meta 24-hour customer window and delivers directly to CEO WhatsApp 100% of the time!)
    const cashierLabel = cashierEmpId ? `${cashierName} (${cashierEmpId})` : cashierName;
    const shiftTimingLabel = `${shiftDate} | ⏱️ ${durationStr || 'Shift'}${startTimeStr ? ' (' + startTimeStr + ' - ' + closeTimeStr + ')' : ''}`;
    const shiftKpis = {
        storeName: `${storeName} - SHIFT SETTLEMENT`,
        date: shiftTimingLabel,
        sales: `Gross: LKR ${grossSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Net Cash: LKR ${netCash.toLocaleString(undefined, {minimumFractionDigits: 2})}`,
        profit: varianceStatusStr,
        invoices: `${totalBills} Bills | Cashier: ${cashierLabel}`,
        creditDebt: `Card: ${cardSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Bank: ${bankSales.toLocaleString(undefined, {minimumFractionDigits: 2})} | Credit: ${creditSales.toLocaleString(undefined, {minimumFractionDigits: 2})}`,
        cfoNote: `🎯 Exp: LKR ${expected.toLocaleString(undefined, {minimumFractionDigits: 2})} | 💵 Counted: LKR ${actual.toLocaleString(undefined, {minimumFractionDigits: 2})} | 🔑 Drawer: LKR ${opening.toLocaleString(undefined, {minimumFractionDigits: 2})} | 📲 Reloads: ${reloads.toLocaleString(undefined, {minimumFractionDigits: 2})} | 💸 Exp: ${expenses.toLocaleString(undefined, {minimumFractionDigits: 2})}`
    };

    console.log(`[Shift WhatsApp] Dispatching autonomous shift settlement to CEO (${phone}) [ManualInteractive: ${isManualInteractive}]:\n`, richMessage);

    // Step A: Send Beautiful Rich Text directly via Meta WhatsApp API (full emoji & metric layout)
    let textRes = await sendDirectMetaWhatsAppText(phone, richMessage);

    if (textRes.success) {
        if (window.showToast) window.showToast("✅ Shift settlement sent directly to CEO WhatsApp!", "success");
        return true;
    }

    console.warn("Direct Meta WhatsApp text failed, attempting approved template fallback:", textRes.error);

    // Step B: Send Approved Meta Template mec_pos_daily_brief (Bypasses Meta 24-hour customer window)
    let templateRes = false;
    try {
        if (typeof dispatchMetaTemplateMessage === 'function') {
            templateRes = await dispatchMetaTemplateMessage(phone, shiftKpis);
        }
    } catch (tmplErr) {
        console.warn("Template dispatch error:", tmplErr);
    }

    if (templateRes) {
        if (window.showToast) window.showToast("✅ Shift settlement sent to CEO WhatsApp (via Meta Template)!", "success");
        return true;
    }

    // Step C: Fallback to WhatsApp Web / Desktop App if manual resend OR if Cloud API failed
    const norm = (typeof window.normalizePhone === 'function') ? window.normalizePhone(phone) : { formatted: phone.replace(/[^0-9]/g, '') };
    const cleanTo = norm.formatted || '94770658356';
    const targetUrl = `https://wa.me/${cleanTo}?text=${encodeURIComponent(richMessage)}`;

    if (isManualInteractive) {
        if (typeof window.openExternalUrl === 'function') {
            window.openExternalUrl(targetUrl);
        } else if (window.electronAPI?.openExternal) {
            window.electronAPI.openExternal(targetUrl);
        } else if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage(JSON.stringify({ type: 'openExternalUrl', action: 'openExternalUrl', url: targetUrl }));
            } catch(e) {
                window.open(targetUrl, '_blank');
            }
        } else {
            window.open(targetUrl, '_blank');
        }
        if (window.showToast) window.showToast("📲 Opened WhatsApp to send Shift Summary!", "info");
        return true;
    } else {
        console.warn("Meta WhatsApp API direct text and template both failed:", textRes?.error);
        if (window.showToast) {
            window.showToast(`⚠️ Shift saved! Click 📲 icon in History to send via WhatsApp Web.`, "warning");
        }
    }
    return false;
}
window.sendShiftBalancingWhatsApp = sendShiftBalancingWhatsApp;

// Manual Dispatch Trigger
window.sendManualCeoDailyWhatsAppReport = async () => {
    const phone = (copilotConfig.ceoPhone || document.getElementById('copilot-ceo-phone-input')?.value || getRegisteredMerchantPhone() || '0770658356').trim();
    if (!phone) {
        window.showToast("⚠️ Please enter a valid CEO phone number first", "error");
        return;
    }
    window.showToast("🚀 Sending CEO WhatsApp Financial Brief...", "info");

    let message = buildCeoWhatsAppBriefText();

    // 1. Send Rich Text directly via Meta WhatsApp API!
    const textRes = await sendDirectMetaWhatsAppText(phone, message);
    if (textRes.success) {
        window.showToast(`✅ WhatsApp Brief Dispatched to CEO (${phone})!`, "success");
    } else {
        console.warn("Meta Direct Text failed, trying fallback template:", textRes.error);
        const metaRes = await sendMetaWhatsAppMessage(phone, message);
        if (metaRes.success) {
            window.showToast(`✅ WhatsApp Brief Dispatched to CEO!`, "success");
        } else {
            const errMsg = metaRes.error?.error?.message || metaRes.error?.message || "Delivery failed";
            window.showToast(`⚠️ WhatsApp: ${errMsg}`, "warning");
            launchWhatsAppUrl(phone, message);
        }
    }

    // 2. Generate PDF in background (non-blocking)
    generateAndUploadDailyPDF().catch(err => {
        console.warn("Background PDF generation:", err);
    });
};

// Manual Audit Execution
window.runInteractiveDiagnostic = async () => {
    window.showToast("🤖 Running full AI Business Audit...", "info");
    await runSilentDiagnostics();
    calculateCopilotMetrics();
    window.showToast("✅ AI Business Audit Complete! Insights generated in Decision Log.", "success");
};
