// High-Performance IndexedDB + C# Offline Cache Engine for MEC POS
// Universal Offline-First speed: 0ms retrieval for Web, Desktop (C# WebView2), and Android

const DB_NAME = 'MEC_POS_OFFLINE_DB';
const DB_VERSION = 1;
const STORE_NAME = 'offline_collections';
const cacheCallbacks = {};

function getIDB() {
    return new Promise((resolve) => {
        if (!window.indexedDB) {
            return resolve(null);
        }
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'collection' });
            }
        };
        request.onsuccess = (event) => resolve(event.target.result);
        request.onerror = (e) => {
            console.warn("[CacheManager IDB] DB Open error:", e);
            resolve(null);
        };
    });
}

// Write to IndexedDB in background
async function idbSet(collectionName, dataObj) {
    try {
        const db = await getIDB();
        if (!db) return;
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.put({
            collection: collectionName,
            data: dataObj,
            updatedAt: Date.now()
        });
    } catch (e) {
        console.warn(`[CacheManager IDB] Put error for ${collectionName}:`, e);
    }
}

// Read from IndexedDB instantly
async function idbGet(collectionName) {
    try {
        const db = await getIDB();
        if (!db) return null;
        return new Promise((resolve) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const req = store.get(collectionName);
            req.onsuccess = () => {
                resolve(req.result ? req.result.data : null);
            };
            req.onerror = () => resolve(null);
        });
    } catch (e) {
        console.warn(`[CacheManager IDB] Get error for ${collectionName}:`, e);
        return null;
    }
}

// Global listener for data returned from C# wrapper
window.onOfflineCacheLoaded = (collectionName, data) => {
    try {
        let parsedData = null;
        if (data) {
            parsedData = JSON.parse(data);
        }
        if (parsedData) {
            // Also mirror C# desktop cache to IndexedDB for ultra-speed
            idbSet(collectionName, parsedData);
        }
        if (cacheCallbacks[collectionName]) {
            cacheCallbacks[collectionName].forEach(cb => cb(parsedData));
            delete cacheCallbacks[collectionName];
        }
    } catch (e) {
        console.error(`Error parsing offline cache for ${collectionName}:`, e);
        if (cacheCallbacks[collectionName]) {
            cacheCallbacks[collectionName].forEach(cb => cb(null));
            delete cacheCallbacks[collectionName];
        }
    }
};

const csharpSaveTimers = {};

export const saveOfflineCache = (collectionName, dataObj) => {
    // 1. Instant background persistence into IndexedDB (0ms)
    idbSet(collectionName, dataObj);

    // 2. Also send to C# desktop wrapper if available to write desktop backup file (debounced & async)
    if (window.chrome && window.chrome.webview) {
        if (csharpSaveTimers[collectionName]) {
            clearTimeout(csharpSaveTimers[collectionName]);
        }
        csharpSaveTimers[collectionName] = setTimeout(() => {
            try {
                // Execute in idle or next tick to prevent blocking POS UI
                const runSave = () => {
                    const dataStr = JSON.stringify(dataObj);
                    window.chrome.webview.postMessage({
                        type: 'saveOfflineCache',
                        collection: collectionName,
                        data: dataStr
                    });
                    console.log(`[CacheManager] Saved ${collectionName} to offline wrapper cache.`);
                };
                if (window.requestIdleCallback) {
                    window.requestIdleCallback(runSave, { timeout: 1000 });
                } else {
                    setTimeout(runSave, 0);
                }
            } catch (e) {
                console.error(`[CacheManager] Failed to save ${collectionName}:`, e);
            }
        }, collectionName === 'products' ? 800 : 200);
    }
};

export const loadOfflineCache = async (collectionName) => {
    // 1. First check high-speed Local IndexedDB (Instant 0ms, works in all browsers and webview)
    const localData = await idbGet(collectionName);
    if (localData) {
        return localData;
    }

    // 2. Fallback to C# Desktop file if running in C# wrapper
    return new Promise((resolve) => {
        if (window.chrome && window.chrome.webview) {
            if (!cacheCallbacks[collectionName]) {
                cacheCallbacks[collectionName] = [];
            }
            cacheCallbacks[collectionName].push(resolve);
            
            try {
                window.chrome.webview.postMessage({
                    type: 'loadOfflineCache',
                    collection: collectionName
                });
                console.log(`[CacheManager] Requested ${collectionName} from offline wrapper cache.`);
                
                setTimeout(() => {
                    if (cacheCallbacks[collectionName]) {
                        console.warn(`[CacheManager] Offline cache load timed out for ${collectionName}.`);
                        window.onOfflineCacheLoaded(collectionName, null);
                    }
                }, 1000);
            } catch (e) {
                console.error(`[CacheManager] Failed to request ${collectionName}:`, e);
                resolve(null);
            }
        } else {
            resolve(null);
        }
    });
};
