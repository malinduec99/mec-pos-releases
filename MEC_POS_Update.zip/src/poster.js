import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";
import { db } from './firebase.js';

// ─── Instant Prefill from Cache (Zero-delay render) ───────────────
try {
    const cachedLogo = localStorage.getItem('mecpos_store_logo');
    if (cachedLogo && !cachedLogo.includes('/logo.png') && !cachedLogo.includes('zenith_logo')) {
        const logoEl = document.getElementById('merchant-logo');
        if (logoEl) logoEl.src = cachedLogo;
    }
} catch (e) {
    // Ignore cache error
}

// ─── Dynamic Merchant Branding Resolution ─────────────────────────
async function syncPosterBranding() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const storeParam = urlParams.get('store');
        const hostname = window.location.hostname;
        const cleanHostname = hostname.replace(/^www\./, '');
        
        let matchedStore = null;
        let storeId = storeParam;

        // 1. Resolve by explicit ?store= parameter
        if (storeParam) {
            try {
                const qSlug = query(collection(db, 'stores'), where('slug', '==', storeParam));
                const snap = await getDocs(qSlug);
                if (!snap.empty) {
                    matchedStore = snap.docs[0].data();
                } else {
                    const snapDoc = await getDoc(doc(db, 'stores', storeParam));
                    if (snapDoc.exists()) matchedStore = snapDoc.data();
                }
            } catch (e) {
                console.warn('Error resolving store by param:', e);
            }
        }

        // 2. Resolve by Domain
        if (!matchedStore) {
            const isBookShopDomain = ['mecbookshop.web.lk', 'mecbookshop.com.lk', 'mec-book-shop.web.app', 'localhost', '127.0.0.1'].includes(cleanHostname);
            if (isBookShopDomain) {
                storeId = 'mec-book-shop';
            } else {
                try {
                    const qDom = query(collection(db, 'stores'), where('domain', '==', cleanHostname));
                    const snapDom = await getDocs(qDom);
                    if (!snapDom.empty) matchedStore = snapDom.docs[0].data();
                } catch (e) {
                    console.warn('Error resolving store by domain:', e);
                }
            }
        }

        // 3. Fallback to slug or default 'mec-book-shop'
        if (!matchedStore) {
            const targetSlug = storeId || localStorage.getItem('mecpos_last_store_id') || 'mec-book-shop';
            try {
                const qDefault = query(collection(db, 'stores'), where('slug', '==', targetSlug));
                const snapDef = await getDocs(qDefault);
                if (!snapDef.empty) {
                    matchedStore = snapDef.docs[0].data();
                } else {
                    const snapDocDef = await getDoc(doc(db, 'stores', targetSlug));
                    if (snapDocDef.exists()) matchedStore = snapDocDef.data();
                }
            } catch (e) {
                console.warn('Error resolving store fallback:', e);
            }
        }

        // 4. Check config collection for store details (bizName, invAddress, invPhone, storeLogoUrl)
        let storeConfig = null;
        const resolvedStoreSlug = matchedStore?.slug || storeId || 'mec-book-shop';
        if (resolvedStoreSlug) {
            try {
                const cfgSnap = await getDoc(doc(db, 'config', resolvedStoreSlug));
                if (cfgSnap.exists()) storeConfig = cfgSnap.data();
            } catch (e) {}
        }

        // 5. Merchant Logo Resolution (Avoid POS Zenith logo)
        const rawLogo = storeConfig?.storeLogoUrl || storeConfig?.logoUrl || matchedStore?.logoUrl || matchedStore?.storeLogoUrl || localStorage.getItem('mecpos_store_logo');
        const merchantLogo = (rawLogo && rawLogo.trim() !== '' && !rawLogo.includes('zenith_logo') && !rawLogo.includes('/logo.png'))
            ? rawLogo
            : '/mec-logo.png';

        const logoImg = document.getElementById('merchant-logo');
        if (logoImg) {
            logoImg.src = merchantLogo;
            logoImg.alt = matchedStore?.name || 'Merchant Logo';
        }

        const faviconLink = document.getElementById('favicon-link');
        if (faviconLink) {
            faviconLink.href = merchantLogo;
        }

        // Store Name
        const storeName = storeConfig?.bizName || matchedStore?.name || matchedStore?.bizName || 'MEC Book Shop';
        const nameEl = document.getElementById('poster-store-name');
        if (nameEl) nameEl.textContent = storeName;

        // Tagline / Category
        const tagline = matchedStore?.tagline || matchedStore?.category || (storeName === 'MEC Book Shop' ? 'Books • Stationery • Digital Printing' : 'Official Retail Store');
        const taglineEl = document.getElementById('poster-store-tagline');
        if (taglineEl) taglineEl.textContent = tagline;

        document.title = `${storeName} — Print Shop QR Poster / Standee`;

        // Download URL & QR Code
        const cleanHost = (cleanHostname === 'localhost' || cleanHostname === '127.0.0.1') ? 'mecbookshop.web.lk' : cleanHostname;
        const downloadUrl = (matchedStore?.downloadUrl)
            ? matchedStore.downloadUrl
            : `https://${cleanHost}/download${storeParam ? '?store=' + encodeURIComponent(storeParam) : ''}`;

        const qrImg = document.getElementById('poster-qr-img');
        if (qrImg) {
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(downloadUrl)}`;
            qrImg.alt = `${storeName} App QR Code`;
        }

        const qrText = document.getElementById('poster-download-text');
        if (qrText) {
            qrText.textContent = downloadUrl.replace(/^https?:\/\//, '');
        }

        // Back button parameter preservation
        const backBtn = document.getElementById('btn-back-download');
        if (backBtn && storeParam) {
            backBtn.href = `/download?store=${encodeURIComponent(storeParam)}`;
        }

        // Footer info
        const address = storeConfig?.invAddress || matchedStore?.address || matchedStore?.location || (storeName === 'MEC Book Shop' ? 'No. 97, Victoria Estate, Panadura Road, Munagama, Horana' : '');
        const addressEl = document.getElementById('poster-footer-address');
        if (addressEl) {
            if (address) {
                addressEl.textContent = `📍 ${address}`;
                addressEl.style.display = '';
            } else {
                addressEl.style.display = 'none';
            }
        }

        const domainText = matchedStore?.domain || cleanHost;
        const webEl = document.getElementById('poster-footer-web');
        if (webEl) webEl.textContent = domainText;

        const phone = storeConfig?.invPhone || matchedStore?.phone || matchedStore?.invPhone || '+94 71 923 3388';
        const phoneEl = document.getElementById('poster-footer-phone');
        if (phoneEl) phoneEl.textContent = phone;

    } catch (err) {
        console.error('Error syncing poster branding:', err);
    }
}

syncPosterBranding();
