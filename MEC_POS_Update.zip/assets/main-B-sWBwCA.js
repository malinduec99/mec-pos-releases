/* empty css              */import{G as nt}from"./index-C9C3758q.js";import{a as Y,c as E,d as C,s as G,o as xe,q as T,w as k,g as A,b as X,e as Me,i as we,f as at,u as Xe,h as rt,l as it,j as st,k as lt,m as Fe}from"./firebase-Bn3UcnFE.js";window.uploadLogToCloud=async(e,t="error")=>{try{const n=window.currentStoreId||"unknown",s=window.HostPCName||navigator.userAgent||"WebBrowser";await Y(E(C,"systemLogs"),{message:e,level:t,storeId:n,pcName:s,timestamp:G()})}catch(n){console.error("Failed to upload log:",n)}};window.addEventListener("error",e=>{window.uploadLogToCloud(`Web Error: ${e.message} at ${e.filename}:${e.lineno}`,"error")});window.addEventListener("unhandledrejection",e=>{window.uploadLogToCloud(`Promise Rejection: ${e.reason}`,"error")});function dt(){try{const e=localStorage.getItem("mecThemeColors");if(e){const t=JSON.parse(e),n=document.documentElement;n.style.setProperty("--primary-blue",t.primary),n.style.setProperty("--accent-blue",t.accent),n.style.setProperty("--admin-bg",t.bg),n.style.setProperty("--glass-bg",t.glass),n.style.setProperty("--primary-color",t.primary),n.style.setProperty("--secondary-color",t.accent),n.style.setProperty("--deep-bg",t.bg),t.bg==="#0f172a"||t.bg==="#11011c"||t.bg==="#022c22"?(n.style.setProperty("--text-dark","#f8fafc"),n.style.setProperty("--text-muted","#94a3b8")):(n.style.setProperty("--text-dark","#0f172a"),n.style.setProperty("--text-muted","#64748b"))}}catch{}}dt();function pe(){const e=document.querySelector("header");if(e){const n=e.getBoundingClientRect().height;document.documentElement.style.setProperty("--header-height",`${Math.round(n)}px`)}const t=document.getElementById("product-grid-header");if(t&&e){const n=e.getBoundingClientRect().height,o=t.getBoundingClientRect().top<=Math.round(n)+2;t.classList.toggle("is-stuck",o)}}window.addEventListener("resize",pe);window.addEventListener("scroll",pe,{passive:!0});document.addEventListener("DOMContentLoaded",pe);setTimeout(pe,200);setTimeout(pe,800);const Ze=new URLSearchParams(window.location.search),Z=window.location.pathname.split("/").filter(e=>e!=="");let Te=null;Z[0]==="store"&&Z[1]?Te=Z[1]:Z[0]&&!["index.html","store.html","track","admin","login.html","merchant-login.html","platform.html"].includes(Z[0])&&(Te=Z[0]);const ct=Ze.get("store")||Te;window.currentStoreId=ct||null;window.currentStoreData=null;try{const e=sessionStorage.getItem("mec_customer_profile");e?window.currentUserProfile=JSON.parse(e):window.currentUserProfile={customerType:"retail"}}catch{window.currentUserProfile={customerType:"retail"}}const ye=E(C,"stores"),ne=window.location.hostname;async function pt(){let e=null;try{if(window.currentStoreId){const t=T(ye,k("slug","==",window.currentStoreId)),n=await A(t);if(!n.empty)e={...n.docs[0].data(),docId:n.docs[0].id};else try{const s=X(C,"stores",window.currentStoreId),o=await at(s);o.exists()&&(e={...o.data(),docId:o.id})}catch{}}else if(["mecbookshop.web.lk","mecbookshop.com.lk","mec-book-shop.web.app","localhost","127.0.0.1"].includes(ne)){window.currentStoreId="mec-book-shop";const n=T(ye,k("slug","==","mec-book-shop")),s=await A(n);s.empty||(e={...s.docs[0].data(),docId:s.docs[0].id})}else if(ne==="mecpos.web.lk"||ne==="mec-pos-shop.web.app"||ne==="mecpos-web-lk.web.app")window.currentStoreId=null;else{const n=ne.replace(/^www\./,""),s=T(ye,k("domain","==",n)),o=await A(s);o.empty||(e={...o.docs[0].data(),docId:o.docs[0].id})}}catch(t){console.error("Store resolution query failed:",t)}if(e)window.currentStoreData=e,window.currentStoreId=e.slug||e.storeSlug||e.docId||"mec-book-shop",console.log("Resolved Store ID:",window.currentStoreId),He(),je(),typeof window.checkAffReferral=="function"&&window.checkAffReferral();else{window.currentStoreId||(window.currentStoreId="mec-book-shop");try{const n=T(ye,k("slug","==","mec-book-shop")),s=await A(n);s.empty||window.currentStoreId==="mec-book-shop"&&(window.currentStoreData=s.docs[0].data())}catch(n){console.error("Error loading fallback store data:",n)}console.log("Resolved Store ID (Fallback):",window.currentStoreId),He(),je(),typeof window.checkAffReferral=="function"&&window.checkAffReferral()}}pt();function He(){var h,u,f,g,b,y,B,w,P,S,$,L,z,M,O;let e=(h=window.currentStoreData)==null?void 0:h.name;e||(window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?e=window.currentStoreId.split("-").map(I=>I.charAt(0).toUpperCase()+I.slice(1)).join(" "):e="MEC Book Shop"),e==="MEC POS"&&(e="MEC Book Shop"),document.title=`${e} | Official Store`;const t=(f=(u=window.currentStoreData)==null?void 0:u.webDesign)==null?void 0:f.primary,n=(b=(g=window.currentStoreData)==null?void 0:g.webDesign)==null?void 0:b.accent;t&&document.documentElement.style.setProperty("--primary-color",t),n&&document.documentElement.style.setProperty("--secondary-color",n),document.querySelectorAll(".logo-text").forEach(I=>{I.innerText=e});const s=window.currentStoreId&&window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master";s?(document.querySelectorAll(".bookshop-brand-banner").forEach(I=>I.style.display="none"),document.querySelectorAll(".merchant-only").forEach(I=>I.style.display="")):(document.querySelectorAll(".bookshop-brand-banner").forEach(I=>I.style.display="block"),document.querySelectorAll(".merchant-only").forEach(I=>I.style.display="none"));const o=(y=window.currentStoreData)==null?void 0:y.logoUrl,i=o&&o.trim()!==""&&!o.includes("zenith_logo")&&!o.includes("/logo.png")?o:"/mec-logo.png";document.querySelectorAll(".logo-img, #pwa-install-banner img").forEach(I=>{I.src=i,I.style.display=s?"":I.classList.contains("merchant-only")?"none":""});const r=document.getElementById("hero");if(r){const I=(w=(B=window.currentStoreData)==null?void 0:B.webDesign)==null?void 0:w.bannerUrl,D=I&&I.length>10?I:window.currentStoreId==="mec-book-shop"?"/banner.png":null;if(D)r.innerHTML=`
        <div class="banner-container" id="banner-container" style="width: 100%;">
          <img id="main-banner" src="${D}" alt="${e} Banner" decoding="async" fetchpriority="high" style="width: 100%; height: 100%; object-fit: contain; display: block;">
        </div>
      `;else{const oe=((S=(P=window.currentStoreData)==null?void 0:P.webContent)==null?void 0:S.welcome)||`Welcome to ${e}`,Be=((L=($=window.currentStoreData)==null?void 0:$.webContent)==null?void 0:L.announce)||"Your premium destination for high-quality products and services.";r.innerHTML=`
        <div class="hero-content" style="text-align: center; width: 90%; max-width: 1100px; margin: 0 auto; padding: 2.5rem 2rem;">
          <h1 id="hero-welcome-text" style="color: white; font-weight: 800; text-shadow: 0 4px 10px rgba(0,0,0,0.3); font-size: 2.5rem; margin-bottom: 1rem;">${oe}</h1>
          <p id="hero-sub-text" style="color: rgba(255,255,255,0.9); font-weight: 500; margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.5;">${Be}</p>
          <button id="shop-now-btn" style="padding: 0.8rem 2rem; font-size: 1rem;" onclick="document.getElementById('shop-section').scrollIntoView({ behavior: 'smooth' })">Shop Now</button>
        </div>
      `}}const d=document.getElementById("page-title");d&&(d.innerText=`${e} | Official Store`);const a=document.getElementById("footer-copy");a&&(a.innerText=`© 2026 ${e}. All rights reserved.`);const l=((z=window.currentStoreData)==null?void 0:z.webEpinics)||{},c=!!l.multiVendor,p=!!l.affiliate;(M=document.getElementById("nav-sell-with-us"))==null||M.remove(),(O=document.getElementById("nav-affiliate-program"))==null||O.remove();const m=document.getElementById("nav-menu");if(m){const I=document.getElementById("nav-auth-item");if(c){const D=document.createElement("li");D.id="nav-sell-with-us",D.innerHTML='<a href="#" onclick="window.toggleSellerPortal(true); return false;">Sell With Us</a>',I?m.insertBefore(D,I):m.appendChild(D)}if(p){const D=document.createElement("li");D.id="nav-affiliate-program",D.innerHTML='<a href="#" onclick="window.toggleAffiliatePortal(true); return false;">Affiliate Program</a>',I?m.insertBefore(D,I):m.appendChild(D)}}document.documentElement.classList.remove("loading-merchant")}let ae;const J=document.createElement("div");J.id="pwa-install-banner";J.innerHTML=`
    <div style="position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:var(--primary-color); color:white; padding:15px 25px; border-radius:50px; display:flex; align-items:center; gap:15px; box-shadow:0 10px 25px rgba(0,0,0,0.3); z-index:9999; cursor:pointer; width:max-content; animation: slideUp 0.5s ease-out;">
        <img src="/logo.png" style="width:30px; height:30px; border-radius:5px;">
        <div>
            <div style="font-weight:bold; font-size:0.9rem;">Install MEC App</div>
            <div style="font-size:0.75rem; opacity:0.9;">Faster access & offline shopping</div>
        </div>
        <button id="pwa-close" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer; margin-left:10px;">&times;</button>
    </div>
    <style>
        @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }
    </style>
`;J.style.display="none";document.body.appendChild(J);window.addEventListener("beforeinstallprompt",e=>{e.preventDefault(),ae=e,J.style.display="block"});J.addEventListener("click",async e=>{if(e.target.id==="pwa-close"){J.style.display="none";return}if(ae){ae.prompt();const{outcome:t}=await ae.userChoice;t==="accepted"&&(J.style.display="none"),ae=null}});"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").then(e=>{console.log("SW Registered",e.scope)}).catch(e=>{console.log("SW Registration Failed",e)})});const H=document.getElementById("menu-toggle"),j=document.getElementById("nav-menu"),U=document.getElementById("mobile-menu-overlay"),ke=()=>{j==null||j.classList.remove("active"),H==null||H.classList.remove("active"),U==null||U.classList.remove("active")};H==null||H.addEventListener("click",()=>{const e=j==null?void 0:j.classList.toggle("active");H==null||H.classList.toggle("active"),e?U==null||U.classList.add("active"):U==null||U.classList.remove("active")});const Ee=document.getElementById("close-menu");Ee==null||Ee.addEventListener("click",ke);U==null||U.addEventListener("click",ke);j==null||j.querySelectorAll("a").forEach(e=>{e.addEventListener("click",ke)});function ue(e,t){var s;if(typeof e=="string"&&e.trim()!==""){const o=e.trim();if((o.startsWith("data:")||o.startsWith("blob:")||o.startsWith("http")||o.startsWith("/"))&&!o.includes("placehold.co")&&!o.includes("zenith_logo.png")&&!o.includes("/logo.png"))return o}const n=(s=window.currentStoreData)==null?void 0:s.logoUrl;return n&&n.trim()!==""&&!n.includes("zenith_logo.png")&&!n.includes("/logo.png")?n:"/mec-logo.png"}const ut=[{id:1,name:"Atlas CR Book (80 Pages)",price:350,category:"Notebooks",image:"https://placehold.co/400x300/002060/FFF?text=Atlas+CR+80"},{id:2,name:"Promate Exercise Book (120 Pg)",price:280,category:"Notebooks",image:"https://placehold.co/400x300/EC008C/FFF?text=Promate+120"}],re=E(C,"products"),mt=E(C,"orders"),gt=E(C,"promotions"),ft=E(C,"branches"),bt=["Ahangama","Ahungalla","Akuressa","Alawwa","Aluthgama","Ambalangoda","Ambalantota","Ampara","Angoda","Anuradhapura","Aranayaka","Athurugiriya","Avissawella","Baddegama","Badulla","Balangoda","Bandaragama","Bandarawela","Battaramulla","Batticaloa","Beliatta","Bentota","Beruwala","Biyagama","Boralasgamuwa","Boralesgamuwa","Bulathsinhala","Chavakachcheri","Chilaw","Chunnakam","Colombo 01 - Fort","Colombo 02 - Slave Island","Colombo 03 - Kollupitiya","Colombo 04 - Bambalapitiya","Colombo 05 - Havelock Town","Colombo 06 - Wellawatte","Colombo 07 - Cinnamon Gardens","Colombo 08 - Borella","Colombo 09 - Dematagoda","Colombo 10 - Maradana","Colombo 11 - Pettah","Colombo 12 - Hultsdorf","Colombo 13 - Kotahena","Colombo 14 - Grandpass","Colombo 15 - Mutwal","Dambulla","Dankotuwa","Dehiowita","Dehiwala","Delgoda","Deniyaya","Deraniyagala","Digana","Divulapitiya","Dodangoda","Dompe","Eheliyagoda","Elpitiya","Embilipitiya","Eppawala","Galagedara","Galgamuwa","Galewela","Galle","Gampaha","Gampola","Gelioya","Giriulla","Godakawela","Gonapinuwala","Habarana","Hakmana","Hambantota","Hanwella","Haputale","Hatton","Hettipola","Hikkaduwa","Hingurakgoda","Hokandara","Homagama","Horana","Ibbagamuwa","Imaduwa","Ingiriya","Ja-Ela","Jaffna","Kadawatha","Kaduwela","Kahawatta","Kalawana","Kalmunai","Kalutara","Kamburupitiya","Kandana","Kandy","Karapitiya","Katubedda","Katugastota","Katunayake","Kegalle","Kekirawa","Kelaniya","Kesbewa","Kilinochchi","Kiribathgoda","Kirinda","Kochchikade","Kohuwala","Kolonnawa","Koralawella","Kosgoda","Kotikawatta","Kottawa","Kuliyapitiya","Kundasale","Kurunegala","Mabima","Madampe","Madapatha","Maharagama","Mahiyanganaya","Malabe","Mannar","Marawila","Maskeliya","Matale","Matara","Mathugama","Matugama","Mawathagama","Medawachchiya","Meegoda","Melsiripura","Menikhinna","Minuwangoda","Mirigama","Mirissa","Monaragala","Moratuwa","Mount Lavinia","Mullaitivu","Narahenpita","Narammala","Naththandiya","Nawala","Nawalapitiya","Negombo","Nelundeniya","Nittambuwa","Nochchiyagama","Nugegoda","Nuwara Eliya","Padukka","Paiyagala","Palavi","Pallekele","Panadura","Pannala","Pannipitiya","Pasikuda","Passara","Peliyagoda","Pelmadulla","Peradeniya","Pilimathalawa","Piliyandala","Pitakotte","Polgahawela","Polonnaruwa","Pugoda","Pundaluoya","Puttalam","Radawana","Ragama","Rajagiriya","Rambukkana","Ranala","Ranna","Rathgama","Ratmalana","Ratnapura","Rikillagaskada","Ruwanwella","Seeduwa","Sigiriya","Talawakele","Tangalle","Thalawathugoda","Thambuttegama","Thihariya","Tissamaharama","Trincomalee","Udugama","Udumulla","Ukuwela","Unawatuna","Urubokka","Uswetakeiyawa","Valvettithurai","Vavuniya","Veyangoda","Wadduwa","Walasmulla","Warakapola","Wariyapola","Waskaduwa","Wattala","Weligama","Welikanda","Welimada","Welipenna","Welisara","Weliweriya","Wellampitiya","Wellawaya","Wennappuwa","Wijerama","Yakkala","Yatiyanthota"];let We=[];xe(ft,e=>{We=e.docs.map(t=>({...t.data(),docId:t.id})),window.allStoreBranches=We,typeof window.populatePickupShops=="function"&&window.populatePickupShops()});function ie(){var s,o,i,r;const e=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master";let t=(window.allStoreBranches||[]).filter(d=>e||d.storeId===window.currentStoreId||!d.storeId);const n={docId:"main",name:(((s=window.currentStoreData)==null?void 0:s.name)||"MEC Book Shop")+" - Main Branch",location:((o=window.currentStoreData)==null?void 0:o.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",address:((i=window.currentStoreData)==null?void 0:i.address)||"No.97, Victoria Park, Rathnapura Road, Munagama, Horana",city:"Horana",district:"Kalutara",phone:((r=window.currentStoreData)==null?void 0:r.phone)||"071 923 3388"};return t.length===0&&(t=[n]),t}window.getAllAvailableShops=ie;function et(){const t=ie().map(s=>(s.location||s.city||"").trim()).filter(s=>s.length>0);return Array.from(new Set([...t,...bt])).filter(Boolean).sort((s,o)=>s.localeCompare(o,void 0,{sensitivity:"base"}))}window.getAvailableTowns=et;let _=[],me=0,x=[],Q="All",R=1,$e=12,ee="recommended",W="",Le=null;document.getElementById("cart-count");window.webStoreBankAccounts={slot1:{docId:"ndb_default",bankName:"National Development Bank (NDB)",badge:"NDB",accountName:"MEC BOOK SHOP & COMMUNICATION",accountType:"Regular Current",bankCode:"7214",swiftCode:"NDBSLKLX",accountNo:"111000391437"},slot2:{docId:"boc_default",bankName:"Bank of Ceylon (BOC)",badge:"BOC",accountName:"WPM Shamesh",branch:"Horana Branch",bankCode:"",swiftCode:"",accountType:"Savings",accountNo:"0084334885"}};window.selectedWebStoreBankSlot="slot1";window.selectWebStoreBankSlot=e=>{window.selectedWebStoreBankSlot=e;const t=document.getElementById("web-bank-card-1"),n=document.getElementById("web-bank-card-2"),s=document.getElementById("web-slot-1-radio"),o=document.getElementById("web-slot-2-radio"),i=document.getElementById("web-bank-1-badge"),r=document.getElementById("web-bank-2-badge");e==="slot1"?(s&&(s.checked=!0),o&&(o.checked=!1),t&&(t.style.background="#f0fdf4",t.style.borderColor="#16a34a",t.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),n&&(n.style.background="#ffffff",n.style.borderColor="#cbd5e1",n.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),i&&(i.style.background="#16a34a",i.style.color="#ffffff",i.innerText="✓ Selected"),r&&(r.style.background="#f1f5f9",r.style.color="#64748b",r.innerText="Click to select")):(s&&(s.checked=!1),o&&(o.checked=!0),n&&(n.style.background="#f0fdf4",n.style.borderColor="#16a34a",n.style.boxShadow="0 4px 14px rgba(22, 163, 74, 0.15)"),t&&(t.style.background="#ffffff",t.style.borderColor="#cbd5e1",t.style.boxShadow="0 2px 8px rgba(0,0,0,0.06)"),r&&(r.style.background="#16a34a",r.style.color="#ffffff",r.innerText="✓ Selected"),i&&(i.style.background="#f1f5f9",i.style.color="#64748b",i.innerText="Click to select"))};window.copyBankDetails=(e,t)=>{const n=document.getElementById(e);if(!n)return;const s=n.innerText.trim();navigator.clipboard.writeText(s),alert(`${t} Copied: ${s}`)};window.updateWebStoreBankCardsUI=()=>{var n,s;const e=(n=window.webStoreBankAccounts)==null?void 0:n.slot1,t=(s=window.webStoreBankAccounts)==null?void 0:s.slot2;if(e){const o=document.getElementById("web-bank-1-title"),i=document.getElementById("web-bank-1-accname"),r=document.getElementById("web-bank-1-accno"),d=document.getElementById("web-bank-1-acctype"),a=document.getElementById("web-bank-1-code"),l=document.getElementById("web-bank-1-swift");o&&e.bankName&&(o.innerText=`🏦 ${e.bankName}`),i&&e.accountName&&(i.innerText=e.accountName),r&&e.accountNo&&(r.innerText=e.accountNo),d&&e.accountType&&(d.innerText=e.accountType),a&&e.bankCode&&(a.innerText=e.bankCode),l&&e.swiftCode&&(l.innerText=e.swiftCode)}if(t){const o=document.getElementById("web-bank-2-title"),i=document.getElementById("web-bank-2-accname"),r=document.getElementById("web-bank-2-accno"),d=document.getElementById("web-bank-2-branch");o&&t.bankName&&(o.innerText=`🏦 ${t.bankName}`),i&&t.accountName&&(i.innerText=t.accountName),r&&t.accountNo&&(r.innerText=t.accountNo),d&&t.branch&&(d.innerText=t.branch)}};function yt(){try{const e=localStorage.getItem("mec_webstore_bank_config");if(e){const t=JSON.parse(e);t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data})}}catch{}try{xe(X(C,"config","webstore_bank_accounts"),e=>{if(e.exists()){const t=e.data();t.slot1Data&&(window.webStoreBankAccounts.slot1={...window.webStoreBankAccounts.slot1,...t.slot1Data}),t.slot2Data&&(window.webStoreBankAccounts.slot2={...window.webStoreBankAccounts.slot2,...t.slot2Data}),window.updateWebStoreBankCardsUI()}},e=>console.warn("Web store banks config snapshot warning:",e))}catch(e){console.warn("Could not setup webstore banks listener:",e)}}yt();function je(){let e;window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?e=T(re):e=T(re,k("storeId","==",window.currentStoreId)),xe(e,t=>{const n=t.docs.map(o=>({...o.data(),id:o.id,docId:o.id,sku:o.data().sku||o.id}));if((window.currentStoreId==="mec-book-shop"||window.currentStoreId==="O8ywuZTKSwdL4z77RQ9M"||window.currentStoreId==="master")&&!n.some(i=>i.name&&i.name.trim().toLowerCase()==="other")&&t.docs.length>0){console.log("Auto-creating 'Other' product for MEC Book Shop...");const i={name:"Other",sku:"SKU-OTHER-0000-GEN-P1C0",category:"Uncategorized",mode:"Shop",supplierId:"General",supplierName:"General",cost:0,price:1,wholesalePrice:1,loyaltyPrice:1,discount:0,stock:999999,wStock:0,totalStock:999999,timestamp:G(),salesToday:0,image:"",variants:[],payMethods:{cod:!0,bank:!0,shop:!0},storeId:window.currentStoreId};i.docId=i.sku,Me(X(C,"products",i.sku),i).catch(r=>console.error("Error creating 'Other' product:",r))}_=n.filter(o=>{const r=window.currentStoreId==="mec-book-shop"||window.currentStoreId==="master"?o.storeId==="mec-book-shop"||o.storeId==="master"||!o.storeId:o.storeId===window.currentStoreId,d=o.mode==="Shop"||o.mode==="Warehouse"||o.mode===void 0,a=o.status!=="pending";return r&&d&&a}),_.sort((o,i)=>{var r,d;return(((r=i.timestamp)==null?void 0:r.seconds)||0)-(((d=o.timestamp)==null?void 0:d.seconds)||0)}),_.length===0&&window.currentStoreId==="master"&&ut.forEach(async o=>{await Y(re,o)}),q(),Se()})}var Qe;(Qe=document.getElementById("product-sort"))==null||Qe.addEventListener("change",e=>{ee=e.target.value,R=1,q()});const wt=()=>{document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.addEventListener("input",t=>{W=t.target.value.toLowerCase(),window.searchQuery=W,document.querySelectorAll("#store-search, .store-search-input").forEach(n=>{n!==t.target&&(n.value=t.target.value)}),R=1,q()})})};wt();window.renderProducts=q;window.clearSearch=()=>{W="",window.searchQuery="",document.querySelectorAll("#store-search, .store-search-input").forEach(e=>{e.value=""}),R=1,q()};function Re(){localStorage.setItem("mec_cart",JSON.stringify(x))}function ht(){const e=localStorage.getItem("mec_cart");e&&(x=JSON.parse(e),me=x.reduce((t,n)=>t+(n.quantity||1),0),Ce())}const se=document.createElement("div");se.id="cart-modal";document.body.appendChild(se);const le=document.createElement("div");le.id="cart-overlay";document.body.appendChild(le);window.toggleCart=e=>{e?(se.classList.add("active"),le.classList.add("active"),Pe(),document.body.style.overflow="hidden"):(se.classList.remove("active"),le.classList.remove("active"),document.body.style.overflow="")};const ge=window.toggleCart;le.onclick=()=>ge(!1);const vt=document.querySelectorAll('a[href="#cart"]');vt.forEach(e=>{e.onclick=t=>{t.preventDefault(),ke(),ge(!0)}});const Ve=document.getElementById("shop-now-btn");Ve&&Ve.addEventListener("click",()=>{const e=document.getElementById("shop-section");e&&e.scrollIntoView({behavior:"smooth"})});const tt={All:"🏠",Notebooks:"📓",Stationery:"📎",Writing:"✏️",Art:"🎨",Books:"📖",Pens:"🖋️",School:"🎒",Office:"🏢"};function xt(){return["All",...new Set(_.map(t=>t.category))]}function Se(){const e=xt(),t=document.getElementById("sidebar-category-list"),n=document.getElementById("mobile-category-bar");t&&(t.innerHTML=e.map(r=>`
      <li class="sidebar-cat-item ${r===Q?"active":""}" data-category="${r}">
        <div class="cat-icon-text">
          <span class="cat-icon">${tt[r]||"📁"}</span>
          <span>${r}</span>
        </div>
        <span class="arrow">›</span>
      </li>
    `).join("")),n&&(n.innerHTML=e.map(r=>`
      <button class="mobile-cat-btn ${r===Q?"active":""}" data-category="${r}">
        ${r}
      </button>
    `).join(""));const s=r=>{var a;Q=r;const d=document.getElementById("featured-title");d&&(d.innerText=r==="All"?"Featured Collection":`${r} Collection`),q(),Se(),V(),(a=document.getElementById("shop-section"))==null||a.scrollIntoView({behavior:"smooth"})};document.querySelectorAll(".sidebar-cat-item").forEach(r=>{r.addEventListener("click",d=>{d.stopPropagation(),s(d.currentTarget.dataset.category)}),r.addEventListener("mouseenter",d=>{const a=d.currentTarget.dataset.category;a!=="All"?kt(a,d.currentTarget):V()})}),document.querySelectorAll(".mobile-cat-btn").forEach(r=>{r.addEventListener("click",d=>s(d.target.dataset.category))});const o=document.querySelector(".category-menu-wrapper"),i=document.getElementById("nav-category-btn");i&&o&&(i.onclick=r=>{r.stopPropagation(),o.classList.toggle("active")}),o==null||o.addEventListener("mouseleave",()=>{o.classList.remove("active"),V()})}document.addEventListener("click",e=>{const t=document.querySelector(".category-menu-wrapper");t&&!t.contains(e.target)&&(t.classList.remove("active"),typeof V=="function"&&V())});const K=document.getElementById("mega-menu");let Ie;function kt(e,t){if(!K)return;clearTimeout(Ie),document.querySelectorAll(".sidebar-cat-item").forEach(a=>a.classList.remove("active")),t==null||t.classList.add("active");const n=(_||[]).filter(a=>a.category===e),s={Writing:["Ball Point Pens","Gel Pens","Markers","Pencils"],Pens:["Ball Point","Gel Pens","Highlighters","Ink Pens"],Notebooks:["Hardcover","Softcover","Spiral","CR Books"],Art:["Watercolors","Acrylics","Brushes","Sketchbooks"],STATIONERIES:["Pens & Pencils","Glue & Tape","Erasers & Rulers","Paper & Files"],ATLAS:["CR Books","Exercise Books","Pastels & Color","Geometry Boxes"]}[e]||["Standard Items","Premium Items","New Arrivals"],o=document.getElementById("mega-sidebar-col");o&&(o.innerHTML=`
      <div style="margin-bottom: 1.1rem;">
        <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; margin-bottom: 3px;">Category</div>
        <div style="font-size: 0.95rem; font-weight: 900; color: #38bdf8; display: flex; align-items: center; gap: 6px; word-break: break-word;">
          <span>${tt[e]||"📁"}</span>
          <span>${e}</span>
        </div>
        <div style="font-size: 0.72rem; color: #10b981; font-weight: 700; margin-top: 3px;">${n.length} Items Available</div>
      </div>
      <button type="button" onclick="window.filterByCategoryAndScroll('${e}')" style="width: 100%; padding: 8px 10px; background: linear-gradient(135deg, #ff6600, #ea580c); color: white; border: none; border-radius: 8px; font-weight: 800; font-size: 0.76rem; cursor: pointer; margin-bottom: 1.1rem; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(255,102,0,0.35); box-sizing: border-box;">
        <span>View All</span>
        <span>→</span>
      </button>
      <div style="font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; margin-bottom: 6px;">Filters</div>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        ${s.map(a=>`<a href="#" onclick="event.preventDefault(); window.filterBySubCategory('${a}', '${e}')" style="color: #cbd5e1; font-size: 0.78rem; text-decoration: none; font-weight: 600; padding: 2px 0; transition: color 0.2s;" onmouseover="this.style.color='#ff9800'" onmouseout="this.style.color='#cbd5e1'">• ${a}</a>`).join("")}
      </div>
    `);const i=document.getElementById("mega-products-heading");i&&(i.innerText=`${e} Products (${n.length})`);const r=document.getElementById("mega-products-list");r&&(r.innerHTML=n.length>0?n.map(a=>`
          <a href="#" class="mega-prod-item" onclick="event.preventDefault(); window.openProductDetail('${a.docId}')">
            <img src="${ue(a.image,a.name)}" class="mega-prod-img" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl || '/logo.png');">
            <div class="mega-prod-info">
              <h5 title="${a.name}">${a.name}</h5>
              <div class="price">LKR ${Number(a.price||0).toFixed(2)}</div>
            </div>
          </a>
        `).join(""):'<div style="grid-column: 1 / -1; color: #94a3b8; font-size: 0.85rem; text-align: center; padding: 3rem 0;">No products found in this category.</div>'),K.style.top="calc(100% + 8px)",K.style.left="248px",K.classList.add("active");const d=K.getBoundingClientRect();if(d.right>window.innerWidth-16){const a=d.right-(window.innerWidth-16);K.style.left=`${Math.max(0,248-a)}px`}}function V(){Ie=setTimeout(()=>{K==null||K.classList.remove("active")},400)}K==null||K.addEventListener("mouseenter",()=>clearTimeout(Ie));var Ye;(Ye=document.getElementById("sidebar-category-list"))==null||Ye.addEventListener("mouseenter",()=>clearTimeout(Ie));window.filterByCategoryAndScroll=e=>{var n;Q=e;const t=document.getElementById("featured-title");t&&(t.innerText=e==="All"?"Featured Collection":`${e} Collection`),q(),Se(),V(),(n=document.getElementById("shop-section"))==null||n.scrollIntoView({behavior:"smooth"})};window.filterBySubCategory=(e,t)=>{var s;Q=t,q(),Se();const n=document.getElementById("featured-title");n&&(n.innerText=`${e} in ${t}`),(s=document.getElementById("shop-section"))==null||s.scrollIntoView({behavior:"smooth"}),V()};window.scrollToProduct=e=>{const t=document.getElementById(`product-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"center"}),t.classList.add("highlight-pulse"),setTimeout(()=>t.classList.remove("highlight-pulse"),3e3),V())};function te(e,t=null,n=null){var p;if(!e)return{retailPrice:0,effectivePrice:0,discountedPrice:0,isSpecial:!1,userType:"retail"};const s=(n||((p=window.currentUserProfile)==null?void 0:p.customerType)||"retail").toLowerCase();let o=0,i=0,r=0;t?(o=Number(t.price),(isNaN(o)||o<=0)&&(o=Number(e.price)||0),i=Number(t.wholesalePrice),(isNaN(i)||i<=0)&&(i=Number(e.wholesalePrice)||0),r=Number(t.loyaltyPrice),(isNaN(r)||r<=0)&&(r=Number(e.loyaltyPrice)||0)):(o=Number(e.price)||0,i=Number(e.wholesalePrice)||0,r=Number(e.loyaltyPrice)||0),isNaN(o)&&(o=0);let d=o,a=!1;s==="wholesale"&&i>0?(d=i,a=i!==o):s==="loyalty"&&r>0&&(d=r,a=r!==o);const l=Number(e.discount)||0,c=d*(1-(l>0?l/100:0));return{retailPrice:isNaN(o)?0:o,effectivePrice:isNaN(d)?0:d,discountedPrice:isNaN(c)?0:c,isSpecial:a,userType:s}}window.getCustomerEffectivePrice=te;function de(e,t=null){return _e(e,t,"web")}function _e(e,t=null,n="web"){if(!e)return 0;if(n==="ShopPay"||n==="shop"||n==="Shop"){if(t){const i=parseFloat(t.stock)||0;if(i>0)return i}const o=parseFloat(e.stock||0);return o>0?o:0}else{if(t){const a=parseFloat(t.stock)||0,l=parseFloat(t.wStock)||0,c=a+l;if(c>0)return c}if(e.variants&&e.variants.length>0){const a=e.variants.reduce((l,c)=>l+(parseFloat(c.stock)||0)+(parseFloat(c.wStock)||0),0);if(a>0)return a}const o=parseFloat(e.stock||0),i=parseFloat(e.wStock||0),r=parseFloat(e.totalStock||0),d=o+i;return d>0?d:r>0?r:0}}const ce=document.getElementById("product-detail-modal"),Oe=document.getElementById("product-detail-overlay");window.openProductDetail=e=>{const t=(window.groupedProducts||[]).find(u=>u.docId===e)||_.find(u=>u.docId===e);if(!t)return;const n=Number(t.discount)||0,s=t.variants&&t.variants.length>0,o=s?t.variants[0]:null;let i=t.image;o&&(o.image?i=o.image:o.images&&o.images.length>0&&(i=o.images[0]));const r=te(t,o),d=r.userType,a=r.isSpecial,l=r.retailPrice,c=r.discountedPrice,p=de(t,o),m={red:"#ef4444",blue:"#2563eb",black:"#1e293b",green:"#16a34a",yellow:"#eab308",orange:"#ea580c",purple:"#9333ea",pink:"#db2777",white:"#f8fafc",grey:"#64748b",gray:"#64748b",brown:"#78350f",navy:"#1e3a8a",cyan:"#0891b2",gold:"#d97706",silver:"#94a3b8"};let h="";if(s){const u=[...new Set(t.variants.map(g=>g.size).filter(Boolean))],f=[...new Set(t.variants.map(g=>g.color).filter(Boolean))];if(u.length>0||f.length>0){let g="";f.length>0&&(g=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Color</span>
              <span class="selected-val" id="detail-selected-color">${(o==null?void 0:o.color)||f[0]}</span>
            </div>
            <div class="variant-pill-container" id="color-pill-group">
              ${f.map(y=>{const B=m[y.toLowerCase()]||"#64748b";return`
                  <button type="button" class="variant-color-btn ${((o==null?void 0:o.color)||f[0])===y?"active":""}" 
                    style="background-color: ${B};" 
                    title="${y}" data-color="${y}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'color', '${y}')">
                  </button>
                `}).join("")}
            </div>
          </div>
        `);let b="";u.length>0&&(b=`
          <div class="variant-selector-group">
            <div class="variant-selector-label">
              <span>Style / Size</span>
              <span class="selected-val" id="detail-selected-size">${(o==null?void 0:o.size)||u[0]}</span>
            </div>
            <div class="variant-pill-container" id="size-pill-group">
              ${u.map(y=>`
                  <button type="button" class="variant-size-btn ${((o==null?void 0:o.size)||u[0])===y?"active":""}" 
                    data-size="${y}"
                    onclick="window.selectVariantByAttribute('${t.docId}', 'size', '${y}')">
                    ${y}
                  </button>
                `).join("")}
            </div>
          </div>
        `),h=`${g}${b}`}else h=`
        <div class="variant-selector-group">
          <div class="variant-selector-label">
            <span>Choose Option / MRP</span>
          </div>
          <div class="variant-pill-container">
            ${t.variants.map((g,b)=>{const y=de(t,g);return`
              <div class="variant-mrp-card ${b===0?"active":""}" id="v-card-${b}"
                   onclick="window.updateDetailDisplay('${t.docId}', ${b})">
                <div style="flex:1;">
                  <div style="font-weight: 800; font-size: 0.9rem; color: #1e293b;">${g.name||g.variantLabel||g.color||g.size||`Option ${b+1}`}</div>
                  <div style="font-size: 0.75rem; color: #64748b;">${y>0?`In Stock (${y})`:"Out of stock"}</div>
                </div>
                <div style="font-weight: 900; color: var(--accent-color); font-size: 1rem;">
                  LKR ${(g.price||t.price||0).toLocaleString()}
                </div>
              </div>
            `}).join("")}
          </div>
        </div>
      `}ce.innerHTML=`
        <button class="detail-close" onclick="window.closeProductDetail()">&times;</button>
        <div class="detail-content">
            <div class="detail-image-sec">
                <img src="${ue(i,t.name)}" id="detail-main-img" 
                    alt="${t.name}" onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');">
            </div>

            <div class="detail-info-sec">
                <div style="font-size: 0.9rem; color: var(--secondary-color); font-weight: 800; text-transform: uppercase;">${t.category}</div>
                <h2 style="font-size: 1.8rem; line-height: 1.2; margin: 0.2rem 0;">${t.name}</h2>
                ${a?`<div style="font-size: 0.8rem; color: ${d==="wholesale"?"#facc15":"#10b981"}; font-weight: 800; margin-bottom: 5px;">✨ CUSTOMER PRICING: ${d.toUpperCase()} APPLIED</div>`:""}
                
                <div class="product-price" style="font-size: 1.6rem; display:flex; align-items:baseline; gap:8px;" id="detail-price-box">
                    ${n>0||a?`<span class="detail-original-price" style="text-decoration:line-through; opacity: 0.5; font-size: 1.1rem;">LKR ${l.toFixed(2)}</span>`:""}
                    <span class="detail-final-price" style="color: var(--accent-color); font-weight: 900;">LKR ${c.toFixed(2)}</span>
                </div>
                
                ${h}

                <div id="detail-stock" style="font-weight: 800; font-size: 0.9rem; color: ${p>0?"#10b981":"#ef4444"}; margin: 0.5rem 0;">
                  ${p>0?`✓ In Stock (${p} available)`:"✕ Out of Stock"}
                </div>
                
                <div class="detail-actions-sec">
                    <button class="add-to-cart-btn detail-add-btn" 
                            onclick="window.handleDetailAddToCart('${t.docId}')">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        </div>
    `,window.activeDetailVariantIndex=0,ce.classList.add("active"),Oe.classList.add("active"),document.body.style.overflow="hidden",V(),window.updateDetailDisplay(e,0)};window.selectVariantByAttribute=(e,t,n)=>{const s=(window.groupedProducts||[]).find(r=>r.docId===e)||_.find(r=>r.docId===e);if(!s||!s.variants)return;const o=window.activeDetailVariantIndex||0;s.variants[o]||s.variants[0];let i=s.variants.findIndex(r=>t==="color"?r.color===n:t==="size"?r.size===n:!1);if(i===-1&&(i=0),t==="color"){document.querySelectorAll("#color-pill-group .variant-color-btn").forEach(d=>{d.classList.toggle("active",d.dataset.color===n)});const r=document.getElementById("detail-selected-color");r&&(r.innerText=n)}if(t==="size"){document.querySelectorAll("#size-pill-group .variant-size-btn").forEach(d=>{d.classList.toggle("active",d.dataset.size===n)});const r=document.getElementById("detail-selected-size");r&&(r.innerText=n)}window.updateDetailDisplay(e,i)};window.closeProductDetail=()=>{ce.classList.remove("active"),Oe.classList.remove("active"),document.body.style.overflow=""};Oe.onclick=window.closeProductDetail;window.updateDetailDisplay=(e,t)=>{window.activeDetailVariantIndex=Number(t);const n=(window.groupedProducts||[]).find(c=>c.docId===e)||_.find(c=>c.docId===e);if(!n)return;const s=n.variants&&n.variants.length>0?n.variants[t]:null,o=document.getElementById("detail-main-img"),i=document.getElementById("detail-stock"),r=ce.querySelector(".detail-original-price"),d=ce.querySelector(".detail-final-price");if(o){let c=n.image;s&&(s.image?c=s.image:s.images&&s.images.length>0&&(c=s.images[0])),o.src=ue(c,n.name)}document.querySelectorAll(".variant-mrp-card").forEach((c,p)=>{c.classList.toggle("active",p===Number(t))}),Number(n.discount);const a=te(n,s);r&&(r.innerText=`LKR ${a.retailPrice.toFixed(2)}`),d&&(d.innerText=`LKR ${a.discountedPrice.toFixed(2)}`);const l=de(n,s);if(i){const c=l>0?`✓ In Stock (${l} available)`:"✕ Out of Stock";i.innerHTML=c,i.style.color=l>0?"#10b981":"#ef4444"}};window.handleDetailAddToCart=e=>{const t=(window.groupedProducts||[]).find(p=>p.docId===e)||_.find(p=>p.docId===e);if(!t)return;const n=window.activeDetailVariantIndex!==void 0?window.activeDetailVariantIndex:0;let s="Default",o=null;t.variants&&t.variants.length>0&&(o=t.variants[n]||t.variants[0],s=o.name||o.variantLabel||o.color||o.size||"Default");const r=te(t,o).effectivePrice,d=o&&o.cost!==void 0?Number(o.cost):Number(t.cost)||0,a=de(t,o),l=x.findIndex(p=>p.docId===t.docId&&p.selectedVariant===s),c=l!==-1?(x[l].quantity||1)+1:1;if(t.mode!=="Service"&&t.mode!=="Technical"&&c>a){alert(`Sorry, out of stock! Only ${a} available.`);return}St(t,s,r,d),window.closeProductDetail(),ge(!0)};function St(e,t,n,s){const o=x.findIndex(i=>i.docId===e.docId&&i.selectedVariant===t);o!==-1?x[o].quantity=(x[o].quantity||1)+1:x.push({...e,selectedVariant:t,price:n,cost:s,quantity:1}),me=x.reduce((i,r)=>i+(r.quantity||1),0),Re(),Ce()}window.changeCartQty=(e,t,n)=>{var o;const s=x.findIndex(i=>i.docId===e&&i.selectedVariant===t);if(s!==-1){if(n>0){const i=_.find(r=>r.docId===e);if(i&&i.mode!=="Service"&&i.mode!=="Technical"){let r=null;t!=="Default"&&i.variants&&(r=i.variants.find(l=>(l.name||l.variantLabel||l.color||l.size||"Variant")===t));const d=((o=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:o.value)||"COD",a=_e(i,r,d);if((x[s].quantity||1)+n>a){alert(d==="ShopPay"?`Sorry! Only ${a} available in Shop stock for shop pickup.`:`Sorry, out of stock! Only ${a} available.`);return}}}x[s].quantity=(x[s].quantity||1)+n,x[s].quantity<=0&&x.splice(s,1),me=x.reduce((i,r)=>i+(r.quantity||1),0),Re(),Ce(),Pe()}};function Ce(){[document.getElementById("cart-count"),document.getElementById("cart-count-mobile"),document.getElementById("cart-count-dock")].forEach(t=>{t&&(t.innerText=me,t.classList.add("bump"),setTimeout(()=>t.classList.remove("bump"),300))})}function qe(e,t,n){if(!e||!t||t.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:""};let s=t;if(e.targetType==="specific_products"){const r=(e.selectedProducts||[]).map(d=>(d||"").trim().toLowerCase());if(s=t.filter(d=>{const a=(d.name||"").trim().toLowerCase(),l=(d.docId||"").trim().toLowerCase();return r.includes(a)||r.includes(l)}),s.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:"Coupon is only valid for selected products."}}else if(e.targetType==="specific_categories"){const r=(e.selectedCategories||[]).map(d=>(d||"").trim().toLowerCase());if(s=t.filter(d=>{const a=(d.category||"").trim().toLowerCase();return r.includes(a)}),s.length===0)return{discountAmount:0,eligibleSubtotal:0,isValidForCart:!1,reason:`Coupon is only valid for: ${(e.selectedCategories||[]).join(", ")}`}}const o=s.reduce((r,d)=>{const a=d.discount||0,l=d.price*(1-a/100),c=d.quantity||1;return r+l*c},0);let i=0;return e.type==="Percentage"?i=o*(Number(e.value)/100):i=Math.min(o,Number(e.value)||0),{discountAmount:i,eligibleSubtotal:o,isValidForCart:!0,reason:""}}function Pe(){var s;const e=x.reduce((o,i)=>{const r=i.discount||0,d=i.price*(1-r/100),a=i.quantity||1;return o+d*a},0);let t=0;if(window.appliedCoupon){const o=qe(window.appliedCoupon,x);o.isValidForCart?t=o.discountAmount:window.appliedCoupon=null}const n=Math.max(0,e-t);se.innerHTML=`
        <div class="cart-header">
            <h2 style="font-size: 1.25rem;">Shopping Cart</h2>
            <button class="close-cart" id="close-cart-btn">&times;</button>
        </div>
        
        <div class="cart-scroll-area" style="flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch;">
            <div class="cart-body">
                ${x.length===0?`
                    <div class="cart-empty-state">
                        <div style="font-size: 4rem; opacity: 0.2;">🛒</div>
                        <p>Your cart is empty</p>
                        <button class="category-btn active" onclick="toggleCart(false)">Start Shopping</button>
                    </div>
                `:x.map(o=>{const i=o.discount||0,r=o.price*(1-i/100),d=o.quantity||1,a=r*d;return`
                        <div class="cart-item" style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem; border-bottom: 1px solid #f1f5f9; gap: 1rem;">
                            <div class="cart-item-info" style="flex: 1;">
                                <h4 style="margin: 0; font-size: 1rem; color: var(--text-dark);">${o.name}</h4>
                                <div style="font-size: 0.75rem; color: var(--text-light); margin: 0.25rem 0 0.5rem;">Variant: ${o.selectedVariant||"Default"}</div>
                                <div class="cart-item-price" style="font-weight: 800; color: var(--primary-color);">
                                    ${i>0?`<span style="text-decoration:line-through; color:#94a3b8; font-size:0.75rem; margin-right:5px; font-weight: normal;">LKR ${o.price.toFixed(2)}</span>`:""}
                                    LKR ${r.toFixed(2)} ${d>1?`<span style="color: var(--text-light); font-weight: normal; font-size: 0.8rem;">x ${d} = LKR ${a.toFixed(2)}</span>`:""}
                                </div>
                            </div>
                            <div class="cart-qty-controls" style="display:flex; align-items:center; gap:0.6rem; background: #f8fafc; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 5px rgba(0,0,0,0.02);">
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', -1)" 
                                        style="background:white; border:1px solid #e2e8f0; color:var(--primary-color); width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.2s;">
                                    -
                                </button>
                                <span style="font-weight:900; width: 24px; text-align:center; color: var(--text-dark); font-size: 1rem;">${d}</span>
                                <button onclick="window.changeCartQty('${o.docId}', '${o.selectedVariant}', 1)" 
                                        style="background:var(--primary-color); border:none; color:white; width: 28px; height: 28px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight:bold; cursor:pointer; font-size: 1.1rem; box-shadow: 0 2px 4px rgba(0,32,96,0.2); transition: all 0.2s;">
                                    +
                                </button>
                            </div>
                        </div>
                    `}).join("")}
            </div>

            ${x.length>0?`
                <div class="cart-footer">
                    <div class="delivery-info-banner">
                        <span>🚚</span>
                        <span>COD LKR 400 | Bank Transfer LKR 250</span>
                    </div>

                    <!-- Promo / Coupon Code Section -->
                    <div class="cart-promo-section" style="padding: 1rem 0; border-bottom: 1px solid #f1f5f9; display: flex; flex-direction: column; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; gap: 0.5rem;">
                            <input id="cart-promo-input" type="text" placeholder="Promo / Coupon Code" style="flex: 1; padding: 0.5rem 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 0.875rem; text-transform: uppercase;" value="${window.appliedCoupon?window.appliedCoupon.code:""}" ${window.appliedCoupon?"disabled":""}>
                            ${window.appliedCoupon?`
                                <button onclick="window.removeCouponCode()" style="background: #ef4444; color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Remove</button>
                            `:`
                                <button onclick="window.applyCouponCode()" style="background: var(--primary-color); color: white; border: none; padding: 0.5rem 0.75rem; border-radius: 8px; cursor: pointer; font-size: 0.875rem; font-weight: bold; transition: all 0.2s;">Apply</button>
                            `}
                        </div>
                        <div id="promo-message" style="font-size: 0.75rem; font-weight: 500;">
                            ${window.appliedCoupon?`✅ Coupon applied: ${window.appliedCoupon.type==="Percentage"?`${window.appliedCoupon.value}% OFF`:`LKR ${window.appliedCoupon.value} OFF`}`:""}
                        </div>
                    </div>
                    
                    ${window.appliedCoupon?`
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: var(--text-light); margin-bottom: 0.5rem;">
                            <span>Subtotal</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-size: 0.95rem; color: #10b981; margin-bottom: 0.5rem;">
                            <span>Coupon Discount (${window.appliedCoupon.code})</span>
                            <span>- LKR ${t.toFixed(2)}</span>
                        </div>
                        <div class="cart-subtotal" style="font-weight: 800; font-size: 1.25rem; color: var(--primary-color);">
                            <span>Total Payable</span>
                            <span>LKR ${n.toFixed(2)}</span>
                        </div>
                    `:`
                        <div class="cart-subtotal">
                            <span>Total Payable</span>
                            <span>LKR ${e.toFixed(2)}</span>
                        </div>
                    `}

                    <div class="checkout-form-section">
                        <p class="section-title" id="contact-details-title">📦 Customer & Delivery Details</p>
                        <div class="input-group">
                            <input id="delivery-phone" type="tel" placeholder="Phone Number 1 *" required value="${localStorage.getItem("mec_saved_phone")||""}">
                        </div>
                        <div class="input-group">
                            <input id="delivery-phone-2" type="tel" placeholder="Phone Number 2 (Optional)" value="${localStorage.getItem("mec_saved_phone2")||""}">
                        </div>
                        <div class="input-group" id="delivery-address-group">
                            <input id="delivery-address" type="text" placeholder="Full Delivery Address *" required value="${localStorage.getItem("mec_saved_address")||""}">
                        </div>
                        <div class="input-group" id="delivery-city-group">
                            <input id="delivery-city" type="text" placeholder="Delivery City / Town *" required value="${localStorage.getItem("mec_saved_city")||""}">
                        </div>

                        <p class="section-title" style="margin-top: 1.5rem;">💳 Payment Method</p>
                        <div class="payment-method-selector">
                            ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="COD" checked onchange="window.onPaymentMethodChange('COD')">
                                <span class="method-label">COD</span>
                            </label>
                            `:""}
                            ${x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="Bank" ${x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)?"":"checked"} onchange="window.onPaymentMethodChange('Bank')">
                                <span class="method-label">Transfer</span>
                            </label>
                            `:""}
                            ${x.every(o=>o.payMethods?o.payMethods.shop!==!1:o.payShop!==!1)?`
                            <label class="method-option">
                                <input type="radio" name="payment-method" value="ShopPay" ${!x.every(o=>o.payMethods?o.payMethods.cod!==!1:o.payCOD!==!1)&&!x.every(o=>o.payMethods?o.payMethods.bank!==!1:o.payBank!==!1)?"checked":""} onchange="window.onPaymentMethodChange('ShopPay')">
                                <span class="method-label">Shop Cash</span>
                            </label>
                            `:""}
                        </div>
                        
                        <!-- Bank Transfer Info Box -->
                        <div id="bank-details-box" style="display: none;">
                            <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.75rem;">
                                <p style="color: #065f46; font-weight: 800; margin: 0; font-size: 0.82rem; display: flex; align-items: center; gap: 6px;">
                                    <span>✨</span> Lower delivery charge (LKR 250)
                                </p>
                                <p style="color: #047857; margin: 3px 0 0; font-size: 0.75rem; font-weight: 600;">
                                    👇 Select the Bank Account you transferred to (ඔබ මුදල් තැන්පත් කළ ගිණුම තෝරන්න):
                                </p>
                            </div>

                            <!-- Account 1: Slot 1 (e.g. NDB) -->
                            <div id="web-bank-card-1" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot1')" style="background: #f0fdf4 !important; color: #0f172a !important; border: 2px solid #16a34a !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 4px 14px rgba(22, 163, 74, 0.15); cursor: pointer; transition: all 0.2s; position: relative;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-1-radio" value="slot1" checked style="accent-color: #16a34a; width: 18px; height: 18px; cursor: pointer;">
                                        <span id="web-bank-1-title" style="font-weight: 900; color: #b91c1c; font-size: 0.95rem;">🏦 National Development Bank (NDB)</span>
                                    </div>
                                    <span id="web-bank-1-badge" style="font-size: 0.72rem; background: #16a34a; color: #ffffff; padding: 3px 8px; border-radius: 6px; font-weight: 800;">✓ Selected</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">
                                    <span>Account Name: <span id="web-bank-1-accname" style="color: #0f172a; font-weight: 700;">MEC BOOK SHOP & COMMUNICATION</span></span>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div id="web-bank-1-type-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 4px; font-weight: 600; padding-left: 26px;">
                                    Account Type: <span id="web-bank-1-acctype" style="color: #0f172a; font-weight: 700;">Regular Current</span>
                                </div>
                                <div id="web-bank-1-codes-row" style="display: flex; gap: 14px; color: #64748b; font-size: 0.76rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">
                                    <span>Bank Code: <strong id="web-bank-1-code" style="color: #334155;">7214</strong></span>
                                    <span>Swift Code: <strong id="web-bank-1-swift" style="color: #334155;">NDBSLKLX</strong></span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; border: 1.5px dashed #16a34a; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span id="web-bank-1-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">111000391437</span>
                                    </div>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-1-accno', 'Account Number');" style="background: #b91c1c; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(185,28,28,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <!-- Account 2: Slot 2 (e.g. BOC) -->
                            <div id="web-bank-card-2" class="bank-info-card selectable-bank-card" onclick="window.selectWebStoreBankSlot('slot2')" style="background: #ffffff !important; color: #0f172a !important; border: 1.5px solid #cbd5e1 !important; border-radius: 12px; padding: 0.85rem; margin: 0.6rem 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: all 0.2s; position: relative;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <input type="radio" name="web-bank-slot-radio" id="web-slot-2-radio" value="slot2" style="accent-color: #0284c7; width: 18px; height: 18px; cursor: pointer;">
                                        <span id="web-bank-2-title" style="font-weight: 900; color: #0284c7; font-size: 0.95rem;">🏦 Bank of Ceylon (BOC)</span>
                                    </div>
                                    <span id="web-bank-2-badge" style="font-size: 0.72rem; background: #f1f5f9; color: #64748b; padding: 3px 8px; border-radius: 6px; font-weight: 700;">Click to select</span>
                                </div>
                                <div id="web-bank-2-branch-row" style="color: #475569; font-size: 0.82rem; margin-bottom: 3px; font-weight: 600; padding-left: 26px;">
                                    Branch: <span id="web-bank-2-branch" style="color: #0f172a; font-weight: 700;">Horana Branch</span>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: #475569; font-size: 0.82rem; margin-bottom: 6px; font-weight: 600; padding-left: 26px;">
                                    <span>Account Name: <span id="web-bank-2-accname" style="color: #0f172a; font-weight: 700;">WPM Shamesh</span></span>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accname', 'Account Name');" style="background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; flex-shrink: 0;" title="Copy Account Name">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                                <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1.5px dashed #94a3b8; border-radius: 8px; padding: 6px 10px; margin-top: 4px; margin-left: 26px;">
                                    <div>
                                        <span style="font-size: 0.68rem; color: #64748b; display: block; font-weight: 700; letter-spacing: 0.05em;">ACCOUNT NUMBER</span>
                                        <span id="web-bank-2-accno" style="font-size: 1.05rem; font-weight: 900; color: #0f172a; font-family: monospace; letter-spacing: 0.5px;">0084334885</span>
                                    </div>
                                    <button type="button" onclick="event.stopPropagation(); window.copyBankDetails('web-bank-2-accno', 'Account Number');" style="background: #0284c7; color: #ffffff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 0.75rem; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(2,132,199,0.25);">
                                        <span>📋</span> Copy
                                    </button>
                                </div>
                            </div>

                            <div style="margin-top: 1rem;">
                                <label style="display: block; font-size: 0.75rem; font-weight: bold; margin-bottom: 0.4rem; color: var(--text-light);">Upload Deposit Slip *</label>
                                <input type="file" id="deposit-slip" accept="image/*, application/pdf" style="font-size: 0.75rem; width: 100%;">
                            </div>
                        </div>

                        <!-- Shop Pickup / Branch Selection Box -->
                        <div id="shop-pickup-box" style="display: none; background: #f0f9ff; border: 1.5px solid #38bdf8; border-radius: 12px; padding: 1.1rem; margin-top: 1rem; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
                            <p style="color: #0369a1; font-weight: 800; margin-bottom: 0.85rem; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">🏪</span> Select Pickup Shop / Branch
                            </p>

                            <!-- City / Town Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">1. Select City / Town (නගරය තෝරන්න)</label>
                                <select id="pickup-town-select" onchange="window.filterShopsByTown(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #94a3b8; font-size: 0.9rem; font-weight: 600; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <option value="All" style="color:#0f172a; background:#ffffff;">All Cities / Towns (සියලුම නගර)</option>
                                  ${et().map(o=>`<option value="${o}" style="color:#0f172a; background:#ffffff;">${o}</option>`).join("")}
                                </select>
                            </div>

                            <!-- Shop / Branch List Dropdown -->
                            <div style="margin-bottom: 0.85rem;">
                                <label style="display: block; font-size: 0.8rem; font-weight: 800; margin-bottom: 0.4rem; color: #0f172a;">2. Choose Shop / Branch (සාප්පුව තෝරන්න) *</label>
                                <select id="pickup-shop-select" onchange="window.onPickupShopSelected(this.value)" 
                                  style="width: 100%; padding: 0.7rem 0.85rem; border-radius: 8px; background: #ffffff; color: #0f172a; border: 1.5px solid #0284c7; font-size: 0.9rem; font-weight: 700; cursor: pointer; outline: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                  <!-- Injected by populatePickupShops -->
                                </select>
                            </div>

                            <!-- Selected Shop Info Card -->
                            <div id="selected-shop-info-card" style="background: #ffffff; border: 1.5px solid #bae6fd; border-radius: 10px; padding: 0.9rem; font-size: 0.85rem; color: #0f172a; line-height: 1.5; box-shadow: 0 2px 6px rgba(0,0,0,0.04);">
                            </div>
                        </div>
                    </div>

                    <div style="margin: 1.25rem 0; display: flex; align-items: flex-start; gap: 8px;">
                        <input type="checkbox" id="terms-agree" style="margin-top: 3px; cursor: pointer; width: 16px; height: 16px; min-width: 16px;">
                        <label for="terms-agree" style="font-size: 0.8rem; color: var(--text-light); line-height: 1.4; cursor: pointer; user-select: none;">
                            I agree to the <a href="/policies?tab=terms" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Terms & Conditions</a>, 
                            <a href="/policies?tab=privacy" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Privacy Policy</a>, and 
                            <a href="/policies?tab=refund" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">Refund Policy</a>.
                        </label>
                    </div>

                    <button id="checkout-btn" class="add-to-cart-btn" style="width:100%; padding:1.25rem; font-size: 1.1rem; border-radius: 12px; height: auto;">
                        Confirm Order
                    </button>
                    <div style="height: 40px;"></div> <!-- Spacer for mobile -->
                </div>
            `:""}
        </div>
    `,document.getElementById("close-cart-btn").onclick=()=>ge(!1),(s=document.getElementById("checkout-btn"))==null||s.addEventListener("click",It),setTimeout(()=>{typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI()},50),window.toggleBankDetails=o=>{const i=document.getElementById("bank-details-box");i&&(i.style.display=o?"block":"none")},window.onPaymentMethodChange=o=>{const i=document.getElementById("bank-details-box"),r=document.getElementById("shop-pickup-box"),d=document.getElementById("delivery-address-group"),a=document.getElementById("delivery-city-group"),l=document.getElementById("contact-details-title");o==="Bank"?(i&&(i.style.display="block"),typeof window.updateWebStoreBankCardsUI=="function"&&window.updateWebStoreBankCardsUI(),r&&(r.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details")):o==="ShopPay"?(i&&(i.style.display="none"),r&&(r.style.display="block",window.populatePickupShops()),d&&(d.style.display="none"),a&&(a.style.display="none"),l&&(l.innerText="👤 Customer Contact Details (Shop Pickup)")):(i&&(i.style.display="none"),r&&(r.style.display="none"),d&&(d.style.display="block"),a&&(a.style.display="block"),l&&(l.innerText="📦 Delivery Details"))},window.populatePickupShops=()=>{var c,p,m,h;const o=document.getElementById("pickup-town-select"),i=document.getElementById("pickup-shop-select"),r=document.getElementById("selected-shop-info-card");if(!i)return;const d=o?o.value:"All",a=ie();let l=a;d&&d!=="All"&&(l=a.filter(u=>((u.location||"")+" "+(u.city||"")+" "+(u.address||"")+" "+(u.name||"")).toLowerCase().includes(d.toLowerCase()))),l.length===0?(i.innerHTML=a.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),r&&(r.innerHTML=`<div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:0.6rem; color:#92400e; font-size:0.8rem; font-weight:700;">⚠️ No registered branch in <b>${d}</b>. Showing our available pickup branches above:</div>`),window.onPickupShopSelected(((c=a[0])==null?void 0:c.docId)||((p=a[0])==null?void 0:p.id)||0)):(i.innerHTML=l.map((u,f)=>`
        <option value="${u.docId||u.id||f}" ${f===0?"selected":""} style="color:#0f172a; background:#ffffff;">
          ${u.name||u.shopName||"Branch"} ${u.location?`(${u.location})`:""}
        </option>
      `).join(""),window.onPickupShopSelected(((m=l[0])==null?void 0:m.docId)||((h=l[0])==null?void 0:h.id)||0))},window.filterShopsByTown=o=>{window.populatePickupShops()},window.onPickupShopSelected=o=>{const i=document.getElementById("selected-shop-info-card");if(!i)return;const r=ie(),d=r.find(a=>a.docId===o||a.id===o)||r[0];d&&(i.innerHTML=`
        <div style="font-weight:800; color:#0284c7; font-size:0.95rem; margin-bottom:4px;">📍 ${d.name||d.shopName||"Main Branch"}</div>
        <div style="color:#334155; font-size:0.85rem; font-weight:600; margin-bottom:4px;">🏠 ${d.location||d.address||"In-store Pickup Counter"}</div>
        <div style="color:#475569; font-size:0.8rem; font-weight:600;">📞 ${d.phone?`Contact: <b>${d.phone}</b>`:"Store Pickup Active"}</div>
        <div style="color:#15803d; font-size:0.8rem; margin-top:6px; font-weight:800; display:flex; align-items:center; gap:4px;">
          <span>✓</span> Collect & Pay Cash at this shop counter
        </div>
      `)}}window.applyCouponCode=async()=>{const e=document.getElementById("cart-promo-input"),t=document.getElementById("promo-message");if(!e)return;const n=e.value.trim().toUpperCase();if(!n){t&&(t.innerText="❌ Please enter a promo code.",t.style.color="#ef4444");return}t&&(t.innerText="⏳ Validating coupon...",t.style.color="var(--primary-color)");try{const s=T(gt,k("code","==",n),k("storeId","==",window.currentStoreId)),o=await A(s);if(o.empty){t&&(t.innerText="❌ Invalid or expired coupon code.",t.style.color="#ef4444");return}const i=o.docs[0],r={...i.data(),id:i.id},d=new Date().toISOString().split("T")[0];if(r.expiryDate<d){t&&(t.innerText="❌ This coupon has expired.",t.style.color="#ef4444");return}if(r.status!=="Active"){t&&(t.innerText="❌ This coupon is inactive.",t.style.color="#ef4444");return}const a=x.reduce((p,m)=>p+m.price*(1-(m.discount||0)/100)*(m.quantity||1),0),l=qe(r,x,a);if(!l.isValidForCart){t&&(t.innerText=`❌ ${l.reason||"Coupon is not applicable to items in your cart."}`,t.style.color="#ef4444");return}window.appliedCoupon=r,Pe();const c=document.getElementById("promo-message");if(c){const p=r.targetType==="specific_products"?" (Selected Items)":r.targetType==="specific_categories"?" (Selected Categories)":"";c.innerText=`✅ Coupon applied: ${r.type==="Percentage"?`${r.value}% OFF`:`LKR ${r.value} OFF`}${p}`,c.style.color="#10b981"}}catch(s){console.error("Error validating coupon:",s),t&&(t.innerText="❌ Error validating coupon code.",t.style.color="#ef4444")}};window.removeCouponCode=()=>{window.appliedCoupon=null,Pe()};async function It(){var m,h,u,f,g,b,y,B;const e=JSON.parse(sessionStorage.getItem("mec_user"));if(!e){alert("Please login to place an order!"),window.location.href="/login.html";return}if(x.length===0)return;const t=document.getElementById("terms-agree");if(t&&!t.checked){alert("Please read and agree to the Terms & Conditions and Privacy Policy to confirm your order!");return}const n=(m=document.getElementById("delivery-phone"))==null?void 0:m.value.trim(),s=(h=document.getElementById("delivery-phone-2"))==null?void 0:h.value.trim(),o=(u=document.getElementById("delivery-address"))==null?void 0:u.value.trim(),i=(f=document.getElementById("delivery-city"))==null?void 0:f.value.trim(),r=((g=document.querySelector('input[name="payment-method"]:checked'))==null?void 0:g.value)||"COD",d=(b=document.getElementById("deposit-slip"))==null?void 0:b.files[0],a=r==="ShopPay";let l=null,c="All";if(a){c=((y=document.getElementById("pickup-town-select"))==null?void 0:y.value)||"All";const w=(B=document.getElementById("pickup-shop-select"))==null?void 0:B.value,P=ie();if(l=P.find(S=>S.docId===w||S.id===w)||P[0],!w&&(!P||P.length===0)){alert("Please select a pickup shop / branch!");return}}if(!n||!a&&(!o||!i)){alert(a?"Please enter your Phone Number for Shop Pickup!":"Please fill in all delivery details (Phone, Address, City)!");return}if(localStorage.setItem("mec_saved_phone",n),localStorage.setItem("mec_saved_phone2",s),localStorage.setItem("mec_saved_address",o),localStorage.setItem("mec_saved_city",i),r==="Bank"&&!d){alert("Please upload your bank deposit slip!");return}for(const w of x){const P=_.find(S=>S.docId===w.docId)||(window.groupedProducts||[]).find(S=>S.docId===w.docId);if(P&&P.mode!=="Service"&&P.mode!=="Technical"){let S=null;w.selectedVariant&&w.selectedVariant!=="Default"&&P.variants&&(S=P.variants.find(L=>(L.name||L.variantLabel||L.color||L.size||"Variant")===w.selectedVariant));const $=_e(P,S,r);if((w.quantity||1)>$){alert(r==="ShopPay"?`Sorry! "${w.name}" only has ${$} available in Shop stock for shop pickup. Please reduce quantity or choose COD/Bank Transfer for delivery.`:`Sorry! "${w.name}" only has ${$} available in stock.`);return}}}const p=async(w=null)=>{var P,S;try{const $=x.reduce((v,F)=>v+F.price*(1-(F.discount||0)/100)*(F.quantity||1),0);let L=0,z="";if(window.appliedCoupon){z=window.appliedCoupon.code;const v=qe(window.appliedCoupon,x,$);v.isValidForCart&&(L=v.discountAmount)}const M=Math.max(0,$-L),O=sessionStorage.getItem("mec_ref_code");let I="",D=0;if(O)try{const v=T(E(C,"affiliates"),k("code","==",O),k("storeId","==",window.currentStoreId));(await A(v)).empty||(I=O,D=Number((M*.05).toFixed(2)))}catch(v){console.error("Error verifying affiliate referral code at checkout:",v)}const oe=window.currentStoreId||"mec-book-shop",Be=e&&(e.id||e.uid)?e.id||e.uid:"guest-"+Date.now(),Ue=e&&(e.name||e.email)?e.name||e.email:n||"Guest Customer",Ke=window.selectedWebStoreBankSlot||"slot1",N=window.webStoreBankAccounts&&window.webStoreBankAccounts[Ke]||((P=window.webStoreBankAccounts)==null?void 0:P.slot1),fe={orderId:"ORD-"+Date.now(),userId:Be,userName:Ue,userEmail:e&&e.email?e.email:"",phone:n||"",phone2:s||"",branchId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"web-order",pickupShopId:a?(l==null?void 0:l.docId)||(l==null?void 0:l.id)||"main":"",pickupShopName:a?(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch":"",pickupTown:a?c:"",pickupShopPhone:a&&(l==null?void 0:l.phone)||"",pickupShopAddress:a&&((l==null?void 0:l.location)||(l==null?void 0:l.address))||"",address:a?`Shop Pickup: ${(l==null?void 0:l.name)||(l==null?void 0:l.shopName)||"Main Branch"} (${(l==null?void 0:l.location)||(l==null?void 0:l.address)||"Store"})`:o||"",city:a?c!=="All"?c:(l==null?void 0:l.location)||(l==null?void 0:l.city)||"Shop Pickup":i||"",items:x.map(v=>({id:v.id||v.docId||"",docId:v.docId||v.id||"",name:v.name||"",price:Number(v.price)||0,cost:Number(v.cost)||0,quantity:Number(v.quantity)||1,discount:Number(v.discount)||0,finalPrice:Number(v.price)*(1-(Number(v.discount)||0)/100)})),subtotal:Number($)||0,discount:Number(L)||0,couponCode:z||"",total:Number(M)||0,status:"Pending",customerType:(((S=window.currentUserProfile)==null?void 0:S.customerType)||"retail").toLowerCase(),paymentMethod:r||"COD",targetBankSlot:r==="Bank"?Ke:null,targetBankAccountId:r==="Bank"&&(N==null?void 0:N.docId)||null,targetBankName:r==="Bank"?(N==null?void 0:N.bankName)||"Bank":null,targetAccountNo:r==="Bank"?(N==null?void 0:N.accountNo)||"":null,targetAccountTitle:r==="Bank"?(N==null?void 0:N.accountName)||"":null,bankCredited:r==="Bank",slipImage:w||"",codCharge:r==="COD"?400:r==="Bank"?250:0,isShopPending:r==="ShopPay",storeId:oe,numericStoreId:"1001",timestamp:G(),date:new Date().toLocaleString(),referredBy:I||"",referredCommission:Number(D)||0};if(await Y(mt,fe),r==="Bank"&&N)try{let v=N.docId;if(!v||v==="ndb_default"||v==="boc_default"){const F=T(E(C,"bank_accounts"),k("accountNo","==",N.accountNo)),be=await A(F);be.empty||(v=be.docs[0].id)}if(v&&v!=="ndb_default"&&v!=="boc_default"){const F=X(C,"bank_accounts",v);await Xe(F,{balance:we(M),updatedAt:G()}),await Y(E(C,"bank_transactions"),{accountId:v,bankName:N.bankName||"Bank Transfer",accountNo:N.accountNo||"",amount:M,type:"Credit",description:`Web Store Bank Transfer: Order #${fe.orderId} (${Ue})`,referenceNo:fe.orderId,orderId:fe.orderId,source:"Web Store",date:new Date().toLocaleDateString("sv-SE"),timestamp:G(),isReconciled:!1,storeId:oe}),console.log(`[Web Store Checkout] Credited LKR ${M} to ${N.bankName} (${N.accountNo})`)}}catch(v){console.warn("Error crediting web store bank account:",v)}if(I)try{const v=T(E(C,"affiliates"),k("code","==",I),k("storeId","==",oe)),F=await A(v);if(!F.empty){const be=F.docs[0].id;await Me(X(C,"affiliates",be),{salesCount:we(1),totalCommission:we(D)},{merge:!0}),sessionStorage.removeItem("mec_ref_code"),sessionStorage.removeItem("mec_ref_clicked")}}catch(v){console.error("Error updating affiliate statistics post-order:",v)}x=[],me=0,window.appliedCoupon=null,Re(),Ce(),ge(!1),alert(r==="Bank"?"Order placed successfully! We will verify your slip soon. Delivery: LKR 250":a?"Order placed successfully! No delivery charge. Please pay at the shop.":"Order placed successfully! Delivery charge will be LKR 400/-")}catch($){console.error("Order error:",$),alert("Error placing order: "+($.message||"Please try again."))}};if(d){const w=new FileReader;w.onload=P=>{const S=new Image;S.onload=()=>{const $=document.createElement("canvas"),L=1e3,z=1e3;let M=S.width,O=S.height;M>O?M>L&&(O*=L/M,M=L):O>z&&(M*=z/O,O=z),$.width=M,$.height=O,$.getContext("2d").drawImage(S,0,0,M,O);const D=$.toDataURL("image/jpeg",.6);p(D)},S.onerror=()=>{p(P.target.result)},S.src=P.target.result},w.onerror=P=>{console.error("FileReader Error:",P),alert("Error reading slip file. Please try selecting the image again.")},w.readAsDataURL(d)}else p()}function q(){const e=document.querySelector("#product-grid"),t=document.getElementById("pagination-controls");if(!e)return;let n=_.filter(a=>{if(a.mode==="Service"||a.mode==="Technical"||a.mode==="POS")return!1;const l=(a.name||"").toLowerCase();if(l==="call"||l.includes("repair")||l.includes("repire")||l.includes("rapair")||l.includes("print out")||l.includes("photo print"))return!1;const c=Q==="All"||a.category===Q,p=window.matchProductSearch?window.matchProductSearch(a,W):a.name.toLowerCase().includes(W)||a.category.toLowerCase().includes(W)||a.sku&&a.sku.toLowerCase().includes(W);return c&&p});ee==="recommended"?((!Le||Le.length!==n.length)&&(Le=n.map((a,l)=>({id:l,sort:Math.random()})).sort((a,l)=>a.sort-l.sort).map(a=>a.id)),n.sort(()=>Math.random()-.5)):n.sort((a,l)=>{if(ee==="az")return a.name.localeCompare(l.name);if(ee==="za")return l.name.localeCompare(a.name);if(ee==="low"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price,p=l.variants&&l.variants.length>0?l.variants[0].price:l.price;return c-p}if(ee==="high"){const c=a.variants&&a.variants.length>0?a.variants[0].price:a.price;return(l.variants&&l.variants.length>0?l.variants[0].price:l.price)-c}return 0});const s=new Map;n.forEach(a=>{const l=a.name.match(/^(.*?) \(((?:Size|Color):.*?)\)$/i),c=l?l[1].trim():a.name.trim(),p=l?l[2].trim():(a.size||a.color)&&`${a.size?a.size:""} ${a.color?a.color:""}`.trim()||"Default",m=c.toLowerCase();if(s.has(m)){const h=s.get(m);h.totalStock+=a.totalStock!==void 0?a.totalStock:a.stock||0;const u=(a.variants||[]).map(f=>({...f,sourceDocId:a.docId}));u.length===0&&u.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),h.variants=[...h.variants,...u]}else{const h=(a.variants||[]).map(u=>({...u,sourceDocId:a.docId}));h.length===0&&h.push({name:p,price:a.price,wholesalePrice:a.wholesalePrice,loyaltyPrice:a.loyaltyPrice,cost:a.cost,stock:a.stock||0,images:[a.image],sourceDocId:a.docId}),s.set(m,{...a,name:c,totalStock:a.totalStock!==void 0?a.totalStock:a.stock||0,variants:h})}}),window.groupedProducts=Array.from(s.values());const o=window.groupedProducts.length,i=Math.ceil(o/$e);R>i&&i>0&&(R=i),R<1&&(R=1);const r=(R-1)*$e,d=window.groupedProducts.slice(r,r+$e);if(window.groupedProducts.length===0){e.innerHTML=`
      <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; color: rgba(255,255,255,0.6);">
        <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
        <h3 style="color: white; font-size: 1.4rem; margin-bottom: 0.5rem;">No products found</h3>
        <p style="font-size: 0.95rem; opacity: 0.7;">We couldn't find any products matching "<strong style="color:#00aeef;">${W}</strong>".<br>Try a different keyword or browse all categories.</p>
        <button onclick="window.clearSearch()" 
          style="margin-top: 1.5rem; background: var(--secondary-color); color: white; border: none; padding: 0.7rem 1.8rem; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: 0.3s;"
          onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
          Clear Search
        </button>
      </div>`,t&&(t.innerHTML="");return}if(e.innerHTML=d.map(a=>{const l=a.variants&&a.variants.length>0,c=l?a.variants[0]:null,p=te(a,c),m=p.retailPrice,h=p.discountedPrice,u=p.isSpecial,f=p.userType,g=Number(a.discount)||0;let b=de(a,c);isNaN(b)&&(b=0);let y=a.image;(!y||y.trim()===""||y.includes("/logo.png"))&&c&&(c.images&&c.images.length>0?y=c.images[0]:c.image&&(y=c.image)),y=ue(y,a.name);const B=a.timestamp?typeof a.timestamp.toMillis=="function"?a.timestamp.toMillis():typeof a.timestamp=="number"?a.timestamp:0:0,w=B>0&&Date.now()-B<10080*60*1e3;return`
    <div class="product-card" id="product-${a.docId}">
      <div class="product-image" style="position: relative; cursor: pointer; border-radius: 12px; overflow: hidden;" onclick="window.openProductDetail('${a.docId}')">
        <div class="image-slider-container" style="height: 100%; width: 100%;">
            <img src="${y}" class="main-product-img" alt="${a.name}" 
                loading="lazy" decoding="async"
                onerror="this.onerror=null; this.src=(window.currentStoreData?.logoUrl && !window.currentStoreData.logoUrl.includes('/logo.png') ? window.currentStoreData.logoUrl : '/mec-logo.png');" 
                style="width:100%; height:100%; object-fit:cover;">
        </div>
        ${b<=0?'<div style="position:absolute; top:12px; right:12px; background:rgba(239, 68, 68, 0.9); backdrop-filter:blur(5px); color:white; padding:5px 12px; border-radius:20px; font-size:0.65rem; font-weight:900; z-index:5;">SOLD OUT</div>':""}
        ${g>0?`<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.7rem; font-weight:700; z-index:5;">${g}% OFF</div>`:w?'<div style="position:absolute; top:12px; left:12px; background:#D23269; color:white; padding:4px 10px; border-radius:4px; font-size:0.6rem; font-weight:700; z-index:5;">NEW</div>':""}
        
        <div class="image-dots" style="position: absolute; bottom: 12px; right: 12px; display: flex; gap: 4px; z-index: 6;">
            ${((c==null?void 0:c.images)||[a.image]).map((P,S)=>`<div class="dot ${S===0?"active":""}" style="width: 5px; height: 5px; border-radius: 50%; background: rgba(255,255,255,0.3); ${S===0?"background: #00aeef; width: 12px; border-radius: 4px;":""}"></div>`).join("")}
        </div>

        ${l?`
          <button class="select-options-btn" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')">
            Select Options
          </button>
        `:`
          <button class="add-to-cart-btn-trigger" onclick="event.stopPropagation(); window.openProductDetail('${a.docId}')" ${b<=0?'disabled style="background:#cbd5e1; cursor:not-allowed;"':""}>
            ${b<=0?"Out of Stock":"Add to Cart"}
          </button>
        `}
      </div>
      <div class="product-info">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.2rem;">
          <div style="font-size: 0.8rem; color: var(--text-light);">${a.category}</div>
          <div class="stock-display" style="font-size: 0.75rem; color: ${b<5?"#ef4444":"#10b981"}; font-weight:700;">Stock: ${b}</div>
        </div>
        <div class="product-title" style="cursor: pointer; transition: color 0.2s;" onclick="window.openProductDetail('${a.docId}')" onmouseover="this.style.color='#D23269'" onmouseout="this.style.color=''">
          ${a.name}
        </div>
        


        <div class="product-price" style="display:flex; align-items:center; flex-wrap:wrap; gap:6px; margin-top:4px;">
            ${g>0||u?`<span class="original-price" style="text-decoration:line-through; color:#94a3b8; font-size:0.8rem;">LKR ${m.toFixed(2)}</span>`:""}
            <span class="final-price" style="color:var(--accent-color); font-weight:900;">LKR ${h.toFixed(2)}</span>
            ${u?`<span style="background:${f==="wholesale"?"rgba(234,179,8,0.18)":"rgba(16,185,129,0.18)"}; color:${f==="wholesale"?"#facc15":"#10b981"}; border:1px solid ${f==="wholesale"?"rgba(234,179,8,0.4)":"rgba(16,185,129,0.4)"}; font-size:0.62rem; font-weight:900; padding:1px 5px; border-radius:4px; text-transform:uppercase;">${f}</span>`:""}
        </div>
      </div>
    </div>`}).join(""),t)if(i>1){let a=`<button class="pag-nav-btn" ${R===1?"disabled":""} onclick="window.changePage(${R-1})">‹ Previous</button>`;const l=5;let c=Math.max(1,R-2),p=Math.min(i,c+l-1);p===i&&(c=Math.max(1,p-l+1)),c>1&&(a+='<button class="pag-page-btn" onclick="window.changePage(1)">1</button>',c>2&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'));for(let m=c;m<=p;m++)a+=`<button class="pag-page-btn ${m===R?"active":""}" onclick="window.changePage(${m})">${m}</button>`;p<i&&(p<i-1&&(a+='<span style="color:white; padding:0 8px; align-self:center; opacity:0.6;">...</span>'),a+=`<button class="pag-page-btn" onclick="window.changePage(${i})">${i}</button>`),a+=`<button class="pag-nav-btn" ${R===i?"disabled":""} onclick="window.changePage(${R+1})">Next ›</button>`,t.innerHTML=a}else t.innerHTML=""}window.changePage=e=>{var t;R=e,q(),(t=document.getElementById("shop-section"))==null||t.scrollIntoView({behavior:"smooth"})};window.updateProductDisplay=(e,t)=>{const n=window.groupedProducts?window.groupedProducts.find(B=>B.docId===e):null,s=document.getElementById(`product-${e}`);if(!n||!s)return;const o=n.variants&&n.variants[t]?n.variants[t]:null,i=te(n,o),r=i.retailPrice,d=i.discountedPrice,a=i.isSpecial,l=Number(n.discount)||0,c=o&&o.stock!==void 0?o.stock:n.stock||0;let p=[];o&&o.images&&o.images.length>0?p=o.images:o&&o.image?p=[o.image]:n.images&&n.images.length>0?p=n.images:p=[n.image];const m=p.map(B=>ue(B,n.name)),h=s.querySelector(".original-price"),u=s.querySelector(".final-price");h&&(h.innerText=`LKR ${r.toFixed(2)}`,h.style.display=l>0||a?"inline":"none"),u&&(u.innerText=`LKR ${d.toFixed(2)}`);const f=s.querySelector(".stock-display");f.innerText=`Stock: ${c}`,f.style.color=c<5?"#ef4444":"#10b981";const g=s.querySelector(".add-to-cart-btn");c<=0?(g.disabled=!0,g.innerText="Out of Stock",g.style.background="#cbd5e1",g.style.cursor="not-allowed"):(g.disabled=!1,g.innerText="Add to Cart",g.style.background="",g.style.cursor="pointer");const b=s.querySelector(".main-product-img");b.src=m[0];const y=s.querySelector(".image-dots");if(y.innerHTML=m.map((B,w)=>`<div class="dot ${w===0?"active":""}" style="width: 6px; height: 6px; border-radius: 50%; background: ${w===0?"white":"rgba(255,255,255,0.5)"};"></div>`).join(""),m.length>1){let B=0;s.imageInterval&&clearInterval(s.imageInterval),s.imageInterval=setInterval(()=>{B=(B+1)%m.length,b.style.opacity="0.5",setTimeout(()=>{b.src=m[B],b.style.opacity="1",y.querySelectorAll(".dot").forEach((P,S)=>{P.style.background=S===B?"white":"rgba(255,255,255,0.5)"})},300)},3e3)}else s.imageInterval&&clearInterval(s.imageInterval)};function Ct(){const e=document.getElementById("nav-auth-item"),t=document.getElementById("user-profile");document.getElementById("user-display-name"),rt(Fe,n=>{if(document.getElementById("hero-title"),document.getElementById("hero-subtitle"),n){const s={name:n.displayName||n.email.split("@")[0],email:n.email,id:n.uid};sessionStorage.setItem("mec_user",JSON.stringify(s));const o=()=>{var B,w,P,S,$;if(!e)return;const l=(((B=window.currentUserProfile)==null?void 0:B.customerType)||"retail").toLowerCase(),c=((w=window.currentUserProfile)==null?void 0:w.phone)||((P=window.currentUserProfile)==null?void 0:P.contact)||"",p=n.photoURL||((S=window.currentUserProfile)==null?void 0:S.photoURL)||(($=window.currentUserProfile)==null?void 0:$.avatar)||"",h=(L=>{if(!L)return"U";const z=L.trim().split(" ");return z.length>=2?(z[0][0]+z[1][0]).toUpperCase():L.slice(0,2).toUpperCase()})(s.name),u=l==="wholesale"?'<span style="background:#eab308; color:#422006; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">WHOLESALE</span>':l==="loyalty"?'<span style="background:#10b981; color:#ffffff; font-size:0.65rem; font-weight:900; padding:2px 6px; border-radius:4px;">LOYALTY</span>':"",f=l==="wholesale"?`<div style="background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #fef08a; font-weight: 600; display:flex; align-items:center; gap:6px;">
               <span>👑</span> Wholesale Customer (Wholesale Price Active)
             </div>`:l==="loyalty"?`<div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #a7f3d0; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>💎</span> Loyalty Card Member Active
                 </div>`:`<div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.2); border-radius: 8px; padding: 8px 10px; font-size: 0.78rem; color: #bae6fd; font-weight: 600; display:flex; align-items:center; gap:6px;">
                   <span>🛍️</span> Standard Retail Customer
                 </div>`;e.innerHTML=`
          <div style="position: relative; display: inline-block;">
            <!-- Circular Avatar Only Trigger Button -->
            <button id="user-profile-trigger" style="
              background: transparent;
              border: none;
              padding: 2px;
              cursor: pointer;
              outline: none;
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
            " title="${s.name}">
              
              <!-- Circular Avatar Photo / Initials -->
              <div style="
                width: 38px;
                height: 38px;
                border-radius: 50%;
                background: linear-gradient(135deg, #0284c7, #6366f1);
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: 800;
                font-size: 0.88rem;
                color: white;
                box-shadow: 0 3px 10px rgba(2, 132, 199, 0.4);
                border: 2px solid ${l==="wholesale"?"#eab308":l==="loyalty"?"#10b981":"#38bdf8"};
                overflow: hidden;
                flex-shrink: 0;
                transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
              " onmouseover="this.style.transform='scale(1.1)'; this.style.boxShadow='0 4px 15px rgba(2, 132, 199, 0.6)'" 
                 onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 3px 10px rgba(2, 132, 199, 0.4)'">
                ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:h}
              </div>

              <!-- Status Badge Dot -->
              ${l==="wholesale"?'<span style="position:absolute; bottom:0; right:0; background:#eab308; color:#422006; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Wholesale">W</span>':l==="loyalty"?'<span style="position:absolute; bottom:0; right:0; background:#10b981; color:#ffffff; font-size:0.55rem; font-weight:900; padding:1px 4px; border-radius:10px; border:1.5px solid #0f172a;" title="Loyalty">L</span>':""}
            </button>

            <!-- Modern Floating Profile Card Dropdown -->
            <div id="user-profile-dropdown" style="
              display: none;
              position: absolute;
              right: 0;
              top: calc(100% + 12px);
              width: 290px;
              background: #0f172a;
              border: 1px solid rgba(255, 255, 255, 0.15);
              border-radius: 16px;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(0, 210, 255, 0.15);
              padding: 1.25rem;
              z-index: 10000;
              text-align: left;
            ">
              <!-- Profile Card Header -->
              <div style="display: flex; align-items: center; gap: 12px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
                <div style="
                  width: 46px;
                  height: 46px;
                  border-radius: 50%;
                  background: linear-gradient(135deg, #0284c7, #8b5cf6);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 1.1rem;
                  color: white;
                  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.35);
                  border: 2px solid rgba(255,255,255,0.6);
                  overflow: hidden;
                  flex-shrink: 0;
                ">
                  ${p?`<img src="${p}" alt="Avatar" style="width:100%; height:100%; object-fit:cover;">`:h}
                </div>
                <div style="overflow: hidden; flex: 1;">
                  <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                    <span style="font-weight: 800; font-size: 0.95rem; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;">
                      ${s.name}
                    </span>
                    ${u}
                  </div>
                  <div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
                    ${s.email||"Registered Customer"}
                  </div>
                </div>
              </div>

              <!-- Account Details & Benefits -->
              <div style="margin: 12px 0;">
                <div style="font-size: 0.7rem; text-transform: uppercase; font-weight: 800; color: #64748b; letter-spacing: 0.5px; margin-bottom: 6px;">
                  Account Membership
                </div>
                ${f}
                
                ${c?`
                  <div style="display:flex; align-items:center; gap:6px; font-size:0.78rem; color:#cbd5e1; margin-top:8px;">
                    <span style="color:#38bdf8;">📞</span> <span>${c}</span>
                  </div>
                `:""}
              </div>

              <!-- Quick Actions -->
              <div style="display: flex; flex-direction: column; gap: 6px; margin: 12px 0;">
                <a href="/track.html" style="
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  padding: 8px 12px;
                  background: rgba(255, 255, 255, 0.05);
                  border: 1px solid rgba(255, 255, 255, 0.08);
                  border-radius: 8px;
                  color: #f1f5f9;
                  text-decoration: none;
                  font-size: 0.82rem;
                  font-weight: 600;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(56, 189, 248, 0.15)'; this.style.borderColor='rgba(56, 189, 248, 0.3)'"
                   onmouseout="this.style.background='rgba(255, 255, 255, 0.05)'; this.style.borderColor='rgba(255, 255, 255, 0.08)'">
                  <span style="display:flex; align-items:center; gap:8px;">
                    <span>📦</span> Track My Orders
                  </span>
                  <span style="color:#94a3b8; font-size:0.75rem;">➔</span>
                </a>
              </div>

              <!-- Divider & Logout Button -->
              <div style="padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08);">
                <button id="nav-logout-btn" style="
                  width: 100%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  gap: 8px;
                  background: rgba(239, 68, 68, 0.12);
                  border: 1px solid rgba(239, 68, 68, 0.3);
                  color: #f87171;
                  padding: 8px 12px;
                  border-radius: 8px;
                  font-size: 0.85rem;
                  font-weight: 700;
                  cursor: pointer;
                  transition: all 0.2s;
                " onmouseover="this.style.background='rgba(239, 68, 68, 0.25)'; this.style.borderColor='rgba(239, 68, 68, 0.5)'"
                   onmouseout="this.style.background='rgba(239, 68, 68, 0.12)'; this.style.borderColor='rgba(239, 68, 68, 0.3)'">
                  <span>🚪</span> Log Out
                </button>
              </div>
            </div>
          </div>
        `;const g=document.getElementById("user-profile-trigger"),b=document.getElementById("user-profile-dropdown");g&&b&&(g.onclick=L=>{L.stopPropagation();const z=b.style.display==="block";b.style.display=z?"none":"block"});const y=document.getElementById("nav-logout-btn");y&&(y.onclick=async L=>{if(L.stopPropagation(),!navigator.onLine){alert("You are currently offline. Unsaved data will be lost if you logout now.");return}try{sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},await lt(Fe),window.location.href="/"}catch(z){console.error("Logout Error:",z),sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},window.location.reload()}})};document.addEventListener("click",l=>{const c=document.getElementById("user-profile-trigger"),p=document.getElementById("user-profile-dropdown");p&&c&&!c.contains(l.target)&&!p.contains(l.target)&&(p.style.display="none")}),o();const i=(n.email||"").trim(),r=i.toLowerCase(),d=T(E(C,"customers"),k("email","==",i)),a=T(E(C,"customers"),k("email","==",r));Promise.all([A(d),A(a)]).then(([l,c])=>{let p=null;if(l.empty?c.empty||(p=c.docs[0].data()):p=l.docs[0].data(),p){const m=(p.customerType||p.type||(p.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...p,customerType:m},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()}else{const m=window.currentStoreId||"mec-book-shop";A(T(E(C,"customers"),k("storeId","==",m))).then(h=>{const u=(n.displayName||n.email.split("@")[0]||"").trim().toLowerCase(),f=h.docs.find(g=>{const b=g.data(),y=(b.email||"").trim().toLowerCase(),B=(b.phone||"").trim(),w=(b.name||"").trim().toLowerCase(),P=y&&y===r,S=n.phoneNumber&&B&&(B===n.phoneNumber||n.phoneNumber.includes(B)),$=w&&u&&(w===u||u.includes(w)||w.includes(u)||u.split(" ")[0]===w);return P||S||$});if(f){const g=f.data(),b=(g.customerType||g.type||(g.loyaltyCardNo?"loyalty":"retail")).toLowerCase();window.currentUserProfile={...g,customerType:b,docId:f.id},!g.email&&n.email&&Xe(X(C,"customers",f.id),{email:n.email}).catch(()=>{})}else window.currentUserProfile={customerType:"retail"};sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()}).catch(()=>{window.currentUserProfile={customerType:"retail"},sessionStorage.setItem("mec_customer_profile",JSON.stringify(window.currentUserProfile)),o(),q()})}}).catch(l=>{console.error("Error fetching user profile:",l),window.currentUserProfile={customerType:"retail"},o(),q()})}else sessionStorage.removeItem("mec_user"),sessionStorage.removeItem("mec_customer_profile"),window.currentUserProfile={customerType:"retail"},q(),e&&(e.innerHTML='<a href="/login">Login</a>'),t&&(t.style.display="none")})}function Pt(){const e=document.getElementById("reviews-container");if(!e)return;const t=E(C,"reviews"),n=T(t,st("timestamp","desc"),it(15));xe(n,s=>{const o=s.docs.map(i=>i.data());if(o.length===0){e.innerHTML='<p class="loading-text">No reviews yet. Be the first to review us!</p>';return}e.innerHTML=o.map(i=>`
      <div class="review-card">
        <div class="review-stars">
          ${"★".repeat(i.rating)}${"☆".repeat(5-i.rating)}
        </div>
        <p class="review-comment">"${i.comment||"No comment provided."}"</p>
        <div class="review-footer">
          <span class="review-author">${i.userName}</span>
          <span class="review-date">${i.date}</span>
        </div>
      </div>
    `).join("")})}ht();Ct();Pt();const Ae="AQ.Ab8RN6In3ydCawx8pf5KvmZq7Bn7hCY76gCdLwZDJK_7WCqCZA";let Ne=null;try{Ae&&(Ne=new nt(Ae))}catch(e){console.warn("Could not instantiate GoogleGenerativeAI client:",e)}function Ge(e,t){if(!_||_.length===0)return t?"සමාවෙන්න, භාණ්ඩ තොරතුරු ලබා ගැනීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.":"Sorry, unable to load product information right now. Please try again.";const s=(e||"").toLowerCase().split(/\s+/).filter(i=>i.length>2),o=_.map(i=>{let r=0;const d=(i.name||"").toLowerCase(),a=(i.category||"").toLowerCase(),l=(i.description||"").toLowerCase();return s.forEach(c=>{d.includes(c)&&(r+=3),a.includes(c)&&(r+=2),l.includes(c)&&(r+=1)}),{product:i,score:r}}).filter(i=>i.score>0).sort((i,r)=>r.score-i.score);if(o.length>0){const i=o.slice(0,3).map(r=>r.product);return t?`ඔව්, අප සතුව පහත භාණ්ඩ තිබේ:
${i.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"තොග ඇත (In Stock)":"තොග අවසන් (Out of Stock)",l=d.wholesalePrice?` | තොග මිල: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

වැඩි විස්තර හෝ තොග ලබාගැනීමට කරුණාකර Support බොත්තම ඔබන්න.`:`Yes, we found the following matching items in stock:
${i.map(d=>{const a=d.stock>0||d.variants&&d.variants.some(c=>c.stock>0)?"In Stock":"Out of Stock",l=d.wholesalePrice?` | Wholesale: LKR ${d.wholesalePrice}`:"";return`• ${d.name} - LKR ${d.price}${l} [${a}]`}).join(`
`)}

For bulk or wholesale inquiries, please click the Support button!`}return t?"ස්තූතියි! ඔබට අවශ්‍ය භාණ්ඩය පිළිබඳ වැඩිදුර තොරතුරු සහ තොග මිල ගණන් සඳහා කරුණාකර අපගේ Support බොත්තම හරහා සම්බන්ධ වන්න.":"Thank you! For more details and wholesale pricing on this item, please click the Support button above to chat with our team."}async function Bt(e,t){var s,o,i,r,d,a;const n=/[\u0D80-\u0DFF]/.test(e)||t==="si"||["ow","ne","hoyala","mata","thiyenawada","tiyenawada","kiyada","poth","atlas"].some(l=>(e||"").toLowerCase().includes(l));try{const l=((s=window.currentStoreData)==null?void 0:s.name)||"MEC Book Shop, Horana",c=(_||[]).slice(0,50).map(u=>{let f=`${u.name} (Retail: LKR ${u.price}${u.wholesalePrice?`, Wholesale: LKR ${u.wholesalePrice}`:""})`;return u.variants&&u.variants.length>0?f+=` [Variants: ${u.variants.map(g=>`${g.name||g.variantLabel||"Var"}-Stock:${g.stock||0}`).join(", ")}]`:f+=` [Stock: ${u.stock||0}]`,f}).join(" | "),p=`You are the polite, helpful AI Store Assistant for ${l}.
Available Inventory & Prices:
${c}

CRITICAL RULES:
1. When asked about product availability or stock, check the catalog above and explicitly state if it is in stock or out of stock, including prices (retail and wholesale if asked).
2. Language: If query is in Sinhala or Singlish, respond in natural, friendly, respectful Sinhala (e.g. "ඔව්, අප ළඟ තිබෙනවා", "තොග ලබාගත හැක"). Otherwise respond in polite English.
3. Keep answers concise, clear, and direct (max 2-3 short sentences).
4. If customer asks for bulk/wholesale or contact, invite them to use the Support button.`;if(Ne)try{const b=(await(await Ne.getGenerativeModel({model:"gemini-2.5-flash"}).generateContent(`${p}

Customer Query: "${e}"`)).response).text().trim();if(b)return b}catch(u){console.warn("SDK gemini-2.5-flash failed, trying direct REST call:",u)}const m=`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(Ae)}`,h=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`${p}

Customer Query: "${e}"`}]}]})});if(h.ok){const u=await h.json(),f=(a=(d=(r=(i=(o=u==null?void 0:u.candidates)==null?void 0:o[0])==null?void 0:i.content)==null?void 0:r.parts)==null?void 0:d[0])==null?void 0:a.text;if(f&&f.trim())return f.trim()}return Ge(e,n)}catch(l){return console.error("Gemini Assistant Error, using local catalog fallback:",l),Ge(e,n)}}window.toggleGeminiChat=e=>{var o;const t=document.getElementById("gemini-chat-window"),n=document.getElementById("gemini-bubble");if(!t)return;(e!=null?!!e:!t.classList.contains("active"))?(t.classList.add("active"),n&&n.classList.remove("active"),(o=document.getElementById("gemini-chat-input"))==null||o.focus()):t.classList.remove("active")};window.sendGeminiChatMessage=async()=>{var p;const e=document.getElementById("gemini-chat-input"),t=document.getElementById("gemini-chat-messages");if(!e||!t||!e.value.trim())return;const n=e.value.trim();e.value="";const s=document.createElement("div");s.className="user-msg",s.textContent=n,t.appendChild(s),t.scrollTop=t.scrollHeight;const o=document.createElement("div");o.className="ai-msg",o.textContent="Thinking...",t.appendChild(o),t.scrollTop=t.scrollHeight;const i=n.toLowerCase(),r=["search","find","hoyala","hoyanna","balanna","thiyenawada","tiyenawada","look for","get me"];let d=n,a=!1;if(r.forEach(m=>{i.includes(m)&&(a=!0)}),a&&(r.forEach(m=>{d=d.replace(new RegExp(m,"gi"),"")}),d=d.replace(/for/gi,"").replace(/mata/gi,"").replace(/whalsale/gi,"").replace(/wholesale/gi,"").replace(/poth/gi,"").trim(),d.length>1)){window.searchQuery=d,W=d;const m=document.getElementById("store-search");m&&(m.value=d),R=1,window.currentPage=1,window.renderProducts&&window.renderProducts(),(p=document.getElementById("shop-section"))==null||p.scrollIntoView({behavior:"smooth"})}const l=/[\u0D80-\u0DFF]/.test(n)||["mata","thiyenawada","tiyenawada","poth"].some(m=>i.includes(m)),c=await Bt(n,l?"si":"en");o.textContent=c,t.scrollTop=t.scrollHeight};window.talkToAgentWhatsApp=()=>{var i,r,d;const e=document.getElementById("gemini-chat-messages");let t="";e&&(t=Array.from(e.querySelectorAll("div")).map(l=>`${l.classList.contains("user-msg")?"Customer":"AI"}: ${l.textContent}`).join(`
`));let n=((i=window.currentStoreData)==null?void 0:i.phone)||((r=window.systemConfig)==null?void 0:r.invPhone)||"94770658356";n=n.replace(/[^0-9]/g,""),n.startsWith("0")&&(n="94"+n.substring(1));const s=`Hi ${((d=window.currentStoreData)==null?void 0:d.name)||"MEC Support"}! I was chatting with your AI assistant. Here is my query:

`,o=encodeURIComponent(s+t);window.open(`https://wa.me/${n}?text=${o}`,"_blank")};setTimeout(()=>{const e=document.getElementById("gemini-bubble");e&&!document.getElementById("gemini-chat-window").classList.contains("active")&&(e.classList.add("active"),setTimeout(()=>e.classList.remove("active"),8e3))},5e3);const Je=document.getElementById("gemini-orb-btn");Je&&Je.addEventListener("click",()=>window.toggleGeminiChat());window.checkAffReferral=async()=>{const e=Ze.get("ref");if(e&&(sessionStorage.setItem("mec_ref_code",e),!sessionStorage.getItem("mec_ref_clicked"))){sessionStorage.setItem("mec_ref_clicked","1");try{const t=T(E(C,"affiliates"),k("code","==",e),k("storeId","==",window.currentStoreId)),n=await A(t);if(!n.empty){const s=X(C,"affiliates",n.docs[0].id);await Me(s,{clicks:we(1)},{merge:!0}),console.log(`Registered click for affiliate promoter: ${e}`)}}catch(t){console.error("Error incrementing referral click:",t)}}};function Et(){if(document.getElementById("affiliate-portal-modal"))return;const e=document.createElement("div");e.id="affiliate-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:600px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleAffiliatePortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="aff-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Program</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Promote our store and earn a 5% commission on every successful purchase referred by you.</p>
        
        <!-- Tab navigation inside modal -->
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="aff-tab-login" onclick="window.switchAffTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="aff-tab-register" onclick="window.switchAffTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register</button>
        </div>

        <form id="aff-login-form" onsubmit="window.handleAffiliateLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="aff-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="aff-register-form" onsubmit="window.handleAffiliateRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="aff-reg-name" placeholder="Full Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="aff-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="aff-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="aff-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Become an Affiliate</button>
        </form>
      </div>

      <div id="aff-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Affiliate Partner Dashboard</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:1.5rem;">Welcome back, <span id="aff-dash-name" style="color:#fff; font-weight:bold;">Promoter</span>!</p>
        
        <div style="background:rgba(56,189,248,0.08); border:1px dashed #38bdf8; padding:1rem; border-radius:12px; margin-bottom:1.5rem;">
          <span style="font-size:0.75rem; color:#38bdf8; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; display:block; margin-bottom:4px;">Your Shareable Referral Link:</span>
          <div style="display:flex; gap:10px; align-items:center;">
            <input type="text" id="aff-referral-url" readonly style="flex:1; background:none; border:none; color:white; font-size:0.85rem; outline:none;" onclick="this.select()">
            <button onclick="window.copyAffReferralLink()" style="background:rgba(255,255,255,0.1); border:none; color:white; padding:6px 12px; border-radius:6px; font-size:0.75rem; font-weight:bold; cursor:pointer;">Copy</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; margin-bottom:1.5rem;">
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-clicks" style="font-size:1.5rem; font-weight:800; color:#38bdf8; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Total Clicks</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-sales" style="font-size:1.5rem; font-weight:800; color:#10b981; display:block;">0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Referred Sales</span>
          </div>
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1rem; border-radius:12px; text-align:center;">
            <span id="aff-commission" style="font-size:1.1rem; font-weight:800; color:#fbbf24; display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">LKR 0</span>
            <span style="font-size:0.75rem; color:#94a3b8;">Earned</span>
          </div>
        </div>

        <button onclick="window.handleAffiliateLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer; transition:0.3s;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}function $t(){if(document.getElementById("seller-portal-modal"))return;const e=document.createElement("div");e.id="seller-portal-modal",e.className="modal-overlay",e.style.cssText="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(2,6,23,0.95); z-index:99999; justify-content:center; align-items:center;",e.innerHTML=`
    <div class="glass-card" style="width:90%; max-width:650px; padding:2.5rem; border-radius:24px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); position:relative; max-height:90vh; overflow-y:auto; color:white;">
      <button onclick="window.toggleSellerPortal(false)" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#94a3b8; font-size:2rem; cursor:pointer; transition:0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">&times;</button>
      
      <div id="seller-auth-section">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Merchant Seller Portal</h2>
        <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:2rem; line-height:1.5;">Register your shop and start selling your products on our storefront today.</p>
        
        <div style="display:flex; gap:10px; margin-bottom:1.5rem; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">
          <button id="seller-tab-login" onclick="window.switchSellerTab('login')" style="background:none; border:none; color:#38bdf8; font-weight:bold; cursor:pointer; padding:5px 10px;">Login</button>
          <button id="seller-tab-register" onclick="window.switchSellerTab('register')" style="background:none; border:none; color:#94a3b8; font-weight:bold; cursor:pointer; padding:5px 10px;">Register Shop</button>
        </div>

        <form id="seller-login-form" onsubmit="window.handleSellerLogin(event)" style="display:flex; flex-direction:column; gap:12px;">
          <input type="email" id="seller-login-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-login-pass" placeholder="Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#38bdf8; border:none; color:#020617; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Sign In</button>
        </form>

        <form id="seller-register-form" onsubmit="window.handleSellerRegister(event)" style="display:none; flex-direction:column; gap:12px;">
          <input type="text" id="seller-reg-shopname" placeholder="Shop / Brand Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-owner" placeholder="Owner Name" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="email" id="seller-reg-email" placeholder="Email Address" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="text" id="seller-reg-phone" placeholder="Phone Number" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <input type="password" id="seller-reg-pass" placeholder="Create Password" required style="width:100%; padding:12px; border-radius:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:white; outline:none;">
          <button type="submit" style="width:100%; padding:12px; border-radius:10px; background:#10b981; border:none; color:white; font-weight:800; cursor:pointer; transition:0.3s; margin-top:10px;">Register Shop</button>
        </form>
      </div>

      <div id="seller-dashboard-section" style="display:none;">
        <h2 style="color:#38bdf8; margin-top:0; font-size:1.8rem; font-weight:800; letter-spacing:-0.5px;">Seller Dashboard</h2>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; background:rgba(255,255,255,0.02); padding:10px 15px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
          <div>
            <span style="font-size:0.8rem; color:#94a3b8; display:block;">Store Name</span>
            <span id="seller-dash-shopname" style="font-weight:bold; font-size:1.1rem; color:#fff;">My Brand Shop</span>
          </div>
          <div id="seller-dash-status-badge" style="padding:4px 10px; border-radius:20px; font-size:0.7rem; font-weight:bold; text-transform:uppercase;">
            Pending
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:1.5rem;">
          
          <!-- Add Product Form -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Add New Product</h4>
            <form id="seller-add-product-form" onsubmit="window.handleSellerAddProduct(event)" style="display:flex; flex-direction:column; gap:10px;">
              <input type="text" id="seller-prod-name" placeholder="Product Title" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="number" id="seller-prod-price" placeholder="Price (LKR)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-category" placeholder="Category (e.g. Gadgets)" required style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <input type="text" id="seller-prod-image" placeholder="Image URL (Optional)" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem;">
              <textarea id="seller-prod-desc" placeholder="Product Description..." rows="2" style="width:100%; padding:10px; border-radius:8px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); color:white; font-size:0.85rem; font-family:inherit; resize:none;"></textarea>
              <button type="submit" style="width:100%; padding:10px; border-radius:8px; background:#38bdf8; border:none; color:#020617; font-weight:bold; cursor:pointer; margin-top:5px;">Submit Product</button>
            </form>
          </div>

          <!-- Product List -->
          <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:1.5rem; border-radius:16px; display:flex; flex-direction:column;">
            <h4 style="margin-top:0; margin-bottom:1rem; color:#38bdf8; font-size:1rem;">Your Products</h4>
            <div id="seller-products-list" style="flex:1; overflow-y:auto; max-height:220px; display:flex; flex-direction:column; gap:8px;">
              <div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>
            </div>
          </div>
        </div>

        <button onclick="window.handleSellerLogout()" style="width:100%; padding:10px; border-radius:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; cursor:pointer;">Sign Out</button>
      </div>
    </div>
  `,document.body.appendChild(e)}window.toggleAffiliatePortal=async e=>{Et();const t=document.getElementById("affiliate-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_affiliate_user");if(n){const s=JSON.parse(n);try{const o=T(E(C,"affiliates"),k("email","==",s.email),k("storeId","==",window.currentStoreId)),i=await A(o);if(i.empty)localStorage.removeItem("mec_affiliate_user"),De();else{const r={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(r)),he(r)}}catch(o){console.error(o),he(s)}}else De()}};function De(){document.getElementById("aff-auth-section").style.display="block",document.getElementById("aff-dashboard-section").style.display="none",window.switchAffTab("login")}window.switchAffTab=e=>{const t=document.getElementById("aff-login-form"),n=document.getElementById("aff-register-form"),s=document.getElementById("aff-tab-login"),o=document.getElementById("aff-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),s&&(s.style.color="#38bdf8",s.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),s&&(s.style.color="#94a3b8",s.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleAffiliateLogin=async e=>{e.preventDefault();const t=document.getElementById("aff-login-email").value.trim(),n=document.getElementById("aff-login-pass").value;try{const s=T(E(C,"affiliates"),k("email","==",t),k("password","==",n),k("storeId","==",window.currentStoreId)),o=await A(s);if(o.empty)alert("Invalid email address or password.");else{const i={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_affiliate_user",JSON.stringify(i)),he(i)}}catch(s){console.error(s),alert("Login failed. Please try again.")}};window.handleAffiliateRegister=async e=>{e.preventDefault();const t=document.getElementById("aff-reg-name").value.trim(),n=document.getElementById("aff-reg-email").value.trim(),s=document.getElementById("aff-reg-phone").value.trim(),o=document.getElementById("aff-reg-pass").value;try{const i=T(E(C,"affiliates"),k("email","==",n),k("storeId","==",window.currentStoreId));if(!(await A(i)).empty){alert("An account with this email is already registered as a partner.");return}const d=t.toLowerCase().replace(/[^a-z0-9]/g,"")+Math.floor(100+Math.random()*900),a={name:t,email:n,phone:s,password:o,code:d,clicks:0,salesCount:0,totalCommission:0,storeId:window.currentStoreId,timestamp:G()},l=await Y(E(C,"affiliates"),a);a.docId=l.id,localStorage.setItem("mec_affiliate_user",JSON.stringify(a)),he(a)}catch(i){console.error(i),alert("Registration failed. Please try again.")}};function he(e){document.getElementById("aff-auth-section").style.display="none",document.getElementById("aff-dashboard-section").style.display="block",document.getElementById("aff-dash-name").innerText=e.name||"Promoter";const t=window.location.protocol,n=window.location.host,s=window.location.pathname;let o=`${t}//${n}${s}`;window.currentStoreId!=="mec-book-shop"&&window.currentStoreId!=="master"?o+=`?store=${window.currentStoreId}&ref=${e.code}`:o+=`?ref=${e.code}`,document.getElementById("aff-referral-url").value=o,document.getElementById("aff-clicks").innerText=e.clicks||0,document.getElementById("aff-sales").innerText=e.salesCount||0,document.getElementById("aff-commission").innerText=`LKR ${(e.totalCommission||0).toFixed(2)}`}window.copyAffReferralLink=()=>{const e=document.getElementById("aff-referral-url");e&&(e.select(),e.setSelectionRange(0,99999),navigator.clipboard.writeText(e.value),alert("Referral link copied to clipboard!"))};window.handleAffiliateLogout=()=>{localStorage.removeItem("mec_affiliate_user"),De()};window.toggleSellerPortal=async e=>{$t();const t=document.getElementById("seller-portal-modal");if(t&&(t.style.display=e?"flex":"none",t.classList.toggle("active",e),e)){const n=localStorage.getItem("mec_seller_user");if(n){const s=JSON.parse(n);try{const o=T(E(C,"vendor_shops"),k("email","==",s.email),k("storeId","==",window.currentStoreId)),i=await A(o);if(i.empty)localStorage.removeItem("mec_seller_user"),ze();else{const r={...i.docs[0].data(),docId:i.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(r)),ve(r)}}catch(o){console.error(o),ve(s)}}else ze()}};function ze(){document.getElementById("seller-auth-section").style.display="block",document.getElementById("seller-dashboard-section").style.display="none",window.switchSellerTab("login")}window.switchSellerTab=e=>{const t=document.getElementById("seller-login-form"),n=document.getElementById("seller-register-form"),s=document.getElementById("seller-tab-login"),o=document.getElementById("seller-tab-register");e==="login"?(t&&(t.style.display="flex"),n&&(n.style.display="none"),s&&(s.style.color="#38bdf8",s.style.borderBottom="2px solid #38bdf8"),o&&(o.style.color="#94a3b8",o.style.borderBottom="none")):(t&&(t.style.display="none"),n&&(n.style.display="flex"),s&&(s.style.color="#94a3b8",s.style.borderBottom="none"),o&&(o.style.color="#10b981",o.style.borderBottom="2px solid #10b981"))};window.handleSellerLogin=async e=>{e.preventDefault();const t=document.getElementById("seller-login-email").value.trim(),n=document.getElementById("seller-login-pass").value;try{const s=T(E(C,"vendor_shops"),k("email","==",t),k("password","==",n),k("storeId","==",window.currentStoreId)),o=await A(s);if(o.empty)alert("Invalid email address or password.");else{const i={...o.docs[0].data(),docId:o.docs[0].id};localStorage.setItem("mec_seller_user",JSON.stringify(i)),ve(i)}}catch(s){console.error(s),alert("Login failed. Please try again.")}};window.handleSellerRegister=async e=>{e.preventDefault();const t=document.getElementById("seller-reg-shopname").value.trim(),n=document.getElementById("seller-reg-owner").value.trim(),s=document.getElementById("seller-reg-email").value.trim(),o=document.getElementById("seller-reg-phone").value.trim(),i=document.getElementById("seller-reg-pass").value;try{const r=T(E(C,"vendor_shops"),k("shopName","==",t),k("storeId","==",window.currentStoreId));if(!(await A(r)).empty){alert("This shop name is already registered.");return}const a=T(E(C,"vendor_shops"),k("email","==",s),k("storeId","==",window.currentStoreId));if(!(await A(a)).empty){alert("This email is already registered to a shop.");return}const c={shopName:t,ownerName:n,email:s,phone:o,password:i,status:"pending",storeId:window.currentStoreId,timestamp:G()},p=await Y(E(C,"vendor_shops"),c);c.docId=p.id,localStorage.setItem("mec_seller_user",JSON.stringify(c)),ve(c);try{const m="+94770658356",h=`🚨 NEW STOREFRONT VENDOR REGISTRATION!
Shop: ${t}
Owner: ${n}
Phone: ${o}
Email: ${s}`,u=`https://www.smslenz.lk/api/send-sms?user_id=981&api_key=40b621ec-69ba-48c4-869b-cf30f3f58791&sender_id=MECBookShop&contact=${encodeURIComponent(m)}&message=${encodeURIComponent(h)}`;fetch(u,{method:"GET",mode:"no-cors"}).catch(()=>{})}catch(m){console.error("Vendor SMS alert error:",m)}}catch(r){console.error(r),alert("Shop registration failed. Please try again.")}};async function ve(e){document.getElementById("seller-auth-section").style.display="none",document.getElementById("seller-dashboard-section").style.display="block",document.getElementById("seller-dash-shopname").innerText=e.shopName||"My Brand Shop";const t=document.getElementById("seller-dash-status-badge");t&&(t.innerText=e.status||"pending",e.status==="active"?(t.style.background="rgba(16, 185, 129, 0.2)",t.style.color="#10b981"):(t.style.background="rgba(251, 191, 36, 0.2)",t.style.color="#fbbf24")),await ot(e.email)}async function ot(e){const t=document.getElementById("seller-products-list");if(t){t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">Loading products...</div>';try{const n=T(re,k("vendorId","==",e),k("storeId","==",window.currentStoreId)),s=await A(n);if(s.empty)t.innerHTML='<div style="color:#64748b; font-size:0.85rem; text-align:center; padding-top:2rem;">No products submitted yet.</div>';else{let o="";s.forEach(i=>{const r=i.data(),d=r.status==="active"?"#10b981":"#fbbf24";o+=`
          <div style="background:rgba(255,255,255,0.02); padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-weight:bold; font-size:0.85rem; display:block;">${r.name||""}</span>
              <span style="font-size:0.75rem; color:#94a3b8;">LKR ${r.price||0}</span>
            </div>
            <span style="font-size:0.7rem; font-weight:bold; text-transform:uppercase; color:${d};">${r.status||"pending"}</span>
          </div>
        `}),t.innerHTML=o}}catch(n){console.error(n),t.innerHTML='<div style="color:#ef4444; font-size:0.85rem; text-align:center; padding-top:2rem;">Error loading products.</div>'}}}window.handleSellerAddProduct=async e=>{e.preventDefault();const t=localStorage.getItem("mec_seller_user");if(!t)return;const n=JSON.parse(t),s=document.getElementById("seller-prod-name").value.trim(),o=document.getElementById("seller-prod-price").value.trim(),i=document.getElementById("seller-prod-category").value.trim(),r=document.getElementById("seller-prod-image").value.trim(),d=document.getElementById("seller-prod-desc").value.trim();try{const a={name:s,price:Number(o),category:i,image:r||"",description:d||"",status:"pending",vendorId:n.email,storeId:window.currentStoreId,timestamp:G(),sku:"SKU-VEND-"+Date.now(),cost:0,discount:0,stock:999,mode:"Shop"};await Y(re,a),alert("Product submitted successfully for approval!"),document.getElementById("seller-add-product-form").reset(),await ot(n.email)}catch(a){console.error(a),alert("Error submitting product. Please try again.")}};window.handleSellerLogout=()=>{localStorage.removeItem("mec_seller_user"),ze()};window.addEventListener("beforeunload",function(e){var t;(t=window.chrome)!=null&&t.webview||window.electron||window.electronAPI||navigator.onLine||(e.preventDefault(),e.returnValue="You are currently offline. Unsaved data will be lost if you close the app.")});
