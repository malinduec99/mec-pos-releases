import { db } from '../firebase.js';
import { 
    collection, 
    onSnapshot,
    query,
    where,
    getDocs
} from "firebase/firestore";
import { saveOfflineCache, loadOfflineCache } from './cacheManager.js';

const suppliersCol = collection(db, 'suppliers');
const productsCol = collection(db, 'products');
const poCol = collection(db, 'purchase_orders');

export function initSupplyChain() {
    // Initialize PO System
    window.currentPO = {
        supplierId: '',
        supplierName: '',
        items: [],
        total: 0,
        status: 'Pending',
        createdAt: new Date(),
        ref: 'PO-' + Math.random().toString(36).substr(2, 9).toUpperCase()
    };

    // Load Suppliers into Select
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';

    const supQ = isMaster ? suppliersCol : query(suppliersCol, where('storeId', '==', storeId));
    
    // Load from cache first
    loadOfflineCache('suppliers').then(cached => {
        if (cached && cached.length > 0) {
            window.allSuppliers = cached;
            const select = document.getElementById('po-supplier-select');
            if (select) {
                select.innerHTML = '<option value="">-- Choose Supplier --</option>' + 
                    cached.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
            }
        }
    });

    onSnapshot(supQ, (snapshot) => {
        const suppliers = snapshot.docs.map(doc => ({ id: doc.id, docId: doc.id, ...doc.data() }));
        window.allSuppliers = suppliers;
        saveOfflineCache('suppliers', suppliers);
        
        const select = document.getElementById('po-supplier-select');
        if (select) {
            select.innerHTML = '<option value="">-- Choose Supplier --</option>' + 
                suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
        }
    });

    // Ensure products are loaded for search
    const prodQ = isMaster ? productsCol : query(productsCol, where('storeId', '==', storeId));
    onSnapshot(prodQ, (snapshot) => {
        window.allProducts = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id, docId: doc.id, sku: doc.data().sku || doc.id }));
        console.log("📦 PO Terminal: Products Loaded", window.allProducts.length);
        window.updatePOHeader();
    });

    // Start Terminal Clock
    if (!window._poClockInterval) {
        window._poClockInterval = setInterval(() => {
            const clock = document.getElementById('po-terminal-clock');
            if (clock) {
                clock.innerText = new Date().toLocaleTimeString();
            }
        }, 1000);
    }

    window.updatePOHeader();
}

window.initSupplyChain = initSupplyChain;

window.exitPOTerminal = () => {
    const poSection = document.getElementById('section-purchase-orders');
    if (poSection) poSection.style.display = 'none';
    
    // Redirect to the Saved POs tab on exit
    if (window.showTab) window.showTab('po-saved');
};

window.updatePOHeader = () => {
    const select = document.getElementById('po-supplier-select');
    if (!select) return;
    
    const supplierId = select.value;
    const supplier = (window.allSuppliers || []).find(s => s.id === supplierId);
    
    const display = document.getElementById('po-supplier-display');
    const catalogHeader = document.getElementById('po-catalog-header');
    const catalogList = document.getElementById('po-quick-select-list');

    if (supplier) {
        window.currentPO.supplierId = supplierId;
        window.currentPO.supplierName = supplier.name;
        if (display) display.innerText = `Ordering from: ${supplier.name}`;
        
        let supplierProducts = (window.allProducts || []).filter(p => p.supplierId === supplierId);
        let isFallback = false;

        if (supplierProducts.length === 0) {
            supplierProducts = (window.allProducts || []).filter(p => !p.supplierId || p.supplierId === 'General').slice(0, 50);
            isFallback = true;
        }

        if (catalogHeader) catalogHeader.innerText = isFallback ? `General Catalog (Fallback)` : `${supplier.name} Catalog`;
        
        if (catalogList) {
            if (supplierProducts.length > 0) {
                catalogList.innerHTML = supplierProducts.map(p => `
                    <div class="catalog-item" onclick="window.addPOItem('${p.sku}')" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 8px; border-radius: 10px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: 0.2s;" onmouseover="this.style.background='rgba(56, 189, 248, 0.05)'; this.style.borderColor='rgba(56, 189, 248, 0.2)';" onmouseout="this.style.background='rgba(255,255,255,0.03)'; this.style.borderColor='rgba(255,255,255,0.05)';" title="Click to add to PO">
                        <img src="${(p.image && !p.image.includes('/logo.png') && !p.image.includes('zenith_logo')) ? p.image : ((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png')}" style="width: 32px; height: 32px; border-radius: 5px; object-fit: cover; background: #fff;" onerror="this.src=((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png');">
                        <div style="flex: 1; overflow: hidden;">
                            <div style="font-weight: 800; color: white; font-size: 0.75rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${p.name}</div>
                            <div style="font-size: 0.6rem; color: #64748b; font-weight: 800;">${p.sku} | LKR ${p.cost || 0}</div>
                        </div>
                        <div style="color: #38bdf8; font-size: 1rem; font-weight: 900; opacity: 0.4;">+</div>
                    </div>
                `).join('');
            } else {
                catalogList.innerHTML = `<div style="color: #475569; font-size: 0.75rem; text-align: center; padding: 20px;">No products found.</div>`;
            }
        }
    } else {
        window.currentPO.supplierId = '';
        window.currentPO.supplierName = '';
        if (display) display.innerText = 'Select a supplier';
        if (catalogHeader) catalogHeader.innerText = `Product Catalog`;
        if (catalogList) catalogList.innerHTML = '<div style="color: #475569; font-size: 0.75rem; text-align: center; padding: 20px;">Choose a supplier to view catalog.</div>';
    }
    
    const refBadge = document.getElementById('po-ref-badge');
    if (refBadge) refBadge.innerText = `REF: ${window.currentPO.ref}`;
};

window.searchProductsForPO = (val) => {
    const dropdown = document.getElementById('po-search-results');
    if (!dropdown) return;

    if (!val || val.length < 2) {
        dropdown.style.display = 'none';
        return;
    }

    const q = val.toLowerCase();
    const products = window.allProducts || [];
    const filtered = products.filter(p => {
        const matchesVariantSku = (p.variants || []).some(v => window.matchProductSku(v.sku, q));
        return (p.name && p.name.toLowerCase().includes(q)) || 
               window.matchProductSku(p.sku, q) ||
               matchesVariantSku;
    }).slice(0, 15);

    if (filtered.length > 0) {
        dropdown.innerHTML = filtered.map(p => `
            <div class="result-item" onclick="window.addPOItem('${p.sku}')" style="padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; display: flex; align-items: center; gap: 12px; transition: background 0.2s;" onmouseover="this.style.background='rgba(56, 189, 248, 0.1)'" onmouseout="this.style.background='transparent'">
                <img src="${(p.image && !p.image.includes('/logo.png') && !p.image.includes('zenith_logo')) ? p.image : ((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png')}" style="width: 35px; height: 35px; border-radius: 8px; object-fit: cover; background: #fff; flex-shrink: 0;" onerror="this.src=((typeof window.getMerchantDefaultLogo === 'function') ? window.getMerchantDefaultLogo() : '/mec-logo.png');">
                <div style="flex: 1; overflow: hidden;">
                    <div style="font-weight: 800; color: white; font-size: 0.85rem; line-height: 1.2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${p.name}</div>
                    <div style="font-size: 0.7rem; color: #38bdf8; font-weight: 800; margin-top: 4px;">${p.sku} | Cost: ${p.cost || 0}</div>
                </div>
            </div>
        `).join('');
        dropdown.style.display = 'block';
    } else {
        dropdown.innerHTML = `<div style="padding: 15px; color: #64748b; font-size: 0.8rem; font-weight: 800; text-align: center;">❌ NO PRODUCTS FOUND</div>`;
        dropdown.style.display = 'block';
    }
};

window.addPOItem = (sku) => {
    const product = (window.allProducts || []).find(p => p.sku === sku);
    if (!product) return;

    const existing = window.currentPO.items.find(i => i.sku === sku);
    if (existing) {
        existing.qty += 1;
    } else {
        window.currentPO.items.push({
            sku: product.sku,
            name: product.name,
            cost: Number(product.cost) || 0,
            qty: 1
        });
    }

    document.getElementById('po-search-results').style.display = 'none';
    document.getElementById('po-search-input').value = '';
    window.showMarketIntelligence(product.name);
    window.renderPOWorksheet();
};

window.showMarketIntelligence = (productName) => {
    const container = document.getElementById('po-intel-container');
    if (!container) return;
    const allVersions = (window.allProducts || []).filter(p => p.name === productName);
    if (allVersions.length === 0) {
        container.innerHTML = `<div style="color: #64748b; text-align: center; padding: 20px;">No comparison data.</div>`;
        return;
    }
    let intelHtml = `
        <div style="background: rgba(56, 189, 248, 0.03); border: 1px solid rgba(56, 189, 248, 0.1); border-radius: 12px; padding: 12px; margin-bottom: 15px;">
            <div style="font-weight: 900; color: white; font-size: 0.9rem; margin-bottom: 3px;">${productName}</div>
            <div style="color: #38bdf8; font-size: 0.6rem; font-weight: 800; text-transform: uppercase;">Supplier Pricing & History</div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 8px;">
    `;
    allVersions.forEach(v => {
        const isCurrentSupplier = v.supplierId === window.currentPO.supplierId;
        const supplierName = v.supplierName || v.supplierId || 'Unknown';
        intelHtml += `
            <div style="${isCurrentSupplier ? 'background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.2);' : 'background: rgba(255,255,255,0.01); border: 1px solid rgba(255,255,255,0.03);'} border-radius: 10px; padding: 10px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                    <span style="font-size: 0.55rem; color: #64748b; font-weight: 900;">${supplierName}</span>
                    <span style="font-size: 0.8rem; color: #38bdf8; font-weight: 900;">${v.cost || 0}</span>
                </div>
            </div>
        `;
    });
    intelHtml += `</div>`;
    container.innerHTML = intelHtml;
};

window.removePOItem = (sku) => {
    window.currentPO.items = window.currentPO.items.filter(i => i.sku !== sku);
    window.renderPOWorksheet();
};

window.updatePOItemQty = (sku, qty) => {
    const item = window.currentPO.items.find(i => i.sku === sku);
    if (item) {
        item.qty = Number(qty) || 0;
        window.updateTotalsOnly();
        const rowTotalEl = document.getElementById(`po-item-total-${sku}`);
        if (rowTotalEl) {
            rowTotalEl.innerText = (item.qty * item.cost).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
    }
};

window.updatePOItemCost = (sku, cost) => {
    const item = window.currentPO.items.find(i => i.sku === sku);
    if (item) {
        item.cost = Number(cost) || 0;
        window.updateTotalsOnly();
        const rowTotalEl = document.getElementById(`po-item-total-${sku}`);
        if (rowTotalEl) {
            rowTotalEl.innerText = (item.qty * item.cost).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
    }
};

window.updateTotalsOnly = () => {
    let grandTotal = 0;
    let totalQty = 0;
    
    if (window.currentPO && window.currentPO.items) {
        window.currentPO.items.forEach(item => {
            const cost = Number(item.cost) || 0;
            const qty = Number(item.qty) || 0;
            grandTotal += (cost * qty);
            totalQty += qty;
        });
    }
    
    const itemsBadge = document.getElementById('po-total-items-badge');
    const grandTotalEl = document.getElementById('po-terminal-grand-total');
    
    if (itemsBadge) itemsBadge.innerText = `${totalQty} ITEMS`;
    if (grandTotalEl) {
        grandTotalEl.innerText = grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    
    window.currentPO.total = grandTotal;
    console.log(`📊 [PO CALC] Items: ${totalQty}, Total: ${grandTotal}`);
};

window.renderPOWorksheet = () => {
    const tbody = document.getElementById('po-items-table-body');
    if (!tbody) return;

    if (window.currentPO.items.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding: 4rem; opacity: 0.3; color: #475569; font-weight: 800;">SEARCH & ADD ITEMS TO START YOUR ORDER.</td></tr>';
        window.updateTotalsOnly();
        return;
    }

    tbody.innerHTML = window.currentPO.items.map(item => `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
            <td style="padding: 8px 12px; cursor: pointer;" onclick="window.showMarketIntelligence('${item.name}')">
                <div style="font-weight: 800; color: white; font-size: 0.8rem; line-height: 1.2;">${item.name}</div>
                <div style="font-size: 0.6rem; color: #475569; font-weight: 800; margin-top: 2px;">${item.sku}</div>
            </td>
            <td style="padding: 8px; text-align: center; width: 80px;">
                <input type="number" value="${item.qty}" oninput="window.updatePOItemQty('${item.sku}', this.value)" style="width: 50px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 6px; padding: 5px; text-align: center; font-weight: 900; font-size: 0.85rem;">
            </td>
            <td style="padding: 8px; text-align: right; width: 130px;">
                <div style="display: flex; align-items: center; justify-content: flex-end; gap: 4px;">
                    <span style="color: #475569; font-size: 0.55rem; font-weight: 900;">LKR</span>
                    <input type="number" value="${item.cost}" step="0.01" min="0" oninput="window.updatePOItemCost('${item.sku}', this.value)" style="width: 80px; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); color: #38bdf8; border-radius: 6px; padding: 5px; text-align: right; font-weight: 900; font-size: 0.85rem;">
                </div>
            </td>
            <td id="po-item-total-${item.sku}" style="padding: 8px 12px; text-align: right; font-weight: 900; color: white; font-size: 0.9rem; width: 130px;">
                ${(Number(item.cost) * Number(item.qty)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </td>
            <td style="padding: 8px; text-align: center; width: 50px;">
                <button onclick="window.removePOItem('${item.sku}')" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #ef4444; padding: 6px; border-radius: 6px;">🗑️</button>
            </td>
        </tr>
    `).join('');
    window.updateTotalsOnly();
};

window.clearPOTerminalItems = () => {
    if (confirm("Clear all items?")) {
        window.currentPO.items = [];
        window.renderPOWorksheet();
    }
};

window.savePOTerminalOrder = async () => {
    if (window.currentPO.items.length === 0) {
        window.showToast("Add items before saving", "warning");
        return;
    }
    if (!window.currentPO.supplierId) {
        window.showToast("Please select a supplier", "warning");
        return;
    }

    try {
        const { addDoc } = await import("firebase/firestore");
        await addDoc(poCol, {
            ...window.currentPO,
            createdAt: new Date(),
            status: 'Saved'
        });
        window.showToast("Purchase Order Saved Successfully", "success");
        // Reset PO
        window.currentPO.items = [];
        window.currentPO.ref = 'PO-' + Math.random().toString(36).substr(2, 9).toUpperCase();
        window.renderPOWorksheet();
        window.updatePOHeader();
    } catch (e) {
        console.error("Error saving PO:", e);
        window.showToast("Error saving Purchase Order", "error");
    }
};

window.printPOTerminalInvoice = (poData = null) => {
    const data = poData || window.currentPO;
    if (data.items.length === 0) {
        window.showToast("No items to print", "warning");
        return;
    }
    window.openPODocument(data, true);
};

window.downloadPOAsPDF = async (poData = null) => {
    const data = poData || window.currentPO;
    if (!data || !data.items || data.items.length === 0) {
        window.showToast("No items to export", "warning");
        return;
    }

    try {
        window.showToast("🚀 Generating PDF document...", "info");
        
        const html = window.getPOHTML(data, false);
        
        const element = document.createElement('div');
        element.innerHTML = html;
        document.body.appendChild(element);

        const opt = {
            margin: 10,
            filename: `PO_${data.ref}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        if (window.electron) {
            html2pdf().set(opt).from(element).toPdf().output('datauristring').then(dataUri => {
                window.electron.send('save-order-export', { base64Data: dataUri, fileName: opt.filename });
                window.showToast(`✅ Saved to C:\\MEC_EXPORTS\\${opt.filename}`, "success");
                document.body.removeChild(element);
            });
        } else {
            await html2pdf().set(opt).from(element).save();
            window.showToast("✅ PO PDF Downloaded", "success");
            document.body.removeChild(element);
        }
    } catch (err) {
        console.error("PDF Generation Error:", err);
        window.showToast("❌ PDF Generation Failed", "error");
    }
};

window.openPODocument = (data, autoPrint = true) => {
    const html = window.getPOHTML(data, true);
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
        window.showToast("⚠️ Popup blocked! Please allow popups or use the direct PDF button.", "error");
        return;
    }
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>PO ${data.ref}</title>
            <style>
                @media print {
                    .no-print { display: none !important; }
                    body { padding: 0 !important; }
                }
            </style>
        </head>
        <body style="margin:0; padding:0;">
            ${html}
            ${autoPrint ? '<script>setTimeout(() => { window.focus(); window.print(); }, 500);<\/script>' : ''}
        </body>
        </html>
    `);
    printWindow.document.close();
};

window.getPOHTML = (data, includeNoPrint = true) => {
    const config = window.STORE_CONFIG || { name: 'MEC Book Shop', logo: '/mec-logo.png', phone: '071 234 5678' };
    const dateStr = new Date(data.createdAt?.seconds * 1000 || data.createdAt).toLocaleDateString('en-GB', { year: 'numeric', month: 'long', day: 'numeric' });

    const itemsHtml = data.items.map((item, index) => `
        <tr style="border-bottom: 1px solid #f1f5f9;">
            <td style="padding: 10px 12px; text-align:center;">${index + 1}</td>
            <td style="padding: 10px 12px;">
                <strong>${item.name || '-'}</strong><br>
                <span style="font-size:10px; color:#94a3b8; font-weight:700;">${item.sku || ''}</span>
            </td>
            <td style="padding: 10px 12px; text-align:center;">${item.qty}</td>
            <td style="padding: 10px 12px; text-align:right;">LKR ${Number(item.cost).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
            <td style="padding: 10px 12px; text-align:right;"><strong>LKR ${(Number(item.cost) * Number(item.qty)).toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></td>
        </tr>
    `).join('');

    return `
    <div style="font-family: 'Outfit', 'Inter', 'Iskoola Pota', 'Iskola Pota', 'Noto Sans Sinhala', 'Segoe UI Sinhala', 'Segoe UI Historic', 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1a1a2e; background: #fff; padding: 40px; width: 210mm; min-height: 297mm; box-sizing: border-box; margin: auto; position: relative;">
        ${includeNoPrint ? `
        <div class="no-print" style="margin-bottom: 20px; padding: 12px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; color: #1d4ed8; font-size: 13px; font-weight: 600; text-align: center;">
            💡 To save as PDF: Click <strong>"Save as PDF"</strong> below, or press <strong>Ctrl+P</strong> → choose <strong>"Save as PDF"</strong> as the printer.
            &nbsp;&nbsp;
            <button style="background: #0ea5e9; color: white; border: none; padding: 10px 24px; border-radius: 8px; font-size: 14px; font-weight: 800; cursor: pointer; margin: 0 6px;" onclick="window.print()">🖨️ Print / Save as PDF</button>
            <button style="background: #64748b; color: white; border: none; padding: 10px 24px; border-radius: 8px; font-size: 14px; font-weight: 800; cursor: pointer; margin: 0 6px;" onclick="window.close()">✕ Close</button>
        </div>
        ` : ''}

        <div style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 20px; border-bottom: 3px solid #0ea5e9; margin-bottom: 25px;">
            <div>
                <h1 style="font-size: 22px; font-weight: 900; color: #0ea5e9; margin: 0 0 4px 0;">${config.name}</h1>
                <p style="color: #64748b; font-size: 12px; margin: 0;">Purchase Order Document</p>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 18px; font-weight: 900; color: #1e293b;">${data.ref}</div>
                <div style="color: #64748b; font-size: 12px; margin-top: 4px;">${dateStr}</div>
                <div style="font-weight: 700; color: #0ea5e9; font-size: 13px; margin-top: 6px;">Supplier: ${data.supplierName || '-'}</div>
            </div>
        </div>

        <div style="font-size: 11px; font-weight: 900; text-transform: uppercase; color: #94a3b8; letter-spacing: 1.5px; margin-bottom: 10px;">Order Items</div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px;">
            <thead>
                <tr style="background: #0ea5e9; color: white;">
                    <th style="padding: 10px 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; text-align:center; width:40px">#</th>
                    <th style="padding: 10px 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; text-align:left;">Description</th>
                    <th style="padding: 10px 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; text-align:center; width:70px">Qty</th>
                    <th style="padding: 10px 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; text-align:right; width:130px">Unit Cost</th>
                    <th style="padding: 10px 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; text-align:right; width:140px">Line Total</th>
                </tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
        </table>

        <div style="display: flex; justify-content: flex-end;">
            <div style="background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 10px; padding: 15px 25px; min-width: 260px;">
                <div style="display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px;">
                    <span>Total Items</span>
                    <span>${data.items.reduce((s, i) => s + Number(i.qty || 0), 0)} units</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; border-top: 2px solid #0ea5e9; margin-top: 8px; padding-top: 10px;">
                    <span style="font-size: 18px; font-weight: 900; color: #0ea5e9;">Grand Total</span>
                    <span style="font-size: 18px; font-weight: 900; color: #0ea5e9;">LKR ${Number(data.total).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
            </div>
        </div>

        <div style="margin-top: 40px; padding-top: 15px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; color: #94a3b8; font-size: 11px;">
            <span>Generated by MEC POS &bull; ${new Date().toLocaleString()}</span>
            <span>Status: ${data.status || 'Saved'}</span>
        </div>
    </div>`;
};

window.renderPOSavedOrders = async () => {
    const listContainer = document.getElementById('po-saved-list');
    if (!listContainer) return;
    
    listContainer.innerHTML = '<div style="padding: 2rem; text-align: center; color: #64748b;">Loading saved orders...</div>';
    
    try {
        const querySnapshot = await getDocs(query(poCol));
        const pos = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).sort((a,b) => b.createdAt - a.createdAt);
        window.allSavedPOs = pos; // Global store

        if (pos.length === 0) {
            listContainer.innerHTML = '<div style="padding: 4rem; text-align: center; color: #475569; font-weight: 800; border: 2px dashed rgba(255,255,255,0.05); border-radius: 24px;">NO SAVED PURCHASE ORDERS FOUND.</div>';
            return;
        }

        listContainer.innerHTML = `
            <table class="admin-table v2-dark">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reference</th>
                        <th>Supplier</th>
                        <th style="text-align: right;">Items</th>
                        <th style="text-align: right;">Total Amount</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${pos.map((po, index) => `
                        <tr>
                            <td style="font-size: 0.8rem;">${new Date(po.createdAt?.seconds * 1000 || po.createdAt).toLocaleDateString()}</td>
                            <td style="font-weight: 900; color: #38bdf8;">${po.ref}</td>
                            <td>${po.supplierName}</td>
                            <td style="text-align: right;">${po.items.length}</td>
                            <td style="text-align: right; font-weight: 900; color: white;">LKR ${Number(po.total).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                            <td style="text-align: center; display: flex; gap: 8px; justify-content: center;">
                                <button onclick="window.printPOByIndex(${index})" class="action-btn" style="padding: 6px 12px; background: rgba(56, 189, 248, 0.1); color: #38bdf8; border: 1px solid rgba(56,189,248,0.2); border-radius: 8px;">🖨️ Print</button>
                                <button onclick="window.downloadPOByIndex(${index})" class="action-btn" style="padding: 6px 12px; background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239,68,68,0.2); border-radius: 8px;">📄 PDF</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (e) {
        console.error("Error loading saved POs:", e);
        listContainer.innerHTML = '<div style="padding: 2rem; text-align: center; color: #ef4444;">Error loading saved orders.</div>';
    }
};

window.printPOByIndex = (index) => {
    if (window.allSavedPOs && window.allSavedPOs[index]) {
        window.printPOTerminalInvoice(window.allSavedPOs[index]);
    }
};

window.downloadPOByIndex = (index) => {
    if (window.allSavedPOs && window.allSavedPOs[index]) {
        window.downloadPOAsPDF(window.allSavedPOs[index]);
    }
};
