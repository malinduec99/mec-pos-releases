import { auth, db } from '../firebase.js';
import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { 
    collection, 
    onSnapshot, 
    addDoc, 
    serverTimestamp, 
    query, 
    orderBy, 
    limit,
    where
} from "firebase/firestore";
import { initAutoBackup } from './backup.js';
import { saveOfflineCache, loadOfflineCache } from './cacheManager.js';

// --- Admin Credentials (Moved from admin.js) ---
export const ADMIN_EMAIL = 'mecbookshop@gmail.com';
export const ADMIN_PASS = 'mec123';
export const PLATFORM_ADMIN = 'malinduec@gmail.com';
export const PLATFORM_PASS = 'malindu123';

const employeesCol = collection(db, 'employees');
const customersCol = collection(db, 'customers');
const branchesCol = collection(db, 'branches');

// --- RBAC Config ---
export const ROLE_PERMISSIONS = {
    'SuperAdmin': ['dashboard', 'orders', 'quotations', 'quotation-history', 'web-orders', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'reports', 'report-hub', 'analytics', 'expenses', 'purchases', 'income', 'suppliers', 'supplier-invoices', 'purchase-orders', 'po-saved', 'promotions', 'customers', 'repairs', 'hrm', 'internal-mail', 'branches', 'stores', 'it-system', 'appearance', 'web-dev', 'credit', 'mrp', 'settings', 'reload', 'bank', 'ai-copilot'],
    'CEO_Admin': ['dashboard', 'orders', 'quotations', 'quotation-history', 'web-orders', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'reports', 'report-hub', 'analytics', 'expenses', 'purchases', 'income', 'suppliers', 'supplier-invoices', 'purchase-orders', 'po-saved', 'promotions', 'customers', 'repairs', 'hrm', 'internal-mail', 'branches', 'it-system', 'appearance', 'web-dev', 'credit', 'mrp', 'settings', 'reload', 'bank', 'ai-copilot'],
    'Admin': ['dashboard', 'orders', 'quotations', 'quotation-history', 'web-orders', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'reports', 'report-hub', 'analytics', 'expenses', 'purchases', 'income', 'suppliers', 'supplier-invoices', 'purchase-orders', 'po-saved', 'promotions', 'customers', 'repairs', 'hrm', 'internal-mail', 'branches', 'it-system', 'appearance', 'web-dev', 'credit', 'mrp', 'settings', 'reload', 'bank', 'ai-copilot'],
    'IT_Manager': ['it-system', 'branches', 'hrm', 'internal-mail', 'stores'],
    'Finance_Manager': ['reports', 'report-hub', 'analytics', 'expenses', 'income', 'purchases', 'suppliers', 'orders', 'quotations', 'quotation-history', 'hrm', 'internal-mail', 'credit', 'bank', 'ai-copilot'],
    'Junior_Accountant': ['reports', 'report-hub', 'analytics', 'expenses', 'income', 'purchases', 'internal-mail'],
    'HR_Manager': ['hrm', 'internal-mail', 'reports'],
    'Inventory_Manager': ['products', 'stocks-view', 'stock', 'categories', 'suppliers', 'supplier-invoices', 'purchases', 'reports', 'report-hub', 'analytics', 'mrp', 'internal-mail'],
    'Stock_Controller': ['products', 'stocks-view', 'stock', 'categories', 'suppliers', 'internal-mail'],
    'Store_Keeper': ['stocks-view', 'stock', 'products', 'internal-mail'],
    'Sales_Manager': ['orders', 'quotations', 'quotation-history', 'customers', 'reports', 'analytics', 'pos', 'credit', 'internal-mail', 'ai-copilot'],
    'Cashier': ['pos', 'orders', 'quotations', 'quotation-history', 'customers', 'repairs', 'credit', 'reports', 'internal-mail'],
    'RepairTech': ['repairs', 'pos', 'internal-mail'],
    'Branch_Manager': ['pos', 'orders', 'quotations', 'quotation-history', 'products', 'stocks-view', 'stock', 'hrm', 'internal-mail', 'reports', 'report-hub', 'analytics', 'ai-copilot'],
    'Web_Developer': ['web-dev', 'appearance', 'it-system', 'internal-mail'],
    'HR': ['hrm', 'internal-mail', 'reports'],
    'Accountant': ['reports', 'report-hub', 'analytics', 'expenses', 'income', 'purchases', 'suppliers', 'orders', 'quotations', 'quotation-history', 'repairs', 'credit', 'bank', 'internal-mail', 'ai-copilot'],
    'Stock': ['products', 'stocks-view', 'stock', 'categories', 'suppliers', 'internal-mail']
};

// --- Role Startup Landing Page & Quick Default Shortcuts Config ---
export const ROLE_STARTUP_TABS = {
    'Cashier': 'pos',
    'RepairTech': 'repairs',
    'Store_Keeper': 'stocks-view',
    'Stock_Controller': 'products',
    'Inventory_Manager': 'products',
    'Stock': 'products',
    'HR_Manager': 'hrm',
    'HR': 'hrm',
    'Sales_Manager': 'orders',
    'Branch_Manager': 'pos',
    'Finance_Manager': 'reports',
    'Accountant': 'reports',
    'Junior_Accountant': 'reports',
    'Web_Developer': 'web-dev',
    'IT_Manager': 'it-system',
    'Admin': 'dashboard',
    'CEO_Admin': 'dashboard',
    'SuperAdmin': 'dashboard'
};

export const ROLE_DEFAULT_FAVORITES = {
    'Cashier': ['pos', 'orders', 'internal-mail', 'customers', 'repairs', 'credit', 'reload'],
    'RepairTech': ['repairs', 'pos', 'internal-mail', 'customers'],
    'Store_Keeper': ['stocks-view', 'stock', 'products', 'internal-mail'],
    'Stock_Controller': ['products', 'stocks-view', 'stock', 'internal-mail'],
    'Inventory_Manager': ['products', 'stocks-view', 'stock', 'internal-mail', 'purchases'],
    'Stock': ['products', 'stocks-view', 'stock', 'internal-mail'],
    'HR_Manager': ['hrm', 'internal-mail'],
    'HR': ['hrm', 'internal-mail'],
    'Sales_Manager': ['orders', 'pos', 'internal-mail', 'customers', 'credit'],
    'Branch_Manager': ['pos', 'orders', 'products', 'stocks-view', 'internal-mail', 'reports'],
    'Finance_Manager': ['reports', 'report-hub', 'analytics', 'internal-mail', 'expenses'],
    'Accountant': ['reports', 'report-hub', 'analytics', 'internal-mail', 'expenses'],
    'Junior_Accountant': ['reports', 'report-hub', 'analytics', 'internal-mail'],
    'Web_Developer': ['web-dev', 'appearance', 'it-system', 'internal-mail'],
    'IT_Manager': ['it-system', 'branches', 'hrm', 'internal-mail'],
    'Admin': ['dashboard', 'pos', 'orders', 'internal-mail', 'products', 'stock'],
    'CEO_Admin': ['dashboard', 'pos', 'orders', 'internal-mail', 'products', 'stock'],
    'SuperAdmin': ['dashboard', 'pos', 'orders', 'internal-mail', 'products', 'stock']
};

// --- Plan Permissions Configuration ---
export const PLAN_PERMISSIONS = {
    'Trial': ['dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings', 'orders', 'quotations', 'quotation-history', 'web-orders', 'internal-mail'],
    'POSLite': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'customers', 'credit', 'expenses', 'internal-mail'
    ],
    'POSStandard': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'customers', 'credit', 'expenses', 'orders', 'web-orders',
        'purchases', 'suppliers', 'supplier-invoices', 'purchase-orders', 'po-saved', 'internal-mail'
    ],
    'POSPro': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'customers', 'credit', 'expenses', 'orders', 'web-orders',
        'purchases', 'suppliers', 'supplier-invoices', 'purchase-orders', 'po-saved',
        'repairs', 'internal-mail'
    ],
    'Starter': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'report-hub', 'customers', 'expenses', 'credit', 'income',
        'orders', 'quotations', 'quotation-history', 'web-orders', 'reload', 'bank', 'internal-mail'
    ],
    'Professional': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'report-hub', 'customers', 'expenses', 'credit', 'income',
        'orders', 'quotations', 'quotation-history', 'web-orders', 'web-dev', 'appearance', 'purchases', 'suppliers',
        'supplier-invoices', 'purchase-orders', 'po-saved', 'promotions', 'repairs', 'reload',
        'hrm', 'internal-mail', 'branches', 'analytics', 'bank', 'ai-copilot'
    ],
    'Ultimate': [
        'dashboard', 'pos', 'products', 'stocks-view', 'stock', 'categories', 'settings',
        'reports', 'report-hub', 'customers', 'expenses', 'credit', 'income',
        'orders', 'quotations', 'quotation-history', 'web-orders', 'web-dev', 'appearance', 'purchases', 'suppliers',
        'supplier-invoices', 'purchase-orders', 'po-saved', 'promotions', 'repairs', 'reload',
        'hrm', 'internal-mail', 'branches', 'mrp', 'analytics', 'it-system', 'stores', 'bank', 'ai-copilot'
    ]
};

export function getCleanPlanName(planStr) {
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMec = !storeId || storeId === '1001' || storeId === 'mec-book-shop' || storeId === 'mec-pos-shop' || storeId === 'mec-pos' || storeId === 'master';
    if (isMec) return 'Ultimate';
    if (!planStr) return 'Ultimate';
    const lower = planStr.toLowerCase();
    if (lower.includes('ultimate') || lower.includes('enterprise') || lower.includes('managed')) return 'Ultimate';
    if (lower.includes('professional') || lower.includes('business')) return 'Professional';
    if (lower.includes('starter')) return 'Starter';
    if (lower.includes('pospro') || lower.includes('pos pro') || lower.includes('repair')) return 'POSPro';
    if (lower.includes('posstandard') || lower.includes('pos standard') || lower.includes('standard')) return 'POSStandard';
    if (lower.includes('poslite') || lower.includes('pos lite') || lower.includes('lite')) return 'POSLite';
    if (lower.includes('trial')) return 'Trial';
    return 'Ultimate';
}

window.PLAN_PERMISSIONS = PLAN_PERMISSIONS;
window.getCleanPlanName = getCleanPlanName;

window.toggleNavGroup = function(groupId) {
    const group = typeof groupId === 'string' ? document.getElementById(groupId) : groupId?.closest?.('.nav-group');
    if (!group) return;
    group.classList.toggle('collapsed');
};

window.updateNavLabelsVisibility = function() {
    document.querySelectorAll('.nav-group').forEach(group => {
        // Count tabs that are NOT hidden (display !== 'none')
        const allTabs = group.querySelectorAll('.nav-tab');
        const hasVisible = Array.from(allTabs).some(tab => tab.style.display !== 'none');
        group.style.display = hasVisible ? 'flex' : 'none';
    });
    document.querySelectorAll('.nav-label').forEach(label => {
        let hasVisibleChild = false;
        let sibling = label.nextElementSibling;
        while (sibling && !sibling.classList.contains('nav-label') && !sibling.classList.contains('nav-group')) {
            if (sibling.classList.contains('nav-tab')) {
                if (sibling.style.display !== 'none') {
                    hasVisibleChild = true;
                    break;
                }
            }
            sibling = sibling.nextElementSibling;
        }
        label.style.display = hasVisibleChild ? 'block' : 'none';
    });
};


window.initAuth = initAuth;

export function initAuth() {
    console.log("🔐 Initializing Auth Module...");

    // 0. System Initializers
    if (typeof initAutoBackup === 'function') initAutoBackup();

    // 1. Data Listeners
    const storeId = typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop';
    const isMaster = storeId === 'master';
    
    const empQ = isMaster ? employeesCol : query(employeesCol, where('storeId', '==', storeId));
    
    // Cache load
    loadOfflineCache('employees').then(cached => {
        if (cached && cached.length > 0) {
            window.allEmployees = cached;
            if (sessionStorage.getItem('isAdminLoggedIn')) {
                if (typeof window.renderAdminEmployeesUI === 'function') window.renderAdminEmployeesUI(cached);
                if (typeof window.populatePayrollStaffDropdown === 'function') window.populatePayrollStaffDropdown(cached);
                if (typeof window.syncAttendanceUI === 'function') window.syncAttendanceUI();
            }
        }
    });

    onSnapshot(empQ, (snapshot) => {
        const staff = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allEmployees = staff;
        saveOfflineCache('employees', staff);
        
        if (sessionStorage.getItem('isAdminLoggedIn')) {
            if (typeof window.renderAdminEmployeesUI === 'function') window.renderAdminEmployeesUI(staff);
            if (typeof window.populatePayrollStaffDropdown === 'function') window.populatePayrollStaffDropdown(staff);
            if (typeof window.populateMailRecipientDropdown === 'function') window.populateMailRecipientDropdown();
            if (typeof window.syncAttendanceUI === 'function') window.syncAttendanceUI();
            
            // Auto-update ID if the form is visible and we are not editing
            const hrmSection = document.getElementById('section-hrm');
            if (hrmSection && hrmSection.style.display !== 'none' && !window.editingEmployeeId) {
                if (typeof window.generateEmployeeID === 'function') window.generateEmployeeID(true);
            }
        }
    });

    const custQ = isMaster ? customersCol : query(customersCol, where('storeId', '==', storeId));
    
    loadOfflineCache('customers').then(cached => {
        if (cached && cached.length > 0) {
            window.allCustomers = cached;
        }
    });

    onSnapshot(custQ, (snapshot) => {
        const customers = snapshot.docs.map(doc => {
            const data = doc.data();
            const phone = data.phone || "";
            return { 
                ...data, 
                docId: doc.id,
                cleanPhone: phone.replace(/[\s-]/g, "")
            };
        });
        window.allCustomers = customers;
        saveOfflineCache('customers', customers);
    });

    const branchQ = isMaster ? branchesCol : query(branchesCol, where('storeId', '==', storeId));
    
    loadOfflineCache('branches').then(cached => {
        if (cached && cached.length > 0) {
            window.allBranches = cached;
            if (typeof window.populateTerminalBranchSelectors === 'function') {
                window.populateTerminalBranchSelectors();
            }
            if (typeof window.populateMailRecipientDropdown === 'function') {
                window.populateMailRecipientDropdown();
            }
        }
    });

    onSnapshot(branchQ, (snapshot) => {
        const branches = snapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        window.allBranches = branches;
        saveOfflineCache('branches', branches);
        if (typeof window.populateTerminalBranchSelectors === 'function') {
            window.populateTerminalBranchSelectors();
        }
        if (typeof window.populateMailRecipientDropdown === 'function') {
            window.populateMailRecipientDropdown();
        }
    });

    // 2. Setup Login Event Listeners
    const loginEmail = document.getElementById('login-email');
    const loginPass = document.getElementById('login-password');
    const loginBtn = document.getElementById('login-btn');

    if (loginBtn) {
        loginBtn.onclick = async (e) => {
            if (e) e.preventDefault();
            const rawEmail = loginEmail?.value || "";
            const userInput = rawEmail.trim().toLowerCase();
            const passInput = loginPass?.value || "";

            const isPlatformAdmin = (userInput === 'malinduec@gmail.com' && passInput === 'malindu123') || (userInput === 'mecposadmin@gmail.com' && passInput === 'mecpos123');
            const isMaster = (userInput === ADMIN_EMAIL && passInput === ADMIN_PASS) || isPlatformAdmin;

            if (isMaster) {
                sessionStorage.setItem('isAdminLoggedIn', 'true');
                if (userInput === ADMIN_EMAIL) {
                    sessionStorage.setItem('userRole', 'CEO_Admin');
                    sessionStorage.setItem('userDesignation', 'CEO / Founder');
                    sessionStorage.setItem('userName', 'Malindu Shamesh');
                    sessionStorage.setItem('userRegNo', 'EMP-001');
                    sessionStorage.setItem('userPhone', '0770658356');
                    sessionStorage.setItem('userBranchName', 'Horana (Main Branch)');
                } else {
                    sessionStorage.setItem('userRole', 'SuperAdmin');
                    sessionStorage.setItem('userDesignation', 'Super Administrator');
                    sessionStorage.setItem('userName', 'Super Admin');
                    sessionStorage.setItem('userRegNo', 'EMP-000');
                    sessionStorage.setItem('userPhone', '0770658356');
                    sessionStorage.setItem('userBranchName', 'Global HQ');
                }
                sessionStorage.setItem('userEmail', userInput);
                sessionStorage.setItem('userUsername', userInput);
                sessionStorage.setItem('userBranchId', 'Global');
                sessionStorage.setItem('userStoreId', 'mec-book-shop');
                const masterShiftLoginTime = new Date().toISOString();
                sessionStorage.setItem('mec_shift_login_time', masterShiftLoginTime);
                localStorage.setItem('mec_shift_login_time', masterShiftLoginTime);
                window.showAdminActions();
            } else {
                const staff = (window.allEmployees || []).find(e => 
                    (e.username?.toLowerCase() === userInput || e.email?.toLowerCase() === userInput) && 
                    e.password === passInput
                );

                if (staff && staff.role_access !== 'none') {
                    sessionStorage.setItem('isAdminLoggedIn', 'true');
                    sessionStorage.setItem('userRole', staff.role_access || 'Cashier');
                    sessionStorage.setItem('userDesignation', staff.role || staff.role_access || 'Cashier');
                    sessionStorage.setItem('userBranchId', staff.branchId || 'Global');
                    sessionStorage.setItem('userBranchName', (staff.branchId === 'Global' || staff.branchId === 'main') ? 'Horana (Main Branch)' : (staff.branchName || staff.branchId || 'Main Branch'));
                    sessionStorage.setItem('userStoreId', staff.storeId || 'mec-book-shop');
                    sessionStorage.setItem('userName', staff.name || 'Staff');
                    sessionStorage.setItem('userEmail', staff.email || userInput);
                    sessionStorage.setItem('userId', staff.docId || staff.id || staff.username || staff.email);
                    sessionStorage.setItem('userUsername', staff.username || userInput);
                    sessionStorage.setItem('userPhone', staff.phone || '');
                    sessionStorage.setItem('userRegNo', staff.regno || 'EMP-001');
                    localStorage.setItem('mec_logged_cashier_id', staff.docId || staff.id || staff.username || staff.email);
                    localStorage.setItem('mec_logged_cashier_name', staff.name);
                    const staffShiftLoginTime = new Date().toISOString();
                    sessionStorage.setItem('mec_shift_login_time', staffShiftLoginTime);
                    localStorage.setItem('mec_shift_login_time', staffShiftLoginTime);

                    // ── Staff Login Alert SMS to CEO ───────────────────────────
                    // Send an SMS to the CEO whenever any employee logs in.
                    // Uses the same SMSLenz dispatchSMS engine as the morning brief.
                    try {
                        const loginNow = new Date();
                        const loginTimeStr = loginNow.toLocaleTimeString('en-LK', { hour: '2-digit', minute: '2-digit', hour12: true });
                        const loginDateStr = loginNow.toLocaleDateString('sv-SE'); // YYYY-MM-DD
                        const staffName   = staff.name || 'Staff';
                        const staffRole   = staff.role || staff.role_access || 'Cashier';
                        const branchLabel = (staff.branchId === 'Global' || staff.branchId === 'main')
                            ? 'Horana (Main Branch)'
                            : (staff.branchName || staff.branchId || 'Main Branch');
                        const regNo       = staff.regno || 'N/A';

                        const loginSmsText =
`[MEC POS - STAFF LOGIN ALERT]
Date: ${loginDateStr}
Time: ${loginTimeStr}

Employee: ${staffName}
Reg No : ${regNo}
Role   : ${staffRole}
Branch : ${branchLabel}

MEC POS System`;

                        // Resolve CEO phone: use aiCopilot config if available, else fallback
                        const ceoPhone = (
                            (window.copilotConfig && window.copilotConfig.ceoPhone) ||
                            localStorage.getItem('ai_ceo_whatsapp_phone') ||
                            '0770658356'
                        ).replace(/[^0-9]/g, '');

                        if (typeof window.dispatchSMS === 'function' && ceoPhone) {
                            window.dispatchSMS(ceoPhone, loginSmsText, { silent: true });
                        }
                    } catch (smsErr) {
                        console.warn('[Login Alert SMS] Failed to send staff login notification:', smsErr);
                    }
                    // ────────────────────────────────────────────────────────────

                    window.showAdminActions();
                } else {
                    window.showToast("❌ Invalid Credentials", "error");
                }
            }
        };

        const handleEnter = (e) => { if (e.key === 'Enter') loginBtn.click(); };
        loginEmail?.addEventListener('keydown', handleEnter);
        loginPass?.addEventListener('keydown', handleEnter);
    }

    // 3. Logout & POS Auth Modal
    let isLoggingOut = false;
    window.handleLogout = async () => {
        if (isLoggingOut) return;
        isLoggingOut = true;

        try {
            // Run Firebase signout asynchronously — don't await to avoid freezing on network lag
            signOut(auth).catch(e => console.warn("Firebase signout error", e));
        } catch(e) {
            console.warn("Firebase signout trigger error", e);
        }

        // Clear session (but keep localStorage for Remember Me preference)
        sessionStorage.clear();
        localStorage.removeItem('mec_shift_login_time');

        // ── C# WebView2 Desktop App ──
        // ONLY send postMessage to C# — let C# handle the navigation.
        // Do NOT also do window.location.href here, as that causes a dual-redirect
        // race condition where both C# Navigate() and JS redirect fire simultaneously.
        if (window.chrome?.webview) {
            try {
                window.chrome.webview.postMessage("logout");
                window.chrome.webview.postMessage({ type: 'logout' });
            } catch(err) {
                console.error("WebView postMessage error:", err);
            }
            setTimeout(() => {
                isLoggingOut = false;
                const isLocal = window.location.protocol === 'file:';
                window.location.href = (isLocal ? '' : '/') + 'merchant-login.html?logout=1&t=' + Date.now();
            }, 100);
            return;
        }

        // ── Electron Desktop App ──
        if (window.electron?.logout) {
            setTimeout(() => {
                isLoggingOut = false;
                window.electron.logout();
            }, 150);
            return;
        }

        // ── Browser / Web Mode ──
        // Only browsers use window.location.href redirect
        setTimeout(() => {
            isLoggingOut = false;
            const isLocal = window.location.protocol === 'file:';
            window.location.href = (isLocal ? '' : '/') + 'merchant-login.html?logout=1&t=' + Date.now();
        }, 150);
    };

    // Bind logout event listeners to all logout buttons
    document.querySelectorAll('.logout-item, .logout-btn, #logout-btn-real, #logout-btn-sidebar').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            window.handleLogout();
        });
    });

    const posAuthForm = document.getElementById('pos-auth-form');
    posAuthForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('pos-auth-email').value;
        const pass = document.getElementById('pos-auth-password').value;
        try {
            await signInWithEmailAndPassword(auth, email, pass);
            window.location.reload();
        } catch (err) {
            window.showToast("❌ Invalid Credentials", "error");
        }
    });

    // 4. Navigation Initializers
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.onclick = () => {
            const tabId = btn.getAttribute('data-tab');
            if (tabId) window.showTab(tabId);
        };
    });

    // Handle impersonation URL params from Super Admin (direct login into admin.html without landing on merchant-login.html)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('impersonate') === '1') {
        const impStore = urlParams.get('store') || 'mec-book-shop';
        const impRole = urlParams.get('role') || 'CEO_Admin';
        const impEmail = urlParams.get('email') || ('info@' + impStore + '.com');
        const impName = urlParams.get('name') || 'Store Admin';

        sessionStorage.setItem('isAdminLoggedIn', 'true');
        sessionStorage.setItem('userRole', impRole);
        sessionStorage.setItem('userEmail', impEmail);
        sessionStorage.setItem('userName', impName);
        sessionStorage.setItem('userBranchId', 'Global');
        sessionStorage.setItem('userStoreId', impStore);
        localStorage.setItem('mecpos_last_store_id', impStore);
        const impShiftLoginTime = new Date().toISOString();
        sessionStorage.setItem('mec_shift_login_time', impShiftLoginTime);
        localStorage.setItem('mec_shift_login_time', impShiftLoginTime);
    }

    if (sessionStorage.getItem('isAdminLoggedIn') === 'true') {
        window.showAdminActions();
    } else {
        window.hideAdminActions();
    }
}

window.toggleLoginPassword = () => {
    const passInput = document.getElementById('login-password');
    if (passInput) passInput.type = (passInput.type === 'password') ? 'text' : 'password';
};

window.showAdminActions = () => {
    // Ensure shift login time is initialized if session exists
    if (!sessionStorage.getItem('mec_shift_login_time')) {
        const cachedTime = localStorage.getItem('mec_shift_login_time') || new Date().toISOString();
        sessionStorage.setItem('mec_shift_login_time', cachedTime);
        localStorage.setItem('mec_shift_login_time', cachedTime);
    }

    // [FIX v3.17.20] Enter immersive fullscreen on login for clean app experience
    // Use setAppFullscreen() — NOT send('set-app-fullscreen') which was never mapped in the preload bridge
    if (window.electron?.setAppFullscreen) {
        window.electron.setAppFullscreen(true);
    } else if (window.chrome?.webview) {
        window.chrome.webview.postMessage({ type: 'setAppFullscreen', flag: true });
    }

    const loginSection = document.getElementById('login-section');
    const adminActions = document.getElementById('admin-actions');
    if (loginSection) loginSection.style.display = 'none';
    if (adminActions) adminActions.style.display = 'block';
    
    // Explicitly make profile block visible
    const profileTrigger = document.getElementById('profile-trigger');
    if(profileTrigger) profileTrigger.style.display = 'block';
    
    // Attempt UI update, wait for system.js if needed
    const updateUserUI = () => {
        if (window.updateUserDisplay) window.updateUserDisplay();
        else setTimeout(updateUserUI, 100);
    };
    updateUserUI();

    const currentRole = sessionStorage.getItem('userRole') || 'Admin';

    const roleTabs = ROLE_PERMISSIONS[currentRole] || [];
    let storeInfo = window.storeInfo;
    if (!storeInfo || !storeInfo.plan) {
        try {
            if (window.initialPlanConfig && window.initialPlanConfig.storeInfo) {
                storeInfo = window.initialPlanConfig.storeInfo;
                if (window.initialPlanConfig.systemConfig) {
                    window.systemConfig = window.initialPlanConfig.systemConfig;
                }
            } else {
                const cached = localStorage.getItem('mecpos_plan_cache');
                if (cached) {
                    storeInfo = JSON.parse(cached);
                } else {
                    storeInfo = {};
                }
            }
        } catch (e) {
            storeInfo = {};
        }
    }
    
    const cleanPlan = getCleanPlanName(storeInfo.plan);
    const planTabs = PLAN_PERMISSIONS[cleanPlan] || PLAN_PERMISSIONS['Trial'];

    // Intersect role and plan permissions (MEC Book Shop / Ultimate gets ALL role tabs)
    const allowedTabs = (cleanPlan === 'Ultimate') ? roleTabs : roleTabs.filter(tab => planTabs.includes(tab));
    window.allowedTabs = allowedTabs;
    
    // Save package plan info locally so C# native wrapper and web offline cache preserve it
    try {
        localStorage.setItem('mecpos_plan_cache', JSON.stringify({ plan: cleanPlan, storeId: typeof window.getStoreId === 'function' ? window.getStoreId() : 'mec-book-shop' }));
    } catch(e) {} 
    
    document.querySelectorAll('.nav-tab').forEach(btn => {
        const tabId = btn.id.replace('tab-', '');
        btn.style.display = allowedTabs.includes(tabId) ? 'flex' : 'none';
    });

    if (typeof window.updateNavLabelsVisibility === 'function') {
        window.updateNavLabelsVisibility();
    }
    if (typeof window.checkCashHistoryNavVisibility === 'function') {
        window.checkCashHistoryNavVisibility();
    }
    if (typeof window.applyModuleVisibility === 'function' && window.systemConfig?.modules) {
        window.applyModuleVisibility(window.systemConfig.modules);
    }

    // Load favorites from local cache or role defaults for instant UI rendering
    if (typeof window.renderFavoritesSidebar === 'function') {
        try {
            const sysCache = localStorage.getItem('mecpos_system_config_cache');
            let userFavs = null;
            if (sysCache) {
                const sysData = JSON.parse(sysCache);
                if (sysData && Array.isArray(sysData.favorites) && sysData.favorites.length > 0) {
                    userFavs = sysData.favorites;
                }
            }
            if (userFavs && userFavs.length > 0) {
                window.renderFavoritesSidebar(userFavs);
            } else {
                // Supply role-tailored default favorites
                const roleFavs = ROLE_DEFAULT_FAVORITES[currentRole] || ['pos', 'orders', 'products', 'stock', 'stocks-view'];
                window.renderFavoritesSidebar(roleFavs);
            }
        } catch (e) {
            const roleFavs = ROLE_DEFAULT_FAVORITES[currentRole] || ['pos', 'orders', 'products', 'stock', 'stocks-view'];
            window.renderFavoritesSidebar(roleFavs);
        }
    }

    // Role-tailored initial tab selection
    const preferredTab = ROLE_STARTUP_TABS[currentRole];
    let defaultTab = (preferredTab && allowedTabs.includes(preferredTab)) ? preferredTab : null;

    if (!defaultTab) {
        if (['SuperAdmin', 'CEO_Admin', 'Admin'].includes(currentRole) && allowedTabs.includes('dashboard')) {
            defaultTab = 'dashboard';
        } else if (allowedTabs.includes('pos')) {
            defaultTab = 'pos';
        } else if (allowedTabs.includes('orders')) {
            defaultTab = 'orders';
        } else if (allowedTabs.includes('web-orders')) {
            defaultTab = 'web-orders';
        } else {
            defaultTab = allowedTabs[0] || 'pos';
        }
    }

    // If current active tab is not allowed or not set, switch to role startup tab immediately
    if (window.currentActiveTab && !allowedTabs.includes(window.currentActiveTab)) {
        if (defaultTab) {
            window.showTab(defaultTab);
        }
    } else if (!window.currentActiveTab && defaultTab) {
        // Immediate showTab prevents Executive Dashboard from flashing for cashiers/operational staff
        window.showTab(defaultTab);
        // Short safety fallback to ensure DOM & listeners are fully initialized
        setTimeout(() => {
            if (window.currentActiveTab !== defaultTab) {
                window.showTab(defaultTab);
            }
        }, 80);
    }

    // Trigger Autonomous Morning CEO Brief SMS via SMSLenz upon morning login
    // NOTE: 60-second delay ensures Firestore data (allOrders, allProducts, allCustomers)
    // is fully loaded before report generation — prevents wrong/zero sales in morning brief.
    const triggerMorningSMS = (retries = 0) => {
        if (typeof window.checkAndDispatchCeoMorningSMS === 'function') {
            window.checkAndDispatchCeoMorningSMS();
        } else if (retries < 15) {
            setTimeout(() => triggerMorningSMS(retries + 1), 5000);
        }
    };
    setTimeout(() => triggerMorningSMS(), 60000); // 60 seconds: wait for Firestore data to load
};

window.hideAdminActions = () => {
    const adminActions = document.getElementById('admin-actions');
    if (adminActions) adminActions.style.display = 'none';
    
    // Redirect to merchant-login.html instead of showing the deprecated old login screen on admin.html
    // This completely eliminates the flash of the old login screen on app launch
    const path = window.location.pathname.toLowerCase();
    const isLoginPage = path.includes('merchant-login.html') || path.includes('super-admin.html') || window.location.href.toLowerCase().includes('merchant-login.html') || window.location.href.toLowerCase().includes('super-admin.html');
    
    if (!isLoginPage) {
        const isLocal = window.location.protocol === 'file:';
        window.location.href = (isLocal ? '' : '/') + 'merchant-login.html';
    } else {
        const loginSection = document.getElementById('login-section');
        if (loginSection) loginSection.style.display = 'block';
    }
};

window.showTab = (tabId) => {
    try {
        if (window.allowedTabs && !window.allowedTabs.includes(tabId)) {
            console.warn(`Tab ${tabId} is not allowed under your plan or role.`);
            return;
        }
        if (tabId === 'pos' && window.allowedTabs && !window.allowedTabs.includes('pos')) {
            document.getElementById('pos-auth-modal').style.display = 'block';
            return; 
        }
        window.currentActiveTab = tabId;
        window.quickStockAddMode = false; // [v3.12.16] Prevent state leakage
        window.quickStockAddVariantId = null;
        
        // Hide all tabs and remove active class
        document.querySelectorAll('.admin-tab-content').forEach(tab => {
            tab.classList.remove('tab-active');
            tab.style.setProperty('display', 'none', 'important');
        });
        document.querySelectorAll('.nav-tab').forEach(link => link.classList.remove('active'));
        
        const activeTab = document.getElementById(`section-${tabId}`);
        if (activeTab) {
            activeTab.classList.add('tab-active');
            activeTab.style.removeProperty('display');
            activeTab.style.setProperty('display', 'flex', 'important');
        }

        // Close floating drawer sidebar automatically upon choosing an item
        if (typeof window.closeDashboardSidebar === 'function') {
            window.closeDashboardSidebar();
        }
        
        // Highlight all matching navigation tabs (main buttons and favorite buttons)
        document.querySelectorAll('.nav-tab').forEach(link => {
            const matchesId = link.id === `tab-${tabId}`;
            const matchesData = link.getAttribute('data-tab') === tabId;
            const matchesOnclick = link.getAttribute('onclick')?.includes(`'${tabId}'`) || link.getAttribute('onclick')?.includes(`"${tabId}"`);
            if (matchesId || matchesData || matchesOnclick) {
                link.classList.add('active');
                // Only auto-expand parent group on explicit user navigation, not on initial page load
                if (window._navAutoExpand) {
                    const parentGroup = link.closest('.nav-group');
                    if (parentGroup) {
                        parentGroup.classList.remove('collapsed');
                    }
                }
            }
        });

        if (tabId === 'quotations') {
            if (window.QuotationManager?.initQuotationManager) {
                window.QuotationManager.initQuotationManager();
            }
        }
        if (tabId === 'quotation-history') {
            if (window.QuotationManager?.loadQuotationsList) {
                window.QuotationManager.loadQuotationsList();
            }
        }

        if (tabId === 'pos') {
            if (typeof window.enterPOSFullscreen === 'function') window.enterPOSFullscreen();
            if (typeof window.restorePOSDraftsUI === 'function') window.restorePOSDraftsUI();
            if (window.renderPOSPendingShopOrders) window.renderPOSPendingShopOrders(window.allOrders || []);
            if (window.handlePOSSearch) window.handlePOSSearch('');
            setTimeout(() => document.getElementById('pos-cust-phone')?.focus(), 300);
            
            // Auto-Scanner activation
            if (localStorage.getItem('mec_pos_auto_scan') === 'true') {
                if (typeof window.startInlineAutoScan === 'function') window.startInlineAutoScan();
            }
        } else {
            document.body.classList.remove('pos-fullscreen-mode');
            // Stop Auto-Scanner
            if (typeof window.stopInlineAutoScan === 'function') window.stopInlineAutoScan();
        }

        if (tabId === 'stock') {
            if (typeof window.enterStockFullscreen === 'function') window.enterStockFullscreen();
            if (typeof window.initPOForm === 'function') window.initPOForm();
        } else {
            document.body.classList.remove('stock-fullscreen-mode');
        }

        if (tabId === 'purchase-orders') {
            if (typeof window.initSupplyChain === 'function') window.initSupplyChain();
        }

        // [FIX] Trigger module-specific renders on tab switch
        if (tabId === 'promotions') {
            if (typeof window.showSubTab === 'function') {
                window.showSubTab('promotions', 'coupons');
            }
            if (window.renderPromotionsUI) {
                window.renderPromotionsUI();
            }
        }
        if (tabId === 'repairs' && window.renderRepairJobsUI && window.allRepairJobs) {
            window.renderRepairJobsUI(window.allRepairJobs);
        }
        if (tabId === 'orders' && window.applyOrderFilters) {
            window.applyOrderFilters();
        }
        if (tabId === 'web-orders' && window.renderWebOrdersPage) {
            window.renderWebOrdersPage();
        }
        if (tabId === 'dashboard') {
            if (typeof window.renderExecutiveDashboard === 'function') {
                window.renderExecutiveDashboard();
            }
        }
        if (tabId === 'hrm') {
            if (typeof window.showHRMSubTab === 'function') {
                window.showHRMSubTab('employees');
            } else {
                // Fallback: show employees sub-tab directly
                document.querySelectorAll('.hrm-sub-content').forEach(c => c.style.display = 'none');
                const empSub = document.getElementById('hrm-sub-employees');
                if (empSub) empSub.style.display = 'block';
            }
            if (window.syncAttendanceUI) window.syncAttendanceUI();
        }
        if (tabId === 'reports') {
            const currentRole = sessionStorage.getItem('userRole') || 'Admin';
            if (currentRole === 'Cashier') {
                // Cashier should only see Cash Balancing
                document.querySelectorAll('.pro-report-nav .pro-nav-btn').forEach(btn => {
                    const clickAttr = btn.getAttribute('onclick') || "";
                    if (clickAttr.includes('cash-balancing')) {
                        btn.style.display = 'block';
                    } else {
                        btn.style.display = 'none';
                    }
                });
                setTimeout(() => {
                    window.switchReportView('cash-balancing');
                }, 100);
            } else {
                // Show all buttons for other roles
                document.querySelectorAll('.pro-report-nav .pro-nav-btn').forEach(btn => {
                    btn.style.display = 'block';
                });
                if (window.generateReportsOld && window.allOrders) {
                    window.generateReportsOld(window.allOrders);
                }
            }
        }
        if (tabId === 'analytics' && window.generateCurrentReport && window.allOrders) {
            window.generateCurrentReport();
        }
        if (tabId === 'report-hub' && window.initReportHubUI) {
            window.initReportHubUI();
        }
        if (tabId === 'credit' && window.renderCreditLedgerUI) {
            window.renderCreditLedgerUI();
        }
        if (tabId === 'stocks-view' && window.renderStocksUI) {
            window.renderStocksUI();
        }
        if (tabId === 'reload') {
            // [FIX] Ensure first sub-tab is visible on entry
            if (typeof window.showSubTab === 'function') window.showSubTab('reload', 'quick');
            if (window.loadReloadHistory) window.loadReloadHistory();
        }
        if (tabId === 'po-saved' && window.renderPOSavedOrders) {
            window.renderPOSavedOrders();
        }
        if (tabId === 'web-dev' && window.loadWebSettings) {
            window.loadWebSettings();
        }
        if (tabId === 'branches') {
            // [FIX] Re-render branches list when tab opens
            if (typeof window.renderBranchesUI === 'function') {
                window.renderBranchesUI(window.allBranches || []);
            }
        }
        if (tabId === 'internal-mail') {
            // [FIX] Switch HRM to internal-mail sub-tab
            if (typeof window.showHRMSubTab === 'function') {
                window.showHRMSubTab('internal-mail');
            }
        }
        if (tabId === 'it-system' && window.renderITSystemLogs) {
            window.renderITSystemLogs();
        }
        if (tabId === 'ai-copilot' && window.initAICopilot) {
            window.initAICopilot();
        }
        if (tabId === 'settings') {
            // [FIX] showTab already sets display:flex on section — just ensure sub-tab shows
            if (typeof window.showSettingsSubTab === 'function') {
                window.showSettingsSubTab('general');
            } else {
                document.querySelectorAll('.settings-view').forEach(view => {
                    view.style.setProperty('display', 'none', 'important');
                });
                const genSub = document.getElementById('set-sub-general');
                if (genSub) genSub.style.setProperty('display', 'block', 'important');
                const genBtn = document.getElementById('btn-set-general');
                if (genBtn) genBtn.classList.add('active');
            }
            // [FIX] Load live settings from Firebase when settings tab opens
            if (typeof window.loadSystemSettings === 'function') {
                window.loadSystemSettings();
            }
        }

    const titleEl = document.getElementById('active-tab-title');
    const subEl = document.getElementById('active-tab-subtitle');
    const titles = {
        'dashboard': ['Executive Dashboard', 'Real-time store performance & executive analytics'],
        'pos': ['POS Terminal', 'Direct store sales & billing'],
        'orders': ['Order Management', 'Process web and app orders'],
        'web-orders': ['Web Store Orders', 'Manage online pickups and deliveries'],
        'ai-copilot': ['AI Business Copilot', 'Fully autonomous store agent & analytics engine'],
        'products': ['Inventory Master', 'Manage your catalog and variants'],
        'stocks-view': ['Current Stocks', 'Real-time batch-wise inventory status'],
        'stock': ['Stock Entry', 'Update inventory from supplier invoices'],
        'categories': ['Category Settings', 'Manage product groups and labels'],
        'reports': ['Financial Reports', 'View sales, profit and performance stats'],
        'report-hub': ['Report Download Center', 'Centralized export hub for advanced auditing'],
        'analytics': ['Advanced Analytics', 'Professional ERP-style reporting dashboard'],
        'expenses': ['Expense Management', 'Track your business costs'],
        'purchases': ['Purchase History', 'Track inventory buys and costs'],
        'suppliers': ['Supplier Database', 'Manage your wholesale partners'],
        'supplier-invoices': ['Supplier Invoices', 'Track and post bulk stock from supplier documents'],
        'purchase-orders': ['Purchase Order Generator', 'Create and manage orders for suppliers'],
        'po-saved': ['Saved Purchase Orders', 'Review and print historical procurement records'],
        'promotions': ['Promotions & Offers', 'Manage store discounts and marketing deals'],
        'income': ['Extra Income', 'Track non-sales revenue sources'],
        'customers': ['Customer Relations', 'Manage your loyal customer database'],
        'repairs': ['Repair Orders', 'Manage intake and delivery of tech repairs'],
        'hrm': ['HRM Management', 'Manage staff, attendance and payroll'],
        'branches': ['Branch Locations', 'Manage multi-store access & data'],
        'it-system': ['IT System & Logs', 'Monitor system security and activity'],
        'stores': ['Managed Merchants', 'Provision and monitor SaaS client stores'],
        'web-dev': ['Website Studio', 'Develop and design your online storefront'],
        'credit': ['Credit Ledger (Naya Bill)', 'Track outstanding balances and customer credit history'],
        'mrp': ['Manufacturing (MRP)', 'Plan production and manage Bill of Materials'],
        'settings': ['System Settings', 'Configure hardware, modules and global preferences'],
        'reload': ['Reload Terminal', 'Manage mobile top-ups and track credit reloads']
    };
        if (titles[tabId] && titleEl && subEl) {
            titleEl.innerText = titles[tabId][0];
            subEl.innerText = titles[tabId][1];
        }
    } catch (err) {
        console.error("FATAL TAB ROUTING ERROR:", err);
        alert("🚨 TAB ROUTING ERROR (" + tabId + "):\n\nMessage: " + err.message + "\n\nStack:\n" + err.stack);
    }
};

window.showSubTab = (section, tabId) => {
    document.querySelectorAll(`#section-${section} .sub-tab-view`).forEach(view => view.style.display = 'none');
    document.querySelectorAll(`.sub-tab[data-section="${section}"]`).forEach(btn => btn.classList.remove('active'));
    const targetView = document.getElementById(`${section}-${tabId}-view`);
    if (targetView) targetView.style.display = 'block';
    const targetBtn = document.querySelector(`.sub-tab[data-section="${section}"][data-tab="${tabId}"]`);
    if (targetBtn) targetBtn.classList.add('active');

    // [v3.9.64] Auto-generate Customer ID if switching to the Add tab
    if (section === 'customers' && tabId === 'add' && typeof window.generateCustomerID === 'function') {
        window.generateCustomerID();
    }
    // [v3.9.64] Force re-render of list if switching to list
    if (section === 'customers' && tabId === 'list' && typeof window.renderCustomersUI === 'function') {
        window.renderCustomersUI(window.allCustomers || []);
    }
    // [NEW] Auto-open Dialog portal popup on tab switch
    if (section === 'reload' && tabId === 'dialog' && typeof window.openDialogPortalPopup === 'function') {
        window.openDialogPortalPopup();
    }
    // [NEW] Force history loading and rendering when switching to recent history tab
    if (section === 'reload' && tabId === 'history' && typeof window.loadReloadHistory === 'function') {
        window.loadReloadHistory();
    }
};


