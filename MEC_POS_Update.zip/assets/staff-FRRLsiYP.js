import{q as S,c as h,d as w,w as I,g as D,l as P,j as _,o as v,u as O,b as H,a as B,s as $}from"./firebase-Bn3UcnFE.js";/* empty css              */window.staffLogin=async()=>{var l;const e=document.getElementById("staff-phone").value.trim(),n=document.getElementById("staff-pin").value.trim();if(!e||!n)return c("Please enter both Phone and PIN");const t=document.getElementById("section-login"),o=document.getElementById("login-loading"),a=document.getElementById("section-dashboard");t.style.display="none",o.style.display="block";try{const i=S(h(w,"employees"),I("phone","==",e)),m=await D(i);if(m.empty)throw new Error("Mobile number not registered.");const d=m.docs[0].data();if(d.docId=m.docs[0].id,n===d.regno||n===d.password){window.currentStaff=d;try{sessionStorage.setItem("mec_staff_session",JSON.stringify(d)),localStorage.setItem("mec_staff_session",JSON.stringify(d))}catch{}C(d),o.style.display="none",a.style.display="block",(l=document.getElementById("section-login"))==null||l.remove()}else throw new Error("Invalid Security PIN.")}catch(i){c(i.message),o.style.display="none",t.style.display="block"}};window.staffLogout=()=>{try{sessionStorage.removeItem("mec_staff_session"),localStorage.removeItem("mec_staff_session")}catch{}window.location.reload()};function R(){try{const e=sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session");if(e){const n=JSON.parse(e);if(n&&(n.docId||n.phone)){window.currentStaff=n;const t=document.getElementById("section-login"),o=document.getElementById("login-loading"),a=document.getElementById("section-dashboard");t&&a&&(t.style.display="none",o&&(o.style.display="none"),a.style.display="block",C(n))}}}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",R):R();function C(e){document.getElementById("disp-name").innerText=e.name,document.getElementById("disp-role").innerText=e.role,document.getElementById("disp-avatar").innerText=e.name.charAt(0).toUpperCase();const n=S(h(w,"payroll"),I("empId","==",e.docId),_("timestamp","desc"),P(1));v(n,l=>{if(!l.empty){const i=l.docs[0].data();document.getElementById("disp-salary").innerText=`LKR ${parseFloat(i.amount).toLocaleString()}`,window.lastPaySlip=i}});const t=new Date,o=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}`,a=S(h(w,"attendance"),I("empId","==",e.docId));v(a,l=>{const i=l.docs.map(d=>d.data()),m=i.filter(d=>d.date.startsWith(o)&&d.status==="Present");document.getElementById("disp-attendance").innerText=`${m.length} Days`,window.myAttendanceRecords=i}),q(e)}let T=!0;const x=new Set;function j(){try{const e=new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");e.volume=.8;const n=e.play();n!==void 0&&n.catch(()=>{try{const t=new(window.AudioContext||window.webkitAudioContext);t.state==="suspended"&&t.resume();const o=t.createOscillator(),a=t.createGain();o.type="sine",o.frequency.setValueAtTime(587.33,t.currentTime),o.frequency.setValueAtTime(880,t.currentTime+.1),a.gain.setValueAtTime(.25,t.currentTime),a.gain.exponentialRampToValueAtTime(.001,t.currentTime+.45),o.connect(a),a.connect(t.destination),o.start(),o.stop(t.currentTime+.5)}catch{}})}catch{}}function q(e){const n=e.storeId||"mec-book-shop",t=e.docId||e.regno||e.email,o=e.role||"Staff",a=e.branchId||"Global",l=S(h(w,"internal_mails"),I("storeId","==",n));v(l,i=>{let m=i.docs.map(r=>({docId:r.id,...r.data()}));m.sort((r,s)=>{var b,M;const p=(b=r.timestamp)!=null&&b.seconds?r.timestamp.seconds*1e3:new Date(r.timestamp||0).getTime()||0;return((M=s.timestamp)!=null&&M.seconds?s.timestamp.seconds*1e3:new Date(s.timestamp||0).getTime()||0)-p});const d=m.filter(r=>{const s=r.recipientId||"ALL";return!!(s==="ALL"||s===t||s===e.regno||s===e.email||s===e.phone||s.startsWith("BRANCH_")&&(s.replace("BRANCH_","")===a||s.replace("BRANCH_","")===e.branchName)||s.startsWith("ROLE_")&&s.replace("ROLE_","").toLowerCase()===o.toLowerCase()||s==="CASHIERS"&&o.toLowerCase().includes("cashier")||s==="INVENTORY"&&(o.toLowerCase().includes("inventory")||o.toLowerCase().includes("stock"))||s==="TECH"&&(o.toLowerCase().includes("tech")||o.toLowerCase().includes("repair"))||s==="HR_ONLY"&&(o.toLowerCase().includes("hr")||o.toLowerCase().includes("admin")||o.toLowerCase().includes("manager")))});if(T)d.forEach(r=>x.add(r.docId)),T=!1;else{const r=d.filter(s=>!x.has(s.docId));r.length>0&&r.forEach(s=>{x.add(s.docId),j(),c(`📩 New Notice from ${s.senderName||"HR"}: ${s.subject||"Staff Message"}`)})}window.myStaffMails=d;const y=d.filter(r=>!r.isRead).length,f=document.getElementById("staff-unread-badge");f&&(y>0?(f.innerText=y,f.style.display="inline-block"):f.style.display="none"),N(d)},i=>{console.warn("Staff mail snapshot error:",i)})}function N(e){const n=document.getElementById("staff-inbox-list");if(n){if(!e||e.length===0){n.innerHTML='<div style="text-align: center; color: #64748b; padding: 2.5rem;">📭 No messages or notices yet.</div>';return}n.innerHTML=e.map(t=>{const o=t.timestamp?new Date(t.timestamp.seconds*1e3).toLocaleString([],{dateStyle:"short",timeStyle:"short"}):"Just now",a=t.priority==="urgent",l=!!(t.attachment&&t.attachment.url),i=t.isRead?"":'<span style="width:8px; height:8px; border-radius:50%; background:#38bdf8; display:inline-block; margin-right:6px;"></span>',m=a?'<span style="color:#ef4444; font-weight:800; font-size:0.7rem;">🚨 URGENT</span>':"";return`
            <div onclick="window.readStaffMailDetail('${t.docId}')" style="background: ${t.isRead?"rgba(255,255,255,0.03)":"rgba(56,189,248,0.08)"}; border: 1px solid ${t.isRead?"rgba(255,255,255,0.06)":"rgba(56,189,248,0.3)"}; padding: 12px 14px; border-radius: 14px; cursor: pointer; transition: background 0.2s;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="display:flex; align-items:center;">
                        ${i}
                        <span style="font-weight:700; color:#f8fafc; font-size:0.85rem;">${t.senderName||"HR Management"}</span>
                    </div>
                    <span style="font-size:0.7rem; color:#94a3b8;">${o}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:600; color:#38bdf8; font-size:0.82rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:280px;">${t.subject||"No Subject"}</div>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${l?'<span title="Has Attachment" style="font-size:0.8rem;">📎</span>':""}
                        ${m}
                    </div>
                </div>
            </div>
        `}).join("")}}window.openStaffInboxModal=()=>{document.getElementById("staff-inbox-modal").style.display="flex",window.myStaffMails&&N(window.myStaffMails)};window.readStaffMailDetail=async e=>{const n=(window.myStaffMails||[]).find(a=>a.docId===e);if(!n)return;if(!n.isRead)try{await O(H(w,"internal_mails",e),{isRead:!0}),n.isRead=!0}catch{}document.getElementById("staff-mail-view-subject").innerText=n.subject||"No Subject",document.getElementById("staff-mail-view-sender").innerText=`${n.senderName||"HR Management"} (${n.senderEmail||"System"})`,document.getElementById("staff-mail-view-date").innerText=n.timestamp?new Date(n.timestamp.seconds*1e3).toLocaleString():"Just now",document.getElementById("staff-mail-view-body").innerText=n.body||"";const t=document.getElementById("staff-mail-view-badge");t&&(n.priority==="urgent"?(t.innerText="🚨 Urgent Notice",t.style.background="rgba(239,68,68,0.2)",t.style.color="#ef4444"):n.priority==="confidential"?(t.innerText="🔒 Confidential",t.style.background="rgba(168,85,247,0.2)",t.style.color="#c084fc"):(t.innerText="✉️ Staff Notice",t.style.background="rgba(56,189,248,0.15)",t.style.color="#38bdf8"));const o=document.getElementById("staff-mail-view-attachment");if(o)if(n.attachment&&n.attachment.url){const a=n.attachment.type&&n.attachment.type.startsWith("image/");let l=`
                <div style="background: rgba(0,0,0,0.5); padding: 10px; border-radius: 12px; border: 1px solid rgba(56,189,248,0.2); display:flex; flex-direction:column; gap:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-size:0.8rem; color:#38bdf8; font-weight:700;">📎 Attachment: ${n.attachment.name||"File"}</span>
                        <a href="${n.attachment.url}" download="${n.attachment.name||"download"}" class="btn-login" style="width:auto; padding:5px 12px; font-size:0.75rem; text-decoration:none; display:inline-block;">⬇️ Download</a>
                    </div>
            `;a&&(l+=`<img src="${n.attachment.url}" style="max-width:100%; max-height:180px; object-fit:contain; border-radius:8px; margin-top:6px;" />`),l+="</div>",o.innerHTML=l,o.style.display="block"}else o.innerHTML="",o.style.display="none";document.getElementById("staff-read-mail-modal").style.display="flex"};function c(e){const n=document.getElementById("toast");n.innerText=e,n.style.display="block",setTimeout(()=>n.style.display="none",3e3)}const F=(e,n)=>{const t=new Blob([e],{type:"text/plain"}),o=window.URL.createObjectURL(t),a=document.createElement("a");a.href=o,a.download=n,a.click(),window.URL.revokeObjectURL(o)};window.downloadMySlip=()=>{var t;if(!window.lastPaySlip)return c("No salary records found.");const e=window.lastPaySlip,n=`
------------------------------------------
        MEC BOOK SHOP - PAY SLIP       
------------------------------------------
Employee: ${window.currentStaff.name}
Role:     ${window.currentStaff.role}
ID:       ${window.currentStaff.regno||"-"}
------------------------------------------
Month:    ${e.month}
Amount:   LKR ${parseFloat(e.amount).toLocaleString()}
Note:     ${e.note||"Regular Salary"}
Date:     ${e.date||new Date(((t=e.timestamp)==null?void 0:t.seconds)*1e3).toLocaleDateString()}
------------------------------------------
Generated by MEC Staff Portal
    `;F(n,`payslip_${e.month}.txt`),c("📥 Payslip downloaded!")};window.viewMyAttendance=()=>{if(!window.myAttendanceRecords||window.myAttendanceRecords.length===0)return c("No attendance records found.");const e=window.currentStaff,n=[...window.myAttendanceRecords].sort((a,l)=>l.date.localeCompare(a.date)),t=`
        <html>
        <head>
            <title>Attendance Report - ${e.name}</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
                .header { text-align: center; margin-bottom: 40px; border-bottom: 2px solid #38bdf8; padding-bottom: 20px; }
                .header h1 { margin: 0; color: #1e293b; text-transform: uppercase; letter-spacing: 2px; }
                .info { display: flex; justify-content: space-between; margin-bottom: 30px; font-size: 0.9rem; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th { background: #38bdf8; color: white; padding: 12px; text-align: left; text-transform: uppercase; font-size: 0.8rem; }
                td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
                tr:nth-child(even) { background: #f8fafc; }
                .status-present { color: #10b981; font-weight: bold; }
                .status-absent { color: #ef4444; font-weight: bold; }
                .status-leave { color: #f59e0b; font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>MEC BOOK SHOP</h1>
                <p>Official Attendance Report</p>
            </div>
            <div class="info">
                <div>
                    <strong>Staff Name:</strong> ${e.name}<br>
                    <strong>Role:</strong> ${e.role}<br>
                    <strong>Employee ID:</strong> ${e.regno||"-"}
                </div>
                <div style="text-align: right;">
                    <strong>Report Date:</strong> ${new Date().toLocaleDateString()}<br>
                    <strong>Total Records:</strong> ${n.length}
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Time</th>
                        <th>Note / Reason</th>
                    </tr>
                </thead>
                <tbody>
                    ${n.map(a=>`
                        <tr>
                            <td>${a.date}</td>
                            <td class="status-${(a.status||"").toLowerCase().replace(" ","")}">${a.status}</td>
                            <td>${a.time||"--:--"}</td>
                            <td>${a.note||"-"}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
            <div style="margin-top: 50px; text-align: center; font-size: 0.7rem; color: #94a3b8;">
                This is a computer-generated report from the MEC Staff Portal.
            </div>
            <script>
                window.onload = () => {
                    setTimeout(() => {
                        window.print();
                        // window.close(); // Optional: close after print
                    }, 500);
                };
            <\/script>
        </body>
        </html>
    `,o=window.open("","_blank");o.document.write(t),o.document.close(),c("📅 Generating PDF Report...")};window.openLeaveModal=()=>{document.getElementById("leave-modal").style.display="flex",document.getElementById("leave-date").value=new Date().toISOString().split("T")[0]};window.submitLeaveRequest=async()=>{var s,p;const e=document.getElementById("leave-date"),n=document.getElementById("leave-type"),t=document.getElementById("leave-reason"),o=e?e.value:"",a=n?n.value:"Half Day",l=t?t.value.trim():"";if(!o||!l)return c("⚠️ Please fill all fields (Date & Reason).");let i=window.currentStaff;if(!i)try{i=JSON.parse(sessionStorage.getItem("mec_staff_session")||localStorage.getItem("mec_staff_session")||"{}")}catch{i={}}const m=i.docId||i.regno||i.id||"EMP-UNKNOWN",d=i.name||((s=document.getElementById("disp-name"))==null?void 0:s.innerText)||"Staff Member",y=i.role||((p=document.getElementById("disp-role"))==null?void 0:p.innerText)||"Staff",f=i.storeId||"mec-book-shop",r=document.querySelector("#leave-modal button.btn-login:last-child");r&&(r.disabled=!0,r.innerText="Submitting...");try{await B(h(w,"leave_requests"),{empId:m,empName:d,empRole:y,empPhone:i.phone||"",date:o,type:a,reason:l,status:"Pending",storeId:f,timestamp:$()}),c("✅ Leave request submitted successfully!");const u=document.getElementById("leave-modal");u&&(u.style.display="none"),t&&(t.value="")}catch(u){console.error("Leave request error:",u),c(`❌ Error: ${u.message||"Failed to submit request"}`)}finally{r&&(r.disabled=!1,r.innerText="Submit Request")}};let g=null,E="environment",L=null,A=null;window.startAttendanceClock=()=>{if(!navigator.geolocation)return c("GPS Geolocation not supported on this device.");c("📍 Accessing GPS coordinates..."),navigator.geolocation.getCurrentPosition(e=>{L=e.coords.latitude,A=e.coords.longitude,document.getElementById("scanner-modal").style.display="flex",g||(g=new Html5Qrcode("scanner-reader")),k()},e=>{console.error("GPS Error:",e),c("❌ Unable to verify location. Enable GPS/Location Services.")},{enableHighAccuracy:!0,timeout:6e3})};const k=()=>{const e={fps:20,qrbox:(n,t)=>({width:Math.floor(n*.7),height:Math.floor(t*.7)})};g.start({facingMode:E},e,G).catch(n=>{console.error("Camera access error:",n),c("Cannot open camera. Check permissions.")})};window.toggleCamera=()=>{E=E==="environment"?"user":"environment",g&&g.isScanning&&g.stop().then(()=>k())};window.closeScanner=()=>{g&&g.isScanning?g.stop().then(()=>{document.getElementById("scanner-modal").style.display="none"}):document.getElementById("scanner-modal").style.display="none"};const G=async e=>{const n=e.trim();if(!n.startsWith("MEC-POS-ATTENDANCE-QR:")){c("⚠️ Invalid QR Code. Scan the Shop QR Code.");return}window.closeScanner(),c("🔄 Verifying physical presence...");const t=n.split(":");t[1];const o=parseFloat(t[2]),a=parseFloat(t[3]),l=6371e3,i=L*Math.PI/180,m=o*Math.PI/180,d=(o-L)*Math.PI/180,y=(a-A)*Math.PI/180,f=Math.sin(d/2)*Math.sin(d/2)+Math.cos(i)*Math.cos(m)*Math.sin(y/2)*Math.sin(y/2),r=2*Math.atan2(Math.sqrt(f),Math.sqrt(1-f)),s=l*r;if(s>100){c(`❌ Out of range: you must be within 100m. Current distance: ${s.toFixed(1)}m`);return}try{const p=new Date,u=p.toLocaleDateString("sv-SE"),b=p.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit"});await B(h(w,"attendance"),{empId:window.currentStaff.docId,empName:window.currentStaff.name,date:u,time:b,status:"Present",note:`GPS+QR Verified (Distance: ${s.toFixed(1)}m)`,storeId:window.currentStaff.storeId||"mec-book-shop",timestamp:$()}),c("✅ Attendance Marked successfully!")}catch(p){console.error(p),c("Error logging attendance to database.")}};
